"""Five standard report tabs and optional complete text evidence, one row per case."""

from datetime import datetime
from math import ceil
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from ..excel_evidence import check_sheet_capacity, excel_value, text_parts
from .models import AnalysisResult
from .preprocessing import AGING_BUCKET_ORDER
from .utils import existing_columns

PROCESSED_COLUMNS = [
    "Analysis_Row_ID",
    "Case_Id",
    "control_logical_code",
    "audit_priority",
    "audit_risk_score",
    "in_priority_queue",
    "in_manual_review",
    "risk_reasons",
    "status",
    "status_normalized",
    "final_decision",
    "decision_normalized",
    "control_execution_date",
    "closure_date",
    "days_to_close",
    "case_age_days",
    "aging_bucket",
    "aged_over_30_days",
    "aged_over_60_days",
    "aged_over_90_days",
    "execution_month",
    "historic_comments_count",
    "historic_comments_count_numeric",
    "has_comment",
    "isautoclosed",
    "auto_close_category",
    "has_workflow_exception",
    "workflow_exception",
    "negative_case_age",
    "completed_without_comments_derived",
    "control_description",
    "hit_search_items",
    "historic_comments_markdown",
]
AGE_BUCKETS = list(AGING_BUCKET_ORDER)
BACKLOG_COLUMNS = [
    "open_0_5_days",
    "open_6_15_days",
    "open_16_30_days",
    "open_31_60_days",
    "open_61_90_days",
    "open_over_90_days",
    "open_unknown_age",
]
NAVY = "243746"
BLUE = "365F78"


def _aging_matrix(summary: pd.DataFrame, index: str) -> pd.DataFrame:
    """Put mutually exclusive age buckets in columns, retaining unknown ages/controls."""
    summary = summary.copy()
    summary["aging_bucket"] = summary["aging_bucket"].astype("string").fillna("Unknown")
    return (
        summary.pivot(index=index, columns="aging_bucket", values="cases")
        .reindex(columns=AGE_BUCKETS)
        .fillna(0)
        .astype(int)
        .reset_index()
    )


def _processed_data(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Select the documented export columns and order the already identified rows."""
    processed = dataframe.copy()
    return processed[existing_columns(processed, PROCESSED_COLUMNS)].sort_values(
        ["audit_risk_score", "case_age_days", "control_logical_code", "Analysis_Row_ID"],
        ascending=[False, False, True, True],
    )


def _new_sheet(writer: pd.ExcelWriter, name: str, note: str) -> None:
    """Create a consistently styled sheet with a title and interpretation note."""
    sheet = writer.book.create_sheet(name)
    sheet.sheet_view.showGridLines = False
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
    sheet.sheet_properties.tabColor = NAVY if name == "Overview" else BLUE
    sheet.cell(2, 1, name).font = Font(name="Arial", size=16, bold=True, color=NAVY)
    sheet.cell(3, 1, note).font = Font(name="Arial", size=10, italic=True, color="52616B")
    sheet.row_dimensions[2].height = 26
    sheet.row_dimensions[3].height = 20
    sheet.sheet_view.zoomScale = 85


def _prepare_text(
    dataframe: pd.DataFrame,
    sheet_name: str,
    table_name: str,
    header_row: int,
    evidence: list[dict[str, Any]],
) -> pd.DataFrame:
    """Copy text to safe cells and preserve oversized values in a companion table.

    Every companion part identifies its source table, worksheet row and column,
    plus Analysis_Row_ID where available. The source cell contains a marked
    preview; all parts, including the first, are stored in Text Evidence. Other
    scalar types stay with pandas so its missing/date serialization is preserved.
    """
    prepared = dataframe.copy()
    for position, (_, source) in enumerate(dataframe.iterrows()):
        for column, field in enumerate(dataframe.columns):
            value = source[field]
            if not isinstance(value, str):
                continue
            value = excel_value(value)
            parts = text_parts(value)
            if len(parts) > 1:
                record = len(evidence) + 1
                for part, text in enumerate(parts, 1):
                    evidence.append(
                        {
                            "evidence_record": record,
                            "source_sheet": sheet_name,
                            "source_table": table_name,
                            "source_row": header_row + position + 1,
                            "source_column": field,
                            "Analysis_Row_ID": source.get("Analysis_Row_ID"),
                            "text_part": f"{part}/{len(parts)}",
                            "text": text,
                        }
                    )
                value = f"[Full text: Text Evidence, record {record}]\n{parts[0]}"
            prepared.iat[position, column] = value
    return prepared


def _write_table(
    writer: pd.ExcelWriter,
    dataframe: pd.DataFrame,
    sheet_name: str,
    table_name: str,
    title: str,
    *,
    text_evidence: list[dict[str, Any]],
    row: int = 5,
    column: int = 1,
) -> int:
    """Write literal cells, collect oversized text, and return the next section row.

    ``text_evidence`` accumulates complete ordered text parts across workbook
    tables. Main table row counts and numerical measures are unchanged. Reject
    overflowing worksheet dimensions before pandas can truncate or omit rows.
    """
    sheet = writer.sheets[sheet_name]
    sheet.cell(row, column, title).font = Font(name="Arial", size=11, bold=True, color=NAVY)
    header_row = row + 1
    check_sheet_capacity(
        header_row + len(dataframe), column + len(dataframe.columns) - 1, sheet_name
    )
    dataframe = _prepare_text(dataframe, sheet_name, table_name, header_row, text_evidence)
    dataframe.to_excel(
        writer, sheet_name=sheet_name, index=False, startrow=header_row - 1, startcol=column - 1
    )
    last_column = column + len(dataframe.columns) - 1
    last_row = header_row + len(dataframe)
    for offset, field in enumerate(dataframe.columns):
        position = column + offset
        letter = get_column_letter(position)
        text_lengths = dataframe[field].astype("string").str.len()
        longest = int(text_lengths.max()) if text_lengths.notna().any() else 0
        width = min(max(len(str(field)) + 2, longest + 2, 14), 32)
        if field in {"historic_comments_markdown", "workflow_exception", "risk_reasons"}:
            width = 48
        sheet.column_dimensions[letter].width = max(sheet.column_dimensions[letter].width, width)
        header = sheet.cell(header_row, position)
        header.font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
        header.fill = PatternFill("solid", fgColor=BLUE)
        header.border = Border(right=Side(style="thin", color="FFFFFF"))
        header.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        rate = "rate" in field or "share" in field or field == "breach_item_coverage"
        for cells in sheet.iter_rows(
            min_row=header_row + 1, max_row=last_row, min_col=position, max_col=position
        ):
            cell = cells[0]
            cell.font = Font(name="Arial", size=10, color="243746")
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            if isinstance(cell.value, str):
                cell.data_type = "s"
            elif isinstance(cell.value, datetime):
                cell.number_format = "yyyy-mm-dd hh:mm:ss"
            elif isinstance(cell.value, (int, float)) and not isinstance(cell.value, bool):
                fractional = isinstance(cell.value, float) and not cell.value.is_integer()
                duration = field.endswith("days_to_close") or field == "case_age_days"
                cell.number_format = (
                    "0.0%" if rate else "#,##0.00" if duration or fractional else "#,##0"
                )
            if isinstance(cell.value, str):
                lines = sum(
                    max(1, ceil(len(line) / (width - 2))) for line in cell.value.split("\n")
                )
                sheet.row_dimensions[cell.row].height = max(
                    sheet.row_dimensions[cell.row].height or 24, min(409, lines * 14 + 6)
                )
    sheet.row_dimensions[header_row].height = 44
    for position in range(header_row + 1, last_row + 1):
        sheet.row_dimensions[position].height = max(sheet.row_dimensions[position].height or 24, 24)
    if len(dataframe):
        ref = f"{get_column_letter(column)}{header_row}:{get_column_letter(last_column)}{last_row}"
        table = Table(displayName=table_name, ref=ref)
        table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
        sheet.add_table(table)
    else:
        sheet.cell(header_row + 1, column, "No rows identified.")
    return max(last_row, header_row + 1) + 3


def write_workbook(
    result: AnalysisResult, output_file: str | Path, *, input_file: str | Path
) -> None:
    """Save five standard tabs and optional complete text evidence without mutation.

    Input/output paths are explicit; this writer does not load configuration or
    create parent directories. Source text remains literal Excel text. Table
    names, cell formats, unknown values and review order retain their contracts.
    XML controls become visible escapes. Oversized source cells have marked
    previews and ordered complete parts in an optional Text Evidence sheet;
    Processed Data remains one row per analyzed case.
    """
    summaries = result.summaries
    processed = _processed_data(result.cases)
    population = summaries["population"]
    review = summaries["review_signals"]
    backlog = _aging_matrix(summaries["open_backlog_summary"], "control_logical_code")
    backlog = backlog.rename(columns=dict(zip(AGE_BUCKETS, BACKLOG_COLUMNS, strict=True)))
    controls = summaries["control_scorecard"].merge(backlog, on="control_logical_code", how="left")
    controls[BACKLOG_COLUMNS] = controls[BACKLOG_COLUMNS].fillna(0).astype(int)
    text_evidence: list[dict[str, Any]] = []

    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        _new_sheet(writer, "Overview", "Counts represent analyzed rows. Blank values are unknown.")
        _new_sheet(
            writer,
            "Control Analysis",
            "Rates use all rows for each control. Open age buckets cover processing rows.",
        )
        _new_sheet(writer, "Monthly Trends", "Grouped by execution month and control.")
        _new_sheet(
            writer,
            "Hit Search Analysis",
            "Items count once per row and can overlap. Attribution comes from the source.",
        )
        _new_sheet(writer, "Processed Data", f"Source: {Path(input_file).name}")

        population_end = _write_table(
            writer,
            population,
            "Overview",
            "FoxPopulation",
            "Population",
            text_evidence=text_evidence,
        )
        review_end = _write_table(
            writer,
            review,
            "Overview",
            "FoxReview",
            "Review signals",
            column=4,
            text_evidence=text_evidence,
        )
        row = max(population_end, review_end)
        for key, name, title in [
            ("status_summary", "FoxStatus", "Status"),
            ("decision_summary", "FoxDecisions", "Decisions"),
            ("auto_closure_summary", "FoxAutoClosure", "Automatic closure"),
        ]:
            row = _write_table(
                writer,
                summaries[key],
                "Overview",
                name,
                title,
                row=row,
                text_evidence=text_evidence,
            )
        _write_table(
            writer,
            _aging_matrix(summaries["aging_summary"], "status_normalized"),
            "Overview",
            "FoxAging",
            "Age buckets by status",
            row=row,
            text_evidence=text_evidence,
        )
        _write_table(
            writer,
            controls,
            "Control Analysis",
            "FoxControls",
            "Control scorecard and backlog",
            text_evidence=text_evidence,
        )
        _write_table(
            writer,
            summaries["monthly_trends"],
            "Monthly Trends",
            "FoxMonthly",
            "Monthly results",
            text_evidence=text_evidence,
        )
        row = _write_table(
            writer,
            summaries["hit_search_summary"],
            "Hit Search Analysis",
            "FoxHitCoverage",
            "Breach attribution coverage",
            text_evidence=text_evidence,
        )
        _write_table(
            writer,
            summaries["hit_search_items"],
            "Hit Search Analysis",
            "FoxHitItems",
            "Items appearing on breach rows",
            row=row,
            text_evidence=text_evidence,
        )
        _write_table(
            writer,
            processed,
            "Processed Data",
            "FoxProcessedData",
            "Analyzed records",
            text_evidence=text_evidence,
        )
        if text_evidence:
            _new_sheet(
                writer,
                "Text Evidence",
                "Complete escaped text. Concatenate text parts in order for each evidence_record.",
            )
            _write_table(
                writer,
                pd.DataFrame(text_evidence),
                "Text Evidence",
                "FoxTextEvidence",
                "Complete source text",
                text_evidence=[],
            )
            writer.sheets["Text Evidence"].freeze_panes = "H7"
        sheet = writer.sheets["Processed Data"]
        sheet.cell(
            4,
            1,
            "Filter status_normalized, has_workflow_exception, "
            "completed_without_comments_derived, in_priority_queue or in_manual_review.",
        )
        sheet.cell(4, 1).font = Font(name="Arial", size=10, italic=True, color="52616B")
        sheet.freeze_panes = "D7"
        for name in ["Control Analysis", "Monthly Trends"]:
            writer.sheets[name].freeze_panes = "B7"
        priority_column = get_column_letter(processed.columns.get_loc("audit_priority") + 1)
        for label, fill, color in [
            ("Critical", "FCE4D6", "9C0006"),
            ("High", "FFF2CC", "9C5700"),
            ("Medium", "FFF8E1", "805500"),
        ]:
            sheet.conditional_formatting.add(
                f"{priority_column}7:{priority_column}{len(processed) + 6}",
                CellIsRule(
                    operator="equal",
                    formula=[f'"{label}"'],
                    fill=PatternFill("solid", fgColor=fill),
                    font=Font(name="Arial", color=color, bold=True),
                ),
            )
