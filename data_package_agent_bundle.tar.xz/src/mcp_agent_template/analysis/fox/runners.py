"""Orchestration entry points for FOX case audit analysis."""

from pathlib import Path
from uuid import uuid4

import pandas as pd

from mcp_agent_template.config import get_settings
from mcp_agent_template.logging_utils import get_logger

from .export import write_workbook
from .hit_search_analysis import build_hit_search_summaries
from .markdown_report import render_markdown
from .models import AnalysisResult
from .preprocessing import (
    current_snapshot,
    deduplicate_case_ids,
    load_cases,
    prepare_cases,
    validate_cases,
)
from .risk_analysis import score_and_select_reviews
from .summary_analysis import build_summaries, collect_analysis_result

logger = get_logger(__name__)


def analyze_cases(dataframe: pd.DataFrame, *, snapshot_at: pd.Timestamp) -> AnalysisResult:
    """Calculate a complete case review without settings, clock reads or file I/O.

    Args:
        dataframe: Source-schema rows. The input is not mutated. Existing sparse
            column pruning precedes exact-row deduplication and normalization.
        snapshot_at: Server-local timestamp used for rows without closure dates.
            Supply the same timestamp to reproduce age-dependent scores.

    Returns:
        Owned case/result frames, including run-local IDs, ordered overlapping
        queues, duplicate disclosures and shared report measures. Conflicting
        records with the same Case_Id remain distinct.

    Raises:
        ValueError: The dataset is empty, required columns are missing, or
            comment counts are invalid, using the existing validation messages;
            also when the explicit snapshot is missing or unparseable.
    """
    snapshot_at = pd.Timestamp(snapshot_at)
    if pd.isna(snapshot_at):
        raise ValueError("snapshot_at must be a valid server-local timestamp.")
    source_row_count = len(dataframe)
    dataframe = validate_cases(dataframe)
    dataframe, duplicate_details = deduplicate_case_ids(dataframe)
    # IDs must not participate in duplicate comparison or depend on pandas indexes.
    dataframe["Analysis_Row_ID"] = range(1, len(dataframe) + 1)
    dataframe, snapshot_date = prepare_cases(dataframe, snapshot_at=snapshot_at)
    dataframe, priority_cases, manual_review = score_and_select_reviews(dataframe)
    summaries = build_summaries(dataframe, snapshot_date)
    summaries.update(build_hit_search_summaries(dataframe))
    return collect_analysis_result(
        dataframe,
        summaries,
        priority_cases,
        manual_review,
        snapshot_at=snapshot_date,
        source_row_count=source_row_count,
        duplicate_details=duplicate_details,
    )


def run_fox_analysis(
    input_file: str | Path,
    output_file: str | Path | None = None,
    markdown_file: str | Path | None = None,
    *,
    output_dir: str | Path | None = None,
) -> str:
    """Preserve the file-based analysis interface and return the saved Markdown.

    Read one Parquet source without modifying it, capture the current local
    datetime once, and write the existing Excel/Markdown reports. Default output
    uses a unique run folder; explicit paths and their parent creation remain
    supported. Validation and filesystem errors propagate to the caller.
    """
    input_file = Path(input_file)
    dataframe = load_cases(input_file)
    result = analyze_cases(dataframe, snapshot_at=current_snapshot())
    logger.info(
        "Loaded %s rows and %s columns after sparse-column pruning; removed %s duplicate rows.",
        result.source_row_count,
        len(dataframe.columns),
        result.source_row_count - len(result.cases),
    )
    logger.info(
        "Analytical snapshot datetime (server local time): %s", result.snapshot_at.isoformat()
    )

    if output_file is None:
        if output_dir is None:
            settings = get_settings()
            output_dir = settings.resolve_path(settings.analysis_results_dir) / "fox"
        run_directory = Path(output_dir).expanduser().resolve() / uuid4().hex
        run_directory.mkdir(parents=True, exist_ok=False)
        output_file = run_directory / "FOX_audit_analysis.xlsx"
    else:
        output_file = Path(output_file).expanduser().resolve()
        output_file.parent.mkdir(parents=True, exist_ok=True)
    markdown_file = (
        Path(markdown_file).expanduser().resolve()
        if markdown_file is not None
        else output_file.with_suffix(".md")
    )
    markdown_file.parent.mkdir(parents=True, exist_ok=True)

    write_workbook(result, output_file, input_file=input_file)
    report = render_markdown(result, input_file, output_file, markdown_file)
    markdown_file.write_text(report, encoding="utf-8")

    logger.info("Analysis complete. Output file: %s", output_file.resolve())
    logger.info("Markdown file: %s", markdown_file.resolve())
    logger.info("Cases analyzed: %s", len(result.cases))
    logger.info("Workflow exceptions: %s", result.cases["has_workflow_exception"].sum())
    logger.info(
        "Completed without comments: %s",
        result.cases["completed_without_comments_derived"].sum(),
    )
    logger.info("Priority cases: %s", len(result.priority_cases))
    logger.info("Manual-review cases: %s", len(result.manual_review))
    return report


def main() -> None:
    """Run the analysis for a Parquet dataset supplied on the command line."""
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_file", type=Path, help="Path to the FOX case Parquet file.")
    parser.add_argument("--output-file", type=Path)
    parser.add_argument("--markdown-file", type=Path)
    args = parser.parse_args()
    print(run_fox_analysis(args.input_file, args.output_file, args.markdown_file))


if __name__ == "__main__":
    main()
