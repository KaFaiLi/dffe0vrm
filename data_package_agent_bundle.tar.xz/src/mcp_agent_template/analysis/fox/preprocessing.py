"""FOX case loading and feature preparation."""

from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import polars as pl

from .risk_analysis import add_workflow_features
from .utils import (
    clean_text,
    normalize_decision,
    normalize_status,
    require_columns,
)

REQUIRED_COLUMNS = [
    "Case_Id",
    "control_logical_code",
    "control_description",
    "control_execution_date",
    "status",
    "final_decision",
    "historic_comments_count",
    "hit_search_items",
]
REPORT_COLUMNS = {
    "historic_comments_markdown",
    "control_description",
    "closure_date",
    "isautoclosed",
}
AGING_THRESHOLDS = (30, 60, 90)
AGING_BUCKET_ORDER = (
    "0-5 days",
    "6-15 days",
    "16-30 days",
    "31-60 days",
    "61-90 days",
    "Over 90 days",
    "Unknown",
)
DUPLICATE_DETAIL_COLUMNS = ["Case_Id", "Record", "Column", "Value"]


def deduplicate_case_ids(
    dataframe: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Remove exact duplicate rows and report differences for repeated Case_Id values."""
    cleaned = dataframe.reset_index(drop=True).drop_duplicates().copy()
    remaining_duplicates = cleaned.loc[cleaned["Case_Id"].duplicated(keep=False)]

    details = []
    for case_id, group in remaining_duplicates.groupby("Case_Id", sort=False):
        different_columns = [
            column
            for column in cleaned.columns
            if column != "Case_Id" and group[column].nunique(dropna=False) > 1
        ]

        for record_number, (_, row) in enumerate(group.iterrows(), start=1):
            details.extend(
                {
                    "Case_Id": case_id,
                    "Record": record_number,
                    "Column": column,
                    "Value": row[column],
                }
                for column in different_columns
            )

    return cleaned, pd.DataFrame(details, columns=DUPLICATE_DETAIL_COLUMNS)


def load_cases(input_file: str | Path) -> pd.DataFrame:
    """Read, validate, and prune sparse fields from the input dataset."""
    input_file = Path(input_file)
    if not input_file.exists():
        raise FileNotFoundError(f"Input file not found: {input_file.resolve()}")

    source = pl.read_parquet(input_file).with_columns(pl.col(pl.Float32, pl.Float64).fill_nan(None))
    dataframe = pd.DataFrame(source.to_dict(as_series=False))
    return validate_cases(dataframe)


def validate_cases(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Validate and prune source columns before duplicate comparison.

    Return an owned frame, retaining required/report fields even when sparse.
    Empty populations or missing required columns raise ValueError. The caller's
    frame is not modified; duplicate removal must follow this projection.
    """
    require_columns(dataframe, REQUIRED_COLUMNS)
    if dataframe.empty:
        raise ValueError("The post-trade control dataset contains no rows.")
    dataframe = dataframe.drop(columns=["historic_comments", "attachment_count"], errors="ignore")
    return prune_sparse_columns(dataframe)


def prune_sparse_columns(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Drop mostly-empty columns while retaining fields used in FOX reporting."""
    null_rates = dataframe.isna().mean()
    keep_columns = [
        column
        for column in dataframe.columns
        if dataframe.empty
        or null_rates[column] < 0.70
        or column in REPORT_COLUMNS
        or column in REQUIRED_COLUMNS
    ]
    return dataframe.loc[:, keep_columns].copy()


def current_snapshot() -> pd.Timestamp:
    """Capture the current server-local datetime, including fractional days."""
    return pd.Timestamp(datetime.now())


def create_aging_bucket(days: pd.Series) -> pd.Series:
    """Bucket durations using the existing inclusive upper bounds, including negatives."""
    return pd.cut(days, bins=[-np.inf, 5, 15, 30, 60, 90, np.inf], labels=AGING_BUCKET_ORDER[:-1])


def prepare_cases(
    dataframe: pd.DataFrame, *, snapshot_at: pd.Timestamp | None = None
) -> tuple[pd.DataFrame, pd.Timestamp]:
    """Return normalized facts and workflow flags without mutating the input.

    Args:
        dataframe: Rows with the required source columns, normally deduplicated.
        snapshot_at: Explicit server-local timestamp for reproducible analysis.
            Omission preserves the current-time behavior for existing callers.

    Returns:
        An owned frame and the timestamp used for unclosed ages. Closure dates
        take precedence regardless of status. Missing dates remain unknown;
        durations retain fractions of a day. Existing workflow columns remain.

    Raises:
        ValueError: Required fields are missing or comment counts are invalid.
    """
    snapshot_date = current_snapshot() if snapshot_at is None else pd.Timestamp(snapshot_at)
    dataframe = dataframe.copy()
    require_columns(dataframe, REQUIRED_COLUMNS)
    dataframe["control_execution_date"] = pd.to_datetime(
        dataframe["control_execution_date"], errors="coerce"
    )
    if "closure_date" in dataframe.columns:
        dataframe["closure_date"] = pd.to_datetime(dataframe["closure_date"], errors="coerce")
    else:
        dataframe["closure_date"] = pd.NaT

    dataframe["status_normalized"] = normalize_status(dataframe["status"])
    dataframe["decision_normalized"] = normalize_decision(dataframe["final_decision"])
    dataframe["control_logical_code"] = clean_text(dataframe["control_logical_code"])
    dataframe["control_description"] = clean_text(dataframe["control_description"])

    dataframe["is_completed"] = dataframe["status_normalized"].eq("completed")
    dataframe["is_processing"] = dataframe["status_normalized"].eq("processing")
    dataframe["is_canceled"] = dataframe["status_normalized"].eq("canceled")
    dataframe["has_decision"] = ~dataframe["decision_normalized"].eq("no decision")
    dataframe["has_closure_date"] = dataframe["closure_date"].notna()
    dataframe["days_to_close"] = (
        dataframe["closure_date"] - dataframe["control_execution_date"]
    ).dt.total_seconds() / 86400

    dataframe["case_age_days"] = np.where(
        dataframe["has_closure_date"],
        dataframe["days_to_close"],
        (snapshot_date - dataframe["control_execution_date"]).dt.total_seconds() / 86400,
    )
    dataframe["negative_case_age"] = dataframe["case_age_days"].lt(0)
    dataframe["aging_bucket"] = create_aging_bucket(dataframe["case_age_days"])
    for threshold in AGING_THRESHOLDS:
        dataframe[f"aged_over_{threshold}_days"] = dataframe["case_age_days"].gt(threshold)

    raw_counts = dataframe["historic_comments_count"]
    counts = pd.to_numeric(raw_counts, errors="coerce")
    if (
        (raw_counts.notna() & counts.isna()) | counts.lt(0) | (counts.notna() & counts.mod(1).ne(0))
    ).any():
        raise ValueError("historic_comments_count must contain nonnegative whole numbers or null.")
    dataframe["historic_comments_count_numeric"] = counts
    dataframe["has_comment"] = counts.gt(0).fillna(False)

    if "isautoclosed" in dataframe.columns:
        dataframe["auto_close_category"] = (
            clean_text(dataframe["isautoclosed"])
            .str.lower()
            .map({"false": "Manual", "true": "Auto"})
            .fillna("Unknown")
        )
    else:
        dataframe["auto_close_category"] = "Unknown"

    dataframe["completed_without_comments_derived"] = dataframe["is_completed"] & counts.eq(
        0
    ).fillna(False)

    dataframe["execution_month"] = (
        dataframe["control_execution_date"].dt.to_period("M").astype("string")
    )
    # Keep prepare_cases' existing workflow columns for direct callers.
    dataframe = add_workflow_features(dataframe)

    return dataframe, snapshot_date
