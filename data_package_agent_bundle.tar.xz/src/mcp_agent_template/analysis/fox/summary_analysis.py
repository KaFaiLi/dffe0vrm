"""Population, control, trend, and executive FOX summaries."""

import pandas as pd

from .models import AnalysisResult
from .preprocessing import AGING_BUCKET_ORDER, AGING_THRESHOLDS
from .risk_analysis import PRIORITY_LABELS
from .utils import percentile_90, safe_rate


def _summarize_monthly_cases(dataframe: pd.DataFrame, group_columns: list[str]) -> pd.DataFrame:
    """Use the same row measures at each grain, calculating medians from case durations."""
    return (
        dataframe.groupby(group_columns, dropna=False)
        .agg(
            cases=("Case_Id", "size"),
            justified_cases=("decision_normalized", lambda values: values.eq("justified").sum()),
            false_anomaly_cases=(
                "decision_normalized",
                lambda values: values.eq("false anomaly").sum(),
            ),
            breach_cases=("decision_normalized", lambda values: values.eq("breach").sum()),
            no_decision_cases=(
                "decision_normalized",
                lambda values: values.eq("no decision").sum(),
            ),
            open_cases=("is_processing", "sum"),
            auto_closed_cases=("auto_close_category", lambda values: values.eq("Auto").sum()),
            completed_without_comments=("completed_without_comments_derived", "sum"),
            median_days_to_close=("days_to_close", "median"),
        )
        .reset_index()
    )


def build_summaries(
    dataframe: pd.DataFrame, snapshot_date: pd.Timestamp
) -> dict[str, pd.DataFrame]:
    """Return grouped and executive tables without mutating prepared/scored cases.

    Counts are retained rows, including repeated case IDs. Control rates use
    all rows for that control. Monthly medians use available case durations,
    including the current date-quality exceptions, at each requested grain.
    Inputs come from preparation/scoring and include execution_month.
    """
    dataframe = dataframe.copy()
    control_rows = []
    for control, group in dataframe.groupby("control_logical_code", dropna=False):
        case_count = len(group)
        control_rows.append(
            {
                "control_logical_code": control,
                "cases": case_count,
                "population_share": safe_rate(case_count, len(dataframe)),
                "justified_cases": group["decision_normalized"].eq("justified").sum(),
                "justified_rate": group["decision_normalized"].eq("justified").mean(),
                "false_anomaly_cases": group["decision_normalized"].eq("false anomaly").sum(),
                "false_anomaly_rate": group["decision_normalized"].eq("false anomaly").mean(),
                "breach_cases": group["decision_normalized"].eq("breach").sum(),
                "breach_rate": group["decision_normalized"].eq("breach").mean(),
                "no_decision_cases": group["decision_normalized"].eq("no decision").sum(),
                "no_decision_rate": group["decision_normalized"].eq("no decision").mean(),
                "open_cases": group["is_processing"].sum(),
                "open_rate": group["is_processing"].mean(),
                "canceled_cases": group["is_canceled"].sum(),
                "auto_closed_cases": group["auto_close_category"].eq("Auto").sum(),
                "auto_close_rate": group["auto_close_category"].eq("Auto").mean(),
                "median_days_to_close": group["days_to_close"].median(),
                "p90_days_to_close": percentile_90(group["days_to_close"]),
                "maximum_days_to_close": group["days_to_close"].max(),
                "cases_over_30_days": group["aged_over_30_days"].sum(),
                "cases_over_60_days": group["aged_over_60_days"].sum(),
                "cases_over_90_days": group["aged_over_90_days"].sum(),
                "completed_without_comments": group["completed_without_comments_derived"].sum(),
                "completed_without_comments_rate": group[
                    "completed_without_comments_derived"
                ].mean(),
                "workflow_exception_cases": group["has_workflow_exception"].sum(),
                "first_execution_date": group["control_execution_date"].min(),
                "last_execution_date": group["control_execution_date"].max(),
            }
        )
    control_scorecard = pd.DataFrame(control_rows).sort_values("cases", ascending=False)

    status_summary = (
        dataframe.groupby("status_normalized", dropna=False)
        .agg(
            cases=("Case_Id", "size"),
            cases_with_decision=("has_decision", "sum"),
            cases_with_closure_date=("has_closure_date", "sum"),
            workflow_exceptions=("has_workflow_exception", "sum"),
        )
        .reset_index()
        .sort_values("cases", ascending=False)
    )
    decision_summary = (
        dataframe.groupby("decision_normalized", dropna=False)
        .agg(
            cases=("Case_Id", "size"),
            median_days_to_close=("days_to_close", "median"),
            completed_without_comments=("completed_without_comments_derived", "sum"),
        )
        .reset_index()
        .sort_values("cases", ascending=False)
    )
    aging_summary = (
        dataframe.groupby(["status_normalized", "aging_bucket"], observed=True, dropna=False)
        .agg(cases=("Case_Id", "size"))
        .reset_index()
    )

    open_cases = (
        dataframe[dataframe["is_processing"]]
        .copy()
        .sort_values(["case_age_days", "control_logical_code"], ascending=[False, True])
    )
    open_backlog_summary = (
        open_cases.groupby(["control_logical_code", "aging_bucket"], observed=True, dropna=False)
        .agg(cases=("Case_Id", "size"))
        .reset_index()
    )

    auto_closure_summary = (
        dataframe.groupby("auto_close_category", dropna=False)
        .agg(
            cases=("Case_Id", "size"),
            justified_cases=("decision_normalized", lambda values: values.eq("justified").sum()),
            false_anomaly_cases=(
                "decision_normalized",
                lambda values: values.eq("false anomaly").sum(),
            ),
            breach_cases=("decision_normalized", lambda values: values.eq("breach").sum()),
            open_cases=("is_processing", "sum"),
            median_days_to_close=("days_to_close", "median"),
            p90_days_to_close=("days_to_close", percentile_90),
            completed_without_comments=("completed_without_comments_derived", "sum"),
        )
        .reset_index()
    )

    monthly_trends = _summarize_monthly_cases(
        dataframe, ["execution_month", "control_logical_code"]
    )
    monthly_summary = _summarize_monthly_cases(dataframe, ["execution_month"])

    executive_summary = pd.DataFrame(
        {
            "metric": [
                "Input cases",
                "Input columns",
                "Distinct controls",
                "Snapshot date",
                "Completed cases",
                "Processing cases",
                "Canceled cases",
                "Justified cases",
                "False anomaly cases",
                "Breach cases",
                "Cases without decision",
                "Median days to close",
                "90th percentile days to close",
                "Cases aged over 30 days",
                "Cases aged over 60 days",
                "Cases aged over 90 days",
                "Workflow exceptions",
                "Completed without comments",
                "Auto-closed cases",
                "High-priority cases",
                "Critical-priority cases",
            ],
            "value": [
                len(dataframe),
                len(
                    dataframe.columns.difference(
                        ["Analysis_Row_ID", "in_priority_queue", "in_manual_review"]
                    )
                ),
                dataframe["control_logical_code"].nunique(dropna=True),
                snapshot_date,
                int(dataframe["is_completed"].sum()),
                int(dataframe["is_processing"].sum()),
                int(dataframe["is_canceled"].sum()),
                int(dataframe["decision_normalized"].eq("justified").sum()),
                int(dataframe["decision_normalized"].eq("false anomaly").sum()),
                int(dataframe["decision_normalized"].eq("breach").sum()),
                int(dataframe["decision_normalized"].eq("no decision").sum()),
                round(dataframe["days_to_close"].median(), 2),
                round(percentile_90(dataframe["days_to_close"]), 2),
                int(dataframe["aged_over_30_days"].sum()),
                int(dataframe["aged_over_60_days"].sum()),
                int(dataframe["aged_over_90_days"].sum()),
                int(dataframe["has_workflow_exception"].sum()),
                int(dataframe["completed_without_comments_derived"].sum()),
                int(dataframe["auto_close_category"].eq("Auto").sum()),
                int(dataframe["audit_priority"].eq("High").sum()),
                int(dataframe["audit_priority"].eq("Critical").sum()),
            ],
        }
    )

    return {
        "executive_summary": executive_summary,
        "control_scorecard": control_scorecard,
        "status_summary": status_summary,
        "decision_summary": decision_summary,
        "aging_summary": aging_summary,
        "open_backlog_summary": open_backlog_summary,
        "auto_closure_summary": auto_closure_summary,
        "monthly_trends": monthly_trends,
        "monthly_summary": monthly_summary,
    }


def collect_analysis_result(
    dataframe: pd.DataFrame,
    summaries: dict[str, pd.DataFrame],
    priority_cases: pd.DataFrame,
    manual_review: pd.DataFrame,
    *,
    snapshot_at: pd.Timestamp,
    source_row_count: int,
    duplicate_details: pd.DataFrame,
) -> AnalysisResult:
    """Build the current analysis result from prepared/scored pipeline outputs.

    Own copies of the case, duplicate and ordered queue frames. Preserve row
    IDs and queue flags produced by preparation/scoring, without reconstructing
    membership from repeated case IDs or pandas indexes. Inputs are not mutated.

    Additional tables are population/review_signals (Metric, Value), open_aging
    (bucket, cases, denominator), quality_signals (signal, cases, denominator),
    priority_counts (priority, cases), execution_period (first, last), and
    control_descriptions (source code/description). Rates stay unrounded until
    presentation. Missing ages/counts and overlapping populations stay explicit.
    """
    cases = dataframe.copy()
    tables = dict(summaries)
    executive = summaries["executive_summary"].set_index("metric")["value"]
    tables["population"] = pd.DataFrame(
        [
            ("Snapshot datetime (server local)", snapshot_at),
            ("Source rows", source_row_count),
            ("Exact duplicates removed", source_row_count - len(cases)),
            ("Analyzed rows", len(cases)),
            ("Distinct non-null Case_Id", cases["Case_Id"].nunique()),
            ("Distinct non-null controls", cases["control_logical_code"].nunique()),
            ("Rows missing Case_Id", cases["Case_Id"].isna().sum()),
            ("Rows missing execution date", cases["control_execution_date"].isna().sum()),
            (
                "Rows with unknown comment count",
                cases["historic_comments_count_numeric"].isna().sum(),
            ),
        ],
        columns=["Metric", "Value"],
    )
    review_metrics = [
        "Median days to close",
        "90th percentile days to close",
        "Cases aged over 30 days",
        "Cases aged over 60 days",
        "Cases aged over 90 days",
        "Workflow exceptions",
        "Completed without comments",
        "High-priority cases",
        "Critical-priority cases",
    ]
    tables["review_signals"] = pd.DataFrame(
        [(metric, executive[metric]) for metric in review_metrics]
        + [
            ("Priority queue rows", len(priority_cases)),
            ("Manual-review rows", len(manual_review)),
        ],
        columns=["Metric", "Value"],
    )
    open_cases = cases.loc[cases["is_processing"]]
    aging_counts = open_cases["aging_bucket"].astype("string").fillna("Unknown").value_counts()
    tables["open_aging"] = pd.DataFrame(
        [
            (bucket, aging_counts.get(bucket, 0), len(open_cases))
            for bucket in AGING_BUCKET_ORDER
            if bucket in aging_counts.index or bucket != "Unknown"
        ],
        columns=["bucket", "cases", "denominator"],
    )
    quality = [
        ("Workflow exceptions", int(cases["has_workflow_exception"].sum()), len(cases)),
        (
            "Completed without comments",
            int(cases["completed_without_comments_derived"].sum()),
            len(cases),
        ),
        ("Negative case age", int(cases["negative_case_age"].sum()), len(cases)),
    ]
    for threshold in AGING_THRESHOLDS:
        column = f"aged_over_{threshold}_days"
        if column in cases:
            quality.append(
                (f"Open over {threshold} days", int(open_cases[column].sum()), len(open_cases))
            )
    tables["quality_signals"] = pd.DataFrame(quality, columns=["signal", "cases", "denominator"])
    priority_counts = cases["audit_priority"].astype("string").value_counts()
    tables["priority_counts"] = pd.DataFrame(
        [(label, priority_counts.get(label, 0)) for label in reversed(PRIORITY_LABELS)],
        columns=["priority", "cases"],
    )
    dates = cases["control_execution_date"].dropna()
    tables["execution_period"] = pd.DataFrame([{"first": dates.min(), "last": dates.max()}])
    controls = cases[["control_logical_code", "control_description"]]
    tables["control_descriptions"] = (
        controls.loc[
            controls["control_logical_code"].notna() & controls["control_logical_code"].ne("")
        ]
        .drop_duplicates("control_logical_code")
        .sort_values("control_logical_code")
    )
    return AnalysisResult(
        cases=cases,
        summaries=tables,
        duplicate_details=duplicate_details.copy(),
        snapshot_at=snapshot_at,
        source_row_count=source_row_count,
        priority_cases=priority_cases.copy(),
        manual_review=manual_review.copy(),
    )
