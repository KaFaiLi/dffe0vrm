"""Transparent case-risk scoring and review-queue selection."""

import pandas as pd

BREACH_POINTS = 5
OLD_OPEN_POINTS = 4
OPEN_POINTS = 3
WORKFLOW_POINTS = 3
UNCOMMENTED_BREACH_POINTS = 3
NEGATIVE_AGE_POINTS = 3
OPEN_AGE_THRESHOLD = 30
OLD_OPEN_AGE_THRESHOLD = 90
PRIORITY_THRESHOLD = 3
PRIORITY_BOUNDS = (2, 5, 8)
PRIORITY_LABELS = ("Low", "Medium", "High", "Critical")


def add_workflow_features(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Return the existing ordered workflow messages and row-level exception flag.

    Multiple workflow conditions remain one scoring signal. This function owns
    the predicates; prepare_cases delegates here to preserve its public result.
    The input frame is not modified.
    """
    dataframe = dataframe.copy()
    dataframe["workflow_exception"] = ""
    dataframe.loc[dataframe["is_completed"] & ~dataframe["has_decision"], "workflow_exception"] += (
        "Completed without final decision; "
    )
    dataframe.loc[
        dataframe["is_completed"] & ~dataframe["has_closure_date"], "workflow_exception"
    ] += "Completed without closure date; "
    dataframe.loc[dataframe["is_processing"] & dataframe["has_decision"], "workflow_exception"] += (
        "Processing case has final decision; "
    )
    dataframe.loc[
        dataframe["is_processing"] & dataframe["has_closure_date"], "workflow_exception"
    ] += "Processing case has closure date; "
    dataframe.loc[dataframe["days_to_close"].lt(0), "workflow_exception"] += (
        "Closure before control execution; "
    )
    dataframe.loc[
        dataframe["is_canceled"] & ~dataframe["has_closure_date"], "workflow_exception"
    ] += "Canceled without closure date; "
    dataframe["workflow_exception"] = dataframe["workflow_exception"].str.strip().str.rstrip(";")
    dataframe["has_workflow_exception"] = dataframe["workflow_exception"].ne("")

    return dataframe


def score_rules_markdown() -> str:
    """Describe the active scoring constants using the existing report wording."""
    low, medium, high = PRIORITY_BOUNDS
    return (
        f"- Breach decision: +{BREACH_POINTS}; open over {OLD_OPEN_AGE_THRESHOLD} days: "
        f"+{OLD_OPEN_POINTS}; open {OPEN_AGE_THRESHOLD + 1}–{OLD_OPEN_AGE_THRESHOLD} days: "
        f"+{OPEN_POINTS}.\n"
        f"- Workflow exception: +{WORKFLOW_POINTS}; negative case age: +{NEGATIVE_AGE_POINTS}.\n"
        f"- Breach completed without comments: an additional +{UNCOMMENTED_BREACH_POINTS} "
        "(on top of the breach score).\n"
        f"- Priority bands: Low 0–{low}, Medium {low + 1}–{medium}, "
        f"High {medium + 1}–{high}, Critical {high + 1}+."
    )


def score_and_select_reviews(
    dataframe: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Return scored rows and the two existing ordered, overlapping queue subsets.

    Input must contain prepare_cases' facts and workflow flags. No input frame
    is mutated. Each workflow row receives one contribution even if it has
    several messages; the negative-age contribution is independently additive.
    Queue flags are calculated here so reports never infer membership by index.
    """
    dataframe = dataframe.copy()
    dataframe["audit_risk_score"] = 0
    dataframe["risk_reasons"] = ""

    def add_risk_points(mask: pd.Series, points: int, reason: str) -> None:
        """Apply one contribution and its explanation to the owned case frame."""
        dataframe.loc[mask, "audit_risk_score"] += points
        dataframe.loc[mask, "risk_reasons"] += reason + "; "

    add_risk_points(dataframe["decision_normalized"].eq("breach"), BREACH_POINTS, "Breach decision")
    add_risk_points(
        dataframe["is_processing"] & dataframe["case_age_days"].gt(OLD_OPEN_AGE_THRESHOLD),
        OLD_OPEN_POINTS,
        f"Open over {OLD_OPEN_AGE_THRESHOLD} days",
    )
    add_risk_points(
        dataframe["is_processing"]
        & dataframe["case_age_days"].gt(OPEN_AGE_THRESHOLD)
        & dataframe["case_age_days"].le(OLD_OPEN_AGE_THRESHOLD),
        OPEN_POINTS,
        f"Open between {OPEN_AGE_THRESHOLD + 1} and {OLD_OPEN_AGE_THRESHOLD} days",
    )
    add_risk_points(
        dataframe["has_workflow_exception"], WORKFLOW_POINTS, "Workflow-state inconsistency"
    )
    add_risk_points(
        dataframe["completed_without_comments_derived"]
        & dataframe["decision_normalized"].eq("breach"),
        UNCOMMENTED_BREACH_POINTS,
        "Breach completed without comments",
    )
    add_risk_points(
        dataframe["negative_case_age"], NEGATIVE_AGE_POINTS, "Negative case aging or date sequence"
    )

    dataframe["risk_reasons"] = dataframe["risk_reasons"].str.strip().str.rstrip(";")
    dataframe["audit_priority"] = pd.cut(
        dataframe["audit_risk_score"],
        bins=[-float("inf"), *PRIORITY_BOUNDS, float("inf")],
        labels=PRIORITY_LABELS,
    )
    dataframe["in_priority_queue"] = dataframe["audit_risk_score"].ge(PRIORITY_THRESHOLD)
    dataframe["in_manual_review"] = (
        dataframe["decision_normalized"].eq("breach")
        | (dataframe["is_processing"] & dataframe["case_age_days"].gt(OLD_OPEN_AGE_THRESHOLD))
        | dataframe["has_workflow_exception"]
        | dataframe["negative_case_age"]
    )
    priority_cases = (
        dataframe[dataframe["in_priority_queue"]]
        .copy()
        .sort_values(
            ["audit_risk_score", "case_age_days", "control_logical_code"],
            ascending=[False, False, True],
        )
    )

    manual_review = (
        dataframe[dataframe["in_manual_review"]]
        .copy()
        .sort_values(["audit_risk_score", "case_age_days"], ascending=[False, False])
    )

    return dataframe, priority_cases, manual_review
