"""The calculated case population shared by the FOX report writers."""

from dataclasses import dataclass

import pandas as pd


@dataclass
class AnalysisResult:
    """Own one run's frames and ordered queue snapshots without performing I/O.

    ``Analysis_Row_ID`` identifies retained rows within this run, independently
    of pandas indexes and repeated ``Case_Id`` values. Keep the already ordered
    queue frames from scoring so report ordering and membership remain stable.
    Summary table keys and grains
    are documented in ``summary_analysis``. Renderers must not mutate these
    frames; the dataclass itself does not make pandas objects immutable.
    """

    cases: pd.DataFrame
    summaries: dict[str, pd.DataFrame]
    duplicate_details: pd.DataFrame
    snapshot_at: pd.Timestamp
    source_row_count: int
    priority_cases: pd.DataFrame
    manual_review: pd.DataFrame
