"""Hit-search item attribution and breach measures for every FOX analysis run."""

import pandas as pd

from .utils import clean_text, require_columns, safe_rate


def build_hit_search_summaries(dataframe: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Count items once per retained row, preserving overlap and repeated Case_Id values.

    Positional identity keeps distinct rows separate even when source IDs or
    pandas indexes repeat. Neither the frame nor source item text is changed.
    """
    require_columns(dataframe, ["decision_normalized", "hit_search_items"])
    items = dataframe[["decision_normalized", "hit_search_items"]].copy()
    items["_row_id"] = range(len(items))
    items["_is_breach"] = items["decision_normalized"].eq("breach")
    items["hit_search_items"] = items["hit_search_items"].astype("string").str.split(",")
    items = items.explode("hit_search_items", ignore_index=True)
    items["hit_search_item"] = clean_text(items["hit_search_items"])
    items = items.loc[items["hit_search_item"].notna() & items["hit_search_item"].ne("")]
    items = items.drop_duplicates(["_row_id", "hit_search_item"])

    breach_rows = int(dataframe["decision_normalized"].eq("breach").sum())
    breach_rows_with_items = int(items.loc[items["_is_breach"], "_row_id"].nunique())
    item_summary = (
        items.groupby("hit_search_item")
        .agg(rows=("_row_id", "nunique"), breach_rows=("_is_breach", "sum"))
        .reset_index()
        .query("breach_rows > 0")
        .sort_values(
            ["breach_rows", "rows", "hit_search_item"],
            ascending=[False, False, True],
        )
    )
    item_summary["share_of_breach_rows"] = item_summary["breach_rows"].map(
        lambda count: safe_rate(count, breach_rows)
    )
    item_summary["breach_rate"] = item_summary["breach_rows"] / item_summary["rows"]
    summary = pd.DataFrame(
        [
            {
                "breach_rows": breach_rows,
                "breach_rows_with_items": breach_rows_with_items,
                "breach_item_coverage": safe_rate(breach_rows_with_items, breach_rows),
                "distinct_breach_items": len(item_summary),
            }
        ]
    )
    return {"hit_search_summary": summary, "hit_search_items": item_summary}
