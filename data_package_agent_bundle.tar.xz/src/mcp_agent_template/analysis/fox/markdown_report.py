"""Evidence-first Markdown report for human or LLM review."""

from pathlib import Path
from typing import Any

import pandas as pd

from .models import AnalysisResult
from .risk_analysis import PRIORITY_THRESHOLD, score_rules_markdown

TOP_CONTROL_LIMIT = 10
TOP_PRIORITY_CASE_LIMIT = 15


def _cell(value: Any, *, limit: int | None = None) -> str:
    """Render a scalar safely in a Markdown table cell."""
    try:
        if bool(pd.isna(value)):
            return "—"
    except (TypeError, ValueError):
        pass

    text = str(value).replace("\r", " ").replace("\n", " ").replace("|", r"\|")
    if limit is not None and len(text) > limit:
        text = text[: limit - 1] + "…"
    return text


def _count(value: Any) -> str:
    try:
        if bool(pd.isna(value)):
            return "—"
        return f"{int(value):,}"
    except (TypeError, ValueError, OverflowError):
        return _cell(value)


def _percent(numerator: Any, denominator: int) -> str:
    try:
        if bool(pd.isna(numerator)) or denominator == 0:
            return "n/a"
        return f"{float(numerator) / denominator:.1%}"
    except (TypeError, ValueError, OverflowError):
        return "n/a"


def _rate(value: Any) -> str:
    try:
        if bool(pd.isna(value)):
            return "n/a"
        return f"{float(value):.1%}"
    except (TypeError, ValueError, OverflowError):
        return "n/a"


def _markdown_table(headers: list[str], rows: list[list[Any]]) -> str:
    if not rows:
        rows = [["None identified", *(["—"] * (len(headers) - 1))]]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    lines.extend("| " + " | ".join(_cell(value) for value in row) + " |" for row in rows)
    return "\n".join(lines)


def _date(value: Any) -> str:
    if pd.isna(value):
        return "n/a"
    return pd.Timestamp(value).date().isoformat()


def _scope_section(
    summaries: dict[str, pd.DataFrame], input_file: str | Path, output_file: str | Path
) -> str:
    """Format the shared population reconciliation and execution period."""
    population = summaries["population"].set_index("Metric")["Value"]
    period = summaries["execution_period"].iloc[0]
    date_range = (
        f"{_date(period['first'])} to {_date(period['last'])}"
        if pd.notna(period["first"])
        else "No valid execution dates"
    )
    records = population["Analyzed rows"]
    rows = [
        ["Source dataset", Path(input_file).name],
        ["Analysis workbook", str(Path(output_file).resolve())],
        ["Rows analyzed", _count(records)],
        ["Distinct non-null Case_Id values", _count(population["Distinct non-null Case_Id"])],
        ["Rows missing Case_Id", _count(population["Rows missing Case_Id"])],
        [
            "Distinct non-null controls",
            _count(population["Distinct non-null controls"]),
        ],
        ["Execution-date range", date_range],
        ["Rows missing execution date", _count(population["Rows missing execution date"])],
        [
            "Rows with unknown comment count",
            _count(population["Rows with unknown comment count"]),
        ],
    ]
    return "## Scope and data basis\n\n" + _markdown_table(["Measure", "Value"], rows)


def _control_descriptions_section(summaries: dict[str, pd.DataFrame]) -> str:
    """Format the source's first retained description per nonblank control code."""
    rows = summaries["control_descriptions"].values.tolist()
    return "## Control descriptions\n\n" + _markdown_table(
        ["control_logical_code", "control_description"], rows
    )


def _population_sections(summaries: dict[str, pd.DataFrame]) -> list[str]:
    """Render status, decisions and open aging with their existing denominators."""
    records = summaries["population"].set_index("Metric").loc["Analyzed rows", "Value"]
    status_rows = [
        [
            row["status_normalized"],
            _count(row["cases"]),
            _percent(row["cases"], records),
            _count(row["cases_with_closure_date"]),
            _count(row["workflow_exceptions"]),
        ]
        for _, row in summaries["status_summary"].iterrows()
    ]
    decision_rows = [
        [
            row["decision_normalized"],
            _count(row["cases"]),
            _percent(row["cases"], records),
            _count(row["completed_without_comments"]),
        ]
        for _, row in summaries["decision_summary"].iterrows()
    ]

    aging = summaries["open_aging"]
    open_count = aging["denominator"].iloc[0]
    aging_rows = [
        [row.bucket, _count(row.cases), _percent(row.cases, row.denominator)]
        for row in aging.itertuples(index=False)
    ]

    return [
        "## Population and outcomes\n\n### Status",
        _markdown_table(
            [
                "Normalized status",
                "Rows",
                "% of rows",
                "With closure date",
                "Workflow exceptions",
            ],
            status_rows,
        ),
        "### Final decision",
        _markdown_table(
            ["Normalized decision", "Rows", "% of rows", "Completed without comments"],
            decision_rows,
        ),
        "### Open-case age buckets",
        f"Processing rows: **{_count(open_count)}**. "
        "Shares below use processing rows as the denominator. Case age uses a populated "
        "closure date when present; otherwise it uses the current datetime captured for this run. "
        "Processing rows with closure dates are also flagged as workflow exceptions.",
        _markdown_table(["Age bucket", "Rows", "% of open rows"], aging_rows),
    ]


def _control_section(summaries: dict[str, pd.DataFrame], records: int) -> str:
    scorecard = summaries["control_scorecard"].head(TOP_CONTROL_LIMIT)
    rows = [
        [
            row["control_logical_code"],
            _count(row["cases"]),
            _percent(row["cases"], records),
            f"{_count(row['breach_cases'])} ({_rate(row['breach_rate'])})",
            f"{_count(row['false_anomaly_cases'])} ({_rate(row['false_anomaly_rate'])})",
            _count(row["open_cases"]),
            _count(row["workflow_exception_cases"]),
        ]
        for _, row in scorecard.iterrows()
    ]
    omitted = max(len(summaries["control_scorecard"]) - TOP_CONTROL_LIMIT, 0)
    note = (
        f"Top {TOP_CONTROL_LIMIT} controls by row count; {omitted:,} lower-volume controls omitted."
    )
    return (
        "## Control concentration\n\n"
        + note
        + "\n\n"
        + _markdown_table(
            [
                "Control",
                "Rows",
                "% of rows",
                "Breach rows (rate)",
                "False-anomaly rows (rate)",
                "Open rows",
                "Workflow exceptions",
            ],
            rows,
        )
    )


def _monthly_section(summaries: dict[str, pd.DataFrame]) -> str:
    """Render one row per execution month across all controls."""
    monthly = summaries["monthly_summary"]
    rows = [
        [
            "Unknown" if pd.isna(row["execution_month"]) else row["execution_month"],
            _count(row["cases"]),
            _count(row["justified_cases"]),
            _count(row["false_anomaly_cases"]),
            _count(row["breach_cases"]),
            _count(row["no_decision_cases"]),
            _count(row["open_cases"]),
            _count(row["auto_closed_cases"]),
            _count(row["completed_without_comments"]),
            ("—" if pd.isna(row["median_days_to_close"]) else f"{row['median_days_to_close']:.2f}"),
        ]
        for _, row in monthly.iterrows()
    ]
    return "\n\n".join(
        [
            "## Monthly analysis",
            "One row per execution month across all controls. Control-level details remain "
            "in the workbook's Monthly Trends tab. "
            "Counts represent retained analyzed rows. Open rows reflect the source's current "
            "processing status within each execution-month group, not historical month-end "
            "backlog. "
            "Missing execution dates appear under Unknown; unavailable medians appear as —. "
            "Median days to close is calculated from all available case durations in the month. "
            "Decision, open, auto-closure and comment measures can "
            "overlap and must not be added together.",
            _markdown_table(
                [
                    "Execution month",
                    "Rows",
                    "Justified",
                    "False anomaly",
                    "Breach",
                    "No decision",
                    "Open rows",
                    "Auto-closed",
                    "Completed without comments",
                    "Median days to close",
                ],
                rows,
            ),
        ]
    )


def _quality_section(summaries: dict[str, pd.DataFrame]) -> list[str]:
    """Render shared quality measures without recalculating case predicates."""
    quality_rows = [
        [
            row.signal,
            _count(row.cases),
            _percent(row.cases, row.denominator),
            _count(row.denominator),
        ]
        for row in summaries["quality_signals"].itertuples(index=False)
    ]
    return [
        "## Workflow and completion signals",
        _markdown_table(["Signal", "Rows", "Share", "Denominator"], quality_rows),
    ]


def _hit_search_items_section(summaries: dict[str, pd.DataFrame]) -> str:
    """Render the hit-search measures already calculated by the analysis pipeline."""
    heading = "## Hit-search item analysis"
    summary = summaries["hit_search_summary"].iloc[0]
    item_summary = summaries["hit_search_items"]
    summary_rows = [
        ["Breach-decision rows", _count(summary["breach_rows"])],
        [
            "Breach rows with hit-search items",
            f"{_count(summary['breach_rows_with_items'])} "
            f"({_rate(summary['breach_item_coverage'])})",
        ],
        ["Distinct items appearing on breach rows", _count(summary["distinct_breach_items"])],
    ]
    detail_rows = [
        [
            row["hit_search_item"],
            _count(row["rows"]),
            _count(row["breach_rows"]),
            _rate(row["share_of_breach_rows"]),
            _rate(row["breach_rate"]),
        ]
        for _, row in item_summary.iterrows()
    ]
    return "\n\n".join(
        [
            heading,
            "The source identifies `hit_search_items` as the item(s) principally responsible "
            "for post-trade control breaches. Comma-separated items are counted once per row. "
            "Items may co-occur, so counts and shares are not additive; this summarizes source "
            "attribution and does not independently verify causality.",
            _markdown_table(["Measure", "Value"], summary_rows),
            _markdown_table(
                [
                    "Hit-search item",
                    "All rows with item",
                    "Breach rows with item",
                    "% of breach rows",
                    "Breach rate among item rows",
                ],
                detail_rows,
            ),
        ]
    )


def _duplicate_case_ids_section(duplicate_details: pd.DataFrame) -> list[str]:
    if duplicate_details.empty:
        return []
    rows = [
        [row["Case_Id"], row["Record"], row["Column"], row["Value"]]
        for _, row in duplicate_details.iterrows()
    ]
    return [
        "## Non-identical duplicate Case_Id records\n\n"
        "Exact duplicate rows were removed. These repeated Case_Id records differ in the "
        "following source columns; values are shown per retained record.\n\n"
        + _markdown_table(["Case_Id", "Record", "Different column", "Value"], rows)
    ]


def _risk_section(
    summaries: dict[str, pd.DataFrame],
    priority_cases: pd.DataFrame,
    manual_review: pd.DataFrame,
) -> list[str]:
    """Format calculated band counts and the already ordered priority selection."""
    records = summaries["population"].set_index("Metric").loc["Analyzed rows", "Value"]
    risk_rows = [
        [row.priority, _count(row.cases), _percent(row.cases, records)]
        for row in summaries["priority_counts"].itertuples(index=False)
    ]
    top_cases = priority_cases.head(TOP_PRIORITY_CASE_LIMIT)
    top_rows = [
        [
            row["Case_Id"],
            row["control_logical_code"],
            row["status_normalized"],
            row["decision_normalized"],
            _cell(row["case_age_days"]),
            _count(row["audit_risk_score"]),
            row["audit_priority"],
            _cell(row["risk_reasons"], limit=180),
            row.get("historic_comments_markdown"),
            _cell(row["hit_search_items"], limit=180),
        ]
        for _, row in top_cases.iterrows()
    ]

    return [
        "## Rule-based risk triage",
        f"Rows with score >= {PRIORITY_THRESHOLD}: **{_count(len(priority_cases))}**. "
        f"Manual-review queue: **{_count(len(manual_review))}** rows. "
        "Queues overlap and are not additive.",
        _markdown_table(["Priority", "Rows", "% of rows"], risk_rows),
        "### Highest-priority rows",
        f"Showing up to {TOP_PRIORITY_CASE_LIMIT} rows ranked by score, age, then control. "
        "Historic comments Markdown is included in full when available.",
        _markdown_table(
            [
                "Case_Id",
                "Control",
                "Status",
                "Decision",
                "Age days",
                "Score",
                "Priority",
                "Score reasons",
                "Historic comments (Markdown)",
                "Hit search items",
            ],
            top_rows,
        ),
        "### Score rules",
        score_rules_markdown(),
    ]


def render_markdown(
    result: AnalysisResult,
    input_file: str | Path,
    output_file: str | Path,
    markdown_file: str | Path | None = None,
) -> str:
    """Render the existing report from calculated tables without mutation or I/O.

    Artifact paths are displayed, not created. The report retains its headings,
    top-ten controls, top-fifteen priority rows and complete available comments.
    Missing values and each measure's population keep their established meaning.
    """
    summaries = result.summaries
    priority_cases = result.priority_cases
    manual_review = result.manual_review
    duplicate_details = result.duplicate_details
    snapshot = result.snapshot_at.isoformat(sep=" ")
    executive = summaries["executive_summary"].set_index("metric")["value"]
    records = executive["Input cases"]
    completed = executive["Completed cases"]
    processing = executive["Processing cases"]
    canceled = executive["Canceled cases"]
    breaches = executive["Breach cases"]
    sections = [
        "# Post-Trade Control Analysis",
        "**Review basis:** descriptive analysis of the supplied post-trade control case extract; "
        "this report supports post-trade control review.",
        _control_descriptions_section(summaries),
        _scope_section(summaries, input_file, output_file),
        *(
            ["Saved Markdown report: " + str(Path(markdown_file).resolve())]
            if markdown_file is not None
            else []
        ),
        "## Snapshot metrics\n\n"
        + _markdown_table(
            ["Metric", "Value"],
            [
                ["Snapshot datetime (current server local time)", snapshot],
                ["Completed rows", f"{_count(completed)} ({_percent(completed, records)})"],
                ["Processing rows", f"{_count(processing)} ({_percent(processing, records)})"],
                ["Canceled rows", f"{_count(canceled)} ({_percent(canceled, records)})"],
                ["Breach-decision rows", f"{_count(breaches)} ({_percent(breaches, records)})"],
                ["Rows in priority queue", _count(len(priority_cases))],
                ["Rows in manual-review queue", _count(len(manual_review))],
            ],
        ),
        *_population_sections(summaries),
        _control_section(summaries, records),
        _monthly_section(summaries),
        *_quality_section(summaries),
        *_duplicate_case_ids_section(duplicate_details),
        _hit_search_items_section(summaries),
        *_risk_section(summaries, priority_cases, manual_review),
        "## Interpretation and limitations\n\n"
        "- Population status, decision, and control counts represent analyzed rows; "
        "only measures labeled distinct use unique non-null `Case_Id` values.\n"
        "- Case age uses closure date minus execution date when closure date is populated; "
        "otherwise it uses the current datetime captured once for this run minus execution date. "
        "The snapshot and timezone-naive source dates use server local time. "
        "A processing row with a closure date is flagged as a workflow exception.\n"
        "- Missing comment counts are unknown, not evidence of no comments; only explicit "
        "zero counts contribute to completed-without-comments measures.\n"
        "- Hit-search items reflect source attribution and are not independently verified.\n"
        "- Risk scores are deterministic triage indicators, not probabilities or "
        "findings. Only the top-priority rows are included in the risk-triage table; "
        "historic comments Markdown is shown in full. Consult the workbook for remaining "
        "case-level records.",
        "## LLM review instructions\n\n"
        "1. Summarize material population, monthly, outcome, backlog, control, evidence, and "
        "workflow patterns using the reported counts and denominators.\n"
        "2. Separate observed facts from hypotheses; identify patterns that warrant "
        "independent evidence or human review.\n"
        "3. Treat hit-search items as source attribution; verify the attributed items "
        "against case comments and supporting evidence before inferring cause. Do not "
        "treat risk scores as confirmed findings.\n"
        "4. State limitations and the additional case-level evidence needed before "
        "drawing conclusions.",
    ]
    return "\n\n".join(sections)
