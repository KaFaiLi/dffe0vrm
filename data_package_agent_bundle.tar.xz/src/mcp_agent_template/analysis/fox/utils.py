import numpy as np
import pandas as pd


# -----------------------------
# Helpers
# -----------------------------
def require_columns(dataframe, columns):
    missing = [column for column in columns if column not in dataframe.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))


def clean_text(series):
    return series.astype("string").str.strip().str.replace(r"\s+", " ", regex=True)


def normalize_status(series):
    text = clean_text(series).str.lower()
    result = pd.Series("unknown", index=series.index, dtype="string")
    result.loc[text.str.contains("complet", na=False)] = "completed"
    result.loc[text.str.contains("process|open|pending|assign", na=False)] = "processing"
    result.loc[text.str.contains("cancel", na=False)] = "canceled"
    return result


def normalize_decision(series):
    text = clean_text(series).str.lower().str.replace(r"[\s_-]+", " ", regex=True)
    result = pd.Series("other", index=series.index, dtype="string")
    result.loc[series.isna() | text.eq("")] = "no decision"
    result.loc[text.str.contains("justif", na=False)] = "justified"
    result.loc[text.str.contains("false", na=False)] = "false anomaly"
    result.loc[text.str.contains("breach", na=False)] = "breach"
    return result


def safe_rate(numerator, denominator):
    return np.nan if denominator == 0 else numerator / denominator


def percentile_90(series):
    valid = series.dropna()
    return np.nan if valid.empty else valid.quantile(0.90)


def autofit_worksheet(worksheet, dataframe, maximum_width=60):
    for position, column in enumerate(dataframe.columns, start=1):
        values = dataframe[column].astype("string")
        content_width = values.str.len().max() if len(values) else 0
        content_width = 0 if pd.isna(content_width) else int(content_width)
        width = min(max(len(str(column)), content_width) + 2, maximum_width)
        letter = worksheet.cell(row=1, column=position).column_letter
        worksheet.column_dimensions[letter].width = width
    worksheet.freeze_panes = "A2"
    if dataframe.shape[1] > 0:
        worksheet.auto_filter.ref = worksheet.dimensions


def write_sheet(writer, dataframe, sheet_name):
    safe_name = sheet_name[:31]
    dataframe.to_excel(writer, sheet_name=safe_name, index=False)
    autofit_worksheet(writer.sheets[safe_name], dataframe)


def existing_columns(dataframe, preferred):
    return [column for column in preferred if column is not None and column in dataframe.columns]
