"""In-memory risk analysis and file/report orchestration with one calculated Review."""

from __future__ import annotations

from pathlib import Path

import polars as pl

from mcp_agent_template.config import get_settings

from .. import charts
from .charts import risk_charts
from .commentary import load_commentary
from .dynamics import analyze_dynamics
from .export import export_workbook
from .models import Review, Row, Source
from .report import markdown_report
from .sgmr import analyze_sgmr
from .sources import load_table, prepare_table
from .workflow import analyze_workflow


def analyze_tables(
    sgmr: pl.DataFrame,
    colibris: pl.DataFrame | None = None,
    *,
    sgmr_name: str = "sgmr.parquet",
    colibris_name: str = "colibris.csv",
) -> Review:
    """Calculate a complete numerical review without settings, clock or file I/O.

    Args:
        sgmr: Raw SGMR table; core columns and at least one row are required.
            Names are case-insensitive. Values retain the file loader's parsing,
            exact-duplicate, conflict and unknown-value rules.
        colibris: Optional raw event table with excessId. None means omitted;
            a header-only frame is a supplied, empty population.
        sgmr_name: Nonblank source label for SGMR evidence references.
        colibris_name: Nonblank source label when Colibris is supplied. Names
            are metadata only and are never resolved or read as paths.

    Returns:
        A fresh Review owning source records, observations, ordered candidates
        and all numerical report tables. Inputs are not mutated or retained.
        The reference date is the latest valid SGMR date, including conflicted
        observations, as in the file runner. No wall-clock snapshot is used.
        Commentary is outside numerical analysis and stays with the file runner.

    Raises:
        ValueError: Required input/columns are missing, column names are ambiguous,
            SGMR is empty or a supplied source label is blank. Invalid individual
            values are disclosed as unknown rather than rejected or set to zero.
    """
    review = Review()
    sgmr_source = prepare_table(sgmr, "sgmr", review, name=sgmr_name)
    colibris_source = prepare_table(colibris, "colibris", review, name=colibris_name)
    return _analyze(sgmr_source, colibris_source, review)


def _analyze(sgmr: Source, colibris: Source, review: Review) -> Review:
    """Fill a fresh, prepared Review in domain order and retain its chart observations.

    SGMR establishes the reference date before independent Colibris aging checks.
    Candidate ties retain priority, source filename, original row ordinal and
    check ordering. Loading disclosures and unprocessed commentary stay intact.
    """
    review.observations = analyze_sgmr(sgmr, review)
    analyze_dynamics(review.observations, review)
    analyze_workflow(colibris, review)

    record_order = {
        record.locator: record.ordinal for source in review.sources for record in source.records
    }

    def candidate_order(row: Row) -> tuple[int, str, int, str]:
        """Order equally prioritized candidates by source file and original record order."""
        first_locator = row["source_locator"].splitlines()[0]
        return (
            row["review_order"],
            first_locator.split(" [", 1)[0],
            record_order.get(first_locator, 0),
            row["check"],
        )

    review.candidates.sort(key=candidate_order)
    return review


def run_risk_metrics_analysis(
    sgmr_path: str | Path,
    colibris_path: str | Path | None = None,
    risk_metrics_commentary_path: str | Path | None = None,
    stress_test_commentary_path: str | Path | None = None,
    var_svar_commentary_path: str | Path | None = None,
    *,
    output_dir: str | Path | None = None,
) -> str:
    """Read source paths, save isolated reports, and return their complete Markdown text.

    SGMR is required. Omitted optional sources disable dependent checks; supplied
    invalid paths fail explicitly. Relative input paths use the current working
    directory. Commentary text is passed through for agent review without record
    extraction or matching. No source files are modified and no model/network
    calls are made. The returned and saved Markdown starts with Metric movements
    and omits prioritized follow-up, limit consumption, executive observations,
    source/availability tables, cross-source reconciliation and chart previews/links.
    SGMR and Colibris are analyzed independently. Complete summary, source
    and availability evidence remains in Excel; PNGs, their index and evidence
    manifest are saved separately. Value outliers have a dedicated section and
    worksheet; the exact-observation joint movement/value day list is complete
    in both Markdown and Excel, without the ordinary 15-row Markdown cap.
    """
    review = Review()
    sgmr = load_table(sgmr_path, "sgmr", review)
    colibris = load_table(colibris_path, "colibris", review)
    for path, role in (
        (risk_metrics_commentary_path, "risk_metrics_commentary"),
        (stress_test_commentary_path, "stress_test_commentary"),
        (var_svar_commentary_path, "var_svar_commentary"),
    ):
        load_commentary(path, role, review)
    _analyze(sgmr, colibris, review)
    if output_dir is None:
        settings = get_settings()
        output_dir = settings.resolve_path(settings.analysis_results_dir) / "risk_metrics"
    with charts.staged_run(output_dir) as (stage, run_dir):
        markdown = run_dir / "risk_metrics_analysis.md"
        workbook = run_dir / "risk_metrics_analysis.xlsx"
        export_workbook(review, stage / workbook.name)
        charts.export_charts(risk_charts(review.observations, review), stage / "charts")
        report = markdown_report(review, workbook, markdown)
        (stage / markdown.name).write_text(report, encoding="utf-8")
    return report
