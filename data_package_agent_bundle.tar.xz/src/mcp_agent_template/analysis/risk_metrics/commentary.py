"""Supply complete commentary documents to the agent without parsing their records."""

from pathlib import Path

from .models import Commentary, Review, Source
from .sources import read_bytes


def load_commentary(path: str | Path | None, role: str, review: Review) -> None:
    """Append a supplied UTF-8 Markdown document without extracting or judging records.

    None omits the optional document. Otherwise, resolve the path against the
    working directory, read it once and normalize BOM/line endings. Register
    its source and complete text on review; never modify the file. Invalid
    paths, extensions or encoding raise ValueError through this boundary.
    """
    if path is None:
        return
    resolved, data = read_bytes(path, ".md", role)
    try:
        content = data.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")
    except UnicodeError as exc:
        raise ValueError(f"{role} must be UTF-8 Markdown: {resolved.name}") from exc
    review.sources.append(Source(role=role, path=str(resolved)))
    review.commentary.append(Commentary(role=role, path=str(resolved), content=content))
