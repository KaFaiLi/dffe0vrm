"""SGMR identities, date coverage, limit history and observation-level evidence."""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Callable, Mapping
from datetime import date

from . import models
from .models import Review, Row, Source, close, identifier, norm

SERIES_FIELDS = (
    "limId",
    "stranaNodeName",
    "stranaPc",
    "rmRiskIndicator",
    "rmRiskMetricName",
    "limUnit",
    "consoVersion",
)
AXIS_FIELDS = (
    "rmRiskMeasureId",
    "rmRiskMetricLabel",
    "rmRiskMetricNameGeneric",
    "metricType_LB",
    "paramTypeId",
    "consoSttScenario",
    "consoAxisValue",
    "consoAxisValue2",
    "rmUnderlyingType1",
    "rmUnderlyingName1",
    "rmUnderlyingType2",
    "rmUnderlyingName2",
    "rmTimeBucket1",
    "rmTimeBucket2",
    "rmTimeBucket3",
    "bucket_LB",
    "maturity_LB",
    "rmCurrency",
    "rmCurrencyPair1",
    "STT Equivalent Shock",
    "Sensibility Shock",
    *(f"metricSpecification{i}_LB" for i in range(1, 7)),
    "underlyings_LB",
    "underlyingsCode_LB",
)


def _hierarchy(observation: models.Observation, review: Review) -> None:
    """Disclose conflicting hierarchy labels using the observation's report identifiers."""
    record = observation.record
    if not record.label("flatStrana"):
        return
    try:
        flat = json.loads(record.label("flatStrana"))
        if not isinstance(flat, dict):
            raise ValueError("not an object")
    except (ValueError, TypeError):
        review.issue("invalid_hierarchy_json", record.locator, "flatStrana is not a JSON object.")
        return
    fields = {
        "BU": "stranaBu",
        "SBU": "stranaSbu",
        "GPC1": "stranaGrppc1",
        "GPC2": "stranaGrppc2",
        "GPC3": "stranaGrppc3",
        "PC": "stranaPc",
    }
    mismatches = [
        key
        for key, column in fields.items()
        if key in flat and record.label(column) and norm(flat[key]) != record.normalized(column)
    ]
    if mismatches:
        review.candidate(
            "hierarchy_conflict",
            observation.identifiers,
            ", ".join(mismatches),
            record.locator,
            "Explicit columns disagree with flatStrana.",
            "Reconcile the source hierarchy before assigning desk ownership.",
            priority=1,
        )


def _prepare(source: Source, review: Review) -> list[models.Observation]:
    """Prepare owned risk values and disclose identity, hierarchy and date conflicts."""
    observations = []
    grains: dict[tuple, list[models.Observation]] = defaultdict(list)
    for record in source.records:
        key = tuple(record.normalized(field) for field in (*SERIES_FIELDS, *AXIS_FIELDS))
        value = record.typed("consoValue")
        date_value = record.typed("consoValueDate")
        comparable = (
            date_value is not None
            and value is not None
            and all(record.label(field) for field in SERIES_FIELDS if field != "stranaPc")
            and record.typed("consoVersion") is not None
        )
        observation = models.Observation(
            record,
            key,
            date_value,
            value,
            comparable=comparable,
        )
        observations.append(observation)
        if date_value is not None and all(key[index] for index in (0, 1, 3)):
            # Conflicting unit/name/hierarchy definitions do not create independent observations.
            grains[(key[0], key[1], key[3], key[6], *key[7:], date_value)].append(observation)
        else:
            review.issue(
                "invalid_grain", record.locator, "Identity, portfolio, metric or date missing."
            )
        if not comparable:
            review.issue(
                "incomparable_series_row",
                record.locator,
                "Series statistics require valid identity/date/value, metric "
                "definition, unit/version.",
            )
        _hierarchy(observation, review)
        start, end = record.typed("limStartDate"), record.typed("limEndDate")
        if date_value and ((start and date_value < start) or (end and date_value > end)):
            review.candidate(
                "outside_limit_effective_dates",
                observation.identifiers,
                date_value,
                record.locator,
                "Observation lies outside a stated limit effective date.",
                "Confirm the effective limit version for this observation.",
                priority=1,
            )
        previous = record.typed("consoLastValueDate")
        if date_value and previous:
            gap = (date_value - previous).days
            if gap <= 0 or (record.normalized("limFrequency") == "DAILY" and gap > 7):
                review.issue("prior_value_date_gap", record.locator, f"Calendar gap: {gap} days.")
    for duplicates in grains.values():
        if len(duplicates) < 2:
            continue
        for observation in duplicates:
            observation.conflict = True
            review.issue(
                "conflicting_observation_grain",
                observation.record.locator,
                "Non-identical records share the analytical grain; excluded from "
                "aggregate measures.",
            )
            review.candidate(
                "conflicting_observation_grain",
                observation.identifiers,
                len(duplicates),
                observation.record.locator,
                "No authoritative record selected.",
                "Obtain the authoritative observation or corrected extract.",
                priority=1,
            )
    return observations


def consecutive_runs(
    rows: list[models.Observation],
    expected_dates: list[date],
    predicate: Callable[[models.Observation], bool],
    *,
    date_indices: Mapping[date, int] | None = None,
) -> list[list[models.Observation]]:
    """Split runs at missing, invalid or conflicting dates on the full supplied calendar.

    date_indices may share the position map for expected_dates across series;
    it is read-only and must describe that complete ordered calendar. Omitting
    it preserves the direct-call interface and constructs the same lookup here.
    """
    indices = (
        date_indices
        if date_indices is not None
        else {value: index for index, value in enumerate(expected_dates)}
    )
    result: list[list[models.Observation]] = []
    current: list[models.Observation] = []
    for row in sorted(rows, key=lambda item: (item.day or date.min, item.record.ordinal)):
        valid = row.day is not None and not row.conflict and predicate(row)
        if current and (not valid or indices[row.day] != indices[current[-1].day] + 1):
            result.append(current)
            current = []
        if valid:
            current.append(row)
    if current:
        result.append(current)
    return result


def analyze_sgmr(source: Source, review: Review) -> list[models.Observation]:
    """Populate SGMR summaries and source-ID detail without changing the supplied records.

    Keep each configured series and axis separate in supplied units. Preserve
    date coverage, hierarchy/effective-date checks and limit-history comparisons,
    but do not calculate limit utilization, exceedances, warnings or episodes.
    Conflicting grains remain visible and are excluded from dependent measures.
    Return prepared observations for movement analysis and charts, retaining
    original IDs, raw source columns and source locators in detailed evidence.
    """
    review.available("SGMR population", source, ())
    review.available("Metric movements", source, ("rmRiskMetricName", "limUnit", "consoVersion"))
    review.available(
        "Metric value outliers", source, ("rmRiskMetricName", "limUnit", "consoVersion")
    )
    review.available("Limit effective dates", source, ("limStartDate", "limEndDate"))
    review.available("Limit changes", source, ("limInitialMinValue", "limInitialMaxValue"))
    observations = _prepare(source, review)
    expected_dates = sorted({row.day for row in observations if row.day is not None})
    review.reference_date = max(expected_dates, default=None)
    groups: dict[tuple, list[models.Observation]] = defaultdict(list)
    for observation in observations:
        groups[observation.key].append(observation)
        record = observation.record
        review.detail.append(
            {
                "id": identifier(record.get("id")) or None,
                **observation.identifiers,
                "unit": record.label("limUnit") or None,
                "source_locator": record.locator,
                "observation_date": observation.day,
                "value": observation.value,
                "conflicting_grain": observation.conflict,
                "comparable_for_statistics": observation.comparable and not observation.conflict,
                "duplicate_locators": "\n".join(record.duplicate_locators),
                **{f"raw:{key}": value for key, value in record.raw.items()},
            }
        )
    changed_series = 0
    for key, rows in sorted(groups.items()):
        identifiers = rows[0].identifiers
        valid = [row for row in rows if not row.conflict]
        observed_dates = {row.day for row in valid if row.day is not None}
        coverage = len(observed_dates) / len(expected_dates) if expected_dates else None
        if coverage is not None and coverage < 0.95:
            review.candidate(
                "series_coverage_below_95_percent",
                identifiers,
                coverage,
                rows[0].record.locator,
                "Denominator is all observed SGMR dates; inception/closure may explain gaps.",
                "Confirm series inception, closure and expected reporting calendar.",
                priority=1,
            )
        periods: dict[str, list[models.Observation]] = {"all": rows}
        for row in rows:
            if row.day:
                quarter = f"{row.day.year}Q{(row.day.month - 1) // 3 + 1}"
                periods.setdefault(quarter, []).append(row)
        for period, period_rows in periods.items():
            usable = [r for r in period_rows if not r.conflict]
            summary: Row = {
                "period": period,
                "limId": key[0],
                "portfolio": key[1],
                "metric": key[3],
                "unit": key[5],
                "version": key[6],
                **identifiers,
                "definition_axes": json.dumps(dict(zip(AXIS_FIELDS, key[7:], strict=True))),
                "observations": len(period_rows),
                "conflicting_rows": sum(r.conflict for r in period_rows),
                "observed_dates": len({r.day for r in usable if r.day}),
                "coverage": coverage if period == "all" else None,
                "source_locator": rows[0].record.locator,
            }
            review.series.append(summary)
        regimes = set()
        observed_change = False
        previous_row = None
        for row in sorted(valid, key=lambda item: (item.day or date.min, item.record.ordinal)):
            r = row.record
            initial = (r.typed("limInitialMinValue"), r.typed("limInitialMaxValue"))
            current = (r.typed("limMinValue"), r.typed("limMaxValue"))
            if row.day and previous_row is not None:
                previous_bounds = (
                    previous_row.record.typed("limMinValue"),
                    previous_row.record.typed("limMaxValue"),
                )
                if any(
                    a is not None and b is not None and not close(a, b)
                    for a, b in zip(previous_bounds, current, strict=True)
                ):
                    observed_change = True
                    review.candidate(
                        "observed_limit_change",
                        identifiers,
                        f"{previous_row.day}: {previous_bounds}; {row.day}: {current}",
                        previous_row.record.locator + "\n" + r.locator,
                        "Observed bound history; the effective date and approval are not inferred.",
                        "Obtain the applicable change decision and effective-date evidence.",
                        priority=1,
                    )
            if row.day:
                previous_row = row
            differs = any(
                a is not None and b is not None and not close(a, b)
                for a, b in zip(initial, current, strict=True)
            )
            regime = (*initial, *current, r.typed("limStartDate"))
            if differs and regime not in regimes:
                regimes.add(regime)
                review.candidate(
                    "changed_limit_bounds",
                    identifiers,
                    f"Initial {initial}; current {current}; start {regime[-1]}",
                    r.locator,
                    "Initial/current differences do not establish approval or "
                    "retrospective application.",
                    "Obtain the changed-limit lineage, effective date and approval evidence.",
                    priority=1,
                )
            if r.typed("limTempMinValue") is not None or r.typed("limTempMaxValue") is not None:
                review.issue(
                    "temporary_bounds_not_applied",
                    r.locator,
                    "Effective timing/precedence not established.",
                )
        changed_series += bool(regimes) or observed_change
    review.count("SGMR input observations", source.input_rows)
    review.count("SGMR exact duplicates removed", source.duplicate_rows)
    review.count("SGMR analyzed observations", len(observations))
    review.count("SGMR series", len(groups))
    review.count("SGMR observed dates", len(expected_dates))
    review.count("SGMR start date", min(expected_dates, default=None))
    review.count("Review reference date", review.reference_date)
    review.count("Changed-limit series", changed_series)
    return observations
