"""Selected Colibris excess-population and workflow evidence screens."""

from __future__ import annotations

from collections import Counter, defaultdict

from .models import Record, Review, Row, Source, identifier, number


def analyze_workflow(source: Source, review: Review) -> None:
    """Calculate independent event checks with literal metric and perimeter report labels."""
    review.available("Excess population", source, ("excessId",))
    review.available(
        "Excess state and calendar aging",
        source,
        ("excessStillOpen", "excessCreationDate", "excessCloseDate"),
    )
    review.available(
        "Excess usage re-performance",
        source,
        ("excessLastConsoValue", "limitValue", "unit", "usage"),
    )
    review.available(
        "Explanation evidence",
        source,
        (
            "lastExcessExplanationCreationDate",
            "lastExcessExplanationCause",
            "lastExcessExplanationActionPlan",
        ),
    )
    review.available(
        "Validation evidence",
        source,
        ("lastExcessValidationCreationDate", "lastExcessValidationIsSatisfactory"),
    )
    review.available(
        "LoD2 evidence",
        source,
        ("lastExcessValidationLod2CreationDate", "lastExcessValidationLod2IsSatisfactory"),
    )
    review.available(
        "Limit-increase chronology",
        source,
        (
            "increaseId",
            "increaseWorkflowStatus",
            "increaseCreationDate",
            "increaseValidationTrdDirCreationDate",
            "increaseValidationRisqCreationDate",
        ),
    )
    if source.path is None:
        review.count("Colibris input events", None)
        review.count("Colibris recorded open events", None)
        return
    ids = Counter(identifier(row.get("excessId")) for row in source.records)
    repeated: dict[tuple, list[Record]] = defaultdict(list)
    for record in source.records:
        event_id = identifier(record.get("excessId"))
        conflicting = not event_id or ids[event_id] > 1
        identifiers = {
            name: record.label(name) or None for name in ("riskMetricName", "perimeterMnemonic")
        }

        def flag(
            check: str,
            observed,
            qualification: str,
            priority: int = 2,
            *,
            event_identifiers: Row = identifiers,
            locator: str = record.locator,
        ) -> None:
            """Retain the event's metric/perimeter labels and exact source reference."""
            review.candidate(
                check,
                event_identifiers,
                observed,
                locator,
                qualification,
                "Inspect the event history, applicable workflow requirements and "
                "supporting approvals.",
                priority=priority,
            )

        if conflicting:
            review.issue(
                "conflicting_or_missing_excess_id",
                record.locator,
                "No authoritative event record selected.",
            )
            flag(
                "conflicting_or_missing_excess_id",
                event_id,
                "Excluded from derived event measures.",
                1,
            )
        opened = record.typed("excessStillOpen")
        created, closed = record.typed("excessCreationDate"), record.typed("excessCloseDate")
        explained = record.typed("lastExcessExplanationCreationDate")
        validated = record.typed("lastExcessValidationCreationDate")
        age = None
        terminal_date = (
            closed if opened is False else review.reference_date if opened is True else None
        )
        if not conflicting and created and terminal_date:
            if terminal_date >= created:
                age = (terminal_date - created).days
            else:
                flag(
                    "negative_event_age",
                    (terminal_date - created).days,
                    "Reference/closure precedes creation; age unavailable.",
                    1,
                )
        if not conflicting:
            for name in (
                "lastExcessValidationIsSatisfactory",
                "lastExcessValidationLod2IsSatisfactory",
            ):
                if record.typed(name) is False:
                    flag(
                        "unsatisfactory_validation_recorded",
                        name,
                        "Source validation flag is explicitly false; "
                        "decision details require review.",
                    )
            if opened is True and closed:
                flag(
                    "open_event_with_closure",
                    closed,
                    "Recorded open flag conflicts with a closure date.",
                    1,
                )
            if opened is False and closed is None:
                flag(
                    "closed_event_without_closure_date",
                    None,
                    "Closure date evidence is missing; no failure inferred.",
                    1,
                )
            if opened is False and record.normalized("excessWorkflowStatus") == "OPEN":
                flag(
                    "event_state_conflict",
                    "OPEN / excessStillOpen=false",
                    "Recorded state fields disagree.",
                    1,
                )
            for label, first, last in (
                ("explanation_before_creation", created, explained),
                ("validation_before_explanation", explained, validated),
                ("closure_before_creation", created, closed),
            ):
                if first and last and last < first:
                    flag(
                        label,
                        (last - first).days,
                        "Calendar-day sequence requires source-history corroboration.",
                        1,
                    )
            for name in ("lastExcessExplanationDeadline", "lastExcessValidationTechnicalDeadline"):
                deadline = record.typed(name)
                if (
                    opened is True
                    and deadline
                    and review.reference_date
                    and deadline < review.reference_date
                ):
                    flag(
                        "open_event_past_recorded_deadline",
                        f"{name}={deadline}",
                        "Open as recorded; freshness and subsequent history unknown. "
                        "Not an SLA conclusion.",
                    )
            if record.label("increaseWorkflowStatus"):
                increase_id = identifier(record.get("increaseId"))
                milestones = [
                    record.typed(name)
                    for name in (
                        "increaseCreationDate",
                        "increaseValidationTrdDirCreationDate",
                        "increaseValidationRisqCreationDate",
                    )
                ]
                if increase_id in {"", "0"} or any(value is None for value in milestones):
                    flag(
                        "incomplete_limit_increase_evidence",
                        record.label("increaseWorkflowStatus"),
                        "Recorded status lacks a usable ID or one or more request/approval dates.",
                    )
                if milestones[0] and any(
                    value and value < milestones[0] for value in milestones[1:]
                ):
                    flag(
                        "limit_approval_before_request",
                        record.label("increaseWorkflowStatus"),
                        "Calendar-date sequence is inconsistent; effective-date "
                        "lineage remains unverified.",
                        1,
                    )
        value, limit = record.typed("excessLastConsoValue"), record.typed("limitValue")
        ratio = None
        if (
            not conflicting
            and value is not None
            and limit is not None
            and ((value >= 0 and limit > 0) or (value < 0 and limit < 0))
        ):
            ratio = abs(value) / abs(limit)
        usage_text = record.label("usage")
        reported_usage = number(usage_text[:-1]) if usage_text.endswith("%") else None
        reported_ratio = reported_usage / 100 if reported_usage is not None else None
        if usage_text and reported_ratio is None:
            review.issue(
                "invalid_reported_usage",
                record.locator,
                "usage must contain an explicit percentage.",
            )
        maximum = record.typed("excessMaxUsage")
        if ratio is not None:
            if reported_ratio is not None and abs(ratio - reported_ratio) > 0.015 + 1e-12:
                flag(
                    "usage_reperformance_difference",
                    abs(ratio - reported_ratio) * 100,
                    "Difference exceeds 1.5 percentage points; relative triggers are "
                    "not absolute breaches.",
                    1,
                )
            if maximum is not None and ratio * 100 - maximum > 1 + 1e-12:
                flag(
                    "maximum_usage_below_last_usage",
                    ratio * 100 - maximum,
                    "Reported maximum is more than one percentage point below the last usage.",
                    1,
                )
        group = tuple(
            record.normalized(name)
            for name in (
                "perimeterMnemonic",
                "riskIndicator",
                "riskMetricName",
                "unit",
                "limitType",
            )
        )
        if not conflicting and all(group) and limit is not None:
            repeated[(*group, limit)].append(record)
        review.excesses.append(
            {
                "excessId": event_id,
                **identifiers,
                "source_locator": record.locator,
                "conflicting_id": conflicting,
                "recorded_open": opened,
                "workflow_status": record.label("excessWorkflowStatus"),
                "creation_date": created,
                "observation_date": record.typed("excessLastConsoValueDate"),
                "closure_date": closed,
                "calendar_age_days": age,
                "explanation_calendar_lag_days": (explained - created).days
                if explained and created and not conflicting
                else None,
                "validation_calendar_lag_days": (validated - explained).days
                if validated and explained and not conflicting
                else None,
                "explanation_date": explained,
                "validation_date": validated,
                "validation_satisfactory": record.typed("lastExcessValidationIsSatisfactory"),
                "lod2_date": record.typed("lastExcessValidationLod2CreationDate"),
                "lod2_satisfactory": record.typed("lastExcessValidationLod2IsSatisfactory"),
                "reperformed_usage": ratio,
                "reported_usage": reported_ratio,
                "reported_max_usage_percent": maximum,
                "duplicate_locators": "\n".join(record.duplicate_locators),
                **{f"raw:{name}": value for name, value in record.raw.items()},
            }
        )
    for _, records in sorted(repeated.items()):
        if len(records) >= 3:
            review.candidate(
                "repeated_excess_population",
                {
                    name: records[0].label(name) or None
                    for name in ("riskMetricName", "perimeterMnemonic")
                },
                len(records),
                "\n".join(record.locator for record in records),
                "Selected excess population; does not estimate daily breach frequency.",
                "Review recurring causes, event independence and remediation evidence.",
            )
    eligible = [row for row in review.excesses if not row["conflicting_id"]]
    known_open = [row for row in eligible if row["recorded_open"] is not None]
    review.count("Colibris input events", source.input_rows)
    review.count("Colibris exact duplicates removed", source.duplicate_rows)
    review.count("Colibris analyzed records", len(source.records))
    review.count("Colibris distinct nonblank event IDs", len([key for key in ids if key]))
    review.count("Colibris events with known open state", len(known_open))
    review.count(
        "Colibris recorded open events",
        sum(row["recorded_open"] is True for row in known_open) if known_open else None,
    )
    for field, label in (
        ("explanation_date", "explanation"),
        ("validation_date", "validation"),
        ("lod2_date", "LoD2"),
    ):
        review.count(
            f"Colibris records with {label} date evidence",
            sum(row[field] is not None for row in eligible),
        )
