"""Load risk evidence with bounded intermediates and exact source identity rules."""

from __future__ import annotations

import csv
import json
from collections import Counter
from collections.abc import Callable, Iterable, Iterator
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from typing import TextIO

import polars as pl

from .models import Record, Review, Row, Source, boolean, day, identifier, number, text

SGMR_REQUIRED = ("limId", "stranaNodeName", "rmRiskIndicator", "consoValueDate", "consoValue")
NUMBER_FIELDS = {
    name.lower()
    for name in (
        "consoValue",
        "consoValueEur",
        "consoVersion",
        "limMinValue",
        "limMaxValue",
        "limInitialMinValue",
        "limInitialMaxValue",
        "limTempMinValue",
        "limTempMaxValue",
        "excessLastConsoValue",
        "limitValue",
        "excessMaxUsage",
        "creationConsValue",
        "daysInExcess",
        "daysWithoutValidationTotal",
        "daysWithoutExplanation",
        "daysWithoutValidateExplanation",
        "nbDaysFoFirstComment",
        "totalNbDaysFo",
        "avgNbDaysFo",
        "nbDaysMmgFirstComment",
        "nbDaysMmgLastComment",
        "totalNbDaysMmg",
        "avgNbDaysMmg",
        "nbDaysWaitingTrader",
        "nbDaysWaitingMacc",
    )
}
DATE_FIELDS = {
    name.lower()
    for name in (
        "consoValueDate",
        "consoLastValueDate",
        "consoCreationDate",
        "limStartDate",
        "limEndDate",
        "eligibleCheckpointStartDate",
        "excessCreationDate",
        "excessLastConsoValueDate",
        "excessCloseDate",
        "closingConsDate",
        "creationConsDate",
        "increaseCreationDate",
        "increaseValidationTrdDirCreationDate",
        "increaseValidationRisqCreationDate",
        "lastExcessExplanationCreationDate",
        "lastExcessExplanationDeadline",
        "lastExcessValidationCreationDate",
        "lastExcessValidationTechnicalDeadline",
        "lastExcessValidationLod2CreationDate",
        "lastExplanationRequestDate",
    )
}
BOOL_FIELDS = {
    name.lower()
    for name in (
        "excessStillOpen",
        "closedManually",
        "lastExcessExplanationIsExcessConfirmed",
        "lastExcessValidationIsSatisfactory",
        "lastExcessValidationLod2IsSatisfactory",
    )
}


def _source_path(path: str | Path, suffix: str, role: str) -> Path:
    """Resolve an existing source of the required format without reading its contents."""
    resolved = Path(path).expanduser().resolve()
    if not resolved.is_file():
        raise ValueError(f"{role} path must be an existing file: {resolved}")
    if resolved.suffix.lower() != suffix:
        raise ValueError(f"{role} requires a {suffix} file: {resolved.name}")
    return resolved


def read_bytes(path: str | Path, suffix: str, role: str) -> tuple[Path, bytes]:
    """Read a complete commentary document; tabular sources use streaming readers."""
    resolved = _source_path(path, suffix, role)
    try:
        return resolved, resolved.read_bytes()
    except OSError as exc:
        raise ValueError(f"Cannot read {role} file; check input permissions: {resolved}") from exc


def _columns(names: list[str], role: str) -> dict[str, str]:
    mapped = {name.strip().lower(): name for name in names}
    if len(mapped) != len(names) or "" in mapped:
        raise ValueError(f"{role} contains blank or ambiguous case-insensitive column names.")
    return mapped


def _parse(record: Record, review: Review) -> None:
    for name, value in record.values.items():
        parser = (
            number
            if name in NUMBER_FIELDS
            else day
            if name in DATE_FIELDS
            else boolean
            if name in BOOL_FIELDS
            else None
        )
        if parser is None:
            continue
        parsed = parser(value)
        if (
            name == "consoversion"
            and parsed is not None
            and (parsed < 0 or not parsed.is_integer())
        ):
            parsed = None
        if (
            name in NUMBER_FIELDS
            and name.startswith(("days", "nbdays", "totalnbdays", "avgnbdays"))
            and parsed is not None
            and parsed < 0
        ):
            parsed = None
        record.parsed[name] = parsed
        if text(value) and parsed is None:
            review.issue(
                "invalid_field", record.locator, f"Invalid {name}; original value retained."
            )


def load_table(path: str | Path | None, role: str, review: Review) -> Source:
    """Read SGMR Parquet or Colibris CSV and append its owned source to review.

    SGMR is required; an omitted Colibris source returns an unavailable Source.
    Validate headers and parse typed fields while preserving original values.
    Exact duplicate rows are counted and excluded from the retained population.
    References use the filename and normalized id/excessId; missing or repeated
    IDs also retain the one-based input record number. Invalid files or schemas
    raise ValueError. Source files are never modified.

    Parquet loads the validated literal path into one columnar frame. CSV uses two streaming
    passes on one open handle: count supplied IDs, then prepare retained records.
    Neither route builds a whole-file bytes buffer or a complete Python row list.
    """
    source = Source(role=role, path=None)
    review.sources.append(source)
    if path is None:
        if role == "sgmr":
            raise ValueError("SGMR path is required.")
        return source
    suffix = ".parquet" if role == "sgmr" else ".csv"
    resolved = _source_path(path, suffix, role)
    source.path = str(resolved)
    try:
        if role == "sgmr":
            try:
                # Source labels must describe this exact file, even when its path has brackets.
                frame = pl.read_parquet(resolved, glob=False)
            except (pl.exceptions.PolarsError, ValueError) as exc:
                raise ValueError(f"Cannot parse {role} {suffix} file: {resolved.name}") from exc
            return _prepare_table(
                source, frame.columns, lambda: frame.iter_rows(named=True), review
            )
        with resolved.open(encoding="utf-8-sig", newline="") as stream:
            try:
                names = csv.DictReader(stream, strict=True).fieldnames or []
            except (UnicodeError, csv.Error) as exc:
                raise ValueError(f"Cannot parse {role} {suffix} file: {resolved.name}") from exc
            return _prepare_table(source, names, lambda: _csv_rows(stream, resolved), review)
    except OSError as exc:
        raise ValueError(f"Cannot read {role} file; check input permissions: {resolved}") from exc


def _csv_rows(stream: TextIO, path: Path) -> Iterator[Row]:
    """Replay a CSV handle from its header, validating each row without retaining a list."""
    stream.seek(0)
    try:
        for row in csv.DictReader(stream, strict=True):
            if None in row or any(value is None for value in row.values()):
                raise ValueError("CSV records do not match the header width")
            yield row
    except (UnicodeError, csv.Error, ValueError) as exc:
        raise ValueError(f"Cannot parse colibris .csv file: {path.name}") from exc


def prepare_table(frame: pl.DataFrame | None, role: str, review: Review, *, name: str) -> Source:
    """Prepare an owned in-memory table using the file loader's population rules.

    Args:
        frame: Raw SGMR or Colibris columns and values. None omits Colibris;
            SGMR requires a nonempty frame with its core columns.
        role: The source role, sgmr or colibris.
        review: Fresh result receiving the source and parsing disclosures.
        name: Nonblank source label, used for evidence references without
            resolving or reading any path.

    Returns:
        A source containing copied records in original order, typed fields and
        exact-duplicate locations. The caller's frame is unchanged.

    Raises:
        ValueError: Required data/columns are absent, names are ambiguous or the
            supplied label is blank. Invalid field values remain disclosed unknowns.
    """
    source = Source(role=role, path=name if frame is not None else None)
    review.sources.append(source)
    if frame is None:
        if role == "sgmr":
            raise ValueError("SGMR table is required.")
        return source
    if not name.strip():
        raise ValueError("A supplied table requires a nonblank source name.")
    # Object columns can retain caller-owned nested values after iter_rows().
    # Copy each retained input row without materializing two complete row lists.
    return _prepare_table(
        source, frame.columns, lambda: frame.iter_rows(named=True), review, copy_values=True
    )


def _canonical_row(raw: Row) -> str:
    """Encode the original exact-duplicate comparison, including type and null distinctions."""
    return json.dumps(raw, sort_keys=True, default=str, ensure_ascii=False)


def _prepare_table(
    source: Source,
    names: list[str],
    rows: Callable[[], Iterable[Row]],
    review: Review,
    *,
    copy_values: bool = False,
) -> Source:
    """Validate headers, remove exact duplicates and parse an owned row population.

    Compare complete raw rows before parsing. Count source IDs before duplicate
    removal, retaining one-based original row ordinals for ambiguous references.
    The rows factory must replay the same supplied population. The first pass
    counts IDs, including duplicates; the second owns retained records and
    appends disclosures in original order. copy_values protects nested values
    in caller-owned in-memory frames. File readers already produce owned values.

    Retain fixed-size SHA-256 keys, verifying canonical equality on every digest
    match. Hash collisions never merge different records. Complete canonical
    strings exist only during comparison, not for the whole retained population.
    """
    role = source.role
    mapping = _columns(names, role)
    required = SGMR_REQUIRED if role == "sgmr" else ("excessId",)
    missing = [name for name in required if name.lower() not in mapping]
    if missing:
        raise ValueError(f"{role} missing required columns: {', '.join(missing)}")
    source.columns = set(mapping)
    filename = Path(source.path).name
    id_field = "id" if role == "sgmr" else "excessId"
    id_column = mapping.get(id_field.lower())
    ids = Counter(identifier(raw.get(id_column)) for raw in rows())
    source.input_rows = sum(ids.values())
    if role == "sgmr" and not source.input_rows:
        raise ValueError("SGMR dataset contains no rows.")
    seen: dict[bytes, list[Record]] = {}
    for ordinal, raw in enumerate(rows(), 1):
        if copy_values:
            raw = deepcopy(raw)
        source_id = identifier(raw.get(id_column))
        reference = f"{id_field}={json.dumps(source_id, ensure_ascii=False)}" if source_id else ""
        if not source_id or ids[source_id] > 1:
            reference = f"{reference}; record={ordinal}" if reference else f"record={ordinal}"
        locator = f"{filename} [{reference}]"
        canonical = _canonical_row(raw)
        key = sha256(canonical.encode("utf-8", errors="surrogatepass")).digest()
        bucket = seen.setdefault(key, [])
        duplicate = next(
            (record for record in bucket if _canonical_row(record.raw) == canonical), None
        )
        if duplicate is not None:
            duplicate.duplicate_locators.append(locator)
            source.duplicate_rows += 1
            review.issue("exact_duplicate", locator, f"Retained record: {duplicate.locator}")
            continue
        record = Record(
            raw, {name: raw[original] for name, original in mapping.items()}, locator, ordinal
        )
        bucket.append(record)
        _parse(record, review)
        source.records.append(record)
    return source
