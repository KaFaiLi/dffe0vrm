"""Incremental Excel output preserving every calculated risk evidence row and style."""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from contextlib import suppress
from datetime import date, datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.cell import Cell, WriteOnlyCell
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from ..excel_evidence import check_sheet_capacity, iter_evidence_rows
from .models import Review, Row
from .report import METHODS, _string, outlier_rows


def _write_sheet(workbook: Workbook, title: str, rows: list[Row]) -> None:
    """Write complete evidence with continuation rows and stable column/style ordering.

    Preflight dimensions and the established first-100-row column widths, then
    stream styled cells. Keep at most 100 prepared rows during preflight and one
    source row's continuation parts during writing. Split strings at 32,000
    characters, keeping numeric measures only in the first part. Inputs remain
    read-only and overflow is rejected before this sheet writes any cells.
    """
    columns = list(dict.fromkeys(key for row in rows for key in row)) or ["status"]
    if not rows:
        rows = [{"status": "No rows; consult source availability."}]
    sample = []
    row_count = 0
    has_parts = False
    for row in iter_evidence_rows(rows):
        row_count += 1
        check_sheet_capacity(row_count + 1, len(columns), title)
        has_parts |= "text_part" in row
        if row_count <= 100:
            sample.append(row)
    if has_parts:
        columns += ["report_record", "text_part"]
    check_sheet_capacity(row_count + 1, len(columns), title)
    sheet = workbook.create_sheet(title)
    for index, column in enumerate(columns, 1):
        width = max([len(column), *(min(len(_string(row.get(column))), 60) for row in sample)])
        sheet.column_dimensions[get_column_letter(index)].width = min(max(width + 2, 12), 60)
    del sample
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{row_count + 1}"
    alignment = Alignment(vertical="top", wrap_text=True)
    font = Font(bold=True, color="FFFFFF")
    fill = PatternFill("solid", fgColor="24465D")

    def cells(values: Iterable[object], *, header: bool = False) -> Iterator[Cell]:
        """Prepare one row's styled, literal cells before write-only serialization."""
        for value in values:
            cell = WriteOnlyCell(sheet, value=value)
            if isinstance(value, str):
                cell.data_type = "s"  # Never execute source text as an Excel formula.
            if isinstance(value, (date, datetime)):
                cell.number_format = "yyyy-mm-dd"
            elif isinstance(value, float):
                cell.number_format = "0.0000"
            cell.alignment = alignment
            if header:
                cell.font, cell.fill = font, fill
            yield cell

    sheet.append(cells(columns, header=True))
    for row in iter_evidence_rows(rows):
        sheet.append(cells(row.get(column) for column in columns))


def _discard_streams(workbook: Workbook) -> None:
    """Best-effort removal of write-only XML files without masking the export error.

    Workbook.close does not clean write-only worksheet temporaries on failure.
    openpyxl's worksheet writer owns those paths; only its own cleanup method
    is used. Successful save already performs this cleanup. Keep these private
    API accesses localized and covered by failed-save/failed-row regressions.
    """
    for sheet in workbook:
        with suppress(Exception):
            if not sheet.closed:
                sheet.close()
        writer = sheet._writer
        if writer is not None:
            with suppress(Exception):
                writer.close()
            with suppress(OSError, ValueError):
                if Path(writer.out).exists():
                    writer.cleanup()


def export_workbook(review: Review, path: Path) -> None:
    """Stream nine complete evidence sheets and close owned resources even on failure.

    Include source identities, population counts, methods and unavailable checks.
    Commentary stays in the complete Markdown report rather than a parsed Excel
    table. Source strings are literal cells, with oversized text split into
    continuation records. Invalid sheet sizes raise ValueError; write errors
    propagate without changing the in-memory review.
    """
    workbook = Workbook(write_only=True)
    methods = [{"kind": "method", "name": name, "detail": detail} for name, detail in METHODS]
    sources = [
        {
            "kind": "source",
            "name": s.role,
            "path": s.path,
            "input_records": s.input_rows,
            "duplicates_removed": s.duplicate_rows,
        }
        for s in review.sources
    ]
    try:
        for name, rows in (
            ("Summary", review.summary),
            ("Series Review", review.series),
            ("Value Outliers", outlier_rows(review)),
            ("Movement and Value Outliers", outlier_rows(review, joint=True)),
            ("Excess Review", review.excesses),
            ("Review Candidates", review.candidates),
            ("Data Quality", review.quality),
            ("SGMR Detail", review.detail),
            (
                "Sources and Methods",
                [
                    *sources,
                    *methods,
                    *[{"kind": "availability", **row} for row in review.availability],
                ],
            ),
        ):
            _write_sheet(workbook, name, rows)
        workbook.save(path)
    except BaseException:
        _discard_streams(workbook)
        raise
    finally:
        workbook.close()
