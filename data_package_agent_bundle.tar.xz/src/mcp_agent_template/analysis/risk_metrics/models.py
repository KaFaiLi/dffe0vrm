"""Owned source records, calculated risk evidence and common value normalization."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

Row = dict[str, Any]


def text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def norm(value: Any) -> str:
    return " ".join(text(value).upper().split())


def number(value: Any) -> float | None:
    if value is None or isinstance(value, bool) or not text(value):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def day(value: Any) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return datetime.fromisoformat(text(value).replace("Z", "+00:00")).date()
    except ValueError:
        return None


def boolean(value: Any) -> bool | None:
    value = norm(value)
    if value in {"TRUE", "YES", "Y", "1"}:
        return True
    if value in {"FALSE", "NO", "N", "0"}:
        return False
    return None


def identifier(value: Any) -> str:
    """Normalize numeric Excel/CSV identifiers without changing textual identifiers."""
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return str(int(value))
    return text(value)


def close(left: float | None, right: float | None) -> bool:
    return (
        left is not None
        and right is not None
        and math.isclose(left, right, rel_tol=1e-8, abs_tol=1e-8)
    )


@dataclass
class Record:
    raw: Row
    values: Row
    locator: str
    ordinal: int
    parsed: Row = field(default_factory=dict)
    duplicate_locators: list[str] = field(default_factory=list)

    def get(self, name: str) -> Any:
        return self.values.get(name.lower())

    def label(self, name: str) -> str:
        return text(self.get(name))

    def normalized(self, name: str) -> str:
        return norm(self.get(name))

    def typed(self, name: str) -> Any:
        return self.parsed.get(name.lower())


@dataclass
class Observation:
    """One retained SGMR value with series identity and movement eligibility flags."""

    record: Record
    key: tuple[str, ...]
    day: date | None
    value: float | None
    conflict: bool = False
    comparable: bool = False

    @property
    def identifiers(self) -> Row:
        """Return report labels from SGMR's metric name and PC, preserving source spelling.

        Map rmRiskMetricName to riskMetricName and stranaPc to perimeterMnemonic.
        Missing labels remain unknown; the complete analytical identity stays in key.
        """
        return {
            "riskMetricName": self.record.label("rmRiskMetricName") or None,
            "perimeterMnemonic": self.record.label("stranaPc") or None,
        }


@dataclass
class Source:
    """Source identity, supplied population and retained structured records for a review."""

    role: str
    path: str | None
    input_rows: int | None = None
    duplicate_rows: int = 0
    columns: set[str] = field(default_factory=set)
    records: list[Record] = field(default_factory=list)


@dataclass
class Commentary:
    """A complete source document supplied to the agent without interpretation."""

    role: str
    path: str
    content: str


@dataclass
class Review:
    """Owned per-run evidence shared by Markdown, Excel and chart writers.

    Analysis entry points create fresh records, rows and observations. Renderers
    treat this mutable container and its nested objects as read-only. Observations
    reference the same retained records as sources; they are not reconstructed
    from display labels or business IDs. Commentary remains unprocessed text.
    """

    sources: list[Source] = field(default_factory=list)
    summary: list[Row] = field(default_factory=list)
    availability: list[Row] = field(default_factory=list)
    series: list[Row] = field(default_factory=list)
    excesses: list[Row] = field(default_factory=list)
    commentary: list[Commentary] = field(default_factory=list)
    candidates: list[Row] = field(default_factory=list)
    quality: list[Row] = field(default_factory=list)
    detail: list[Row] = field(default_factory=list)
    reference_date: date | None = None
    observations: list[Observation] = field(default_factory=list)

    def issue(self, check: str, locator: str, detail: str) -> None:
        self.quality.append({"check": check, "source_locator": locator, "detail": detail})

    def candidate(
        self,
        check: str,
        identifiers: Row,
        observed: Any,
        locator: str,
        qualification: str,
        follow_up: str,
        *,
        priority: int = 2,
        date_start: date | None = None,
        date_end: date | None = None,
    ) -> None:
        """Append a source-linked candidate with separate metric and perimeter labels.

        Labels describe the supplied record; they do not replace its source locator
        or the full series identity used for calculations and chart matching.
        """
        self.candidates.append(
            {
                "review_order": priority,
                "check": check,
                "riskMetricName": identifiers.get("riskMetricName"),
                "perimeterMnemonic": identifiers.get("perimeterMnemonic"),
                "observed": observed,
                "source_locator": locator,
                "qualification": qualification,
                "follow_up": follow_up,
                **({"date_start": date_start, "date_end": date_end} if date_start else {}),
            }
        )

    def available(self, check: str, source: Source, fields: tuple[str, ...]) -> bool:
        missing = [field for field in fields if field.lower() not in source.columns]
        status = "unavailable" if source.path is None or missing else "available"
        valid_rows = sum(
            all(
                record.parsed.get(name.lower(), record.get(name)) is not None
                and text(record.parsed.get(name.lower(), record.get(name))) != ""
                for name in fields
            )
            for record in source.records
        )
        if status == "available" and fields and source.records and valid_rows < len(source.records):
            status = "partial" if valid_rows else "unavailable"
        self.availability.append(
            {
                "check": check,
                "source": source.role,
                "status": status,
                "missing_fields": ", ".join(missing) if source.path else "source omitted",
                "usable_records_for_all_listed_fields": valid_rows if source.path else None,
            }
        )
        return status != "unavailable"

    def count(self, name: str, value: Any) -> None:
        self.summary.append({"measure": name, "value": value})
