"""Movement/value z-scores, exact-observation joint flags and retained level shifts."""

from __future__ import annotations

from collections import defaultdict
from itertools import pairwise
from math import isfinite
from statistics import fmean, pstdev

from .models import Observation, Review, Row
from .sgmr import consecutive_runs


def _shift(values: list[float]) -> tuple[int, float, float | None] | None:
    """Retain the strongest qualifying 20-before/20-after mean shift, earliest on ties."""
    best = None
    score = -1.0
    for index in range(20, len(values) - 19):
        before, after = values[index - 20 : index], values[index : index + 20]
        baseline, changed = fmean(before), fmean(after)
        if baseline == 0:
            continue
        relative = (changed - baseline) / abs(baseline)
        dispersion = (pstdev(before) + pstdev(after)) / 2
        effect = abs(changed - baseline) / dispersion if dispersion else None
        if abs(relative) >= 0.20 and (effect is None or effect >= 2.5):
            candidate_score = abs(relative) * effect if effect is not None else float("inf")
            if candidate_score > score:
                best, score = (index, relative, effect), candidate_score
    return best


def _movements(segment: list[Observation], details: dict[str, Row], review: Review) -> Row:
    """Calculate every successive percentage movement within one comparable segment.

    Use (current - previous) / abs(previous), excluding zero previous values and
    nonfinite results from the population mean and population standard deviation.
    Standardize all known movements against that same complete segment, with no
    minimum sample count. A zero dispersion leaves z-scores and flags unknown.
    Flag abs(z) > 3, excluding equality and retaining both tails. Update the
    existing SGMR detail rows and return segment-level numerical evidence. Source
    records are read-only; observations at a segment boundary are never bridged.
    """
    changes = []
    for previous, current in pairwise(segment):
        detail = details[current.record.locator]
        detail["previous_observation_date"] = previous.day
        detail["previous_source_locator"] = previous.record.locator
        if previous.value == 0:
            detail["movement_status"] = "zero_previous_value"
            continue
        change = (current.value - previous.value) / abs(previous.value)
        if not isfinite(change):
            detail["movement_status"] = "nonfinite_movement"
            review.issue("nonfinite_movement", current.record.locator, "Movement remains unknown.")
            continue
        detail["relative_movement"] = change
        changes.append((current, change))
    values = [change for _, change in changes]
    average = fmean(values) if values else None
    deviation = pstdev(values) if values else None
    for current, change in changes:
        detail = details[current.record.locator]
        z = (change - average) / deviation if deviation else None
        detail.update(
            movement_z_score=z,
            movement_outlier=abs(z) > 3 if z is not None else None,
            movement_population_count=len(values),
            mean_relative_movement=average,
            movement_population_stddev=deviation,
            movement_status="available" if z is not None else "zero_movement_dispersion",
        )
        if z is not None and abs(z) > 3:
            review.candidate(
                "movement_outlier",
                current.identifiers,
                f"movement={change:.6g}; z={z:.6g}; population={len(values)}",
                current.record.locator,
                "Absolute movement z-score >3 over all known movements in this comparable "
                "segment. Descriptive screen; no policy materiality conclusion.",
                "Corroborate positions, market conditions, model changes and "
                "contemporaneous commentary.",
                priority=3,
            )
    return {
        "movement_observations": len(values),
        "mean_relative_movement": average,
        "movement_population_stddev": deviation,
        "maximum_absolute_movement_z_score": max(
            (abs(details[current.record.locator]["movement_z_score"]) for current, _ in changes),
            default=None,
        )
        if deviation
        else None,
        "movement_outliers": sum(
            details[current.record.locator]["movement_outlier"] is True for current, _ in changes
        ),
        "zero_baseline_changes_unavailable": sum(
            previous.value == 0 for previous, _ in pairwise(segment)
        ),
        "largest_absolute_relative_change": max((abs(value) for value in values), default=None),
    }


def analyze_dynamics(observations: list[Observation], review: Review) -> None:
    """Enrich existing detail and series evidence without combining distinct risk definitions.

    Calculate movements for every comparable consecutive segment, including those
    with fewer than 20 values. Existing risk-level outliers still require 20
    observations and use abs(z) > 3; mean-shift rules are unchanged. Neither
    volatility-change nor persistent-trend calculations are performed. Record
    movement availability independently from the retained level-statistics gate.
    Retain signed value scores, baselines and unavailable reasons for every row.
    Joint flags require both screens on that exact observation, never a date-only
    or display-label match between different series.
    """
    dates = sorted({row.day for row in observations if row.day is not None})
    # Every series uses the same complete calendar; build its lookup only once.
    date_indices = {value: index for index, value in enumerate(dates)}
    details = {row["source_locator"]: row for row in review.detail}
    for row in observations:
        details[row.record.locator].update(
            previous_observation_date=None,
            previous_source_locator=None,
            relative_movement=None,
            movement_z_score=None,
            movement_outlier=None,
            movement_population_count=None,
            mean_relative_movement=None,
            movement_population_stddev=None,
            movement_status="no_previous_comparable_observation"
            if row.comparable and not row.conflict
            else "invalid_or_conflicting_observation",
            value_z_score=None,
            value_outlier=None,
            value_population_count=None,
            mean_value=None,
            value_population_stddev=None,
            value_status="insufficient_comparable_observations"
            if row.comparable and not row.conflict
            else "invalid_or_conflicting_observation",
            movement_and_value_outlier=None,
        )
    groups: dict[tuple, list[Observation]] = defaultdict(list)
    for row in observations:
        groups[row.key].append(row)
    segments_analyzed = 0
    movement_count = 0
    movement_segments = 0
    scored_movements = 0
    scored_values = 0
    for key, rows in sorted(groups.items()):
        segments = consecutive_runs(
            rows, dates, lambda row: row.comparable, date_indices=date_indices
        )
        if not any(len(segment) >= 20 for segment in segments):
            review.issue(
                "statistics_unavailable",
                rows[0].record.locator,
                (
                    "Fewer than 20 consecutive comparable observations; risk-level outlier "
                    "and mean-shift screens unavailable. Successive movements are calculated "
                    "independently where possible."
                ),
            )
        for segment in segments:
            values = [row.value for row in segment]
            movement = _movements(segment, details, review)
            movement_count += movement["movement_observations"]
            movement_segments += movement["movement_observations"] > 0
            scored_movements += (
                movement["movement_observations"] if movement["movement_population_stddev"] else 0
            )
            first_row = segment[0]
            summary = {
                "period": "statistics segment" if len(segment) >= 20 else "movement segment",
                "limId": key[0],
                "portfolio": key[1],
                "metric": key[3],
                "unit": key[5],
                "version": key[6],
                **first_row.identifiers,
                "date_start": first_row.day,
                "date_end": segment[-1].day,
                "statistics_observations": len(values) if len(values) >= 20 else None,
                "minimum_value": min(values),
                "maximum_value": max(values),
                "value_observations": len(values),
                "value_outliers": None,
                **movement,
                "source_locator": first_row.record.locator,
            }
            review.series.append(summary)
            for row in segment:
                details[row.record.locator]["value_population_count"] = len(values)
            if len(segment) < 20:
                continue
            segments_analyzed += 1
            average, deviation = fmean(values), pstdev(values)
            shift = _shift(values)
            summary.update(
                mean_value=average,
                population_stddev=deviation,
                outlier_screen_available=deviation > 0,
                value_outliers=sum(abs((value - average) / deviation) > 3 for value in values)
                if deviation
                else None,
                shift_relative_change=shift[1] if shift else None,
                shift_effect=shift[2] if shift else None,
                shift_zero_dispersion=shift is not None and shift[2] is None,
            )

            def flag(
                check: str,
                observed,
                row: Observation,
                qualification: str,
            ) -> None:
                """Append a retained level-screen candidate with its original source identity."""
                review.candidate(
                    check,
                    row.identifiers,
                    observed,
                    row.record.locator,
                    qualification + " Descriptive screen; no policy materiality conclusion.",
                    (
                        "Corroborate positions, market conditions, model changes and "
                        "contemporaneous commentary."
                    ),
                    priority=3,
                )

            for index, row in enumerate(segment):
                z = (values[index] - average) / deviation if deviation else None
                details[row.record.locator].update(
                    value_z_score=z,
                    value_outlier=abs(z) > 3 if z is not None else None,
                    value_population_count=len(values),
                    mean_value=average,
                    value_population_stddev=deviation,
                    value_status="available" if z is not None else "zero_value_dispersion",
                )
                scored_values += z is not None
                if z is not None and abs(z) > 3:
                    flag(
                        "metric_outlier",
                        z,
                        row,
                        "Population z-score over this comparable segment.",
                    )
            if shift:
                label = "zero dispersion" if shift[2] is None else f"effect={shift[2]:.6g}"
                flag(
                    "sustained_level_shift",
                    f"relative change={shift[1]:.6g}; {label}",
                    segment[shift[0]],
                    "Strongest qualifying 20-before/20-after comparison in this segment.",
                )
    for detail in details.values():
        # Join the two calculated flags on the retained source row, not on a shared date.
        movement, value = detail["movement_outlier"], detail["value_outlier"]
        detail["movement_and_value_outlier"] = (
            False
            if movement is False or value is False
            else True
            if movement is True and value is True
            else None
        )
    review.count("Comparable statistical segments analyzed", segments_analyzed)
    review.count("Comparable movement segments analyzed", movement_segments)
    review.count("Risk movements calculated", movement_count)
    review.count("Risk movements with known z-score", scored_movements)
    review.count("Risk values with known z-score", scored_values)
    review.count(
        "Metric value outlier observations",
        sum(row["value_outlier"] is True for row in details.values()),
    )
    review.count(
        "Movement and value outlier observations",
        sum(row["movement_and_value_outlier"] is True for row in details.values()),
    )
    for availability in review.availability:
        if availability["check"] == "Metric value outliers":
            availability["value_z_scores"] = scored_values
            availability["status"] = (
                ("available" if scored_values == len(observations) else "partial")
                if scored_values
                else "unavailable"
            )
            if not scored_values and not availability["missing_fields"]:
                availability["missing_fields"] = (
                    "No segment with at least 20 comparable values and positive value dispersion"
                )
        if availability["check"] == "Metric movements":
            availability["movement_observations"] = movement_count
            availability["movement_z_scores"] = scored_movements
            if not movement_count:
                availability["status"] = "unavailable"
                if not availability["missing_fields"]:
                    availability["missing_fields"] = (
                        "No consecutive comparable pair with a nonzero previous value"
                    )
            elif scored_movements < movement_count:
                availability["status"] = "partial"
