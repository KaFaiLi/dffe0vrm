"""Source-linked risk-value timelines and existing review markers."""

from collections import defaultdict
from collections.abc import Iterator

from matplotlib.figure import Figure
from matplotlib.text import Text

from ..charts import Chart, date_axes, label, numeric_values, style
from .models import Observation, Review
from .sgmr import AXIS_FIELDS, SERIES_FIELDS

FAMILIES = {"VAR": "var", "SVAR": "svar", "STRESS TEST": "stress", "STRESS": "stress"}
STYLES = {
    "Movement": ("#8056A3", "s"),
    "Limit change": ("#277F72", "^"),
    "Other review": ("#536878", "o"),
}


class _RiskFigure(Figure):
    """Release risk-chart text renderer caches before discarding the artists.

    Matplotlib 3.11 Text objects cache their last renderer. Artist cycles can
    retain that renderer's Agg pixel buffer even after the canvas is detached.
    Clearing this cache while artists are still attached releases the buffer
    without running process-wide garbage collection or changing PnL figures.
    """

    def clear(self, keep_observers: bool = False) -> None:
        """Clear artists and their renderer references on success or export failure."""
        for artist in self.findobj(Text):
            # Text has no public cache-release method; this is the same cache
            # Matplotlib itself excludes when copying/pickling a Text object.
            artist._renderer = None
        super().clear(keep_observers=keep_observers)


def _category(check: str) -> str:
    """Map retained review checks to value-timeline marker styles."""
    if check in {"observed_limit_change", "changed_limit_bounds"}:
        return "Limit change"
    if check in {
        "metric_outlier",
        "movement_outlier",
        "sustained_level_shift",
    }:
        return "Movement"
    return "Other review"


def risk_charts(observations: list[Observation], review: Review) -> Iterator[Chart]:
    """Yield figures for separate SGMR series in their supplied units.

    Match existing numerical findings through exact source locators. Missing
    and conflicted observations remain gaps on the full supplied SGMR calendar,
    including dates before or after a series' own observations. No dates are
    invented. Commentary is agent context and is never assigned to a chart
    through label matching.
    Use one value axis without limit-bound lines, utilization or warning panels.
    """
    groups = defaultdict(list)
    locator_keys = {}
    for item in observations:
        groups[item.key].append(item)
        for locator in (item.record.locator, *item.record.duplicate_locators):
            locator_keys[locator] = item.key
    findings_by_key = defaultdict(list)
    for candidate in review.candidates:
        # Neither a display scope nor a semantic cross-source match establishes identity.
        keys = {
            locator_keys[locator]
            for locator in candidate["source_locator"].splitlines()
            if locator in locator_keys
        }
        for key in keys:
            findings_by_key[key].append(candidate)
    # Share the full observed calendar across series, retaining leading/trailing
    # gaps without repeatedly scanning each series for its date bounds.
    dates = sorted({item.day for item in observations if item.day is not None})
    for ordinal, (key, members) in enumerate(sorted(groups.items())):
        family = FAMILIES.get(key[3], "highlighted_risk")
        findings = findings_by_key[key]
        if family == "highlighted_risk" and not findings:
            continue
        dated = [item for item in members if item.day is not None]
        if not dated:
            continue
        scope = dict(zip((*SERIES_FIELDS, *AXIS_FIELDS), key, strict=True))
        rows = {item.day: item for item in dated if not item.conflict and item.comparable}
        values = numeric_values(rows[d].value if d in rows else None for d in dates)
        figure = _RiskFigure()
        risk_axis = figure.subplots()
        risk_axis.plot(
            dates,
            values,
            marker="o",
            markersize=3,
            label="Observed risk",
            color="#2864A0",
            linewidth=2,
        )
        markers = defaultdict(dict)
        by_locator = {item.record.locator: item for item in rows.values()}
        for finding in findings:
            category = _category(finding["check"])
            for locator in finding["source_locator"].splitlines():
                item = by_locator.get(locator)
                if item is not None:
                    markers[category][item.day] = item.value
        for category in reversed(STYLES):
            points = markers.get(category)
            if not points:
                continue
            color, symbol = STYLES[category]
            risk_axis.plot(
                list(points),
                numeric_values(points.values()),
                linestyle="none",
                label=category,
                color=color,
                marker=symbol,
                markerfacecolor="none" if category == "Other review" else color,
                markersize=6,
            )
        title = f"{key[3]} · {key[1]} · limit {key[0]} · series {ordinal + 1}"
        subtitle = (
            f"{key[4]} · PC {key[2] or 'unspecified'} · "
            f"{key[5] or 'unit unknown'} · version {key[6]}"
        )
        if scope["consoSttScenario"]:
            subtitle += " · scenario " + scope["consoSttScenario"]
        date_axes(figure, dates)
        risk_axis.set_ylabel(label(key[5] or "Unit unknown"))
        risk_axis.set_xlabel("Observation date")
        figure.legend(
            loc="outside lower center",
            ncols=3,
            fontsize=9,
            frameon=False,
            title="Markers: existing review candidates",
            title_fontsize=10,
        )
        notes = [
            "Risk values remain in supplied units and are not summed.",
            "Gaps include missing, conflicting or incomparable observations.",
            "Markers use exact SGMR source locators; "
            "Colibris workflow evidence stays independent; commentary is agent context.",
            "Series number distinguishes full definitions within this run. "
            "The chart index and manifest retain every definition/scenario axis.",
        ]
        if not any(item.value is not None for item in rows.values()):
            risk_axis.text(
                0.5,
                0.5,
                "No comparable observations; consult data-quality evidence",
                transform=risk_axis.transAxes,
                ha="center",
            )
        style(figure, title, subtitle, height=900)
        yield Chart(
            figure,
            family,
            title,
            scope,
            key[5] or "unknown",
            dates,
            [item.record.locator for item in members],
            notes,
            findings,
        )
