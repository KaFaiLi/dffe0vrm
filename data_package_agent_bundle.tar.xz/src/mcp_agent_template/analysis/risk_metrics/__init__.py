"""Deterministic risk review with in-memory analysis and source-linked report artifacts."""

from .runners import analyze_tables, run_risk_metrics_analysis

__all__ = ["analyze_tables", "run_risk_metrics_analysis"]
