"""Shared lossless cell preparation for deterministic analysis workbooks.

Writers own their domain layouts. These helpers prepare literal source values,
split long text, and enforce Excel capacity without changing numerical results.
"""

from __future__ import annotations

import json
import math
import re
from collections.abc import Iterable, Iterator
from datetime import date, datetime
from decimal import Decimal
from typing import Any

TEXT_PART_SIZE = 32000


def excel_value(value: Any) -> Any:
    """Prepare a scalar without discarding precision or XML-incompatible controls.

    Decimal amounts remain exact text, non-finite floats remain visibly named,
    and compound evidence uses JSON. XML control characters become visible
    ``\\uXXXX`` escapes. Writers must still mark strings as literal cell values
    and split long text before assigning it to a cell.
    """
    if isinstance(value, Decimal):
        value = str(value)
    elif isinstance(value, float) and not math.isfinite(value):
        value = json.dumps(value)
    elif isinstance(value, (dict, list, tuple)):
        value = json.dumps(value, default=str, ensure_ascii=False)
    elif not isinstance(value, (str, int, float, bool, date, datetime, type(None))):
        value = str(value)
    if isinstance(value, str):
        value = re.sub(
            r"[\x00-\x08\x0b\x0c\x0e-\x1f]",
            lambda match: f"\\u{ord(match.group()):04x}",
            value,
        )
    return value


def text_parts(text: str) -> list[str]:
    """Split already prepared text into ordered cell-sized parts, retaining empties."""
    return [
        text[start : start + TEXT_PART_SIZE] for start in range(0, len(text), TEXT_PART_SIZE)
    ] or [""]


def evidence_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Copy evidence into safe rows with numbered continuations for oversized text.

    Non-text measures occur only in the first part, preserving totals. Source
    rows remain unchanged. ``report_record`` is the one-based source ordinal and
    ``text_part`` is ``part/total``; these columns occur only on split records.
    Layouts requiring one row per case can use ``excel_value`` and ``text_parts``
    with a separate companion table instead.
    """
    return list(iter_evidence_rows(rows))


def iter_evidence_rows(rows: Iterable[dict[str, Any]]) -> Iterator[dict[str, Any]]:
    """Yield complete Excel-safe evidence, retaining only one source row's fragments.

    Match evidence_rows exactly: preserve source order, repeat text fragments,
    keep numeric measures only in the first part, and number split records by
    their original one-based ordinal. Input records are never mutated. Risk
    workbook export consumes this iterator; existing list-based callers retain
    the evidence_rows interface and output.
    """
    for ordinal, row in enumerate(rows, 1):
        clean = {key: excel_value(value) for key, value in row.items()}
        fragments = {
            key: text_parts(value) for key, value in clean.items() if isinstance(value, str)
        }
        count = max([1, *(len(parts) for parts in fragments.values())])
        for part in range(count):
            item = {
                key: (fragments[key][part] if part < len(fragments[key]) else "")
                if key in fragments
                else value
                if part == 0
                else None
                for key, value in clean.items()
            }
            if count > 1:
                item.update(report_record=ordinal, text_part=f"{part + 1}/{count}")
            yield item


def check_sheet_capacity(rows: int, columns: int, title: str) -> None:
    """Reject dimensions beyond Excel's capacity, including headers and layout offsets."""
    if rows > 1048576 or columns > 16384:
        raise ValueError(f"{title} exceeds Excel worksheet capacity; use a smaller source package.")
