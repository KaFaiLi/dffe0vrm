"""Load canonical sources, validate grains and prepare facts with source locations."""

import csv
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import load_workbook

from .models import Review

PNL_SOURCE_KEYS = ("PC", "GOP", "PTF")
HIERARCHY = ("bu", "sbu", "grppc100", "grppc200", "grppc300", "td", "pc", "ggop", "gop")
ATTRIBUTION_METADATA = (
    *HIERARCHY,
    "asofdate",
    "isbatchvalidated",
    "status",
    "validated",
    "air_mpc_validation_status",
    "air_fo_validation status",
)
REQUIRED = {
    "pnl": (
        "Value Date",
        "Notion",
        "GOP",
        "PC",
        "Currency",
        "DTD",
    ),
    "attribution": (
        *HIERARCHY,
        "asofdate",
    ),
    "adjustments": (
        "ADJUSTMENTID",
        "GOP",
        "PTF",
        "PC",
        "CCY",
        "AMOUNTINEUR",
        "VALDATEBEGIN",
        "VALDATEEND",
    ),
    "validation": ("gop", "team", "state", "api_request_date", "pnlType"),
}


def attribution_drivers(rows: list[dict]) -> list[str]:
    """Return daily monetary driver columns in source order.

    The wide attribution contract contains hierarchy/date/validation metadata,
    daily monetary drivers and optional unused final/cumulative columns.
    All non-metadata daily columns are drivers, including
    zero-valued and daily-only drivers. Cumulative columns are unused;
    their presence never determines whether a daily driver is analysed.
    """
    return list(
        dict.fromkeys(
            field
            for row in rows
            for field in row
            if field not in ATTRIBUTION_METADATA
            and field != "Final Result Acc DTD"
            and not field.startswith("_")
            and not field.endswith(" Cumulative")
        )
    )


def number(value) -> Decimal | None:
    try:
        result = Decimal(str(value).strip())
        return result if result.is_finite() else None
    except (InvalidOperation, ValueError):
        return None


def day(value, *, history=False) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value or "").strip()
    formats = (
        ("%m/%d/%Y", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S")
        if history
        else (
            "%Y-%m-%d",
            "%Y-%m-%d %H:%M:%S",
        )
    )
    for fmt in formats:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    return None


def text(value) -> str:
    return "" if value is None else str(value).strip()


def boolean(value) -> bool | None:
    return {"true": True, "1": True, "false": False, "0": False}.get(text(value).lower())


def _headers(values, role):
    names = [text(v) for v in values]
    if role == "pnl":
        aliases = {"valuationdate": "Value Date", "versiontype": "Version"}
        names = [aliases.get(name.casefold(), name) for name in names]
    lowered = [n.casefold() for n in names]
    if len(set(lowered)) != len(lowered):
        raise ValueError(f"{role}: duplicate column names are ambiguous.")
    missing = [k for k in REQUIRED[role] if k.casefold() not in lowered]
    if missing:
        raise ValueError(f"{role}: missing required columns: {', '.join(missing)}")
    canonical = {k.casefold(): k for k in REQUIRED[role]}
    if role == "attribution":
        canonical["final result acc dtd"] = "Final Result Acc DTD"
    if role == "pnl":
        canonical.update({k.casefold(): k for k in ("Version", "PTF", "WTD", "MTD", "QTD", "YTD")})
    return [canonical.get(k.casefold(), k) for k in names]


def load_table(path, role):
    """Load a source table with canonical headers and original row references.

    PnL accepts CSV or one schema-matching XLSX sheet; other roles accept CSV.
    Attribution requires at least one daily driver column, independently of its
    optional, unused final PnL column. Entirely blank drivers remain present.
    Required PnL columns cannot be entirely blank. Only an all-blank PnL Version
    column is discarded as unused metadata. Other blank columns remain present
    so missing attribution drivers and complete source records remain auditable.
    Source files are read without modification; invalid formats or schemas raise
    ValueError and filesystem failures propagate as OSError.
    """
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"{role}: input must be an existing file: {path}")
    sheet = None
    if path.suffix.lower() == ".xlsx" and role == "pnl":
        # Read cached values only: an uncached formula remains unknown.
        with path.open("rb") as stream:
            book = load_workbook(stream, read_only=True, data_only=True)
            try:
                candidates = []
                for tab in book:
                    first = next(tab.iter_rows(values_only=True), ())
                    try:
                        _headers(first, role)
                    except ValueError:
                        continue
                    else:
                        candidates.append(tab)
                if len(candidates) != 1:
                    raise ValueError("pnl: expected exactly one sheet with the required columns.")
                tab = candidates[0]
                sheet = tab.title
                iterator = tab.iter_rows(values_only=True)
                names = _headers(next(iterator), role)
                values = list(iterator)
            finally:
                book.close()
    elif path.suffix.lower() == ".csv":
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.reader(stream)
            names = _headers(next(reader, []), role)
            values = list(reader)
    else:
        raise ValueError(f"{role}: expected CSV" + (" or XLSX." if role == "pnl" else "."))
    rows = []
    for offset, values_row in enumerate(values, 2):
        if len(values_row) != len(names):
            raise ValueError(f"{role}: wrong number of fields at record {offset}.")
        row = dict(zip(names, values_row, strict=True))
        row["_ref"] = f"{path}" + (f" [sheet={sheet}]" if sheet else "") + f" [row={offset}]"
        rows.append(row)
    if not rows:
        raise ValueError(f"{role}: the source has no data rows.")
    if role == "attribution" and not attribution_drivers(rows):
        raise ValueError("attribution: expected at least one daily monetary driver column.")
    empty = {name for name in names if all(not text(row[name]) for row in rows)}
    if role == "pnl":
        missing = [name for name in REQUIRED[role] if name in empty]
        if missing:
            raise ValueError(f"pnl: required columns are entirely null: {', '.join(missing)}")
        # A blank driver is missing evidence, not an absent input column. Only
        # Version has an explicit contract permitting all-null column removal.
        if "Version" in empty:
            for row in rows:
                del row["Version"]
    return rows


def load_commentary(path):
    path = Path(path).expanduser().resolve()
    if path.suffix.lower() != ".md" or not path.is_file():
        raise ValueError("Commentary must be an existing Markdown file.")
    return path, path.read_text(encoding="utf-8-sig")


def prepare(rows: list[dict], role: str, review: Review) -> list[dict]:
    """Validate source grains before PC aggregation and mark rejected PC dates.

    All dates are included independently for each source. Source dates include
    rejected rows so charts leave visible gaps. An identifiable PC/date with
    rejected source contributions is excluded from the corresponding PC totals
    rather than presenting a partial sum as a complete observation.

    Args:
        rows: Canonical source records from ``load_table`` (including ``_ref``),
            or equivalent in-memory records. Input rows are not mutated.
        role: ``pnl`` or ``attribution``. PnL duplicate keys are date/PC/GOP/PTF;
            attribution uses date/full hierarchy. Key comparison retains raw
            source values, while PC aggregation trims identifiers.
        review: Receives scope, supplied dates, rejected PC dates and issues.
            Attribution driver names are retained before rejection so an entirely
            rejected source can still report its unavailable driver coverage.

    Returns:
        New row dictionaries with parsed ``_date`` and Decimal ``_daily`` for PnL.
        Attribution final PnL is optional and does not gate source validity;
        missing/invalid individual drivers are handled independently at aggregation.
        All copies of duplicate keys are excluded, retaining source order.

    Raises:
        ValueError: PnL Notion is not a single nonblank value or Currency is not
            EUR, including rows subsequently excluded numerically. No currency
            conversion or currency-specific analysis is performed.
    """
    if role == "attribution":
        review.attribution_driver_fields = attribution_drivers(rows)
    if role == "pnl":
        notions = {text(row.get("Notion")) for row in rows}
        if len(notions) != 1 or "" in notions:
            raise ValueError("pnl: Notion must have exactly one nonblank value per run.")
        if any(text(row.get("Currency")) != "EUR" for row in rows):
            raise ValueError("pnl: Currency must be EUR; currency conversion is not supported.")
        review.pnl_scope = {"Notion": notions.pop(), "Currency": "EUR"}
    field = "Value Date" if role == "pnl" else "asofdate"
    result = []
    for row in rows:
        row = dict(row)
        row["_date"] = day(row.get(field))
        if row["_date"] is not None:
            # Rejected amounts and duplicate grains still establish a supplied date.
            review.source_dates.setdefault(role, set()).add(row["_date"])
        keys = PNL_SOURCE_KEYS if role == "pnl" else ("pc", "gop")
        if role == "pnl":
            row["_daily"] = number(row.get("DTD"))
        missing_keys = [
            k for k in keys if not text(row.get(k)) and not (role == "pnl" and k == "PTF")
        ]
        if row["_date"] is None or (role == "pnl" and row["_daily"] is None) or missing_keys:
            if role == "pnl" and row["_date"] is not None:
                review.incomplete_pnl_dates.add((row["_date"], text(row.get("PC"))))
            elif role == "attribution" and row["_date"] is not None:
                review.incomplete_attribution_dates.add((row["_date"], text(row.get("pc"))))
            review.add(
                "invalid_row",
                row,
                f"{role}: missing/invalid "
                + ("date, amount or core key." if role == "pnl" else "date or core key."),
                dataset=role,
            )
            continue
        result.append(row)
    if role == "pnl":
        unique_keys = ("_date", *PNL_SOURCE_KEYS)
    else:
        unique_keys = ("_date", *HIERARCHY)
    return unique_rows(result, unique_keys, review, role)


def unique_rows(rows, keys, review, role):
    """Exclude ambiguous source keys and mark their PC dates incomplete across all dates."""
    groups = {}
    for row in rows:
        key = tuple(row.get(k) for k in keys)
        groups.setdefault(key, []).append(row)
    valid = []
    for group in groups.values():
        if len(group) == 1:
            valid.extend(group)
        else:
            for row in group:
                if role == "pnl":
                    review.incomplete_pnl_dates.add((row["_date"], text(row.get("PC"))))
                elif role == "attribution":
                    review.incomplete_attribution_dates.add((row["_date"], text(row.get("pc"))))
                review.add(
                    "duplicate_key",
                    row,
                    f"{role}: ambiguous business key; excluded.",
                    dataset=role,
                )
    return valid


def source_manifest(paths):
    import hashlib

    return [
        {
            "role": role,
            "path": str(Path(path).resolve()),
            "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        }
        for role, path in paths.items()
    ]
