"""Collected numerical review results and source evidence."""

from dataclasses import dataclass, field
from datetime import date


@dataclass
class Review:
    """Shared mutable evidence for calculations, Markdown, Excel and charts.

    Analysis stages populate tables, issues and source-date completeness in
    order. Renderers treat the result as read-only. ``pnl_daily`` retains the
    complete PC/date records returned by ``pnl_analysis``, including constituent
    references, so the runner need not carry a separate chart result. This
    dataclass does not make its nested records immutable. Attribution driver
    fields retain source order before rejected grains are removed, allowing
    missing driver amounts to remain explicit in retained daily evidence.
    """

    tables: dict[str, list[dict]] = field(default_factory=dict)
    issues: list[dict] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    source_dates: dict[str, set[date]] = field(default_factory=dict)
    pnl_scope: dict[str, str] = field(default_factory=dict)
    incomplete_pnl_dates: set[tuple[date, str]] = field(default_factory=set)
    incomplete_attribution_dates: set[tuple[date, str]] = field(default_factory=set)
    pnl_daily: list[dict] = field(default_factory=list)
    attribution_driver_fields: list[str] = field(default_factory=list)

    def add(self, check: str, row: dict, detail: str, **values) -> None:
        """Append one issue with source context, preserving stage and row order."""
        self.issues.append(
            {
                "check": check,
                "date": str(row.get("_date", "")),
                "gop": row.get("gop", row.get("GOP", "")),
                "reference": row.get("_ref", ""),
                "detail": detail,
                **values,
            }
        )
