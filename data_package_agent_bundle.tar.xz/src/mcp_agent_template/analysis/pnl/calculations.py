"""PC-level PnL screening and independent attribution calculations."""

from collections import defaultdict
from decimal import Decimal
from statistics import mean, pstdev

from .loading import (
    attribution_drivers,
    number,
    text,
)
from .models import Review


def pnl_analysis(rows: list[dict], review: Review) -> list[dict]:
    """Aggregate source PnL to daily PC totals and screen those complete series.

    Args:
        rows: Prepared, valid, unique source rows. Across all supplied dates,
            all GOP/PTF contributions sharing date and PC are summed. Notion
            and currency are validated run-level metadata, not keys. Version
            names may change by date and are not validated or used as keys.
            Source-key validation and duplicate exclusions
            happen before this function; legitimate different GOP/PTF rows add
            to the same PC daily total. PC dates with rejected constituents are
            excluded from totals and screening because their complete amount is unknown.
        review: Receives PC daily totals, series statistics, outliers and
            reversal candidates. Outliers also produce pnl_outlier issues.

    Returns:
        The aggregated daily PC records used by the PnL charts. Each record
        retains every contributing source reference. Optional reported YTD is
        summed only when all contributing rows supply a numeric YTD value;
        it is displayed without reconciliation and never drives screening.

    Statistics use one observation per PC date and all valid desk data,
    with one series per PC and no minimum count. Daily
    outliers have absolute z-score >= 3. Reversal candidates are
    adjacent supplied PC observations with opposite signs, both absolute
    z-scores >= 2 and magnitude ratio from 0.5 to 1.5, without a time-gap limit.
    Constant values have unavailable z-scores. This function performs no
    cumulative checks or monthly summaries and does not mutate source records.
    """
    contributions = defaultdict(list)
    for row in rows:
        key = (row["_date"], text(row["PC"]))
        contributions[key].append(row)

    daily = []
    for (event_date, pc), members in sorted(contributions.items()):
        if (event_date, pc) in review.incomplete_pnl_dates:
            continue
        amount = sum((row["_daily"] for row in members), Decimal(0))
        ytd = [number(row.get("YTD")) for row in members]
        references = [row["_ref"] for row in members]
        daily.append(
            {
                "PC": pc,
                "DTD": amount,
                "YTD": sum(ytd, Decimal(0)) if all(value is not None for value in ytd) else None,
                "source rows": len(members),
                "_date": event_date,
                "_daily": amount,
                "_ref": "; ".join(references),
                "_refs": references,
            }
        )

    groups = defaultdict(list)
    for row in daily:
        groups[row["PC"]].append(row)
    summaries, outliers, patterns = [], [], []
    for pc, series in sorted(groups.items()):
        scope = {"PC": pc}
        series.sort(key=lambda row: row["_date"])
        values = [float(row["_daily"]) for row in series]
        average, deviation = mean(values), pstdev(values)
        summaries.append(
            {
                **scope,
                "observations": len(series),
                "source rows": sum(row["source rows"] for row in series),
                "DTD sum": sum((row["_daily"] for row in series), Decimal(0)),
                "mean": average,
                "standard deviation": deviation,
                "z threshold": 3,
                "outlier screen": "checked" if deviation else "unavailable (constant values)",
            }
        )
        for row in series:
            score = (float(row["_daily"]) - average) / deviation if deviation else None
            row["_z_score"] = score
            if score is None or abs(score) < 3:
                continue
            outliers.append(
                {
                    "date": row["_date"],
                    **scope,
                    "DTD": row["_daily"],
                    "z score": score,
                    "n": len(series),
                    "mean": average,
                    "stddev": deviation,
                    "reference": row["_ref"],
                }
            )
            review.add(
                "pnl_outlier",
                row,
                "PC daily total has absolute z-score >= 3.",
                pc=row["PC"],
                DTD=row["_daily"],
                z_score=score,
            )
        for left, right in zip(series, series[1:], strict=False):
            if not deviation or left["_daily"] * right["_daily"] >= 0:
                continue
            ratio = abs(right["_daily"] / left["_daily"])
            if (
                abs(left["_z_score"]) >= 2
                and abs(right["_z_score"]) >= 2
                and Decimal(".5") <= ratio <= Decimal("1.5")
            ):
                patterns.append(
                    {
                        **scope,
                        "first date": left["_date"],
                        "second date": right["_date"],
                        "first DTD": left["_daily"],
                        "second DTD": right["_daily"],
                        "reference": left["_ref"] + "; " + right["_ref"],
                    }
                )
    review.tables["PnL series"] = summaries
    review.tables["PnL daily"] = [
        {
            "date": row["_date"],
            "PC": row["PC"],
            "DTD": row["_daily"],
            "reported YTD": row["YTD"],
            "z score": row["_z_score"],
            "source rows": row["source rows"],
            "reference": row["_ref"],
        }
        for row in daily
    ]
    review.tables["PnL outliers"] = outliers
    review.tables["PnL reversal candidates"] = patterns
    review.notes.append(
        "PnL: valid unique GOP/PTF source contributions are aggregated by date and PC "
        "before all statistical checks. Amounts are EUR and Notion is single-valued "
        "run metadata. Version names may change by date and do not split series. "
        "Observations count PC dates, not source rows. Screens use all supplied dates "
        "with no minimum observation count. Constant values have unavailable z-scores. "
        "PC dates with rejected source contributions remain unknown and are not screened. "
        "Reversals compare adjacent supplied PC observations without a time-gap limit. "
        "No PnL cumulative checks or monthly summaries are performed. Reported YTD, "
        "when complete, is summed for display only and is not reconciled."
    )
    return daily


def _attribution_baseline(known: list[dict], field: str) -> tuple[Decimal | None, Decimal | None]:
    """Return only the mean and deviation needed for the driver outlier screen.

    Use every known daily PC amount, with Decimal arithmetic and variance divided
    by the number of known dates. No series summary or trend is calculated.
    Empty inputs return unknown values; constant inputs have zero deviation.
    """
    values = [row[field] for row in known]
    if not values:
        return None, None
    average = sum(values, Decimal(0)) / len(values)
    variation = sum(((value - average) ** 2 for value in values), Decimal(0))
    return average, (variation / len(values)).sqrt()


def attribution_analysis(rows: list[dict], review: Review) -> list[dict]:
    """Aggregate daily attribution drivers and retain outliers plus daily evidence.

    Args:
        rows: Prepared unique source rows, treated as read-only. Each daily driver
            is summed across GOP/hierarchy constituents by date/PC. Final PnL,
            cumulative fields and metadata are unused.
        review: Receives daily evidence, outliers and source-bound issues. Daily
            evidence records screen availability; rejected PC dates remain in
            incomplete_attribution_dates and the runner's Desk data counts.

    Returns:
        Wide daily PC driver records for desk-data counts. Rejected constituents
        exclude the whole PC/date; a missing driver constituent leaves only that
        driver's amount unknown. Source amounts are never filled or rescaled.

    Each PC/driver's complete known daily history supplies the mean and standard
    deviation needed for the absolute z-score >= 3 screen. There is no minimum
    count; empty or constant histories have no z-score. PnL dates do not constrain
    attribution dates. No attribution series summaries, trend fits, driver
    rankings, ratios to PnL or cumulative checks are calculated or exported.
    """
    fields = review.attribution_driver_fields or attribution_drivers(rows)
    contributions = defaultdict(list)
    for row in rows:
        contributions[(row["_date"], text(row["pc"]))].append(row)
    daily = []
    for (event_date, pc), members in sorted(contributions.items()):
        if (event_date, pc) in review.incomplete_attribution_dates:
            continue
        values = {}
        for field in fields:
            amounts = [number(row.get(field)) for row in members]
            # A partial GOP sum would misstate the PC observation and its baseline.
            values[field] = (
                sum(amounts, Decimal(0)) if all(value is not None for value in amounts) else None
            )
        references = [row["_ref"] for row in members]
        daily.append(
            {
                "pc": pc,
                **values,
                "_date": event_date,
                "_ref": "; ".join(references),
                "_refs": references,
                "_source_rows": len(members),
            }
        )

    groups = defaultdict(list)
    for row in daily:
        groups[row["pc"]].append(row)
    evidence, outliers = [], []
    for pc, series in sorted(groups.items()):
        for field in fields:
            known = [row for row in series if row[field] is not None]
            average, deviation = _attribution_baseline(known, field)
            screen = (
                "checked"
                if deviation
                else "unavailable (constant values)"
                if known
                else "unavailable (no known values)"
            )
            for row in series:
                amount = row[field]
                score = (amount - average) / deviation if amount is not None and deviation else None
                observation = {
                    "date": row["_date"],
                    "pc": pc,
                    "driver": field,
                    "amount": amount,
                    "z score": score,
                    "outlier screen": screen,
                    "source rows": row["_source_rows"],
                    "reference": row["_ref"],
                }
                evidence.append(observation)
                if score is not None and abs(score) >= 3:
                    outliers.append(
                        {
                            **observation,
                            "n": len(known),
                            "mean": average,
                            "standard deviation": deviation,
                        }
                    )
                    review.add(
                        "attribution_outlier",
                        row,
                        "PC daily driver amount has absolute z-score >= 3.",
                        pc=pc,
                        driver=field,
                        amount=amount,
                        z_score=score,
                        n=len(known),
                    )
    review.tables["Attribution daily"] = evidence
    review.tables["Attribution outliers"] = outliers
    review.notes.append(
        "Attribution: each daily driver is summed across GOP/hierarchy contributions by "
        "date/PC and screened against all its known daily amounts (absolute z-score >= 3). "
        "Missing driver constituents remain unknown; rejected constituents exclude their "
        "whole PC/date, counted in Desk data. Daily evidence retains screen availability; "
        "empty or constant histories have no z-score. No series summaries or trends are "
        "calculated. Final PnL and cumulative columns are unused. Drivers are not ranked, "
        "combined into a decomposition or compared with PnL."
    )
    return daily
