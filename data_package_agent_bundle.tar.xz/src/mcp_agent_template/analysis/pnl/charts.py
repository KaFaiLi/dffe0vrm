"""Standalone daily PC PnL figures with the existing statistical outliers."""

from collections import defaultdict
from collections.abc import Iterator
from datetime import date

from matplotlib.figure import Figure

from ..charts import COLORS, Chart, date_axes, label, numeric_values, style
from .loading import number
from .models import Review


def _value(row: dict | None) -> float | None:
    value = number(row.get("DTD")) if row else None
    return float(value) if value is not None else None


def _groups(
    rows: list[dict],
) -> Iterator[tuple[tuple[str, int], list[dict]]]:
    """Group complete daily PC totals by PC and calendar year across all dates."""
    groups = defaultdict(list)
    for row in rows:
        groups[(row["PC"], row["_date"].year)].append(row)
    for identity, members in sorted(groups.items()):
        yield identity, sorted(members, key=lambda row: row["_date"])


def _coverage(year: int, dates: list[date]) -> list[str]:
    notes = [
        f"Observed {dates[0]} to {dates[-1]}. Missing supplied dates/amounts remain gaps; "
        "no holiday calendar or missing values are inferred.",
    ]
    if dates[0] > date(year, 1, 1) or dates[-1] < date(year, 12, 31):
        notes.append(
            "Partial calendar-year observation window; full-year coverage is not established."
        )
    return notes


def pnl_charts(
    pnl: list[dict],
    review: Review,
) -> Iterator[Chart]:
    """Plot daily PC totals from the same PnL source used for the desk hierarchy.

    Accept the aggregates returned by ``pnl_analysis`` and mark its existing
    outliers, matched by date and PC. Currency is run-level metadata. Screening uses
    all supplied dates; splitting charts by year never recomputes scores.
    Missing/rejected observations remain gaps and all constituent references
    are retained. These figures are saved separately from the LLM Markdown.
    """
    for (pc, year), rows in _groups(pnl):
        scope = {"PC": pc}
        dates = sorted(d for d in review.source_dates["pnl"] if d.year == year)
        by_date = {item["_date"]: item for item in rows}
        findings = [
            {"check": "pnl_outlier", **item}
            for item in review.tables.get("PnL outliers", [])
            if item["date"] in by_date and item["PC"] == pc
        ]
        title = f"PnL daily · {year} · PC {scope['PC']}"
        values = [_value(by_date.get(d)) for d in dates]
        figure = Figure()
        axis = figure.subplots()
        axis.plot(
            dates,
            numeric_values(values),
            color=COLORS[0],
            linewidth=1.4,
            marker="o",
            markersize=3,
            label="Daily PnL",
        )
        if findings:
            axis.scatter(
                [item["date"] for item in findings],
                [float(item["DTD"]) for item in findings],
                marker="D",
                s=55,
                color="#E8A317",
                edgecolors="#243746",
                linewidths=0.8,
                zorder=3,
                label="Outlier (|z| ≥ 3; all supplied dates)",
            )
            for item in findings:
                value = float(item["DTD"])
                axis.annotate(
                    f"{item['date']}\nz={item['z score']:.2f}",
                    (item["date"], value),
                    xytext=(0, 10 if value >= 0 else -10),
                    textcoords="offset points",
                    ha="center",
                    va="bottom" if value >= 0 else "top",
                    fontsize=8,
                )
            axis.margins(y=0.18)
            axis.legend(loc="best", fontsize=9)
        axis.axhline(0, color="#A8B4BE", linewidth=0.7)
        axis.set_ylabel(label(review.pnl_scope["Currency"]))
        axis.set_xlabel("Observation date")
        date_axes(figure, dates)
        style(figure, title, review.pnl_scope["Currency"])
        yield Chart(
            figure,
            "pnl_daily",
            title,
            scope,
            review.pnl_scope["Currency"],
            dates,
            [reference for item in rows for reference in item["_refs"]],
            _coverage(year, [item["_date"] for item in rows])
            + [
                "GOP/PTF contributions are aggregated to daily PC totals.",
                "Diamonds mark existing PC daily outliers (absolute z-score >= 3) "
                "across all supplied dates, not a separate annual screen.",
            ],
            findings=findings,
        )
