"""Complete PnL workbook evidence, exact amounts and literal source text."""

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

from ..excel_evidence import TEXT_PART_SIZE as TEXT_PART_SIZE
from ..excel_evidence import check_sheet_capacity
from ..excel_evidence import evidence_rows as evidence_rows
from .models import Review


def export_workbook(review: Review, path: str | Path) -> None:
    """Save all evidence tables, including distinct all-record hierarchy paths.

    The Desk hierarchy sheet retains source hierarchy levels, supplied row counts
    and the first source reference for each path. All source text is stored as
    literal cell content; oversized text uses numbered continuation rows.
    The PnL scope sheet records the run's Currency and Notion once, so daily
    amounts remain interpretable without reopening the source or Markdown.

    Args:
        review: Calculated evidence, treated as read-only. Sheet and column order
            follow the supplied tables; Decimal amounts remain exact text.
        path: Destination workbook, relative to the working directory if needed.

    Raises:
        ValueError: Evidence exceeds Excel's row or column capacity.
        OSError: The destination cannot be written.
    """
    book = Workbook()
    book.remove(book.active)
    tables = {
        "Exceptions": review.issues,
        "PnL scope": [review.pnl_scope] if review.pnl_scope else [],
        **review.tables,
        "Limitations": [{"note": n} for n in review.notes],
    }
    for title, rows in tables.items():
        rows = evidence_rows(rows)
        sheet = book.create_sheet(title[:31])
        columns = list(dict.fromkeys(k for row in rows for k in row)) or ["Result"]
        check_sheet_capacity(len(rows) + 1, len(columns), title)
        sheet.append(columns)
        for row in rows:
            sheet.append([row.get(key) for key in columns])
        if not rows:
            sheet.append(["No records"])
        # Source text must never become executable spreadsheet formulas.
        for row in sheet:
            for item in row:
                if isinstance(item.value, str) and item.value.startswith(("=", "+", "-", "@")):
                    item.data_type = "s"
        for item in sheet[1]:
            item.font = Font(bold=True, color="FFFFFF")
            item.fill = PatternFill("solid", fgColor="243746")
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for column in sheet.columns:
            letter = column[0].column_letter
            sheet.column_dimensions[letter].width = min(
                65, max(12, max(len(str(c.value or "")) for c in column) + 2)
            )
    book.save(path)
    book.close()
