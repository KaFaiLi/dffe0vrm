"""Deterministic PnL review with a single report runner."""

from .runners import run_pnl_analysis

__all__ = ["run_pnl_analysis"]
