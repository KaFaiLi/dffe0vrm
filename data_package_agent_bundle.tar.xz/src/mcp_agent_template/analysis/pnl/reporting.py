"""Markdown presentation of calculated PnL evidence."""

import json
from collections import Counter
from decimal import Decimal
from pathlib import Path

from .loading import number
from .models import Review
from .tree import generate_tree

DISPLAY_LIMIT = 12


def cell(value):
    if value is None:
        return "unknown"
    if isinstance(value, (float, Decimal)):
        decimal = Decimal(str(value))
        if decimal.is_finite() and decimal.as_tuple().exponent < -2:
            return f"{value:.2f}"
    if isinstance(value, (dict, list)):
        return json.dumps(value, default=str, ensure_ascii=False)
    return str(value)


def safe(value, *, truncate=True):
    content = cell(value)
    if truncate and len(content) > 350:
        content = content[:350] + "… [full text in workbook]"
    return (
        content.replace("|", "\\|")
        .replace("\n", " ")
        .replace("\r", " ")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def diverse_examples(rows):
    """Show distinct entity/status combinations before repeating a long backlog."""
    seen, first, rest = set(), [], []
    for row in rows:
        key = tuple(
            str(row.get(k, ""))
            for k in (
                "pc",
                "PC",
                "gop",
                "GOP",
                "state",
                "FO",
                "MPC",
                "field",
                "check",
                "adjustment_id",
            )
        )
        if key not in seen:
            first.append(row)
            seen.add(key)
        else:
            rest.append(row)
    return first + rest


def table(rows, limit=DISPLAY_LIMIT, *, diverse=False, truncate=True):
    if not rows:
        return "No records."
    if diverse:
        rows = diverse_examples(rows)
    limit = len(rows) if limit is None else limit
    columns = list(dict.fromkeys(k for row in rows for k in row))
    lines = [
        "| " + " | ".join(safe(key, truncate=False) for key in columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    lines.extend(
        "| " + " | ".join(safe(row.get(k), truncate=truncate) for k in columns) + " |"
        for row in rows[:limit]
    )
    if len(rows) > limit:
        lines.append(
            f"Showing {limit} of {len(rows)} rows; {len(rows) - limit} omitted. "
            "Workbook retains all rows."
        )
    return "\n".join(lines)


# These source-owned sections also bind metadata-free numerical rows in the
# review evidence catalog. Original commentary is outside this section contract.
SECTION_SOURCES = {
    "Desk analytical structure": "pnl",
    "PC PnL summary": "pnl",
    "PnL outliers": "pnl",
    "PnL reversal candidates": "pnl",
    "Attribution outliers": "attribution",
    "Adjustment summary": "adjustments",
    "Unusual adjustment dates": "adjustments",
    "Adjustment repeated entries": "adjustments",
    "Validation summary": "validation",
    "Devalidated summary": "validation",
}


def display_rows(rows, *, omit=()):
    """Project Markdown values without mutating exact workbook evidence.

    Generated hashes, locators and constituent row counts are workbook-only.
    Values with more than two decimal places are rounded for display, including
    source adjustment amounts loaded as strings. Integers, shorter decimals,
    identifiers and original evidence stay unchanged.
    The caller can additionally omit repeated scope or supporting statistics.
    Statistical labels use desk-data wording; their calculation is unchanged.
    """
    excluded = {"sha256", "reference", "references", "source rows", *omit}
    result = []
    for row in rows:
        item = {}
        for key, value in row.items():
            if key in excluded or key.startswith("_"):
                continue
            if key in {"AMOUNT", "AMOUNTINEUR"} and isinstance(value, str):
                parsed = number(value)
                if parsed is not None:
                    value = parsed
            item[key] = value
        result.append(item)
    return result


def markdown(review: Review, workbook: str | Path, markdown_path: str | Path) -> str:
    """Render a focused PC review, then append both original commentary files.

    All supplied dates are reviewed independently for each dataset. Markdown
    shows the full desk tree, EUR PC PnL summaries, attribution outliers and
    creation dates whose adjustment-count z-score exceeds 3. Attribution daily
    evidence remains in the workbook; series summaries and trends are not calculated.
    Adjustment summaries show counts by SOURCE and NATURE; their EUR net amounts
    remain in the workbook. Validation counts and state percentages are split
    by team and PnL type, using each group's record count as the denominator.
    Individual adjustments and raw validation records remain workbook-only.
    Validation also shows grouped DEValidated counts.
    Routine daily records, technical provenance, desk-data counts and repeated
    issue evidence stay in the workbook. Missing/constant screen availability
    remains explicit. Original commentary is appended unchanged, outside all
    display filters. The returned text is identical to the saved Markdown.

    Args:
        review: Calculated evidence, treated as read-only. Sources and Commentary
            sources are optional for in-memory reviews; the file runner adds both.
        workbook: Workbook location to display, without reading or writing it.
        markdown_path: Report location to display, without reading or writing it.

    Returns:
        Markdown text with a trailing newline; no files or settings are accessed.
    """
    lines = [
        "# PnL and Income Attribution Review",
        "Coverage: **all supplied desk data**. Date coverage: **all supplied dates**, "
        "independently for each dataset.",
        "## Scope and sources",
        "; ".join(f"{key}: {safe(value)}" for key, value in review.pnl_scope.items()) + ".",
        table(
            [
                {"dataset": s["role"], "file": Path(s["path"]).name}
                for s in review.tables.get("Sources", [])
            ],
            limit=None,
        ),
    ]
    if "Desk hierarchy" in review.tables:
        lines += [
            "## Desk analytical structure",
            "Coverage: all supplied PnL desk data. All observed paths are retained, "
            "including numerically excluded rows. Multiple parent "
            "paths may reflect changes over time; blank identifiers display as (blank).",
            "```text\n" + generate_tree(review.tables["Desk hierarchy"]) + "\n```",
        ]

    labels = {
        "pnl_outlier": "PC PnL outliers",
        "attribution_outlier": "PC attribution driver outliers",
        "adjustment_daily_concentration": "Unusual adjustment creation dates",
        "adjustment_repeated_entry": "Repeated adjustment candidates",
        "adjustment_scope": "Invalid adjustment dates or identifiers",
        "validation_devalidated": "Devalidated validation records",
        "invalid_row": "Invalid numerical source records",
        "duplicate_key": "Duplicate numerical business keys",
    }
    counts = Counter(i["check"] for i in review.issues)
    lines += [
        "## Checks requiring review",
        table(
            [
                {"screen": labels.get(k, k.replace("_", " ")), "observations": n}
                for k, n in sorted(counts.items())
            ],
            limit=None,
        )
        if counts
        else "No review candidates flagged; check screen availability below.",
        "Counts can overlap. Unusual adjustment dates are screened using CREATIONDATE only. "
        "Statistical candidates do not establish a control failure.",
    ]

    def section(
        title, rows, *, note="", empty="No candidates found.", omit=(), limit=None, truncate=True
    ):
        lines.append(f"## {title}")
        if note:
            lines.append(note)
        lines.append(
            table(display_rows(rows, omit=omit), limit=limit, truncate=truncate) if rows else empty
        )

    pnl = review.tables.get("PnL series", [])
    section(
        "PC PnL summary",
        pnl,
        note="GOP/PTF amounts are summed by date and PC within the single run-level scope. "
        "Screens use all supplied dates with no minimum observation count. "
        "Empty or constant series have no z-score.",
    )
    section(
        "PnL outliers",
        review.tables.get("PnL outliers", []),
        omit=("n", "mean", "stddev"),
        note="Absolute z-score >= 3, using all known daily PC amounts.",
        empty="No PnL outliers flagged; see PC screen availability above.",
    )
    section(
        "PnL reversal candidates",
        review.tables.get("PnL reversal candidates", []),
        note="Adjacent supplied observations with opposite signs, both "
        "absolute z-scores >= 2 and magnitude ratio 0.5 to 1.5; no time-gap limit.",
        empty="No PnL reversal candidates found.",
    )
    section(
        "Attribution outliers",
        review.tables.get("Attribution outliers", []),
        note="Daily PC driver amounts with absolute z-score >= 3. "
        "Each driver uses all its known daily amounts, without filling missing values. "
        "Screen availability remains in the daily workbook evidence; "
        "empty or constant series have no z-score.",
        empty="No attribution driver outliers found; check screen availability in the workbook.",
    )

    section(
        "Adjustment summary",
        review.tables.get("Adjustment summary", []),
        omit=("currency", "net amount"),
        note="Counts by SOURCE and NATURE. "
        "All supplied adjustments contribute to counts; AMOUNTINEUR in EUR remains "
        "in the workbook without amount-based screening.",
    )
    all_activity = review.tables.get("Adjustment daily activity", [])
    activity = sorted(
        [
            row
            for row in all_activity
            if row["record count z score"] is not None and row["record count z score"] > 3
        ],
        key=lambda row: row["record count z score"],
        reverse=True,
    )
    availability_note = (
        " Count z-scores are unavailable for empty or constant daily counts."
        if not all_activity or any(row["record count screen"] != "checked" for row in all_activity)
        else ""
    )
    section(
        "Unusual adjustment dates",
        activity,
        omit=("currency", "net amount", "gross amount", "record count screen", "review candidate"),
        note="CREATIONDATE values with adjustment-count z-score > 3 only, "
        "ranked by count z-score and filtered before display rounding. "
        "The calendar includes supplied PnL dates with zero activity "
        "and valid creation dates." + availability_note,
        empty="No unusual adjustment dates flagged.",
    )
    section(
        "Adjustment repeated entries",
        review.tables.get("Adjustment repeated entries", []),
        omit=("matching fields",),
        empty="No matching rows under different IDs found.",
    )
    validation = [
        {key: f"{value:.2f}%" if key.endswith(" %") else value for key, value in row.items()}
        for row in review.tables.get("Validation summary", [])
    ]
    section(
        "Validation summary",
        validation,
        note="All supplied history records are counted separately by team and PnL type "
        "(STAB/FLASH). Each state percentage is its count divided by that group's records, "
        "times 100. Rounded percentages may not sum to exactly 100%. Additional states are "
        "included under Other; original labels remain in workbook records. "
        "DEValidated is included in the total, not an additional count.",
    )
    section(
        "Devalidated summary",
        review.tables.get("Devalidated summary", []),
        note="DEValidated records grouped by team, GOP and PnL type.",
        empty="No DEValidated records found.",
    )

    covered = {
        "pnl_outlier",
        "attribution_outlier",
        "adjustment_daily_concentration",
        "adjustment_repeated_entry",
        "validation_devalidated",
    }
    other = [issue for issue in review.issues if issue["check"] not in covered]
    if other:
        section("Data quality observations", other)
    lines += [
        "## Interpretation notes",
        "PnL and attribution are independent reviews. Reported PnL YTD is display-only; "
        "attribution final PnL and cumulative columns are unused. Full daily tables, all "
        "adjustments and detailed validation records "
        "remain in the workbook. Review statistical candidates alongside the original "
        "commentary and corroborating evidence.",
    ]
    result = "\n\n".join(lines)
    for source in review.tables.get("Commentary sources", []):
        result += (
            f"\n\n## Original {source['family']} commentary\n\n"
            f"Source: {source['path']}\n\n"
            "The following original Markdown is source evidence for your independent review.\n\n"
            + source["markdown"]
        )
    result += f"\n\n## Saved artifacts\n\nWorkbook: {workbook}\n\nMarkdown: {markdown_path}"
    return result + "\n"
