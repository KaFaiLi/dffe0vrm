"""Adjustment checks and validation-history review."""

from collections import defaultdict
from decimal import Decimal

from .loading import day, number, text
from .models import Review

ADJUSTMENT_Z_THRESHOLD = Decimal("3")


def _count_statistics(values: list[Decimal]) -> tuple[Decimal | None, Decimal | None, str]:
    """Calculate the mean, standard deviation and z-score availability.

    Args:
        values: All observations for one screen, expressed as Decimal values in
            a common unit. Values are used as supplied, without a minimum count.

    Returns:
        The mean, standard deviation and screen status. Variance is
        the sum of squared deviations divided by the number of known observations.
        Empty input returns (None, None, "unavailable (no observations)").
        For a constant set of values, the mean is its common value, the deviation
        is zero and the status is "unavailable (constant values)" because a
        z-score would divide by zero. Otherwise the status is "checked".
        The mean and deviation retain the input unit.
    """
    if not values:
        return None, None, "unavailable (no observations)"
    average = sum(values, Decimal(0)) / len(values)
    deviation = (sum((value - average) ** 2 for value in values) / len(values)).sqrt()
    if not deviation:
        return average, deviation, "unavailable (constant values)"
    return average, deviation, "checked"


def adjustment_analysis(rows: list[dict], review: Review) -> None:
    """Review a single desk's complete adjustment data using supplied EUR amounts.

    Args:
        rows: Tidy source records with unique ADJUSTMENTIDs and complete numeric
            AMOUNTINEUR values in EUR. Repeated-entry checks compare source
            values exactly as supplied, excluding the ID, unused AMOUNT and
            internal fields whose names start with an underscore. No amount
            normalization is applied to that comparison. Decimal conversion is
            used separately for monetary arithmetic.
        review: Receives the detailed tables, issues and methodology notes.
            All adjustment records retain every supplied column in the workbook.
            Its supplied PnL dates provide zero-activity dates for daily screens;
            individual PnL or attribution records are not matched to adjustments.

    All source rows remain in the results, totals and statistical screens,
    across all dates, including repeated-entry candidates. The summary groups by
    SOURCE and NATURE, trimming whitespace but preserving case; missing or blank
    classifications share an empty label. Counts include every row, and workbook
    net amounts sum AMOUNTINEUR in EUR within each group. Daily count
    screens use z-scores strictly greater than 3,
    without a minimum count. Empty or constant values have no z-scores.
    Counts group solely by CREATIONDATE, assigning each record once. Daily
    net and gross EUR amounts remain descriptive workbook evidence and do not
    trigger flags. The count calendar combines supplied
    PnL dates and valid creation dates; valuation dates do not define daily groups
    or statistical observations. Source records are not mutated.
    """
    records, invalid_scope = [], 0
    for raw in rows:
        row = dict(raw)
        amount = number(row.get("AMOUNTINEUR"))
        if amount is None:
            raise ValueError("adjustments: AMOUNTINEUR must be present and numeric.")
        first, last = day(row.get("VALDATEBEGIN")), day(row.get("VALDATEEND"))
        row["_date"] = first
        adjustment_id = text(row.get("ADJUSTMENTID"))

        valid_interval = first is not None and last is not None and first <= last
        if not adjustment_id or not valid_interval:
            review.add(
                "adjustment_scope",
                row,
                "Missing ID or invalid valuation interval.",
                adjustment_id=adjustment_id,
            )
            invalid_scope += 1

        records.append(
            {
                "source": row,
                "amount": amount,
                "result": {
                    **{key: value for key, value in row.items() if not key.startswith("_")},
                    "reference": row.get("_ref", ""),
                },
            }
        )

    signatures = defaultdict(list)
    for record in records:
        row = record["source"]
        signature = tuple(
            (key, value)
            for key, value in sorted(row.items())
            if not key.startswith("_") and key not in {"ADJUSTMENTID", "AMOUNT"}
        )
        signatures[signature].append(row)

    repeated_entries = []
    for signature, group in signatures.items():
        adjustment_ids = sorted({text(row.get("ADJUSTMENTID")) for row in group})
        if len(adjustment_ids) < 2:
            continue
        references = "; ".join(text(row.get("_ref")) for row in group)
        repeated_entries.append(
            {
                "ADJUSTMENTIDs": "; ".join(adjustment_ids),
                "duplicate rows": len(group),
                "matching fields": dict(signature),
                "references": references,
            }
        )
        review.add(
            "adjustment_repeated_entry",
            group[0],
            "Matching adjustment rows have different adjustment IDs.",
            adjustment_ids="; ".join(adjustment_ids),
            duplicate_rows=len(group),
            references=references,
        )
    review.tables["Adjustment repeated entries"] = repeated_entries

    daily_sources = defaultdict(list)
    for record in records:
        event_date = day(record["source"].get("CREATIONDATE"))
        if event_date is not None:
            daily_sources[event_date].append(record)
    # Preserve the supplied PnL calendar as zero-activity dates, without joining rows.
    dates = sorted(set(review.source_dates.get("pnl", ())) | daily_sources.keys())
    daily_activity = []
    for event_date in dates:
        group = daily_sources.get(event_date, ())
        daily_activity.append(
            {
                "date": event_date,
                "currency": "EUR",
                "adjustment count": len(group),
                "net amount": sum((r["amount"] for r in group), Decimal(0)),
                "gross amount": sum((abs(r["amount"]) for r in group), Decimal(0)),
            }
        )
    count_mean, count_sd, count_screen = _count_statistics(
        [Decimal(item["adjustment count"]) for item in daily_activity]
    )
    for item in daily_activity:
        count_score = (
            (Decimal(item["adjustment count"]) - count_mean) / count_sd
            if count_screen == "checked"
            else None
        )
        flagged = count_score is not None and count_score > ADJUSTMENT_Z_THRESHOLD
        item.update(
            {
                "record count z score": count_score,
                "record count screen": count_screen,
                "review candidate": "record count" if flagged else "",
            }
        )
        if flagged:
            source = daily_sources[item["date"]][0]["source"]
            review.add(
                "adjustment_daily_concentration",
                {**source, "_date": item["date"]},
                "Daily creation-date adjustment count has z-score > 3.",
                adjustment_count=item["adjustment count"],
                count_z_score=count_score,
                observations=len(daily_activity),
            )
    review.tables["Adjustment daily activity"] = daily_activity

    groups = defaultdict(list)
    for record in records:
        source = record["source"]
        groups[(text(source.get("SOURCE")), text(source.get("NATURE")))].append(record)
    review.tables["Adjustment summary"] = [
        {
            "source": source,
            "nature": nature,
            "currency": "EUR",
            "count": len(group),
            "net amount": sum((record["amount"] for record in group), Decimal(0)),
        }
        for (source, nature), group in sorted(groups.items())
    ]
    review.tables["All adjustments"] = [record["result"] for record in records]
    review.notes.append(
        f"Adjustments: all {len(rows)} supplied rows retained across all dates; "
        f"{invalid_scope} have a missing ID or invalid interval. "
        "All supplied rows contribute to totals and statistical screens. "
        "The summary groups counts and EUR net amounts by SOURCE and NATURE; "
        "Markdown shows counts only. Classification labels are trimmed, case-sensitive, "
        "and blank when missing. "
        "The dataset belongs to one desk; no PnL or desk mapping is performed. All calculations "
        "use supplied AMOUNTINEUR in EUR, assumed present and numeric. AMOUNT is unused. "
        "Matching rows under different IDs are repeated-entry candidates; comparison uses "
        "source values as supplied, excluding ADJUSTMENTID, unused AMOUNT and internal fields. "
        "Candidates remain included in totals. Daily adjustment counts are screened by "
        "CREATIONDATE only with z-score > 3 and no minimum observation count. "
        "Empty or constant values have unavailable z-scores. The calendar uses supplied "
        "PnL dates plus valid creation dates. Each adjustment is assigned once. Net and gross "
        "EUR amounts are descriptive workbook evidence, without amount-based screening. "
        "Valuation dates do not define daily activity groups or daily statistical observations."
    )


VALIDATION_STATES = (
    "Not Validated",
    "Waiting Official PNL",
    "Validated",
    "DEValidated",
)


def validation_analysis(rows: list[dict], review: Review) -> None:
    """Summarize the supplied PnL validation dataset and flag devalidated records.

    State labels are used exactly as supplied. The four standard labels get
    their own summary counts and percentages within each team/PnL-type group;
    any additional labels are counted under Other, which appears only when needed.
    Percentages are 100 * state count / group record count, in percentage points.
    Team and PnL-type grouping trims whitespace and ignores case; blank and
    additional types remain separate groups. Grouped DEValidated counts support
    a summarized Markdown review. Detailed records
    remain available in the workbook and retain the original state.
    Every state other than exactly Validated counts as a record without
    validation in the workbook detail table, without a summary aggregate.
    Exactly DEValidated also produces a separate detail and issue.

    All supplied rows are counted independently, without PnL/attribution joins,
    date or active filtering, deduplication, or latest-state selection. The
    supplied records are not mutated; review receives the tables and issues.
    """
    records, exceptions, devalidated = [], [], []
    counts = defaultdict(lambda: defaultdict(int))
    devalidated_counts = defaultdict(int)
    for raw in rows:
        row = dict(raw)
        row["_date"] = day(row.get("api_request_date"), history=True) or text(
            row.get("api_request_date")
        )
        team = text(row.get("team")).upper()
        pnl_type = text(row.get("pnlType")).upper()
        state = row.get("state", "")

        record = {key: value for key, value in row.items() if not key.startswith("_")}
        record["review date"] = row["_date"]
        record["normalized team"] = team
        record["reference"] = row.get("_ref", "")
        records.append(record)
        counts[(team, pnl_type)][state if state in VALIDATION_STATES else "Other"] += 1

        if state != "Validated":
            exceptions.append(record)
        if state == "DEValidated":
            devalidated.append(record)
            devalidated_counts[(team, text(row.get("gop")), pnl_type)] += 1
            review.add(
                "validation_devalidated",
                row,
                "PnL validation record is DEValidated.",
                team=team,
                state=state,
            )

    labels = VALIDATION_STATES
    if any("Other" in states for states in counts.values()):
        labels = (*labels, "Other")
    summary = []
    for (team, pnl_type), states in sorted(counts.items()):
        total = sum(states.values())
        item = {
            "team": team,
            "pnlType": pnl_type,
            "records": total,
        }
        for label in labels:
            count = states.get(label, 0)
            item[label] = count
            item[f"{label} %"] = Decimal(100) * count / total
        summary.append(item)
    review.tables["Validation summary"] = summary
    review.tables["Devalidated records"] = devalidated
    review.tables["Devalidated summary"] = [
        {"team": team, "gop": gop, "pnlType": pnl_type, "records": count}
        for (team, gop, pnl_type), count in sorted(devalidated_counts.items())
    ]
    review.tables["Validation exceptions"] = exceptions
    review.tables["Validation records"] = records
    review.notes.append(
        f"PnL validation is a standalone review of all {len(records)} supplied records. "
        "The summary counts rows separately by team and PnL type (including STAB and FLASH) "
        "for Not Validated, Waiting Official PNL, Validated and DEValidated. Percentages are "
        "100 * state count / records within each team/PnL-type group. Team and type grouping "
        "trims whitespace and ignores case; blank and additional types are retained. "
        "Other labels are counted under Other when present, "
        "with their original values retained in record details. State comparisons use "
        "the supplied labels exactly. DEValidated records are flagged separately and "
        "already included in the summary totals. A state label does not prove missing "
        "approval. No not-labelled-Validated aggregate or separate state-count table is produced. "
        "The active flag, PnL dates and attribution statuses do not select or "
        "alter these records. No PnL/attribution matching, latest-state selection, "
        "deduplication, validation SLA or aging analysis is performed."
    )
