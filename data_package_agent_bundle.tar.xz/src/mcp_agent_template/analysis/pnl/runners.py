"""Public orchestration for the six-file PnL review."""

from pathlib import Path

from .. import charts
from .calculations import attribution_analysis, pnl_analysis
from .charts import pnl_charts
from .commentary import commentary_analysis
from .controls import adjustment_analysis, validation_analysis
from .excel import export_workbook
from .loading import load_table, prepare, source_manifest
from .models import Review
from .reporting import markdown
from .tree import hierarchy_paths


def analyze_pnl(
    pnl_rows: list[dict],
    attribution_rows: list[dict],
    adjustment_rows: list[dict],
    validation_rows: list[dict],
) -> Review:
    """Calculate the full review from canonical records without I/O or settings.

    Args:
        pnl_rows: Records with canonical PnL headers and ``_ref`` source locators,
            as returned by ``load_table``. All supplied EUR desk rows supply the
            hierarchy and single-valued Notion before invalid dates,
            amounts and duplicate date/PC/GOP/PTF keys are excluded.
        attribution_rows: Independent attribution records with canonical headers
            and ``_ref`` locators. Each daily contribution is screened for PC-level
            outliers. No attribution series summaries or trends are calculated.
            Dates and full-hierarchy duplicates
            are checked independently of PnL; rejected constituents leave PC dates unknown.
        adjustment_rows: All adjustment records, with numeric AMOUNTINEUR in EUR.
            Supplied PnL dates add zero-activity dates to creation-date screens.
        validation_rows: All validation-history records; original states and every
            supplied row contribute, without date filtering or deduplication.

    Returns:
        A fresh mutable Review containing numerical tables, issues, methodology,
        supplied-date calendars and the daily PnL chart records. Inputs are not
        mutated. File manifests and original commentary belong to the runner;
        no paths are read, clock captured, settings loaded or artifacts written.
        PnL statistics use floats; monetary sums retain Decimal precision.

    Raises:
        ValueError: PnL scope is mixed/blank, no valid unique PnL source rows
            remain, or an adjustment EUR amount is missing/invalid.
    """
    loaded = {
        "pnl": pnl_rows,
        "attribution": attribution_rows,
        "adjustments": adjustment_rows,
        "validation": validation_rows,
    }
    review = Review()
    review.tables["Desk hierarchy"] = hierarchy_paths(loaded["pnl"])
    pnl = prepare(loaded["pnl"], "pnl", review)
    attribution = prepare(loaded["attribution"], "attribution", review)
    if not pnl:
        raise ValueError("No valid PnL observations in the supplied dataset.")
    review.tables["Desk data"] = [
        {"dataset": role, "supplied rows": len(rows)} for role, rows in loaded.items()
    ]
    for item, prepared in zip(review.tables["Desk data"][:2], (pnl, attribution), strict=True):
        item["valid unique rows"] = len(prepared)
        item["excluded invalid or duplicate"] = item["supplied rows"] - len(prepared)
    review.pnl_daily = pnl_analysis(pnl, review)
    review.tables["Desk data"][0]["PC daily totals"] = len(review.pnl_daily)
    review.tables["Desk data"][0]["incomplete PC dates"] = len(review.incomplete_pnl_dates)
    attribution_pc = attribution_analysis(attribution, review)
    review.tables["Desk data"][1]["PC daily totals"] = len(attribution_pc)
    review.tables["Desk data"][1]["incomplete PC dates"] = len(review.incomplete_attribution_dates)
    adjustment_analysis(loaded["adjustments"], review)
    validation_analysis(loaded["validation"], review)
    review.notes.append(
        "Missing PnL and attribution amounts remain unknown. Blank "
        "optional adjustment references are not automatically missing approvals. "
        "All reports contain source-derived information and need the same "
        "access controls as the supplied files."
    )
    return review


def run_pnl_analysis(
    income_attribution_path: str,
    pnl_path: str,
    adjustments_path: str,
    validation_history_path: str,
    income_attribution_commentary_path: str,
    pnl_commentary_path: str,
    *,
    output_dir: str | Path | None = None,
) -> str:
    """Report the desk hierarchy, independent reviews and original commentary.

    Desk hierarchy paths use all already loaded EUR PnL desk data, including
    rows excluded from numerical checks.
    The complete tree appears in Markdown and distinct paths with source counts
    and representative row references are saved in the workbook. Markdown omits
    technical provenance columns and routine daily rows, summarizes validation
    counts and percentages by team/PnL type, and shows only adjustment creation
    dates whose count z-score is strictly greater than 3. Complete
    adjustment records and descriptive EUR amounts remain in the workbook.
    Notion must have exactly one nonblank value and Currency must be EUR across
    all supplied PnL rows, before numerical exclusions; invalid values raise
    ValueError. There is no currency conversion or splitting. These fields appear
    once in the Markdown run scope and workbook PnL scope sheet, not as grouping
    keys. Required numerical columns are Value Date (ValuationDate alias), Notion,
    GOP, PC, Currency and DTD;
    PTF is optional. Version is optional, unused source metadata: the loader
    maps versiontype to Version if present and drops an all-null Version column.
    Its values are not validated, may change by date or be blank, and are omitted
    from the run scope. PnL source uniqueness is date/PC/GOP/PTF; contributions
    aggregate to date/PC daily totals, and all PnL screens group only by PC.
    PnL and attribution independently aggregate all supplied dates to daily PC
    amounts. Neither dataset's dates restrict the other. Attribution screens every
    daily driver independently for absolute z-score >= 3, using its complete
    known daily history. Markdown shows attribution outliers; daily evidence
    and screen availability remain in Excel. Attribution series summaries and
    trends are not calculated or exported. Final PnL and
    cumulative fields are unused; there are no contribution rankings or ratios.
    Adjustments and validation
    retain their all-record rules. Both commentary files are included in
    full in the returned Markdown and saved workbook, without
    parsing, filtering, automatic findings or links to numerical issues. The
    caller's LLM reviews that source material independently. Sources stay read-only.
    Daily PC PnL PNGs use that same loaded PnL source and mark existing outliers.
    Charts group by PC/year and use the run-level Currency as the amount unit.
    Charts are standalone artifacts, with no previews or links in the Markdown.

    Args:
        income_attribution_path: Wide attribution CSV with daily driver amounts and hierarchy;
            Final Result Acc DTD is optional and unused by attribution analysis.
        pnl_path: PnL CSV or XLSX with exactly one worksheet matching the source schema.
        adjustments_path: Adjustment CSV with supplied numeric AMOUNTINEUR values in EUR.
        validation_history_path: CSV containing every validation-history record to review.
        income_attribution_commentary_path: Original attribution Markdown, included in full.
        pnl_commentary_path: Original PnL Markdown, included in full.
        output_dir: Parent of the unique artifact directory. Defaults to the configured
            ANALYSIS_RESULTS_DIR/pnl. Relative source and output paths use the working directory.

    Returns:
        The saved Markdown report, covering all supplied dates in each dataset.

    Raises:
        ValueError: An input has an unsupported format, ambiguous/missing schema,
            no source records, or no valid unique PnL observations.
        OSError: Sources cannot be read or report artifacts cannot be written.
    """
    paths = {
        "pnl": pnl_path,
        "attribution": income_attribution_path,
        "adjustments": adjustments_path,
        "validation": validation_history_path,
        "IA commentary": income_attribution_commentary_path,
        "PnL commentary": pnl_commentary_path,
    }
    loaded = {
        role: load_table(paths[role], role)
        for role in ("pnl", "attribution", "adjustments", "validation")
    }
    review = analyze_pnl(
        loaded["pnl"], loaded["attribution"], loaded["adjustments"], loaded["validation"]
    )
    # Keep the established workbook sheet order when adding file evidence.
    review.tables = {
        "Desk hierarchy": review.tables["Desk hierarchy"],
        "Sources": source_manifest(paths),
        **review.tables,
    }
    review.tables["Commentary sources"] = commentary_analysis(
        {"attribution": income_attribution_commentary_path, "pnl": pnl_commentary_path}
    )
    if output_dir is None:
        from mcp_agent_template.config import get_settings

        settings = get_settings()
        output_dir = settings.resolve_path(settings.analysis_results_dir) / "pnl"
    with charts.staged_run(output_dir) as (stage, directory):
        workbook, report_file = directory / "pnl_review.xlsx", directory / "pnl_review.md"
        export_workbook(review, stage / workbook.name)
        charts.export_charts(pnl_charts(review.pnl_daily, review), stage / "charts")
        result = markdown(review, workbook, report_file)
        (stage / report_file.name).write_text(result, encoding="utf-8")
    return result
