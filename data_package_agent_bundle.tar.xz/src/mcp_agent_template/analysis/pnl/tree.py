"""Describe the observed desk hierarchy from the complete loaded PnL desk data."""

import re

from .loading import text

COLUMNS = ("BU", "SBU", "GPC1", "GPC2", "GPC3", "PC", "GOP")


def hierarchy_paths(rows: list[dict]) -> list[dict]:
    """Collect distinct hierarchy paths without selecting numerical observations.

    Args:
        rows: The complete PnL desk data returned by ``load_table``, with a
            consistent set of headers and original ``_ref`` source locations.
            No date, amount or duplicate-key filtering applies.

    Returns:
        One record per distinct path, in first-observed source order. Available
        hierarchy columns follow ``COLUMNS``; absent optional levels are omitted.
        Header matching ignores case. Identifiers retain their case, with the
        same whitespace trimming used by the numerical PnL review. Blank values
        remain empty strings. Each path records its supplied row count and first
        source reference, including rows excluded from numerical calculations.
        Different parent paths for the same PC/GOP remain separate records;
        this describes observed membership, not a current or dated organisation.
        The input rows are not modified and no file is read.
    """
    if not rows:
        return []
    headers = {field.casefold(): field for field in rows[0]}
    levels = [field for field in COLUMNS if field.casefold() in headers]
    paths = {}
    for row in rows:
        key = tuple(text(row[headers[field.casefold()]]) for field in levels)
        if key not in paths:
            paths[key] = {
                **dict(zip(levels, key, strict=True)),
                "source rows": 0,
                "reference": row["_ref"],
            }
        paths[key]["source rows"] += 1
    return list(paths.values())


def generate_tree(paths: list[dict]) -> str:
    """Render every observed path as a directory-style tree for Markdown.

    Accept the records produced by ``hierarchy_paths``. Shared ancestors appear
    once, while equal identifiers under different parents remain distinct.
    A single top-level node has no connector. Blank identifiers display as
    ``(blank)`` and control characters are escaped so a label cannot create new
    tree or Markdown lines. Source order is retained without display limits.
    The paths and their source references remain unchanged for workbook export.
    """
    if not paths:
        return "No hierarchy paths."
    levels = [field for field in COLUMNS if field in paths[0]]
    root = {}
    for path in paths:
        branch = root
        for field in levels:
            branch = branch.setdefault(path[field], {})

    lines = []

    def render(branch: dict, prefix: str = "", depth: int = 0) -> None:
        for index, (value, children) in enumerate(branch.items()):
            last = index == len(branch) - 1
            single_root = depth == 0 and len(branch) == 1
            label = re.sub(
                r"[\x00-\x1f\x7f]",
                lambda match: f"\\u{ord(match.group()):04x}",
                value or "(blank)",
            )
            connector = "" if single_root else "└── " if last else "├── "
            lines.append(f"{prefix}{connector}{label} [{levels[depth]}]")
            if children:
                indent = "" if single_root else "    " if last else "│   "
                render(children, prefix + indent, depth + 1)

    render(root)
    return "\n".join(lines)
