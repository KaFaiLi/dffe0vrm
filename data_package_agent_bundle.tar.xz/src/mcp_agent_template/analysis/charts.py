"""Headless Matplotlib PNGs and evidence indexes for deterministic reports."""

from __future__ import annotations

import html
import json
import time
import traceback
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from shutil import rmtree
from textwrap import wrap
from threading import RLock
from uuid import uuid4

from matplotlib import dates as mdates
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.text import Text

COLORS = ("#2864A0", "#B65C18", "#277F72", "#8056A3", "#BA4563", "#697833")
GAIN, LOSS = "#277F72", "#BD3D45"
# Serialize figure generation and rendering across report threads. Use direct
# Figure objects so exports never register GUI windows or change pyplot's backend.
_RENDER_LOCK = RLock()


def label(value: object, width: int = 85) -> str:
    """Wrap source labels as literal text; render with math/TeX parsing disabled."""
    return "\n".join(wrap(str(value), width))


def numeric_values(values: Iterable[object]) -> list[float]:
    """Use NaN to leave missing source values as gaps in lines and bars."""
    return [float(value) if value is not None else float("nan") for value in values]


def markdown_text(value: object) -> str:
    return html.escape(str(value)).replace("[", "&#91;").replace("]", "&#93;").replace("\n", " ")


@dataclass
class Chart:
    """Own one standalone figure and its complete source/evidence metadata."""

    figure: Figure
    family: str
    title: str
    scope: dict[str, str]
    unit: str
    dates: list[date]
    references: list[str]
    notes: list[str] = field(default_factory=list)
    findings: list[dict] = field(default_factory=list)

    def metadata(self, filename: str) -> dict:
        """Describe an exported PNG without embedding display-preview policy."""
        return {
            "file": filename,
            "family": self.family,
            "title": self.title,
            "scope": self.scope,
            "unit": self.unit,
            "date_start": min(self.dates, default=None),
            "date_end": max(self.dates, default=None),
            "source_locators": list(dict.fromkeys(self.references)),
            "notes": self.notes,
            "findings": self.findings,
        }


def style(figure: Figure, title: str, subtitle: str, *, height: int = 620) -> None:
    heading = label(title, 95)
    subheading = label(subtitle, 120)
    title_lines = heading.count("\n") + subheading.count("\n") + 2
    figure.set_size_inches(14, (height + max(0, title_lines - 3) * 30) / 100)
    figure.set_dpi(200)
    figure.set_facecolor("white")
    figure.set_layout_engine("constrained", h_pad=0.16, w_pad=0.16, hspace=0.12)
    figure.suptitle(f"{heading}\n{subheading}", fontsize=14)
    for axis in figure.axes:
        axis.set_facecolor("white")
        axis.set_axisbelow(True)
        axis.grid(axis="y", color="#E1E7EC", linewidth=0.6)
        axis.spines[["top", "right"]].set_visible(False)
        axis.spines[["left", "bottom"]].set_color("#A8B4BE")
        axis.tick_params(labelsize=9, colors="#243746")
    literal_text(figure)


def literal_text(figure: Figure) -> None:
    """Keep source markup literal, including dollars and backslashes."""
    for text in figure.findobj(Text):
        text.set_parse_math(False)
        text.set_usetex(False)
        text.set_fontfamily("DejaVu Sans")
        text.set_color("#243746")


def date_axes(figure: Figure, dates: list[date]) -> None:
    for axis in figure.axes:
        span = (max(dates) - min(dates)).days if dates else 0
        locator = (
            mdates.DayLocator(interval=max(1, (span + 6) // 7))
            if dates and span < 14
            else mdates.AutoDateLocator(minticks=3, maxticks=7)
        )
        axis.xaxis.set_major_locator(locator)
        axis.xaxis.set_major_formatter(mdates.DateFormatter("%d %b\n%Y"))
        if dates:
            # Bound all-missing and single-observation series to their real dates.
            first, last = mdates.date2num([min(dates), max(dates)])
            padding = max(0.6, (last - first) * 0.03)
            axis.set_xlim(first - padding, last + padding)


def export_charts(charts: Iterable[Chart], directory: Path) -> list[dict]:
    """Render one figure at a time with Agg, including from active asyncio loops."""
    directory.mkdir()
    records = []
    with _RENDER_LOCK:
        for chart in charts:
            try:
                filename = f"chart-{len(records) + 1:04d}.png"
                literal_text(chart.figure)
                FigureCanvasAgg(chart.figure).print_png(directory / filename)
                records.append(chart.metadata(filename))
            except BaseException as exc:
                # A retained save error otherwise owns the Agg canvas and pixel
                # buffer through unwound renderer/Pillow frame locals. Preserve
                # the exception and stack while releasing those local references.
                traceback.clear_frames(exc.__traceback__)
                raise
            finally:
                chart.figure.clear()
                # Drop the Agg pixel buffer immediately, rather than waiting for
                # the cyclic figure/canvas references to be garbage collected.
                chart.figure.set_canvas(None)
    write_index(records, directory)
    return records


def write_index(records: list[dict], directory: Path) -> None:
    """Write a standalone index with complete chart scopes, sources and findings."""
    (directory / "manifest.json").write_text(
        json.dumps(records, default=str, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    lines = [
        "# Chart index",
        "PNG figures contain source-derived information. Apply the source access controls.",
        "[Complete chart scopes, source locators and findings](manifest.json)",
    ]
    for item in records:
        title = markdown_text(item["title"])
        lines.extend(
            [
                f"## {title}",
                f"![{title}]({item['file']})",
                "Scope: " + markdown_text(json.dumps(item["scope"], ensure_ascii=False)),
                f"Dates: {item['date_start']} to {item['date_end']}. "
                f"Unit: {markdown_text(item['unit'])}.",
                *["- " + markdown_text(note) for note in item["notes"]],
            ]
        )
        if item["findings"]:
            counts = {}
            for finding in item["findings"]:
                check = finding["check"]
                counts[check] = counts.get(check, 0) + 1
            lines.append("Findings: " + markdown_text(json.dumps(counts)))
    if not records:
        lines.append("No eligible chart series; consult source availability and data quality.")
    (directory / "index.md").write_text("\n\n".join(lines) + "\n", encoding="utf-8")


@contextmanager
def staged_run(output_dir: str | Path) -> Iterator[tuple[Path, Path]]:
    """Publish a complete run directory only after every artifact succeeds."""
    root = Path(output_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    identity = uuid4().hex
    stage, destination = root / f".{identity}.tmp", root / identity
    stage.mkdir()
    assert stage.resolve().parent == root and destination.resolve().parent == root
    try:
        yield stage, destination
        # Windows indexing/antivirus may briefly deny a directory rename after
        # all our file handles are closed. Retry only these publication errors.
        for attempt in range(4):
            try:
                stage.rename(destination)
                break
            except PermissionError as exc:
                if getattr(exc, "winerror", None) not in {5, 32, 33} or attempt == 3:
                    raise
                time.sleep(0.05 * 3**attempt)
    except BaseException:
        # Only the fresh private staging directory is ever recursively removed.
        rmtree(stage, ignore_errors=True)
        raise
