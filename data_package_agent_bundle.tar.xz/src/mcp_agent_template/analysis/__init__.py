"""Deterministic dataset analyses exposed through MCP tools."""
