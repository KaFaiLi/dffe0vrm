"""Extract display text from current ToolMessage string or content-block results.

The notebook renderer and the retained LLM adapter share this helper. Its result
shape handling is active functionality, independent of removed import aliases.
"""

from __future__ import annotations

from typing import Any


def tool_text(result: Any) -> str:
    """Extract the concatenated text payload from a tool result."""
    if isinstance(result, str):
        return result
    if isinstance(result, list):
        parts: list[str] = []
        for item in result:
            if isinstance(item, dict) and "text" in item:
                parts.append(str(item["text"]))
            elif isinstance(item, str):
                parts.append(item)
            else:
                parts.append(str(item))
        return "".join(parts)
    if isinstance(result, dict) and "text" in result:
        return str(result["text"])
    return str(result)
