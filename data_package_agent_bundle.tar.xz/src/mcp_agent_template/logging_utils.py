"""Entrypoint-owned stderr logging; library builders do not configure hosts."""

from __future__ import annotations

import copy
import logging
import sys
import traceback

from rich.console import Console
from rich.logging import RichHandler


class CredentialFilter(logging.Filter):
    """Return handler-local copies of log records with credential text redacted."""

    def filter(self, record):
        """Redact message and traceback text without mutating sibling handlers."""
        from mcp_agent_template.observability.context import ACTIVE_RUNTIME
        from mcp_agent_template.observability.privacy import Redactor

        runtime = ACTIVE_RUNTIME.get()
        if runtime is None:
            # ``OBS_MODE=off`` must not import or initialize the optional OTel
            # stack merely to sanitize an operational log line.
            otel = sys.modules.get("mcp_agent_template.observability.recording.otel")
            runtime = otel.default_runtime() if otel else None
        redactor = runtime.redactor if runtime else Redactor.for_settings(None)
        # Python 3.12+ permits a filter to replace the record for this handler;
        # copying prevents redaction from rewriting records seen by host handlers.
        record = copy.copy(record)
        record.msg = redactor.text(record.getMessage())
        record.args = ()
        if record.exc_info:
            record.msg += "\n" + redactor.text(
                "".join(traceback.format_exception(*record.exc_info))
            )
            record.exc_info = None
            record.exc_text = None
        return record


def setup_logging(
    level: str = "INFO", *, console: Console | None = None, console_level: str | None = None
) -> None:
    """Configure managed entrypoint logging without replacing host handlers."""
    root = logging.getLogger()
    if not root.handlers:
        handler = RichHandler(
            console=console or Console(stderr=True), show_path=False, rich_tracebacks=False
        )
        handler.setLevel((console_level or level).upper())
        handler.addFilter(CredentialFilter())
        root.addHandler(handler)
        root.setLevel(level.upper())
        # Managed CLI/server processes route FastMCP and HTTP diagnostics through
        # this credential filter. Existing embedding-host logging stays untouched
        # because the branch runs only when the root has no configured handlers.
        for name in ("fastmcp", "uvicorn", "uvicorn.error", "uvicorn.access"):
            logger = logging.getLogger(name)
            for previous in logger.handlers[:]:
                logger.removeHandler(previous)
            logger.propagate = True
            logger.setLevel(logging.NOTSET)


def get_logger(name: str) -> logging.Logger:
    """Return a named logger configured with the package credential filter."""
    return logging.getLogger(name)
