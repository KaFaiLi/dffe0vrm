"""Helpers to run the MCP server as a background HTTP process.

Why: MCP's *stdio* client spawns a subprocess and wires its stderr to
``sys.stderr``. Inside a Jupyter kernel ``sys.stderr`` has no real file
descriptor, so stdio can't be used from a notebook. Running the server over HTTP
sidesteps that entirely (and keeps a single long-lived server process instead of
re-spawning one per tool call). Use this from the notebook; the CLI and tests
use stdio directly.
"""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
from pathlib import Path

from mcp_agent_template.config import Settings, get_settings
from mcp_agent_template.logging_utils import get_logger

logger = get_logger(__name__)


def _port_open(host: str, port: int, timeout: float = 0.5) -> bool:
    """Probe whether a TCP listener accepts a connection within the short timeout."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        return s.connect_ex((host, port)) == 0


def wait_for_port(host: str, port: int, timeout: float = 20.0) -> bool:
    """Poll until ``host:port`` accepts connections or ``timeout`` elapses."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _port_open(host, port):
            return True
        time.sleep(0.3)
    return False


def wait_for_port_free(host: str, port: int, timeout: float = 10.0) -> bool:
    """Poll until ``host:port`` is no longer accepting connections."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _port_open(host, port):
            return True
        time.sleep(0.2)
    return False


def _terminate_process(proc: subprocess.Popen, timeout: float = 10.0) -> None:
    """Stop and reap an owned child, including after a failed startup."""
    if proc.poll() is None:
        try:
            if getattr(proc, "stdin", None) is not None:
                proc.stdin.close()
            else:
                proc.terminate()
        except ProcessLookupError:
            pass  # The child exited between poll and terminate.
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        proc.wait(timeout=timeout)
    finally:
        if getattr(proc, "stdin", None) is not None:
            proc.stdin.close()


def stop_http_server(
    proc: subprocess.Popen | None,
    settings: Settings | None = None,
) -> None:
    """Terminate a server process and wait for its port to be released.

    Safe to call with ``None`` or an already-dead process. Ensures the port is
    actually free before returning, so an immediate restart won't collide.
    """
    if proc is None:
        return
    settings = settings or get_settings()
    _terminate_process(proc)
    if not wait_for_port_free(settings.mcp_host, settings.mcp_port):
        raise RuntimeError(
            f"MCP server process stopped, but {settings.mcp_host}:{settings.mcp_port} "
            "is still in use."
        )


def spawn_http_server(
    settings: Settings | None = None,
    *,
    log_path: str | Path | None = None,
) -> subprocess.Popen:
    """Start the configured Python MCP server module over HTTP in the background.

    Returns the :class:`subprocess.Popen` handle. Call :func:`stop_http_server` when done
    (or use :func:`http_server` as a context manager). Server logs go to
    ``log_path`` (default ``<app_root>/mcp_server.log``).
    """
    settings = settings or get_settings()
    if _port_open(settings.mcp_host, settings.mcp_port):
        raise RuntimeError(
            f"{settings.mcp_host}:{settings.mcp_port} is already in use. "
            "Stop the other server or change MCP_PORT."
        )

    log_file = settings.resolve_path(log_path or "mcp_server.log")
    # Popen duplicates the descriptors into the child. The parent owns no log
    # handle after launch, including when Popen or readiness checks fail.
    with log_file.open("a", encoding="utf-8") as log_handle:
        os.chmod(log_file, 0o600)
        proc = subprocess.Popen(
            [sys.executable, "-m", settings.mcp_server_module, "--shutdown-on-stdin"],
            env=settings.mcp_server_env("http"),
            stdin=subprocess.PIPE,
            stdout=log_handle,
            stderr=log_handle,
        )
    try:
        if not wait_for_port(settings.mcp_host, settings.mcp_port) or proc.poll() is not None:
            raise RuntimeError(
                f"MCP HTTP server failed to start on {settings.mcp_http_url}. See logs: {log_file}"
            )
    except BaseException:
        _terminate_process(proc)
        raise
    logger.info("MCP HTTP server ready at %s (pid=%s)", settings.mcp_http_url, proc.pid)
    return proc


class http_server:  # noqa: N801 - context-manager style name
    """Context manager wrapping :func:`spawn_http_server`.

    Example::

        with http_server(settings) as proc:
            ...  # server is up
    """

    def __init__(self, settings: Settings | None = None, **kwargs) -> None:
        """Store HTTP server settings without spawning a subprocess."""
        self.settings = settings or get_settings()
        self.kwargs = kwargs
        self.proc: subprocess.Popen | None = None

    def __enter__(self) -> subprocess.Popen:
        """Enter the managed lifecycle and return the active resource."""
        self.proc = spawn_http_server(self.settings, **self.kwargs)
        return self.proc

    def __exit__(self, *exc) -> None:
        """Finish the managed lifecycle while preserving any caller exception."""
        try:
            stop_http_server(self.proc, self.settings)
        finally:
            self.proc = None
