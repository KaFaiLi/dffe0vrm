"""Build stable, redaction-safe model, tool, and response descriptors for recording."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, is_dataclass
from typing import TypeVar, get_args, get_origin

from httpx2 import Timeout
from langchain.agents.structured_output import AutoStrategy, ProviderStrategy, ToolStrategy
from pydantic import BaseModel, SecretBytes, SecretStr
from pydantic.fields import FieldInfo


def qualified_name(value) -> str:
    """Return the most specific import-qualified name available for a value."""
    return (
        getattr(value, "__module__", type(value).__module__)
        + "."
        + getattr(value, "__qualname__", type(value).__qualname__)
    )


def describe(value):
    """Deterministic public configuration; opaque bodies require a declared revision."""
    if value is None or isinstance(value, (str, int, bool, float)):
        return value
    if get_origin(value) is not None or isinstance(value, TypeVar):
        return annotation_descriptor(value)
    if isinstance(value, FieldInfo):
        return {"type": qualified_name(type(value)), "config": describe(value.asdict())}
    if isinstance(value, (SecretStr, SecretBytes)):
        return "[REDACTED]"
    if isinstance(value, BaseModel):
        return {
            "type": qualified_name(type(value)),
            "config": describe(value.model_dump(mode="python")),
        }
    if isinstance(value, Timeout):
        return describe(value.as_dict())
    if isinstance(value, dict):
        return {
            str(k): describe(v) for k, v in sorted(value.items(), key=lambda item: str(item[0]))
        }
    if isinstance(value, (tuple, list)):
        return [describe(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted((describe(v) for v in value), key=str)
    if isinstance(value, type) or callable(value):
        return {"callable": qualified_name(value)}
    if is_dataclass(value):
        return describe(asdict(value))
    return {"type": qualified_name(type(value))}


def annotation_descriptor(value):
    """Describe native reducers and typing metadata without process addresses."""
    origin = get_origin(value)
    if origin is not None:
        return {
            "origin": qualified_name(origin),
            "arguments": [annotation_descriptor(argument) for argument in get_args(value)],
        }
    if isinstance(value, TypeVar):
        return {
            "type_variable": value.__name__,
            "constraints": [annotation_descriptor(item) for item in value.__constraints__],
            "bound": annotation_descriptor(value.__bound__),
            "covariant": value.__covariant__,
            "contravariant": value.__contravariant__,
        }
    return describe(value)


def response_descriptor(value):
    """One output contract for composition, durable compatibility, and recording."""
    if value is None:
        return None
    explicit = isinstance(value, (AutoStrategy, ProviderStrategy, ToolStrategy))
    schema = value.schema if explicit else value
    options = {}
    if isinstance(value, ProviderStrategy):
        options = {"strict": value.schema_spec.strict}
    elif isinstance(value, ToolStrategy):
        options = {
            "tool_message_content": value.tool_message_content,
            "handle_errors": describe(value.handle_errors),
        }
    return {
        "strategy": type(value).__name__ if explicit else "AutoStrategy",
        "options": options,
        "schemas": [spec.json_schema for spec in ToolStrategy(schema).schema_specs],
    }


def model_descriptor(model):
    # Describe execution options, never clients, credentials, counters, or caches.
    """Build the redaction-safe model descriptor stored with an agent definition."""
    names = (
        "model_name",
        "model",
        "temperature",
        "max_tokens",
        "max_completion_tokens",
        "top_p",
        "top_k",
        "frequency_penalty",
        "presence_penalty",
        "seed",
        "stop",
        "timeout",
        "request_timeout",
        "max_retries",
        "model_kwargs",
        "reasoning_effort",
        "reasoning",
        "streaming",
        "disable_streaming",
        "profile",
        "extra_body",
        "default_query",
        "disabled_params",
        "use_responses_api",
        "base_url",
        "openai_api_base",
        "api_base",
    )
    return {
        "class": qualified_name(type(model)),
        "name": getattr(model, "model_name", getattr(model, "model", None)),
        **{key: describe(getattr(model, key)) for key in names if hasattr(model, key)},
    }


def tool_descriptor(tool):
    """Canonical public tool contract, shared with observation snapshots."""
    if isinstance(tool, dict):
        return deepcopy(tool)
    schema = tool.tool_call_schema
    return {
        "name": tool.name,
        "description": tool.description,
        "schema": deepcopy(schema) if isinstance(schema, dict) else schema.model_json_schema(),
        "metadata": tool.metadata,
        "extras": getattr(tool, "extras", None),
        **{
            name: describe(getattr(tool, name))
            for name in (
                "return_direct",
                "response_format",
                "handle_tool_error",
                "handle_validation_error",
            )
        },
    }
