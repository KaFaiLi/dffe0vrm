"""Build a LangGraph ReAct agent wired to the MCP server + skills + LLM.

The star of the show is :func:`build_agent`, an async factory that:

1. connects to the FastMCP server (stdio subprocess by default) and loads its
    tools via LangChain's built-in ``MCPAdapter``;
2. discovers skills from the skills folder and exposes them as tools;
3. builds a chat model from the GenAI manager;
4. assembles a ``create_agent`` graph with a skills-aware system prompt.

It's async because loading MCP tools requires a live client session.
"""

from __future__ import annotations

import sys
from typing import Any

import httpx2
from fastmcp import Client
from fastmcp.client.transports import StdioTransport, StreamableHttpTransport
from langchain.agents.middleware import AgentMiddleware
from langchain.mcp import MCPAdapter
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools import BaseTool

from mcp_agent_template.agent.bundle import AgentBundle
from mcp_agent_template.agent.composition import tool_descriptor
from mcp_agent_template.agent.factory import _prepare_node
from mcp_agent_template.config import Settings, get_settings
from mcp_agent_template.logging_utils import get_logger
from mcp_agent_template.observability.capture.build import observe_build
from mcp_agent_template.observability.context import ACTIVE_RUNTIME, emit
from mcp_agent_template.observability.recording.runtime import ObservabilityRuntime
from mcp_agent_template.skills.loader import agent_skills_path, discover_skills

logger = get_logger(__name__)


class _ToolCallMiddleware(AgentMiddleware):
    """Run a tool-call wrapper through the current agent middleware API."""

    def __init__(self, async_wrapper: Any, sync_wrapper: Any = None, *, name: str):
        """Store synchronous/asynchronous delegates and a unique middleware name."""
        self._async_wrapper = async_wrapper
        self._sync_wrapper = sync_wrapper or async_wrapper
        self._name = name

    @property
    def name(self) -> str:
        """Return the stable name used for middleware collision validation."""
        return self._name

    def wrap_tool_call(self, request: Any, handler: Any) -> Any:
        """Apply this policy around a synchronous tool call."""
        return self._sync_wrapper(request, handler)

    async def awrap_tool_call(self, request: Any, handler: Any) -> Any:
        """Apply this policy around an asynchronous tool call."""
        return await self._async_wrapper(request, handler)


def tool_call_middleware(async_wrapper: Any, *, name: str) -> AgentMiddleware:
    """Adapt an async tool-call wrapper to create_agent middleware."""
    return _ToolCallMiddleware(async_wrapper, name=name)


def build_mcp_client(settings: Settings | None = None) -> MCPAdapter:
    """Create a LangChain MCP adapter configured for our FastMCP server.

    - ``stdio`` (default): spawns ``python -m mcp_agent_template.mcp_server`` as a
      subprocess. No separate server process to manage -- ideal for a template.
    - ``http``: connects to an already-running server at ``MCP_HTTP_URL``.
    """
    settings = settings or get_settings()
    transport = settings.mcp_transport.lower().strip()

    if transport == "stdio":
        # Force the child to stdio regardless of the parent's .env. Inheriting
        # the remaining environment keeps the installed package and corporate
        # authentication visible to the subprocess.
        child_env = settings.mcp_server_env("stdio")
        active = ACTIVE_RUNTIME.get()
        if active is not None:
            child_env["OBS_MODE"] = "local" if active.enabled else "off"
            child_env["OBS_DIR"] = str(active.path.parent)
        # ``keep_alive=False`` gives the adapter ownership of ordinary transport
        # sessions instead of leaving a background MCP process behind.
        target: Any = StdioTransport(
            sys.executable,
            ["-m", settings.mcp_server_module],
            env=child_env,
            keep_alive=False,
        )
    elif transport == "http":

        def httpx_client_factory(**kwargs: Any) -> httpx2.AsyncClient:
            """Create the HTTPX2 client required by the MCP streamable-HTTP transport."""
            kwargs["timeout"] = httpx2.Timeout(
                settings.mcp_tool_timeout,
                read=settings.mcp_read_timeout,
            )
            return httpx2.AsyncClient(**kwargs)

        target = StreamableHttpTransport(
            settings.mcp_http_url,
            httpx_client_factory=httpx_client_factory,
        )
    else:
        raise ValueError(f"Unsupported MCP_TRANSPORT={transport!r}. Use 'stdio' or 'http'.")

    # The native adapter preserves MCP content blocks and represents server tool
    # failures as ``ToolMessage(status="error")`` for agent-level recovery.
    return MCPAdapter(Client(target, timeout=settings.mcp_read_timeout))


@observe_build
async def build_agent(
    settings: Settings | None = None,
    *,
    model: BaseChatModel | None = None,
    extra_tools: list[BaseTool] | None = None,
    mcp_tools: list[BaseTool] | None = None,
    middleware: tuple[AgentMiddleware, ...] = (),
    observability: ObservabilityRuntime | None = None,
) -> AgentBundle:
    """Build the ReAct agent and return an :class:`AgentBundle`.

    Args:
        settings: Override settings (defaults to :func:`get_settings`).
        model: Provide a pre-built chat model (skips the GenAI manager).
        extra_tools: Additional LangChain tools to expose to the agent.
    """
    settings = settings or get_settings()

    # 1. MCP tools.
    mcp_client = build_mcp_client(settings) if mcp_tools is None else None
    logger.info("Loading MCP tools (transport=%s)...", settings.mcp_transport)
    mcp_tools = await mcp_client.list_tools() if mcp_tools is None else list(mcp_tools)
    emit("catalog.discovered", {"kind": "mcp", "tools": [tool_descriptor(t) for t in mcp_tools]})
    logger.info("Loaded %d MCP tool(s): %s", len(mcp_tools), [t.name for t in mcp_tools])

    return _prepare_node(
        settings,
        mcp_client=mcp_client,
        mcp_tools=mcp_tools,
        skills=discover_skills(agent_skills_path(settings)),
        model=model,
        extra_tools=list(extra_tools or []),
        middleware=middleware,
        observability=observability,
    )
