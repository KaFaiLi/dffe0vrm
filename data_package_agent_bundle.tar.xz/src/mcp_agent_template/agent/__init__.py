"""The LangGraph ReAct agent that ties MCP tools + skills + LLM together."""

from mcp_agent_template.agent.multi_agent import AgentSpec, build_agent_tree
from mcp_agent_template.agent.react_agent import (
    AgentBundle,
    build_agent,
    build_mcp_client,
)
from mcp_agent_template.agent.runtime.context import RunContext
from mcp_agent_template.config import ContextCompactionSettings

__all__ = [
    "AgentBundle",
    "build_agent",
    "build_mcp_client",
    "AgentSpec",
    "build_agent_tree",
    "RunContext",
    "ContextCompactionSettings",
]
