"""Shared native middleware composition for single agents and tree nodes."""

from __future__ import annotations

import hashlib
from collections import Counter
from typing import Any

from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware
from langchain_core.tools import BaseTool

from mcp_agent_template.agent.bundle import AgentBundle
from mcp_agent_template.agent.composition import model_descriptor, tool_descriptor
from mcp_agent_template.agent.prompts import build_system_prompt
from mcp_agent_template.agent.runtime.context import RunContext
from mcp_agent_template.agent.runtime.context_policy import ContextCompactionMiddleware
from mcp_agent_template.agent.runtime.middleware import (
    RuntimePolicyMiddleware,
    ToolRoundPolicyMiddleware,
)
from mcp_agent_template.agent.runtime.todos import AgentTodoMiddleware
from mcp_agent_template.config import Settings
from mcp_agent_template.llm.genai_manager import get_chat_model
from mcp_agent_template.observability.capture.middleware import (
    EffectiveRequestMiddleware,
    ObservationMiddleware,
)
from mcp_agent_template.observability.context import emit
from mcp_agent_template.observability.privacy import Redactor
from mcp_agent_template.skills.loader import Skill
from mcp_agent_template.skills.tools import build_skill_tools, render_skills_overview

# Reserve only middleware installed by the current graph composition.
REQUIRED_NAMES = frozenset(
    kind.__name__
    for kind in (
        ObservationMiddleware,
        ToolRoundPolicyMiddleware,
        ContextCompactionMiddleware,
        AgentTodoMiddleware,
        RuntimePolicyMiddleware,
        EffectiveRequestMiddleware,
    )
)


def validate_tools(tools: list[BaseTool], *, agent_name: str | None = None) -> None:
    """Reject duplicate tool names before graph construction makes dispatch ambiguous."""
    duplicates = sorted(name for name, count in Counter(t.name for t in tools).items() if count > 1)
    if duplicates:
        prefix = "Colliding" if agent_name is None else f"Agent {agent_name!r} has colliding"
        raise ValueError(f"{prefix} tool names: {duplicates}. Tool names must be unique.")


def build_graph(
    *,
    model: Any,
    tools: list[BaseTool],
    system_prompt: str,
    settings: Settings,
    max_iterations: int,
    child_names: set[str] | None = None,
    middleware: tuple[AgentMiddleware, ...] = (),
    name: str | None = None,
    skills: list[Skill] | None = None,
) -> tuple[Any, str, str, int, list[BaseTool]]:
    """Build one native graph and return its reproducible execution metadata.

    Application middleware is inserted between the package's observation/round
    layers and combined runtime policy. Middleware-provided tools participate
    in the same collision check as MCP, skill, child, and application tools.
    The definition includes only this node's selected skill inventory; full
    skill bodies remain on-demand tool results, not model input at construction.
    """
    names = [item.name for item in middleware]
    if len(set(names)) != len(names) or REQUIRED_NAMES.intersection(names):
        raise ValueError("Application middleware names must be unique and not reserved.")
    stack = [
        ObservationMiddleware(),
        ToolRoundPolicyMiddleware(max_iterations),
        AgentTodoMiddleware(),
        *middleware,
        *(
            [ContextCompactionMiddleware(settings.context_compaction)]
            if settings.context_compaction.input_token_budget is not None
            else []
        ),
        # Keep runtime hooks after request transformations and before final
        # capture; one registration now owns the former lifecycle/tool layers.
        RuntimePolicyMiddleware(child_names=child_names or set()),
        EffectiveRequestMiddleware(),
    ]
    extension_tools = [tool for item in stack for tool in getattr(item, "tools", ())]
    validate_tools([*tools, *extension_tools], agent_name=name)
    definition = {
        "name": "agent" if name is None else name,
        "system_prompt": system_prompt,
        "model": model_descriptor(model),
        "tools": [tool_descriptor(t) for t in [*tools, *extension_tools]],
        "skills": [
            {"name": s.name, "description": s.description, "path": str(s.path), "files": s.files}
            for s in skills or []
        ],
        "middleware": [item.name for item in stack],
        "max_iterations": max_iterations,
        "parallel_tools": True,
        "context_compaction": settings.context_compaction.model_dump(),
    }
    encoded = Redactor.for_settings(settings).encode(definition)
    fingerprint = hashlib.sha256(encoded.encode()).hexdigest()
    emit("capture.agent_definition", {**definition, "fingerprint": fingerprint})
    graph = create_agent(
        model,
        tools,
        name="agent" if name is None else name,
        system_prompt=system_prompt,
        middleware=stack,
        context_schema=RunContext,
    )
    # Middleware hooks add LangGraph steps that do not correspond one-for-one to
    # user-visible tool rounds. Keep the graph ceiling comfortably above valid
    # executions; ``ToolRoundPolicyMiddleware`` enforces the exact round limit.
    recursion_limit = max_iterations * (len(stack) * 2 + 3) + len(stack) * 2 + 10
    return graph, encoded, fingerprint, recursion_limit, extension_tools


def _prepare_node(
    settings: Settings,
    *,
    mcp_client: Any,
    mcp_tools: list[BaseTool],
    skills: list[Skill],
    model: Any = None,
    model_name: str | None = None,
    temperature: float | None = None,
    extra_tools: list[BaseTool] | None = None,
    sub_agent_tools: list[BaseTool] | None = None,
    system_prompt_extra: str | None = None,
    max_iterations: int | None = None,
    middleware: tuple[AgentMiddleware, ...] = (),
    name: str | None = None,
    observability: Any = None,
) -> AgentBundle:
    """Prepare one node after discovery and selection for both public builders.

    The helper owns model creation, prompt composition, middleware assembly, and
    the immutable build receipt.  Callers remain responsible for discovering or
    selecting MCP tools, skills, and child-agent tools.
    """
    skill_tools = build_skill_tools(skills)
    extra_tools = list(extra_tools or [])
    sub_agent_tools = list(sub_agent_tools or [])
    tools = [*mcp_tools, *skill_tools, *extra_tools, *sub_agent_tools]
    if model is None:
        model = get_chat_model(model=model_name, temperature=temperature, settings=settings)
    system_prompt = build_system_prompt(render_skills_overview(skills))
    if system_prompt_extra:
        system_prompt = f"{system_prompt}\n{system_prompt_extra}\n"
    iterations = max_iterations or settings.agent_max_iterations
    agent, definition, fingerprint, recursion_limit, middleware_tools = build_graph(
        model=model,
        tools=tools,
        system_prompt=system_prompt,
        settings=settings,
        max_iterations=iterations,
        child_names={t.name for t in sub_agent_tools},
        middleware=middleware,
        name=name,
        skills=skills,
    )
    return AgentBundle(
        agent=agent,
        model=model,
        mcp_client=mcp_client,
        mcp_tools=list(mcp_tools),
        skill_tools=skill_tools,
        sub_agent_tools=sub_agent_tools,
        skills=list(skills),
        system_prompt=system_prompt,
        max_iterations=iterations,
        extra_tools=extra_tools,
        middleware_tools=middleware_tools,
        settings=settings.model_copy(deep=True),
        name="agent" if name is None else name,
        observability=observability,
        definition_json=definition,
        build_fingerprint=fingerprint,
        recursion_limit=recursion_limit,
    )
