"""A tiny CLI to chat with the agent from a terminal.

    mcp-agent-chat "what tools do you have? add 2 and 3"
    mcp-agent-chat            # interactive REPL

Requires a real LLM provider (set GENAI_PROVIDER in .env); the 'fake' provider
will connect and load tools but won't actually reason about them.
"""

from __future__ import annotations

import asyncio
import sys

from mcp_agent_template.agent.react_agent import build_agent
from mcp_agent_template.config import get_settings
from mcp_agent_template.logging_utils import setup_logging
from mcp_agent_template.observability import ObservabilityRuntime


async def _run_once(message: str) -> None:
    """Build one observed agent, submit a message, and print its final text."""
    settings = get_settings()
    async with ObservabilityRuntime.local(settings, process_default=True) as recording:
        bundle = await build_agent(settings, observability=recording)
        answer = await bundle.ask(message)
        print(answer)


async def _repl() -> None:
    """Keep one observed agent open for an interactive terminal session."""
    settings = get_settings()
    async with ObservabilityRuntime.local(settings, process_default=True) as recording:
        bundle = await build_agent(settings, observability=recording)
        print(
            f"Connected. {len(bundle.mcp_tools)} MCP tool(s), "
            f"{len(bundle.skills)} skill(s). Type 'exit' to quit.\n"
        )
        while True:
            try:
                msg = input("you> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if msg.lower() in {"exit", "quit"}:
                break
            if not msg:
                continue
            answer = await bundle.ask(msg)
            print(f"agent> {answer}\n")


def main() -> None:
    """Run the command-line entry point and translate expected failures for shell users."""
    setup_logging(get_settings().log_level)
    args = sys.argv[1:]
    if args:
        asyncio.run(_run_once(" ".join(args)))
    else:
        asyncio.run(_repl())


if __name__ == "__main__":
    main()
