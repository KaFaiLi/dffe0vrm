"""High-level ownership wrapper for compiled agent graphs and their resources.

``AgentBundle`` keeps the native graph accessible while providing safe
convenience methods that allocate a fresh run context, establish observation
scope, apply the compiled recursion limit, and close streaming resources.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import aclosing, asynccontextmanager
from dataclasses import dataclass, field
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools import BaseTool

from mcp_agent_template.agent.runtime.context import RunContext
from mcp_agent_template.agent.runtime.invocation import InvocationScope
from mcp_agent_template.config import Settings, get_settings
from mcp_agent_template.observability.context import ACTIVE_RUNTIME, ACTIVE_SCOPE
from mcp_agent_template.observability.recording.runtime import ObservabilityRuntime
from mcp_agent_template.skills.loader import Skill


@dataclass
class AgentBundle:
    """Each convenience call owns fresh context and a flushed recording scope.

    Supply an opened ObservabilityRuntime to share one recorder across calls.
    Otherwise calls own a recorder automatically according to Settings.obs.
    Raw native graphs require context=bundle.new_context(); use bundle.astream
    to capture streaming execution and close it explicitly when stopping early.
    """

    agent: Any
    model: BaseChatModel | None
    mcp_client: Any = None
    mcp_tools: list[BaseTool] = field(default_factory=list)
    skill_tools: list[BaseTool] = field(default_factory=list)
    sub_agent_tools: list[BaseTool] = field(default_factory=list)
    extra_tools: list[BaseTool] = field(default_factory=list)
    middleware_tools: list[BaseTool] = field(default_factory=list)
    skills: list[Skill] = field(default_factory=list)
    system_prompt: str = ""
    max_iterations: int = 10
    settings: Settings = field(default_factory=get_settings)
    name: str = "agent"
    observability: ObservabilityRuntime | None = None
    definition_json: str | None = None
    build_fingerprint: str | None = None
    recursion_limit: int | None = None

    @property
    def all_tools(self) -> list[BaseTool]:
        """Return every base, skill, sub-agent, extension, and application tool in call order."""
        return [
            *self.mcp_tools,
            *self.skill_tools,
            *self.extra_tools,
            *self.sub_agent_tools,
            *self.middleware_tools,
        ]

    def new_context(self) -> RunContext:
        """Create an independent invocation context from this bundle's frozen settings."""
        return RunContext.from_settings(self.settings)

    def _run_config(self, extra: dict | None = None) -> dict:
        """Merge caller graph configuration with the bundle's recursion limit."""
        return {
            "recursion_limit": self.recursion_limit or self.max_iterations * 3 + 2,
            **(extra or {}),
        }

    @asynccontextmanager
    async def _recording(self) -> AsyncIterator[ObservabilityRuntime | None]:
        """Yield the supplied, active, or call-owned observability runtime.

        A caller-supplied runtime must already be open because its ownership
        remains with the caller.  In the absence of one, each convenience call
        owns and closes a local runtime according to the frozen settings.
        """
        if self.observability is not None:
            if self.observability.started is None or self.observability.closed:
                raise ValueError(
                    "Open the supplied ObservabilityRuntime before invoking the bundle."
                )
            yield self.observability if self.observability.enabled else None
        elif active := ACTIVE_RUNTIME.get():
            yield active
        else:
            async with ObservabilityRuntime.local(self.settings) as runtime:
                yield runtime if runtime.enabled else None

    def observe_invocation(self, *, runtime=None, context=None, config=None) -> InvocationScope:
        """Create an observation scope bound to this bundle and optional runtime context."""
        context = context or self.new_context()
        context.claim()
        # Parent attribution is valid only inside the same budget tree. An
        # unrelated active scope may be task-local but must not become this run's
        # logical parent.
        parent = ACTIVE_SCOPE.get()
        if parent is not None and (
            parent.context is None or parent.context.budget is not context.budget
        ):
            parent = None
        scope = InvocationScope(runtime, self.name, context, self._run_config(config), parent)
        scope.build_fingerprint = self.build_fingerprint
        scope.definition_json = self.definition_json
        return scope

    async def ainvoke(self, message: str | dict, **kwargs: Any) -> dict:
        """Invoke the graph once and return its native result mapping."""
        inputs = (
            {"messages": [{"role": "user", "content": message}]}
            if (isinstance(message, str))
            else message
        )
        async with self._recording() as runtime:
            scope = self.observe_invocation(
                runtime=runtime,
                context=kwargs.pop("context", None),
                config=kwargs.pop("config", None),
            )
            return await scope.ainvoke(self.agent, inputs, **kwargs)

    async def astream(self, message: str | dict, **kwargs: Any) -> AsyncIterator[Any]:
        """Stream native graph updates while keeping the invocation observation scope open."""
        inputs = (
            {"messages": [{"role": "user", "content": message}]}
            if (isinstance(message, str))
            else message
        )
        async with self._recording() as runtime:
            scope = self.observe_invocation(
                runtime=runtime,
                context=kwargs.pop("context", None),
                config=kwargs.pop("config", None),
            )
            async with aclosing(scope.astream(self.agent, inputs, **kwargs)) as stream:
                async for event in stream:
                    yield event

    async def ask(self, message: str, **kwargs: Any) -> str:
        """Run one text request and return the final assistant text."""
        result = await self.ainvoke(message, **kwargs)
        return result["messages"][-1].text if result.get("messages") else ""
