"""Compose parent/sub-agent trees: ReAct agents that call other ReAct agents.

A sub-agent is a fully-formed :class:`~mcp_agent_template.agent.react_agent.AgentBundle`
(its own MCP tools + skills + model) wrapped as an ``ask_<name>`` tool on its
parent.

Parallel tool calling is always enabled throughout the tree. A parent's
``concurrency`` setting applies only to its own sub-agent calls:

- ``"parallel"`` (default) -- native LangGraph parallel execution.
- ``"sequential"``         -- one child at a time.
- an ``int``                 -- at most that many running at once.
- a callable                 -- your own ``(request, execute) -> result`` hook,
  full control (retries, custom ordering, cancellation, ...).

This builds entirely on public LangChain agent middleware extension points, so
no internals are patched. Everything else (MCP tools, skills, model, prompt)
is assembled from the exact same building blocks as :func:`build_agent`, so a
single :class:`AgentSpec` with no ``sub_agents`` behaves identically to today's
single-agent path.

Quick start::

    reviewer = AgentSpec(
        name="reviewer",
        description="Reviews post-trade control cases.",
        tool_names=["run_post_trade_review"],
        skill_names=["post-trade-control"],
    )
    orchestrator = AgentSpec(
        name="orchestrator",
        description="Top-level assistant that delegates to specialists.",
        sub_agents=[reviewer],
        concurrency="parallel",
    )
    bundle = await build_agent_tree(orchestrator)
    answer = await bundle.ask("Review the post-trade cases in /data/post-trade.")
"""

from __future__ import annotations

import asyncio
import time
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Annotated, Any, Literal

from langchain.agents.middleware import AgentMiddleware
from langchain.agents.middleware.todo import Todo
from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import BaseTool, StructuredTool, ToolException
from langgraph.prebuilt.tool_node import AsyncToolCallWrapper
from pydantic import BaseModel, Field

from mcp_agent_template.agent.factory import _prepare_node
from mcp_agent_template.agent.react_agent import (
    AgentBundle,
    build_mcp_client,
    tool_call_middleware,
)
from mcp_agent_template.agent.runtime.middleware import ChildConcurrencyMiddleware
from mcp_agent_template.config import ContextCompactionSettings, Settings, get_settings
from mcp_agent_template.logging_utils import get_logger
from mcp_agent_template.observability.capture.build import observe_build
from mcp_agent_template.observability.context import ACTIVE_SCOPE
from mcp_agent_template.observability.recording.runtime import ObservabilityRuntime
from mcp_agent_template.skills.loader import Skill, agent_skills_path, discover_skills

logger = get_logger(__name__)

ConcurrencyMode = Literal["sequential", "parallel"] | int | AsyncToolCallWrapper


@dataclass
class AgentSpec:
    """Declarative description of one agent (leaf or parent) in a tree.

    Only ``name`` and ``description`` are required. Everything else has a
    default that reproduces today's single-agent behavior: no sub-agents,
    all discovered MCP tools, all discovered skills.
    """

    name: str
    description: str
    sub_agents: list[AgentSpec] = field(default_factory=list)
    concurrency: ConcurrencyMode = "parallel"
    tool_names: list[str] | None = None
    skill_names: list[str] | None = None
    skills_dir: str | Path | None = None
    extra_tools: list[BaseTool] = field(default_factory=list)
    model: Any | None = None  # pre-built BaseChatModel, overrides model_name/temperature
    model_name: str | None = None
    temperature: float | None = None
    max_iterations: int | None = None
    system_prompt_extra: str | None = None
    call_timeout: float | None = None
    context_compaction: ContextCompactionSettings | None = None


def _validate_tree(root: AgentSpec) -> None:
    """Catch duplicate names, cycles, and sub-agent tool collisions up front.

    Runs before any MCP connection or skill discovery, so bad wiring fails
    fast with a clear message instead of hanging or half-building a tree.
    """
    seen: dict[str, AgentSpec] = {}

    def walk(spec: AgentSpec, ancestors: tuple[str, ...]) -> None:
        """Validate one specification and recursively inspect its descendants."""
        if spec.name in ancestors:
            path = " -> ".join((*ancestors, spec.name))
            raise ValueError(f"Cycle detected in agent tree: {path!r}.")
        if spec.name in seen and seen[spec.name] is not spec:
            raise ValueError(
                f"Duplicate agent name {spec.name!r} used for two different "
                "AgentSpec instances. Agent names must be unique across the tree."
            )
        seen[spec.name] = spec

        child_tool_names = [f"ask_{c.name}" for c in spec.sub_agents]
        dupes = sorted(n for n, count in Counter(child_tool_names).items() if count > 1)
        if dupes:
            raise ValueError(
                f"Agent {spec.name!r} has sub-agents producing duplicate tool names: {dupes}."
            )
        for child in spec.sub_agents:
            walk(child, (*ancestors, spec.name))

    walk(root, ())


class _AskSubAgentInput(BaseModel):
    """Validate the delegated task supplied to a generated ``ask_<name>`` tool."""

    task: Annotated[str, Field(description="The task or question to delegate to this sub-agent.")]


def make_agent_tool(
    spec: AgentSpec,
    bundle: AgentBundle,
    *,
    default_timeout: float,
) -> BaseTool:
    """Wrap a sub-agent's :class:`AgentBundle` as a tool its parent can call.

    Each call is a fresh, isolated invocation of the sub-agent (no shared
    memory across calls) -- simple, bounded in cost, and easy to reason
    about. Failures and timeouts are normalized to :class:`ToolException` so
    a broken sub-agent surfaces as an error message the parent LLM can react
    to, instead of crashing the whole run.

    The tool returns ``(content, artifact)`` (``response_format=
    "content_and_artifact"``): ``content`` is the sub-agent's final answer
    (what the parent LLM sees and reasons over), and ``artifact`` is
    ``{"agent": <name>, "messages": [...], "todos": [...]}`` -- the sub-agent's
    full message trace and final independent checklist. The artifact is
    invisible to the LLM but lets notebook tooling
    (:func:`mcp_agent_template.notebook.stream_trace`) render exactly which
    agent did what, nested and clearly labeled.
    """
    tool_name = f"ask_{spec.name}"
    timeout = spec.call_timeout if spec.call_timeout is not None else default_timeout

    async def _run(task: str, config: RunnableConfig = None) -> tuple[str, dict[str, Any]]:
        """Execute one isolated child request and return content plus trace artifact."""
        captured: list[Any] = []
        captured_todos: list[Todo] = []

        async def _drive() -> None:
            """Consume child values so the final message and todo state are retained."""
            inputs = {"messages": [{"role": "user", "content": task}]}
            if isinstance(bundle, AgentBundle):
                parent = ACTIVE_SCOPE.get()
                context = (
                    parent.context.child() if parent and parent.context else bundle.new_context()
                )
                context._call_deadline = time.monotonic() + timeout
                stream = bundle.astream(
                    inputs, config=config, context=context, stream_mode="values"
                )
            else:
                stream = bundle.agent.astream(
                    inputs, config=bundle._run_config(), stream_mode="values"
                )
            async for chunk in stream:
                # values-mode chunks contain the current full state, so later
                # snapshots must replace earlier message versions by ID.
                captured[:] = chunk["messages"]
                captured_todos[:] = chunk.get("todos", [])

        try:
            await asyncio.wait_for(_drive(), timeout=timeout)
        except TimeoutError as e:
            raise ToolException(f"Sub-agent '{spec.name}' timed out after {timeout}s.") from e
        except ToolException:
            raise
        except Exception as e:  # noqa: BLE001 - normalize to a safe tool error
            raise ToolException(f"Sub-agent '{spec.name}' failed: {e}") from e

        final_message = next(
            (
                msg
                for msg in reversed(captured)
                if isinstance(msg, AIMessage) and not msg.tool_calls and msg.text
            ),
            None,
        )
        final = final_message.text if final_message is not None else ""
        return final, {"agent": spec.name, "messages": captured, "todos": captured_todos}

    return StructuredTool.from_function(
        coroutine=_run,
        name=tool_name,
        description=spec.description,
        args_schema=_AskSubAgentInput,
        handle_tool_error=True,
        response_format="content_and_artifact",
    )


@observe_build
async def build_agent_tree(
    root: AgentSpec,
    settings: Settings | None = None,
    *,
    mcp_tools: list[BaseTool] | None = None,
    middleware: tuple[AgentMiddleware, ...] = (),
    observability: ObservabilityRuntime | None = None,
) -> AgentBundle:
    """Build a parent/sub-agent tree and return the root's :class:`AgentBundle`.

    A single MCP client/tool set is created once and shared by every node in
    the tree -- no per-agent subprocess spawning. Sub-agents are built
    bottom-up, wrapped as ``ask_<name>`` tools, and attached to their
    parent's tool list. A spec with no ``sub_agents`` and no filters behaves
    exactly like :func:`~mcp_agent_template.agent.react_agent.build_agent`.
    """
    settings = settings or get_settings()
    _validate_tree(root)

    mcp_client = build_mcp_client(settings) if mcp_tools is None else None
    mcp_tools = await mcp_client.list_tools() if mcp_tools is None else list(mcp_tools)
    mcp_tools_by_name = {t.name: t for t in mcp_tools}
    logger.info("Loaded %d MCP tool(s), shared across the agent tree.", len(mcp_tools))

    skill_catalogs: dict[Path, tuple[Skill, ...]] = {}

    async def _build(spec: AgentSpec) -> AgentBundle:
        """Recursively compile one node after selecting its tools and skills."""
        # Tool selection occurs before child construction so unknown names fail
        # without compiling a partially usable subtree.
        if spec.tool_names is None:
            node_mcp_tools = list(mcp_tools)
        else:
            unknown = [n for n in spec.tool_names if n not in mcp_tools_by_name]
            if unknown:
                raise ValueError(
                    f"Agent {spec.name!r} references unknown tool_names {unknown}. "
                    f"Available: {sorted(mcp_tools_by_name)}."
                )
            node_mcp_tools = [mcp_tools_by_name[n] for n in spec.tool_names]

        # Skill catalogs are cached by resolved directory because sibling agents
        # commonly share the same immutable on-disk skill set.
        skills_path = agent_skills_path(settings, spec.skills_dir)
        skills_path = skills_path.resolve()
        if skills_path not in skill_catalogs:
            skill_catalogs[skills_path] = tuple(discover_skills(skills_path))
        node_skills = list(skill_catalogs[skills_path])
        if spec.skill_names is not None:
            by_name = {s.name: s for s in node_skills}
            unknown_skills = [n for n in spec.skill_names if n not in by_name]
            if unknown_skills:
                raise ValueError(
                    f"Agent {spec.name!r} references unknown skill_names "
                    f"{unknown_skills}. Available: {sorted(by_name)}."
                )
            node_skills = [by_name[n] for n in spec.skill_names]

        # 3. Sub-agents -> tools, built bottom-up (post-order).
        child_tools: list[BaseTool] = []
        gated_tool_names: set[str] = set()
        for child_spec in spec.sub_agents:
            child_bundle = await _build(child_spec)
            child_tool = make_agent_tool(
                child_spec, child_bundle, default_timeout=settings.agent_call_timeout
            )
            child_tools.append(child_tool)
            gated_tool_names.add(child_tool.name)

        application = list(middleware) if spec is root else []
        if child_tools:
            if callable(spec.concurrency):
                application.append(
                    tool_call_middleware(spec.concurrency, name="sub_agent_concurrency")
                )
            elif spec.concurrency != "parallel":
                limit = 1 if spec.concurrency == "sequential" else spec.concurrency
                if not isinstance(limit, int) or limit < 1:
                    raise ValueError(
                        "Child concurrency must be sequential, parallel, or a positive int."
                    )
                application.append(ChildConcurrencyMiddleware(limit, gated_tool_names))
        return _prepare_node(
            settings.model_copy(update={"context_compaction": spec.context_compaction})
            if spec.context_compaction is not None
            else settings,
            mcp_client=mcp_client,
            mcp_tools=node_mcp_tools,
            skills=node_skills,
            model=spec.model,
            model_name=spec.model_name,
            temperature=spec.temperature,
            extra_tools=list(spec.extra_tools),
            sub_agent_tools=child_tools,
            system_prompt_extra=spec.system_prompt_extra,
            max_iterations=spec.max_iterations,
            middleware=tuple(application),
            name=spec.name,
            observability=observability,
        )

    return await _build(root)
