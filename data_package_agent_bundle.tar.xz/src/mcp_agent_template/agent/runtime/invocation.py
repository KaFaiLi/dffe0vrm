"""Bundle-owned graph invocation, stream delivery and terminal outcomes.

The recorder owns sinks; this execution module owns native graph driving.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections.abc import Sequence
from contextlib import aclosing, contextmanager
from typing import Any

from opentelemetry.trace import Status, StatusCode

from mcp_agent_template.observability.context import local_execution
from mcp_agent_template.observability.recording.runtime import completion_for, has_interrupt
from mcp_agent_template.observability.semantics import error_kind


class InvocationScope:
    """Own graph driving, correlation, and terminal recording for one invocation.

    A scope is single-use.  Child scopes inherit root correlation and aggregate
    counters, while each scope retains its own completion, latency, and callback
    state.  ``finish`` is idempotent so context cleanup and exception paths can
    safely converge on the same terminal event.
    """

    def __init__(self, runtime, agent_name, context=None, config=None, parent=None):
        """Initialize correlation and counters without starting spans or graph work."""
        self.runtime = runtime
        self.agent_name = agent_name
        self.context = context
        self.config = dict(config or {})
        self.parent = parent
        self.run_id = str(uuid.uuid4())
        self.root_run_id = parent.root_run_id if parent else self.run_id
        self.parent_run_id = parent.run_id if parent else None
        self.span = None
        self.trace_id = None
        self.started = None
        self.finished = False
        self.pause_seconds = 0.0
        self.summary = {
            "model_calls": 0,
            "calls_with_usage": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "handled_error_count": 0,
            "denied_call_count": 0,
            "suppressed_call_count": 0,
        }
        self.aggregate = parent.aggregate if parent else self.summary
        self.callback = None
        self.build_fingerprint = None
        self.definition_json = None

    @property
    def deadline(self) -> float | None:
        """Return the earliest root-run or child-call monotonic deadline."""
        if self.context is None:
            return None
        deadlines = [
            d for d in (self.context.budget.deadline, self.context._call_deadline) if d is not None
        ]
        return min(deadlines) if deadlines else None

    @property
    def timeout_scope(self) -> str:
        """Identify whether the effective timeout belongs to the root or child call."""
        if (
            self.context
            and self.context._call_deadline is not None
            and self.deadline == self.context._call_deadline
        ):
            return "child"
        return "root"

    def exception_completion(self, exc: BaseException) -> str:
        """Map an exception to a terminal label while preserving elapsed deadlines.

        An owning root or batch timeout can cancel this scope before the local
        timeout context converts cancellation to ``TimeoutError``.  Comparing
        against the effective deadline keeps that outcome classified as a timeout.
        """
        if (
            isinstance(exc, asyncio.CancelledError)
            and self.deadline is not None
            and time.monotonic() >= self.deadline
        ):
            return "timed_out"
        return completion_for(exc)

    def start(self, inputs: Any = None) -> InvocationScope:
        """Start correlation, callbacks, span state, and the ``run.started`` event."""
        if self.started is not None:
            raise ValueError("Invocation scope has already been used.")
        self.started = time.monotonic()
        if self.runtime:
            with local_execution(self.runtime, self):
                self.span = self.runtime.tracer.start_span(
                    f"agent.invoke {self.agent_name}",
                    attributes={
                        "mcp_agent_template.run_id": self.run_id,
                        "mcp_agent_template.root_run_id": self.root_run_id,
                        "mcp_agent_template.agent.name": self.agent_name,
                    },
                )
                self.trace_id = f"{self.span.get_span_context().trace_id:032x}"
            self.runtime.active_scopes.add(self.run_id)
            from langchain_core.runnables.config import merge_configs

            from mcp_agent_template.observability.capture.callbacks import ObservationCallback

            self.callback = ObservationCallback(self)
            # Child graph configuration can inherit the root handler. Reusing it
            # avoids duplicate callbacks; task-local active scope still assigns
            # every event to the correct child invocation.
            inherited = self.config.get("callbacks")
            handlers = (
                inherited if isinstance(inherited, list) else getattr(inherited, "handlers", [])
            )
            existing = next(
                (h for h in (handlers or []) if isinstance(h, ObservationCallback)), None
            )
            if existing is None:
                self.config = merge_configs(self.config, {"callbacks": [self.callback]})
            else:
                self.callback = existing
            with self.activate():
                self.emit(
                    "run.started",
                    {
                        "agent_name": self.agent_name,
                        "parent_run_id": self.parent_run_id,
                        "build_fingerprint": self.build_fingerprint,
                        "thread_id": self.config.get("configurable", {}).get("thread_id"),
                        "input": inputs,
                        "checkpoint_id": self.config.get("configurable", {}).get("checkpoint_id"),
                        "limits": {
                            "max_tool_calls": self.context.max_tool_calls,
                            "max_concurrent_tools": self.context.max_concurrent_tools,
                            "timeout": self.context.timeout,
                        }
                        if self.context
                        else None,
                        "tags": self.config.get("tags"),
                        "metadata": self.config.get("metadata"),
                    },
                )
                if self.definition_json is not None:
                    definition = json.loads(self.definition_json)
                    self.emit(
                        "capture.run_definition",
                        {
                            **definition["data"],
                            "stage": "agent_definition",
                        },
                        redactions=definition["redactions"],
                    )
                self.runtime.metric(
                    "mcp_agent_template.child.active"
                    if self.parent
                    else "mcp_agent_template.run.active",
                    active=True,
                )
        return self

    @contextmanager
    def activate(self):
        """Bind this runtime, scope, and span to the current context variables."""
        with local_execution(self.runtime, self, self.span):
            yield self

    def emit(
        self, name: str, payload: Any, *, correlation=None, redactions: Sequence[str] = ()
    ) -> None:
        """Record a payload, retaining redaction paths from an immutable build receipt."""
        if self.runtime:
            self.runtime.emit(
                name, payload, scope=self, correlation=correlation, redactions=redactions
            )

    def count(self, name: str, value: int = 1) -> None:
        """Increment both the local summary and its root aggregate, when distinct."""
        self.summary[name] = self.summary.get(name, 0) + value
        if self.aggregate is not self.summary:
            self.aggregate[name] = self.aggregate.get(name, 0) + value

    def finish(self, completion: str = "completed", error: BaseException | None = None) -> None:
        """Finalize callbacks, metrics, span state, and the terminal event once."""
        if self.finished:
            return
        self.finished = True
        self.completion = completion
        if self.runtime:
            with self.activate():
                if self.callback:
                    self.callback.finish_open(self)
                if completion in ("failed", "timed_out"):
                    self.span.set_status(Status(StatusCode.ERROR))
                self.emit(
                    "run.finished",
                    {
                        "completion": completion,
                        "error": error,
                        "error_kind": error_kind(error),
                        "timeout_scope": self.timeout_scope if completion == "timed_out" else None,
                        "duration": time.monotonic() - self.started,
                        "consumer_pause_seconds": self.pause_seconds,
                        "summary": self.summary,
                        "telemetry_complete": "partial"
                        if self.summary.get("recording_errors") or self.runtime.store.failed
                        else "complete",
                    },
                )
                self.runtime.metric(
                    "mcp_agent_template.child.active"
                    if self.parent
                    else "mcp_agent_template.run.active",
                    -1,
                    active=True,
                )
                if not self.parent:
                    self.runtime.metric(
                        "mcp_agent_template.run.count", attributes={"completion": completion}
                    )
                    self.runtime.metric(
                        "mcp_agent_template.run.duration",
                        time.monotonic() - self.started,
                        histogram=True,
                        attributes={"completion": completion},
                    )
                self.span.end()
            self.runtime.active_scopes.discard(self.run_id)

    async def __aenter__(self):
        """Enter the managed lifecycle and return the active resource."""
        return self

    async def __aexit__(self, exc_type, exc, tb):
        """Finish the managed lifecycle while preserving any caller exception."""
        if self.started is not None and not self.finished:
            self.finish(self.exception_completion(exc) if exc else "closed_early", exc)

    async def ainvoke(self, graph, inputs, *, output_transform=None, **kwargs):
        """Invoke the graph once and return its native result mapping."""
        self.start(inputs)
        try:
            with self.activate():
                if self.context:
                    self.context.budget.check_deadline()
                    async with asyncio.timeout_at(self.deadline):
                        result = await graph.ainvoke(
                            inputs, config=self.config, context=self.context, **kwargs
                        )
                else:
                    result = await graph.ainvoke(
                        inputs, config=self.config, context=self.context, **kwargs
                    )
                self.emit("capture.output", result)
                if has_interrupt(result):
                    self.finish("interrupted")
                # Delivery belongs to this run; cleanup precedes its terminal event.
                if output_transform is not None:
                    if self.context:
                        async with asyncio.timeout_at(self.deadline):
                            result = await output_transform(result)
                    else:
                        result = await output_transform(result)
            self.finish("completed")
            return result
        except BaseException as exc:
            self.finish(self.exception_completion(exc), exc)
            raise

    async def astream(self, graph, inputs, **kwargs):
        """Stream native graph updates while keeping the invocation observation scope open."""
        async with aclosing(self._astream(graph, inputs, **kwargs)) as stream:
            async for event in stream:
                yield event

    async def _astream(self, graph, inputs, **kwargs):
        """Drive the native stream and preserve caller-requested modes and shapes."""
        self.start(inputs)
        interrupted = False
        try:
            # Native message/custom streams can omit interrupts entirely. Add the
            # updates channel only for internal observation, then remove it again
            # so callers receive exactly their requested v1/v2 event shape.
            requested = kwargs.get("stream_mode")
            if requested is None:
                requested = getattr(graph, "stream_mode", "values")
            modes = [requested] if isinstance(requested, str) else list(requested)
            extra_updates = "updates" not in modes
            if extra_updates:
                kwargs = {**kwargs, "stream_mode": [*modes, "updates"]}
            stream = graph.astream(inputs, config=self.config, context=self.context, **kwargs)
            try:
                while True:
                    try:
                        with self.activate():
                            if self.context:
                                self.context.budget.check_deadline()
                                async with asyncio.timeout_at(self.deadline):
                                    event = await anext(stream)
                            else:
                                event = await anext(stream)
                            self.emit("capture.stream", event)
                            if has_interrupt(event):
                                interrupted = True
                            if extra_updates:
                                if kwargs.get("version", "v1") == "v2":
                                    if event["type"] not in modes:
                                        continue
                                else:
                                    subgraphs = kwargs.get("subgraphs", False)
                                    mode, data = event[-2:]
                                    if mode not in modes:
                                        continue
                                    if isinstance(requested, str):
                                        event = (event[0], data) if subgraphs else data
                    except StopAsyncIteration:
                        break
                    paused = time.monotonic()
                    try:
                        yield event
                    finally:
                        self.pause_seconds += time.monotonic() - paused
            finally:
                with self.activate():
                    await stream.aclose()
            self.finish("interrupted" if interrupted else "completed")
        except BaseException as exc:
            self.finish(self.exception_completion(exc), exc)
            raise
