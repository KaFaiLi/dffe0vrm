"""Expose native invocation context, lifecycle, compaction, and middleware policy components."""
