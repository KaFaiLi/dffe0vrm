"""Invocation-owned execution limits shared by a root agent and its children.

``RunContext`` separates per-node scheduling state from the ``RunBudget`` that
must be shared across a delegation tree.  Tool/model reservations are protected
by a thread lock because synchronous and asynchronous middleware can consume the
same allowance.  Concurrency gates deliberately cover external tools but not
sub-agent delegation, which has its own parent-level capacity policy.
"""

from __future__ import annotations

import asyncio
import threading
import time
from dataclasses import dataclass
from typing import Any

from mcp_agent_template.config import Settings


class ToolBudgetExceeded(RuntimeError):
    """No tool may execute after the shared allowance is exhausted."""


class ModelBudgetExceeded(RuntimeError):
    """The root and children exhausted their shared model allowance."""


class RunBudget:
    """Track invocation-wide call quotas, tool concurrency, and the deadline.

    A single instance is shared by every child context created from a root run.
    Reservations are monotonic: failed or cancelled calls are not returned to
    the allowance because they still consumed scheduling capacity.
    """

    def __init__(self, max_calls: int, concurrency: int, timeout: float, max_model_calls: int):
        """Initialize counters, capacity gates, and a monotonic absolute deadline."""
        self.max_calls = max_calls
        self.calls = 0
        self.max_model_calls = max_model_calls
        self.model_calls = 0
        self.deadline = time.monotonic() + timeout
        self.external_slots = asyncio.Semaphore(concurrency)
        self.sync_external_slots = threading.BoundedSemaphore(concurrency)
        self._lock = threading.Lock()

    def check_deadline(self) -> None:
        """Raise ``TimeoutError`` once the shared monotonic deadline has passed."""
        if time.monotonic() >= self.deadline:
            raise TimeoutError("Agent invocation deadline exceeded.")

    def reserve(self) -> None:
        """Atomically reserve one tool call from the invocation-wide allowance."""
        with self._lock:
            self.check_deadline()
            if self.calls >= self.max_calls:
                raise ToolBudgetExceeded(f"Shared limit of {self.max_calls} tool calls exhausted.")
            self.calls += 1

    def reserve_model(self) -> None:
        """Atomically reserve one model call from the invocation-wide allowance."""
        with self._lock:
            self.check_deadline()
            if self.model_calls >= self.max_model_calls:
                raise ModelBudgetExceeded(
                    f"Shared limit of {self.max_model_calls} model calls exhausted."
                )
            self.model_calls += 1


@dataclass
class RunContext:
    """Carry invocation-local scheduling state through LangGraph runtime context.

    Root bundle calls require a fresh, single-use context.  ``child()`` creates
    separate ordering gates and context summaries while retaining the root
    budget, so delegation cannot reset call counts or extend the deadline.
    """

    max_tool_calls: int = 100
    max_concurrent_tools: int = 8
    timeout: float = 300.0
    max_model_calls: int = 64

    def __post_init__(self) -> None:
        """Validate configured limits and allocate fresh root scheduling state."""
        if min(self.max_tool_calls, self.max_concurrent_tools, self.max_model_calls) < 1:
            raise ValueError("Run limits must be positive.")
        if self.timeout <= 0:
            raise ValueError("Run timeout must be positive.")
        self._budget = RunBudget(
            self.max_tool_calls, self.max_concurrent_tools, self.timeout, self.max_model_calls
        )
        self.ordering = asyncio.Semaphore(1)
        self.sync_ordering = threading.Lock()
        self.child_gates: dict[str, asyncio.Semaphore] = {}
        # Compaction summaries describe one node's message history. Sharing them
        # with a child would inject parent conversation state into the child prompt.
        self.context_summaries: list[Any] = []
        self._started = False
        self._claimed = False
        self._call_deadline: float | None = None

    @property
    def budget(self) -> RunBudget:
        """Return the quota/deadline object shared by this delegation tree."""
        return self._budget

    @classmethod
    def from_settings(cls, settings: Settings) -> RunContext:
        """Create a fresh root context from the validated runtime settings."""
        return cls(
            settings.agent_max_tool_calls,
            settings.agent_max_concurrent_tools,
            settings.agent_run_timeout,
            settings.agent_max_model_calls,
        )

    def claim(self) -> None:
        """Reserve this execution context for one bundle invocation."""
        if self._claimed or self._started:
            raise ValueError("RunContext has already been used; create a fresh context.")
        self._claimed = True

    def begin(self) -> None:
        """Mark graph execution as started and reject accidental context reuse."""
        if self._started:
            raise ValueError("RunContext has already been used; create a fresh context.")
        self._started = True

    def child(self) -> RunContext:
        """Create isolated child scheduling state that shares the root budget."""
        child = RunContext(
            self.max_tool_calls, self.max_concurrent_tools, self.timeout, self.max_model_calls
        )
        child._budget = self._budget
        return child


def require_context(context: Any) -> RunContext:
    """Return a validated run context or fail before applying invocation policy."""
    if not isinstance(context, RunContext):
        raise ValueError("Use bundle.ainvoke/astream or pass context=bundle.new_context().")
    return context
