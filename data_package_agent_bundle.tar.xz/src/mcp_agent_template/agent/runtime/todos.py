"""Native todo tracking with prompt assembly owned by the shared builder."""

from collections.abc import Awaitable, Callable

from langchain.agents.middleware import ModelRequest, ModelResponse, TodoListMiddleware
from langchain_core.messages import AIMessage


class AgentTodoMiddleware(TodoListMiddleware):
    """Retain native todo tools/state/checks without appending a second prompt.

    ``build_system_prompt`` includes the todo instructions so bundle metadata,
    request inspection, and dispatched prompts describe the same default prompt.
    All todo execution and parallel-write validation remain owned by LangChain.
    """

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse | AIMessage:
        """Apply this policy around a synchronous model call."""
        return handler(request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse | AIMessage:
        """Apply this policy around an asynchronous model call."""
        return await handler(request)
