"""LangChain middleware enforcing tool rounds, lifecycle, and capacity policy.

The middleware operates on native requests and messages rather than replacing
LangGraph execution.  Call quotas and deadlines come from ``RunContext``;
denials are returned as ordinary error ``ToolMessage`` objects so the model can
respond without triggering an unobserved side effect.
"""

from __future__ import annotations

import asyncio
from contextlib import nullcontext
from typing import Any

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.errors import GraphRecursionError

from mcp_agent_template.agent.runtime.context import ToolBudgetExceeded, require_context
from mcp_agent_template.observability.capture.middleware import observed_gate
from mcp_agent_template.observability.context import ACTIVE_SCOPE, emit


class ToolRoundPolicyMiddleware(AgentMiddleware):
    """Reject extra tool rounds before side effects without altering model messages."""

    def __init__(self, max_iterations: int):
        """Configure the maximum number of tool-bearing assistant turns."""
        if max_iterations < 1:
            raise ValueError("max_iterations must be >= 1.")
        self.max_iterations = max_iterations

    def after_model(self, state: dict, runtime: Any) -> dict:
        """Count tool-bearing assistant turns and fail before an excess round executes."""
        messages = state.get("messages", [])
        last = next((m for m in reversed(messages) if isinstance(m, AIMessage)), None)
        if last is None or not last.tool_calls:
            return {}
        emit("tool.proposed", last)
        rounds = 0
        for message in reversed(messages):
            if isinstance(message, HumanMessage):
                break
            if isinstance(message, AIMessage) and message.tool_calls:
                rounds += 1
        if rounds > self.max_iterations:
            emit("policy.round_limit", {"rounds": rounds, "limit": self.max_iterations})
            raise GraphRecursionError(
                f"Agent exceeded its limit of {self.max_iterations} tool-call rounds."
            )
        return {}

    async def aafter_model(self, state: dict, runtime: Any) -> dict:
        """Apply the same round check on LangChain's asynchronous hook path."""
        return self.after_model(state, runtime)


class RuntimePolicyMiddleware(AgentMiddleware):
    """Own invocation lifecycle, parallel model settings, and tool execution policy.

    Each graph execution requires a fresh ``RunContext``. Tool calls reserve the
    root tree's shared budget before dispatch and use invocation-owned capacity;
    delegated child calls never hold an external-tool permit. Model reservation
    and final request capture remain in ``EffectiveRequestMiddleware``.

    Install after application middleware and context compaction, immediately
    before effective dispatch, to preserve the existing model/tool hook order.
    """

    def __init__(self, *, child_names: set[str] | None = None):
        """Configure delegated tools, which do not consume external-tool slots.

        Args:
            child_names: Delegation tool names exempt from external-tool slots.
                Missing or empty names treat every tool as an external operation.
                Other calls may run in parallel within invocation capacity.
        """
        self.child_names = frozenset(child_names or ())

    def before_agent(self, state: dict, runtime: Any) -> None:
        """Begin the supplied single-use context and reject a repeated execution."""
        require_context(runtime.context).begin()

    async def abefore_agent(self, state: dict, runtime: Any) -> None:
        """Begin the supplied context on LangChain's asynchronous hook path."""
        self.before_agent(state, runtime)

    def wrap_model_call(self, request: Any, handler: Any) -> Any:
        """Apply this policy around a synchronous model call."""
        return handler(self._parallel_request(request))

    async def awrap_model_call(self, request: Any, handler: Any) -> Any:
        """Apply this policy around an asynchronous model call."""
        return await handler(self._parallel_request(request))

    @staticmethod
    def _parallel_request(request: Any) -> Any:
        """Return a request copy that explicitly permits provider parallel tool calls."""
        return request.override(
            model_settings={**request.model_settings, "parallel_tool_calls": True}
        )

    @staticmethod
    def _denied(request: Any, error: ToolBudgetExceeded) -> ToolMessage:
        """Convert a budget denial into an observed tool error for the model."""
        emit("tool.denied", {"call": request.tool_call, "reason": "tool_budget"})
        scope = ACTIVE_SCOPE.get()
        if scope:
            scope.count("denied_call_count")
        return ToolMessage(
            content=str(error),
            name=request.tool_call["name"],
            tool_call_id=request.tool_call["id"],
            status="error",
        )

    def wrap_tool_call(self, request: Any, handler: Any) -> Any:
        """Apply this policy around a synchronous tool call."""
        context = require_context(request.runtime.context)
        try:
            context.budget.reserve()
        except ToolBudgetExceeded as error:
            return self._denied(request, error)
        external = (
            nullcontext()
            if request.tool_call["name"] in self.child_names
            else context.budget.sync_external_slots
        )
        with external:
            context.budget.check_deadline()
            return handler(request)

    async def awrap_tool_call(self, request: Any, handler: Any) -> Any:
        """Apply this policy around an asynchronous tool call."""
        context = require_context(request.runtime.context)

        async def execute() -> Any:
            """Reserve budget and execute under the appropriate external gate."""
            try:
                context.budget.reserve()
            except ToolBudgetExceeded as error:
                return self._denied(request, error)
            if request.tool_call["name"] in self.child_names:
                return await handler(request)
            async with observed_gate(context.budget.external_slots, "external_capacity"):
                return await handler(request)

        async with asyncio.timeout_at(context.budget.deadline):
            return await execute()


class ChildConcurrencyMiddleware(AgentMiddleware):
    """Limit child scheduling per parent invocation, not per compiled graph."""

    def __init__(self, concurrency: int, names: set[str]):
        """Configure the per-parent semaphore applied to named child tools."""
        self.concurrency = concurrency
        self.names = frozenset(names)

    async def awrap_tool_call(self, request: Any, handler: Any) -> Any:
        """Gate matching child calls while allowing unrelated tools through unchanged."""
        if request.tool_call["name"] not in self.names:
            return await handler(request)
        context = require_context(request.runtime.context)
        gate = context.child_gates.setdefault(self.name, asyncio.Semaphore(self.concurrency))
        async with observed_gate(gate, "child_capacity"):
            return await handler(request)
