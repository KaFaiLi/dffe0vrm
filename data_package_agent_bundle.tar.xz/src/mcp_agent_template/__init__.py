"""MCP Agent Template.

A batteries-included starting point for building and *testing* MCP tools with a
LangGraph ReAct agent, pluggable skills, and a swappable LLM backend.

Package layout
--------------
- ``config``       : typed settings loaded from the environment / ``.env``.
- ``llm``          : the GenAI API manager (LLM provider abstraction).
- ``mcp_server``   : the FastMCP server + where you implement your tools.
- ``skills``       : discover skill folders and expose instructions and supporting files.
- ``agent``        : the LangGraph ReAct agent wiring everything together.
"""

from mcp_agent_template.config import Settings, get_settings

__all__ = ["Settings", "get_settings", "__version__"]

__version__ = "0.1.0"
