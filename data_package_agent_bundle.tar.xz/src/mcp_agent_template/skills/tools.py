"""Turn discovered skills into LangChain tools + a system-prompt overview."""

from __future__ import annotations

import base64
import mimetypes
from pathlib import PurePosixPath
from typing import Literal

from langchain_core.tools import BaseTool, StructuredTool, ToolException
from pydantic import BaseModel, Field

from mcp_agent_template.skills.loader import Skill


class _LoadSkillInput(BaseModel):
    """Validate the exact discovered skill name supplied to catalog tools."""

    name: str = Field(description="Exact skill name as shown by list_skills.")


class _ReadSkillFileInput(_LoadSkillInput):
    """Input schema for reading a file from a skill's inventory."""

    path: str = Field(
        description="Relative file path listed by load_skill, e.g. references/api.md."
    )
    encoding: Literal["auto", "utf-8", "base64"] = Field(
        default="auto",
        description="auto reads UTF-8 text or base64 binary; base64 preserves exact bytes.",
    )


def render_skills_overview(skills: list[Skill]) -> str:
    """Render a compact catalog of skills for the system prompt.

    Only names + descriptions (cheap on context). The full body is fetched on
    demand via ``load_skill``.
    """
    if not skills:
        return "No skills are currently available."
    lines = ["You have access to the following skills (load one before using it):"]
    for s in skills:
        lines.append(f"- {s.name}: {s.description}")
    lines.append(
        "\nCall `load_skill(name=...)` to read a skill's full instructions, then follow them."
        " Read supporting files on demand with `read_skill_file(name=..., path=...)`."
    )
    return "\n".join(lines)


def build_skill_tools(skills: list[Skill]) -> list[BaseTool]:
    """Build catalog, instruction and supporting-file tools bound to selected skills."""
    by_name = {s.name: s for s in skills}

    def require_skill(name: str) -> Skill:
        """Return a discovered skill by name or raise an actionable tool error."""
        skill = by_name.get(name)
        if skill is None:
            available = ", ".join(by_name) or "(none)"
            raise ToolException(f"Unknown skill {name!r}. Available skills: {available}.")
        return skill

    def list_skills() -> str:
        """List the skills available to you, with a one-line description each."""
        if not by_name:
            return "No skills are available."
        return "\n".join(f"- {s.name}: {s.description}" for s in by_name.values())

    def load_skill(name: str) -> str:
        """Load a skill's full instructions by name, then follow them.

        Args:
            name: The exact skill name (see the system prompt or ``list_skills``).

        Raises:
            ToolException: if no skill with the given name exists.  The agent
                receives the error message and can try another name or proceed
                without the skill.
        """
        skill = require_skill(name)
        if not skill.files:
            return skill.instructions
        inventory = "\n".join(f"- {path}" for path in skill.files)
        return (
            f"{skill.instructions}\n\nSkill folder: {skill.root}\n"
            f"Supporting files:\n{inventory}\n\n"
            "Read needed files with read_skill_file(name=..., path=...). "
            "Paths are relative to this skill folder. Scripts are not automatically executed."
        )

    def read_skill_file(
        name: str, path: str, encoding: Literal["auto", "utf-8", "base64"] = "auto"
    ) -> dict:
        """Read a supporting file from a selected skill without executing it.

        Returns content with its encoding, MIME type, byte count and local path.
        Binary content is base64. File content is never silently truncated.
        """
        skill = require_skill(name)
        try:
            content = skill.read_file(path)
        except (OSError, ValueError) as exc:
            raise ToolException(f"Could not read file for skill {name!r}: {exc}") from exc
        relative = PurePosixPath(path.replace("\\", "/")).as_posix()
        mime_type = mimetypes.guess_type(relative)[0]
        text = None
        if encoding != "base64":
            try:
                text = content.decode("utf-8")
            except UnicodeDecodeError as exc:
                if encoding == "utf-8":
                    raise ToolException(
                        "Skill file is not UTF-8 text; use encoding='base64'."
                    ) from exc
            if encoding == "auto" and "\x00" in (text or ""):
                text = None
        return {
            "name": name,
            "relative_path": relative,
            "path": str(skill.root / relative),
            "mime_type": mime_type
            or ("text/plain" if text is not None else "application/octet-stream"),
            "size_bytes": len(content),
            "encoding": "utf-8" if text is not None else "base64",
            "content": text if text is not None else base64.b64encode(content).decode("ascii"),
        }

    list_tool = StructuredTool.from_function(
        func=list_skills,
        name="list_skills",
        description="List the skills available to you with short descriptions.",
        handle_tool_error=True,
    )
    load_tool = StructuredTool.from_function(
        func=load_skill,
        name="load_skill",
        args_schema=_LoadSkillInput,
        description=(
            "Load a skill's full instructions and supporting-file inventory. Call this "
            "before attempting a task a skill covers, then follow the returned "
            "instructions."
        ),
        handle_tool_error=True,
    )
    read_tool = StructuredTool.from_function(
        func=read_skill_file,
        name="read_skill_file",
        args_schema=_ReadSkillFileInput,
        description=(
            "Read a reference, script, template or asset listed by load_skill. "
            "Use a relative path within the selected skill folder. Returns UTF-8 text or "
            "base64 binary content with file metadata; maximum file size is one MiB. "
            "Reading a script does not execute it."
        ),
        handle_tool_error=True,
    )
    return [list_tool, load_tool, read_tool]
