"""Skills: reusable, model-facing instruction packs discovered from a folder.

A *skill* is a directory containing a ``SKILL.md`` file with YAML frontmatter:

    ---
    name: web_research
    description: How to research a topic on the web and cite sources.
    ---
    # Web research
    ...step-by-step instructions the model should follow...

The agent is told (in its system prompt) which skills exist and what they're
for, then pulls the full instructions on demand via the ``load_skill`` tool.
Skill folders may also contain references, scripts, templates, assets and other
supporting files. ``load_skill`` lists them; ``read_skill_file`` reads selected
text or binary content on demand, without executing scripts.
This "progressive disclosure" keeps the base prompt small while giving the model
deep, task-specific know-how when it needs it.
"""

from mcp_agent_template.skills.loader import Skill, discover_skills
from mcp_agent_template.skills.tools import build_skill_tools, render_skills_overview

__all__ = [
    "Skill",
    "discover_skills",
    "build_skill_tools",
    "render_skills_overview",
]
