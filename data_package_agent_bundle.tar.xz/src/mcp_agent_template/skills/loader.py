"""Discover skill folders and read their supporting files on demand."""

from __future__ import annotations

from pathlib import Path, PurePosixPath, PureWindowsPath

import yaml
from pydantic import BaseModel, ConfigDict, field_validator

from mcp_agent_template.config import Settings, get_settings
from mcp_agent_template.logging_utils import get_logger

logger = get_logger(__name__)

MAX_SKILL_FILE_BYTES = 1024 * 1024


def agent_skills_path(settings: Settings, skills_dir: str | Path | None = None) -> Path:
    """Select the configured skills folder or an explicit node folder.

    An explicit node directory or custom settings directory keeps its existing
    discovery behavior, even when empty or missing.
    """
    if skills_dir is not None:
        return settings.resolve_path(skills_dir)
    return settings.skills_path


class Skill(BaseModel):
    """A single skill loaded from disk.

    Fields are validated and frozen on construction. Discovery supplies the
    required supporting-file inventory, empty for Markdown-only skills, along
    with the resolved instruction path used as the file-containment boundary.
    """

    model_config = ConfigDict(frozen=True)

    name: str
    description: str
    body: str
    path: Path
    files: tuple[str, ...]

    @field_validator("path")
    @classmethod
    def _absolute_path(cls, path: Path) -> Path:
        """Freeze the skill directory boundary while retaining the instruction path.

        Resolving the parent prevents a later symlink or junction replacement from
        silently changing the containment boundary used by ``read_file``.
        """
        return path.parent.resolve() / path.name

    @property
    def root(self) -> Path:
        """Absolute folder containing this skill's instructions and resources."""
        return self.path.parent

    @property
    def instructions(self) -> str:
        """Return the complete model-facing instructions without YAML frontmatter."""
        return self.body.strip()

    def read_file(self, path: str) -> bytes:
        """Read an inventoried relative file, with a one-MiB limit and no execution.

        Recheck containment on every read, including symlink/junction targets.
        Both slash styles are accepted, but absolute paths, traversal and Windows
        drive/alternate-stream paths are rejected on every platform.
        """
        normalized = path.replace("\\", "/")
        if (
            not normalized
            or "\x00" in normalized
            or ":" in normalized
            or PurePosixPath(normalized).is_absolute()
            or PureWindowsPath(path).drive
            or any(part in {".", ".."} for part in normalized.split("/"))
        ):
            raise ValueError("Use a relative file path inside the selected skill folder.")
        relative = PurePosixPath(normalized).as_posix()
        if relative not in self.files:
            raise ValueError(f"Unknown skill file {relative!r}; use the inventory from load_skill.")
        target = (self.root / relative).resolve()
        if not target.is_relative_to(self.root):
            raise ValueError("Skill file resolves outside the selected skill folder.")
        if not target.is_file():
            raise ValueError(f"Skill file {relative!r} is no longer a regular file.")
        with target.open("rb") as handle:
            content = handle.read(MAX_SKILL_FILE_BYTES + 1)
        if len(content) > MAX_SKILL_FILE_BYTES:
            raise ValueError(
                f"Skill file {relative!r} exceeds the {MAX_SKILL_FILE_BYTES}-byte limit."
            )
        return content


def _discover_files(root: Path) -> tuple[str, ...]:
    """Inventory files without loading content or entering another skill folder."""
    files = []
    for directory, dirnames, filenames in root.walk():
        dirnames[:] = sorted(
            name
            for name in dirnames
            if (directory / name).resolve().is_relative_to(root)
            and not (directory / name / "SKILL.md").is_file()
        )
        for name in filenames:
            path = directory / name
            if path == root / "SKILL.md":
                continue
            if path.is_file() and path.resolve().is_relative_to(root):
                files.append(path.relative_to(root).as_posix())
    return tuple(sorted(files))


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    """Split a ``---``-delimited YAML frontmatter block from the body.

    Returns ``(metadata, body)``. If there is no frontmatter, metadata is empty
    and body is the whole text.
    """
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) == 3:
            _, fm, body = parts
            try:
                meta = yaml.safe_load(fm) or {}
            except yaml.YAMLError as e:  # pragma: no cover - defensive
                logger.warning("Bad YAML frontmatter: %s", e)
                meta = {}
            if isinstance(meta, dict):
                return meta, body
    return {}, text


def _load_one(skill_md: Path) -> Skill | None:
    """Load and validate one ``SKILL.md``, returning ``None`` on read failure."""
    try:
        text = skill_md.read_text(encoding="utf-8")
    except OSError as e:  # pragma: no cover - defensive
        logger.warning("Could not read %s: %s", skill_md, e)
        return None

    meta, body = _parse_frontmatter(text)
    # Missing frontmatter remains usable: the containing folder supplies identity
    # and the first nonblank body line supplies a compact catalog description.
    name = str(meta.get("name") or skill_md.parent.name).strip()
    description = str(
        meta.get("description") or _first_paragraph(body) or "(no description)"
    ).strip()
    return Skill(
        name=name,
        description=description,
        body=body,
        path=skill_md,
        files=_discover_files(skill_md.parent.resolve()),
    )


def _first_paragraph(body: str) -> str:
    """Return the first nonblank heading or text line as a fallback description."""
    for line in body.splitlines():
        line = line.strip().lstrip("#").strip()
        if line:
            return line
    return ""


def discover_skills(skills_dir: str | Path | None = None) -> list[Skill]:
    """Find and parse all skills under ``skills_dir``.

    A skill is any directory containing a ``SKILL.md`` file. A top-level
    ``SKILL.md`` is also supported. Supporting files are inventoried recursively,
    including references, scripts, templates and binary assets; their content is
    read only on demand. Results preserve directory discovery order.
    """
    if skills_dir is None:
        skills_dir = agent_skills_path(get_settings())
    root = Path(skills_dir).resolve()
    if not root.exists():
        logger.warning("Skills dir does not exist: %s", root)
        return []

    skills: dict[str, Skill] = {}
    for skill_md in sorted(root.rglob("SKILL.md")):
        if not skill_md.resolve().is_relative_to(root):
            continue
        skill = _load_one(skill_md)
        if skill is None:
            continue
        if skill.name in skills:
            logger.warning(
                "Duplicate skill name %r (%s); keeping first.",
                skill.name,
                skill_md,
            )
            continue
        skills[skill.name] = skill

    logger.info("Discovered %d skill(s) in %s", len(skills), root)
    return list(skills.values())
