"""Complete, credential-redacted serialization shared by every local sink.

Projection is loss-aware: supported values are represented explicitly, cycles
become references, binary data is base64, and unsupported objects raise instead
of falling back to a potentially leaky ``repr``.  Redaction covers configured
secret values, credential-shaped keys, inline assignments, auth headers, and URL
userinfo before JSON reaches SQLite or operational logs.
"""

from __future__ import annotations

import base64
import dataclasses
import enum
import json
import math
import os
import re
import threading
import traceback
from collections import OrderedDict
from collections.abc import Mapping, Sequence
from datetime import date, datetime
from pathlib import Path
from typing import Any
from uuid import UUID

from pydantic import BaseModel, SecretBytes, SecretStr

_SECRET_KEY = re.compile(
    r"(?:api[_-]?key|password|passwd|secret|authorization|cookie|access[_-]?token|refresh[_-]?token|credential)",
    re.I,
)
_INLINE = re.compile(
    r"""(?i)(["']?(?:api[_-]?key|password|passwd|secret|authorization|cookie|access[_-]?token|refresh[_-]?token)["']?\s*[:=]\s*)(?:["'][^"'\r\n]*["']|\[REDACTED\](?=$|[\s,;&}\]])|[^\s,;&}\]]+)"""
)
_BEARER = re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+")
_URL_AUTH = re.compile(r"(https?://)[^/@\s]+:[^/@\s]+@")


class SerializationFailure(TypeError):
    """Report that a payload cannot be serialized completely and safely."""


class Redactor:
    """Project arbitrary supported payloads while redacting credential material."""

    def __init__(self, secrets: tuple[str, ...] = ()) -> None:
        """Normalize explicit secrets and initialize the bounded text cache."""
        self.secrets = tuple(sorted({x for x in secrets if x}, key=len, reverse=True))
        # Full message histories frequently reuse large immutable strings. Cache
        # only strings—not mutable messages or state—and cap retained input plus
        # output bytes to prevent observability from becoming an unbounded store.
        self._text_cache: OrderedDict[str, tuple[str, int]] = OrderedDict()
        self._text_cache_bytes = 0
        self._text_cache_limit = 1024 * 1024
        self._text_lock = threading.Lock()

    @classmethod
    def for_settings(cls, settings: Any) -> Redactor:
        """Collect explicit secret values from environment and validated settings."""
        values = [v for k, v in os.environ.items() if _SECRET_KEY.search(k) and v]

        def collect(value):
            """Recursively collect Pydantic secret values without stringifying objects."""
            if isinstance(value, SecretStr):
                values.append(value.get_secret_value())
            elif isinstance(value, BaseModel):
                for child in vars(value).values():
                    collect(child)
            elif isinstance(value, Mapping):
                for child in value.values():
                    collect(child)
            elif isinstance(value, (tuple, list)):
                for child in value:
                    collect(child)

        collect(settings)
        return cls(tuple(values))

    def text(self, value: str) -> str:
        """Redact credential text, caching only bounded medium-to-large strings."""
        if 1024 <= len(value) <= self._text_cache_limit // 8:
            with self._text_lock:
                if value in self._text_cache:
                    result, _ = self._text_cache[value]
                    self._text_cache.move_to_end(value)
                    return result
            result = self._redact_text(value)
            size = len(value.encode("utf-8")) + len(result.encode("utf-8"))
            if size <= self._text_cache_limit:
                with self._text_lock:
                    previous = self._text_cache.pop(value, None)
                    if previous:
                        self._text_cache_bytes -= previous[1]
                    self._text_cache[value] = (result, size)
                    self._text_cache_bytes += size
                    while self._text_cache_bytes > self._text_cache_limit:
                        _, (_, removed) = self._text_cache.popitem(last=False)
                        self._text_cache_bytes -= removed
            return result
        return self._redact_text(value)

    def _redact_text(self, value: str) -> str:
        """Apply explicit-secret, auth-header, URL-userinfo, and assignment redaction rules."""
        for secret in self.secrets:
            value = value.replace(secret, "[REDACTED]")
        value = _BEARER.sub(r"\1 [REDACTED]", value)
        value = _URL_AUTH.sub(r"\1[REDACTED]@", value)
        # Consume the entire existing marker, including its closing bracket,
        # when recording a previously redacted build definition again.
        return _INLINE.sub(lambda m: m.group(1) + "[REDACTED]", value)

    def project(self, value: Any) -> tuple[Any, list[str]]:
        """Project a supported value and return every redacted JSON-style path."""
        redactions: list[str] = []
        active: dict[int, str] = {}

        def walk(item: Any, path: str) -> Any:
            """Recursively project one value while tracking cycles and redactions."""
            if isinstance(item, (SecretStr, SecretBytes)):
                redactions.append(path)
                return "[REDACTED]"
            if item is None or isinstance(item, (bool, int)):
                return item
            if isinstance(item, float):
                return item if math.isfinite(item) else {"$float": str(item)}
            if isinstance(item, str):
                result = self.text(item)
                if result != item:
                    redactions.append(path)
                return result
            if isinstance(item, (bytes, bytearray, memoryview)):
                data = bytes(item)
                if any(secret.encode() in data for secret in self.secrets):
                    redactions.append(path)
                    return {"$binary": "[REDACTED]", "bytes": len(data)}
                return {"$binary": base64.b64encode(data).decode("ascii"), "encoding": "base64"}
            if isinstance(item, (UUID, Path, date, datetime)):
                return walk(str(item), path)
            if isinstance(item, enum.Enum):
                return walk(item.value, path)
            if isinstance(item, BaseException):
                return walk(
                    {
                        "type": type(item).__name__,
                        "message": str(item),
                        "stack": "".join(traceback.format_exception(item)),
                    },
                    path,
                )
            ident = id(item)
            if ident in active:
                return {"$ref": active[ident]}
            active[ident] = path
            try:
                if isinstance(item, BaseModel):
                    return walk(
                        {
                            **{k: getattr(item, k) for k in type(item).model_fields},
                            **(item.model_extra or {}),
                        },
                        path,
                    )
                if dataclasses.is_dataclass(item) and not isinstance(item, type):
                    return walk(
                        {f.name: getattr(item, f.name) for f in dataclasses.fields(item)}, path
                    )
                if isinstance(item, Mapping):
                    result = {}
                    for key, child in item.items():
                        if not isinstance(key, (str, int, float, bool, UUID)):
                            raise SerializationFailure(
                                f"Unsupported key type: {type(key).__name__}"
                            )
                        key = str(key)
                        clean_key = self.text(key)
                        child_path = f"{path}/{clean_key}"
                        if _SECRET_KEY.search(key):
                            redactions.append(child_path)
                            result[clean_key] = "[REDACTED]"
                        else:
                            result[clean_key] = walk(child, child_path)
                    return result
                if isinstance(item, (list, tuple, set, frozenset)):
                    return [walk(child, f"{path}/{i}") for i, child in enumerate(item)]
                raise SerializationFailure(f"Unsupported payload type: {type(item).__name__}")
            finally:
                active.pop(ident, None)

        return walk(value, "$"), redactions

    def encode(
        self, value: Any, *, context: dict | None = None, redactions: Sequence[str] = ()
    ) -> str:
        """Redact and encode one envelope, retaining paths from earlier redaction.

        Previously redacted build receipts can be recorded without nesting an
        envelope. Supplied paths refer to the same payload structure and are
        deduplicated with newly removed credentials; values are always projected.
        """
        payload, paths = self.project(value)
        envelope = {
            "schema_version": 1,
            "data": payload,
            "redactions": list(dict.fromkeys([*redactions, *paths])),
        }
        if context is not None:
            envelope["context"], paths = self.project(context)
            envelope["redactions"].extend("context" + path[1:] for path in paths)
        return json.dumps(envelope, ensure_ascii=False, allow_nan=False)
