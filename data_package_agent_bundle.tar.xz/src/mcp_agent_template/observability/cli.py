"""Read-only inspection and complete JSON exports for the local recorder.

Commands open SQLite in read-only mode and never start a service, mutate
recordings, or contact a network endpoint.  Exported run archives include
process-level health and metrics separately from run-attributed observations.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
import time
from contextlib import closing
from pathlib import Path

from mcp_agent_template.config import Settings
from mcp_agent_template.observability.recording.storage import connect_readonly, read_rows


def _decode(rows):
    """Decode persisted JSON envelopes in payload and summary columns in place."""
    for row in rows:
        for field in ("payload", "summary"):
            if row.get(field):
                row[field] = json.loads(row[field])
    return rows


def archive(path: Path, run_id: str) -> dict:
    """Archive one recorded run and return a machine-readable archive receipt."""
    roots = read_rows(path, "SELECT root_run_id FROM runs WHERE run_id=?", (run_id,))
    if not roots:
        raise ValueError("Run not found")
    root_id = roots[0]["root_run_id"]
    runs = _decode(
        read_rows(path, "SELECT * FROM runs WHERE root_run_id=? ORDER BY started", (root_id,))
    )
    events = _decode(
        read_rows(path, "SELECT * FROM events WHERE root_run_id=? ORDER BY cursor", (root_id,))
    )
    trace_ids = {row["trace_id"] for row in runs if row["trace_id"]}
    spans = []
    if trace_ids:
        marks = ",".join("?" for _ in trace_ids)
        spans = _decode(
            read_rows(
                path,
                f"SELECT * FROM spans WHERE trace_id IN ({marks}) ORDER BY started",
                tuple(trace_ids),
            )
        )
    # Process health, unscoped events, and metric snapshots describe recorder
    # coverage but are not attributed to a particular agent run.
    process_ids = {r["process_instance_id"] for r in runs} | {
        s["process_instance_id"] for s in spans
    }
    marks = ",".join("?" for _ in process_ids)
    processes = read_rows(
        path, f"SELECT * FROM processes WHERE process_instance_id IN ({marks})", tuple(process_ids)
    )
    metrics = _decode(
        read_rows(
            path,
            f"SELECT * FROM metric_points WHERE process_instance_id IN ({marks}) "
            "ORDER BY timestamp",
            tuple(process_ids),
        )
    )
    unscoped = _decode(
        read_rows(
            path,
            "SELECT * FROM events WHERE root_run_id IS NULL "
            f"AND process_instance_id IN ({marks}) ORDER BY cursor",
            tuple(process_ids),
        )
    )
    partial = any(p["health"] != "healthy" for p in processes) or any(
        r["summary"] and r["summary"]["data"].get("telemetry_complete") == "partial" for r in runs
    )
    complete = all(p["stopped"] for p in processes) and all(r["ended"] for r in runs)
    # FastMCP's logical CLIENT span can contain a wire CLIENT span whose child is
    # the remote SERVER span. Follow the causal chain rather than requiring one edge.
    by_id = {s["span_id"]: s for s in spans}
    server_descendants: dict[str, list[str]] = {}
    server_parents = set()
    for server in spans:
        if server["payload"]["data"]["kind"] != "SpanKind.SERVER":
            continue
        parent_id = server["parent_span_id"]
        server_parents.add(parent_id)
        seen = set()
        while parent_id in by_id and parent_id not in seen:
            seen.add(parent_id)
            server_descendants.setdefault(parent_id, []).append(server["span_id"])
            parent_id = by_id[parent_id]["parent_span_id"]
    remote_coverage = [
        {
            "span_id": s["span_id"],
            "name": s["name"],
            "server_span_observed": bool(server_descendants.get(s["span_id"])),
            "direct_server_child": s["span_id"] in server_parents,
            "server_span_ids": server_descendants.get(s["span_id"], []),
        }
        for s in spans
        if s["payload"]["data"]["kind"] == "SpanKind.CLIENT"
    ]
    return {
        "schema_version": 1,
        "capture": "full_redacted",
        "retention": "indefinite",
        "recording_status": "partial" if partial else ("complete" if complete else "unconfirmed"),
        "remote_coverage": remote_coverage,
        "coverage": {
            "started": min(r["started"] for r in runs),
            "ended": max((r["ended"] or r["started"]) for r in runs),
        },
        "metric_semantics": (
            "Cumulative process snapshots: never sum repeated snapshots "
            "or add child totals to roots."
        ),
        "root_run_id": root_id,
        "runs": runs,
        "events": events,
        "spans": spans,
        "processes": processes,
        "process_metrics": metrics,
        "process_events": unscoped,
    }


def _since(value):
    """Convert a compact duration such as ``1h`` to a Unix cutoff timestamp."""
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    try:
        return time.time() - float(value[:-1]) * units[value[-1]]
    except (KeyError, ValueError, IndexError):
        raise argparse.ArgumentTypeError("Use a duration such as 1h or 7d") from None


def main(argv=None):
    """Parse an inspection command and emit UTF-8 JSON or text to standard output."""
    # JSON stays UTF-8 even when the Windows terminal uses another locale.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app-root", type=Path)
    parser.add_argument("--db", type=Path)
    commands = parser.add_subparsers(dest="command", required=True)
    listing = commands.add_parser("list")
    listing.add_argument("--limit", type=int, default=20)
    show = commands.add_parser("show")
    show.add_argument("run_id")
    tail = commands.add_parser("tail")
    tail.add_argument("run_id")
    tail.add_argument("--cursor", type=int, default=0)
    tail.add_argument("--follow", action="store_true")
    stats = commands.add_parser("stats")
    stats.add_argument("--since", type=_since, default=_since("1h"))
    export = commands.add_parser("export")
    export.add_argument("run_id")
    export.add_argument("--format", choices=["json", "jsonl"], default="json")
    export.add_argument("--output", type=Path)
    export.add_argument("--prices", type=Path, help="Optional local versioned JSON price table")
    commands.add_parser("doctor")
    args = parser.parse_args(argv)
    settings = Settings(**({"app_root": args.app_root} if args.app_root else {}))
    path = args.db or settings.resolve_path(settings.obs.dir) / "observability.sqlite3"
    try:
        if args.command == "list":
            if args.limit < 1:
                parser.error("--limit must be positive")
            result = _decode(
                read_rows(
                    path,
                    (
                        "SELECT run_id,agent_name,started,ended,completion,summary "
                        "FROM runs WHERE parent_run_id IS NULL ORDER BY started DESC "
                        "LIMIT ?"
                    ),
                    (args.limit,),
                )
            )
        elif args.command in ("show", "export"):
            result = archive(path, args.run_id)
            if args.command == "export":
                if args.prices:
                    from mcp_agent_template.observability.cost import estimate_cost

                    result["cost_estimate"] = estimate_cost(
                        result["events"], json.loads(args.prices.read_text())
                    )
                if args.format == "jsonl":
                    output = (
                        "\n".join(
                            json.dumps({"table": k, "record": row}, ensure_ascii=False)
                            for k, rows in result.items()
                            if isinstance(rows, list)
                            for row in rows
                        )
                        + "\n"
                    )
                    output = (
                        json.dumps(
                            {
                                "manifest": {
                                    k: v for k, v in result.items() if not isinstance(v, list)
                                }
                            },
                            ensure_ascii=False,
                        )
                        + "\n"
                        + output
                    )
                else:
                    output = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
                if args.output:
                    with args.output.open("x", encoding="utf-8") as file:
                        import os

                        os.chmod(args.output, 0o600)
                        file.write(output)
                else:
                    sys.stdout.write(output)
                return 0
        elif args.command == "tail":
            cursor = args.cursor
            while True:
                rows = _decode(
                    read_rows(
                        path,
                        (
                            "SELECT * FROM events WHERE (root_run_id=? OR run_id=?) AND "
                            "cursor>? ORDER BY cursor"
                        ),
                        (args.run_id, args.run_id, cursor),
                    )
                )
                for row in rows:
                    print(json.dumps(row, ensure_ascii=False), flush=True)
                    cursor = row["cursor"]
                if not args.follow:
                    break
                time.sleep(0.25)
            return 0
        elif args.command == "stats":
            rows = read_rows(
                path,
                (
                    "SELECT completion,COUNT(*) count,AVG(ended-started) "
                    "mean_seconds FROM runs WHERE parent_run_id IS NULL AND "
                    "started>=? GROUP BY completion"
                ),
                (args.since,),
            )
            durations = read_rows(
                path,
                (
                    "SELECT ended-started duration FROM runs WHERE parent_run_id "
                    "IS NULL AND started>=? AND ended IS NOT NULL ORDER BY "
                    "duration"
                ),
                (args.since,),
            )
            values = [r["duration"] for r in durations]
            summaries = _decode(
                read_rows(
                    path,
                    (
                        "SELECT summary FROM runs WHERE parent_run_id IS NULL AND "
                        "started>=? AND summary IS NOT NULL"
                    ),
                    (args.since,),
                )
            )
            totals = {}
            for row in summaries:
                for key, value in row["summary"]["data"]["summary"].items():
                    totals[key] = totals.get(key, 0) + value
            waits = _decode(
                read_rows(
                    path,
                    (
                        "SELECT payload FROM events WHERE timestamp>=? AND "
                        "event_name='tool.wait_finished'"
                    ),
                    (args.since,),
                )
            )
            wait_totals = {}
            for row in waits:
                data = row["payload"]["data"]
                group = wait_totals.setdefault(
                    data["kind"], {"seconds": 0, "samples": 0, "not_acquired": 0}
                )
                group["seconds"] += data["duration"]
                group["samples"] += 1
                group["not_acquired"] += int(not data["acquired"])
            volume = read_rows(
                path,
                (
                    "SELECT COUNT(*) records,COALESCE(SUM(LENGTH(CAST(payload AS "
                    "BLOB))),0) bytes FROM events WHERE timestamp>=?"
                ),
                (args.since,),
            )[0]
            health = _decode(
                read_rows(
                    path,
                    (
                        "SELECT payload FROM events WHERE timestamp>=? AND "
                        "event_name='telemetry.session_finished'"
                    ),
                    (args.since,),
                )
            )
            result = {
                "runs": rows,
                "sample_count": len(values),
                "duration_percentiles": {
                    str(p): values[min(len(values) - 1, int((len(values) - 1) * p / 100))]
                    if values
                    else None
                    for p in (50, 95, 99)
                },
                "database_bytes": path.stat().st_size,
                "usage_and_outcomes": totals,
                "usage_note": (
                    "Token totals cover calls_with_usage only; other calls have unknown usage."
                ),
                "waits": wait_totals,
                "event_volume": volume,
                "recording_sessions": health,
            }
        else:
            with closing(connect_readonly(path)) as db:
                check = db.execute("PRAGMA quick_check").fetchone()[0]
            processes = read_rows(path, "SELECT * FROM processes")
            for process in processes:
                process["owner_status"] = (
                    "stopped"
                    if process["stopped"]
                    else (
                        "unknown"
                        if time.time() - process["heartbeat"] > 30
                        else "recently_observed"
                    )
                )
            result = {
                "path": str(path),
                "integrity": check,
                "capture": settings.obs.capture,
                "retention": "indefinite",
                "network_export": False,
                "processes": processes,
                "unknown_runs": read_rows(
                    path,
                    "SELECT run_id,process_instance_id,completion FROM runs WHERE ended IS NULL",
                ),
                "health_snapshots": _decode(
                    read_rows(path, "SELECT * FROM metric_points ORDER BY timestamp DESC LIMIT 1")
                ),
                "langsmith": "Disabled in managed execution contexts and owned subprocesses.",
                "capability_gaps": [
                    (
                        "Unexposed provider retries, provider-hidden data, and "
                        "forced-exit buffers cannot be reconstructed."
                    ),
                    (
                        "Caller-owned callbacks/exporters and HTTP servers are "
                        "outside managed sink ownership."
                    ),
                ],
                "database_bytes": path.stat().st_size,
                "wal_bytes": Path(str(path) + "-wal").stat().st_size
                if Path(str(path) + "-wal").exists()
                else 0,
            }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, sqlite3.Error, ValueError) as exc:
        print(f"Local observation query failed: {type(exc).__name__}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
