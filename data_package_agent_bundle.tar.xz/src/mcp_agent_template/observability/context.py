"""Task-local observation bindings kept separate from agent conversation state.

Context variables correlate nested model/tool events without inserting telemetry
objects into LangGraph messages or checkpoints.  Bindings are active only while
code executes; streamed values are yielded after the execution context is reset.
"""

from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any
from uuid import uuid4

from opentelemetry import trace

ACTIVE_RUNTIME: ContextVar[Any] = ContextVar(
    "mcp_agent_template_observability_runtime", default=None
)
ACTIVE_SCOPE: ContextVar[Any] = ContextVar("mcp_agent_template_observability_scope", default=None)
ACTIVE_TOOL: ContextVar[dict | None] = ContextVar(
    "mcp_agent_template_observability_tool", default=None
)


@dataclass(frozen=True)
class ModelObservation:
    """Carry immutable round/request correlation for the active model attempt."""

    run_id: str
    round_id: str | None
    request_id: str | None
    purpose: str

    def fields(self) -> dict:
        """Return a new JSON-friendly mapping of the correlation fields."""
        return {
            "run_id": self.run_id,
            "round_id": self.round_id,
            "request_id": self.request_id,
            "purpose": self.purpose,
        }


ACTIVE_MODEL: ContextVar[ModelObservation | None] = ContextVar(
    "mcp_agent_template_model_observation", default=None
)


def model_context() -> dict | None:
    """Return a copy of the active model observation fields, if a call is active."""
    value, scope = ACTIVE_MODEL.get(), ACTIVE_SCOPE.get()
    return value.fields() if value and scope and value.run_id == scope.run_id else None


@contextmanager
def model_stage(*, round: bool = False, purpose: str | None = None, reuse: bool = False):
    """Bind request identity to the current task for one model stage.

    A new round receives a new round identifier and defers request identity to
    the effective dispatch hook.  ``reuse`` is for nested capture that must retain
    an already assigned request identifier.
    """
    scope = ACTIVE_SCOPE.get()
    if scope is None or scope.runtime is None:
        yield None
        return
    parent = model_context() or {}
    if reuse and parent.get("request_id"):
        yield parent
        return
    value = ModelObservation(
        scope.run_id,
        str(uuid4()) if round else parent.get("round_id"),
        None if round else str(uuid4()),
        purpose or parent.get("purpose", "agent"),
    )
    token = ACTIVE_MODEL.set(value)
    try:
        yield value.fields()
    finally:
        ACTIVE_MODEL.reset(token)


def emit(name: str, payload: Any) -> str | None:
    """Emit an event through the active task-local observation scope, when configured."""
    runtime = ACTIVE_RUNTIME.get()
    if runtime is not None:
        return runtime.emit(name, payload, scope=ACTIVE_SCOPE.get())


@contextmanager
def operation(name: str, payload: Any = None):
    """Observe a synchronous code block as one nested operation."""
    runtime = ACTIVE_RUNTIME.get()
    if runtime is None:
        yield None
        return
    with runtime.operation(name, payload) as span:
        yield span


@contextmanager
def local_execution(runtime=None, scope=None, span=None):
    """Bind local runtime/span state only for the duration of active execution.

    LangSmith tracing is disabled inside this local recorder to avoid duplicate
    or remote capture.  Tokens are always reset so unrelated tasks cannot inherit
    a completed invocation's scope.
    """
    from langsmith import tracing_context

    runtime_token = ACTIVE_RUNTIME.set(runtime)
    scope_token = ACTIVE_SCOPE.set(scope)
    try:
        with (
            tracing_context(enabled=False),
            (
                trace.use_span(
                    span, end_on_exit=False, record_exception=False, set_status_on_exception=False
                )
                if span is not None
                else nullcontext()
            ),
        ):
            yield
    finally:
        ACTIVE_SCOPE.reset(scope_token)
        ACTIVE_RUNTIME.reset(runtime_token)
