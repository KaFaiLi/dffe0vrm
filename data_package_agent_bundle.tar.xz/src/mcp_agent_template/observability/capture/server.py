"""Drain admitted records before Uvicorn restores termination signals."""

from typing import Any


class CloseObservationsOnShutdown:
    """Close the recorder at the ASGI lifespan boundary, including graceful SIGTERM."""

    def __init__(self, app: Any, runtime: Any) -> None:
        """Wrap an ASGI application while retaining its externally owned runtime."""
        self.app = app
        self.runtime = runtime

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        """Process one protocol call and delegate to the wrapped application."""
        if scope["type"] != "lifespan":
            await self.app(scope, receive, send)
            return

        async def send_with_flush(message: dict) -> None:
            """Drain the runtime before forwarding a terminal lifespan response."""
            if message["type"] in ("lifespan.shutdown.complete", "lifespan.shutdown.failed"):
                await self.runtime.aclose()
            await send(message)

        await self.app(scope, receive, send_with_flush)
