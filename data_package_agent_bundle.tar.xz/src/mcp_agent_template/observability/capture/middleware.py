"""Observe model/tool hooks and reserve each model attempt before dispatch."""

import time
from contextlib import asynccontextmanager, contextmanager

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import ToolMessage
from langgraph.types import Command
from opentelemetry.trace import Status, StatusCode

from mcp_agent_template.observability.capture.requests import request_snapshot
from mcp_agent_template.observability.context import (
    ACTIVE_RUNTIME,
    ACTIVE_SCOPE,
    ACTIVE_TOOL,
    emit,
    model_stage,
    operation,
)


def tool_errors(value):
    """Return the error messages carried by a native tool result, if any."""
    if isinstance(value, ToolMessage):
        return int(value.status == "error")
    if isinstance(value, list):
        return sum(tool_errors(v) for v in value)
    if isinstance(value, Command) and isinstance(value.update, dict):
        from langchain_core.messages import convert_to_messages

        messages = value.update.get("messages", [])
        return tool_errors(
            convert_to_messages(messages if isinstance(messages, list) else [messages])
        )
    return 0


@asynccontextmanager
async def observed_gate(gate, kind):
    """Measure an async capacity gate and record its queue and execution phases."""
    started = time.monotonic()
    emit("tool.wait_started", {"kind": kind, "tool": ACTIVE_TOOL.get()})
    acquired = False
    try:
        await gate.acquire()
        acquired = True
        elapsed = time.monotonic() - started
        emit(
            "tool.wait_finished",
            {"kind": kind, "duration": elapsed, "acquired": True, "tool": ACTIVE_TOOL.get()},
        )
        runtime = ACTIVE_RUNTIME.get()
        if runtime:
            runtime.metric(
                "mcp_agent_template.tool.wait.duration",
                elapsed,
                histogram=True,
                attributes={"kind": kind},
            )
        yield
    finally:
        if acquired:
            gate.release()
        else:
            emit(
                "tool.wait_finished",
                {
                    "kind": kind,
                    "duration": time.monotonic() - started,
                    "acquired": False,
                    "tool": ACTIVE_TOOL.get(),
                },
            )


class ObservationMiddleware(AgentMiddleware):
    """Observe model rounds and tool calls without rewriting their native results."""

    async def awrap_model_call(self, request, handler):
        """Record the round input and keep a round identifier around downstream hooks."""
        if ACTIVE_RUNTIME.get() is None:
            return await handler(request)
        with model_stage(round=True, purpose="agent"):
            with operation("model.round", request_snapshot(request, "round_input")):
                return await handler(request)

    async def awrap_tool_call(self, request, handler):
        """Measure one tool call, including handled error results, without masking failures."""
        runtime, scope = ACTIVE_RUNTIME.get(), ACTIVE_SCOPE.get()
        if runtime is None:
            return await handler(request)
        token = ACTIVE_TOOL.set(request.tool_call)
        started = time.monotonic()
        try:
            with operation("tool.call", request.tool_call) as span:
                if request.tool is None:
                    emit("tool.invalid", {"call": request.tool_call, "error_kind": "validation"})
                result = await handler(request)
                errors = tool_errors(result)
                if errors:
                    span.set_status(Status(StatusCode.ERROR))
                    if scope:
                        scope.count("handled_error_count", errors)
                emit(
                    "tool.finished",
                    {"call": request.tool_call, "result": result, "error_results": errors},
                )
                return result
        finally:
            runtime.metric(
                "mcp_agent_template.tool.calls", attributes={"tool": request.tool_call["name"]}
            )
            runtime.metric(
                "mcp_agent_template.tool.duration",
                time.monotonic() - started,
                histogram=True,
                attributes={"tool": request.tool_call["name"]},
            )
            ACTIVE_TOOL.reset(token)


@contextmanager
def _model_attempt(request, *, purpose=None):
    """Reserve model budget and capture the final effective request before dispatch."""
    # Import lazily because capture utilities can be imported without composing
    # an agent, and eagerly importing runtime policy would create a cycle.
    from mcp_agent_template.agent.runtime.context import require_context

    with model_stage(purpose=purpose):
        require_context(request.runtime.context).budget.reserve_model()
        if ACTIVE_RUNTIME.get() is None:
            yield
        else:
            emit("capture.model_request", request_snapshot(request, "effective_request"))
            with operation("model.dispatch"):
                yield


class EffectiveRequestMiddleware(AgentMiddleware):
    """Identify and reserve each attempt, then capture its effective dispatch."""

    def wrap_model_call(self, request, handler):
        """Apply this policy around a synchronous model call."""
        with _model_attempt(request):
            return handler(request)

    async def awrap_model_call(self, request, handler):
        """Apply this policy around an asynchronous model call."""
        with _model_attempt(request):
            return await handler(request)
