"""Translate native LangChain callbacks into invocation-owned local observations.

Callbacks preserve provider responses and exceptions.  Per-model records retain
span, timing, usage, and correlation state until a terminal callback arrives;
``finish_open`` closes orphaned records when graph cleanup occurs first.
"""

from __future__ import annotations

import time
from uuid import uuid4

from langchain_core.callbacks import AsyncCallbackHandler
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from mcp_agent_template.observability.context import ACTIVE_SCOPE, model_context
from mcp_agent_template.observability.semantics import (
    GENAI_INPUT_TOKENS,
    GENAI_MODEL,
    GENAI_OPERATION,
    GENAI_OUTPUT_TOKENS,
    MAPPING_VERSION,
)


def output_kind(token, chunk):
    """Identify visible output; role/usage-only stream frames are not tokens."""
    message = getattr(chunk, "message", None)
    if token or getattr(message, "content", None):
        return "content"
    if any(
        call.get("name") or call.get("args") for call in getattr(message, "tool_call_chunks", [])
    ):
        return "tool_call"
    if any(
        (getattr(message, "additional_kwargs", {}) or {}).get(key)
        for key in ("reasoning_content", "reasoning", "thinking")
    ):
        return "reasoning"
    return None


class ObservationCallback(AsyncCallbackHandler):
    """Translate native callbacks into events without raising collector failures."""

    run_inline = True
    raise_error = False

    def __init__(self, scope):
        """Bind the fallback invocation scope and initialize open model-call state."""
        self.scope = scope
        self.models = {}

    def observe(self, name, payload, run_id, parent_run_id=None, *, record=None):
        """Emit a callback payload with native and package-level correlation."""
        record = record or self.models.get(run_id)
        scope = record["scope"] if record else ACTIVE_SCOPE.get() or self.scope
        scope.emit(
            name,
            {
                "native_run_id": str(run_id),
                "native_parent_run_id": str(parent_run_id) if parent_run_id else None,
                **payload,
            },
            correlation=record["correlation"] if record else None,
        )

    async def on_chat_model_start(
        self, serialized, messages, *, run_id, parent_run_id=None, metadata=None, **kwargs
    ):
        """Record the chat model start callback without altering native execution."""
        if run_id in self.models:
            # Merged LangChain configuration can expose the same inherited handler
            # through multiple paths; one native run must create only one record.
            return
        scope = ACTIVE_SCOPE.get() or self.scope
        runtime = scope.runtime
        correlation = model_context() or {
            "run_id": scope.run_id,
            "round_id": None,
            "purpose": "unattributed",
        }
        if not correlation.get("request_id"):
            correlation = {**correlation, "request_id": str(uuid4())}
        model = (metadata or {}).get("ls_model_name") or (serialized or {}).get("name", "unknown")
        span = runtime.tracer.start_span(
            f"chat {model}",
            attributes={
                GENAI_OPERATION: "chat",
                GENAI_MODEL: model,
                "mcp_agent_template.mapping_version": MAPPING_VERSION,
                "mcp_agent_template.native_run_id": str(run_id),
                "mcp_agent_template.run_id": scope.run_id,
                **{
                    f"mcp_agent_template.{key}": value
                    for key, value in correlation.items()
                    if value is not None
                },
            },
        )
        self.models[run_id] = {
            "scope": scope,
            "span": span,
            "started": time.monotonic(),
            "first": False,
            "model": model,
            "stream_usage": None,
            "fragments": 0,
            "correlation": correlation,
        }
        scope.count("model_calls")
        with trace.use_span(span, end_on_exit=False):
            params = kwargs.get("invocation_params")
            self.observe(
                "model.started",
                {
                    "request_version": 1,
                    "stage": "native_model_input",
                    "messages": messages,
                    "serialized": serialized,
                    "model": model,
                    "metadata": metadata,
                    "invocation_params": params,
                    "coverage": {
                        "messages": "captured",
                        "invocation_params": "captured" if params is not None else "unavailable",
                        "bound_tools": "captured"
                        if isinstance(params, dict) and "tools" in params
                        else "not_exposed",
                        "provider_http_body": "not_observed",
                    },
                },
                run_id,
                parent_run_id,
            )
        runtime.metric("mcp_agent_template.model.calls", attributes={"model": model})

    async def on_llm_new_token(self, token, *, chunk=None, run_id, parent_run_id=None, **kwargs):
        """Record the llm new token callback without altering native execution."""
        record = self.models.get(run_id)
        if record:
            with trace.use_span(record["span"], end_on_exit=False):
                kind = output_kind(token, chunk)
                if not record["first"] and kind is not None:
                    record["first"] = True
                    latency = time.monotonic() - record["started"]
                    self.observe(
                        "model.first_token",
                        {
                            "duration": latency,
                            "output_kind": kind,
                            "fragment_index": record["fragments"],
                        },
                        run_id,
                        parent_run_id,
                    )
                    record["scope"].runtime.metric(
                        "mcp_agent_template.model.first_token.duration",
                        latency,
                        histogram=True,
                        attributes={"output_kind": kind},
                    )
                self.observe(
                    "capture.model.stream",
                    {"token": token, "chunk": chunk, "fragment_index": record["fragments"]},
                    run_id,
                    parent_run_id,
                )
                record["fragments"] += 1
            usage = getattr(getattr(chunk, "message", None), "usage_metadata", None)
            if usage:
                record["stream_usage"] = usage

    async def on_llm_end(self, response, *, run_id, parent_run_id=None, **kwargs):
        """Record the llm end callback without altering native execution."""
        record = self.models.pop(run_id, None)
        if not record:
            return
        scope, span = record["scope"], record["span"]
        usage = None
        for batch in response.generations:
            for generation in batch:
                usage = (
                    getattr(getattr(generation, "message", None), "usage_metadata", None) or usage
                )
        with trace.use_span(span, end_on_exit=False):
            self.observe(
                "model.finished",
                {
                    "response": response,
                    "usage": usage,
                    "model": record["model"],
                    "duration": time.monotonic() - record["started"],
                    "first_token_observed": record["first"],
                    "usage_coverage": "reported" if usage else "unknown",
                    "completion": "completed",
                },
                run_id,
                parent_run_id,
                record=record,
            )
        if usage:
            scope.count("calls_with_usage")
            for key in ("input_tokens", "output_tokens"):
                count = usage.get(key)
                if count is not None:
                    scope.count(key, count)
                    span.set_attribute(
                        GENAI_INPUT_TOKENS if key == "input_tokens" else GENAI_OUTPUT_TOKENS, count
                    )
                    scope.runtime.metric(
                        "mcp_agent_template.model.tokens",
                        count,
                        attributes={"type": key, "model": record["model"]},
                    )
        else:
            scope.runtime.metric("mcp_agent_template.model.usage_missing")
        scope.runtime.metric(
            "mcp_agent_template.model.duration",
            time.monotonic() - record["started"],
            histogram=True,
            attributes={"model": record["model"]},
        )
        span.end()

    async def on_llm_error(self, error, *, run_id, parent_run_id=None, **kwargs):
        """Record the llm error callback without altering native execution."""
        record = self.models.pop(run_id, None)
        if record:
            from mcp_agent_template.observability.recording.runtime import completion_for

            completion = completion_for(error)
            if completion in ("failed", "timed_out"):
                record["span"].set_status(Status(StatusCode.ERROR))
            with trace.use_span(record["span"], end_on_exit=False):
                self.observe(
                    "model.finished",
                    {
                        "completion": completion,
                        "error": error,
                        "error_kind": "model" if completion in ("failed", "timed_out") else None,
                        "model": record["model"],
                        "usage_coverage": "partial" if record["stream_usage"] else "unknown",
                        "partial_response": kwargs.get("response"),
                        "partial_usage": record["stream_usage"],
                    },
                    run_id,
                    parent_run_id,
                    record=record,
                )
            record["scope"].runtime.metric("mcp_agent_template.model.usage_missing")
            record["span"].end()

    async def on_chain_start(self, serialized, inputs, *, run_id, parent_run_id=None, **kwargs):
        """Record the chain start callback without altering native execution."""
        self.observe(
            "capture.graph.started",
            {
                "serialized": serialized,
                "inputs": inputs,
                "name": kwargs.get("name"),
                "metadata": kwargs.get("metadata"),
            },
            run_id,
            parent_run_id,
        )

    async def on_chain_end(self, outputs, *, run_id, parent_run_id=None, **kwargs):
        """Record the chain end callback without altering native execution."""
        self.observe("capture.graph.finished", {"outputs": outputs}, run_id, parent_run_id)

    async def on_chain_error(self, error, *, run_id, parent_run_id=None, **kwargs):
        """Record the chain error callback without altering native execution."""
        self.observe("capture.graph.failed", {"error": error}, run_id, parent_run_id)

    async def on_tool_start(self, serialized, input_str, *, run_id, parent_run_id=None, **kwargs):
        """Record the tool start callback without altering native execution."""
        self.observe(
            "capture.tool.started",
            {"serialized": serialized, "input": input_str, "inputs": kwargs.get("inputs")},
            run_id,
            parent_run_id,
        )

    async def on_tool_end(self, output, *, run_id, parent_run_id=None, **kwargs):
        """Record the tool end callback without altering native execution."""
        self.observe("capture.tool.finished", {"output": output}, run_id, parent_run_id)

    async def on_tool_error(self, error, *, run_id, parent_run_id=None, **kwargs):
        """Record the tool error callback without altering native execution."""
        self.observe("capture.tool.failed", {"error": error}, run_id, parent_run_id)

    async def on_retry(self, retry_state, *, run_id, parent_run_id=None, **kwargs):
        """Record the retry callback without altering native execution."""
        self.observe(
            "retry.observed",
            {"attempt": retry_state.attempt_number, "idle_for": retry_state.idle_for},
            run_id,
            parent_run_id,
        )

    async def on_custom_event(self, name, data, *, run_id, **kwargs):
        """Record the custom event callback without altering native execution."""
        self.observe("capture.custom", {"name": name, "data": data}, run_id)

    def finish_open(self, scope):
        """Close model records left open when their invocation terminates first."""
        for run_id, record in list(self.models.items()):
            if record["scope"] is scope:
                scope.emit(
                    "model.finished",
                    {
                        "native_run_id": str(run_id),
                        "completion": "unknown",
                        "partial_usage": record["stream_usage"],
                    },
                    correlation=record["correlation"],
                )
                record["span"].end()
                del self.models[run_id]
