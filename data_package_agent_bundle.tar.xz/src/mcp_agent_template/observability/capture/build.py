"""Observe graph composition without changing the shared factory contract."""

from functools import wraps

from mcp_agent_template.observability.context import operation


def observe_build(function):
    """Wrap an async agent builder so runtime-owned composition is observed.

    The wrapper is inert when callers omit ``observability`` and preserves the
    wrapped function's identity through :func:`functools.wraps`.
    """

    @wraps(function)
    async def wrapped(*args, **kwargs):
        """Execute the builder inside an optional runtime activation scope."""
        runtime = kwargs.get("observability")
        if runtime is None:
            return await function(*args, **kwargs)
        with runtime.activate(), operation("build", {"builder": function.__name__}):
            return await function(*args, **kwargs)

    return wrapped
