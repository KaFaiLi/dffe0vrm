"""Capture native agent, model, tool, MCP, and server lifecycle observations locally."""
