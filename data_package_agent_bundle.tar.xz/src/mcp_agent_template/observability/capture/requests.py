"""Declarative, complete request snapshots at public model boundaries."""

from mcp_agent_template.agent.composition import (
    model_descriptor,
    response_descriptor,
    tool_descriptor,
)

REQUEST_VERSION = 1


def request_snapshot(request, stage):
    """Project the effective model request into a serializable observation payload."""
    return {
        "request_version": REQUEST_VERSION,
        "stage": stage,
        "messages": request.messages,
        "system_message": request.system_message,
        "tools": [tool_descriptor(tool) for tool in request.tools],
        "tool_choice": request.tool_choice,
        "response_format": response_descriptor(request.response_format),
        "model": model_descriptor(request.model),
        "model_settings": request.model_settings,
    }
