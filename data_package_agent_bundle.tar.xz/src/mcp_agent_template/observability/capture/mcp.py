"""FastMCP tool-boundary recording using the local recorder and span seams."""

from __future__ import annotations

import sys
from typing import Any

from fastmcp.server.middleware import CallNext, Middleware, MiddlewareContext

from mcp_agent_template.observability.context import ACTIVE_RUNTIME, emit, operation


class MCPObservationMiddleware(Middleware):
    """Record complete server tool arguments/results without changing dispatch."""

    async def on_call_tool(
        self, context: MiddlewareContext[Any], call_next: CallNext[Any, Any]
    ) -> Any:
        """Record one server-side tool request/result pair without changing dispatch."""
        runtime = ACTIVE_RUNTIME.get()
        if runtime is None:
            module = sys.modules.get("mcp_agent_template.observability.recording.otel")
            runtime = module.default_runtime() if module else None
        if runtime is None or not runtime.enabled:
            return await call_next(context)
        with runtime.activate():
            with operation("mcp.server.tool", context.message):
                emit("capture.mcp.server.request", context.message)
                result = await call_next(context)
                emit("capture.mcp.server.result", result)
                return result
