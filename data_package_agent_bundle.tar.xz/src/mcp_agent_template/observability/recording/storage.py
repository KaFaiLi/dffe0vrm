"""Single-owner SQLite writer, lossless payload interning, and read-only queries.

Request threads enqueue already-redacted records into an unbounded in-process
queue; a dedicated writer owns SQLite schema initialization, batching, and WAL
transactions. Queue growth is observable and never converted into silent
sampling or drop-on-full behavior.
"""

from __future__ import annotations

import hashlib
import json
import os
import queue
import re
import sqlite3
import threading
import time
from collections import OrderedDict
from contextlib import closing
from pathlib import Path
from typing import Any
from urllib.parse import quote

SCHEMA_VERSION = 2
# Match complete JSON string literals, including escaped quotes. Interning whole
# literals lets the SQL view reconstruct each original envelope byte for byte.
_JSON_STRING = re.compile(r'"[^"\\]*(?:\\.[^"\\]*)*"')
_PART_MIN_BYTES = 1024
_SCHEMA = """
CREATE TABLE processes (
    process_instance_id TEXT PRIMARY KEY, service TEXT, pid INTEGER,
    started REAL, heartbeat REAL, stopped REAL, health TEXT, unrecorded INTEGER DEFAULT 0
);
CREATE TABLE _events (
    cursor INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT UNIQUE,
    process_instance_id TEXT, source_seq INTEGER, timestamp REAL, event_name TEXT,
    root_run_id TEXT, run_id TEXT, trace_id TEXT, span_id TEXT, payload TEXT,
    UNIQUE(process_instance_id, source_seq)
);
CREATE INDEX events_root ON _events(root_run_id, cursor);
CREATE INDEX events_run ON _events(run_id, cursor);
CREATE INDEX events_request
ON _events(run_id, json_extract(payload,'$.context.request_id'), event_name);
CREATE INDEX events_round
ON _events(run_id, json_extract(payload,'$.context.round_id'), event_name);
CREATE TABLE _runs (
    run_id TEXT PRIMARY KEY, root_run_id TEXT, parent_run_id TEXT,
    process_instance_id TEXT, agent_name TEXT, trace_id TEXT, thread_id TEXT,
    started REAL, ended REAL, completion TEXT, payload TEXT, summary TEXT,
    start_event_id TEXT, finish_event_id TEXT
);
CREATE INDEX runs_root ON _runs(root_run_id, started);
CREATE TABLE spans (
    trace_id TEXT, span_id TEXT, parent_span_id TEXT, process_instance_id TEXT,
    name TEXT, started REAL, ended REAL, payload TEXT,
    PRIMARY KEY(trace_id, span_id)
);
CREATE TABLE metric_points (
    collection_id TEXT, point_index INTEGER, process_instance_id TEXT,
    timestamp REAL, payload TEXT, PRIMARY KEY(collection_id, point_index)
);
CREATE TABLE payload_parts (part_id TEXT PRIMARY KEY, payload TEXT NOT NULL);
CREATE TABLE event_parts (
    event_id TEXT, part_index INTEGER, token TEXT, part_id TEXT,
    PRIMARY KEY(event_id, part_index)
);
CREATE VIEW events AS
        SELECT e.cursor,e.event_id,e.process_instance_id,e.source_seq,e.timestamp,e.event_name,
               e.root_run_id,e.run_id,e.trace_id,e.span_id,
               (WITH RECURSIVE expanded(step,payload) AS (
                    SELECT 0,e.payload
                    UNION ALL
                    SELECT x.step+1,replace(x.payload,r.token,p.payload)
                    FROM expanded x JOIN event_parts r
                      ON r.event_id=e.event_id AND r.part_index=x.step+1
                    JOIN payload_parts p ON p.part_id=r.part_id
                ) SELECT payload FROM expanded ORDER BY step DESC LIMIT 1) AS payload
        FROM _events e;
CREATE VIEW captures AS
    SELECT event_id,run_id,payload FROM events WHERE event_name LIKE 'capture.%';
CREATE VIEW logs AS
    SELECT event_id,run_id,payload FROM events WHERE event_name='log';
CREATE VIEW feedback AS
    SELECT event_id,run_id,payload FROM events
    WHERE event_name IN ('feedback.recorded','evaluation.finished');
CREATE VIEW runs AS
        SELECT r.run_id,r.root_run_id,r.parent_run_id,r.process_instance_id,r.agent_name,
               r.trace_id,r.thread_id,r.started,r.ended,r.completion,
               coalesce(s.payload,r.payload) AS payload,coalesce(f.payload,r.summary) AS summary
        FROM _runs r LEFT JOIN events s ON s.event_id=r.start_event_id
                     LEFT JOIN events f ON f.event_id=r.finish_event_id;
"""


def _payload_parts(encoded: str) -> tuple[str, list[tuple[str, str, str]]]:
    """Intern exact redacted content literals, retaining every observation's envelope.

    Effective requests, native responses, tool outcomes and final states keep
    their own identities and semantics. Only byte-identical content is shared.
    Tokens are deliberately absent from the source, so reconstruction cannot
    replace a caller's literal or recursively replace content inside a part.
    """
    from uuid import uuid4

    parts: dict[str, tuple[str, str, str]] = {}

    def replace(match: re.Match) -> str:
        """Replace a large repeated JSON literal with a collision-resistant token."""
        literal = match.group()
        if len(literal) < _PART_MIN_BYTES // 4 or len(literal.encode("utf-8")) < _PART_MIN_BYTES:
            return literal
        if literal not in parts:
            part_id = hashlib.sha256(literal.encode("utf-8")).hexdigest()
            token = json.dumps(f"\x00obs:{uuid4()}")
            while token in encoded:
                token = json.dumps(f"\x00obs:{uuid4()}")
            parts[literal] = (token, part_id, literal)
        return parts[literal][0]

    compact = _JSON_STRING.sub(replace, encoded)
    return compact, list(parts.values())


class LocalStore:
    """Own one background SQLite writer without truncation, sampling, or deletion."""

    def __init__(self, path: Path, flush_interval: float = 0.25) -> None:
        """Initialize queue, health counters, and lifecycle state without I/O."""
        self.path = path
        self.flush_interval = flush_interval
        self.queue: queue.Queue = queue.Queue()
        self.thread: threading.Thread | None = None
        self.ready = threading.Event()
        self.error: str | None = None
        self.failed = False
        self.closed = False
        self.pending_bytes = 0
        self.pending_records = 0
        self.peak_pending_bytes = 0
        self.peak_pending_records = 0
        self.unrecorded = 0
        self.written = 0
        self.write_seconds = 0.0
        self.oldest_pending: float | None = None
        self._lock = threading.Lock()
        self._accepted_parts: OrderedDict[str, None] = OrderedDict()

    def start(self) -> None:
        """Start the writer and wait for current-schema initialization or rejection.

        Empty databases are initialized atomically; existing version-2 databases
        keep their schema and records. Unsupported or populated unversioned stores
        fail with RuntimeError after the worker has stopped. No migration occurs.
        """
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.path.parent, 0o700)
        self.thread = threading.Thread(
            target=self._work, name="mcp_agent_template-observability-writer", daemon=True
        )
        self.thread.start()
        self.ready.wait()
        if self.failed:
            self.thread.join()
            raise RuntimeError(f"Cannot initialize local observation store ({self.error}).")

    def enqueue(self, kind: str, record: dict) -> bool:
        """Admit a record without SQLite I/O, returning false after failure or close."""
        with self._lock:
            if self.failed or self.closed:
                self.unrecorded += 1
                return False
            record = dict(record)
            if kind == "event":
                # This seam receives already-redacted envelopes. Payload interning
                # is in-memory; SQLite work remains on the writer thread.
                if record["event_name"] in ("run.started", "run.finished"):
                    data = json.loads(record["payload"])["data"]
                    record["run_data"] = {
                        key: data.get(key)
                        for key in ("agent_name", "parent_run_id", "thread_id", "completion")
                    }
                record["payload"], parts = _payload_parts(record["payload"])
                record["part_refs"] = [(token, part_id) for token, part_id, _ in parts]
                record["new_parts"] = [
                    (part_id, literal)
                    for _, part_id, literal in parts
                    if part_id not in self._accepted_parts
                ]
                for _, part_id, _ in parts:
                    self._accepted_parts[part_id] = None
                    self._accepted_parts.move_to_end(part_id)
                # Eviction forgets only the producer-side optimization and may
                # repeat ``INSERT OR IGNORE``; durable content remains in SQLite.
                while len(self._accepted_parts) > 4096:
                    self._accepted_parts.popitem(last=False)
            size = len(record.get("payload", "").encode("utf-8")) + sum(
                len(literal.encode("utf-8")) for _, literal in record.get("new_parts", ())
            )
            self.pending_bytes += size
            self.pending_records += 1
            self.peak_pending_bytes = max(self.peak_pending_bytes, self.pending_bytes)
            self.peak_pending_records = max(self.peak_pending_records, self.pending_records)
            if self.oldest_pending is None:
                self.oldest_pending = time.monotonic()
            self.queue.put((kind, record, size))
        return True

    def health(self) -> dict:
        """Return an atomic snapshot of backlog, throughput, and failure counters."""
        with self._lock:
            return {
                "pending_records": self.pending_records,
                "pending_bytes": self.pending_bytes,
                "oldest_pending_seconds": time.monotonic() - self.oldest_pending
                if self.oldest_pending
                else 0,
                "peak_pending_records": self.peak_pending_records,
                "peak_pending_bytes": self.peak_pending_bytes,
                "written_records": self.written,
                "write_seconds": self.write_seconds,
                "unrecorded": self.unrecorded,
                "failed": self.failed,
            }

    def flush(self) -> bool:
        """Wait for admitted records without allowing shutdown to strand the barrier.

        Flush and close serialize queue admission under the lifecycle lock. The
        wait itself must release that lock so the writer can finish its work.
        Calls after closure retain the existing health-only return contract.
        """
        with self._lock:
            if self.closed or self.failed:
                return not self.failed
            barrier = threading.Event()
            self.queue.put(("flush", barrier, 0))
        barrier.wait()
        return not self.failed

    def close(self) -> bool:
        """Stop after draining admitted records and join the writer thread."""
        with self._lock:
            if self.closed:
                return not self.failed
            self.closed = True
            self.queue.put(("stop", None, 0))
        if self.thread:
            self.thread.join()
        return not self.failed

    def _work(self) -> None:
        """Own schema setup, batching, transactions, barriers, and terminal state."""
        connection = None
        try:
            connection = sqlite3.connect(self.path, timeout=5)
            if connection.execute("PRAGMA user_version").fetchone()[0] not in (0, SCHEMA_VERSION):
                raise ValueError("Unsupported observation schema version")
            os.chmod(self.path, 0o600)
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA synchronous=NORMAL")
            connection.execute("BEGIN IMMEDIATE")
            with connection:
                # Read after acquiring the write lock because another process may
                # have initialized the database while this writer waited.
                version = connection.execute("PRAGMA user_version").fetchone()[0]
                if version not in (0, SCHEMA_VERSION):
                    raise ValueError("Unsupported observation schema version")
                if version == 0:
                    if connection.execute(
                        "SELECT 1 FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' LIMIT 1"
                    ).fetchone():
                        raise ValueError("Unversioned observation database is not empty")
                    # Execute individually to keep concurrent initialization
                    # inside this transaction rather than implicitly committing.
                    for statement in _SCHEMA.split(";"):
                        if statement.strip():
                            connection.execute(statement)
                    connection.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
        except Exception as exc:
            self.failed = True
            self.error = type(exc).__name__
            self.ready.set()
            if connection:
                connection.close()
            return
        self.ready.set()
        try:
            while True:
                item = self.queue.get()
                if item[0] in ("flush", "stop"):
                    if item[0] == "flush":
                        item[1].set()
                        continue
                    break
                batch = [item]
                barrier = None
                deadline = time.monotonic() + self.flush_interval
                while time.monotonic() < deadline:
                    try:
                        next_item = self.queue.get(timeout=max(0, deadline - time.monotonic()))
                    except queue.Empty:
                        break
                    if next_item[0] in ("flush", "stop"):
                        barrier = next_item
                        break
                    batch.append(next_item)
                if not self.failed:
                    started = time.monotonic()
                    try:
                        while True:
                            try:
                                with connection:
                                    for kind, record, _ in batch:
                                        self._write(connection, kind, record)
                                break
                            except sqlite3.OperationalError as exc:
                                if getattr(exc, "sqlite_errorcode", None) not in (
                                    sqlite3.SQLITE_BUSY,
                                    sqlite3.SQLITE_LOCKED,
                                ):
                                    raise
                                if time.monotonic() - started >= 30:
                                    # Persistent locking must not prevent shutdown indefinitely.
                                    raise
                                time.sleep(0.02)
                        self.written += len(batch)
                    except Exception as exc:
                        self.failed = True
                        self.error = type(exc).__name__
                    self.write_seconds += time.monotonic() - started
                with self._lock:
                    self.pending_bytes -= sum(item[2] for item in batch)
                    self.pending_records -= len(batch)
                    if self.failed:
                        self.unrecorded += len(batch)
                    if self.pending_records == 0:
                        self.oldest_pending = None
                if barrier:
                    if barrier[0] == "stop":
                        break
                    barrier[1].set()
        finally:
            connection.close()

    @staticmethod
    def _write(db: sqlite3.Connection, kind: str, r: dict) -> None:
        """Apply one normalized queued record to its SQLite table or view backing."""
        if kind == "event":
            values = tuple(
                r.get(k)
                for k in (
                    "event_id",
                    "process_instance_id",
                    "source_seq",
                    "timestamp",
                    "event_name",
                    "root_run_id",
                    "run_id",
                    "trace_id",
                    "span_id",
                    "payload",
                )
            )
            cursor = db.execute(
                (
                    "INSERT OR IGNORE INTO _events "
                    "(event_id,process_instance_id,source_seq,timestamp,event_name,"
                    "root_run_id,run_id,trace_id,span_id,payload) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?)"
                ),
                values,
            )
            # A duplicate identity can still carry a part used by a later
            # accepted record. Persist queued parts before the identity guard.
            db.executemany(
                "INSERT OR IGNORE INTO payload_parts VALUES (?,?)", r.get("new_parts", ())
            )
            if cursor.rowcount == 0:
                return
            db.executemany(
                "INSERT INTO event_parts VALUES (?,?,?,?)",
                (
                    (r["event_id"], i, token, part_id)
                    for i, (token, part_id) in enumerate(r.get("part_refs", ()), 1)
                ),
            )
            data = r.get("run_data", {})
            if r["event_name"] == "run.started":
                db.execute(
                    "INSERT INTO _runs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        r["run_id"],
                        r["root_run_id"],
                        data.get("parent_run_id"),
                        r["process_instance_id"],
                        data["agent_name"],
                        r["trace_id"],
                        data.get("thread_id"),
                        r["timestamp"],
                        None,
                        "running",
                        None,
                        None,
                        r["event_id"],
                        None,
                    ),
                )
            elif r["event_name"] == "run.finished":
                db.execute(
                    "UPDATE _runs SET ended=?,completion=?,finish_event_id=? WHERE run_id=?",
                    (r["timestamp"], data["completion"], r["event_id"], r["run_id"]),
                )
        elif kind == "span":
            db.execute(
                "INSERT OR REPLACE INTO spans VALUES (?,?,?,?,?,?,?,?)",
                tuple(
                    r[k]
                    for k in (
                        "trace_id",
                        "span_id",
                        "parent_span_id",
                        "process_instance_id",
                        "name",
                        "started",
                        "ended",
                        "payload",
                    )
                ),
            )
        elif kind == "metric":
            db.execute(
                "INSERT OR IGNORE INTO metric_points VALUES (?,?,?,?,?)",
                tuple(
                    r[k]
                    for k in (
                        "collection_id",
                        "point_index",
                        "process_instance_id",
                        "timestamp",
                        "payload",
                    )
                ),
            )
        elif kind == "process":
            db.execute(
                (
                    "INSERT INTO processes VALUES (?,?,?,?,?,?,?,?) ON "
                    "CONFLICT(process_instance_id) DO UPDATE SET "
                    "heartbeat=excluded.heartbeat,stopped=excluded.stopped,health=excluded.health,unrecorded=excluded.unrecorded"
                ),
                tuple(
                    r[k]
                    for k in (
                        "process_instance_id",
                        "service",
                        "pid",
                        "started",
                        "heartbeat",
                        "stopped",
                        "health",
                        "unrecorded",
                    )
                ),
            )


def connect_readonly(path: Path) -> sqlite3.Connection:
    """Open a current-schema SQLite recording read-only without changing or migrating it."""
    connection = sqlite3.connect(
        f"file:{quote(str(path.resolve()))}?mode=ro", uri=True, timeout=0.1
    )
    connection.row_factory = sqlite3.Row
    if connection.execute("PRAGMA user_version").fetchone()[0] != SCHEMA_VERSION:
        connection.close()
        raise ValueError("Unsupported observation schema version")
    return connection


def read_rows(path: Path, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
    """Execute a read-only query and return rows as plain dictionaries."""
    with closing(connect_readonly(path)) as db:
        return [dict(row) for row in db.execute(sql, params)]
