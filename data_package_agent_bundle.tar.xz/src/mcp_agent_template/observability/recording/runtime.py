"""Explicit ownership of local telemetry resources and invocation scopes.

Applications create and close ``ObservabilityRuntime`` instances; importing the
package never allocates a writer, changes the host's OTel provider, or installs a
log handler.  Producer paths redact and enqueue records, while the owned store
performs all SQLite work on its background thread.
"""

from __future__ import annotations

import asyncio
import logging
import os
import threading
import time
import uuid
from collections.abc import Sequence
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

from langgraph.errors import GraphInterrupt
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from mcp_agent_template.observability.context import (
    ACTIVE_RUNTIME,
    ACTIVE_SCOPE,
    local_execution,
    model_context,
)
from mcp_agent_template.observability.privacy import Redactor
from mcp_agent_template.observability.recording.storage import LocalStore
from mcp_agent_template.observability.semantics import error_kind

if TYPE_CHECKING:
    from langchain_core.runnables import RunnableConfig

    from mcp_agent_template.agent.runtime.context import RunContext
    from mcp_agent_template.agent.runtime.invocation import InvocationScope
    from mcp_agent_template.config import Settings


def identity() -> tuple[str | None, str | None]:
    """Return the task-local run and span identifiers used for correlation."""
    span = trace.get_current_span().get_span_context()
    return (f"{span.trace_id:032x}", f"{span.span_id:016x}") if span.is_valid else (None, None)


def completion_for(exc: BaseException) -> str:
    """Map an invocation exception to its stable terminal completion label."""
    if isinstance(exc, GraphInterrupt):
        return "interrupted"
    if isinstance(exc, asyncio.CancelledError):
        return "cancelled"
    if isinstance(exc, TimeoutError):
        return "timed_out"
    if isinstance(exc, GeneratorExit):
        return "closed_early"
    return "failed"


def has_interrupt(value: Any) -> bool:
    """Return whether a nested result contains a LangGraph interrupt marker."""
    if getattr(value, "interrupts", None):
        return True
    if isinstance(value, dict):
        if value.get("type") in {"updates", "values"}:
            return has_interrupt(value.get("data"))
        return bool(value.get("__interrupt__"))
    if isinstance(value, tuple):
        return any(has_interrupt(item) for item in value)
    return False


async def settle_owned(task: asyncio.Task) -> bool:
    """Join owned work even after repeated cancellation; the caller reads its result."""
    cancelled = False
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            cancelled = True
        except BaseException:
            break
    return cancelled


class LocalLogHandler(logging.Handler):
    """Forward standard-library records only when this runtime owns the context."""

    def __init__(self, runtime):
        """Retain the owning runtime without registering the handler globally."""
        super().__init__()
        self.runtime = runtime

    def emit(self, record):
        """Emit an event through the active task-local observation scope, when configured."""
        from mcp_agent_template.observability.recording.otel import default_runtime

        if (ACTIVE_RUNTIME.get() or default_runtime()) is not self.runtime:
            return
        if record.name.startswith("opentelemetry"):
            return  # Recording OTel diagnostics would recursively create more diagnostics.
        try:
            standard = logging.makeLogRecord({}).__dict__.keys()
            payload = {
                "message": record.getMessage(),
                "level": record.levelname,
                "logger": record.name,
                "path": record.pathname,
                "line": record.lineno,
                "exception": record.exc_info[1] if record.exc_info else None,
                "extras": {
                    k: v
                    for k, v in vars(record).items()
                    if k not in standard and k not in {"message", "asctime"}
                },
            }
            self.runtime.emit("log", payload, scope=ACTIVE_SCOPE.get())
        except Exception as exc:
            self.runtime.recording_error(exc)


class ObservabilityRuntime:
    """Own one optional local recorder and all of its OTel/logging resources.

    Lifecycle is single-use and supports synchronous or asynchronous ownership.
    ``mode='off'`` keeps the same invocation interface but allocates no SQLite or
    OTel resources.  Collector failures are counted and warned safely; they do
    not replace a successful agent result or original agent exception.
    """

    def __init__(
        self, settings: Settings, *, tracer_provider=None, process_default: bool = False
    ) -> None:
        """Snapshot settings and allocate inert resource objects without starting them."""
        self.settings = settings.model_copy(deep=True)
        self.redactor = Redactor.for_settings(settings)
        self.session_id = str(uuid.uuid4())
        self.process_id = str(uuid.uuid4())
        self.path = settings.resolve_path(settings.obs.dir) / "observability.sqlite3"
        self.store = LocalStore(self.path, settings.obs.flush_interval_ms / 1000)
        self.provider = tracer_provider
        self.process_default = process_default
        self.started = None
        self.closed = False
        self.sequence = 0
        self.errors = 0
        self.serialization_seconds = 0.0
        self.serialized_bytes = 0
        self._warned = False
        self._lock = threading.RLock()
        self._lifecycle_lock = threading.RLock()
        self._startup_task = None
        self._close_task = None
        self._otel = None
        self._instruments = {}
        self.tracer = trace.NoOpTracer()
        self.meter_provider = None
        self.meter = None
        self.log_handler = LocalLogHandler(self)
        self.active_scopes = set()

    @classmethod
    def local(cls, settings: Settings, **kwargs: Any) -> ObservabilityRuntime:
        """Construct an application-owned local runtime without starting it."""
        return cls(settings, **kwargs)

    @property
    def enabled(self) -> bool:
        """Return whether local recording is started, enabled, and not yet closed."""
        return self.started is not None and not self.closed and self.settings.obs.mode == "local"

    def start(self) -> ObservabilityRuntime:
        """Start the runtime once under the synchronous lifecycle lock."""
        with self._lifecycle_lock:
            return self._start()

    def _start(self) -> ObservabilityRuntime:
        """Start owned storage, OTel routing, metrics, logging, and heartbeat state."""
        if self.started is not None or self.closed:
            raise ValueError("Recording runtime already started or closed.")
        self.started = time.time()
        if self.settings.obs.mode == "off":
            return self
        try:
            from mcp_agent_template.observability.recording import otel
        except ImportError as exc:
            raise RuntimeError(
                "Local recording requires opentelemetry-sdk; "
                "install dependencies or set OBS_MODE=off."
            ) from exc
        self._otel = otel
        try:
            self.store.start()
            self.tracer = otel.register(self, self.provider, self.process_default)
            self.meter_provider, self.meter = otel.metrics(self)
            logging.getLogger().addHandler(self.log_handler)
            self.heartbeat()
        except BaseException as startup_error:
            self.recording_error(startup_error)
            try:
                self.close()
            except BaseException as cleanup_error:
                self.recording_error(cleanup_error)
            raise
        return self

    async def __aenter__(self):
        """Enter the managed lifecycle and return the active resource."""
        if self._startup_task is not None:
            raise ValueError("Recording runtime already started or closed.")
        self._startup_task = asyncio.create_task(
            asyncio.to_thread(self.start), name="mcp_agent_template-recorder-start"
        )
        cancelled = await settle_owned(self._startup_task)
        if cancelled:
            error = self._startup_task.exception() if not self._startup_task.cancelled() else None
            if error is not None:
                self.recording_error(error)
            try:
                await self.aclose()
            finally:
                raise asyncio.CancelledError
        return self._startup_task.result()

    async def __aexit__(self, *args):
        """Finish the managed lifecycle while preserving any caller exception."""
        await self.aclose()

    def __enter__(self):
        """Enter the managed lifecycle and return the active resource."""
        return self.start()

    def __exit__(self, *args):
        """Finish the managed lifecycle while preserving any caller exception."""
        self.close()

    def heartbeat(self, stopped: bool = False) -> None:
        """Publish process health and writer backlog to the local store."""
        if self.enabled:
            if self.store.failed:
                self.recording_error(RuntimeError("local writer failed"))
            self.store.enqueue(
                "process",
                {
                    "process_instance_id": self.process_id,
                    "service": self.settings.obs.service_name,
                    "pid": os.getpid(),
                    "started": self.started,
                    "heartbeat": time.time(),
                    "stopped": time.time() if stopped else None,
                    "health": "degraded" if self.errors or self.store.failed else "healthy",
                    "unrecorded": self.errors + self.store.unrecorded,
                },
            )

    def recording_error(self, exc: BaseException) -> None:
        """Count a collector failure and emit at most one sanitized warning."""
        self.errors += 1
        scope = ACTIVE_SCOPE.get()
        if scope and scope.runtime is self:
            scope.count("recording_errors")
        if not self._warned:
            self._warned = True
            # Error type only: errors may embed credentials or arbitrary payloads.
            import sys

            print(
                f"Local observability degraded ({type(exc).__name__}); "
                "recording may be incomplete.",
                file=sys.stderr,
            )

    def emit(
        self,
        name: str,
        payload: Any,
        *,
        scope=None,
        correlation=None,
        redactions: Sequence[str] = (),
    ) -> str | None:
        """Record one envelope, preserving prior redaction paths on copied definitions.

        Payloads are always redacted again using the active runtime's settings.
        ``redactions`` carries paths already removed from a saved build receipt;
        it does not bypass serialization or credential protection.
        """
        if not self.enabled:
            return
        started = time.perf_counter()
        try:
            correlation = correlation if correlation is not None else model_context()
            if correlation and (scope is None or correlation.get("run_id") != scope.run_id):
                correlation = None
            encoded = self.redactor.encode(payload, context=correlation, redactions=redactions)
        except Exception as exc:
            self.recording_error(exc)
            name, encoded = (
                "telemetry.serialization_failed",
                self.redactor.encode(
                    {"source_event": name, "error_type": type(exc).__name__}, context=correlation
                ),
            )
        self.serialization_seconds += time.perf_counter() - started
        self.serialized_bytes += len(encoded.encode("utf-8"))
        trace_id, span_id = identity()
        if scope and scope.trace_id and scope.trace_id != trace_id:
            trace_id, span_id = scope.trace_id, None
        with self._lock:
            self.sequence += 1
            event_id = str(uuid.uuid4())
            accepted = self.store.enqueue(
                "event",
                {
                    "event_id": event_id,
                    "process_instance_id": self.process_id,
                    "source_seq": self.sequence,
                    "timestamp": time.time(),
                    "event_name": name,
                    "root_run_id": scope.root_run_id if scope else None,
                    "run_id": scope.run_id if scope else None,
                    "trace_id": trace_id or (scope.trace_id if scope else None),
                    "span_id": span_id,
                    "payload": encoded,
                },
            )
        if not accepted:
            self.recording_error(RuntimeError("local writer unavailable"))
        return event_id if accepted else None

    def metric(
        self,
        name: str,
        value: int | float = 1,
        *,
        histogram: bool = False,
        attributes: dict | None = None,
        active: bool = False,
    ) -> None:
        """Update a lazily created counter, histogram, or up/down counter."""
        if not self.enabled or self.meter is None:
            return
        try:
            with self._lock:
                if name not in self._instruments:
                    factory = (
                        self.meter.create_histogram
                        if histogram
                        else (
                            self.meter.create_up_down_counter
                            if active
                            else self.meter.create_counter
                        )
                    )
                    self._instruments[name] = factory(name, unit="s" if histogram else "1")
                instrument = self._instruments[name]
            clean, _ = self.redactor.project(attributes or {})
            if histogram:
                instrument.record(value, clean)
            else:
                instrument.add(value, clean)
        except Exception as exc:
            self.recording_error(exc)

    @contextmanager
    def activate(self):
        """Bind this runtime during active execution when recording is enabled."""
        with local_execution(self if self.enabled else None):
            yield self

    @contextmanager
    def operation(self, name, payload=None):
        """Observe a synchronous code block as one nested operation."""
        if not self.enabled:
            yield None
            return
        scope = ACTIVE_SCOPE.get()
        started = time.monotonic()
        with self.tracer.start_as_current_span(
            name, record_exception=False, set_status_on_exception=False
        ) as span:
            self.emit(f"{name}.started", payload, scope=scope)
            try:
                yield span
            except BaseException as exc:
                span.set_status(
                    Status(
                        StatusCode.ERROR
                        if completion_for(exc) in ("failed", "timed_out")
                        else StatusCode.UNSET
                    )
                )
                self.emit(
                    f"{name}.finished",
                    {
                        "completion": completion_for(exc),
                        "error": exc,
                        "error_kind": error_kind(exc),
                        "duration": time.monotonic() - started,
                    },
                    scope=scope,
                )
                raise
            else:
                self.emit(
                    f"{name}.finished",
                    {"completion": "completed", "duration": time.monotonic() - started},
                    scope=scope,
                )

    def observe_invocation(
        self,
        agent_name: str = "agent",
        *,
        context: RunContext | None = None,
        config: RunnableConfig | None = None,
        parent=None,
    ) -> InvocationScope:
        """Create an observation scope bound to this bundle and optional runtime context."""
        from mcp_agent_template.agent.runtime.invocation import InvocationScope

        return InvocationScope(self if self.enabled else None, agent_name, context, config, parent)

    def flush(self) -> bool:
        """Synchronously flush metric readers, spans, and admitted store records."""
        if self.meter_provider:
            self.meter_provider.force_flush()
        self.heartbeat()
        healthy = self.store.flush() if self.enabled else True
        if not healthy:
            self.recording_error(RuntimeError("local writer failed"))
        return healthy

    async def aflush(self) -> bool:
        """Asynchronously flush while preserving the native result contract."""
        return await asyncio.to_thread(self.flush)

    def record_feedback(
        self,
        run_id: str,
        value: Any,
        *,
        evaluator: str | None = None,
        evaluator_version: str | None = None,
        dataset: str | None = None,
        example: str | None = None,
    ) -> None:
        """Append human feedback or externally computed evaluation results locally."""
        from types import SimpleNamespace

        from mcp_agent_template.observability.recording.storage import read_rows

        if not self.enabled:
            raise ValueError("Start a local recording runtime before recording feedback.")
        self.store.flush()
        rows = read_rows(self.path, "SELECT * FROM runs WHERE run_id=?", (run_id,))
        if not rows:
            raise ValueError("Run not found")
        scope = SimpleNamespace(**rows[0])
        self.emit(
            "evaluation.finished" if evaluator else "feedback.recorded",
            {
                "value": value,
                "evaluator": evaluator,
                "evaluator_version": evaluator_version,
                "dataset": dataset,
                "example": example,
            },
            scope=scope,
        )

    def close(self) -> None:
        """Synchronously close the runtime once under the lifecycle lock."""
        with self._lifecycle_lock:
            self._close()

    def _close(self) -> None:
        """Release owned handlers, providers, registrations, and storage in order."""
        if self.closed:
            return
        if self.active_scopes:
            raise RuntimeError(
                "Close active invocation scopes before closing their recording runtime."
            )
        failures = []

        def finish(operation):
            """Run one cleanup operation while retaining later cleanup opportunities."""
            try:
                operation()
            except BaseException as exc:
                self.recording_error(exc)
                failures.append(exc)

        if self.settings.obs.mode == "local" and self.started and self._otel is not None:
            if self.meter_provider:
                finish(self.meter_provider.force_flush)
                finish(self.meter_provider.shutdown)
            finish(
                lambda: self.emit(
                    "telemetry.session_finished",
                    {
                        **self.store.health(),
                        "serialization_seconds": self.serialization_seconds,
                        "serialized_bytes": self.serialized_bytes,
                        "recording_errors": self.errors,
                    },
                )
            )
            finish(lambda: self.heartbeat(stopped=True))
            finish(lambda: logging.getLogger().removeHandler(self.log_handler))
            finish(lambda: self._otel.unregister(self))

            def close_store():
                """Close the writer and convert a reported failure into runtime health."""
                if not self.store.close():
                    self.recording_error(RuntimeError("local writer failed"))

            finish(close_store)
        self.closed = True
        if failures:
            raise failures[0]

    async def aclose(self) -> None:
        """Asynchronously close while preserving the native result contract."""
        cancelled = False
        if self._startup_task is not None:
            cancelled = await settle_owned(self._startup_task)
            # Observe startup failure without replacing the original exception.
            if not self._startup_task.cancelled():
                self._startup_task.exception()
        if self._close_task is None:
            self._close_task = asyncio.create_task(
                asyncio.to_thread(self.close), name="mcp_agent_template-recorder-close"
            )
        cancelled = await settle_owned(self._close_task) or cancelled
        try:
            self._close_task.result()
        except BaseException:
            if not self.closed:
                self._close_task = None
            if cancelled:
                raise asyncio.CancelledError from None
            raise
        if cancelled:
            raise asyncio.CancelledError
