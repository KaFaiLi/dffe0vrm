"""Public OpenTelemetry SDK integration with local-runtime routing.

One process tracer provider can serve multiple application-owned recording
runtimes.  A private session attribute routes each ended span to its owner and is
removed before persistence.  No exporter sends telemetry to a remote service.
"""

from __future__ import annotations

import json
import threading
import time
import uuid

from opentelemetry import trace
from opentelemetry.metrics import Observation
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import (
    MetricExporter,
    MetricExportResult,
    PeriodicExportingMetricReader,
)
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import SpanLimits, SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.sampling import ALWAYS_ON

from mcp_agent_template.observability.context import ACTIVE_RUNTIME

_SESSION = "mcp_agent_template.internal.recording_session"
_LOCK = threading.Lock()
_RUNTIMES = {}
_DEFAULT = None
_PROVIDER = None


class LocalSpanProcessor(SpanProcessor):
    """Route completed spans to the runtime that was active when they started."""

    def on_start(self, span, parent_context=None):
        """Record the start callback without altering native execution."""
        runtime = ACTIVE_RUNTIME.get() or _DEFAULT
        if runtime is not None and runtime.session_id in _RUNTIMES:
            span.set_attribute(_SESSION, runtime.session_id)
            span.set_attribute("mcp_agent_template.service.name", runtime.settings.obs.service_name)
            span.set_attribute("mcp_agent_template.process_instance_id", runtime.process_id)

    def on_end(self, span):
        """Record the end callback without altering native execution."""
        runtime = _RUNTIMES.get((span.attributes or {}).get(_SESSION))
        if runtime is not None:
            try:
                document = json.loads(span.to_json())
                document.get("attributes", {}).pop(_SESSION, None)
                accepted = runtime.store.enqueue(
                    "span",
                    {
                        "trace_id": f"{span.context.trace_id:032x}",
                        "span_id": f"{span.context.span_id:016x}",
                        "parent_span_id": f"{span.parent.span_id:016x}" if span.parent else None,
                        "process_instance_id": runtime.process_id,
                        "name": runtime.redactor.text(span.name),
                        "started": span.start_time / 1e9,
                        "ended": span.end_time / 1e9,
                        "payload": runtime.redactor.encode(document),
                    },
                )
                if not accepted:
                    runtime.recording_error(RuntimeError("local writer unavailable"))
            except Exception as exc:
                runtime.recording_error(exc)

    def shutdown(self):
        """Perform no work because this processor owns no background resources."""
        pass

    def force_flush(self, timeout_millis=30000):
        """Report success because ended spans are synchronously admitted to storage."""
        return True  # Ended spans have already been admitted to the local writer.


def register(runtime, provider=None, process_default=False):
    """Register a runtime with the process tracer provider and return its tracer.

    The first runtime may install a provider only when the host still exposes the
    proxy provider.  Embedding hosts must pass their already installed provider
    explicitly; conflicting ownership is rejected.
    """
    global _PROVIDER, _DEFAULT
    with _LOCK:
        if _PROVIDER is None:
            existing = trace.get_tracer_provider()
            if provider is not None:
                if existing is not provider:
                    raise ValueError(
                        "Install the supplied tracer provider in the host before recording."
                    )
                _PROVIDER = provider
            elif isinstance(existing, trace.ProxyTracerProvider):
                limits = SpanLimits(
                    **{
                        name: SpanLimits.UNSET
                        for name in (
                            "max_attributes",
                            "max_events",
                            "max_links",
                            "max_span_attributes",
                            "max_event_attributes",
                            "max_link_attributes",
                            "max_attribute_length",
                            "max_span_attribute_length",
                        )
                    }
                )
                _PROVIDER = TracerProvider(
                    sampler=ALWAYS_ON,
                    span_limits=limits,
                    resource=Resource({"service.name": runtime.settings.obs.service_name}),
                )
                trace.set_tracer_provider(_PROVIDER)
            else:
                raise ValueError(
                    "An embedding host already owns OTel; explicitly supply its tracer provider."
                )
            _PROVIDER.add_span_processor(LocalSpanProcessor())
        elif provider is not None and provider is not _PROVIDER:
            raise ValueError("Conflicting process tracer provider ownership.")
        if process_default and _DEFAULT is not None:
            raise ValueError("A process-default recording session is already active.")
        _RUNTIMES[runtime.session_id] = runtime
        if process_default:
            _DEFAULT = runtime
        return _PROVIDER.get_tracer("mcp_agent_template.observability", "1")


def unregister(runtime):
    """Remove runtime routing and clear process-default ownership when applicable."""
    global _DEFAULT
    with _LOCK:
        _RUNTIMES.pop(runtime.session_id, None)
        if _DEFAULT is runtime:
            _DEFAULT = None


def default_runtime():
    """Return the process-default local observability runtime, if registered."""
    return _DEFAULT


class LocalMetricExporter(MetricExporter):
    """Persist complete SDK metric collections through the owning local runtime."""

    def __init__(self, runtime):
        """Retain the runtime that owns all exported metric collections."""
        super().__init__()
        self.runtime = runtime

    def export(self, metrics_data, timeout_millis=10000, **kwargs):
        """Redact and enqueue one complete SDK metric collection."""
        try:
            # Persist the SDK document intact so cumulative snapshots are not
            # accidentally interpreted as interval deltas.
            document = json.loads(metrics_data.to_json())
            accepted = self.runtime.store.enqueue(
                "metric",
                {
                    "collection_id": str(uuid.uuid4()),
                    "point_index": 0,
                    "process_instance_id": self.runtime.process_id,
                    "timestamp": time.time(),
                    "payload": self.runtime.redactor.encode(document),
                },
            )
            self.runtime.heartbeat()
            return MetricExportResult.SUCCESS if accepted else MetricExportResult.FAILURE
        except Exception as exc:
            self.runtime.recording_error(exc)
            return MetricExportResult.FAILURE

    def shutdown(self, timeout_millis=30000, **kwargs):
        """Perform no work because the runtime owns the underlying store lifecycle."""
        pass

    def force_flush(self, timeout_millis=10000):
        """Report success because exports are synchronously admitted to the store."""
        return True


def metrics(runtime):
    """Create OpenTelemetry metric instruments bound to the supplied runtime."""
    reader = PeriodicExportingMetricReader(
        LocalMetricExporter(runtime),
        export_interval_millis=runtime.settings.obs.metric_interval_seconds * 1000,
    )
    provider = MeterProvider(
        metric_readers=[reader],
        resource=Resource(
            {
                "service.name": runtime.settings.obs.service_name,
                "service.instance.id": runtime.process_id,
            }
        ),
    )
    meter = provider.get_meter("mcp_agent_template.observability", "1")
    for field, unit in (
        ("pending_records", "1"),
        ("pending_bytes", "By"),
        ("oldest_pending_seconds", "s"),
        ("write_seconds", "s"),
        ("unrecorded", "1"),
        ("written_records", "1"),
    ):

        def observe(options, key=field):
            """Read one writer-health field for an observable gauge callback."""
            return [Observation(runtime.store.health()[key])]

        meter.create_observable_gauge(
            "mcp_agent_template.telemetry." + field, callbacks=[observe], unit=unit
        )
    return provider, meter
