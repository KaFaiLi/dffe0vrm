"""Provide application-owned local observation runtimes, storage, and OpenTelemetry integration."""
