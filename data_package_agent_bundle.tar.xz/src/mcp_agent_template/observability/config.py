"""Validated local-recording policy with no implicit sampling or retention cap."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ObservabilitySettings(BaseModel):
    """Configure optional local recording, batching, metrics, and service identity.

    Settings are frozen so a started runtime retains one explainable policy for
    its entire lifecycle.  ``capture`` currently accepts only complete redacted
    payloads; plaintext or partial capture is not a fallback.
    """

    model_config = ConfigDict(frozen=True)

    mode: Literal["local", "off"] = "local"
    dir: str = ".mcp_agent_template/observability"
    capture: Literal["full_redacted"] = "full_redacted"
    flush_interval_ms: int = Field(default=250, ge=0)
    metric_interval_seconds: float = Field(default=5, gt=0)
    service_name: str = "data-package-agent"
