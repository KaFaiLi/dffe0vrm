"""Expose the observability command-line interface through ``python -m``.

Importing this module has no side effects. Execution is delegated to the CLI
only when Python runs the module as a script.
"""

from mcp_agent_template.observability.cli import main

raise SystemExit(main())
