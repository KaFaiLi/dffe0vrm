"""Local observability. Installing/importing the package starts no recorder."""


def __getattr__(name):
    """Lazily expose recorder classes without initializing the optional OTel SDK."""
    if name == "ObservabilityRuntime":
        from mcp_agent_template.observability.recording.runtime import ObservabilityRuntime

        return ObservabilityRuntime
    raise AttributeError(name)


__all__ = ["ObservabilityRuntime"]
