"""Versioned mappings from native failures and experimental GenAI fields.

The labels are local observation semantics, not a claim that experimental OTel
GenAI conventions form a stable external schema.
"""

from langchain_core.tools import ToolException
from langgraph.errors import GraphRecursionError
from pydantic import ValidationError

GENAI_OPERATION = "gen_ai.operation.name"
GENAI_MODEL = "gen_ai.request.model"
GENAI_INPUT_TOKENS = "gen_ai.usage.input_tokens"
GENAI_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
# This version identifies the package mapping only; it is not an OTel schema URL.
MAPPING_VERSION = "mcp_agent_template-v1"


class ContextLimitExceeded(ValueError):
    """Report that protected model input cannot fit the configured context budget."""

    code = "CONTEXT_LIMIT_EXCEEDED"

    def __init__(self, detail: str):
        """Prefix human-readable detail with the stable machine error code once."""
        super().__init__(detail if detail.startswith(self.code + ":") else f"{self.code}: {detail}")


def error_kind(error: BaseException | None) -> str | None:
    """Map a native exception to the stable local failure category used by observations."""
    if error is None:
        return None
    if isinstance(error, ContextLimitExceeded):
        return "context_limit"
    if isinstance(error, GraphRecursionError):
        return "round_limit"
    from mcp_agent_template.agent.runtime.context import ModelBudgetExceeded, ToolBudgetExceeded

    if isinstance(error, ModelBudgetExceeded):
        return "model_budget"
    if isinstance(error, ToolBudgetExceeded):
        return "tool_budget"
    if isinstance(error, TimeoutError):
        return "deadline"
    if isinstance(error, ValidationError):
        return "validation"
    if isinstance(error, ToolException):
        return "tool"
    return "internal" if isinstance(error, Exception) else None
