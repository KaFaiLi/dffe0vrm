"""Optional offline estimates from an explicit, user-owned price table."""

from decimal import Decimal
from typing import Any


def estimate_cost(events: list[dict], prices: dict) -> dict[str, Any]:
    """Count each model completion once; unknown prices/usage stay unknown.

    Rates are currency per million tokens. Cached input and reasoning output
    details, when present, are subsets of the provider's input/output totals.
    """
    for key in ("version", "currency", "effective_date", "models"):
        if key not in prices:
            raise ValueError(f"Price table requires {key}")
    calls, seen = [], set()
    subtotal = Decimal(0)
    for event in events:
        if event["event_name"] != "model.finished":
            continue
        data = event["payload"]["data"]
        identity = (event["run_id"], data["native_run_id"])
        if identity in seen:
            continue
        seen.add(identity)
        usage = data.get("usage")
        rates = prices["models"].get(data.get("model"))
        amount = None
        reason = "missing_price_or_usage"
        if usage is not None and rates is not None:
            try:
                inputs, outputs = usage["input_tokens"], usage["output_tokens"]
                input_details = usage.get("input_token_details") or {}
                output_details = usage.get("output_token_details") or {}
                # Audio/cache creation accounting needs an explicit extension,
                # never silently apply text pricing to unhandled token classes.
                if any(v for k, v in input_details.items() if k != "cache_read") or any(
                    v for k, v in output_details.items() if k != "reasoning"
                ):
                    raise ValueError("Unsupported token class")
                cached = input_details.get("cache_read", 0)
                reasoning = output_details.get("reasoning", 0)
                if not 0 <= cached <= inputs or not 0 <= reasoning <= outputs:
                    raise ValueError("Invalid token subsets")
                amounts = [(inputs - cached, "input"), (outputs - reasoning, "output")]
                if cached:
                    amounts.append((cached, "cached_input"))
                if reasoning:
                    amounts.append((reasoning, "reasoning_output"))
                rated = [(n, Decimal(str(rates[k]))) for n, k in amounts]
                if any(not rate.is_finite() or rate < 0 for _, rate in rated):
                    raise ValueError("Invalid price")
                amount = sum(Decimal(n) * rate for n, rate in rated) / Decimal(1000000)
                subtotal += amount
                reason = None
            except (KeyError, ValueError, ArithmeticError, TypeError):
                amount, reason = None, "incomplete_or_unsupported_pricing"
        calls.append(
            {
                "run_id": event["run_id"],
                "native_run_id": data["native_run_id"],
                "model": data.get("model"),
                "estimated_cost": str(amount) if amount is not None else None,
                "unknown_reason": reason,
            }
        )
    unknown = sum(call["estimated_cost"] is None for call in calls)
    return {
        "price_table_version": prices["version"],
        "currency": prices["currency"],
        "effective_date": prices["effective_date"],
        "known_subtotal": str(subtotal),
        "estimated_total": None if unknown else str(subtotal),
        "unknown_calls": unknown,
        "calls": calls,
        "basis": "provider-reported usage; observed public model calls only",
    }
