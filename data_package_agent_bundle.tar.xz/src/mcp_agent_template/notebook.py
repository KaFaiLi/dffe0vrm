"""Pretty, theme-friendly HTML widgets for the playground notebook.

Each function returns an ``IPython.display.HTML`` object, so notebook cells stay
one-liners (``display(tool_catalog(tools))``) while the output looks polished.
Styling uses semi-transparent neutrals + solid accent badges so it reads well in
both light and dark Jupyter themes. Import is lazy: this module has no hard
dependency on IPython unless you actually call a widget.
"""

from __future__ import annotations

import html as _html
import json
from typing import Any

# Shared visual constants keep independently rendered widgets consistent within
# one notebook without injecting a global stylesheet into the user's document.
_INDIGO = "#6366f1"
_VIOLET = "#8b5cf6"
_GREEN = "#16a34a"
_AMBER = "#d97706"
_RED = "#dc2626"
_SLATE = "#64748b"
_TEAL = "#0d9488"
_PINK = "#db2777"
_CYAN = "#0891b2"

# Colors cycled through to give each distinct agent name (orchestrator,
# sub-agents, ...) a stable, distinguishable badge color across a trace.
# Red is reserved for errors, so it's excluded here.
_AGENT_PALETTE = (_INDIGO, _VIOLET, _AMBER, _TEAL, _PINK, _CYAN)

_FONT = "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif"
_MONO = "'SFMono-Regular',Consolas,'Liberation Mono',Menlo,monospace"
_CARD = (
    "border:1px solid rgba(127,127,127,.25);border-radius:12px;"
    "background:rgba(127,127,127,.06);padding:14px 16px;margin:6px 0;"
    f"font-family:{_FONT};line-height:1.45;"
)
# Fixed-height, scrollable box for long pre-formatted content (tool results,
# reasoning, tool-call args) so a big payload doesn't blow up the cell output.
_SCROLL_BOX = "max-height:260px;overflow-y:auto;"


def _esc(x: Any) -> str:
    """Convert arbitrary notebook display data to safe HTML-escaped text."""
    return _html.escape(str(x))


def _html_obj(markup: str):
    """Wrap trusted, package-generated markup in an IPython ``HTML`` object."""
    from IPython.display import HTML

    return HTML(markup)


def _badge(text: str, color: str) -> str:
    """Render escaped text as a compact colored identity badge."""
    return (
        f'<span style="display:inline-block;padding:2px 9px;border-radius:9999px;'
        f"background:{color};color:#fff;font-size:11px;font-weight:600;"
        f'white-space:nowrap;">{_esc(text)}</span>'
    )


def _chip(text: str) -> str:
    """Render escaped text as a compact monospace metadata chip."""
    return (
        f'<code style="font-family:{_MONO};font-size:11.5px;padding:1px 6px;'
        f'border-radius:6px;background:rgba(127,127,127,.16);">{_esc(text)}</code>'
    )


def _agent_color(name: str) -> str:
    """Deterministically map an agent name to a stable badge color.

    Same name -> same color, always (within and across runs), so a reader
    can visually track "who did what" in a multi-agent trace at a glance.
    """
    return _AGENT_PALETTE[sum(ord(c) for c in name) % len(_AGENT_PALETTE)]


def _agent_badge(agent_name: str | None) -> str:
    """A small colored 'who did this' badge, or '' if no name is given."""
    if not agent_name:
        return ""
    return _badge(agent_name, _agent_color(agent_name))


# Public notebook widgets return display objects rather than calling ``display``;
# callers retain control over cell ordering and repeated rendering.
def banner(title: str, subtitle: str = ""):
    """A gradient hero banner for the top of the notebook."""
    sub = (
        f'<div style="opacity:.92;font-size:13.5px;margin-top:6px;">{_esc(subtitle)}</div>'
        if subtitle
        else ""
    )
    return _html_obj(
        f'<div style="background:linear-gradient(135deg,{_INDIGO},{_VIOLET});'
        f"color:#fff;border-radius:14px;padding:20px 22px;font-family:{_FONT};"
        f'box-shadow:0 6px 20px rgba(99,102,241,.25);">'
        f'<div style="font-size:20px;font-weight:700;letter-spacing:.2px;">{_esc(title)}</div>'
        f"{sub}</div>"
    )


def status_panel(mapping: dict[str, Any], title: str = "Environment"):
    """A compact key/value panel (great for showing config / a run summary)."""
    rows = "".join(
        f'<div style="display:flex;gap:10px;padding:3px 0;">'
        f'<div style="color:{_SLATE};min-width:130px;font-size:12.5px;">{_esc(k)}</div>'
        f'<div style="font-family:{_MONO};font-size:12.5px;">{_esc(v)}</div></div>'
        for k, v in mapping.items()
    )
    return _html_obj(
        f'<div style="{_CARD}">'
        f'<div style="font-weight:700;margin-bottom:6px;color:{_INDIGO};">{_esc(title)}</div>'
        f"{rows}</div>"
    )


def tool_catalog(tools: list[Any], title: str = "Tool catalog"):
    """Render tools as a table of names, descriptions, and parameters."""
    head = (
        f'<tr style="text-align:left;color:{_SLATE};font-size:11.5px;'
        'text-transform:uppercase;letter-spacing:.4px;">'
        '<th style="padding:6px 10px;">Tool</th>'
        '<th style="padding:6px 10px;">Description</th>'
        '<th style="padding:6px 10px;">Params</th>'
        "</tr>"
    )
    body = []
    for t in tools:
        desc = (getattr(t, "description", "") or "").strip().splitlines()
        desc = desc[0] if desc else ""
        params = list(getattr(t, "args", {}) or {})
        params_html = " ".join(_chip(p) for p in params) or (
            f'<span style="color:{_SLATE};font-size:12px;">—</span>'
        )
        body.append(
            '<tr style="border-top:1px solid rgba(127,127,127,.18);">'
            f'<td style="padding:8px 10px;font-family:{_MONO};font-weight:600;'
            f'color:{_INDIGO};vertical-align:top;">{_esc(t.name)}</td>'
            f'<td style="padding:8px 10px;font-size:13px;vertical-align:top;">{_esc(desc)}</td>'
            f'<td style="padding:8px 10px;vertical-align:top;">{params_html}</td></tr>'
        )
    return _html_obj(
        f'<div style="{_CARD}">'
        f'<div style="font-weight:700;margin-bottom:8px;color:{_INDIGO};">'
        f'{_esc(title)} <span style="color:{_SLATE};font-weight:400;">'
        f"({len(tools)})</span></div>"
        '<table style="border-collapse:collapse;width:100%;">'
        f"{head}{''.join(body)}</table></div>"
    )


def skills_cards(skills: list[Any], title: str = "Skills"):
    """Render discovered skill names and descriptions as compact notebook cards."""
    if not skills:
        inner = f'<div style="color:{_SLATE};">No skills found.</div>'
    else:
        cards = "".join(
            '<div style="border:1px solid rgba(127,127,127,.22);border-radius:10px;'
            'padding:10px 12px;background:rgba(127,127,127,.04);">'
            f'<div style="font-family:{_MONO};font-weight:700;color:{_VIOLET};">'
            f"{_esc(s.name)}</div>"
            f'<div style="font-size:12.5px;margin-top:3px;">{_esc(s.description)}</div></div>'
            for s in skills
        )
        inner = (
            '<div style="display:grid;grid-template-columns:repeat(auto-fill,'
            f'minmax(230px,1fr));gap:10px;">{cards}</div>'
        )
    return _html_obj(
        f'<div style="{_CARD}"><div style="font-weight:700;margin-bottom:8px;'
        f'color:{_INDIGO};">{_esc(title)} <span style="color:{_SLATE};'
        f'font-weight:400;">({len(skills)})</span></div>{inner}</div>'
    )


def token_meter(label: str, tokens: int, soft_limit: int = 500):
    """A horizontal bar showing a token count against a 'keep it small' budget."""
    pct = min(100, tokens / soft_limit * 100) if soft_limit else 0
    if tokens < soft_limit * 0.4:
        color = _GREEN
    elif tokens < soft_limit:
        color = _AMBER
    else:
        color = _RED
    return _html_obj(
        f'<div style="{_CARD}">'
        f'<div style="display:flex;justify-content:space-between;font-size:13px;'
        f'margin-bottom:6px;"><span>{_esc(label)}</span>'
        f'<span style="font-family:{_MONO};color:{color};font-weight:700;">'
        f"{tokens} tokens</span></div>"
        '<div style="height:10px;border-radius:9999px;background:rgba(127,127,127,.18);'
        'overflow:hidden;">'
        f'<div style="height:100%;width:{pct:.0f}%;background:{color};"></div></div>'
        f'<div style="color:{_SLATE};font-size:11px;margin-top:5px;">'
        f"soft budget: {soft_limit} tokens</div></div>"
    )


def json_view(obj: Any, title: str = "Result"):
    """Pretty-print a JSON-able object in a monospace card."""
    try:
        text = json.dumps(obj, indent=2, ensure_ascii=False)
    except TypeError:
        text = str(obj)
    return _html_obj(
        f'<div style="{_CARD}"><div style="font-weight:700;margin-bottom:6px;'
        f'color:{_INDIGO};">{_esc(title)}</div>'
        f'<pre style="margin:0;font-family:{_MONO};font-size:12.5px;'
        f'white-space:pre-wrap;">{_esc(text)}</pre></div>'
    )


def command_box(command: str, note: str = ""):
    """A copy-friendly command block (run in a real terminal)."""
    note_html = (
        f'<div style="color:{_SLATE};font-size:12px;margin-bottom:6px;">{_esc(note)}</div>'
        if note
        else ""
    )
    return _html_obj(
        f'<div style="{_CARD}">{note_html}'
        f'<pre style="margin:0;font-family:{_MONO};font-size:12.5px;'
        "background:rgba(127,127,127,.14);padding:10px 12px;border-radius:8px;"
        f'white-space:pre-wrap;">{_esc(command)}</pre></div>'
    )


# Trace rendering is split into extraction and markup helpers so streaming can
# update one display object without duplicating message-shape logic.
def _truncate(text: str, limit: int) -> tuple[str, bool]:
    """Bound display text and report whether an ellipsis was appended."""
    if len(text) <= limit:
        return text, False
    return text[:limit], True


def _reasoning_from_blocks(blocks: Any) -> str | None:
    """Extract exposed reasoning text from normalized LangChain content blocks."""
    if not isinstance(blocks, list):
        return None

    parts: list[str] = []
    for block in blocks:
        if not isinstance(block, dict) or block.get("type") not in {
            "reasoning",
            "thinking",
        }:
            continue
        text = block.get("reasoning") or block.get("text") or block.get("thinking")
        if text:
            parts.append(str(text))
            continue
        summary = block.get("summary")
        if isinstance(summary, str) and summary:
            parts.append(summary)
        elif isinstance(summary, list):
            parts.extend(
                str(item["text"]) for item in summary if isinstance(item, dict) and item.get("text")
            )
    return "\n".join(parts) or None


def _extract_reasoning(msg: Any) -> str | None:
    """Read exposed summaries from current Responses/normalized content blocks.

    Return None for absent or unparseable content. Opaque reasoning and unrelated
    provider metadata are not rendered as exposed summaries.
    """
    try:
        reasoning = _reasoning_from_blocks(getattr(msg, "content_blocks", None))
    except (AttributeError, TypeError, ValueError):
        reasoning = None
    return reasoning or _reasoning_from_blocks(getattr(msg, "content", None))


def _message_text(msg: Any) -> str:
    """Flatten a message's content (str or content-block list) to plain text."""
    content = getattr(msg, "content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") in {"reasoning", "thinking"}:
                    continue  # rendered separately by _extract_reasoning
                parts.append(block.get("text", "") or "")
            else:
                parts.append(str(block))
        return "".join(parts)
    return str(content)


def trace_message(msg: Any, agent_name: str | None = None):
    """Render one LangGraph trace message as a standalone HTML card.

    ``agent_name``, if given, shows a small colored badge identifying which
    agent produced this message -- useful once sub-agents are involved. For a
    full agent run, prefer :func:`stream_trace`, which renders every message
    from a run (including nested sub-agent traces) inside one scrollable
    panel instead of one output per message.
    """
    return _html_obj(_trace_message_markup(msg, agent_name=agent_name))


def _trace_message_markup(msg: Any, agent_name: str | None = None) -> str:
    """Build inner HTML markup for one trace message (no outer HTML wrapper).

    Distinguishes the user turn, any model reasoning (collapsible, dim), tool
    calls (accent chip + pretty-printed args), tool results (color/label by
    kind: skill exploration, skill reading, error, or generic result), and the
    final assistant answer (highlighted) -- so a streamed agent run reads like
    a clean transcript instead of a raw ``pretty_print()`` dump. Unknown
    message types fall back to a plain preformatted block.

    When a tool result carries a nested sub-agent trace (see
    :func:`~mcp_agent_template.agent.multi_agent.make_agent_tool`'s
    ``artifact``), it's rendered as a distinctly bordered, indented block
    containing that sub-agent's own messages -- each tagged with its own
    ``agent_name`` badge -- so it's unmistakable which agent did what, no
    matter how deep the delegation goes.
    """
    from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

    from mcp_agent_template.tool_results import tool_text

    badge = _agent_badge(agent_name)

    if isinstance(msg, HumanMessage):
        return (
            f'<div style="{_CARD}border-left:3px solid {_SLATE};">'
            '<div style="display:flex;justify-content:space-between;'
            'align-items:center;margin-bottom:4px;">'
            f'<div style="font-weight:700;color:{_SLATE};font-size:11px;'
            'text-transform:uppercase;letter-spacing:.4px;">🧑 User</div>'
            f"{badge}</div>"
            f'<div style="font-size:13.5px;white-space:pre-wrap;">'
            f"{_esc(_message_text(msg))}</div></div>"
        )

    if isinstance(msg, SystemMessage):
        return (
            f'<div style="{_CARD}border-left:3px solid {_SLATE};opacity:.8;">'
            '<div style="display:flex;justify-content:space-between;align-items:center;">'
            f'<div style="font-weight:700;color:{_SLATE};font-size:11px;'
            'text-transform:uppercase;letter-spacing:.4px;">⚙️ System directive</div>'
            f"{badge}</div>"
            f'<div style="font-size:12px;white-space:pre-wrap;margin-top:4px;">'
            f"{_esc(_message_text(msg))}</div></div>"
        )

    if isinstance(msg, ToolMessage):
        artifact = getattr(msg, "artifact", None)
        if isinstance(artifact, dict) and "messages" in artifact and "agent" in artifact:
            # Nested sub-agent run: render its own trace, indented and
            # color-coded by its name, so delegation is unmistakable even
            # when it happens several levels deep. Also show the exact payload
            # and status returned to the parent agent.
            sub_name = artifact["agent"]
            sub_color = _agent_color(sub_name)
            nested = "".join(
                _trace_message_markup(m, agent_name=sub_name) for m in artifact["messages"]
            )
            is_error = getattr(msg, "status", "success") == "error"
            tool_name = getattr(msg, "name", None) or f"ask_{sub_name}"
            result_color = _RED if is_error else _GREEN
            result_label = "❌ Tool error" if is_error else "📤 Result sent to parent"
            result_text = tool_text(msg.content)
            shown, truncated = _truncate(result_text, 4000)
            truncation_note = (
                f'<div style="color:{_SLATE};font-size:11px;margin-top:4px;">'
                f"… truncated ({len(result_text)} chars total)</div>"
                if truncated
                else ""
            )
            parent_result = (
                f'<div style="{_CARD}border-left:3px solid {result_color};">'
                '<div style="display:flex;justify-content:space-between;align-items:center;">'
                f'<div style="font-weight:700;color:{result_color};font-size:11px;'
                f'text-transform:uppercase;letter-spacing:.4px;">{result_label}</div>'
                f"{_chip(tool_name)}</div>"
                f'<pre style="margin:6px 0 0;font-family:{_MONO};font-size:12px;'
                f'white-space:pre-wrap;{_SCROLL_BOX}">{_esc(shown)}</pre>'
                f"{truncation_note}</div>"
            )
            return (
                f'<div style="{_CARD}border-left:4px solid {sub_color};'
                'background:rgba(127,127,127,.035);">'
                '<div style="display:flex;justify-content:space-between;align-items:center;">'
                f'<div style="font-weight:700;color:{sub_color};font-size:11px;'
                'text-transform:uppercase;letter-spacing:.4px;">🧩 Sub-agent run</div>'
                f"{_badge(sub_name, sub_color)}</div>"
                '<div style="margin-top:8px;margin-left:6px;padding-left:12px;'
                f'border-left:2px dashed {sub_color}66;">{nested}</div>'
                f"{parent_result}</div>"
            )

        is_error = getattr(msg, "status", "success") == "error"
        tool_name = getattr(msg, "name", None) or "tool"
        if is_error:
            color, label = _RED, "❌ Tool error"
        elif tool_name == "load_skill":
            color, label = _VIOLET, "📖 Skill reading"
        elif tool_name == "list_skills":
            color, label = _VIOLET, "🔍 Exploring available skills"
        else:
            color, label = _GREEN, "📥 Tool result"
        text = tool_text(msg.content)
        shown, truncated = _truncate(text, 4000)
        note = (
            f'<div style="color:{_SLATE};font-size:11px;margin-top:4px;">'
            f"… truncated ({len(text)} chars total)</div>"
            if truncated
            else ""
        )
        return (
            f'<div style="{_CARD}border-left:3px solid {color};">'
            '<div style="display:flex;justify-content:space-between;align-items:center;">'
            f'<div style="font-weight:700;color:{color};font-size:11px;'
            f'text-transform:uppercase;letter-spacing:.4px;">{label}</div>'
            f'<div style="display:flex;gap:6px;align-items:center;">'
            f"{badge}{_chip(tool_name)}</div></div>"
            f'<pre style="margin:6px 0 0;font-family:{_MONO};font-size:12px;'
            f'white-space:pre-wrap;{_SCROLL_BOX}">{_esc(shown)}</pre>{note}</div>'
        )

    if isinstance(msg, AIMessage):
        extra_blocks: list[str] = []

        reasoning = _extract_reasoning(msg)
        if reasoning:
            extra_blocks.append(
                '<details open style="margin-top:6px;">'
                f'<summary style="cursor:pointer;color:{_SLATE};font-size:12px;'
                'font-weight:600;">🧠 Reasoning</summary>'
                f'<div style="font-size:12px;color:{_SLATE};white-space:pre-wrap;'
                f'font-style:italic;margin-top:4px;{_SCROLL_BOX}">{_esc(reasoning)}</div></details>'
            )

        tool_calls = getattr(msg, "tool_calls", None) or []
        for tc in tool_calls:
            args_json = json.dumps(tc.get("args", {}), indent=2, ensure_ascii=False)
            extra_blocks.append(
                f'<div style="margin-top:8px;">{_badge("calling", _INDIGO)} '
                f"{_chip(tc.get('name', ''))}"
                f'<pre style="margin:4px 0 0;font-family:{_MONO};font-size:12px;'
                "background:rgba(127,127,127,.10);padding:6px 8px;border-radius:6px;"
                f'white-space:pre-wrap;{_SCROLL_BOX}">{_esc(args_json)}</pre></div>'
            )

        text = _message_text(msg).strip()
        is_final = bool(text) and not tool_calls
        accent = _GREEN if is_final else _VIOLET
        header = "🤖 Assistant — final answer" if is_final else "🤖 Assistant"
        body = (
            f'<div style="font-size:13.5px;white-space:pre-wrap;margin-top:4px;">{_esc(text)}</div>'
            if text
            else ""
        )
        return (
            f'<div style="{_CARD}border-left:3px solid {accent};">'
            '<div style="display:flex;justify-content:space-between;align-items:center;">'
            f'<div style="font-weight:700;color:{accent};font-size:11px;'
            f'text-transform:uppercase;letter-spacing:.4px;">{header}</div>'
            f"{badge}</div>"
            f"{body}{''.join(extra_blocks)}</div>"
        )

    # Fallback for any other message type.
    return (
        f'<div style="{_CARD}"><pre style="margin:0;font-family:{_MONO};'
        f'font-size:12px;white-space:pre-wrap;">{_esc(str(msg))}</pre></div>'
    )


async def stream_trace(
    agent: Any,
    message: str,
    *,
    config: dict | None = None,
    context: Any = None,
    settings: Any = None,
    title: str | None = None,
    max_height: int = 520,
    agent_name: str | None = None,
) -> str:
    """Stream an agent run as one live-updating, scrollable trace panel.

    Drop-in replacement for the common "``astream`` + ``pretty_print()``" loop
    used throughout the notebook: renders Human/System/AI/Tool messages via
    :func:`_trace_message_markup` (reasoning shown collapsed,
    tool calls/results color-coded), and keeps everything inside a single
    scrollable panel (``max_height`` px) that updates in place as new messages
    arrive -- instead of one growing output per message -- so a long run never
    blows up the cell's height. Returns the final assistant answer.

    Important: messages are tracked by id and *replaced in place* when a later
    chunk updates an existing message (e.g. post-model hooks rewriting a
    multi-tool-call AIMessage into a single-call one). This avoids stale cards
    and keeps trace + tool results consistent.

    Pass ``agent_name`` (e.g. ``"orchestrator"``) to badge every top-level
    message with it -- handy once sub-agents are involved, since any
    ``ask_<name>`` tool result that carries a nested sub-agent trace is
    rendered inline, indented, and badged with *its own* name automatically.
    """
    import uuid

    from IPython.display import Markdown, display, update_display
    from langchain_core.messages import AIMessage

    if title:
        display(Markdown(f"### {title}"))

    display_id = f"trace-{uuid.uuid4().hex}"
    cards: list[str] = []

    def _panel() -> Any:
        """Render all accumulated cards inside the bounded live trace panel."""
        return _html_obj(
            f'<div style="max-height:{max_height}px;overflow-y:auto;'
            f'padding-right:6px;">{"".join(cards)}</div>'
        )

    display(_panel(), display_id=display_id)

    card_index_by_id: dict[str, int] = {}
    final_text = ""
    from contextlib import aclosing

    from mcp_agent_template.agent.bundle import AgentBundle
    from mcp_agent_template.config import get_settings

    bundle = (
        agent
        if isinstance(agent, AgentBundle)
        else AgentBundle(
            agent=agent,
            model=None,
            settings=settings or get_settings(),
            name=agent_name or "notebook",
        )
    )
    stream = bundle.astream(message, config=config or {}, context=context, stream_mode="values")
    async with aclosing(stream):
        async for chunk in stream:
            changed = False
            for msg in chunk["messages"]:
                markup = _trace_message_markup(msg, agent_name=agent_name)
                msg_id = getattr(msg, "id", None)
                if msg_id is None:
                    cards.append(markup)
                    changed = True
                else:
                    idx = card_index_by_id.get(msg_id)
                    if idx is None:
                        card_index_by_id[msg_id] = len(cards)
                        cards.append(markup)
                        changed = True
                    elif cards[idx] != markup:
                        cards[idx] = markup
                        changed = True
                if isinstance(msg, AIMessage) and msg.content and not msg.tool_calls:
                    final_text = _message_text(msg)
            if changed:
                update_display(_panel(), display_id=display_id)
    return final_text
