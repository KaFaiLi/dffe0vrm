"""Expose deterministic FOX case review and saved evidence through one MCP tool.

The adapter selects a schema-matching Parquet file; calculations and report
writing belong to analysis.fox. Input paths use the server working directory,
while the configured analysis destination determines where reports are saved.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import polars as pl
from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from pydantic import Field

from mcp_agent_template.analysis.fox.preprocessing import REQUIRED_COLUMNS
from mcp_agent_template.analysis.fox.runners import (
    run_fox_analysis as _run_fox_analysis,
)
from mcp_agent_template.config import Settings


def _find_case_parquet(folder: Path) -> Path:
    """Select one immediate-child Parquet file with the required case columns.

    Other readable Parquet schemas are ignored; filenames are unrestricted.
    Raise ToolError for an unreadable Parquet schema or zero/multiple matches.
    Only schemas are inspected here; row validation belongs to the runner.
    """
    required_columns = set(REQUIRED_COLUMNS)
    candidates = []
    for path in folder.iterdir():
        if not path.is_file() or path.suffix.lower() != ".parquet":
            continue
        try:
            columns = set(pl.scan_parquet(path).collect_schema().names())
        except pl.exceptions.PolarsError as exc:
            raise ToolError(f"Cannot read Parquet schema for {path.name}; check the file.") from exc
        if required_columns <= columns:
            candidates.append(path)

    if not candidates:
        required = ", ".join(REQUIRED_COLUMNS)
        raise ToolError(
            f"No Parquet file with the required post-trade control columns ({required}) "
            f"was found in {folder}."
        )
    if len(candidates) > 1:
        names = ", ".join(sorted(path.name for path in candidates))
        raise ToolError(
            f"Multiple post-trade control Parquet files found in {folder}: {names}. "
            "Use a folder containing only the dataset to analyze."
        )
    return candidates[0]


def register(mcp: FastMCP, settings: Settings) -> None:
    """Register the folder-only review tool with this server's output destination."""
    output_dir = settings.resolve_path(settings.analysis_results_dir) / "fox"

    @mcp.tool
    def run_post_trade_review(
        folder_path: Annotated[
            str,
            Field(
                description=(
                    "Existing folder to scan nonrecursively for exactly one Parquet file "
                    "containing the required case-sensitive columns: "
                    f"{', '.join(REQUIRED_COLUMNS)}. "
                    "Filenames are unrestricted; other readable Parquet schemas are ignored. "
                    "Supply a folder, not a file. Absolute paths and paths relative to the "
                    "MCP server's working directory are accepted; APP_ROOT is not the input "
                    "path base. All supplied rows and dates are analyzed."
                )
            ),
        ],
    ) -> str:
        """Analyze FOX post-trade control cases for an auditor's evidence review.

        Deterministically reconcile source/analyzed rows and duplicate case IDs;
        summarize outcomes, control concentration, execution-month patterns,
        processing backlog, workflow inconsistencies, comment/auto-close signals,
        hit-search attribution and overlapping rule-based review queues. No LLM
        is called and source files are unchanged. No date filter or snapshot
        argument is accepted: one current server-local timestamp anchors ages
        without closure dates; populated closures take precedence for every status.

        Args:
            folder_path: Folder with exactly one schema-matching Parquet file among
                its immediate children. Comment counts must be nonnegative whole
                numbers or null. Optional closure_date, isautoclosed and
                historic_comments_markdown enrich the review; missing evidence
                remains unknown. Relative paths use the server working directory.

        Returns:
            The saved Markdown report text, including actual source and artifact
            paths. Each successful run writes FOX_audit_analysis.md and
            FOX_audit_analysis.xlsx under ANALYSIS_RESULTS_DIR/fox/<run-id>/.
            Markdown shows the ten largest controls and at most fifteen priority
            rows; the five standard workbook sheets retain all analyzed rows and queue
            flags, not an unmodified source copy. No charts are generated.
            Oversized text has complete parts in an optional Text Evidence sheet;
            main case rows are unchanged and XML controls use visible escapes.
            Load post-trade-control and its dataset/interpretation references
            before drawing conclusions: scores are review priorities, source
            breach labels and hit-search items require corroboration, and the
            displayed rows are not an audit sample.

        Raises:
            ToolError: The folder is invalid, Parquet schemas cannot be read,
                zero/multiple files match, the dataset is empty or fails row
                validation, or input/report access fails. Correct the stated
                problem before rerunning; a failed call is not a completed review.
        """
        folder = Path(folder_path).expanduser().resolve()
        if not folder.is_dir():
            raise ToolError(f"folder_path must be an existing directory: {folder}")

        input_file = _find_case_parquet(folder)
        try:
            return _run_fox_analysis(input_file=input_file, output_dir=output_dir)
        except ValueError as exc:
            raise ToolError(str(exc)) from exc
        except OSError as exc:
            raise ToolError(
                "Cannot read the dataset or save the reports; check input permissions and "
                "the configured ANALYSIS_RESULTS_DIR destination."
            ) from exc
