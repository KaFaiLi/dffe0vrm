"""Tool modules for the MCP server.

Each module here exposes a ``register(mcp)`` function that attaches its tools to
the shared :class:`fastmcp.FastMCP` instance. This keeps tools grouped by domain
and makes the server file trivial. To add a new group:

1. Create ``my_tools.py`` with a ``register(mcp)`` function.
2. Import it in ``server.build_server`` and call ``my_tools.register(mcp)``.
"""
