"""Model-facing contract for file-based risk outliers and independent excess workflows."""

from typing import Annotated

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from pydantic import Field

from mcp_agent_template.analysis.risk_metrics import run_risk_metrics_analysis as run_analysis
from mcp_agent_template.config import Settings


def register(mcp: FastMCP, settings: Settings) -> None:
    """Register the five-path risk review with its configured artifact destination."""
    output_dir = settings.resolve_path(settings.analysis_results_dir) / "risk_metrics"

    @mcp.tool
    def run_risk_metrics_analysis(
        sgmr_path: Annotated[
            str,
            Field(
                description="Required nonempty SGMR Parquet file of observed risk values. "
                "Core columns: limId, stranaNodeName, rmRiskIndicator, consoValueDate, "
                "consoValue. Comparable outlier series also need rmRiskMetricName, limUnit "
                "and a nonnegative integer consoVersion. stranaPc supplies the displayed "
                "perimeterMnemonic. Headers are case-insensitive; extra columns are retained."
            ),
        ],
        colibris_path: Annotated[
            str | None,
            Field(
                description="Optional UTF-8 Colibris excess-event CSV with excessId. Supports "
                "recorded states, calendar aging, explanation/validation and approval "
                "chronology, recurrence and within-Colibris usage checks when fields exist. "
                "Omit when absent; omission leaves dependent checks unavailable."
            ),
        ] = None,
        risk_metrics_commentary_path: Annotated[
            str | None,
            Field(
                description="Optional UTF-8 risk-metrics commentary Markdown. Included in full "
                "as unprocessed source evidence for direct agent review; omit when absent "
                "or already supplied in the conversation."
            ),
        ] = None,
        stress_test_commentary_path: Annotated[
            str | None,
            Field(
                description="Optional UTF-8 stress-test commentary Markdown, included in full "
                "as unprocessed source evidence for direct agent review. Omit when absent."
            ),
        ] = None,
        var_svar_commentary_path: Annotated[
            str | None,
            Field(
                description="Optional UTF-8 VaR/SVaR commentary Markdown, included in full "
                "as unprocessed source evidence for direct agent review. Omit when absent."
            ),
        ] = None,
    ) -> str:
        """Review risk movements, metric-value outliers, joint outlier days and excess workflows.

        Use for supplied SGMR measurements and optional Colibris events/commentary.
        Load the risk-metrics skill for the dataset and interpretation contracts.
        Calculations are deterministic, make no LLM calls and preserve source files.
        All supplied dates and perimeters are included; there are no date filters.
        Absolute input paths or paths relative to the server working directory are
        accepted. Omit absent optional sources; supplied invalid files fail explicitly.

        Calculate (current - previous) / abs(previous) for every comparable consecutive
        pair, including segments shorter than 20 observations. Movement z-scores use
        the population mean and standard deviation of known movements in that segment.
        Value z-scores use (value - segment mean) / population standard deviation and
        require at least 20 consecutive comparable values. Both checks flag abs(z) >3,
        excluding equality and including both tails. A zero previous value leaves its
        movement unknown; zero dispersion leaves scores/flags unknown. Missing dates,
        invalid values and conflicting observations break comparable segments.

        Joint outlier days require both flags on the exact same SGMR observation.
        Matching dates or labels across different series cannot create a joint flag.
        Full limit/portfolio/PC/indicator/metric/unit/version/scenario identities stay separate.
        Display rows with riskMetricName and perimeterMnemonic, mapped from SGMR
        rmRiskMetricName and stranaPc or from the corresponding Colibris fields.

        Retain SGMR date-coverage, hierarchy, effective-date, limit-history and level-shift
        checks, and independent Colibris state, calendar-aging, validation, deadline,
        approval-chronology, recurrence and usage checks in Excel. The reference date
        is the latest valid SGMR value date. SGMR limit consumption, volatility-change,
        persistent-trend and cross-source reconciliation are not calculated. Commentary
        is complete unprocessed source text for direct review, without extraction,
        scoring or automatic matching. Screens do not establish control failures,
        approved materiality or SLA breaches.

        Returns:
            Markdown identical to the saved risk_metrics_analysis.md, including links
            to it and risk_metrics_analysis.xlsx under ANALYSIS_RESULTS_DIR/risk_metrics/
            in a unique run folder. Sections include Metric movements, Metric value
            outliers, Days with movement and value outliers, Excess governance and
            Data quality. The joint-day table is complete; other detail tables show
            at most 15 rows. The nine-sheet workbook retains all observations, signed
            scores, baselines, unavailable reasons, source references and methods,
            including Value Outliers and Movement and Value Outliers worksheets.
            References use SGMR id or Colibris excessId with record-number fallbacks;
            no source hashes are published. Excess governance Markdown uses excessId
            without source_locator or reperformed_usage columns. Markdown omits
            Prioritized follow-up, Executive observations, Scope and availability,
            Limit consumption and visualizations. Separate risk-value PNGs and their
            index/manifest remain in charts/, without links in the main Markdown.

        Raises:
            ToolError: A supplied input fails validation, or file access/report writing
                fails. Missing optional sources disable only their dependent checks.
        """
        try:
            return run_analysis(
                sgmr_path,
                colibris_path,
                risk_metrics_commentary_path,
                stress_test_commentary_path,
                var_svar_commentary_path,
                output_dir=output_dir,
            )
        except ValueError as exc:
            raise ToolError(str(exc)) from exc
        except OSError as exc:
            raise ToolError(
                "Cannot read the risk sources or save reports; check input permissions "
                "and the configured ANALYSIS_RESULTS_DIR destination."
            ) from exc
