"""Read-only, project-scoped file discovery for MCP clients."""

from __future__ import annotations

import stat
from typing import Annotated

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from pydantic import Field

from mcp_agent_template.config import Settings


def _list_files(settings: Settings, folder_path: str, recursive: bool) -> dict:
    """Return sorted APP_ROOT-relative files without following traversal links.

    Resolve the requested directory against APP_ROOT, then enumerate immediate
    files or recurse when requested. Hidden regular files are included without
    reading their contents. Symlinks and junctions encountered during traversal
    are skipped. Invalid paths, containment failures and incomplete enumeration
    raise ToolError; no partial listing is returned. Resolution checks detect
    ordinary escapes but do not provide an OS sandbox against filesystem races.
    """
    try:
        if not folder_path.strip() or "\x00" in folder_path:
            raise ToolError("folder_path must be a non-empty directory path without null bytes.")
        root = settings.app_root.resolve(strict=True)
        folder = settings.resolve_path(folder_path)
        if not folder.is_relative_to(root):
            raise ToolError("folder_path must stay within the project folder (APP_ROOT).")
        if not folder.is_dir():
            raise ToolError("folder_path must be an existing directory within the project.")

        files = []
        pending = [folder]
        while pending:
            directory = pending.pop()
            # Recheck before traversal; filesystem mutation is not sandboxed.
            if not directory.resolve(strict=True).is_relative_to(root):
                raise ToolError("A directory resolved outside the project folder; listing aborted.")
            for entry in directory.iterdir():
                mode = entry.lstat().st_mode
                if stat.S_ISLNK(mode) or entry.is_junction():
                    continue
                if not entry.resolve(strict=True).is_relative_to(root):
                    raise ToolError(
                        "An entry resolved outside the project folder; listing aborted."
                    )
                if stat.S_ISREG(mode):
                    files.append(entry.relative_to(root).as_posix())
                elif recursive and stat.S_ISDIR(mode):
                    pending.append(entry)
        return {
            "folder_path": folder.relative_to(root).as_posix(),
            "recursive": recursive,
            "files": sorted(files),
        }
    except (OSError, ValueError, RuntimeError) as exc:
        raise ToolError(
            "Cannot list the folder completely; check the path, permissions and whether "
            "entries changed during listing. No partial result was returned."
        ) from exc


def register(mcp: FastMCP, settings: Settings) -> None:
    """Attach project file discovery to the server."""

    @mcp.tool
    def list_files(
        folder_path: Annotated[
            str,
            Field(description="Project-relative directory or absolute directory inside APP_ROOT."),
        ] = ".",
        recursive: Annotated[
            bool,
            Field(description="Include subfolder files when true; otherwise immediate files only."),
        ] = False,
    ) -> dict:
        """List files inside the project without reading or changing their contents.

        Defaults to the project root and immediate files only. Set recursive=true
        to include nested files. Returns folder_path, recursive, and files: sorted,
        APP_ROOT-relative paths using forward slashes (not relative to folder_path).
        Hidden filenames are included; directory entries, symlinks and junctions
        encountered during traversal are excluded. Empty folders return files=[].
        Invalid/outside-project paths and enumeration failures produce errors,
        never partial listings. Results are not truncated; choose a narrow folder
        to avoid large responses. Relative paths are independent of server cwd.
        """
        return _list_files(settings, folder_path, recursive)
