"""Expose the six-source EUR PnL review and its saved evidence through MCP.

Descriptions are the model-facing contract; calculations and artifact writing
remain in analysis.pnl. Source paths use the server working directory, while
the configured analysis destination determines where reports are saved.
"""

from typing import Annotated

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from pydantic import Field

from mcp_agent_template.analysis.pnl.runners import run_pnl_analysis as run_analysis
from mcp_agent_template.config import Settings


def register(mcp: FastMCP, settings: Settings) -> None:
    """Register the six required source paths with this server's output destination."""
    destination = settings.resolve_path(settings.analysis_results_dir) / "pnl"

    @mcp.tool
    def run_pnl_analysis(
        income_attribution_path: Annotated[
            str,
            Field(
                description=(
                    "Existing wide attribution CSV with asofdate, "
                    "bu/sbu/grppc100/grppc200/grppc300/td/pc/ggop/gop and at least one "
                    "daily monetary driver. Each driver is screened independently by PC; "
                    "final PnL, cumulative and validation fields are optional and unused. "
                    "All supplied attribution dates are used, independently of PnL."
                )
            ),
        ],
        pnl_path: Annotated[
            str,
            Field(
                description=(
                    "Existing AIR PnL CSV or XLSX with exactly one matching worksheet. "
                    "Required columns: Value Date (ValuationDate alias), Notion, GOP, PC, "
                    "Currency, DTD. Every row must use EUR and the same nonblank Notion, "
                    "before numerical exclusions. PTF and Version (versiontype alias) "
                    "are optional; Version is unused. All supplied PnL dates are used."
                )
            ),
        ],
        adjustments_path: Annotated[
            str,
            Field(
                description=(
                    "Existing one-desk adjustment CSV with ADJUSTMENTID, GOP, PTF, PC, "
                    "CCY, AMOUNTINEUR, VALDATEBEGIN and VALDATEEND. Every row needs numeric "
                    "AMOUNTINEUR in EUR. CREATIONDATE enables daily record-count screening; "
                    "SOURCE/NATURE provide count groups. AMOUNT is optional and unused. "
                    "All rows are retained; missing/invalid creation dates cannot enter "
                    "daily counts, and valuation dates are not substituted."
                )
            ),
        ],
        validation_history_path: Annotated[
            str,
            Field(
                description=(
                    "Existing validation-history CSV with gop, team, state, "
                    "api_request_date and pnlType. Every history row contributes to "
                    "state counts/percentages within its team/PnL-type group, including "
                    "STAB/FLASH. Active is optional and unused. No date filter, "
                    "latest-state selection, deduplication or approval inference."
                )
            ),
        ],
        income_attribution_commentary_path: Annotated[
            str,
            Field(
                description=(
                    "Existing original attribution commentary Markdown (.md), required "
                    "and returned in full for direct review. No date filtering, parsing "
                    "or automatic association with numerical observations is performed."
                )
            ),
        ],
        pnl_commentary_path: Annotated[
            str,
            Field(
                description=(
                    "Existing original PnL commentary Markdown (.md), required and "
                    "returned in full for direct review. Recorded explanations and "
                    "approvals are source evidence, not independently verified facts."
                )
            ),
        ],
    ) -> str:
        """Review all supplied EUR desk PnL and independent attribution/control data.

        Supply all six existing files. Absolute paths and paths relative to the
        MCP server's working directory are accepted; APP_ROOT is not the input
        path base. Load the pnl skill and its dataset/interpretation references.
        The analysis is deterministic, calls no LLM and leaves sources unchanged.
        Each dataset uses all its supplied dates; no review-date, review-context,
        mapping or output-path arguments are accepted. Discover paths with
        list_files when needed; it lists within APP_ROOT and cannot read contents.

        Unique date/PC/GOP/PTF contributions sum to daily PC PnL totals. Invalid
        or duplicate constituents leave the identifiable PC/date unknown.
        The observed BU/SBU/GPC1/GPC2/GPC3/PC/GOP desk tree includes all supplied
        PnL rows, including numerical exclusions; it is not a cross-source mapping.

        PnL outliers use absolute z-score >= 3 over all known daily totals within each PC;
        reversals use adjacent supplied dates with opposite signs, both absolute
        z-scores >= 2 and a magnitude ratio of 0.5..1.5. There is no minimum
        observation count or time-gap limit. Empty/constant series have no
        z-score. No cumulative checks or monthly summaries are performed.
        Attribution independently aggregates each daily driver by PC/date and
        screens each PC/driver's known history for absolute z-score >= 3. Missing
        constituents stay unknown. Daily evidence records screen availability;
        attribution series summaries and trends are not calculated or exported.
        Attribution drivers may overlap and are not added into a decomposition;
        their source units are not inferred from the PnL EUR scope.

        Adjustments retain every source row, using supplied AMOUNTINEUR in EUR.
        Markdown shows SOURCE/NATURE counts, repeated-entry candidates and
        CREATIONDATE counts with z-score strictly greater than 3. The count
        calendar combines supplied PnL dates and valid creation dates, including
        zero-activity dates, without filling other calendar gaps. There is no
        amount-based screening or FX conversion/check.
        Validation independently counts every supplied history row by team and
        PnL type, showing state counts/percentages and grouped DEValidated counts.
        State labels match exactly; additional labels remain under Other. Team
        and type grouping trims whitespace and ignores case. DEValidated counts
        are already included in totals; source labels do not prove failed approval.

        Args:
            income_attribution_path: Wide attribution CSV for independent driver outliers.
            pnl_path: EUR PnL CSV or single-schema-sheet XLSX for daily PC checks.
            adjustments_path: Complete desk adjustment CSV using supplied AMOUNTINEUR.
            validation_history_path: Complete history CSV for team/type state summaries.
            income_attribution_commentary_path: Original attribution Markdown.
            pnl_commentary_path: Original PnL Markdown.

        Returns:
            The saved Markdown text, with the full desk tree, PC PnL summaries,
            outliers/reversals, attribution outliers, adjustment/validation
            summaries, both complete original commentaries and actual artifact
            paths. Commentary is unparsed source evidence with no automatic
            numerical links. Each successful run saves pnl_review.xlsx and
            pnl_review.md under ANALYSIS_RESULTS_DIR/pnl/<run-id>/, plus daily
            EUR PC/year PNGs, index and manifest under charts/. Images mark
            existing outliers; no chart links/previews appear in returned text.
            Daily tables, exact decimal evidence, exclusions, hashes, source
            references and full adjustment/validation records stay in Excel.
            Saved artifacts are not evidence of inspection. Statistical
            candidates do not establish causes or control failures.

        Raises:
            ToolError: Missing/unsupported files or schemas, ambiguous PnL sheets,
                empty numerical sources, invalid EUR/Notion scope, no valid PnL
                rows, invalid AMOUNTINEUR, or input/output access errors. Correct
                the stated input/access problem before rerunning. Do not relabel
                currencies, drop rows, fabricate commentary or repeat an unchanged
                call to obtain a successful review or workbook-only evidence.
        """
        try:
            return run_analysis(
                income_attribution_path,
                pnl_path,
                adjustments_path,
                validation_history_path,
                income_attribution_commentary_path,
                pnl_commentary_path,
                output_dir=destination,
            )
        except ValueError as exc:
            raise ToolError(str(exc)) from exc
        except OSError as exc:
            raise ToolError(
                "Cannot read PnL inputs or save reports; check source permissions and "
                "ANALYSIS_RESULTS_DIR."
            ) from exc
