"""Build the FastMCP server.

The server itself is tiny: it creates a :class:`fastmcp.FastMCP` instance,
gives it useful ``instructions`` (these are shown to MCP clients / the model),
and lets each tool module register its tools. Put your real tools in the
``tools/`` package.
"""

from __future__ import annotations

from fastmcp import FastMCP

from mcp_agent_template.config import Settings, get_settings
from mcp_agent_template.logging_utils import get_logger, setup_logging
from mcp_agent_template.mcp_server.tools import (
    filesystem_tools,
    pnl_tools,
    post_trade_review_tools,
    risk_metrics_tools,
)
from mcp_agent_template.observability.capture.mcp import MCPObservationMiddleware

logger = get_logger(__name__)

SERVER_INSTRUCTIONS = """\
This server exposes tools via MCP.

How to use it well:
- Every tool's docstring is its contract for the model. Read it before calling.
- Tools return compact, structured results. Prefer calling a tool over guessing.
- `list_files` discovers files within APP_ROOT without reading their contents.
    Paths are project-root-relative. Set recursive=true to include subfolders;
    otherwise only immediate files are returned. Use narrow folders for large trees.
- `run_post_trade_review` requires `folder_path`, a directory with exactly one
    Parquet file with the required post-trade control columns. The filename is not fixed.
    It returns the analysis Markdown and saves report files.
- `run_risk_metrics_analysis` requires an SGMR Parquet path and accepts optional
    Colibris CSV and three commentary Markdown paths. Load the risk-metrics skill.
    It calculates separate movement/value population abs(z) >3 screens and lists
    every observation with both flags. Value scores require at least 20 comparable
    observations; movement scores also cover shorter segments. It returns Markdown
    and saves nine-sheet Excel evidence plus separate risk-value charts. Joint-day
    rows are complete; other Markdown detail tables show at most 15 rows. Rows use
    riskMetricName and perimeterMnemonic. SGMR and Colibris are independent; no
    cross-source reconciliation or SGMR limit consumption is performed. Commentary
    stays complete unprocessed text. Missing checks and full methods remain in Excel.
- `run_pnl_analysis` requires six existing files: EUR desk PnL, attribution,
    adjustments, validation history and both original Markdown commentaries.
    Load the pnl skill and its dataset/interpretation references first. Source
    paths use the server working directory; all supplied dates are reviewed
    independently. It returns Markdown with complete commentary and actual saved
    report paths. Daily workbook evidence and separate PC PnL charts require
    additional inspection; attribution trends are not calculated or exported.
"""


def build_server(settings: Settings | None = None) -> FastMCP:
    """Create the configured FastMCP server and register every supported tool group."""
    settings = settings or get_settings()

    mcp = FastMCP(
        name=settings.mcp_server_name,
        instructions=SERVER_INSTRUCTIONS,
        middleware=[MCPObservationMiddleware()],
    )

    # Register tool groups. Add your own modules here.
    filesystem_tools.register(mcp, settings)
    post_trade_review_tools.register(mcp, settings)
    risk_metrics_tools.register(mcp, settings)
    pnl_tools.register(mcp, settings)

    logger.info("FastMCP server '%s' built.", settings.mcp_server_name)
    return mcp


def run(settings: Settings | None = None) -> None:
    """Own and flush SQLite recording for the complete server process."""
    from mcp_agent_template.observability import ObservabilityRuntime

    settings = settings or get_settings()
    setup_logging(settings.log_level)
    with ObservabilityRuntime.local(settings, process_default=True) as observations:
        with observations.activate():
            _run_server(settings, observations)


def _run_server(settings: Settings | None = None, observations=None) -> None:
    """Run the server using the transport from settings."""
    settings = settings or get_settings()
    mcp = build_server(settings)

    transport = settings.mcp_transport.lower().strip()
    if transport == "stdio":
        logger.info("Starting MCP server on STDIO transport.")
        mcp.run()  # defaults to stdio
    elif transport == "http":
        logger.info("Starting MCP server on HTTP transport at %s", settings.mcp_http_url)
        from starlette.middleware import Middleware

        from mcp_agent_template.observability.capture.server import CloseObservationsOnShutdown

        middleware = [Middleware(CloseObservationsOnShutdown, runtime=observations)]
        mcp.run(
            transport="http",
            host=settings.mcp_host,
            port=settings.mcp_port,
            middleware=middleware,
            uvicorn_config={"log_config": None},
        )
    else:
        raise ValueError(f"Unsupported MCP_TRANSPORT={transport!r}. Use 'stdio' or 'http'.")
