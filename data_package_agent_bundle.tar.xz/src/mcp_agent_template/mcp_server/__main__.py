"""Entry point so the server can be launched as a subprocess.

    python -m mcp_agent_template.mcp_server        # stdio (default)
    MCP_TRANSPORT=http python -m mcp_agent_template.mcp_server

This is exactly the command the agent uses to spawn the server over stdio, and
the command you point the MCP Inspector at.
"""

from __future__ import annotations

from collections.abc import Callable

from mcp_agent_template.mcp_server.server import run


def main(run_server: Callable[[], None] = run) -> None:
    """Run the command-line entry point and translate expected failures for shell users."""
    import _thread
    import argparse
    import sys
    import threading

    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--shutdown-on-stdin",
        action="store_true",
        help="Owned HTTP helper: stop gracefully when the parent closes stdin.",
    )
    args = parser.parse_args()
    if args.shutdown_on_stdin:

        def wait_for_owner() -> None:
            """Interrupt the server when the owning process closes standard input."""
            sys.stdin.buffer.read(1)
            _thread.interrupt_main()

        threading.Thread(target=wait_for_owner, daemon=True, name="http-owner").start()
    try:
        run_server()
    except KeyboardInterrupt:
        if not args.shutdown_on_stdin:
            raise


if __name__ == "__main__":
    main()
