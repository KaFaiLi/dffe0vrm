"""Centralized, typed configuration.

Everything the template needs is read from environment variables (optionally via
a ``.env`` file). Import :func:`get_settings` anywhere you need config; it is
cached so the ``.env`` file is only parsed once per process.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from pydantic import BaseModel, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from mcp_agent_template.observability.config import ObservabilitySettings

# Source checkouts use the package root. Installed wheels use the caller's
# working directory, never the interpreter's Lib/site-packages for app writes.
_MODULE_PATH = Path(__file__).resolve()
REPO_ROOT = (
    _MODULE_PATH.parents[2] if _MODULE_PATH.parents[1].name == "src" else Path.cwd().resolve()
)


class ContextCompactionSettings(BaseModel):
    """Configure history compaction against an explicit model-input allowance.

    The package never guesses a deployment's context window.  When a budget is
    supplied, compaction begins at ``trigger_fraction`` and aims below
    ``target_fraction`` while retaining the requested number of recent groups.
    """

    model_config = {"frozen": True, "extra": "forbid"}

    input_token_budget: int | None = Field(default=None, gt=0)
    trigger_fraction: float = Field(default=0.80, gt=0, lt=1, allow_inf_nan=False)
    target_fraction: float = Field(default=0.60, gt=0, lt=1, allow_inf_nan=False)
    summary_max_tokens: int | None = Field(default=None, gt=0)
    keep_recent_groups: int = Field(default=2, ge=0)

    @model_validator(mode="after")
    def _ordered_fractions(self) -> ContextCompactionSettings:
        """Require the target fraction to leave headroom below the trigger."""
        if self.target_fraction >= self.trigger_fraction:
            raise ValueError("target_fraction must be less than trigger_fraction.")
        return self


class Settings(BaseSettings):
    """Validate runtime settings loaded from environment variables and ``.env``.

    ``app_root`` controls both the selected ``.env`` file and every relative
    runtime path.  Unknown environment keys are ignored so this package can run
    inside larger corporate processes without owning their configuration.
    """

    model_config = SettingsConfigDict(
        env_file=REPO_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
        env_nested_delimiter="_",
        env_nested_max_split=1,
    )

    app_root: Path = Field(default=REPO_ROOT)
    obs: ObservabilitySettings = Field(default_factory=ObservabilitySettings)
    context_compaction: ContextCompactionSettings = Field(default_factory=ContextCompactionSettings)

    def __init__(self, **values):
        """Resolve the application root before Pydantic loads its root-local ``.env``."""
        env_root = next(
            (value for key, value in os.environ.items() if key.lower() == "app_root"), None
        )
        root = Path(values.get("app_root", env_root or REPO_ROOT)).expanduser().resolve()
        values["app_root"] = root
        values.setdefault("_env_file", root / ".env")
        super().__init__(**values)

    # --- LLM / GenAI manager -------------------------------------------------
    genai_provider: str = Field(
        default="socgenai_llm",
        description="LangChain chat-model provider: genai_manager | socgenai_llm.",
    )
    genai_model: str = Field(default="gpt-6-luna")
    genai_temperature: float | None = Field(default=None)
    genai_reasoning_effort: str | None = Field(default=None)
    genai_use_responses_api: bool = Field(
        default=True,
        description="Use the Responses API when the selected provider supports it.",
    )

    # --- MCP server ----------------------------------------------------------
    mcp_transport: str = Field(default="stdio", description="stdio | http")
    mcp_host: str = Field(default="127.0.0.1")
    mcp_port: int = Field(default=8000)
    mcp_server_name: str = Field(default="mcp-agent-template")
    mcp_server_module: str = "mcp_agent_template.mcp_server"
    mcp_tool_timeout: float = Field(
        default=600.0,
        description=(
            "Seconds to wait for an MCP tool call to complete (HTTP connect "
            "+ server processing). Raise this for slow tools or beefy LLM calls "
            "that happen inside a tool. Corresponds to the `timeout` field of "
            "langchain-mcp-adapters' streamable-HTTP connection."
        ),
    )
    mcp_read_timeout: float = Field(
        default=900.0,
        description=(
            "Seconds to keep the SSE stream open waiting for the next event "
            "(i.e. max silence between chunks). 300 s (5 min) is the library "
            "default. Raise this if a tool streams a very long response. "
            "Corresponds to the `sse_read_timeout` field."
        ),
    )

    # --- Skills --------------------------------------------------------------
    skills_dir: str = Field(default="skills")
    analysis_results_dir: str = Field(
        default=".mcp_agent_template/analysis",
        description="Application-relative or absolute directory for saved analysis reports.",
    )

    # --- Agent ---------------------------------------------------------------
    agent_max_iterations: int = Field(
        default=10,
        ge=1,
        description=(
            "Maximum number of tool-call rounds the ReAct agent is allowed per "
            "run. Each round = one LLM call + its tool calls. Mapped to "
            "LangGraph's `recursion_limit` at invocation time (approx. "
            "max_iterations × 3 to account for hook + model + tool nodes). "
            "Raise this for multi-step tasks; lower it to cap costs."
        ),
    )
    agent_call_timeout: float = Field(
        default=120.0,
        description=(
            "Default seconds to wait for a sub-agent tool call (`ask_<name>`, "
            "see agent.multi_agent) to complete when the AgentSpec doesn't set "
            "its own `call_timeout`. Prevents a hung/looping sub-agent from "
            "stalling its parent forever."
        ),
    )
    # --- Logging -------------------------------------------------------------
    log_level: str = Field(default="INFO")
    agent_max_tool_calls: int = Field(default=100, ge=1)
    agent_max_model_calls: int = Field(default=64, ge=1)
    agent_max_concurrent_tools: int = Field(default=8, ge=1)
    agent_run_timeout: float = Field(default=300.0, gt=0, allow_inf_nan=False)

    def resolve_path(self, path: str | Path) -> Path:
        """Return an absolute normalized path rooted at ``app_root`` when relative."""
        candidate = Path(path).expanduser()
        return (candidate if candidate.is_absolute() else self.app_root / candidate).resolve()

    def mcp_server_env(self, transport: str) -> dict[str, str]:
        """Build the MCP subprocess environment without dropping corporate settings.

        A configured temperature is included only when explicit; omitting it is
        required for reasoning-enabled calls.  Paths are resolved before crossing
        the process boundary so child behavior is independent of its working directory.
        """
        return {
            **{
                key: value
                for key, value in os.environ.items()
                if key.lower() not in {"genai_temperature", "genai_reasoning_effort"}
            },
            "APP_ROOT": str(self.app_root),
            "MCP_TRANSPORT": transport,
            "MCP_HOST": self.mcp_host,
            "MCP_PORT": str(self.mcp_port),
            "MCP_SERVER_NAME": self.mcp_server_name,
            "MCP_TOOL_TIMEOUT": str(self.mcp_tool_timeout),
            "MCP_READ_TIMEOUT": str(self.mcp_read_timeout),
            "ANALYSIS_RESULTS_DIR": str(self.resolve_path(self.analysis_results_dir)),
            "GENAI_MODEL": self.genai_model,
            "GENAI_PROVIDER": self.genai_provider,
            **(
                {"GENAI_TEMPERATURE": str(self.genai_temperature)}
                if self.genai_temperature is not None
                else {}
            ),
            **(
                {"GENAI_REASONING_EFFORT": self.genai_reasoning_effort}
                if self.genai_reasoning_effort is not None
                else {}
            ),
            "GENAI_USE_RESPONSES_API": str(self.genai_use_responses_api).lower(),
            "LOG_LEVEL": self.log_level,
            "OBS_MODE": self.obs.mode,
            "OBS_DIR": str(self.resolve_path(self.obs.dir)),
            "OBS_SERVICE_NAME": self.obs.service_name,
            "OBS_FLUSH_INTERVAL_MS": str(self.obs.flush_interval_ms),
            "OBS_METRIC_INTERVAL_SECONDS": str(self.obs.metric_interval_seconds),
        }

    @property
    def skills_path(self) -> Path:
        """Return the absolute skills directory beneath the application root."""
        return self.resolve_path(self.skills_dir)

    @property
    def mcp_http_url(self) -> str:
        """Return the local streamable-HTTP MCP endpoint derived from host and port."""
        return f"http://{self.mcp_host}:{self.mcp_port}/mcp"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-cached settings snapshot.

    Call ``get_settings.cache_clear()`` in tests or controlled reconfiguration
    code when environment changes must be observed within the same process.
    """
    return Settings()
