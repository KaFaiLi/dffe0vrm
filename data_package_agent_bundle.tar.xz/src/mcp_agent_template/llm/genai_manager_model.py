"""Compatibility LangChain adapter for the GenAI API manager library.

The adapter preserves native LangChain messages and tool calls while translating
to either Azure v1 Chat Completions or Responses request shapes.  The shared
``socgenai_llm`` adapter is the required production agent path; this local class
remains for explicit compatibility tests and does not provide a fallback.
"""

from __future__ import annotations

import json
import os
from collections.abc import Sequence
from typing import Any

from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    ChatMessage,
    FunctionMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.messages.tool import ToolCall, invalid_tool_call
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.utils.function_calling import convert_to_openai_tool
from pydantic import Field, StrictBool

from mcp_agent_template.config import get_settings
from mcp_agent_template.tool_results import tool_text


def _default_model_name() -> str:
    """Resolve the default deployment name from environment before validated settings."""
    return os.getenv("GENAI_MODEL") or get_settings().genai_model


def _get(obj: Any, key: str, default: Any = None) -> Any:
    """Read ``key`` from a dict OR an attribute-style object (SDKs vary)."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _lc_message_to_openai(message: BaseMessage) -> dict[str, Any]:
    """Convert a LangChain message to an OpenAI-style ``messages`` entry."""
    if isinstance(message, SystemMessage):
        return {"role": "system", "content": message.content}
    if isinstance(message, HumanMessage):
        return {"role": "user", "content": message.content}
    if isinstance(message, ToolMessage):
        return {
            "role": "tool",
            "content": message.content,
            "tool_call_id": message.tool_call_id,
        }
    if isinstance(message, FunctionMessage):
        return {
            "role": "function",
            "name": message.name,
            "content": message.content,
        }
    if isinstance(message, ChatMessage):
        return {"role": message.role, "content": message.content}
    if isinstance(message, AIMessage):
        out: dict[str, Any] = {"role": "assistant", "content": message.content or ""}
        if message.tool_calls or message.invalid_tool_calls:
            out["content"] = message.content or None
            out["tool_calls"] = [
                {
                    "id": tc["id"],
                    "type": "function",
                    "function": {
                        "name": tc["name"],
                        "arguments": json.dumps(tc["args"]),
                    },
                }
                for tc in message.tool_calls
            ] + [
                {
                    "id": tc.get("id"),
                    "type": "function",
                    "function": {
                        "name": tc.get("name", ""),
                        "arguments": tc.get("args", ""),
                    },
                }
                for tc in message.invalid_tool_calls
            ]
        return out
    raise TypeError(f"Unsupported LangChain message type {type(message).__name__}.")


def _text_content(message: BaseMessage, *, mode: str) -> str:
    """Return text content or reject unsupported multimodal content."""
    if not isinstance(message.content, str):
        raise ValueError(
            f"{mode} mode supports text messages only; got {type(message.content).__name__}."
        )
    return message.content


def _lc_messages_to_responses(messages: list[BaseMessage]) -> list[dict[str, Any]]:
    """Convert the supported LangChain history to Responses input items."""
    converted: list[dict[str, Any]] = []

    def message_item(role: str, text: str, content_type: str) -> dict[str, Any]:
        """Build one typed Responses message item from validated text."""
        return {
            "type": "message",
            "role": role,
            "content": [{"type": content_type, "text": text}],
        }

    for message in messages:
        if isinstance(message, SystemMessage):
            converted.append(
                message_item("system", _text_content(message, mode="Responses"), "input_text")
            )
        elif isinstance(message, HumanMessage):
            converted.append(
                message_item("user", _text_content(message, mode="Responses"), "input_text")
            )
        elif isinstance(message, AIMessage):
            content = message.content
            if isinstance(content, str) and content:
                converted.append(message_item("assistant", content, "output_text"))
            elif isinstance(content, Sequence) and not isinstance(content, (str, bytes)):
                for block in content:
                    block_type = _get(block, "type", None)
                    if block_type == "reasoning":
                        reasoning = _get(block, "reasoning", None)
                        if reasoning:
                            converted.append(
                                {
                                    key: value
                                    for key, value in (
                                        ("type", "reasoning"),
                                        ("id", _get(block, "id", None)),
                                        (
                                            "summary",
                                            [{"type": "summary_text", "text": str(reasoning)}],
                                        ),
                                    )
                                    if value is not None
                                }
                            )
                    elif block_type in {"text", "output_text"}:
                        text = _get(block, "text", None)
                        if text:
                            converted.append(message_item("assistant", str(text), "output_text"))
                    elif block_type in {"tool_call", "function_call"}:
                        call_id = (
                            _get(block, "call_id", None)
                            if block_type == "function_call"
                            else _get(block, "id", None)
                        )
                        if not call_id and block_type == "tool_call":
                            call_id = _get(block, "call_id", None)
                        if not call_id:
                            raise ValueError("Responses function calls require a call ID.")
                        name = _get(block, "name", "")
                        args = _get(block, "args", None)
                        arguments = _get(block, "arguments", None)
                        if arguments is None:
                            arguments = json.dumps(args or {}, ensure_ascii=False)
                        converted.append(
                            {
                                "type": "function_call",
                                "call_id": call_id,
                                "name": name,
                                "arguments": arguments,
                            }
                        )
            elif content:
                raise ValueError("Responses content must be text blocks.")
            if message.invalid_tool_calls:
                raise ValueError("Responses mode cannot replay invalid tool calls.")
            content_call_ids = set()
            if isinstance(content, Sequence) and not isinstance(content, (str, bytes)):
                content_call_ids = {
                    (
                        _get(block, "call_id", None)
                        if _get(block, "type", None) == "function_call"
                        else _get(block, "id", None) or _get(block, "call_id", None)
                    )
                    for block in content
                    if _get(block, "type", None) in {"function_call", "tool_call"}
                }
            for tool_call in message.tool_calls:
                call_id = tool_call.get("id")
                if not call_id:
                    raise ValueError("Responses function calls require a call ID.")
                if call_id in content_call_ids:
                    continue
                converted.append(
                    {
                        "type": "function_call",
                        "call_id": call_id,
                        "name": tool_call["name"],
                        "arguments": json.dumps(tool_call["args"], ensure_ascii=False),
                    }
                )
        elif isinstance(message, ToolMessage):
            call_id = message.tool_call_id
            if not call_id:
                raise ValueError("Responses function-call outputs require a tool call ID.")
            converted.append(
                {
                    "type": "function_call_output",
                    "call_id": call_id,
                    # MCP adapters may represent tool output as a list of text
                    # content blocks rather than a plain string.
                    "output": tool_text(message.content),
                }
            )
        else:
            raise ValueError(
                f"Responses mode does not support LangChain message type {type(message).__name__}."
            )
    return converted


def _flatten_responses_tools(
    tools: Sequence[dict[str, Any]] | None,
) -> list[dict[str, Any]] | None:
    """Flatten classic Chat Completions function tools for Responses."""
    if tools is None:
        return None
    flattened: list[dict[str, Any]] = []
    for tool in tools:
        if not isinstance(tool, dict) or tool.get("type") != "function":
            tool_type = tool.get("type") if isinstance(tool, dict) else type(tool).__name__
            raise ValueError(
                "Responses mode supports only classic function tools; "
                f"hosted/native tool type {tool_type!r} is not supported."
            )
        function = tool.get("function")
        if function is None and "name" in tool:
            function = tool
        if not isinstance(function, dict) or not function.get("name"):
            raise ValueError("Responses function tools require a function name.")
        response_tool = {"type": "function", "name": function["name"]}
        for key in ("description", "parameters", "strict"):
            value = function.get(key, tool.get(key))
            if value is not None:
                response_tool[key] = value
        flattened.append(response_tool)
    return flattened


def _responses_tool_choice(choice: Any) -> Any:
    """Validate and normalize the compatible Responses tool-choice forms."""
    if choice is True or choice == "any":
        return "required"
    if choice is False or choice is None:
        return None
    if isinstance(choice, str):
        if choice in {"auto", "none", "required"}:
            return choice
        if choice:
            return {"type": "function", "name": choice}
        raise ValueError("Responses tool_choice cannot be an empty string.")
    if isinstance(choice, dict) and choice.get("type") == "function":
        function = choice.get("function")
        name = choice.get("name")
        if isinstance(function, dict):
            name = name or function.get("name")
        if not name:
            raise ValueError("Responses function tool_choice requires a function name.")
        return {"type": "function", "name": name}
    raise ValueError(
        "Responses tool_choice must be auto, none, required, any, a boolean, or a function target."
    )


def _chat_tool_choice(choice: Any) -> Any:
    """Normalize LangChain tool-choice aliases to native Chat Completions values."""
    if choice is True or choice == "any":
        return "required"
    if choice is False or choice is None:
        return None
    if isinstance(choice, str) and choice not in {"auto", "none", "required"}:
        return {"type": "function", "function": {"name": choice}}
    return choice


def _responses_usage_metadata(usage: Any) -> dict[str, int] | None:
    """Normalize Responses token usage to LangChain's canonical three counters."""
    if usage is None:
        return None
    input_tokens = _get(usage, "input_tokens", _get(usage, "prompt_tokens", None))
    output_tokens = _get(usage, "output_tokens", _get(usage, "completion_tokens", None))
    total_tokens = _get(usage, "total_tokens", None)
    if input_tokens is None or output_tokens is None:
        return None
    if total_tokens is None:
        total_tokens = input_tokens + output_tokens
    return {
        "input_tokens": int(input_tokens),
        "output_tokens": int(output_tokens),
        "total_tokens": int(total_tokens),
    }


def _responses_response_to_ai_message(response: Any) -> AIMessage:
    """Parse a Responses result into LangChain's Responses v1 message format."""
    status = _get(response, "status", None)
    if status not in {"completed", "incomplete"}:
        raise ValueError(f"Response terminated with unsupported status {status!r}.")
    output = _get(response, "output", None)
    if not isinstance(output, Sequence) or isinstance(output, (str, bytes)):
        raise ValueError("Responses result must contain an output list.")

    content_blocks: list[dict[str, Any]] = []
    tool_calls: list[ToolCall] = []
    invalid_calls = []
    for item in output:
        item_type = _get(item, "type", None)
        if item_type == "message":
            content = _get(item, "content", [])
            if isinstance(content, str):
                if content:
                    content_blocks.append({"type": "text", "text": content})
            elif isinstance(content, Sequence):
                for block in content:
                    if _get(block, "type", None) == "output_text":
                        text = _get(block, "text", None)
                        if text is not None:
                            content_blocks.append({"type": "text", "text": str(text)})
            else:
                raise ValueError("Responses message content must be text blocks.")
        elif item_type == "output_text":
            text = _get(item, "text", None)
            if text is not None:
                content_blocks.append({"type": "text", "text": str(text)})
        elif item_type == "function_call":
            raw_args = _get(item, "arguments", "")
            call_id = _get(item, "call_id", None)
            if not call_id:
                raise ValueError("Responses function calls require a call ID.")
            name = _get(item, "name", "")
            try:
                args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                if not isinstance(args, dict):
                    raise ValueError("Function arguments must be a JSON object.")
            except (json.JSONDecodeError, TypeError, ValueError) as error:
                invalid_calls.append(
                    invalid_tool_call(
                        name=name,
                        args=raw_args if isinstance(raw_args, str) else json.dumps(raw_args),
                        id=call_id,
                        error=str(error),
                    )
                )
                content_blocks.append(
                    {
                        "type": "invalid_tool_call",
                        "name": name,
                        "args": raw_args if isinstance(raw_args, str) else json.dumps(raw_args),
                        "id": call_id,
                        "error": str(error),
                    }
                )
            else:
                tool_calls.append(ToolCall(name=name, args=args, id=call_id))
                content_blocks.append(
                    {
                        "type": "tool_call",
                        "name": name,
                        "args": args,
                        "id": call_id,
                    }
                )
        elif item_type == "reasoning":
            item_id = _get(item, "id", None)
            summary = _get(item, "summary", None)
            if isinstance(summary, str):
                summary = [{"type": "summary_text", "text": summary}]
            if isinstance(summary, Sequence) and not isinstance(summary, (str, bytes)):
                for block in summary:
                    text = _get(block, "text", None)
                    if text:
                        content_blocks.append(
                            {
                                key: value
                                for key, value in (
                                    ("type", "reasoning"),
                                    ("reasoning", str(text)),
                                    ("id", item_id),
                                )
                                if value is not None
                            }
                        )
        elif item_type is not None:
            raise ValueError(f"Responses output item type {item_type!r} is out of scope.")

    if not any(block.get("type") == "text" for block in content_blocks):
        output_text = _get(response, "output_text", None)
        if isinstance(output_text, str):
            content_blocks.append({"type": "text", "text": output_text})

    response_id = _get(response, "id", None)
    usage = _get(response, "usage", None)
    response_metadata: dict[str, Any] = {
        key: value
        for key, value in (
            ("id", response_id),
            ("response_id", response_id),
            ("model", _get(response, "model", None)),
            ("status", status),
            ("output_version", "v1"),
            ("usage", usage),
            (
                "request_id",
                _get(response, "_request_id", _get(response, "request_id", None)),
            ),
        )
        if value is not None
    }
    message = AIMessage(
        content=content_blocks,
        tool_calls=tool_calls,
        invalid_tool_calls=invalid_calls,
        response_metadata=response_metadata,
        id=response_id,
        usage_metadata=_responses_usage_metadata(usage),
    )
    return message


def _extract_reasoning(*sources: Any) -> str | None:
    """Best-effort extraction of reasoning text from an OpenAI-style completion.

    Different OpenAI-compatible providers (via the GenAI API manager) surface
    a model's reasoning/thinking trace differently:

    - a plain string on ``message.reasoning_content`` or ``message.reasoning``
      (DeepSeek/Groq-style, some proxies).
    - a plain string at the ``choice`` or top-level ``response`` instead of
      ``message`` (some proxies put it as a sibling of ``message``).
    - a structured value: a dict with a ``content``/``text``/``summary`` key,
      or a list of blocks (OpenRouter's ``reasoning_details``), each with a
      ``text``/``content`` field.

    Checks every ``source`` (pass message, choice, response -- in that
    priority order) and both key names; returns ``None`` if nothing is found.
    """
    for source in sources:
        if source is None:
            continue
        for key in ("reasoning_content", "reasoning", "reasoning_details"):
            value = _get(source, key, None)
            if not value:
                continue
            if isinstance(value, str):
                return value
            if isinstance(value, dict):
                text = value.get("content") or value.get("text") or value.get("summary")
                if text:
                    return str(text)
            elif isinstance(value, list):
                parts = [
                    str(_get(item, "text", None) or _get(item, "content", None) or item)
                    for item in value
                    if item
                ]
                if parts:
                    return "\n".join(parts)
            else:
                return str(value)
    return None


def _openai_response_to_ai_message(response: Any) -> AIMessage:
    """Parse an OpenAI-style response into a LangChain ``AIMessage``."""
    choices = _get(response, "choices", None)
    if not isinstance(choices, Sequence) or isinstance(choices, (str, bytes)) or not choices:
        raise ValueError("Chat Completions result must contain a non-empty choices list.")
    choice = choices[0]
    message = _get(choice, "message", {})
    content = _get(message, "content", "") or ""

    tool_calls: list[ToolCall] = []
    invalid_calls = []
    for raw in _get(message, "tool_calls", []) or []:
        fn = _get(raw, "function", {})
        args_raw = _get(fn, "arguments", "{}")
        try:
            args = json.loads(args_raw) if isinstance(args_raw, str) else dict(args_raw)
            if not isinstance(args, dict):
                raise ValueError("Function arguments must be a JSON object.")
        except (json.JSONDecodeError, TypeError, ValueError) as error:
            invalid_calls.append(
                invalid_tool_call(
                    name=_get(fn, "name", ""),
                    args=args_raw if isinstance(args_raw, str) else json.dumps(args_raw),
                    id=_get(raw, "id", None),
                    error=str(error),
                )
            )
        else:
            tool_calls.append(
                ToolCall(
                    name=_get(fn, "name", ""),
                    args=args,
                    id=_get(raw, "id", None),
                )
            )

    usage = _get(response, "usage", None)
    response_metadata = {"usage": usage} if usage is not None else {}

    additional_kwargs: dict[str, Any] = {}
    reasoning = _extract_reasoning(message, choice, response)
    if reasoning:
        # Stored under the same key the notebook trace renderer looks for
        # (`mcp_agent_template.notebook._extract_reasoning`).
        additional_kwargs["reasoning_content"] = reasoning

    return AIMessage(
        content=content,
        tool_calls=tool_calls,
        invalid_tool_calls=invalid_calls,
        additional_kwargs=additional_kwargs,
        response_metadata=response_metadata,
    )


class GenAIManagerChatModel(BaseChatModel):
    """LangChain chat model backed by your GenAI manager library.

    Configure via the GenAIManager; subclasses can override :meth:`_completion`
    or :meth:`_responses_completion` for offline tests or custom transports.
    """

    model: str = Field(default_factory=_default_model_name)
    temperature: float = Field(default=0.0)
    use_responses_api: StrictBool = False
    # ``bind_tools`` stores OpenAI-style schemas here so both transports can
    # derive their native request representation from the same bound tools.
    tools: list[dict[str, Any]] | None = Field(default=None)
    model_kwargs: dict[str, Any] = Field(default_factory=dict)

    @property
    def _llm_type(self) -> str:
        """Return LangChain's stable serialization identifier for this adapter."""
        return "genai_manager"

    def bind_tools(
        self,
        tools: Sequence[Any],
        *,
        tool_choice: Any = None,
        strict: bool | None = None,
        parallel_tool_calls: bool | None = None,
        **kwargs: Any,
    ) -> GenAIManagerChatModel:
        """Attach tools (converted to OpenAI tool schemas) to the model."""
        formatted = [convert_to_openai_tool(t, strict=strict) for t in tools]
        if tool_choice is not None:
            kwargs["tool_choice"] = tool_choice
        if parallel_tool_calls is not None:
            kwargs["parallel_tool_calls"] = parallel_tool_calls
        return self.bind(tools=formatted, **kwargs)

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Dispatch one synchronous request and return a native LangChain result."""
        request_kwargs = dict(self.model_kwargs)
        request_kwargs["temperature"] = self.temperature
        if stop is not None:
            request_kwargs["stop"] = stop
        request_kwargs.update(kwargs)
        tools = request_kwargs.pop("tools", self.tools)
        for key in ("ls_structured_output_format", "structured_output_format"):
            request_kwargs.pop(key, None)
        if "tool_choice" in request_kwargs:
            tool_choice = _chat_tool_choice(request_kwargs["tool_choice"])
            if tool_choice is None:
                request_kwargs.pop("tool_choice")
            else:
                request_kwargs["tool_choice"] = tool_choice
        elif tools:
            request_kwargs["tool_choice"] = "auto"
        if "use_responses_api" in request_kwargs:
            raise ValueError("use_responses_api is constructor-only and cannot be invoked.")
        if request_kwargs.get("strict") is not None:
            raise ValueError("strict must be supplied to bind_tools(), not as a request option.")

        if self.use_responses_api:
            response = self._responses_completion(
                messages=messages,
                tools=tools,
                stop=request_kwargs.pop("stop", None),
                **request_kwargs,
            )
            ai_message = _responses_response_to_ai_message(response)
        else:
            oai_messages = [_lc_message_to_openai(m) for m in messages]
            response = self._completion(
                messages=oai_messages,
                tools=tools,
                stop=request_kwargs.pop("stop", None),
                **request_kwargs,
            )
            ai_message = _openai_response_to_ai_message(response)
        return ChatResult(generations=[ChatGeneration(message=ai_message)])

    @staticmethod
    def _extract_json_payload(obj: Any) -> Any:
        """Extract JSON data from supported SDK, Pydantic, text, or mapping results."""
        if isinstance(obj, dict):
            return obj
        # OpenAI SDK responses are Pydantic v2 models on the supported path.
        if hasattr(obj, "model_dump"):
            try:
                return obj.model_dump()
            except Exception:
                pass
        # Retain the Pydantic v1 ``json`` path for explicit compatibility inputs.
        if hasattr(obj, "json"):
            try:
                raw_json = obj.json()
                if isinstance(raw_json, str):
                    return json.loads(raw_json)
                return raw_json
            except Exception:
                pass
        if hasattr(obj, "text"):
            text = obj.text
        elif isinstance(obj, str):
            text = obj
        else:
            text = str(obj)
        text = text.strip()
        start = text.find("{")
        end = text.rfind("}") + 1
        if start != -1 and end > start:
            try:
                return json.loads(text[start:end])
            except json.JSONDecodeError:
                pass
        return text

    @staticmethod
    def _call_and_parse(
        genai_api_client: Any,
        model: str,
        temperature: float,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Call the manager's Chat Completions entry point and parse its payload."""
        extra = dict(kwargs)
        if tools is not None:
            extra["tools"] = tools
            if tools and "tool_choice" not in extra:
                extra["tool_choice"] = "auto"

        result = genai_api_client.get_genai_completion(
            model=model,
            messages=messages,
            temperature=temperature,
            **extra,
        )
        payload = GenAIManagerChatModel._extract_json_payload(result)
        return payload if isinstance(payload, dict) else {}

    def _completion(
        self,
        *,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        stop: list[str] | None,
        **kwargs: Any,
    ) -> Any:
        """Call the GenAI API manager and return an OpenAI-style response dict."""
        from genai_api_manager import GenAiApiClient  # lazy import

        client = GenAiApiClient()
        request_kwargs = dict(kwargs)
        temperature = request_kwargs.pop("temperature", self.temperature)
        if stop is not None:
            request_kwargs["stop"] = stop
        if tools is not None:
            request_kwargs["tools"] = tools
        payload = self._call_and_parse(
            genai_api_client=client,
            model=self.model,
            temperature=temperature,
            messages=messages,
            **request_kwargs,
        )
        # Preserve the complete parsed response so the downstream converter can
        # read native ``choices[0].message.tool_calls`` and usage metadata.
        return payload

    def _build_responses_payload(
        self,
        *,
        messages: list[BaseMessage],
        tools: list[dict[str, Any]] | None,
        stop: list[str] | None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Build the deliberately small Responses request supported locally."""
        options = dict(kwargs)
        for key in ("ls_structured_output_format", "structured_output_format"):
            options.pop(key, None)
        if stop is not None:
            options["stop"] = stop
        if options.get("stop") is not None:
            raise ValueError("stop is not supported by the local Responses adapter.")
        if options.get("stream_options") is not None:
            raise ValueError("stream_options are not supported by the local Responses adapter.")
        if options.get("stream") is True or options.get("streaming") is True:
            raise ValueError("Responses streaming is not supported by the local adapter.")
        options.pop("stream", None)
        options.pop("streaming", None)
        if options.get("n", 1) not in (None, 1):
            raise ValueError("Responses supports only one result (n=1).")
        for key in ("previous_response_id", "background"):
            if key in options and options[key] is not None:
                raise ValueError(f"Responses option {key!r} is out of scope for the local adapter.")
        for key in (
            "functions",
            "function_call",
            "response_format",
            "structured_output_format",
            "strict",
            "logprobs",
            "top_logprobs",
        ):
            if options.get(key) is not None:
                raise ValueError(f"Responses option {key!r} is not supported by the local adapter.")

        limits = [
            options.pop(key)
            for key in ("max_tokens", "max_completion_tokens", "max_output_tokens")
            if options.get(key) is not None
        ]
        if limits and any(value != limits[0] for value in limits):
            raise ValueError("Conflicting output token limits.")
        if limits:
            options["max_output_tokens"] = limits[0]
        options.pop("max_tokens", None)
        options.pop("max_completion_tokens", None)
        options.pop("n", None)
        options.pop("stop", None)
        if options.get("reasoning_effort") is not None:
            effort = options.pop("reasoning_effort")
            reasoning = dict(options.get("reasoning") or {})
            if reasoning.get("effort") not in (None, effort):
                raise ValueError("Conflicting reasoning effort settings.")
            reasoning["effort"] = effort
            options["reasoning"] = reasoning

        if "tool_choice" in options:
            tool_choice = _responses_tool_choice(options["tool_choice"])
            if tool_choice is None:
                options.pop("tool_choice")
            else:
                options["tool_choice"] = tool_choice
        elif tools:
            options["tool_choice"] = "auto"

        payload: dict[str, Any] = {
            "model": self.model,
            "input": _lc_messages_to_responses(messages),
        }
        flattened_tools = _flatten_responses_tools(tools)
        if flattened_tools is not None:
            payload["tools"] = flattened_tools
        payload.update({key: value for key, value in options.items() if value is not None})
        return payload

    def _responses_completion(
        self,
        *,
        messages: list[BaseMessage],
        tools: list[dict[str, Any]] | None,
        stop: list[str] | None,
        **kwargs: Any,
    ) -> Any:
        """Dispatch a validated payload through the manager's non-streaming Responses API."""
        from genai_api_manager import GenAiApiClient  # lazy import

        client = GenAiApiClient()
        payload = self._build_responses_payload(
            messages=messages,
            tools=tools,
            stop=stop,
            **kwargs,
        )
        return client.get_genai_response(request=payload)
