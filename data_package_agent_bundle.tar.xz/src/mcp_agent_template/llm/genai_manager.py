"""GenAI API manager.

A single choke-point for creating chat models. The rest of the app (agent,
notebook) just calls :func:`get_chat_model` and never imports an LLM library
directly, so you can change how models are built in exactly one place.

Compatibility providers:
- ``genai_manager``: wraps ``genai_api_manager.GenAiApiClient`` via
  :class:`~mcp_agent_template.llm.genai_manager_model.GenAIManagerChatModel`.
  Install with ``uv sync --extra genai-manager`` and set
  ``GENAI_PROVIDER=genai_manager`` in ``.env``.
- ``socgenai_llm``: uses the shared ``socgenai_llm.GenAIChatModel`` adapter.
    Install with ``uv sync --extra socgenai-llm`` and set
    ``GENAI_PROVIDER=socgenai_llm`` in ``.env``.

The returned object is always a LangChain ``BaseChatModel``, which is what
``langchain.agents.create_agent`` and ``.bind_tools`` expect.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel

from mcp_agent_template.config import Settings, get_settings
from mcp_agent_template.logging_utils import get_logger

logger = get_logger(__name__)


class GenAIManager:
    """Central factory and request-policy layer for LangChain chat models.

    The configured provider is selected explicitly and failures are propagated;
    this layer never retries through another provider or silently changes the
    requested model.  Shared request defaults belong here so every agent builder
    receives the same Responses and reasoning-summary policy.
    """

    def __init__(self, settings: Settings | None = None) -> None:
        """Capture an explicit settings snapshot without constructing an SDK client."""
        self.settings = settings or get_settings()

    # -- public API ----------------------------------------------------------
    def get_chat_model(
        self,
        *,
        model: str | None = None,
        temperature: float | None = None,
        use_responses_api: bool | None = None,
        **kwargs: Any,
    ) -> BaseChatModel:
        """Build a chat model for the configured provider.

        Args:
            model: Override the default model name from settings.
            temperature: Override the default sampling temperature.
            use_responses_api: Select the Responses adapter when true.
            **kwargs: Passed through to the underlying model constructor.

        Raises:
            ValueError: If the configured compatibility provider is unknown.
        """
        provider = self.settings.genai_provider.lower().strip()
        model = model or self.settings.genai_model
        temperature = self.settings.genai_temperature if temperature is None else temperature
        use_responses_api = (
            self.settings.genai_use_responses_api
            if use_responses_api is None
            else use_responses_api
        )
        effort = self.settings.genai_reasoning_effort
        model_options = kwargs.get("model_kwargs")
        model_options = model_options if isinstance(model_options, dict) else {}
        reasoning = kwargs.get("reasoning")
        model_reasoning = model_options.get("reasoning")
        has_explicit_effort = (
            kwargs.get("reasoning_effort") is not None
            or (isinstance(reasoning, dict) and reasoning.get("effort") is not None)
            or model_options.get("reasoning_effort") is not None
            or (isinstance(model_reasoning, dict) and model_reasoning.get("effort") is not None)
        )
        if effort is not None and not has_explicit_effort:
            if use_responses_api and provider == "socgenai_llm":
                model_options = deepcopy(model_options)
                model_options["reasoning_effort"] = effort
                kwargs["model_kwargs"] = model_options
            elif use_responses_api:
                reasoning = deepcopy(reasoning or {})
                reasoning["effort"] = effort
                kwargs["reasoning"] = reasoning
            else:
                kwargs["reasoning_effort"] = effort
        logger.info("Building chat model: provider=%s model=%s", provider, model)

        builders = {
            "genai_manager": self._build_genai_manager_model,
            "socgenai_llm": self._build_socgenai_llm_model,
        }
        if provider not in builders:
            raise ValueError(
                f"Unknown GENAI_PROVIDER={provider!r}. Expected one of: {', '.join(builders)}."
            )
        return builders[provider](
            model=model, temperature=temperature, use_responses_api=use_responses_api, **kwargs
        )

    # -- providers -----------------------------------------------------------
    def _build_genai_manager_model(
        self,
        *,
        model: str,
        temperature: float | None,
        use_responses_api: bool | None = None,
        **kwargs: Any,
    ) -> BaseChatModel:
        """Build a chat model backed by your GenAI manager library.

        Your GenAI manager is a library you call like
        ``genai_api_manager.SomeClass(...).completion(...)`` and which returns an
        OpenAI-style response. :class:`GenAIManagerChatModel` adapts Chat
        Completions and the explicitly selected Responses transport to LangChain.

        This builds the model successfully; it raises a clear error only when you
        actually call the LLM before configuring the selected transport (so the agent
        graph still compiles and tools/skills can be inspected).
        """
        from mcp_agent_template.llm.genai_manager_model import GenAIManagerChatModel

        return GenAIManagerChatModel(
            model=model,
            temperature=0.0 if temperature is None else temperature,
            use_responses_api=False if use_responses_api is None else use_responses_api,
            model_kwargs=kwargs,
        )

    @staticmethod
    def _build_socgenai_llm_model(
        *,
        model: str,
        temperature: float | None,
        use_responses_api: bool | None = None,
        **kwargs: Any,
    ) -> BaseChatModel:
        """Build the required shared SocGen adapter with Responses policy intact.

        Constructor fields are separated from provider request options using the
        adapter's Pydantic model fields.  Responses calls always request detailed
        reasoning summaries; caller-supplied reasoning options are preserved.
        """
        try:
            from socgenai_llm import GenAIChatModel
        except ImportError as e:
            raise ImportError(
                "The socgenai_llm provider requires the optional dependency. "
                "Install it with `uv sync --extra socgenai-llm`."
            ) from e

        request_options = deepcopy(kwargs.pop("model_kwargs", {}))
        if use_responses_api:
            reasoning = kwargs.get("reasoning", request_options.pop("reasoning", {})) or {}
            kwargs["reasoning"] = {"summary": "detailed", **deepcopy(reasoning)}
        constructor = {
            key: value for key, value in kwargs.items() if key in GenAIChatModel.model_fields
        }
        request_options.update(
            {key: value for key, value in kwargs.items() if key not in GenAIChatModel.model_fields}
        )
        if request_options:
            constructor["model_kwargs"] = request_options
        return GenAIChatModel(
            model=model,
            temperature=temperature,
            use_responses_api=use_responses_api,
            **constructor,
        )


def get_chat_model(
    *,
    model: str | None = None,
    temperature: float | None = None,
    settings: Settings | None = None,
    **kwargs: Any,
) -> BaseChatModel:
    """Build a chat model through the central factory using optional settings."""
    return GenAIManager(settings=settings).get_chat_model(
        model=model, temperature=temperature, **kwargs
    )
