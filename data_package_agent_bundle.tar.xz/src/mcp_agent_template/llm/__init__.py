"""Expose the approved GenAI-backed LangChain model factory used by agent builders."""

from mcp_agent_template.llm.genai_manager import GenAIManager, get_chat_model

__all__ = ["GenAIManager", "get_chat_model"]
