"""Checkout-only helpers for the Data Package Agent notebooks."""
