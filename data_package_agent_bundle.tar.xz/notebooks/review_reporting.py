"""Validate a market review against its run evidence and render one finding.

Validation establishes structure, trace provenance and declared coverage, not the
correctness of an auditor's judgment. Evidence excerpts refer to tool reports;
they do not imply that the underlying workbook or source record was opened.
"""

from __future__ import annotations

import hashlib
import html
import json
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Annotated, Any, Literal, get_args

from langchain_core.messages import AIMessage, ToolMessage
from pydantic import BaseModel, ConfigDict, Field, model_validator

Topic = Literal["pnl", "risk_metrics", "post_trade"]
EvidenceMode = Literal["verbatim", "catalog"]
Text = Annotated[str, Field(min_length=1)]
TOPIC_TOOLS = {
    "pnl": "run_pnl_analysis",
    "risk_metrics": "run_risk_metrics_analysis",
    "post_trade": "run_post_trade_review",
}
TOOL_ARGUMENTS = {
    "pnl": frozenset(
        {
            "pnl_path",
            "income_attribution_path",
            "adjustments_path",
            "validation_history_path",
            "income_attribution_commentary_path",
            "pnl_commentary_path",
        }
    ),
    "risk_metrics": frozenset(
        {
            "sgmr_path",
            "colibris_path",
            "risk_metrics_commentary_path",
            "stress_test_commentary_path",
            "var_svar_commentary_path",
        }
    ),
    "post_trade": frozenset({"folder_path"}),
}
SOURCE_ARGUMENTS = {
    "pnl": "pnl_path",
    "attribution": "income_attribution_path",
    "adjustments": "adjustments_path",
    "validation": "validation_history_path",
    "ia_commentary": "income_attribution_commentary_path",
    "pnl_commentary": "pnl_commentary_path",
    "risk_consumption": "sgmr_path",
    "excess_events": "colibris_path",
    "risk_commentary": "risk_metrics_commentary_path",
    "stress_commentary": "stress_test_commentary_path",
    "var_commentary": "var_svar_commentary_path",
    "post_trade_cases": "folder_path",
}
CHECK_TOPICS = {
    **{f"D{i:02}": None for i in range(1, 5)},
    **{f"P{i:02}": "pnl" for i in range(1, 12)},
    **{f"R{i:02}": "risk_metrics" for i in range(1, 11)},
    **{f"T{i:02}": "post_trade" for i in range(1, 10)},
    **{f"C{i:02}": None for i in range(1, 3)},
}
Comparison = Literal[
    "pnl_attribution",
    "pnl_adjustments_validation",
    "pnl_risk",
    "risk_excess_workflow",
    "numbers_commentary",
    "post_trade_activity",
]
COMPARISONS = get_args(Comparison)


class Record(BaseModel):
    """Reject undeclared fields and avoid silently coercing report content."""

    model_config = ConfigDict(extra="forbid", strict=True, str_strip_whitespace=True)


class Source(Record):
    id: Text
    path: Text
    topic: Topic
    kind: Literal[
        "pnl",
        "attribution",
        "adjustments",
        "validation",
        "ia_commentary",
        "pnl_commentary",
        "risk_consumption",
        "excess_events",
        "risk_commentary",
        "stress_commentary",
        "var_commentary",
        "post_trade_cases",
    ]
    scope: Text


class MappingBasis(Record):
    """An operator-supplied relationship, never an inferred entity match."""

    id: Text
    source_ids: list[str] = Field(min_length=2)
    scope: Text
    period: Text
    measurement_basis: Text
    reference: Text


class Criterion(Record):
    id: Text
    requirement: Text
    reference: Text


class EvidenceReference(Record):
    id: Text
    source_id: Text = Field(
        description="Manifest source ID established by successful tool-report binding."
    )
    locator: Text = Field(
        description="Exact filename/path locator copied from the quoted report row, including "
        "its original Markdown escaping. Prefer the displayed locator; the trusted PnL "
        "full-source-path equivalent is accepted only when the report compacts that path "
        "to an unambiguous basename and preserves the entire row/record suffix. "
        "A manifest path alone or generic heading does not establish a verbatim citation. "
        "Server-resolved catalog records instead use a tool-report number and line number."
    )
    excerpt: Annotated[
        str,
        Field(
            min_length=8,
            description="Verbatim text from one captured tool-report line. In verbatim mode "
            "the source locator must occur on that same line. Copy the complete Markdown "
            "evidence row when possible, preserving all escaping. Catalog mode copies the "
            "exact server-owned line. "
            "Do not combine a source-inventory path with a summary from another report line.",
        ),
    ]
    level: Literal["tool_report"] = "tool_report"


class EvidenceSelection(Record):
    """Select server-owned evidence without retyping or reassigning its contents."""

    id: Text
    catalog_id: Text = Field(
        description="Exact ID returned by lookup_review_evidence for this run."
    )


class TopicCoverage(Record):
    topic: Topic
    status: Literal["completed", "failed", "timed_out", "not_run"]
    explanation: Text


class CheckResult(Record):
    check_id: Text
    status: Literal[
        "exception_identified",
        "no_exception_identified",
        "insufficient_evidence",
        "not_performed",
        "not_applicable",
    ]
    basis: Text
    evidence_ids: list[str]


class Observation(Record):
    id: Text
    topic: Topic = Field(
        description="Primary theme of this observation. Cross-source supporting observations "
        "may cite multiple topics' checks only with actual evidence for every cited topic, "
        "including this primary theme."
    )
    check_ids: list[str] = Field(
        min_length=1,
        description="Known checklist IDs. Topic-specific checks must represent exactly the "
        "topics of the cited evidence and include the primary theme. Shared D/C checks alone "
        "may span topics, but still require evidence for the primary theme.",
    )
    statement: Text
    measures_and_basis: Text
    contrary_evidence: Text
    uncertainty: Text
    follow_up: Text
    evidence_ids: list[str] = Field(min_length=1)


class CrossSourceComparison(Record):
    comparison: Comparison
    relationship: Literal["confirmed", "contextual", "contradictory", "ambiguous", "unlinked"]
    assessment: Text
    mapping_id: str | None
    compatibility_limits: list[str]
    evidence_ids: list[str]
    follow_up: Text


class FinalFinding(Record):
    disposition: Literal["supported_finding", "further_evidence_required", "no_finding_identified"]
    title: Text
    conclusion: Text
    criterion_ids: list[str]
    condition: Text
    cross_source_comparisons: list[Comparison]
    cause: Text
    demonstrated_effect: Text
    potential_exposure: Text
    recommendation: Text
    limitations: list[str]
    evidence_ids: list[str]


class ArtifactReference(Record):
    topic: Topic
    path: Text


class AuditReport(Record):
    """One consolidated assessment, with its supporting workpapers."""

    schema_version: Literal["1.0"]
    run_id: Text
    scope: Text
    sources: list[Source]
    mappings: list[MappingBasis]
    criteria: list[Criterion]
    execution_status: Literal["completed", "partial", "failed"]
    topic_coverage: list[TopicCoverage]
    checks: list[CheckResult]
    evidence: list[EvidenceReference]
    observations: list[Observation]
    cross_source_matrix: list[CrossSourceComparison]
    final_finding: FinalFinding
    evidence_requests: list[str]
    artifacts: list[ArtifactReference]

    @model_validator(mode="after")
    def complete_registers(self) -> AuditReport:
        """Require complete registers without imposing positive audit conclusions."""
        _exact_keys([c.check_id for c in self.checks], set(CHECK_TOPICS), "checklist")
        _exact_keys([c.topic for c in self.topic_coverage], set(TOPIC_TOOLS), "topics")
        _exact_keys(
            [c.comparison for c in self.cross_source_matrix], set(COMPARISONS), "comparisons"
        )
        for label, values in (
            ("sources", self.sources),
            ("evidence", self.evidence),
            ("observations", self.observations),
        ):
            ids = [v.id for v in values]
            if len(set(ids)) != len(ids):
                raise ValueError(f"Duplicate IDs in {label}.")
        return self


class _CatalogAuditDraft(AuditReport):
    """The model supplies selections; the server owns the final evidence records."""

    evidence: list[EvidenceSelection]


def _exact_keys(keys: list[str], expected: set[str], label: str) -> None:
    if len(keys) != len(expected) or set(keys) != expected:
        raise ValueError(f"Incomplete or duplicate {label}; expected {sorted(expected)}.")


@dataclass
class RunEvidence:
    """Facts collected by the caller from messages, not supplied by the model."""

    statuses: dict[str, str] = field(default_factory=lambda: dict.fromkeys(TOPIC_TOOLS, "not_run"))
    reports: list[tuple[str, set[str], str]] = field(default_factory=list)
    analyses: list[dict[str, Any]] = field(default_factory=list)
    artifacts: dict[str, str] = field(default_factory=dict)
    supporting_artifacts: dict[str, str] = field(default_factory=dict)
    main_skill_loaded: bool = False


def _pnl_section_lines(body: str, sources: list[Source]) -> dict[int, str]:
    """Bind summary table lines to the source owning each PnL report section.

    Only renderer-owned numerical sections of this report format are eligible.
    Original commentary permanently ends the scope, so its headings cannot
    impersonate numerical sections. Ambiguous source kinds are not assigned.
    These are tool-calculation citations, never claims of raw-source inspection.
    """
    if not body.startswith("# PnL and Income Attribution Review\n"):
        return {}
    from mcp_agent_template.analysis.pnl.reporting import SECTION_SOURCES

    bindings, source_id = {}, None
    for index, line in enumerate(body.splitlines(), 1):
        if line.startswith("## Original "):
            break
        if line.startswith("## "):
            kind = SECTION_SOURCES.get(line[3:])
            matches = [s.id for s in sources if s.topic == "pnl" and s.kind == kind]
            source_id = matches[0] if len(matches) == 1 else None
        elif source_id and line.startswith("| "):
            bindings[index] = source_id
    return bindings


def _risk_excess_lines(body: str, sources: list[Source]) -> dict[int, str]:
    """Bind renderer-owned excessId rows to the single supplied Colibris source.

    Excess governance deliberately omits per-row file locators. Bind only that
    numerical section of the known risk report format, declining ambiguous source
    populations. Stop before literal commentary so source-owned headings cannot
    impersonate calculated event evidence. No sources or workbooks are opened.
    """
    if not body.startswith("# Risk Metrics Analysis\n"):
        return {}
    matches = [s.id for s in sources if s.topic == "risk_metrics" and s.kind == "excess_events"]
    if len(matches) != 1:
        return {}
    bindings, excess_section = {}, False
    for index, line in enumerate(body.splitlines(), 1):
        if line.startswith("## Commentary supplied for agent review"):
            break
        if line.startswith("## "):
            excess_section = line == "## Excess governance"
        elif excess_section and line.startswith("| "):
            bindings[index] = matches[0]
    return bindings


def build_evidence_catalog(
    captured: RunEvidence, sources: list[Source]
) -> dict[str, EvidenceReference]:
    """Index exact successful tool-report lines without reading sources or workbooks.

    Multi-source reports require an unambiguous filename/path marker, a
    renderer-owned PnL/excess-governance section binding, or a literal risk-commentary
    source block. Citations use report and line numbers rather than publishing
    internal digests or inventing raw source locations.
    """
    source_by_id = {source.id: source for source in sources}
    markers: dict[str, set[str]] = {}
    for source in sources:
        for marker in (Path(source.path).resolve().as_posix(), Path(source.path).name):
            markers.setdefault(marker, set()).add(source.id)
    marker_pattern = (
        re.compile(
            r"(?<![\w.-])(?:"
            + "|".join(re.escape(marker) for marker in sorted(markers, key=len, reverse=True))
            + r")(?![\w.-])"
        )
        if markers
        else None
    )
    # Stable human-readable report numbers; digests remain internal catalog keys.
    report_numbers = {
        key: ordinal
        for ordinal, key in enumerate(
            sorted({(topic, tuple(sorted(ids)), body) for topic, ids, body in captured.reports}),
            1,
        )
    }
    catalog = {}
    for topic, source_ids, body in captured.reports:
        if not source_ids or any(
            key not in source_by_id or source_by_id[key].topic != topic for key in source_ids
        ):
            continue
        report_digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
        report_sources = [source_by_id[key] for key in source_ids]
        sections = {
            **_pnl_section_lines(body, report_sources),
            **_risk_excess_lines(body, report_sources),
        }
        pending_commentary: set[str] = set()
        commentary_source: set[str] = set()
        commentary_fence = ""
        for index, line in enumerate(body.splitlines(), 1):
            # Risk reports wrap complete commentary in a fence longer than any
            # source backtick run. Bind those literal lines to the explicit file,
            # including lines mentioning another source; never parse their claims.
            if commentary_fence and line == commentary_fence:
                commentary_fence, commentary_source = "", set()
                continue
            if pending_commentary and re.fullmatch(r"`{3,}text", line):
                commentary_fence = line.removesuffix("text")
                commentary_source, pending_commentary = pending_commentary, set()
                continue
            if not line.strip() or len(line) < 8:
                continue
            if index in sections:
                matched = {sections[index]}
            elif commentary_fence:
                matched = commentary_source
            elif len(source_ids) == 1:
                matched = source_ids
            else:
                matched = set()
                if marker_pattern is not None:
                    for match in marker_pattern.finditer(_report_marker(line)):
                        matched.update(markers[match.group()])
            if not commentary_fence:
                pending_commentary = (
                    matched
                    if topic == "risk_metrics"
                    and line.startswith("Source: ")
                    and len(matched) == 1
                    and matched.issubset(source_ids)
                    and source_by_id[next(iter(matched))].kind
                    in {"risk_commentary", "stress_commentary", "var_commentary"}
                    else set()
                )
            if len(matched) != 1 or not matched.issubset(source_ids):
                continue
            source_id = next(iter(matched))
            identity = json.dumps(
                [topic, report_digest, source_id, index, line], ensure_ascii=False
            )
            catalog_id = "catalog-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20]
            # Every field is server-owned. Preserve the exact line, including
            # whitespace, rather than applying model-input whitespace coercion.
            reference = EvidenceReference.model_construct(
                id=catalog_id,
                source_id=source_id,
                locator=(
                    f"tool_report:{topic}:"
                    f"{report_numbers[(topic, tuple(sorted(source_ids)), body)]}:line:{index}"
                ),
                excerpt=line,
                level="tool_report",
            )
            existing = catalog.get(catalog_id)
            if existing is not None and existing != reference:
                raise ValueError("Evidence catalog ID collision.")
            catalog[catalog_id] = reference
    return catalog


def _text(message: Any) -> str:
    return message.text


def capture_run_evidence(
    messages: list[Any],
    sources: list[Source],
    output_dir: Path,
    *,
    expected_arguments: Mapping[str, Mapping[str, Any]] | None = None,
) -> RunEvidence:
    """Read successful nested tool messages and match their actual input paths.

    Only files inside this invocation's unique output folder can be artifacts.
    A successful child answer alone is not evidence of a successful analysis.
    Failed children expose no partial nested trace in the existing tree adapter.
    Expected arguments bind current source paths; unsupported tool arguments
    are excluded before evidence is accepted. Source-bound follow-ups retain their actual
    arguments and artifacts but do not replace canonical population coverage.
    """
    result = RunEvidence()
    calls = {c["id"]: c for m in messages if isinstance(m, AIMessage) for c in m.tool_calls}
    for message in messages:
        if not isinstance(message, ToolMessage):
            continue
        call = calls.get(message.tool_call_id, {})
        if (
            call.get("name") == "load_skill"
            and call.get("args", {}).get("name") == "market-activity-review"
            and message.status == "success"
        ):
            result.main_skill_loaded = True
        topic = call.get("name", "").removeprefix("ask_")
        if topic not in TOPIC_TOOLS:
            continue
        status = "timed_out" if "timed out after" in _text(message) else "failed"
        artifact = message.artifact if isinstance(message.artifact, dict) else {}
        children = artifact.get("messages", []) if message.status == "success" else []
        child_calls = {
            c["id"]: c for m in children if isinstance(m, AIMessage) for c in m.tool_calls
        }
        for child in children:
            if not isinstance(child, ToolMessage) or child.status != "success":
                continue
            child_call = child_calls.get(child.tool_call_id, {})
            if child_call.get("name") != TOPIC_TOOLS[topic]:
                continue
            args = child_call.get("args", {})
            if not isinstance(args, dict) or set(args) - TOOL_ARGUMENTS[topic]:
                continue
            source_ids = {
                source.id
                for source in sources
                if source.topic == topic and _source_argument_matches(source, args, _text(child))
            }
            expected = {s.id for s in sources if s.topic == topic}
            if not expected or source_ids != expected:
                continue
            canonical_scope = expected_arguments is None or _arguments_match(
                args, expected_arguments.get(topic, {})
            )
            if canonical_scope:
                status = "completed"
            result.reports.append((topic, source_ids, _text(child)))
            result.analyses.append(
                {"topic": topic, "arguments": dict(args), "canonical_scope": canonical_scope}
            )
        if result.statuses[topic] != "completed":
            result.statuses[topic] = status
    root = output_dir.resolve()
    if root.is_dir():
        for candidate in root.rglob("*"):
            path = candidate.resolve()
            if not path.is_relative_to(root) or not path.is_file():
                continue
            if path.suffix.lower() not in {".md", ".xlsx"}:
                continue
            for topic, _, content in result.reports:
                if str(path).replace("\\", "/") in content.replace("\\", "/"):
                    result.artifacts[str(path)] = topic
    result.supporting_artifacts = _chart_artifacts(result.artifacts, root)
    return result


def _chart_artifacts(primary_artifacts: Mapping[str, str], output_root: Path) -> dict[str, str]:
    """Allow only existing chart files explicitly linked by a bound primary report."""
    artifacts = {}
    for filename, topic in primary_artifacts.items():
        report = Path(filename)
        if report.suffix.lower() != ".md":
            continue
        chart_directory = report.parent / "charts"
        chart_root = chart_directory.resolve()
        if chart_root != chart_directory or not chart_root.is_relative_to(output_root):
            continue
        try:
            body = report.read_text(encoding="utf-8")
        except OSError:
            continue
        for target in re.findall(r"\[[^\]\n]*\]\(<?(charts/[^\s)>]+)>?\)", body):
            relative = Path(target)
            if ".." in relative.parts:
                continue
            candidate = (report.parent / relative).resolve()
            if (
                candidate.is_relative_to(chart_root)
                and candidate.is_relative_to(output_root)
                and candidate.suffix.lower() in {".md", ".json", ".png"}
                and candidate.is_file()
            ):
                artifacts[str(candidate)] = topic
    return artifacts


def _arguments_match(actual: Mapping[str, Any], expected: Mapping[str, Any]) -> bool:
    for key, value in expected.items():
        supplied = actual.get(key)
        if key.endswith("_path") and value is not None:
            if not isinstance(supplied, str) or Path(supplied).resolve() != Path(value).resolve():
                return False
        elif supplied != value:
            return False
    return True


def _source_argument_matches(source: Source, arguments: Mapping[str, Any], body: str) -> bool:
    supplied = arguments.get(SOURCE_ARGUMENTS[source.kind])
    if not isinstance(supplied, str):
        return False
    path = Path(source.path).resolve()
    if source.kind == "post_trade_cases":
        return Path(supplied).resolve() == path.parent and path.name in body
    return Path(supplied).resolve() == path


def _report_marker(value: str) -> str:
    """Undo report escaping only for source identification, never for quotations."""
    return re.sub(r"\\([\\`*_\[\]{}|])", r"\1", html.unescape(value)).replace("\\", "/")


def _locator_sources(locator: str, sources: list[Source]) -> set[str]:
    normalized = _report_marker(locator)

    def contains(marker: str) -> bool:
        return re.search(r"(?<![\w.-])" + re.escape(marker) + r"(?![\w.-])", normalized) is not None

    full_paths = {
        source.id for source in sources if contains(Path(source.path).resolve().as_posix())
    }
    if full_paths:
        return full_paths
    return {source.id for source in sources if contains(Path(source.path).name)}


def _bound_excerpt(ref: EvidenceReference, sources: list[Source], captured: RunEvidence) -> bool:
    # A shared heading/report is not a source locator. Ambiguous basenames need
    # full paths; the locator and quote must coexist on one actual evidence line.
    if _locator_sources(ref.locator, sources) != {ref.source_id}:
        return False
    locators = [ref.locator]
    source = next(source for source in sources if source.id == ref.source_id)
    if source.topic == "pnl":
        # PnL reporting replaces only the trusted source path immediately before
        # a bracketed location. Preserve the suffix and the original report data.
        compact = ref.locator.replace(source.path + " [", Path(source.path).name + " [")
        if compact != ref.locator and _locator_sources(compact, sources) == {ref.source_id}:
            locators.append(compact)
    return any(
        ref.source_id in ids
        and any(
            any(locator in line for locator in locators) and ref.excerpt in line
            for line in body.splitlines()
        )
        for _, ids, body in captured.reports
    )


def validate_audit_report(
    text: str,
    *,
    run_id: str,
    sources: list[Source],
    captured: RunEvidence,
    mappings: Sequence[MappingBasis] = (),
    criteria: Sequence[Criterion] = (),
    evidence_mode: EvidenceMode = "verbatim",
) -> AuditReport:
    """Validate strict JSON plus provenance; never repair via another model call."""

    def unique_object(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError(f"Duplicate JSON field: {key}.")
            obj[key] = value
        return obj

    raw = json.loads(text, object_pairs_hook=unique_object)
    if evidence_mode == "catalog":
        draft = _CatalogAuditDraft.model_validate(raw)
        catalog = build_evidence_catalog(captured, sources)
        resolved = []
        for selection in draft.evidence:
            if selection.catalog_id not in catalog:
                raise ValueError(f"Unknown evidence catalog ID for {selection.id}.")
            resolved.append(catalog[selection.catalog_id].model_copy(update={"id": selection.id}))
        report = AuditReport.model_validate({**draft.model_dump(), "evidence": resolved})
    elif evidence_mode == "verbatim":
        report = AuditReport.model_validate(raw)
    else:
        raise ValueError("Unsupported evidence mode.")
    if report.run_id != run_id or report.sources != sources:
        raise ValueError("Run ID or source inventory differs from the supplied manifest.")
    if report.mappings != list(mappings) or report.criteria != list(criteria):
        raise ValueError("Mappings or criteria differ from the operator-supplied definitions.")
    if not captured.main_skill_loaded:
        raise ValueError("The main agent did not load market-activity-review.")
    for coverage in report.topic_coverage:
        if coverage.status != captured.statuses[coverage.topic]:
            raise ValueError(f"Unsupported execution status for {coverage.topic}.")
    completed = sum(s == "completed" for s in captured.statuses.values())
    expected_status = "completed" if completed == 3 else "partial" if completed else "failed"
    if report.execution_status != expected_status:
        raise ValueError("Overall execution status does not match the captured run.")
    source_ids = {s.id for s in sources}
    source_by_id = {s.id: s for s in sources}
    evidence = {e.id: e for e in report.evidence}
    for ref in evidence.values():
        if ref.source_id not in source_ids or (
            evidence_mode == "verbatim" and not _bound_excerpt(ref, sources, captured)
        ):
            raise ValueError(f"Evidence {ref.id} is not present in a bound successful tool report.")

    def references(ids: list[str]) -> set[str]:
        if any(key not in evidence for key in ids):
            raise ValueError(f"Unknown evidence reference in {ids}.")
        return {evidence[key].source_id for key in ids}

    for check in report.checks:
        check_sources = references(check.evidence_ids)
        topic = CHECK_TOPICS[check.check_id]
        if topic and any(source_by_id[key].topic != topic for key in check_sources):
            raise ValueError(f"Wrong evidence topic for {check.check_id}.")
        if check.status in {"exception_identified", "no_exception_identified"}:
            if not check.evidence_ids or (topic and captured.statuses[topic] != "completed"):
                raise ValueError(f"Unsupported performed procedure {check.check_id}.")
    for observation in report.observations:
        observation_sources = references(observation.evidence_ids)
        if any(key not in CHECK_TOPICS for key in observation.check_ids):
            raise ValueError(f"Observation {observation.id} has invalid topic/check references.")
        evidence_topics = {source_by_id[key].topic for key in observation_sources}
        check_topics = {
            CHECK_TOPICS[key] for key in observation.check_ids if CHECK_TOPICS[key] is not None
        }
        if observation.topic not in evidence_topics or (
            check_topics
            and (observation.topic not in check_topics or check_topics != evidence_topics)
        ):
            raise ValueError(f"Wrong evidence topic for observation {observation.id}.")
    bases = {m.id: m for m in mappings}
    if len(bases) != len(mappings):
        raise ValueError("Duplicate mapping IDs.")
    for relation in report.cross_source_matrix:
        linked_sources = references(relation.evidence_ids)
        if relation.mapping_id is not None and relation.mapping_id not in bases:
            raise ValueError("A cross-source mapping was not supplied by the operator.")
        if relation.relationship in {"confirmed", "contradictory"}:
            basis = bases.get(relation.mapping_id)
            if (
                basis is None
                or len(linked_sources) < 2
                or not linked_sources.issubset(set(basis.source_ids))
                or not set(basis.source_ids).issubset(source_ids)
                or relation.compatibility_limits
            ):
                raise ValueError(
                    "Confirmed/contradictory links require a compatible supplied mapping."
                )
            kinds = {source_by_id[key].kind for key in linked_sources}
            numeric = {"pnl", "attribution", "adjustments", "risk_consumption", "excess_events"}
            commentary = {
                "ia_commentary",
                "pnl_commentary",
                "risk_commentary",
                "stress_commentary",
                "var_commentary",
            }
            required_groups = {
                "pnl_attribution": ({"pnl"}, {"attribution"}),
                "pnl_adjustments_validation": ({"pnl"}, {"adjustments", "validation"}),
                "pnl_risk": ({"pnl", "attribution", "adjustments"}, {"risk_consumption"}),
                "risk_excess_workflow": ({"risk_consumption"}, {"excess_events"}),
                "numbers_commentary": (numeric, commentary),
                "post_trade_activity": ({"post_trade_cases"}, numeric),
            }
            if any(not kinds.intersection(group) for group in required_groups[relation.comparison]):
                raise ValueError("Cross-source evidence does not cover the compared source kinds.")
    finding = report.final_finding
    finding_sources = references(finding.evidence_ids)
    if not set(finding.criterion_ids).issubset({c.id for c in criteria}):
        raise ValueError("The finding cites criteria not supplied by the operator.")
    if not set(finding.cross_source_comparisons).issubset(COMPARISONS):
        raise ValueError("The finding cites an unknown cross-source comparison.")
    if finding.disposition == "supported_finding":
        linked = [
            r
            for r in report.cross_source_matrix
            if r.comparison in finding.cross_source_comparisons
            and r.relationship in {"confirmed", "contradictory"}
        ]
        if not finding.criterion_ids or len(finding_sources) < 2 or not linked:
            raise ValueError(
                "A supported finding needs criteria and corroborated cross-source evidence."
            )
        if any(not set(r.evidence_ids).issubset(finding.evidence_ids) for r in linked):
            raise ValueError("The finding must retain the evidence for its corroborated links.")
    if finding.disposition == "no_finding_identified":
        if completed != 3 or any(
            c.status not in {"no_exception_identified", "not_applicable"} for c in report.checks
        ):
            raise ValueError(
                "Unresolved checks require further_evidence_required, not a clean finding."
            )
    actual_artifacts = {(str(Path(a.path).resolve()), a.topic) for a in report.artifacts}
    primary = set(captured.artifacts.items())
    allowed = primary | set(captured.supporting_artifacts.items())
    if (
        len(actual_artifacts) != len(report.artifacts)
        or not primary.issubset(actual_artifacts)
        or not actual_artifacts.issubset(allowed)
    ):
        raise ValueError("Artifact inventory differs from the captured tool-generated files.")
    return report


def render_audit_report(report: AuditReport) -> str:
    """Render every validated field, with one final finding and no second LLM call."""
    data = report.model_dump(mode="json")
    lines = ["# Market activity review", "", "## Final finding", ""]

    def safe(value: Any) -> str:
        if isinstance(value, list):
            return "; ".join(safe(item) for item in value) or "None recorded"
        escaped = html.escape(str(value) if value is not None else "Unknown")
        for char in "\\`*_{}[]()#+!|":
            escaped = escaped.replace(char, "\\" + char)
        return escaped.replace("\n", "<br>")

    def fields(record: dict) -> None:
        for key, value in record.items():
            lines.extend([f"**{key.replace('_', ' ').title()}:** {safe(value)}", ""])

    def records(items: list[dict]) -> None:
        headers = list(items[0])
        if len(headers) <= 5:
            lines.append("| " + " | ".join(h.replace("_", " ").title() for h in headers) + " |")
            lines.append("| " + " | ".join("---" for _ in headers) + " |")
            for item in items:
                lines.append("| " + " | ".join(safe(item[key]) for key in headers) + " |")
            lines.append("")
        else:
            for index, item in enumerate(items, 1):
                lines.extend([f"#### Record {index}", ""])
                fields(item)

    fields(data.pop("final_finding"))
    lines.extend(["## Supporting workpapers", ""])
    for key, value in data.items():
        lines.extend([f"### {key.replace('_', ' ').title()}", ""])
        if isinstance(value, list) and value and isinstance(value[0], dict):
            records(value)
        else:
            lines.extend([safe(value), ""])
    return "\n".join(lines)


def report_instructions(evidence_mode: EvidenceMode = "verbatim") -> str:
    """Generate the model-facing schema from the same contract used for validation."""
    if evidence_mode == "catalog":
        schema = _CatalogAuditDraft.model_json_schema()
        evidence_instructions = (
            "Use lookup_review_evidence to inspect the current run's trusted evidence catalog. "
            "Each evidence entry must contain only your evidence id and an exact catalog_id "
            "returned by that tool. The server supplies the immutable source, locator and "
            "verbatim excerpt; never type, paraphrase or reassign those fields yourself. "
            "Catalog locators identify tool-report lines, not raw-file inspection. "
            "Reuse evidence IDs rather than duplicating citations. If no suitable catalog "
            "entry exists, omit that evidence/observation and mark the relevant check "
            "insufficient_evidence or not_performed. "
        )
    elif evidence_mode == "verbatim":
        schema = AuditReport.model_json_schema()
        evidence_instructions = (
            "Evidence locator must include an unambiguous source filename/path. Locator and "
            "excerpt must match the same line of a successful topic tool report. The only "
            "locator equivalence accepted is the trusted PnL source path compacted to its "
            "unambiguous basename before an unchanged bracketed row/record suffix. The "
            "excerpt remains verbatim. Generic headings cannot certify a source. Copy the "
            "complete original Markdown evidence row as the excerpt when possible, including "
            "its locator and Markdown escaping; copy those citation fields from the "
            "specialist unchanged. Prefer the report's displayed locator; never cite a "
            "manifest path alone or paraphrase/shorten a quote. Reuse evidence IDs rather "
            "than duplicating citations. If no source-bound row can be quoted, omit that "
            "evidence/observation and mark the relevant check insufficient_evidence or "
            "not_performed. "
        )
    else:
        raise ValueError("Unsupported evidence mode.")
    return (
        "Return only one JSON object matching this schema, without fences or extra text. "
        "Preserve the supplied run_id and sources in their original order. All 36 checks "
        "and all six cross-source comparisons are required. "
        + evidence_instructions
        + "Do not claim raw-file inspection. Artifacts must include every actual successful "
        "tool's primary workbook and Markdown report exactly once. Existing chart "
        "indexes/manifests/PNG previews explicitly linked by those primary reports are "
        "optional; do not invent or include unobserved files from failed children. "
        "Use the exact comparison enum IDs in final_finding.cross_source_comparisons. "
        "Use further_evidence_required when a common issue cannot be "
        "established. A supported finding requires operator-supplied criterion IDs and "
        "a confirmed or contradictory link with an operator-supplied mapping ID. "
        "Never invent mappings, criteria, successful execution or evidence. "
        "No-finding disposition requires all checks to have no exception or a justified "
        "not-applicable result.\n" + json.dumps(schema, ensure_ascii=False)
    )
