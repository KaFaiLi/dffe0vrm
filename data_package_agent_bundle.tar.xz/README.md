# Data Package Agent

**Internal use only. Under active development.** This README is for colleagues
developing and integrating the agent within `private_suite`.

The package exposes deterministic data analysis through FastMCP and uses
LangChain/LangGraph agents with application skills to review the results.
Current analysis covers post-trade controls, P&L and risk metrics; the market
activity notebook brings those reviews together.

The distribution is still named `mcp-agent-template`; Python imports use
`mcp_agent_template`. This is an independent Python 3.12+ uv project within the
suite repository. Keep its environment and tests separate from the suite root.
Read the package [contributor guidance](AGENTS.md) before making changes.
Start with the [architecture and onboarding guide](docs/architecture/README.md)
for the system design, agent loop, middleware, every tool and application skill.
The [documentation index](docs/README.md) separates maintained guides from
historical plans, research and validation records.

## Set up your environment

Use `uv` and run package commands from `packages/data-package-agent/`.

### Corporate setup: integration pending

With access to the configured corporate package index and internal provider
repositories, the intended workflow is:

```powershell
cd packages/data-package-agent
uv sync --extra dev --extra socgenai-llm
```

**This is not yet a confirmed clean install.** The agent requires
`langchain-core>=1.6.10`, while the sibling wrapper pins `langchain-core==1.6.6`.
Corporate dependency resolution remains unverified, and this package has no
`uv.lock` yet. Preserve the corporate index and production pins while integration
is resolved. Once resolution succeeds, maintain the package lockfile and use
locked commands.

### Isolated local development

To develop against all three sibling source trees, use the checked-in
[local environment template](../../devtools/foundry_lab/agent_environment.toml).
From this package directory in PowerShell:

```powershell
New-Item -ItemType Directory -Path ../../artifacts/foundry-agent -Force | Out-Null
Copy-Item -LiteralPath ../../devtools/foundry_lab/agent_environment.toml `
    -Destination ../../artifacts/foundry-agent/pyproject.toml
uv sync --project ../../artifacts/foundry-agent --python 3.12
$agentUv = @('run', '--project', '../../artifacts/foundry-agent', '--locked', '--python', '3.12')
```

This installs the agent, wrapper and API manager editable in a separate ignored
environment, using public dependencies, `openai==3.24.0` and a local
`langchain-core==1.6.10` override. It does not resolve corporate integration or
change production metadata. Synthetic tests need no provider credentials.

For this setup, replace `uv run` in the runtime examples below with
`uv @agentUv`, keeping the same package working directory. Plain `uv run`
selects the package's corporate environment again.

## Configure the application

Settings come from the environment and `<APP_ROOT>/.env`. Source checkouts
default `APP_ROOT` to this package directory; installed wheels default it to the
process working directory. Set an explicit writable `APP_ROOT` when embedding
the package elsewhere.

A minimal application `.env` is shown below. Replace the placeholder with an
approved, priced Azure deployment that supports Responses:

```dotenv
GENAI_PROVIDER=socgenai_llm
GENAI_MODEL=<approved-priced-responses-deployment>
GENAI_USE_RESPONSES_API=true
MCP_TRANSPORT=stdio
SKILLS_DIR=skills
ANALYSIS_RESULTS_DIR=.mcp_agent_template/analysis
OBS_MODE=local
```

Agent execution uses `socgenai_llm.GenAIChatModel` through the central
`get_chat_model` factory, the Responses API and `reasoning.summary="detailed"`.
Sampling parameters and output-token limits are omitted by default. Extra
provider request options belong in `model_kwargs` when calling the factory.

Configure Azure authentication, trusted configuration, pricing, proxy behavior
and encrypted audit logging through the internal
[wrapper guide](../socgenai-llm/docs/socgenai-llm.md) and
[manager configuration guide](../genai-api-manager/docs/reference/api-manager-configuration.md).
An agent `.env` alone does not provision provider access. Keep credentials and
local configuration out of tracked files.

## Start and integrate

### MCP server

```powershell
uv run mcp-agent-server
```

The server waits for an MCP client over stdio; it is not a chat prompt. A client
can launch this installed entry point or run
`python -m mcp_agent_template.mcp_server` using the selected environment's Python.
Starting the server and calling its analysis tools does not require an LLM call.

For a separately running HTTP server:

```powershell
$env:MCP_TRANSPORT = 'http'
uv run mcp-agent-server
```

The default endpoint is `http://127.0.0.1:8000/mcp`; configure it with `MCP_HOST`
and `MCP_PORT`. Set `MCP_TRANSPORT=http` in the agent process too. In stdio mode,
the agent builder launches its own server subprocess, so no separate server is
needed. Notebook helpers use HTTP and manage their server lifecycle.

The application server currently exposes four tools:

| Tool | Input and result |
| --- | --- |
| `list_files(folder_path=".", recursive=False)` | Lists sorted `APP_ROOT`-relative paths without reading contents. |
| `run_post_trade_review(folder_path)` | Selects exactly one matching Parquet dataset; returns Markdown and saves Excel/Markdown evidence. |
| `run_pnl_analysis(...)` | Reviews six required files: EUR desk P&L, independent attribution, adjustments, validation history and two original commentaries. Returns Markdown and saves complete workbook evidence plus daily PC P&L charts; load the `pnl` skill for scope, thresholds and evidence limits. |
| `run_risk_metrics_analysis(sgmr_path, ...)` | Reviews SGMR movement/value outliers and exact-observation joint days, with optional Colibris workflows and three commentary sources; returns Markdown and saves nine-sheet Excel evidence plus standalone risk-value charts. |

Analysis is deterministic and leaves source files unchanged. Results go to
`ANALYSIS_RESULTS_DIR/{fox,pnl,risk_metrics}/<run-id>/`, relative to `APP_ROOT`
unless the destination is absolute. Analysis source paths may be absolute or
relative to the server's working directory. Only `list_files` confines discovery
to `APP_ROOT` and skips symlinks/junctions; these checks are not an OS sandbox.

### In-memory numerical analysis

Python callers can calculate without loading files, settings or an LLM:

- `mcp_agent_template.analysis.pnl.runners.analyze_pnl(...)` accepts four lists
  of canonical P&L, attribution, adjustment and validation records. See the
  [P&L analysis guide](docs/pnl-analysis.md#calculation-structure).
- `mcp_agent_template.analysis.risk_metrics.analyze_tables(sgmr, colibris=None)`
  accepts raw Polars tables. See the
  [risk analysis guide](docs/risk-metrics-analysis.md).

Both return the existing mutable `Review` result for reporting and charts.
Their file-based entry points and MCP tools retain the same interfaces and
calculation rules.

### Python and CLI agent

Once provider access is configured and live execution is authorized, try a
one-shot request or start the interactive CLI:

```powershell
uv run mcp-agent-chat "List your available tools and skills."
uv run mcp-agent-chat
```

Both commands invoke the LLM and can incur cost. To embed an agent in Python:

```python
import asyncio

from mcp_agent_template.agent import build_agent
from mcp_agent_template.config import Settings
from mcp_agent_template.llm.genai_manager import get_chat_model


async def main() -> None:
    """Run one configured request and close the owned provider client."""
    settings = Settings(genai_provider="socgenai_llm", genai_use_responses_api=True)
    with get_chat_model(settings=settings) as model:
        bundle = await build_agent(settings, model=model)
        answer = await bundle.ask("List your available tools and skills.")
        print(answer)


asyncio.run(main())
```

`AgentBundle.ask()` returns final text, `ainvoke()` returns native state and
`astream()` yields graph events. Bundle methods own a fresh run context and
recording scope per invocation. Explicitly close streams when stopping early;
raw graph calls require a fresh explicit `RunContext`.

Use `extra_tools` for application tools and `middleware` for invocation policies.
For synthetic tests, inject a scripted `model` and `mcp_tools` to avoid provider
construction and MCP discovery. `AgentSpec` and `build_agent_tree` compose
specialists sharing root model/tool budgets and deadlines. See
[agent prompts and tool scheduling](docs/agent-prompts.md) and
[history compaction](docs/context-compaction.md) for runtime policies.

Skills load from `APP_ROOT/skills` by default, with no packaged fallback. This
checkout provides `pnl`, `post-trade-control`, `risk-metrics` and
`market-activity-review`. When integrating a wheel, deploy the required skill
folders and references separately, then set `APP_ROOT` or `SKILLS_DIR`.
Missing folders yield no skills.

### Review notebook

Open [market_activity_review.ipynb](notebooks/market_activity_review.ipynb) in a
Python 3.12+ kernel with the agent and notebook dependencies installed. Begin
with `RUN_REVIEW=False`: inspect setup, source paths and the manifest before
enabling billable execution. The notebook coordinates a main reviewer and three
specialists, then validates one consolidated report as JSON and Markdown.

The notebook and `notebooks/review_reporting.py` are checkout-only examples,
excluded from the wheel. Follow the
[market activity review guide](docs/market-activity-review.md) for execution,
source mappings, evidence requirements and output contracts.

## Test and validate

From the package's corporate development environment:

```powershell
uv run pytest tests dashboard/tests -q
uv run ruff check .
uv run ruff format --check .
git diff --check
```

Plain `uv run pytest` collects `tests/` only; include `dashboard/tests`
explicitly. For a focused integration check, run
`uv run pytest tests/test_mcp_server.py -q`: it launches the real stdio server
and exercises discovery/calls without LLM credentials.

In the isolated local environment, use:

```powershell
uv @agentUv python -m pytest -c pyproject.toml tests dashboard/tests -q `
    --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv python -m pytest `
    -c ../../devtools/tests/foundry/data_package_agent/pytest.ini `
    ../../devtools/tests/foundry/data_package_agent -q
uv @agentUv ruff check .
uv @agentUv ruff format --check .
git diff --check
```

The local template includes `pytest-socket`. The host allowlist blocks external
connections in the pytest process while permitting Windows asyncio and dashboard
loopback traffic; it does not sandbox subprocess networking. Do not substitute
`--disable-socket`, which prevents Windows asyncio startup. This package has its
own pytest configuration and does not implement the root `--offline` profile.

Keep corporate-usable synthetic regressions in `tests/`, viewer tests in
`dashboard/tests/`, and Foundry runner/probe regressions in the separate
suite-owned group above. Keep the agent outside root collection and the portable
manager/wrapper test bundle. See [test guidance](tests/README.md).

For packaging changes, run `uv build` from this package's configured environment
and verify installed public imports outside the source tree. Outputs belong to
this package's `dist/`.

Live Foundry checks require separate authorization and the suite's opt-in
`devtools/foundry_lab/run.py --operation data-package-agent --run-live` runner.
Follow the complete [live-test setup](AGENTS.md#authorized-local-live-test) for
credentials, pricing, max/detailed reasoning and bounded requests. Synthetic
tests, local live evidence and corporate acceptance remain separate; local
success does not establish corporate identity, proxy, shared-drive, route or
dependency compatibility.

## Develop and inspect a change

| Area | Where to work |
| --- | --- |
| Analysis and calculations | `src/mcp_agent_template/analysis/` |
| MCP interfaces and registration | `src/mcp_agent_template/mcp_server/tools/` and `mcp_server/server.py` |
| Agent composition and execution policies | `src/mcp_agent_template/agent/` and `agent/runtime/` |
| Provider construction and request options | `src/mcp_agent_template/llm/genai_manager.py` |
| Application instructions and dataset contracts | `skills/<name>/SKILL.md` and its references |
| Recording and inspection | `src/mcp_agent_template/observability/` and `dashboard/` |

When adding a tool, define typed inputs and a model-facing docstring, register
it, add synthetic calculation and MCP contract coverage, and update its skill
and guide. Keep calculations independent of the LLM. Cover missing inputs,
units, saved evidence and failure paths as applicable.

Local SQLite recording defaults to enabled and captures complete model/tool
payloads with credential redaction. It can retain sensitive business content
in plaintext, separately from the manager's encrypted audit logs.
`OBS_MODE=off` disables it. Keep recordings and generated analysis artifacts out
of commits.

Inspect recordings with the standalone read-only dashboard:

```powershell
python dashboard/server.py
```

Open [the local viewer](http://127.0.0.1:8765). It needs only Python 3.12+ and
reads `.mcp_agent_template/observability/observability.sqlite3` by default.
Pass `--db <path>` for another `APP_ROOT` or `OBS_DIR`. See
[observability](docs/observability.md) for recorder ownership and
[the dashboard guide](dashboard/README.md) for conversation, usage and trace views.

## Further reading

| Task | Guide |
| --- | --- |
| Understand post-trade tools and skill loading | [Skills and analysis tools](docs/skills.md), [post-trade structure](docs/post-trade-analysis.md) |
| Integrate P&L sources and evidence | [P&L analysis](docs/pnl-analysis.md) |
| Integrate risk sources and interpret checks | [Risk analysis](docs/risk-metrics-analysis.md), [dataset contract](skills/risk-metrics/references/dataset.md), [methodology](skills/risk-metrics/references/methodology.md) |
| Work with saved charts | [Analysis visualizations](docs/analysis-visualizations.md) |
| Find maintained guides and historical records | [Documentation index](docs/README.md) |

Reports under `docs/review/` record evidence for their stated date and environment;
they do not certify the current checkout or corporate acceptance.
