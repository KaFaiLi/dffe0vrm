# SQLite logging and native middleware

This internal guide describes recording ownership, middleware and inspection.
Use the [development README](../README.md) for Python 3.12+ environment setup,
provider integration and package test commands.

## What is recorded

Local recording is enabled by default. The database is:

~~~text
<APP_ROOT>/.mcp_agent_template/observability/observability.sqlite3
~~~

Source checkouts default APP_ROOT to this package directory; installed wheels
default it to the process working directory. Set it explicitly for a separate
application workspace. Relative skill and observation paths use the same root;
subprocesses receive these settings.

The recorder uses a single SQLite writer, credential redaction, OpenTelemetry
integration, native callbacks, capture middleware and inspection commands.
It records:

- Run definitions, input/output, outcomes, root/child relationships and timings.
- Effective model requests, native responses and exposed invocation metadata.
- Model usage and streaming fragments, with missing usage kept unknown.
- Tool arguments/results, handled errors, waits and policy decisions.
- FastMCP server tool requests/results and lifecycle logs.
- Credential-redacted logs, exceptions, spans, metric points and recorder health.

Run definitions use one recording envelope and include the node's selected skill
inventory (names, descriptions, instruction paths and reference filenames).
Skill bodies still enter model history only when loaded. Definitions retain the
redaction paths from their saved build receipt. The dashboard also projects older
double-wrapped definitions for display without rewriting their raw exported records;
an absent historical skill inventory is not reconstructed from current files.

Opt-in [history compaction](context-compaction.md) records summary model calls
with `purpose="summary"`, effective projected requests, and compaction outcomes.
Complete native history and returned traces remain available; system/developer
instructions are never compacted. Summary calls count in model usage totals.

Complete records are retained without application payload caps, sampling or
automatic deletion. The redactor removes credentials; it does not classify
arbitrary confidential business content. Native callbacks describe their coverage
and do not claim to capture the corporate provider's HTTP request body.
Agent tool results and server requests are recorded at their respective boundaries;
external MCP process records do not automatically inherit the agent's run ID.

## Storage version and complete reads

The writer, CLI and dashboard support SQLite `user_version=2` only. Empty
databases are initialized directly in that schema in one transaction. Existing
version-2 stores remain readable and writable without rewriting their contents.
Version-1 stores and populated unversioned databases are rejected; there is no
automatic migration. Retain a previous application version separately if you
need to export a version-1 recording, and use a fresh destination for new runs.

`events`, `runs`, `captures`, `logs` and `feedback` retain their complete column
and read contracts as SQL views. Capture/log/feedback rows and run start/finish
records reference canonical events rather than duplicating payloads. New stores
do not create migration-history or legacy mirror tables. Existing version-2
stores are not destructively stripped of extra tables or rewritten.

For new events, byte-identical redacted JSON string literals of at least 1 KiB
share one content part. Per-event references retain all stages, contexts, message
versions, native artifacts and redaction paths. Plain SQLite reconstructs the
original envelope byte for byte, including Unicode and escaping. No Python
reader function, sampling or truncation is required. Full selected records and
JSON exports keep the existing envelope/archive version 1; this is distinct
from the SQLite storage version. Direct writes belong to the recorder's private
tables, not these read views.

The producer cache of accepted part identities is bounded to 4,096 entries;
eviction repeats an idempotent insert and does not delete durable content.
Repeated immutable text redaction uses a per-redactor cache bounded to 1 MiB.
Mutable messages/state are never cached. Other observation metadata and short
content remain serialized independently, and full-content reads reconstruct
parts on demand. See the
[implementation report](review/template-design-simplification-validation-2026-10-14.md)
for the synthetic measurements and their limits.

The CLI and server own their recorder for their complete lifetime. Library
builders leave host logging alone. bundle.ask, bundle.ainvoke and bundle.astream
automatically own and close a recorder when an explicit opened recorder is absent.
Notebook stream_trace accepts either a bundle or a raw graph and owns streaming
recording. Raw graph invocation requires a fresh runtime context and does not
implicitly start recording.

## Configuration

Use the normal environment or application-root .env:

~~~dotenv
OBS_MODE=local
OBS_DIR=.mcp_agent_template/observability
OBS_SERVICE_NAME=data-package-agent
OBS_FLUSH_INTERVAL_MS=250
OBS_METRIC_INTERVAL_SECONDS=5
LOG_LEVEL=INFO
~~~

OBS_MODE=off disables recording and creates no SQLite file. LOG_LEVEL controls
managed CLI/server logging; an embedding host's existing logger levels and
handlers remain its responsibility. Model/tool captures are separate from log
level filtering. No remote exporter or telemetry service is configured.

### Naming and existing recordings

The recording directory is `.mcp_agent_template`; custom OpenTelemetry attributes
and metrics use the `mcp_agent_template.*` namespace. The mapping identifier is
`mcp_agent_template-v1`, and the dashboard database override is
`MCP_AGENT_TEMPLATE_OBS_DB`.

When upgrading from an earlier donor-named release, move the existing recording
directory to `.mcp_agent_template`, or retain its location with `OBS_DIR` and the
dashboard's `--db` option. Update dashboard environment overrides and custom
telemetry queries to the names above. New recordings use the new namespace;
existing database contents are not rewritten. Historical run, event and usage
records remain readable, while older spans may lack the newly named run-ID
attribute in the dashboard.

Libraries allocate no recorder merely by importing modules or building a graph.
A shared recorder can capture graph composition as well as multiple invocations:

~~~python
from mcp_agent_template.agent import build_agent
from mcp_agent_template.config import Settings
from mcp_agent_template.observability import ObservabilityRuntime

settings = Settings()
async with ObservabilityRuntime.local(settings) as recording:
    bundle = await build_agent(settings, observability=recording)
    answer = await bundle.ask("List your tools")
    await recording.aflush()
    print(recording.path)
~~~

Close all active invocations before closing an explicitly shared recorder.
Concurrent flush and close serialize writer-queue admission: an admitted flush
barrier precedes the stop command, and waits happen outside the lifecycle lock.
Flush calls after closure retain the existing health-only return behavior.
An embedding host that owns an OpenTelemetry tracer provider should supply that
provider explicitly to ObservabilityRuntime.local; the recorder does not replace it.

Writer/serialization failures mark telemetry degraded without changing an otherwise
valid agent answer. Partial recorder startup, cancellation and repeated cancellation
join owned work and remove handlers. A recorder that cannot start reports startup
failure. Stream consumers should explicitly close a stream when stopping early:

~~~python
from contextlib import aclosing

async with aclosing(bundle.astream("List your tools", stream_mode="updates")) as stream:
    async for event in stream:
        print(event)
        if should_stop(event):
            break
~~~

## Native middleware

Both build_agent and build_agent_tree use one graph composition function. Its
required order is:

1. ObservationMiddleware: outer model-round/tool capture.
2. ToolRoundPolicyMiddleware: exact round limit without suppressing parallel calls.
3. AgentTodoMiddleware: native per-invocation `write_todos` state and tool.
4. Caller-supplied middleware.
5. ContextCompactionMiddleware, when an input budget is configured: outgoing
   history projection and summary calls.
6. RuntimePolicyMiddleware: invocation ownership, parallel model settings, shared
   tool budgets and invocation-owned tool capacity.
7. EffectiveRequestMiddleware: attempt identity, model reservation and final request at dispatch.

The default stack contains five middleware entries. RuntimePolicyMiddleware
combines the former adjacent RunLifecycleMiddleware and ToolExecutionMiddleware
registrations without changing their hook order relative to application
middleware, context compaction or effective request capture. Build definitions
and fingerprints reflect the combined registration; historical definitions
remain readable. The graph recursion safety ceiling is still calculated from
the installed stack; ToolRoundPolicyMiddleware retains the exact round limit.

Custom graphs use one `RuntimePolicyMiddleware(child_names=...)`. The former
`RunLifecycleMiddleware` and `ToolExecutionMiddleware` classes and the ignored
`sequential` keyword have been removed. Public builders reserve only the current
built-in middleware names.

Effective dispatch allocates a fresh request identity for every application
handler attempt, then reserves the shared model budget before capturing or
calling the model. Sequential retries and concurrent handler attempts retain
distinct request IDs within the same round. Budget rejection produces no
effective-request snapshot or native model call. The separate
`RequestObservationMiddleware` has been removed; round/tool observation and
server observation remain at their existing boundaries. Model reservations
also remain enforced with recording disabled.
Custom graphs must include `EffectiveRequestMiddleware` for model reservations,
alongside RuntimePolicyMiddleware. Public
builders install RuntimePolicyMiddleware and EffectiveRequestMiddleware.

MCPObservationMiddleware records the server tool boundary separately. HTTP
shutdown flushes recording at the public ASGI lifespan boundary.

See the [complete middleware usage and cleanup review](review/middleware-usage-and-cleanup-2026-10-14.md)
for the dated registration and removal inventory. The old first-call planning
hooks are removed; native todo tracking is provided by AgentTodoMiddleware.
Skill catalogs, skill tools and child-agent tools remain available without
mandatory first-call skill loading or delegation.

Each root gets new counters/gates/deadline. Children share the root budget/deadline;
explicit parent child-capacity gates belong to the invocation. Delegation does
not hold an external-tool slot while a child needs that slot. Native tool
execution remains in LangChain/LangGraph.
Root invocations remain independent even when sharing a compiled bundle.

~~~dotenv
AGENT_MAX_ITERATIONS=10
AGENT_MAX_TOOL_CALLS=100
AGENT_MAX_MODEL_CALLS=64
AGENT_MAX_CONCURRENT_TOOLS=8
AGENT_RUN_TIMEOUT=300
~~~

AGENT_MAX_ITERATIONS bounds tool rounds per agent/current user turn.
AGENT_MAX_TOOL_CALLS and AGENT_MAX_MODEL_CALLS bound the entire root/child tree.
Capacity limits external tool operations; child-call timeouts still use the
existing AGENT_CALL_TIMEOUT or AgentSpec.call_timeout. Native recursion_limit
remains a separate safety bound. Budgets are reserved before side effects.

Parallel tool calling is always enabled. `RuntimePolicyMiddleware` supplies
`parallel_tool_calls=True` at model dispatch, after application model settings
have been applied and before the effective request is captured. Remove
`ALLOW_PARALLEL_TOOL_CALLS` / `Settings.allow_parallel_tool_calls` from configuration;
that setting no longer exists. There is no global ordering gate. `AgentSpec.concurrency`
defaults to `"parallel"`; explicit child limits still apply only to child tools.
See [agent prompts and parallel tool calls](agent-prompts.md) for migration details.

Pass native application middleware through the public builders:

~~~python
from langchain.agents.middleware import AgentMiddleware


class ApplicationMiddleware(AgentMiddleware):
    async def awrap_model_call(self, request, handler):
        # Apply application policy through request.override(...), if needed.
        return await handler(request)


bundle = await build_agent(middleware=(ApplicationMiddleware(),))
# For a tree: await build_agent_tree(spec, middleware=(ApplicationMiddleware(),))
~~~

Tree builder application middleware applies to the root. Required middleware
names are reserved; duplicate tool names, including middleware-provided tools,
are rejected before that node's graph is constructed. An explicitly supplied
mcp_tools=[] bypasses MCP discovery for scripted/local-only agents.

Fresh default calls start fresh histories. Native graph callers can supply
context=bundle.new_context(); use bundle methods or an explicit InvocationScope
to record those calls. This migration does not add checkpoint memory, durable
effects, dynamic tool discovery, or workspace/process tools.

Graph invocation and stream delivery now live in `agent.runtime.invocation`.
`RunContext` owns execution limits and gates; recording ancestry is chosen at
the bundle invocation seam when a child shares its parent's budget. The
`InvocationScope` import is `agent.runtime.invocation.InvocationScope`;
the former recording-runtime re-export has been removed.
Recorder startup, cancellation shielding, flush and close ownership
retain their existing behavior.

Both builders share node preparation. Tree skill catalogs are parsed once per
resolved directory per build, then independently selected for each node. Graphs,
models and child invocation contexts are not cached globally. Single agents and
equivalent tree leaves use the same system prompt and tool definitions.

Unused internal helpers `schema_descriptor`, `capture.build.fingerprint`,
`summary_request` and `SERVER_KEY` have been removed after suite-wide import and
public-export checks found no callers. Applications importing these undocumented
helpers directly must stop using those imports; the retained model/tool/output
descriptors and `AgentBundle.build_fingerprint` own the active contracts.
`InvocationScope.build_event_id` and the always-null `source_build_event_id`
definition field have also been removed. Build attribution remains available
through `run.started.build_fingerprint`; historical fields remain readable.
No SQLite schema migration or changes to the public bundle exports are required.

The earlier removal of planning middleware and obsolete policy adapters remains
in effect: no first-call skill or delegation directive is injected. Applications
use the bundle builders and active runtime policies. Caller-supplied concurrency
wrappers remain supported.

## Inspect and export

Run from the configured corporate environment:

~~~powershell
uv run python -m mcp_agent_template.observability list
uv run python -m mcp_agent_template.observability doctor
uv run python -m mcp_agent_template.observability stats
uv run python -m mcp_agent_template.observability show <run-id>
uv run python -m mcp_agent_template.observability export <run-id> --output run.json
~~~

Use --db before the command to inspect a different database. Read-only queries
and JSON/JSONL exports reuse mcp_agent_template's format. Usage counts each native model
call once; root totals include children. A child without reported usage remains
an unknown-usage call, rather than zero usage.

## Read-only dashboard

The standalone [dashboard](../dashboard/README.md) displays the recorded
conversations, usage, model requests, tool calls, logs, spans, and recorder health.
It reads the same SQLite schema and requires only Python's standard library.
Start it from this package directory:

~~~powershell
python dashboard/server.py
~~~

Open <http://127.0.0.1:8765>. The default source is this package's
`.mcp_agent_template/observability/observability.sqlite3`; use `--db` for a database under a
custom application root or observation directory, and `--port` for another port.
The viewer binds to localhost and opens the database read-only, including live
WAL recordings and closed recordings whose WAL sidecars have been removed.
Complete selected records and exports preserve the recorded redacted payloads.

The dashboard is a separate development application outside the agent wheel.
See [dashboard validation](review/dashboard-validation-2026-10-13.md) for
integration evidence.

## Historical design and validation

The [13 October implementation record](review/logging-middleware-validation-2026-10-13.md)
describes the original donor integration and dependency boundary. The
[OpenTelemetry research](research/langchain-langgraph-opentelemetry.md),
[gap analysis](research/mcp-agent-template-otel-gap-analysis.md) and
[simplification report](review/template-design-simplification-validation-2026-10-14.md)
are dated design/evidence records. Their proposed work and measured counts are
not a current backlog or a fresh validation of this checkout.
