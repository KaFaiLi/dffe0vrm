# Automatic conversation-history compaction

Compaction reduces the messages sent to the model when an explicitly configured
prompt allowance is approached. It applies to single agents and every node of
an agent tree. It is disabled by default; no deployment context size is guessed.

## Enable compaction

```python
from mcp_agent_template.agent import ContextCompactionSettings, build_agent
from mcp_agent_template.config import Settings

settings = Settings(context_compaction=ContextCompactionSettings(input_token_budget=32_000))
bundle = await build_agent(settings)
```

The example allowance is an application choice, not a claim about any model's
capacity. Operators must select an allowance within the deployed model's limit,
after reserving output headroom. Include instructions and tool schemas in it.

Environment configuration supports both JSON and nested fields:

```dotenv
CONTEXT_COMPACTION_INPUT_TOKEN_BUDGET=32000
CONTEXT_COMPACTION_TRIGGER_FRACTION=0.8
CONTEXT_COMPACTION_TARGET_FRACTION=0.6
CONTEXT_COMPACTION_KEEP_RECENT_GROUPS=2
```

Summary requests have no project-imposed output-token limit by default. Leave
`CONTEXT_COMPACTION_SUMMARY_MAX_TOKENS` unset; remove an existing value to adopt
this default. Explicit positive values remain supported for caller compatibility.
The provider still applies its own limits.

`AgentSpec(context_compaction=...)` overrides the package policy for that node.
`None` inherits the package settings; `ContextCompactionSettings()` explicitly
disables compaction for that node. Child overrides do not become parent policies
and are not inherited by their siblings. Existing builders and calls keep their
behavior when no input allowance is configured. There are no model-visible
inspection or compaction tools.

## Instructions stay intact

The original system prompt, its skill catalog, and all application-injected
system/developer messages stay verbatim. They are never supplied to the
summarizer as source material. Tool definitions and structured-output schemas
also remain unchanged. All these fixed inputs still count toward the allowance.
Provider-native `instructions` and output/tool schemas in model defaults,
request options and `extra_body` also count as protected input. Counting these
layers is conservative: overridden duplicates may count more than once. Summary
requests omit those instructions and schemas, including nested body overrides;
their tool prohibition and optional explicit summary limit cannot be overridden
by main-request defaults. Main-request token limits are not inherited by summaries.
Main-request options remain unchanged.

With compaction enabled, supply history through graph messages. Provider `input`
or `messages` overrides and server-side `previous_response_id`, `conversation`
or `prompt` references raise `ContextLimitExceeded`: their effective history or
instructions cannot be bounded locally. Disabled compaction preserves their
existing behavior.

The latest user request is retained verbatim. Older user messages, assistant
answers, completed tool calls/results and prior summaries can be summarized.
Loaded skill bodies are ordinary tool results: summaries are instructed to keep
their skill names, essential requirements and resource references.

Calls and results are grouped atomically. A parallel group is eligible only
when every call has its corresponding result. Partial groups, dangling results
and groups crossing system/developer instructions remain protected. Summaries
replace spans in place, without moving history across protected instructions.

At 80% of the allowance, the policy selects older eligible history, preferring
to keep the two newest groups intact. It aims for 60%. If necessary, even the
latest completed tool group can be summarized. Large selected results are
processed in bounded portions; every selected portion reaches the summarizer
in order, without silent truncation. Summaries preserve completed work,
requirements, decisions, essential results, failures, identifiers, references
and remaining work. They are lossy memory notes, not guaranteed exact copies.

The final projection is checked again before main-model dispatch. If protected
inputs or the resulting summary cannot fit, `ContextLimitExceeded` stops the
request. No instruction, schema or current user request is shortened to recover
space. Missing or malformed summaries fail explicitly.

## History, cost and observation

Only outgoing model inputs change. Graph state, returned histories, original
tool artifacts, IDs and tool-round limits retain their complete native data.
This reduces model context, not the memory required to retain a full transcript.
Artifacts and diagnostic metadata not sent to the model are excluded from token
counting and summarization. An invocation keeps its summary cache; a new
invocation may need to summarize supplied full history again. There is no durable
conversation-memory store added by this feature.

Each summary uses the node's existing deployment/provider/transport, with tools
disabled and no output-token limit unless explicitly configured. Summary calls
consume the shared root model-call budget, can exhaust it before the main request, and obey root/child
deadlines. No retry or provider fallback is added. Provider errors and
cancellation propagate unchanged. Children share only execution budgets, not
summary content; simultaneous roots remain isolated.

Existing request capture and callbacks record summary calls with
`purpose="summary"`, their usage and their separate request identities. Summary
text is excluded from native user-facing message streams via `nostream`.
`context.compaction` events report outcome, estimated before/after sizes,
estimator, allowance, summary-call count, summarized-message count and duration.
Failure diagnostics expose the exception type, not raw provider payloads.
Existing redaction and recording privacy rules continue to apply; history and
summary material can contain sensitive business data.

## Counting and compatibility

Token counts include textual content, call arguments/results, instruction text,
tool/output schemas and estimated framing. Optional `tiktoken` is used when it
recognizes the selected model; unknown deployments or unavailable tokenizer data
use a conservative UTF-8 byte estimate. Estimates are not provider billing
counts or a guarantee that the deployment accepts the request. The byte fallback
can compact earlier and require more summary calls than a known tokenizer.

V1 accepts text and supported textual content blocks, including structured
textual tool output. Non-text media produces an explicit error when compaction
is enabled; disabled compaction leaves existing media behavior alone.

Offline coverage uses scripted models, real agent graphs and the real SDK over
synthetic HTTP transports. These checks do not establish live Azure or corporate
compatibility. The manager's accounting/encryption contract, deployment routing,
dependency pins, corporate configuration and SQLite schema are unchanged.
