# Dashboard thinking and request inspection validation

The dashboard now separates exposed thinking summaries from answers, provides
a per-call model timeline, and opens a searchable complete request JSON view
with stage selection, copy/download, deep links and follow updates. Summary
fragments survive an explicitly linked final response that omits the summary;
terminal summary text replaces fragments. Usage counts each native call once.
Unknown summaries, usage and first-output timing remain unavailable.

The viewer remains a stdlib, read-only SQLite application. Provider HTTP bodies
require an explicitly correlated capture event. The optional development
Foundry probe adds that event through an HTTPX request hook and the existing
agent recorder/redactor. It records JSON only, excluding headers and endpoint
URLs. No provider switch, credentials, dependency changes, encryption changes
or new shipped adapter behavior are introduced.

## Initial local live evidence

Two separately bounded local Foundry agent invocations used exactly
`gpt-6-luna` via Azure v1 Responses. Both discovered seven MCP tools, called the
real stdio `add(19, 23)` tool once, received 42 and returned `42`. No SDK retries
or API/model/provider fallbacks occurred. External tracing was disabled.

| Recording | Reasoning request | Input | Output | Calculated EUR |
| --- | --- | ---: | ---: | ---: |
| `adb3f2d1-b8d8-45e8-9a21-967dc6a2eab8` | low / detailed; direct addition task | 1,900 | 26 | 0.20430 |
| `e2c0af91-f1f3-4ff2-b12d-171b371ee9c1` | medium / auto; derive inputs from remainder constraints | 2,046 | 167 | 0.325486 |

The second invocation reported 1,006 input / 162 output tokens, then 1,040 input
/ 5 output tokens. Cache reads were zero; the second request reported 1,037
cache-write tokens, a subset of input. Costs use configured local EUR rates per
1,000 tokens. Combined spend across both invocations was **EUR 0.529786**;
these calculations do not verify provider billing.

Each invocation persisted two encrypted audit records. In-memory decryption
verified the fixed prompt and provider output; recorded usage/cost agreed with
the calculation and logger ledger. Each writer reported two written events,
zero dropped events/write errors/enqueue errors, a drained queue and closed
worker. Each dashboard recording contains two explicitly correlated HTTP JSON
bodies with the requested model and two completed native calls. Dashboard
usage reconciliation agrees; inspection left the SQLite file hash unchanged.

**These early invocations returned no thinking summary text.** The first invocation's output
contained a function call then a message. The second contained a reasoning
item with an empty `summary` array, plus the function call, then a message.
This was verified against decrypted provider output without printing audit
keys or raw records. The dashboard correctly shows “No thinking summary was
exposed in this recording.” Both probes therefore have `success=false`: their
summary requirement was unmet despite successful agent execution, request
capture and accounting. Synthetic summary coverage is distinct from this live
limitation; no replacement summary was generated.

OpenAI documents [the summary option](https://developers.openai.com/api/docs/guides/reasoning#reasoning-summaries)
and [GPT-6 Luna reasoning/tool support](https://developers.openai.com/api/docs/models/gpt-6-luna).
These describe the request contract; they do not establish this Azure
deployment's summary availability. The task does not validate corporate Entra
identity, proxy, shared drives, or sibling wrapper dependency compatibility.

Runtime: Python 3.12.12, agent 0.1.0, manager 0.4.0, OpenAI SDK 3.24.0,
LangChain 1.4.5, langchain-core 1.6.10, LangGraph 1.2.15 and FastMCP 4.1.0.
The isolated uv validation environment leaves package metadata, corporate
indexes, pins and package lockfiles unchanged. Local recordings and screenshots
are ignored artifacts; they are not included in the PR or distributions.

## Regressions and UI checks

After rebasing onto `main` at `06f5017`, the full agent/dashboard pytest suite
passed **238 tests and four subtests** with only loopback hosts allowed. Live
calls preceded that final rebase; the integrated branch was validated offline
without additional billable calls. The four focused dashboard-probe cases
cover actual SDK SSE, real agent/MCP/recorder integration, exact outbound
body equality, explicit request identities, absent endpoint/key fields, an
empty summary, HTTP 429 without retry, unpriced rejection and the live gate.
Manager/wrapper Foundry helper regressions passed **54 tests** with the root
`--offline` profile and sockets blocked.

Synthetic UI checks verified streamed summary updates, terminal replacement,
usage deduplication, complete text, stage/search/deep-link behavior, body
copy/download, disclosure/focus/reading-position preservation and narrow-screen
layout. The live UI displayed both completed calls, missing-summary labels and
the observed provider HTTP body with medium/auto reasoning. The full body
retained system/user input, tool schemas, token bound and SDK transport flags.

Ruff lint/format checks passed for the agent/dashboard and changed development
helpers. Both JavaScript syntax checks and whitespace checks passed. The agent
wheel and source distribution built successfully, and archive inspection
confirmed that local credentials, development probes and recordings were
excluded. Request search was also verified after a deep-link reload, with the
match centered in the reading area. Offline contracts do not establish live
Azure compatibility.

## Shared-wrapper max/detailed investigation

At the user's request, the agent defaults and both local agent probes now use
the real `socgenai_llm.GenAIChatModel`, Responses, and detailed summaries.
Authorized probes request max effort, a 4,096-token output cap, zero retries
and disabled external tracing/cache. `AGENTS.md` records those requirements.
The corporate indexes and all three packages' dependency metadata/pins are
unchanged. The isolated uv template overrides core to 1.6.10 to accommodate the
agent while running the actual wrapper; this is a local validation boundary.

The factory had a reproducible request bug: extra constructor options such as
`max_output_tokens` were silently ignored by the shared wrapper. A regression
failed with a missing output limit in the actual converted request. The factory
now splits declared constructor options from provider options, puts the latter
in `model_kwargs`, preserves caller dictionaries, and defaults Responses
reasoning summaries to detailed. Default sampling is omitted and propagated
correctly to MCP children. Explicit compatibility adapters remain available;
there is no runtime fallback.

Three separately bounded real agent executions used `gpt-6-luna`, max/detailed
reasoning and the shared wrapper:

| Run | Task / transport | Input | Output | Reasoning tokens | Summary characters | Calculated EUR |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| `18146c05-a586-4e40-a52b-72de3ae40b70` | remainder constraints / internal stream | 2,329 | 309 | 281 | 0 | 0.43981 |
| `4d37dd10-10f2-4915-b742-a5086360fcf7` | same task / native non-streaming | 2,231 | 211 | 183 | 0 | 0.373366 |
| `9f26ca85-e910-4e39-a746-11e241c521bd` | harder fixed Sudoku / native non-streaming | 2,829 | 701 | 673 | 1,364 | 0.623825 |

Every run discovered seven MCP tools, called stdio `add(19, 23)` exactly once,
and replied `42`. Every call completed within the token cap, recorded its exact
HTTP JSON, and reconciled audit usage/cost with the logger ledger. These three
investigation runs cost **EUR 1.437001** by local pricing; provider billing and
corporate acceptance are unverified.

The streamed short-task run produced zero summary characters in SDK summary
deltas, summary-done events and completed reasoning items. The native short-task
response echoed max/detailed but also returned an empty summary. This rules out
downstream capture loss for those samples and streaming as their sole cause.
The harder native task produced a real 1,364-character summary. Its complete
provider-text hash matched the dashboard text hash exactly; the final answer
call had no new summary. The deployment can therefore expose summaries. The
comparison supports workload-dependent omission; it does not establish a token
threshold or promise that max effort forces a summary on every request.
Azure documents [effort adapting to task complexity](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/reasoning#reasoning-effort)
and [the exposed summary parameter](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/reasoning#reasoning-summary).

The Sudoku invocation exposed a separate local validator bug: the fixed prompt
contains newlines, but the checker searched serialized audit JSON for literal
unescaped text. It falsely set `encrypted_audit_verified=false`, so the original
CLI report remains `success=false`. The corrected checker traverses decoded
JSON fields. In-memory revalidation of both original encrypted records passed
prompt, completion-summary hash and usage/cost checks; dashboard capture,
tool result and final answer also passed. A separate ignored revalidation report
records successful verification after the checker fix. The original report and
recording were retained unchanged; no additional paid call was needed.

The five shared-wrapper dashboard cases now exercise internal-stream and native
HTTP transport, summary SSE counters, absence of a summary, exact summary hash
preservation, 429/no retry, pricing rejection and the live gate. The multiline
fixed prompt exercises the corrected audit checker through the real pipeline.
The full wrapper suite passed **1,201 tests**, with eight corporate acceptance
cases skipped, in the isolated core-1.6.10 environment. Before integrating the
later merged PR #7, the agent/dashboard suite passed **241 tests and four subtests**.
The 54 locked manager/wrapper Foundry regressions
also passed. Local UI evidence displays the actual detailed summary and the
provider request's max/detailed configuration.
## Prior PR #7 merge review and integration

Integrated `main` at `dd83b9d`, including the revised prompt/parallel-tool policy
and embedding/cache-report changes. Both Astra standards and spec reviewers
cleared the final integration. The shared probe retains separate single-add,
parallel-add and dashboard scenarios, including their output/tool limits,
request options and success predicates. Unsupported dashboard-plus-parallel
combinations are rejected before dispatch.

Review found that following an unchanged native request could leave a newly
arrived provider body unavailable, and that a successful refresh after a fetch
failure could leave the error banner visible. Refresh now compares available
stages and the complete selected record, confirms that the body is rendered,
and preserves the latest search/disclosure/scroll state after a pending fetch.
Four runtime regressions failed before the fix. All six Node tests now pass,
including unchanged-body preservation and UI changes during a pending fetch.

Final integrated checks on 2026-10-14:

- Root locked offline suite: **2,042 passed**, 15 corporate cases skipped.
- Isolated Python 3.12 agent/dashboard suite with loopback-only sockets:
  **253 passed and four subtests passed**.
- Node request-refresh suite: **six passed**; both JavaScript syntax checks passed.
- Repository Ruff lint/format and Git whitespace checks passed.
- Agent wheel/sdist builds and archive checks passed. Public exports and parallel
  defaults passed from the installed wheel outside the checkout.

These integration checks made no new paid requests. Earlier live evidence above
remains limited to its recorded heads; the early missing live summary text meant
dashboard live-summary acceptance was unmet at that point. The shared-wrapper
investigation above subsequently recorded a detailed summary. Corporate acceptance and provider
billing remain unverified. GitHub reported no CI checks for this PR.

The follow-up integrated the merged PR #7 at `189d3c2` while retaining the
revised system-prompt hash, parallel-add scenario and serial-execution rejection
checks. All agent scenarios now use the shared Responses/max/detailed path.
Final combined validation passed **256 agent/dashboard tests and four subtests**,
all **six Node request-refresh tests**, the **54 locked Foundry regressions**,
Ruff lint/format, JavaScript syntax, whitespace, and agent wheel/sdist builds.
The archive checks exclude credentials, development probes and recordings.
This integration made no further paid requests; the detailed summary's original
recording and independent post-fix revalidation remain the live evidence.
