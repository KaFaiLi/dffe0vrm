# Analysis integration validation — 2026-10-17

Historical verification extracted from the skill guide. These counts and runtime
versions are retained as recorded evidence, not current acceptance. See the
[current skills guide](../skills.md), [risk demo record](risk-metrics-demo-validation-2026-10-17.md)
and [development setup](../../README.md) for contracts and evidence boundaries.

Validation on 2026-10-17: 382 package/dashboard tests passed, including four
subtests; the 17 Foundry probe tests passed separately from their new
`devtools/tests/foundry/data_package_agent/` location. The suite's Python 3.11
offline run passed 2,044 tests with 15 corporate live cases skipped, including
portable-bundle and test-boundary checks. Ruff lint/formatting, skill validation,
wheel/sdist builds and installed-wheel imports/report output outside the checkout
passed. The installed FOX check used pandas 3.0.6 and NumPy 2.5.4. Corporate
dependency resolution and live acceptance were not exercised.
