# Live agent workflow and dashboard review — 2026-10-14

Four explicitly authorized synthetic scenarios passed against local Azure Foundry
deployment `gpt-6-luna`. They used the real agent, MCP stdio server, sibling
`socgenai_llm.GenAIChatModel`, API manager, OpenAI SDK, Responses API and manager
internal streaming. Requests used max reasoning, detailed exposed summaries,
bounded output/time and zero SDK retries. No failed request was replayed.

## Live evidence

| Scenario | Model calls | Input tokens | Output tokens | Calculated EUR |
| --- | ---: | ---: | ---: | ---: |
| One MCP addition | 2 | 6,580 | 26 | 0.473782 |
| Two parallel MCP additions | 2 | 6,688 | 61 | 0.124734 |
| Sudoku and dashboard reasoning summary | 2 | 7,283 | 475 | 0.417479 |
| Coordinator/worker, todos and history compaction | 9 | 22,620 | 477 | 1.471803 |
| **Total** | **15** | **43,171** | **1,039** | **2.487798** |

Costs use the ignored local pricing configuration, denominated per 1,000 tokens.
They are calculated accounting evidence, not verified provider billing. Cache
reads and writes are subsets of input, not additional tokens. Across these runs,
cache reads totalled 30,840 and cache writes 12,286. All fifteen encrypted audit
records matched input/output/cache counts and calculated costs; the logger
ledgers agreed. There were no dropped events, write/enqueue errors or undrained
queues, and all writers closed.

The single-tool case returned `42`. The parallel case returned `42,18` and the
actual MCP executions overlapped for 2.656 seconds. The dashboard scenario
returned `42`; the first call exposed 830 characters of reasoning summary, while
the second exposed none. The dashboard displayed the recorded summary and
reported unavailable text honestly on the other call.

The broader workflow made nine model calls, including exactly one history-summary
request, and six tool calls: four native todo writes, one delegation and one MCP
addition. The coordinator and worker each created then completed their own todo.
The worker added 19 and 23; both agents returned `42`. Seeded earlier synthetic
history triggered compaction before the current task. Outgoing agent inputs used
the summary instead of the archive, while native message history remained intact.
The run used a shared limit of twelve model calls and eight tools, 4,096 output
tokens per request, a 45-second SDK timeout, a 240-second root deadline and a
270-second outer timeout. The existing spending guard remained active.

The workflow exposed no reasoning-summary text. Its successful history-compaction
summary is a separate observation and must not be described as an exposed thinking
summary. Dashboard projections verified both agents, all nine provider request
bodies, per-agent and combined usage, native todo tool messages, and exclusion of
auxiliary compaction replies from chat transcripts. The closed SQLite file's hash
was unchanged by inspection. Four compaction lifecycle events describe the one
summary operation; they are not four summary requests.

## Dashboard review and corrections

Separate Astra reviewers inspected backend projections and browser JavaScript.
The review reproduced and corrected six defects:

1. Failed polling loads could become permanently stale after the database
   watermark was updated. Pending refreshes now retry unchanged watermarks,
   including initial loading and final-page transcript fetches.
2. Follow latest scrolled an unmounted replacement node after reconciliation.
   It now scrolls the last mounted transcript node.
3. Manual request refresh cleared the selected detail before a failed fetch,
   losing its retry cursor. Manual refresh and following retain an independent
   cursor and preserve the existing body, search, disclosures and scroll position.
4. Fallback transcripts exposed auxiliary history-summary responses as assistant
   conversation. These remain in model evidence and usage, outside the transcript.
5. Native `write_todos` returns `Command.update.messages`; fallback transcripts
   omitted those tool results. They now recover the messages and their source paths.
6. Unguarded SQLite JSON extraction let unrelated malformed events break valid
   request inspection. Queries now guard extraction and preserve malformed raw
   evidence using the shared decoder.

Browser inspection of the actual live recordings verified the coordinator/worker
selector, completed todo results, final answers, request-body search and manual
refresh, Follow latest scrolling, model timeline and usage reconciliation. The
worker displayed eight native messages and 9,669 tokens; the root total included
both agents and the summary call, 23,097 tokens. Desktop layout remained readable.

## Reproduction and verification

Use the isolated Python 3.12 uv environment documented in
[AGENTS.md](../../AGENTS.md). It loads the three sibling packages editable and
locally overrides `langchain-core` to 1.6.10 without changing production metadata,
corporate indexes or existing locks. The SDK is OpenAI 3.24.0. Live commands use
`devtools/foundry_lab/run.py --run-live`; the new broader case is documented in
[the dashboard guide](../../dashboard/README.md#bounded-tree-todo-and-compaction-workflow).

Offline checks use synthetic HTTP with the actual graph, MCP subprocess, wrapper
and SDK. The workflow regressions cover success, HTTP 429 without replay, explicit
live opt-in and unpriced rejection before dispatch. Dashboard regressions exercise
actual graph recordings and production JavaScript functions.

Final validation passed:

- Agent package: `uv run --project ../../artifacts/foundry-agent --locked
  --python 3.12 python -m pytest -c pyproject.toml tests dashboard/tests -q
  --allow-hosts=127.0.0.1,::1 --allow-unix-socket --tb=short` — **464 tests and
  4 subtests**, with one existing LangChain MCP beta warning (326.21 seconds).
- Suite root: `uv run --locked pytest --offline
  packages/genai-api-manager/tests/foundry packages/socgenai-llm/tests/foundry
  devtools/tests -q` — **112 tests** (36.62 seconds).
- Node: `node --test dashboard/tests/test_request_refresh.cjs
  dashboard/tests/test_dashboard_refresh.cjs` — **15 tests**; both JavaScript
  syntax checks passed.
- Package Ruff checks and formatting passed for all 177 Python files. Changed
  development helpers passed root Ruff checks and formatting. `git diff --check`
  passed. Browser inspection reported no warning/error console entries.
- A final independent Astra review of the new workflow runner found no blocker
  in opt-in, pricing, request bounds, retry policy, privacy or evidence checks.

The ignored output directories are under `devtools/foundry_lab/output/`:

| Scenario | Directory |
| --- | --- |
| Single addition | `ebc2dbf617004b68a55cce838cd17baa` |
| Parallel additions | `54e2bff6268c4f8493b2ffd01069da1b` |
| Dashboard summary | `846e54c45b2f45a298019f3ac72685c6` |
| Full workflow | `67f2b9d0d1af4abb9b297a323c571467` |

Each contains a safe `summary.json`; audit logs and plaintext SQLite recordings
remain ignored and sensitive. Additional safe aggregate evidence is in
`artifacts/live-agent-review-2026-10-14/case-results.json`.

Corporate Entra authentication, proxy, shared drives, production endpoint
acceptance and corporate dependency resolution were not exercised. These bounded
local scenarios do not establish compatibility for every deployment or arbitrary
agent task. No claims of provider billing verification are made.
