# PnL implementation and agent evaluation — 2026-10-17

The new `analysis/pnl/` module, single `run_pnl_analysis` MCP tool and application
`pnl` skill are implemented on `codex/pnl-audit`. The six source paths produce
Markdown for the agent and a workbook with complete evidence tables.

The deterministic analyzer detected **7 of 7 seeded exceptions**. A completed
live agent review identified all seven exceptions with their dates or adjustment
ID. On the fuller interpretation rubric, **six are complete and one is partial**:
the agent identified the PnL outlier but did not connect it to the injected
Unexplained attribution contribution. This is one synthetic case, not a measured
general accuracy or false-positive rate.

## Case and isolation

The copied source templates are under `devtools/test_source/`. History labels
formerly called team A/B are now FO/MPC. The reproducible generator creates
`devtools/test_source/pnl_review/input/`; its answer key sits outside that folder.
The live runner copies only the input folder and application skill, and never
loads the answer key. The fixed prompt names the review scope and file paths,
without specifying the seeded dates, entities, IDs or anomaly count.

The case contains 3,132 PnL rows, 3,132 attribution rows, 9,048 validation records,
24 adjustments and 106 selected commentary records for 2025-07-01 to 2026-06-30.
There are 12 PnL series with 261 dates each. The synthetic context explicitly
defines FIC/EQD descendants, MPC's accepted Official PNL state, row currencies and
matching PnL/attribution basis. These are fixture definitions, not corporate rules.

The baseline attribution template retains its original cumulative values. The
generator rebuilds calendar-year accumulations in the evaluation copy before
introducing the reset anomaly, isolating that error from baseline convention.
The baseline ECHO validation gap and four pending commentary validations remain
separate from the seven intentional injections.

## Detection and interpretation

The workbook's Exceptions table was compared with exact check/entity/date/ID
keys using `devtools/pnl_evaluation/assess.py`. Agent interpretation was then
reviewed against the final response; passage matching alone does not award a pass.

| Injection | Numerical detection | Agent's final review | Interpretation |
| --- | --- | --- | --- |
| ALPHA, 2025-11-18: DTD 12 and corresponding Unexplained contribution | Detected PnL outlier | DTD +12, z=14.06, PnL row 1202; requested valuation support | Partial: correct outlier, no explicit Unexplained attribution link |
| ALPHA, 2026-01-01: prior-year attribution carried forward | Detected annual reset difference | Reported +27.776541 on Jan 1 and equal opposite Jan 2 difference; requested reset/source recalculation | Complete |
| BRAVO, 2026-02-03: FO Pending | Detected non-validation | FO Pending, validation row 5380, separately recognized accepted MPC evidence | Complete |
| CHARLIE, 2026-03-17: absent MPC history | Detected evidence gap | Missing MPC evidence, PnL row 2224; did not call it a proven failed approval | Complete |
| DELTA, 2026-04-14: conflicting active FO states | Detected conflict | Cited Validated/Pending records at validation rows 7111 and 9049 | Complete |
| Adjustment 96600002: EUR amount increased by 100,000 | Detected conversion difference | EUR 585,200.50 versus 485,200.50, adjustment row 3; requested FX/source correction support | Complete |
| GOLF, 2026-05-12: attribution MPC Pending | Detected attribution non-validation | Cited attribution row 2708 and kept it separate from PnL history | Complete |

Additional checks:

- All 24 adjustments appear in the detailed workbook, including the June 30
  valuation adjustment created on July 1. The agent explicitly reported all 24
  checked and disclosed that Markdown displays only 12.
- The agent identified ECHO's 261 missing obligations for both roles, and reported
  264 distinct exception obligations without adding overlapping FO/MPC counts.
- Six statistical PnL candidates were found, including the injected one and five
  baseline candidates. These do not automatically constitute audit findings.
- The agent retained FIC/EQD parent scope, separated commentary managerial
  validation from FO/MPC validation, and avoided an invented validation SLA.
- Its combined adjustment amount used the supplied EUR-converted column; it did
  not add raw USD, JPY and EUR PnL or add adjustments to reported PnL.

The omitted Unexplained link illustrates a limit of the compact Markdown:
driver profiles retain all fields in the workbook, while the visible excerpt
shows only the largest 12 profiles. The agent did not retrieve omitted workbook
rows. A future enhancement could present daily attribution drivers beside each
PnL outlier; that capability is not claimed by this implementation.

## Live execution and accounting evidence

Successful run: `92208b90cd2b4a82890d0d9fd226e1de`.
It used the real agent graph, actual MCP stdio tool, sibling `socgenai_llm`,
Azure Responses, `gpt-6-luna`, max reasoning and detailed exposed summaries.
It loaded the PnL skill and both references, called the analysis exactly once,
and returned a 6,293-character final review. All source hashes remained unchanged.

The harness used for this live evaluation permitted 12 model calls, 12 tool calls,
16,384 output tokens per request, a 240-second agent deadline and a 270-second
outer deadline. SDK retries
are zero. The EUR 5 post-response accounting threshold is not a hard spending cap.
The successful run used eight model calls and eight tool calls.

Before PR creation, the branch was rebased onto `8be16c6`, which introduced the
suite's policy of omitting default output-token limits. The current PnL runner
follows that policy and retains the request/tool/time/spending controls above.
The live results below remain evidence from the earlier capped harness; no new
live call was made during PR preparation.

Three earlier bounded runs did not produce a completed review. They are retained
as failures, not counted as successful detection evaluations. Each subsequent
run followed an explicit harness/report change; no automatic replay was used.

| Run ID | Outcome | Model calls | Input tokens | Output tokens | Calculated EUR |
| --- | --- | --- | --- | --- | --- |
| db5ee497625845929cadd234a2cc02ef | Six-call budget exhausted | 6 | 43,571 | 7,348 | 0.00584602894 |
| e530eab46a844eceac86b25f3bb2f7cd | Final response incomplete at 8,192-token output limit | 7 | 48,031 | 9,402 | 0.00653298779 |
| c9fe1f13da624b259a55bdd6c7f1f40a | Eight-call budget exhausted after task-list update | 8 | 48,413 | 12,766 | 0.00754967848 |
| 92208b90cd2b4a82890d0d9fd226e1de | Completed review | 8 | 89,067 | 14,912 | 0.00971895632 |
| Total | Four development runs | 29 | 229,082 | 44,428 | 0.02964765153 |

The successful run reported 66,674 cache-read and 22,369 cache-write tokens, both
subsets of input. Costs use the configured local per-1,000-token prices.
All eight encrypted audit events matched provider usage, calculated cost and
the logger ledger. No drops, enqueue errors or write errors occurred; the queue
drained and writer closed. These are calculated costs, not provider billing proof.

Local run artifacts remain ignored under
`devtools/foundry_lab/output/92208b90cd2b4a82890d0d9fd226e1de/`:
`summary.json`, `tool_calls.json`, `provider_turns.json`,
`agent_response.md`, `assessment.json`, and
`analysis/pnl/4c9ab1c448804ff2b9566e5adcc7938f/pnl_review.md` / `.xlsx`.
Do not publish encrypted audit files or their keys.

## Offline and packaging verification

Validation used the isolated Python 3.12.12 uv environment described in the
agent's AGENTS.md. Runtime versions included agent 0.1.0, manager 0.4.0,
socgenai-llm 2.5.0, langchain-core 1.6.10 and OpenAI SDK 3.24.0.
The local core override remains separate from production dependency pins.

- **408 package/dashboard tests passed**, including 24 PnL analysis cases and
  real MCP transport, concurrent report isolation and skill-loading tests.
- **20 isolated Foundry development regressions passed**. The three PnL runner
  regressions were rerun after final harness changes and passed.
- Package Ruff lint and formatting, changed development-file Ruff checks,
  skill validation and `git diff --check` passed.
- Wheel and sdist built with an invocation-only public build index; corporate
  package metadata and indexes were preserved.
- The wheel imported outside the checkout and ran the six-file case successfully.
  Archive inspection confirmed the new module and tool are included, while
  local credentials, development datasets and Foundry output are excluded.
  The skill is deployed as application files, matching post-trade-control.

After rebasing onto `8be16c6` for PR creation, the expanded suites passed
**411 package/dashboard tests** (plus four subtests) and **32 isolated Foundry
development regressions**. Package/development Ruff checks, formatting,
`git diff --check`, and wheel/sdist builds passed again. This rerun exercises
the current runner's omitted output-token limits with synthetic Azure responses.

No corporate identity, proxy, shared-drive, dependency-resolution or live
corporate acceptance is established by these local checks.
