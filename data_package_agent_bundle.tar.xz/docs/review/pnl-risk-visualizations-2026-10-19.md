# PnL and risk visualization validation — 2026-10-19

Implemented in the `pnl-risk-visualizations` worktree on
`codex/pnl-risk-visualizations`, based on `521c620`. Existing source datasets and
the original checkout's uncommitted work were preserved.

## Result

The normal PnL and risk runners now publish Plotly PNG figures, a complete chart
index and a source-evidence manifest alongside the existing Markdown and Excel.
Daily PnL, annual reported YTD and dated year-end factor snapshots remain at their
original comparable grains. Risk timelines show dated bounds, directional
utilization and existing source-linked findings. Public runner/MCP arguments and
Markdown return types are unchanged. See [the guide](../analysis-visualizations.md).

The committed PnL evaluation dataset produced **312 PNGs**: 48 daily/YTD PnL
figures, 240 factor small-multiple pages and 24 year-end factor snapshots.
The committed risk demo produced **36 PNGs**, covering its 12 VaR, 12 SVaR and
12 stress-test series. Other metric series are included when the analysis flags
them; that behavior is covered by an exposure fixture. All demo source hashes
remained unchanged. Generated files and the reproduction script are ignored under
`artifacts/visualization-demo/`; `summary.json` identifies the latest completed runs.

Visual inspection covered risk findings and changing limits, stress limits,
daily PnL, factor YTD small multiples and year-end bars. The review corrected
crowded footnotes, single-factor layout and long risk subtitles. Full risk
definition axes remain in the chart index and manifest.

## Checks

- Agent/dashboard suite: **506 passed, 4 subtests passed**. This run preceded the
  final title-layout polish and explicit report-section insertion.
- Final focused PnL/risk/chart and real MCP suite: **120 passed**, including actual
  browser PNG rendering, annual resets, partial cutoffs, missing/conflicting data,
  source integrity, independent factors, directional limits, exact series links,
  statistical windows, concurrency and publication cleanup.
- Separate offline mocked Foundry PnL/risk probes: **11 passed**. These used
  synthetic transport, not billable model requests.
- Package Ruff and formatting checks and `git diff --check`: passed.
- Wheel and source distribution: built. Verified new modules and Plotly/Kaleido
  dependency metadata, archive exclusions, and public runner imports from the
  installed wheel in an isolated environment outside the checkout.

The suites emitted the existing LangChain MCP beta warning. Initial tests exposed
two transient Windows directory-rename permission errors; both passed unchanged
on rerun. Publication now retries only Windows access/sharing errors, at most
three waits (50/150/450 ms), and still propagates persistent failure. A deterministic
regression verifies the bound and cleanup without sleeping.

Commands ran from the agent package using the isolated uv project described in
its AGENTS.md, with the pytest loopback allowlist. The focused command was:

```powershell
uv run --project ../../artifacts/foundry-agent --locked python -m pytest `
  -c pyproject.toml tests/analysis/test_charts.py tests/analysis/test_pnl_analysis.py `
  tests/analysis/test_risk_metrics.py tests/test_pnl_mcp.py tests/test_risk_metrics_mcp.py `
  -q --allow-hosts=127.0.0.1,::1 --allow-unix-socket
```

## Runtime boundary

Local validation used Python 3.12.12, Plotly 6.9.0, Kaleido 1.5.0 and installed
Microsoft Edge selected through `BROWSER_PATH`. The isolated environment retains
the documented local langchain-core 1.6.10 override and actual sibling packages.
The package corporate index, provider pins and root environment were unchanged.
The agent remains outside the suite lock; its local resolved lock is ignored,
and a production agent lock was not fabricated.

The first offline build could not resolve Hatchling from the corporate-index
cache. The successful build used `uv build --no-sources --default-index
https://pypi.org/simple`, without modifying the configured index. Corporate
dependency resolution and Azure acceptance remain unverified. No live LLM calls
were made or needed for this change.
