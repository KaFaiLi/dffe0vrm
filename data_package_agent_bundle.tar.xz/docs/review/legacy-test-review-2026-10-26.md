# Data Package Agent legacy-test review — 2026-10-26

This is the test-cleanup baseline at commit `b5dd347`. The subsequent
[compatibility-code removal](../legacy-removal.md) supersedes the retained-code
inventory below; deleted-file links refer to that historical checkout.

Scope: Data Package Agent only, including its dashboard and the separately
collected suite-owned agent probe tests. The API manager and wrapper are unchanged.
The requested policy is to remove obsolete and dedicated backward-compatibility
tests, while identifying retained compatibility code for a separate decision.

## Review outcome

Reviewed the inventory, test purposes and imports across 50 Python test modules
under the package, two dashboard JavaScript suites, and eight Python agent-probe
modules under the suite's development tools. Candidate legacy cases were checked
against their implementation and current package contracts.

Removed 41 test functions, including the 28-function
`tests/test_genai_manager_model.py` module. Of its 28 cases, 27 exercised the old
adapter; its one mock-only shared-provider factory case overlapped
the stronger current `test_socgenai_factory.py` coverage. Mixed tests retain their
current-behavior assertions, with historical parameters and fixtures removed.
The per-file inventory below counts functions, not expanded pytest cases.

Production modules, provider selection, dependency pins, package metadata and
lockfiles are unchanged. Dedicated compatibility coverage is intentionally gone;
remaining test success does not establish backward compatibility of the retained
code or readability/migration of historical databases.

## Removed or narrowed coverage

| Area | Change | Current coverage retained |
| --- | --- | --- |
| Old LLM adapter | Delete `test_genai_manager_model.py` and its adapter-based compaction transport case. | Actual shared wrapper factory, Responses compaction, explicit caller limits, tool history and reasoning summaries. |
| Parallel policy | Remove old split middleware parameters, disabled-parallel configuration and ignored sequential keyword cases. Replace adapter-dependent dispatch with the shared `socgenai_llm` Responses conversion path. | Both public builders, sync/async tool overlap, request immutability, exact budgets and effective-request recording. |
| Notebook/rendering | Remove Responses v0 fallback, compatibility summary metadata and legacy token-only stream assertions. | Normalized summaries, raw evidence and separation of tool arguments from answer text. |
| FOX reports | Remove three frame-interface/import compatibility tests. | Current in-memory result, stable row identity, queue order, complete reports and input immutability. |
| PnL/risk imports | Remove PnL re-export identity checks and risk writer/type alias assertions. Switch remaining PnL calculation tests to the owning `loading.prepare` import. | Arithmetic, current workbook rendering, full long-text evidence and immutable results. |
| Retired PnL preview | Remove the test of the uncalled balanced preview helper using former factor chart families. | Current exported charts and assertions that PnL returns no chart previews. |
| Historical review periods | Remove two tests accepting old period-filtered tool traces. | Current source binding, evidence validation and rejection of removed date parameters by Python/MCP. |
| SQLite v1 | Remove old reader/migration/rollback fixtures and the migration branch of concurrent startup. | Current schema initialization, two-writer startup, redaction, payload interning, exports and current writer/reader integration. |
| Dashboard fixtures | Initialize databases with the real current storage writer; populate private tables and read public views. | Standalone standard-library execution, all dashboard behavior, malformed-record handling and actual read-only-table rejection. |
| Skill constructor | Remove the assertion for the original four-field `Skill` constructor. | Markdown-only loading and current supporting-file discovery/read contracts. |

The dashboard fixture loads only the standard-library storage module from this
checkout, closes its writer, and then inserts synthetic records. Two deliberately
corrupt-record tests drop JSON expression indexes before writing invalid JSON;
normal fixtures retain the production indexes. No production database is touched.

Kept tests with words such as “backward”, “historical” or “compatibility” when they
describe current behavior: backward pagination, historical business data,
cross-source evidence compatibility, reserved middleware rejection and forbidden
old input parameters. Current PnL source-column aliases and observation envelope
version 1 are supported data contracts; envelope version 1 is distinct from the
removed SQLite storage-v1 fixtures.

## Legacy support scripts and modules to highlight

All paths below are relative to this package unless explicitly marked suite root.
These files are highlighted for review, not deleted. Several combine active
behavior with a small compatibility branch.

| File | Legacy/older-development purpose | Current owner or boundary |
| --- | --- | --- |
| `scripts/setup_genai_manager.py` (subsequently removed) | One-off removal of `mf-genai-api-manager.pth`, then installation of the `genai-manager` extra; prints instructions selecting the old provider. | Normal agent use is `socgenai_llm`; use the documented package/local environment setup. This script was not run. |
| `analysis/fox/fox_analysis.py` (subsequently removed) | Backward-compatible executable module forwarding to `runners.main`. | `analysis.fox.runners`. |
| [llm/genai_manager_model.py](../../src/mcp_agent_template/llm/genai_manager_model.py) | Complete older LangChain adapter, old reasoning shapes, Chat/Responses conversion and Pydantic-v1 serialization. | The normal agent path uses the sibling `socgenai_llm.GenAIChatModel`. |
| [llm/genai_manager.py](../../src/mcp_agent_template/llm/genai_manager.py) | Explicit `genai_manager` factory branch retains the older adapter. | Also owns the active shared-provider factory; do not remove the module wholesale. |
| [config.py](../../src/mcp_agent_template/config.py) | Retains `allow_parallel_tool_calls` and normalizes old false values to true. | Current runtime always enables model parallel tool calling; capacity remains a separate limit. |
| [agent/runtime/middleware.py](../../src/mcp_agent_template/agent/runtime/middleware.py) | Split `RunLifecycleMiddleware`/`ToolExecutionMiddleware` wrappers and ignored ordering keywords. | `RuntimePolicyMiddleware` and `ToolRoundPolicyMiddleware` remain active. |
| [agent/factory.py](../../src/mcp_agent_template/agent/factory.py) | Reserves the names of the old middleware pair to prevent conflicting application middleware. | Current builder validation, so rejection tests remain. |
| [agent/prompts.py](../../src/mcp_agent_template/agent/prompts.py) | `build_sequential_policy_prompt` is an empty compatibility helper. | Current prompt assembly and todo instructions still use this module. |
| `analysis/fox/duplicate_analysis.py` (subsequently removed) | Re-exports duplicate constants and handling under the former import path. | `analysis.fox.preprocessing`. |
| [analysis/fox/utils.py](../../src/mcp_agent_template/analysis/fox/utils.py) | `create_aging_bucket` forwards the old helper import. | `preprocessing.create_aging_bucket`; other utility functions remain active. |
| [analysis/fox/markdown_report.py](../../src/mcp_agent_template/analysis/fox/markdown_report.py) | `format_analysis_markdown` accepts original frame arguments; retains `AGING_BUCKET_ORDER` import. | `render_markdown(AnalysisResult, ...)`. |
| [analysis/fox/export.py](../../src/mcp_agent_template/analysis/fox/export.py) | `export_report` regenerates sequential IDs and index-based queue membership for old frame callers. | `write_workbook(AnalysisResult, ...)`. |
| [analysis/fox/summary_analysis.py](../../src/mcp_agent_template/analysis/fox/summary_analysis.py) | Missing `execution_month` fallback and `collect_analysis_result` bridge support older frame inputs. | Both also participate in the active numerical/report pipeline. |
| [analysis/fox/models.py](../../src/mcp_agent_template/analysis/fox/models.py) | Stores caller-supplied queue snapshots so legacy annotations survive. | Active `AnalysisResult` shared by current report writers. |
| [analysis/pnl/calculations.py](../../src/mcp_agent_template/analysis/pnl/calculations.py) | Retains `prepare` at its old import location. | `analysis.pnl.loading.prepare`. |
| [analysis/pnl/reporting.py](../../src/mcp_agent_template/analysis/pnl/reporting.py) | Re-exports `TEXT_PART_SIZE`, `evidence_rows` and `export_workbook`. | `analysis.pnl.excel`; Markdown functions remain active here. |
| [analysis/risk_metrics/sgmr.py](../../src/mcp_agent_template/analysis/risk_metrics/sgmr.py) | Re-exports `Observation`. | `analysis.risk_metrics.models.Observation`; SGMR analysis remains active. |
| [analysis/risk_metrics/report.py](../../src/mcp_agent_template/analysis/risk_metrics/report.py) | Former Excel-writer entry point and ignored `visualizations` keyword. | `analysis.risk_metrics.export.export_workbook`; current Markdown remains here. |
| [analysis/charts.py](../../src/mcp_agent_template/analysis/charts.py) | `chart_section` and its preview selection helper remain after PnL inline previews were retired; no production call sites found. | Chart generation/export is active elsewhere in this module; do not delete it wholesale. |
| [observability/recording/storage.py](../../src/mcp_agent_template/observability/recording/storage.py) | Reads SQLite v1 and migrates it with preserved exceptional `_legacy_*` mirror rows. | Current schema is v2. Fresh-database initialization still calls the migration machinery, so it is not wholly dead code. |
| [observability/recording/runtime.py](../../src/mcp_agent_template/observability/recording/runtime.py) | Lazy `InvocationScope` re-export preserves its historical import location. | `agent.runtime.invocation.InvocationScope`. |
| [dashboard/server.py](../../dashboard/server.py) | Accepts SQLite storage versions 1 and 2 for read-only inspection. | Current fixtures now use writer-created v2 databases. |
| [dashboard/message_view.py](../../dashboard/message_view.py) | Reasoning-metadata and token-only stream fallbacks for old recorded shapes. | Normalized message blocks and callback chunks. |
| [notebook.py](../../src/mcp_agent_template/notebook.py) | Responses-v0 and provider reasoning metadata fallbacks. | Current normalized Responses content blocks. |
| [skills/loader.py](../../src/mcp_agent_template/skills/loader.py) | Defaults supporting-file metadata so the original four-field `Skill` construction remains accepted. | Current skill discovery supplies the file inventory. |
| [notebooks/review_reporting.py](../../notebooks/review_reporting.py) | Generic expected-argument matching can retain historical period-scoped trace evidence. | Also enforces current source provenance and canonical coverage; not an obsolete module. |
| [tool_results.py](../../src/mcp_agent_template/tool_results.py) | Normalizes result shapes across LangChain/MCP adapter versions. | Active integration utility; its string/block handling is not exclusively legacy. |

The [package metadata](../../pyproject.toml) still declares the old
`genai-manager` extra and corporate source references. This review does not alter
those references or resolve the existing corporate dependency conflict.

Suite-root [devtools/pnl_evaluation/generate.py](../../../../devtools/pnl_evaluation/generate.py)
explicitly mentions legacy validation cases. It generates synthetic evaluation
datasets, rather than providing a runtime compatibility adapter.
`scripts/benchmark_recording.py`, the agent Foundry probe runners and their
regressions exercise current behavior and remain. Comparing baseline/candidate
performance is not backward-compatibility support.

## Validation

The pre-cleanup agent/dashboard baseline passed 766 pytest cases. The final
suite passed **703 cases and two subtests** in 272.30 seconds, with the existing
LangChain MCP beta warning. This removes 63 expanded pytest cases while retaining
424 source test functions (down from 465). Supporting verification completed:

- Dashboard JavaScript: 15 passed with Node's test runner.
- Standalone dashboard: 37 passed with `python -S -m unittest discover -s dashboard/tests -q`,
  confirming no third-party imports are needed by that test command.
- Agent-specific offline probe regressions: 46 passed on the first run; the
  remaining notebook preflight case failed because the new isolated environment
  lacked IPython. After `uv add --project artifacts/foundry-agent --dev ipython`
  in the suite root, that case passed on its focused rerun. No probe code changed.
  All 47 cases therefore have passing evidence across those runs.
- Ruff lint, Ruff format checks and `git diff --check` passed.

No live Foundry or corporate Azure requests were performed. Validation used the
ignored local environment with Python 3.12.12, OpenAI 3.24.0, LangChain Core 1.6.10,
LangChain 1.4.7, LangGraph 1.2.17, FastMCP 4.1.3, Polars 2.1.0, pytest 9.1.1 and
Ruff 0.17.2. IPython 9.17.1 was added only to that environment for the notebook
preflight. Production pins and corporate resolution remain unchanged/unverified.
The existing `langchain.mcp` beta warning remains visible.

Commands run from the package directory, using the isolated project documented
in `AGENTS.md`:

```powershell
$agentUv = @('run', '--project', '../../artifacts/foundry-agent', '--locked', '--python', '3.12')
uv @agentUv python -m pytest -c pyproject.toml tests dashboard/tests -q --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv python -m pytest -c ../../devtools/tests/foundry/data_package_agent/pytest.ini ../../devtools/tests/foundry/data_package_agent -q
uv @agentUv python -S -m unittest discover -s dashboard/tests -q
node --test dashboard/tests/test_dashboard_refresh.cjs dashboard/tests/test_request_refresh.cjs
uv @agentUv ruff check .
uv @agentUv ruff format --check .
git diff --check
```

No builds were required: package sources, packaging and dependency metadata were
not changed.

## Complete test-file disposition

Counts are source test functions before/after cleanup; parametrization expands
them at collection time. A retained file can contain many regression cases.


| Test file | Functions before → after | Disposition |
| --- | --- | --- |
| [tests/analysis/test_adjustments.py](../../tests/analysis/test_adjustments.py) | 13 → 13 | Retained: current behavior |
| [tests/analysis/test_attribution_pc_analysis.py](../../tests/analysis/test_attribution_pc_analysis.py) | 9 → 9 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/analysis/test_charts.py](../../tests/analysis/test_charts.py) | 17 → 17 | Retained: current behavior |
| [tests/analysis/test_commentary.py](../../tests/analysis/test_commentary.py) | 2 → 2 | Retained: current behavior |
| [tests/analysis/test_desk_hierarchy.py](../../tests/analysis/test_desk_hierarchy.py) | 4 → 4 | Retained: current behavior |
| [tests/analysis/test_fox_analysis.py](../../tests/analysis/test_fox_analysis.py) | 14 → 14 | Retained: current behavior |
| [tests/analysis/test_fox_pipeline.py](../../tests/analysis/test_fox_pipeline.py) | 7 → 4 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/analysis/test_hit_search_analysis.py](../../tests/analysis/test_hit_search_analysis.py) | 3 → 3 | Retained: current behavior |
| [tests/analysis/test_pnl_analysis.py](../../tests/analysis/test_pnl_analysis.py) | 24 → 24 | Retained: current behavior |
| [tests/analysis/test_pnl_evidence.py](../../tests/analysis/test_pnl_evidence.py) | 4 → 4 | Retained: current behavior |
| [tests/analysis/test_pnl_markdown.py](../../tests/analysis/test_pnl_markdown.py) | 7 → 6 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/analysis/test_pnl_pc_analysis.py](../../tests/analysis/test_pnl_pc_analysis.py) | 6 → 6 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/analysis/test_pnl_pipeline.py](../../tests/analysis/test_pnl_pipeline.py) | 5 → 4 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/analysis/test_pnl_validation.py](../../tests/analysis/test_pnl_validation.py) | 7 → 7 | Retained: current behavior |
| [tests/analysis/test_risk_metrics.py](../../tests/analysis/test_risk_metrics.py) | 45 → 45 | Retained: current behavior |
| [tests/analysis/test_risk_metrics_in_memory.py](../../tests/analysis/test_risk_metrics_in_memory.py) | 9 → 9 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_analysis_fixture_collection.py](../../tests/test_analysis_fixture_collection.py) | 1 → 1 | Retained: current behavior |
| [tests/test_builder_simplification.py](../../tests/test_builder_simplification.py) | 5 → 5 | Retained: current behavior |
| [tests/test_configuration.py](../../tests/test_configuration.py) | 6 → 6 | Retained: current behavior |
| [tests/test_context_compaction.py](../../tests/test_context_compaction.py) | 25 → 24 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_context_compaction_options.py](../../tests/test_context_compaction_options.py) | 3 → 3 | Retained: current behavior |
| [tests/test_context_compaction_responses.py](../../tests/test_context_compaction_responses.py) | 1 → 1 | Retained: current behavior |
| [tests/test_dashboard.py](../../tests/test_dashboard.py) | 6 → 6 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_default_analysis_skills.py](../../tests/test_default_analysis_skills.py) | 5 → 5 | Retained: current behavior |
| [tests/test_filesystem_tools.py](../../tests/test_filesystem_tools.py) | 5 → 5 | Retained: current behavior |
| `tests/test_genai_manager_model.py` | 28 → 0 | Removed old adapter suite |
| [tests/test_market_review_notebook.py](../../tests/test_market_review_notebook.py) | 5 → 5 | Retained: current behavior |
| [tests/test_mcp_server.py](../../tests/test_mcp_server.py) | 3 → 3 | Retained: current behavior |
| [tests/test_middleware.py](../../tests/test_middleware.py) | 14 → 14 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_model_attempts.py](../../tests/test_model_attempts.py) | 5 → 5 | Retained: current behavior |
| [tests/test_multi_agent.py](../../tests/test_multi_agent.py) | 10 → 10 | Retained: current behavior |
| [tests/test_notebook.py](../../tests/test_notebook.py) | 5 → 4 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_observability.py](../../tests/test_observability.py) | 7 → 7 | Retained: current behavior |
| [tests/test_observability_startup.py](../../tests/test_observability_startup.py) | 5 → 5 | Retained: current behavior |
| [tests/test_observability_storage.py](../../tests/test_observability_storage.py) | 4 → 4 | Retained: current behavior |
| [tests/test_parallel_dispatch.py](../../tests/test_parallel_dispatch.py) | 3 → 2 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_payload_storage.py](../../tests/test_payload_storage.py) | 8 → 5 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_pnl_mcp.py](../../tests/test_pnl_mcp.py) | 3 → 3 | Retained: current behavior |
| [tests/test_post_trade_review_mcp.py](../../tests/test_post_trade_review_mcp.py) | 2 → 2 | Retained: current behavior |
| [tests/test_react_agent.py](../../tests/test_react_agent.py) | 5 → 5 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_review_reporting.py](../../tests/test_review_reporting.py) | 43 → 41 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_risk_metrics_mcp.py](../../tests/test_risk_metrics_mcp.py) | 2 → 2 | Retained: current behavior |
| [tests/test_serve.py](../../tests/test_serve.py) | 10 → 10 | Retained: current behavior |
| [tests/test_skills.py](../../tests/test_skills.py) | 19 → 19 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [tests/test_socgenai_factory.py](../../tests/test_socgenai_factory.py) | 3 → 3 | Retained: current behavior |
| [tests/test_todo_compaction.py](../../tests/test_todo_compaction.py) | 1 → 1 | Retained: current behavior |
| [tests/test_todos.py](../../tests/test_todos.py) | 10 → 10 | Retained: current behavior |
| [dashboard/tests/test_inspection.py](../../dashboard/tests/test_inspection.py) | 29 → 29 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [dashboard/tests/test_message_view.py](../../dashboard/tests/test_message_view.py) | 3 → 3 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [dashboard/tests/test_server.py](../../dashboard/tests/test_server.py) | 5 → 5 | Current cases retained; legacy assertions/fixtures/imports cleaned |
| [devtools/tests/foundry/data_package_agent/test_foundry_dashboard_probe.py](../../../../devtools/tests/foundry/data_package_agent/test_foundry_dashboard_probe.py) | 3 → 3 | Retained: current behavior |
| [devtools/tests/foundry/data_package_agent/test_foundry_probe.py](../../../../devtools/tests/foundry/data_package_agent/test_foundry_probe.py) | 5 → 5 | Retained: current behavior |
| [devtools/tests/foundry/data_package_agent/test_market_review_probe.py](../../../../devtools/tests/foundry/data_package_agent/test_market_review_probe.py) | 3 → 3 | Retained: current behavior |
| [devtools/tests/foundry/data_package_agent/test_pnl_evaluation.py](../../../../devtools/tests/foundry/data_package_agent/test_pnl_evaluation.py) | 2 → 2 | Retained: current behavior |
| [devtools/tests/foundry/data_package_agent/test_pnl_probe.py](../../../../devtools/tests/foundry/data_package_agent/test_pnl_probe.py) | 2 → 2 | Retained: current behavior |
| [devtools/tests/foundry/data_package_agent/test_post_trade_probe.py](../../../../devtools/tests/foundry/data_package_agent/test_post_trade_probe.py) | 5 → 5 | Retained: current behavior |
| [devtools/tests/foundry/data_package_agent/test_risk_metrics_probe.py](../../../../devtools/tests/foundry/data_package_agent/test_risk_metrics_probe.py) | 3 → 3 | Retained: current behavior |
| [devtools/tests/foundry/data_package_agent/test_workflow_probe.py](../../../../devtools/tests/foundry/data_package_agent/test_workflow_probe.py) | 2 → 2 | Retained: current behavior |
| [dashboard/tests/test_dashboard_refresh.cjs](../../dashboard/tests/test_dashboard_refresh.cjs) | 6 → 6 JS cases | Retained: current refresh/recovery behavior |
| [dashboard/tests/test_request_refresh.cjs](../../dashboard/tests/test_request_refresh.cjs) | 9 → 9 JS cases | Retained: current refresh/recovery behavior |
