# Data Package Agent code and legacy design review

The one-off Python probe for this dated investigation was removed in the
[26 October compatibility cleanup](../legacy-removal.md). Its source is preserved
in Git history at commit `b5dd347`; commands and results below describe that snapshot.


Date: **2026-10-14**. Reviewed suite snapshot:
`ea5196ae56c6e0d880c1b58c94419d1dc535d968`.
The user selected the entire current package, with README, current guides and
root/package AGENTS.md as the intended behavior. This is a snapshot review,
not a comparison against the original import or a historical implementation.

Seven defects were confirmed with synthetic probes despite all **225 existing
agent/dashboard tests passing**. Two findings concern standards and documented
construction/error contracts; five concern behavior. Remaining design cleanup
is separated from those defects. At review time, runtime code and corporate
configuration were unchanged.

Implementation follow-up on **2026-10-14** fixes **S1**, removes the named **D11**
remnants and consolidates attempt allocation/reservation into effective dispatch.
The findings and JSON evidence below retain the original review snapshot.
The other six defect findings remain outside that requested implementation.
See the current [observability guide](../observability.md) and
[middleware inventory](middleware-usage-and-cleanup-2026-10-14.md) for migration
notes and the updated stack.

Follow-up validation: **234 agent/dashboard tests passed** with the documented
loopback-only socket allowlist, including new single/tree skill-recovery cases
and attempt identity, concurrent handler/root, retry, budget rejection,
cancellation and synchronous reservation-hook regressions. Ruff lint and
formatting passed. Wheel and source distribution built with
`uv build --offline --no-config --python 3.12`; archive checks excluded credentials,
local recordings and harness files. A fresh wheel installation outside the
checkout retained all exported names and both CLI entry points, preserved the
historical `InvocationScope` import, and completed a real scripted graph after
an unknown skill. Provider settings, corporate indexes and dependency metadata
remain unchanged; corporate/live acceptance was not run.

PR integration rebased the implementation onto main
`189d3c2b4e39a2dc5409c3c5886b921ae8675ff4`. The lifecycle middleware retains
main's `parallel_tool_calls=True` projection; effective dispatch owns the moved
model reservation. The synchronous parallel-dispatch regression now exercises
both layers and still verifies one reservation and an unchanged caller request.
The integrated agent/dashboard suite passed **262 tests and four subtests**
with the same loopback allowlist. Ruff, formatting, whitespace checks, wheel and
source builds passed. A unique wheel path avoided reuse of an earlier same-version
installation; installed changed-module source hashes matched this checkout,
and public imports, CLI entries, historical scope import and skill recovery passed.

The requested development worktree is
`C:\Users\likin\.codex\worktrees\data-package-agent-review\private_suite`, on
branch `codex/data-package-agent-review`. It initially started from the user's
`codex/live-suite-verification` branch and was later rebased onto main for the PR.

## Standards

**S1 [P2] Return a recoverable error for an unknown skill.**
[skills/tools.py:143](../../src/mcp_agent_template/skills/tools.py) passes
`handle_tool_errors=True`; the supported field is `handle_tool_error`.
The extra keyword is ignored, leaving the default policy. `load_skill` promises
that the agent "receives the error message and can try another name"; package
AGENTS.md also asks for actionable errors. A real built graph calling an absent
skill raised `ToolException` before its scripted recovery answer. Use the
singular option and cover recovery through the graph. The existing direct-call
test expects the exception and therefore misses this breach.

**S2 [P2] Reject duplicate MCP names before filtering a tree node.**
[multi_agent.py:241](../../src/mcp_agent_template/agent/multi_agent.py) collapses
the catalog into a dictionary before validation. Two injected tools named
`duplicate`, filtered by `AgentSpec.tool_names=["duplicate"]`, build successfully
and select the last implementation. The
[observability guide](../observability.md) promises "duplicate tool names ...
are rejected before that node's graph is constructed." Validate the catalog
before creating its name index; retain the final combined namespace check.

Standards: **2 findings**, both P2; the skill failure prevents same-run recovery.

## Spec

**B1 [P2] Keep numeric handled tool errors in Activity outcomes.**
[dashboard/inspection.py:176](../../dashboard/inspection.py) applies
`json_array_length` to `error_results`, although the actual capture middleware
emits an integer. The dashboard guide says "Severity/outcome is a separate
badge." An event with `error_results=1` appears as `recorded` in Activity,
as `error` in selected detail, and disappears under the error filter. Preserve
numeric counts and historical array forms. The current dashboard fixture uses
an array and misses the production shape.

**B2 [P2] Guard malformed evidence in model request correlation.**
[dashboard/request_view.py:83](../../dashboard/request_view.py) applies
`json_extract` to all events of the selected request's run without the shared
JSON validity guard. The dashboard guide promises "malformed event JSON is
retained as raw evidence with a visible error." One unrelated malformed log
payload makes valid request detail raise `OperationalError: malformed JSON`;
Activity remains readable. Reuse `records.json_sql` and the shared
`document`/`envelope` helpers across the request projections.

**B3 [P1] Own and close the API manager clients.**
[genai_manager_model.py:680](../../src/mcp_agent_template/llm/genai_manager_model.py)
and its Responses path at line 788 construct a client for each call and never
close it, including on provider failure. The manager's public interface requires
"Use a context manager or close() to ... release resources." Four synthetic
success/failure calls constructed four clients and closed zero. Actual manager
construction owns SDK, credential and logger resources; its default logger
starts a daemon writer retained by a bound method and an atexit callback. These
accumulate in long-lived agents. Give clients explicit ownership and cleanup
on both paths, preserving the original provider exception.

**B4 [P1] Normalize reported Chat Completions usage for the recorder.**
[genai_manager_model.py:507](../../src/mcp_agent_template/llm/genai_manager_model.py)
retains raw usage but omits `AIMessage.usage_metadata`. The callback reads only
the canonical field. The observability guide promises "Model usage ... with
missing usage kept unknown." A valid response reporting 11 input and 7 output
tokens produced `usage=null` and coverage `unknown` in `model.finished`.
Normalize authoritative totals and supported subsets at the adapter. This
reconfirms the previously documented, still-open **G01**, rather than identifying
a new regression. The manager's separate encrypted accounting is unaffected.

**B5 [P2] Preserve the recursion allowance for notebook raw graphs.**
[bundle.py:64](../../src/mcp_agent_template/agent/bundle.py) falls back to 32
steps, while the current factory gives the default graph 172. `stream_trace`
wraps raw graphs in a new bundle without the factory allowance. Its documented
raw-graph mode failed with `GraphRecursionError` on ten tool rounds and a final
answer; the same script reset and passed when given the original bundle.
Centralize the bound or carry it into the raw-graph wrapper, and remove the
obsolete `iterations * 3` configuration explanation.

Spec: **5 findings**; the P1 issues are unclosed clients and omitted reported
usage. Dashboard and raw-notebook failures remain separate from those issues.

## Redundant and legacy design candidates

These are design judgments, not additional confirmed defects:

- **Unused remnants:** searches find no consumers of `schema_descriptor`
  (`agent/composition.py:74`), `fingerprint` (`observability/capture/build.py:10`),
  `summary_request` (`observability/capture/requests.py:30`) or `SERVER_KEY`
  (`agent/react_agent.py:43`). `InvocationScope.build_event_id` is always initialized
  to null and never assigned, yet is emitted as `source_build_event_id`. Remove
  unused helpers after checking external imports; remove or properly populate
  the unused build-event reference. These are remaining **D11** candidates.
- **Attempt middleware:** `RequestObservationMiddleware` could share attempt
  allocation with effective dispatch. Its separate placement has documented
  retry/failure semantics, so consolidation needs those cases and concurrency
  verified first. It is already identified as conditional in the middleware
  inventory; removing all observation wrappers would lose distinct stages.
- **Adapter overlap:** the local adapter duplicates conversion responsibilities
  of the sibling `socgenai_llm` adapter. **D06 was previously excluded by the
  user**, and incompatible core pins still prevent direct consolidation. Fix
  the concrete local defects without treating this review as authorization to
  change providers, dependency constraints or adapter selection.
- **Notebook rendering:** every values snapshot rerenders the complete history.
  Consider updates for changed messages if long traces demonstrate a problem;
  preserve message-ID replacements and nested child artifacts. No new rendering
  performance measurements were made.
- **Development metadata:** dev/all extras and the dev dependency group repeat
  tooling with different minimums; Ruff is absent from the latter. This remains
  **D12**, requiring a separately authorized configuration decision.

The earlier **D01–D05/D07–D08** fixes are present. Shared node preparation,
per-build skill caching, invocation-owned budgets/gates, cancellation cleanup,
transactional storage migration and lossless content reconstruction should be
preserved. Their complexity alone is not evidence that they are legacy code.

## Validation and reproduction

Package checks used the isolated Python 3.12 uv workflow documented in package
AGENTS.md, with the real sibling manager editable and OpenAI 3.24.0. The agent
remains outside the root/wrapper environment. Public dependencies satisfied
the declared minimums; their versions are in the
[evidence JSON](data-package-agent-review-evidence-2026-10-14.json).

| Check | Result |
| --- | --- |
| Agent and dashboard pytest, loopback-only socket allowlist | 225 passed, one upstream LangChain MCP beta warning, 58.56 seconds |
| Package Ruff lint and formatting | Passed |
| Additional synthetic review probes | All seven described outcomes reproduced |
| Git whitespace check | Passed |

The first test run explicitly disabled the OpenTelemetry SDK and therefore
failed two assertions requiring local spans/metrics (223 passed). Removing that
reviewer-imposed setting restored all 225 tests. Local instrumentation remained
enabled for the final run; external LangSmith tracing was disabled.

From `packages/data-package-agent/`, use the `$agentUv` array from AGENTS.md:

```powershell
Remove-Item -LiteralPath Env:\OTEL_SDK_DISABLED -ErrorAction SilentlyContinue
$env:LANGSMITH_TRACING = 'false'
$env:LANGCHAIN_TRACING_V2 = 'false'
uv @agentUv python -m pytest -c pyproject.toml tests dashboard/tests -q `
    --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv ruff check .
uv @agentUv ruff format --check .
uv @agentUv python docs/review/data-package-agent-review-probes-2026-10-14.py `
    --output docs/review/data-package-agent-review-evidence-2026-10-14.json
```

The `data-package-agent-review-probes-2026-10-14.py` review probe (now in Git history) uses a synthetic
API manager client, scripted native models, real graph policies/callbacks,
temporary SQLite recordings and isolated dashboard fixtures. Notebook display
functions are replaced with inert functions; its real stream driving is exercised.
It documents current defects rather than functioning as an acceptance test
that passes after fixes. No paid calls, credential reads or corporate services
were involved. Corporate dependency resolution and live acceptance remain
unverified; no package build was needed for review-only documentation.
