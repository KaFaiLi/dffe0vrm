# Market activity review validation — 2026-10-19

Historical implementation and live-run evidence, extracted from the notebook
guide. Failed drafts remain failed; offline revalidation is distinct from a
fresh live run. Request bounds, source variants, runtime versions and counts
below describe those dated checks. Use the
[current notebook guide](../market-activity-review.md) for execution and the
supported report contract.

## Implementation verification — 19 October 2026

The isolated local Python 3.12+ environment, using the actual sibling packages
and the documented local-only `langchain-core==1.6.10` override, passed the full
agent/dashboard suite: **526 tests and four subtests**. The final focused report
and notebook suite passed **34 tests**, including export/cleanup checks added
after the full-suite run started. These are separate runs, not additive counts.
Package Ruff lint and changed-file formatting passed; package-wide formatting
reported only the pre-existing code fence in the unchanged P&L implementation
plan. Skill validation and `git diff --check` passed.

A separate non-billable smoke check executed the notebook's real baseline
preflight and all three real analysis tools through MCP. All completed, producing
six workbook/Markdown artifacts. All twelve source hashes were unchanged. The
trace wrappers used to inspect these tool outcomes were synthetic harness data;
this was not a live main-agent or specialist-model evaluation. No provider calls
were made, and live model quality and corporate acceptance remain unverified.

## First live attempt — 19 October 2026

The explicitly authorized local Foundry run `4c4cfb49be8a4265ac46b956ba90e27e`
used the actual notebook and all twelve baseline sources with `gpt-6-luna`.
The main loaded its shared skill, delegated the three initial reviews together,
and all three topic analyses completed. Six Excel/Markdown workpapers remain in
the ignored run directory. All source hashes were unchanged.

This run and the research inventory used a pre-existing local validation-history
variant with `MOCK_TEAM_A/B` labels (SHA-256
`c904f59d452671046b839ae425885e6a56027f73bc2baa03c22bc32ab306202f`).
That local CSV edit is not part of this implementation; the tracked baseline
uses FO/MPC labels. Verify the manifest and actual tool output when reproducing
the review. The notebook preserves supplied FO/MPC roles and treats only unmapped
MOCK labels as a role-definition gap. Other comparison definitions still require
documented inputs.

**This end-to-end test did not pass.** The initial 32-request limit was exhausted
during a targeted post-trade follow-up, before final synthesis. No final finding,
validated JSON or consolidated Markdown report was produced. The requested
follow-up was a closure-after-snapshot calculation unavailable through the
folder-only tool. Its absence is an unperformed audit procedure, not evidence
of a business control failure.

All 32 dispatched requests completed in 469.812 seconds. Reported usage was
369,265 input and 134,215 output tokens, including 210,583 cache-read and 158,586
cache-write tokens as input subsets. Calculated cost was **EUR 0.07924280263**
using local per-1,000-token prices. All 32 encrypted audit records reconciled
with captured usage/cost and the ledger; there were no dropped events or write
errors, and the writer closed. This is not provider billing verification.
A preceding setup attempt failed before dispatch because the installed MCP
update setting requires `off`; that attempt made no provider requests.

The runner now permits 64 requests, and the notebook explicitly rejects
delegating calculations the tool cannot perform. The 34 notebook/reporting
tests and four runner tests passed after these changes. A separate combined
runner regression run passed 12 tests. These offline checks do not establish
that the revised live workflow succeeds. No automatic live replay occurred;
another billable run requires confirmation. Corporate acceptance remains unverified.

## PR integration review — 19 October 2026

The review compared PR #19 (`8c6ea2a`, PNG reports) and PR #20 (`35ddb30`,
market review) with their shared `main` base `521c620`, then tested their combined
tree in a separate worktree using tracked demo inputs. Existing working-copy
CSV and research edits were not used or modified.

**Standards:** PR #19 had no actionable findings. PR #20 had one P2: independent
substring checks could accept another source's quote under a different source
ID within a shared topic report. Citations now require an unambiguous source
filename/path locator and an exact excerpt on the same report line.

**Spec:** PR #19 had no substantive findings. PR #20 had one P2: unordered path
matching allowed swapped commentary roles or changed review dates/context to
certify the original population. Paths now bind to tool-parameter roles, and
the notebook supplies its canonical arguments for coverage validation. A
follow-up regression found during re-review was also fixed: successful narrowed
analyses retain their evidence, artifacts and actual arguments, while only a
canonical analysis establishes completed coverage. Final focused re-review
found no remaining substantive issues.

The manager/wrapper offline profile passed **2,044 tests**, with **15 corporate
acceptance tests skipped**. The isolated agent Foundry regressions passed
**46 tests**. The final combined agent/dashboard suite passed **599 tests and
four subtests**, with only the pinned LangChain MCP beta warning. Reporting
regressions passed **84 tests**, including wrong-source
quotes, unrelated report lines, ambiguous filenames, swapped roles, changed
dates/context and retained follow-up workpapers. Suite Ruff lint/format and
diff checks passed. All three wheel/source builds passed; the shared package
archive/installed verifiers passed, and the agent wheel's new modules and
installed imports were checked outside the checkout. The local build used a
public index override without changing corporate configuration or package pins.
The final focused notebook/reporting run passed **93 tests**.

Two authorized live chart workflows passed through the actual agent, MCP
subprocess, sibling wrapper/manager and Azure Responses with max/detailed
reasoning, zero SDK retries and no output-token allowance:

| Live case / run ID | Requests | Input / output tokens | Cache read / write tokens | Calculated EUR cost |
| --- | ---: | ---: | ---: | ---: |
| P&L / `0a9c500f459242178ed233fe688b1206` | 8 | 95,087 / 14,100 | 66,666 / 28,397 | 0.01002814044 |
| Risk / `8e4925704a7c4e5ca41ddca276bf7c1c` | 8 | 115,305 / 16,136 | 79,125 / 36,156 | 0.01190805490 |

Cache reads/writes are input subsets, not additional input tokens. Pricing
used the ignored local price configuration per 1,000 tokens. The runs produced
**312 P&L PNGs and 36 risk PNGs** with complete chart indexes/manifests;
representative images were visually inspected. All supplied input hashes were
unchanged. All 16 encrypted audit records reconciled with captured usage/cost
and their ledgers, with no drops or writer errors, empty queues and closed
writers. Calculated costs do not establish provider billing.

The runtime remains the documented isolated Python 3.12.12 environment with
the local-only `langchain-core==1.6.10` override and actual sibling packages.
Production pins, corporate identity, proxy, shared drives and corporate Azure
acceptance remain separate and unverified.

The first combined market-review run after the provenance fix,
`43093e05f16f4b1395b11e7058702870`, completed all three topic analyses and
37 requests in 800.469 seconds, but its final report was **rejected**. Some
citations combined a source-inventory locator with a quote from another report
line; others altered the quoted text. No validated consolidated report was
published. The strict citation checks were retained. Field-level schema and
specialist/main instructions now require copied original evidence rows with
their source locators and escaping, reuse citation IDs, and omit evidence that
cannot be quoted faithfully. The final focused notebook/reporting run passed
46 tests after those instruction changes.

That rejected run reported 608,606 input and 195,224 output tokens, including
391,212 cache reads and 217,283 cache writes as input subsets. Its calculated
cost was EUR 0.11452714441. All 37 encrypted audit records and the ledger
reconciled, with no dropped events, enqueue errors or write failures; the queue
drained and the writer closed. All twelve source hashes remained unchanged.
These accounting checks do not make the rejected report a successful audit review.

The next run, `b5f2709f39ca44cc8f5a6505f6bda81c`, also remained **unsuccessful**.
P&L and risk completed; the post-trade specialist reached its 10-minute child
deadline, so its hidden partial trace could not certify completed coverage.
The main returned a partial report. All twenty quoted evidence rows matched
their successful tool reports verbatim, but offline replay exposed additional
integration defects: P&L's documented path compaction was treated as a changed
locator; shared D/C checks were rejected in topic observations; and legitimate
linked chart index/manifest files were outside the captured primary-workpaper
inventory. These cases now have focused handling and regression coverage.
Final comparison references used labels instead of the required identifiers;
their exact enum is now explicit in the model-facing schema. The original
report was not repaired or reclassified as a successful run.

This second run completed 35 requests in 978.969 seconds, reporting 617,394
input and 214,438 output tokens, including 379,905 cache reads and 237,384
cache writes as input subsets. Calculated cost was EUR 0.12521128271. All
35 encrypted audit records reconciled to usage, cost and the ledger, with no
logger drops or errors, an empty queue and a closed writer.

The local runner now allows a bounded 15-minute specialist deadline, 25-minute
root deadline and 26-minute outer cleanup deadline; the 64-request/80-tool
bounds, SDK timeout and zero retries are unchanged. The demonstration prompts
omit planning-tool updates so calls focus on skill loading, analysis and the
consolidated review. Reasoning remains max/detailed, and output-token limits
remain omitted.

The third verbatim-authoring run, `d3d2da3226e34f55966181f43c97ea29`, completed
all three reviews and 27 requests in 1046.094 seconds, including interpretation
follow-ups without rerunning the analysis tools. It still did **not** publish a
validated report: one copied excerpt changed a character, and the single-source
post-trade citations combined input paths with section labels that were not
literal report locators. Its raw output remains rejected and unchanged.

Reported usage was 281,222 input and 322,013 output tokens, including 148,380
cache reads and 132,761 cache writes as input subsets. Calculated cost was
EUR 0.15937580818. All 27 encrypted audit records matched usage/cost and the
ledger, with no logger errors/drops, an empty queue and a closed writer. All
twelve input hashes were unchanged.

The notebook now uses catalog selection instead of asking the model to retype
citations. Multi-source entries need unambiguous source markers; single-source
entries identify the exact tool-report digest and line. The model selects
opaque IDs from the scoped lookup, and validation rebuilds the catalog and
inserts server-owned evidence fields. Unknown/stale IDs, forged fields and
hash collisions fail closed. Legacy verbatim mode stays strict. This contract
change does not repair or republish any of the rejected saved responses.

The catalog-selection run, `600a6017b56d46e8acb5d16a530b3ffc`, completed all
three topic analyses through the actual four-agent notebook, MCP subprocesses,
sibling wrapper/manager and Azure Responses. It completed 25 requests in
873.422 seconds. All 40 selected catalog IDs resolved to exact source-bound
report lines. The original probe still reported failure: one supporting
commentary observation cited both P&L and risk checks/evidence, while validation
treated its `pnl` topic as exclusive. That contract defect is now fixed using
the primary-theme rule above, with acceptance and rejection regressions.

The unchanged recorded draft was then revalidated **offline**, using the
recorded successful tool arguments and exact saved report bytes with the
production capture, catalog, validation and rendering functions. All three
topic statuses, analysis scopes and artifact inventories matched the recorded
execution; all twelve input hashes matched. The result has 40 exact evidence
records, seven supporting observations, six artifacts, all 36 checklist IDs
and six cross-source comparisons. Its disposition is
`further_evidence_required`; this is a valid evidence-limited assessment.
Resolved `review.json`/`review.md` and a separate `post_review_validation.json`
record this replay in the ignored run directory. The original draft, execution,
validation error and `summary.success=false` remain unchanged. No new provider
requests were made for this replay, and the final validator change has not had
a fresh live run.

The catalog run reported 523,307 input and 171,177 output tokens, including
378,066 cache reads and 145,166 cache writes as input subsets. Calculated cost
was EUR 0.09568493364. All 25 encrypted audit records matched usage/cost and
the ledger, with no errors/drops, an empty queue and a closed writer. Across
the two chart runs and four market-review runs during this integration review,
the actual total was 140 requests, 2,240,921 input / 933,088 output tokens and
**EUR 0.51673536428** calculated cost, including unsuccessful runs. Provider
billing and corporate acceptance remain unverified.
