# Template design simplification implementation and validation

Date: **2026-10-14**. Implementation base:
`22d9554f4c70c3caee146c9a4a746072b8299f78`.
Scope: [D01–D08](../research/template-design-simplification-analysis.md), with
**D06 explicitly skipped at the user's request**. Integration with current main
preserves the separately merged removal of planning middleware and obsolete
adapters; D03 is superseded by that removal.

## Implemented findings

| Finding | Result | Compatibility and limits |
| --- | --- | --- |
| D01 | Preserve the earlier removal of obsolete policy adapters and `_make_concurrency_wrapper`. Compiled-tree regressions exercise the active policies. | Active builders use invocation-owned policies; caller concurrency wrappers remain supported. Removed helper imports are not restored. |
| D02 | Both builders use `_prepare_node` for skills/tools, model selection, system prompt, native graph and bundle construction. Counter-based validation owns the final namespace, including middleware tools. | Public builder interfaces and root-only application middleware remain. Tree diagnostics include the agent name; duplicate sibling tool detection is linear. |
| D03 | Superseded by the earlier planning-removal change. Shared preparation does not construct or inject planning directives. | Skills and child tools remain available through ordinary discovery and prompts. Successive-turn regressions confirm no planning middleware, definition field or capture event. |
| D04 | Storage version 2 replaces exact capture/log/feedback mirroring and run start/finish copies with event-backed SQL views. | Original column names and complete payload reads/exports remain. Version-1 readers remain supported; writer migration is transactional and retains orphaned/differing historical rows. |
| D05 | Redacted content literals of at least 1 KiB have one canonical part, with references in each event. Accepted part identity caching and immutable text redaction caching are bounded. | Lossless initial stage: all observations, metadata, stages and native artifacts remain. Small content and other metadata still serialize independently; mutable state is never cached. This does not claim every repeated capture operation has been eliminated. |
| D06 | Skipped. | No adapter, provider setting, corporate reference, dependency requirement or lockfile changed. |
| D07 | `agent.runtime.invocation.InvocationScope` owns graph driving, terminal outcomes and stream delivery. Recording runtime owns sinks and recorder lifetime. `RunContext` no longer carries observation references or the unused invocation-manager field. | Bundle invocation explicitly links child ancestry through shared execution budgets. Historical scope import remains. Context reuse rejection, timeout attribution, cancellation shielding, stream detachment and recorder cleanup remain covered. |
| D08 | Each tree build caches immutable parsed skill catalogs by resolved path, then copies/selects independently per node. | Cache lifetime is one build; later builds see changed files. Graphs/models are not cached, and child invocations keep independent contexts. |

The work does not extend D09–D12, change corporate configuration or integrate
the agent into the suite environment.

## Storage migration

Version 1 remains readable through current CLI/dashboard connections. A writer
upgrades it to version 2 under an explicit SQLite transaction. Migration failure
rolls back DDL and retains version 1. Stop old writers before an upgrade; old
applications reject version 2. Retain a version-1 backup for rollback to an old
application. Migration does not automatically vacuum or compact historical
event content.

Current writers acquire the SQLite write lock before reading the schema version.
Initial schema creation and migration retain that lock through the version update,
so simultaneous current-version starters do not repeat another writer's migration.

Public `events`, `runs`, `captures`, `logs` and `feedback` are complete SQL read
views. Events own each observation envelope; `payload_parts` owns exact content
literals and `event_parts` owns references. Reconstruction uses ordinary SQLite
string replacement inside the view, without a custom reader function. Tests
compare the resulting strings byte for byte, including escaped quotes, Unicode,
backslashes and newlines. Content hashing occurs only after credential redaction.

Request attempts, rounds, pre-policy input, effective requests, native results,
tool outcomes, stream snapshots and final state retain their separate identities
and meanings. Deduplication shares identical content rather than merging these
events. The envelope and JSON export versions remain 1 independently of storage
version 2. Full-content queries incur reconstruction work; measurements below
do not establish large-dashboard query performance.

## Verification

### Integrated review against main

Integration base: `3b66ca7421475a766f21181afa4e9b5123317cfe`, including the
planning removal, skill-folder/error-recovery, naming and local-probe PRs.
Two independent Astra reviewers found the obsolete planning integration and a
concurrent migration race. Both are resolved; follow-up standards and spec
reviews found no remaining actionable issues.

- **225 agent/dashboard tests passed** using the isolated public-dependency uv
  command in the package [AGENTS.md](../../AGENTS.md), with loopback-only socket
  access and external tracing disabled. No live provider requests were made.
- Both deterministic simultaneous-start cases (empty v0 and historical v1)
  failed before the storage fix and passed afterward. The full payload-storage
  group passed all 9 cases, including migration rollback and exact readback.
- Existing no-planning and skill-file failure/recovery tests remain in the full
  suite. The focused builder/middleware/skills group passed 97 cases.
- Ruff lint and formatting, JavaScript syntax and Git whitespace checks passed.
- Wheel and source distribution built. A fresh wheel installation outside the
  checkout passed public export checks, historical `InvocationScope` import
  compatibility and a real SQLite v2 content round-trip. Archive inspection
  confirmed the new invocation module, absence of obsolete compatibility code
  and exclusion of credentials/local recordings. A fresh wheel path avoided an
  earlier uv environment reusing the previous same-version artifact.

Runtime: Python 3.12.12, FastMCP 4.1.0, LangChain 1.4.5, langchain-core 1.6.10,
LangGraph 1.2.15, OpenAI 3.24.0, pytest 9.1.1, pytest-asyncio 1.4.0 and Ruff
0.17.0. These satisfy the declared runtime minimums. Corporate index/provider
acceptance remains unverified. Corporate metadata and lockfiles are unchanged.
The synthetic benchmark below remains historical evidence; it was not rerun
and does not establish production performance.

### Initial implementation evidence

Initial agent and dashboard run before integration with the planning-removal,
skill-folder, naming and local-probe changes:

~~~text
python -m pytest -c pyproject.toml tests dashboard/tests -q --tb=short
162 passed
~~~

The invocation used `uv run --no-project --python` with the available cached
interpreter and process-local `PYTHONPATH`, including the agent source and a
cached pytest-asyncio installation. It did not substitute local provider
configuration or make authenticated provider calls. MCP integration tests used
real local transports.

| Check | Result |
| --- | --- |
| Agent and dashboard tests | 162 passed; expected legacy deprecation and upstream beta warnings. |
| Ruff check and format check | Passed with the unchanged package configuration. |
| Wheel and source distribution | Built with `uv build --offline --no-build-isolation` and cached Hatchling/build dependencies. |
| Installed imports outside source | Built wheel installed with uv into an isolated validation environment. Public agent exports, local model import and historical `InvocationScope` import verified from installed files, with cached runtime dependencies. |
| Archive inclusion | Initial artifacts included the new invocation module and then-present compatibility module; `.env`, `.venv`, `.harness`, credentials and local development files were excluded. The compatibility module was removed during integration to preserve the earlier adapter removal. |
| Historical/read-only storage | Version-1 reads, exact/exceptional mirrors, run summaries, migration rollback, repeat opening, live WAL reads and dashboard inspection covered. |
| Capture fidelity | Real model/tool recording and complete archive export preserve large content, redaction, native messages and pre-policy/effective-request differences. Duplicate event identities cannot leave later content references unresolved. |
| Active execution | Decision trimming/replacement IDs; sequential, integer, parallel and caller child concurrency; existing independent-root, budget, timeout, cancellation and shutdown regressions passed. |

The normal `uv sync --extra dev` attempt failed resolving the existing corporate
Git hostname. No dependency contract was lowered or redirected to bypass this.
Local cached validation used Python 3.13.7, FastMCP 4.0.10, langchain-core 1.6.5,
LangGraph 1.2.12, OpenTelemetry SDK 1.45.0, pytest 9.1.1, pytest-asyncio 1.3.0,
Ruff 0.16.9 and Hatchling 1.32.4. FastMCP and langchain-core are below the
declared minimums, so a fully resolved corporate environment and authenticated
provider compatibility remain unverified. Repeat normal sync, tests and builds
there before deployment.

## Synthetic recorder measurement

[`scripts/benchmark_recording.py`](../../scripts/benchmark_recording.py) emits
160 observations from four producer threads. Every observation contains five
occurrences of the same 40,020-byte synthetic content, alongside distinct
observation metadata. A second workload delays each writer operation by 2 ms.
No provider or MCP connection is involved. Baseline source was exported from
the implementation base into an ignored validation directory; both runs used
the same cached runtime dependencies. Samples ran sequentially.

| Workload | Implementation | Producer seconds | Drain/flush seconds | Peak pending payload bytes | Physical content-column bytes | Database bytes after close |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Normal writer | Baseline | 2.487 | 1.085 | 31,252,541 | 56,091,483 | 56,352,768 |
| Normal writer | Candidate | 0.284 | 0.003 | 42,292 | 131,187 | 335,872 |
| 2 ms writer delay | Baseline | 2.694 | 1.300 | 31,050,430 | 56,091,483 | 56,352,768 |
| 2 ms writer delay | Candidate | 0.265 | 0.294 | 51,440 | 131,187 | 335,872 |

All samples finished with zero recorder errors, zero unrecorded events and
zero pending records. Candidate content had one canonical part. Public event
payload reads reconstructed about 32 MB in both implementations; dynamic health
metadata accounts for their one-byte difference. This workload intentionally
favors exact content reuse. These single samples measure neither production
latency nor corporate shared-drive behavior, and they do not guarantee a general
speedup or bounded queue behavior under arbitrary load. The existing queue
remains unbounded and lossless until writer failure.

Physical content-column bytes include baseline event/mirror payload columns,
or candidate raw event payloads, canonical parts and reference tokens/part IDs.
They are not total SQLite bytes or measured disk I/O. Producer time excludes
recorder startup/close; drain time includes the explicit flush after producers
finish. Complete values are in the
[measurement JSON](template-design-simplification-measurements-2026-10-14.json).

Reproduce in an approved package environment:

~~~powershell
uv run python scripts/benchmark_recording.py --output artifacts/recording-normal.json
uv run python scripts/benchmark_recording.py --slow-ms 2 --output artifacts/recording-slow.json
~~~

Select baseline source through a separate validation environment/PYTHONPATH;
do not alter the package's dependency contracts for a comparison. Real
large-tree and diverse-payload workloads remain necessary before extending
caching to compiled agents/models or adopting a different capture policy.
