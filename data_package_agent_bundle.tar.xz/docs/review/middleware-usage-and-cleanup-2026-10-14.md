# Middleware usage and cleanup

Reviewed on 2026-10-14 against suite commit
`22d9554f4c70c3caee146c9a4a746072b8299f78`.
Updated at the user's request to remove planning middleware entirely.
The later skill-recovery/cleanup follow-up consolidates attempt identity and
model reservation into effective dispatch, removing the separate request wrapper.

Repository searches found middleware implementations and registration in Data
Package Agent. The API manager and LangChain wrapper do not register middleware.
This inventory describes repository call sites; it cannot establish whether an
external application imports an undocumented helper.

## Active middleware and every registration path

Both `build_agent()` in [react_agent.py](../../src/mcp_agent_template/agent/react_agent.py)
and each node constructed by `build_agent_tree()` in
[multi_agent.py](../../src/mcp_agent_template/agent/multi_agent.py) call the shared
[build_graph() factory](../../src/mcp_agent_template/agent/factory.py).
That factory installs the following stack in order:

| Middleware | Hook and use | Registration / decision |
| --- | --- | --- |
| `ObservationMiddleware` | Async model wrapper creates the outer round identity and span. Async tool wrapper captures tool results/errors, duration and counts. | Every graph; retained. Capture passes through when no recorder is active. |
| `ToolRoundPolicyMiddleware` | Sync/async post-model hook enforces the exact tool-round limit while retaining all proposed parallel calls and message/call IDs. | Every graph; retained. A recursion limit measures graph steps and cannot replace this policy. |
| `AgentTodoMiddleware` | Native LangChain todo tool/state and duplicate-write checks; model hooks pass through because the shared prompt builder owns todo guidance. | Every graph, including workers; added for per-invocation todo tracking. No completion gate. |
| Application middleware | Caller-defined native hooks, request changes and tools. | `middleware=` on either builder; tree extensions apply only to the root. Retained. |
| `RunLifecycleMiddleware` | Sync/async pre-agent hook begins a fresh invocation context. Model wrappers apply `parallel_tool_calls=True` after application settings. | Every graph; retained. Shared model reservation now belongs to effective dispatch. |
| `ToolExecutionMiddleware` | Sync/async tool wrapper reserves shared tool budget, applies external capacity, checks deadlines, and excludes delegation from external permits. | Every graph; retained. This enforces execution policy even for application middleware tools. |
| `EffectiveRequestMiddleware` | Innermost model wrapper allocates each attempt identity, reserves the shared model budget, then captures the effective request and dispatch span. Sync/async reservation hooks use the same preparation. | Every graph; retained. Rejected reservations create no effective snapshot or provider call. The original round input and effective request can differ. |

Additional middleware has distinct conditional registration:

| Middleware | Use and all registration conditions | Decision |
| --- | --- | --- |
| `ChildConcurrencyMiddleware` | In `build_agent_tree()`, gates only child tool names for a parent with children when `AgentSpec.concurrency` is `"sequential"` or a positive integer. Gates belong to the invocation. `"parallel"` needs no child gate. | Retained. Child capacity and external-tool capacity serve different resources. |
| `_ToolCallMiddleware` via `tool_call_middleware()` | `build_agent_tree()` installs a caller's callable `AgentSpec.concurrency` wrapper as `sub_agent_concurrency` when child tools exist. | Retained: an actual builder call site depends on this adapter. |
| `MCPObservationMiddleware` | [build_server()](../../src/mcp_agent_template/mcp_server/server.py) registers it with FastMCP. It captures server-side tool arguments, results and failures for stdio, HTTP and in-process clients. | Retained. The server boundary differs from the agent's tool boundary. |
| `CloseObservationsOnShutdown` | [_run_server()](../../src/mcp_agent_template/mcp_server/server.py) installs this ASGI lifespan wrapper on the HTTP server when recording is enabled. It drains recording before forwarding shutdown completion/failure. | Retained. HTTP lifecycle cleanup is separate from agent policy. |

The six required middleware names remain reserved. Definitions and
build fingerprints now reflect the actually installed stack, and the existing
recursion safety formula uses that stack's length.

The first registered wrapper is the outermost wrapper. Round observation stays
outside application middleware; attempt preparation and effective dispatch now
share the innermost model wrapper.
[LangChain middleware composition](https://github.com/langchain-ai/langchain/blob/master/openwiki/middleware.md)
documents this ordering; repository tests exercise the current local stack.

## Removed obsolete paths

These paths are no longer called by either current builder. The obsolete policy
adapters were already unused before removal; the request wrapper was removed
after its active responsibilities were consolidated:

| Removed definition / helper | Previous repository usage | Active replacement |
| --- | --- | --- |
| `RequestObservationMiddleware` | Both builders registered it to allocate attempt identity before model reservation. | `EffectiveRequestMiddleware` now allocates identity before reserving model budget and capturing the effective dispatch. |
| `sequential_tool_node()` and `_sequential_tool_call_wrapper()` | Only `tests/test_react_agent.py` called the node helper; its wrapper belonged to the same legacy chain. The semaphore belonged to the constructed node. | Native builder tools and `ToolExecutionMiddleware`, with fresh invocation-owned ordering. |
| `sequential_tool_middleware()` | No production or test call site. | `ToolExecutionMiddleware`. |
| `_PlanningMiddleware` and `planning_middleware()` | The factory function only constructed the legacy class; no caller used that factory. | Native `AgentMiddleware.wrap_model_call` / `awrap_model_call` for explicitly supplied application input changes. |
| `_PostModelMiddleware` and `post_model_middleware()` | The factory function only constructed the legacy class; no caller used that factory. | `ToolRoundPolicyMiddleware` and native application `after_model` / `aafter_model` hooks. |
| `single_tool_call_hook()` | Only old helper tests and legacy helper docstrings referenced it. | `ToolRoundPolicyMiddleware`, also enforcing the round budget. |
| `_make_concurrency_wrapper()` | Only direct helper tests called it. Its built-in semaphore was shared across invocations. | Invocation-owned `ChildConcurrencyMiddleware`; callable concurrency still uses `tool_call_middleware()`. |

These undocumented module-level helper imports have been removed intentionally.
Applications importing them directly must use the replacements above. The
exported `mcp_agent_template.agent` builders, bundle, spec, MCP client builder and
`RunContext` keep their imports and signatures.

Tests that exercised obsolete paths now exercise the active policy and real
builders: tool decision trimming, preservation of IDs, execution serialization,
child sequential/parallel/integer capacity, regular tools bypassing child gates,
custom concurrency, invalid modes, and absence of legacy planning directives over successive turns.
Synchronization uses events rather than timing sleeps.

## Planning removal and remaining candidates

The subsequent todo addition provides structured per-invocation checklist state
through `AgentTodoMiddleware`. It does not restore the legacy directives below.
See [todo tracking](../agent-prompts.md#todo-tracking) for its current contract.

At the user's request, `PlanningMiddleware`, `make_skill_planner_hook()`,
`make_delegation_hook()` and their unused `_current_turn()` helper were removed.
Both builders now construct the native graph without a planning directive.
The internal factory no longer accepts `directive`, new build definitions omit
`planning_directive`, and the planning name is no longer reserved. Skills remain
in the system-prompt catalog with `list_skills` and `load_skill` tools; child
agents remain available through `ask_<name>` tools. First-call skill/delegation
instructions are no longer injected. The model decides whether to use these
tools from the normal prompt, descriptions and caller-supplied instructions.

Historical recordings can still contain planning events/definition fields.
The dashboard retains their interpretation and shows a planning disclosure only
when an old definition actually supplies one.

At the planning-removal snapshot, only planning was removed. The later request
wrapper consolidation is recorded below. Other possibilities have different
tradeoffs:

| Candidate | What permits removal | Recommendation |
| --- | --- | --- |
| `RequestObservationMiddleware` | Its sole identity wrapper duplicated preparation at effective dispatch. | Completed: allocation and reservation now occur together at effective dispatch. Real graph regressions cover retries, concurrent roots/handlers, budget rejection and cancellation. |
| `_ToolCallMiddleware` | Used only for callable `AgentSpec.concurrency`. | Remove only if dropping custom concurrency wrappers from that public option, or replace it with an equivalent native extension adapter. |
| `ChildConcurrencyMiddleware` | Only needed for explicit per-parent child limits when parallel tool execution is enabled. Global sequential mode and `"parallel"` already omit it. | Remove only if abandoning child-specific scheduling limits; keeping it costs no extra stack entry in modes that do not use it. |
| `ObservationMiddleware`, `EffectiveRequestMiddleware`, `MCPObservationMiddleware` | Removing each discards its round/tool, final-request, or server-boundary recording respectively. Native callbacks do not capture every one of those boundaries. | Product choices about logging detail, rather than unused-code removals. Retain them while those inspection features are wanted. |
| `RunLifecycleMiddleware`, `ToolExecutionMiddleware`, `ToolRoundPolicyMiddleware` | These own fresh contexts, budgets, tool ordering/capacity and exact round limits. Their responsibilities could be combined into fewer classes without dropping behavior. | Retain the protections; merging classes is a separate refactor. |
| `CloseObservationsOnShutdown` | HTTP shutdown must still drain admitted recorder data. | Retain; raw removal would weaken shutdown durability. |

An ignored synthetic probe compared the shipped stack with a temporary factory
filter excluding `RequestObservationMiddleware`. In both cases, an application
wrapper dispatched two concurrent handlers in one model round: two distinct
attempt IDs joined to both native `model.started` and `model.finished` records,
with zero recorder errors. This supports the recommendation for the current
stack, but is not regression coverage for all retry, budget-failure or external
extension behavior. That historical shipped stack still contained the request
wrapper; the current implementation removes it with regression coverage.

## Validation

Normal offline `uv sync --extra dev --offline` could not fetch the existing
corporate Git dependency. No package metadata, corporate index, provider
reference or dependency constraint was changed.

Local validation uses the existing dependency cache, process-local `PYTHONPATH`
overlays, and the package's separate uv Python 3.12.12 environment. FastMCP
4.0.10 and LangChain core 1.6.5 in that cache are below the declared floors
4.0.11 and 1.6.10. Results from this environment are local regression evidence;
validation of the fully resolved corporate environment remains pending.

From the agent package directory, with the ignored cache-overlay runner:

| Command | Result |
| --- | --- |
| `uv run --no-sync python .mcp_agent_template/validation/run.py pytest tests/test_react_agent.py tests/test_middleware.py tests/test_multi_agent.py -q --tb=short` | 38 passed after planning removal; existing LangChain MCP beta warning. |
| `uv run --no-sync python .mcp_agent_template/validation/run.py pytest tests dashboard/tests -q --tb=short` | 154 passed after planning removal; existing LangChain MCP beta warning. Four tests of the removed delegation hook were retired. |
| `uv run --no-sync python .mcp_agent_template/validation/run.py ruff check .` | Passed. |
| `uv run --no-sync python .mcp_agent_template/validation/run.py ruff format --check .` | Passed; 93 files already formatted. |
| `uv run --no-sync python .mcp_agent_template/validation/run.py build` (`uv build --offline --no-build-isolation` with the same cached dependencies) | Wheel and source distribution built. |
| Isolated uv environment, local wheel installed with `uv pip install --offline --no-deps`, source-free imports using the same dependency overlays | All package and agent public exports imported from the installed wheel. Obsolete helpers absent. Both distributions exclude `.env`, credentials, `.mcp_agent_template`, environments and recording files. |
| `node --check dashboard/static/request.js` | Passed after making the historical planning disclosure conditional. |

No authenticated provider calls or paid live tests are part of this cleanup.

At the user's request, development moved from the earlier branch worktree into
the separate managed `planning-middleware-removal` worktree with detached HEAD.
The nine changed files had identical normalized contents after transfer. The
full suite ran before transfer; lint, formatting, JavaScript syntax, builds,
installed-wheel exports and the request-identity probe also ran in the new
worktree. No further development branch was created.

## Standards — initial cleanup review

No Standards findings.

The diff follows the root and package `AGENTS.md`: it preserves exported builders,
corporate configuration and dependency metadata, keeps the cleanup within Data
Package Agent, documents intentionally removed helpers and their replacements,
and replaces obsolete-helper tests with active middleware and builder coverage.
The new concurrency tests use deterministic events.

No actionable baseline code smells introduced by the diff. Validation against
fully resolved corporate dependencies remains pending, accurately disclosed in
the inventory.

## Spec — initial cleanup review

No Spec findings.

The change satisfies "Review the middleware and list the all their usage": the
inventory covers every active middleware class, registration path, condition,
responsibility, and removed helper across the suite.

It satisfies "Remove the not necessary middleware": base-commit references
confirm deleted helpers had no production callers. The active policy, recording,
lifecycle, child-capacity, and callable concurrency paths remain. Planning is
omitted when no directive exists, with builder regressions covering that behavior.

"Create a new branch for the development" is satisfied by
`codex/middleware-review-cleanup`.

No missing requested requirement, incorrect implementation, or scope creep
identified. Declared corporate dependency compatibility remains explicitly
unverified; local cached-environment checks are described with their version
limitations.

Both independent reviews evaluated the implementation commit `f4a7321` against
`22d9554f4c70c3caee146c9a4a746072b8299f78`. Standards: 0 findings, no worst issue.
Spec: 0 findings, no worst issue.

## Standards — planning removal

No Standards findings.

The diff follows root and package guidance: corporate configuration and
dependency metadata remain unchanged; removals stay within the requested
planning behavior; documented public agent exports are preserved; intentionally
removed helper imports and changed behavior have migration guidance. Regression
coverage exercises both builders, successive turns, retained skill and child
tools, and absence of injected planning events. Historical dashboard
interpretation remains intact.

No actionable baseline code smells introduced. Validation against fully resolved
corporate dependencies remains pending and is accurately disclosed.

## Spec — planning removal

No Spec findings.

The diff fulfills "remove the planningmiddleware first": the class,
registration, directive builders and stale hooks are removed. Skills and
child-agent tools remain available; no other active middleware is removed.
Current documentation describes the behavior change, and dashboard handling
preserves historical planning records.

The recommendations answer "what are other middleware that could be removed"
with explicit tradeoffs. `RequestObservationMiddleware` is identified as the
next candidate, with incomplete failure/retry coverage disclosed. The change is
in the separate detached worktree requested by the user.

Both follow-up reviews evaluated implementation commit `40befbb` against
`e1b7d65fe99c9b0d9aa49e0e37509a2b9c508eaf`. Standards: 0 findings, no worst issue.
Spec: 0 findings, no worst issue.
