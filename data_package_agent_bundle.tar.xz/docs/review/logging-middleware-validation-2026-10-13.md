# Python 3.12, SQLite logging and middleware validation

Date: 2026-10-13.
Target: P:/Alan/Github/Data-Package-Agent.
Donor: mcp_agent_template donor,
commit 782b3c03af3585458a555b958fe91dc7de821824.

## Implemented scope

- Python minimum >=3.12, .python-version selecting 3.12, Ruff target py312.
- mcp_agent_template SQLite schema/writer, credential redaction, local OpenTelemetry,
  callbacks, model/tool capture and read-only inspection/export commands.
- Automatic scoped recording for bundle invocations and notebook streams;
  explicit reusable recording for CLI/server and embedding applications.
- A shared native graph factory and named middleware for current-turn planning,
  exact round limits, invocation-owned ordering, shared model/tool budgets,
  root deadlines, capture and caller extensions.
- Parent/child correlation with inherited callbacks and usage counted once.
- FastMCP tool-boundary request/result recording.
- Explicit non-keep-alive stdio transport, owned HTTP helper and graceful
  shutdown/flush behavior.
- Application-root paths, observation configuration and subprocess propagation.
- Missing README restored; absent bundled-skill tests now use temporary fixtures.

No provider logic, corporate index, internal URL/reference or provider default
was migrated from mcp_agent_template. Repository formatting was normalized, including
formatting-only changes in the existing adapter source. The provider contract
tests were retained and passed.

Later plan items remain outside this change: workspace/process tools, full
context compaction, persistent recovery, profile delegation, scoped memory,
shared skill discovery cache, dashboard and the evaluation application.

## Reuse and integration decisions

The observability directory, logging_utils.py, serve.py and MCP entrypoint reuse
mcp_agent_template implementations. Formatting follows this repository's existing Ruff
rules. Model/tool descriptor helpers were extracted from mcp_agent_template composition
without importing its complete delegation/persistence stack.

The recording runtime excludes donor persistence/process-session integration.
Its native interrupt results remain available. Budget/context/middleware
mechanisms were adapted to the existing nested AgentSpec / ask_<name> interface.
The corporate MCPAdapter and httpx2 timeout behavior remain in use.

Testing found duplicate inherited model callbacks in nested calls. The child
tool now exposes RunnableConfig in the exact type recognized by native tool
configuration injection; callbacks are reused, and repeated native model-start
delivery to the same observer is guarded. Parent totals now count the child's
native model call and reported usage once.

The original stdio transport default kept subprocesses alive between sessions.
The client now uses mcp_agent_template's explicit StdioTransport(keep_alive=False) policy.
A regression test checks that both discovery and calls close their recording
processes on a continuing event loop.

## Validation environment and limitations

Normal installation was attempted with the unchanged corporate configuration:

~~~powershell
uv sync --extra dev
uv pip install --python .venv/Scripts/python.exe --offline --default-index <configured-corporate-index> -e '.[dev]'
uv pip install --python .venv/Scripts/python.exe --default-index <configured-corporate-index> -e '.[dev]'
~~~

Results:

- uv selected CPython 3.12.12 and created .venv.
- uv sync could not resolve the corporate Git hostname for an existing optional
  GenAI dependency.
- The online install also failed DNS resolution for the corporate package index.
- Offline resolution lacked cached packages meeting the declared constraints.
- No uv.lock was produced and no index, internal reference, or dependency floor
  was lowered to bypass these failures.

Local validation used the Python 3.12 interpreter with process-local PYTHONPATH
entries pointing to already available cached compatible binaries/pure packages
and the donor's installed packages. This was a validation environment only;
these paths are not product configuration or committed runtime setup.

| Package | Local validation version |
| --- | --- |
| Python | 3.12.12 |
| FastMCP | 4.0.10 |
| LangChain | 1.4.2 |
| langchain-core | 1.6.5 |
| LangGraph | 1.2.12 |
| OpenTelemetry SDK | 1.45.0 |
| pytest | 9.1.1 |
| pytest-asyncio | 1.4.0 |
| Ruff | 0.16.9 |
| Hatchling | 1.32.4 |

FastMCP and langchain-core in this cache are below the target's declared minimums
(4.0.11 and 1.6.10). Passing cached-environment tests therefore does not establish
validation against a fully resolved target environment. Retry normal uv sync,
the full test suite and build after corporate access is restored.

No authenticated corporate-provider calls were made. Provider unit contracts
and real local MCP transports were tested; live provider/request coverage
remains an explicit validation gap.

## Final checks

With the local validation environment described above:

~~~powershell
.venv/Scripts/python.exe -m pytest -q
ruff check .
ruff format --check .
uv build --offline --no-build-isolation --python .venv/Scripts/python.exe
~~~

- Full suite: **119 passed** on Python 3.12.12.
- Ruff: all checks and repository formatting checks passed.
- Build: source distribution and wheel succeeded using cached build dependencies.
- Wheel metadata requires Python >=3.12 and includes the observability modules.
- The source distribution includes README.md; diagnostic files, .env and .venv
  were verified absent from both distributions.
- All 52 runtime source modules passed the Python 3.12 grammar check.
- The existing corporate index and socgenai_llm Git revision were verified intact.
- Existing LangChain MCPAdapter emits its beta warning; no test failed because of it.

Coverage includes real stdio/HTTP MCP operations, actual handler-output redaction,
lossless large payload recording, SQLite schema conflict, writer failure, partial
startup, repeated cancellation, metric-flush failure, stream early closure,
independent concurrent roots, shared child usage, exact budgets, namespace checks,
custom middleware capture, notebook ownership, typed observation configuration,
subprocess setting propagation and process shutdown/reaping.

## Inspected smoke recording

A scripted native model invoked the real stdio MCP add tool with 2 and 3,
received its actual result and returned 5. This is a local transport/recording
smoke test, not an authenticated model invocation.

- Run ID: c25cdf75-8df6-4c56-889e-0533f1975def.
- SQLite: .mcp_agent_template/validation/logging-middleware-e1ec4921/records/observability.sqlite3.
- Exports/evidence: run.json, validation.json and doctor.json in that run directory.
- Retained rows: 3 processes, 1 run, 62 events, 9 logs, 23 captures,
  22 spans and 8 metric collections.
- Native usage: 2 model calls, 8 input tokens and 4 output tokens, both calls
  reporting usage; no duplicate child/native accounting.
- Recording health: complete, no recording errors.
- All three recorder processes were stopped and healthy, with zero unrecorded
  observations. No unknown runs remained.
- SQLite integrity check: ok; WAL bytes after shutdown: 0.
- Synthetic credentials were absent from the export and replaced in console output.
- Server arguments/results, client tool output, model request/response, usage,
  final state, log rows, spans and metrics were inspected after flush/shutdown.

Complete diagnostic artifacts are retained under ignored .mcp_agent_template; no automatic
deletion or payload truncation was added. The usage guide is
[docs/observability.md](../observability.md).
