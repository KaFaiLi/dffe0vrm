# PnL simplification — 23 October 2026

Work started from clean `main` at
`0ec42c0cf3d47191e499c2f539bb36933482c5ea` in the new
`codex/simplify-pnl-analysis` worktree. The supplied analysis-refactoring guideline
and the package's maintained PnL and visualization contracts guided the change.

## Contract inventory

| Area | Preserved behavior |
| --- | --- |
| Interfaces | Six source-path runner/MCP arguments; keyword-only runner `output_dir`; Markdown return; removed review dates remain rejected. Existing preparation/workbook imports remain available. |
| Population | Full-source hierarchy; PnL date/PC/GOP/PTF duplicates and attribution date/full-hierarchy duplicates exclude every copy. Invalid constituents leave identifiable PC dates unknown. Raw duplicate comparison and trimmed PC aggregation remain distinct. |
| Calculations | Independent PnL/attribution dates; Decimal sums; floating PnL statistics; population z-score equality; reversal criteria; GOP netting before driver gross amounts; source-order driver ties and unknown denominators. |
| Controls | All adjustments in EUR, creation-date calendar plus supplied PnL dates, exact repeated-entry comparison; all validation rows and exact state labels, with DEValidated a subset of not Validated. |
| Identity | Source locators are evidence, not unique business keys. All constituent references survive; summary, issue and detail order remain unchanged. |
| Reports | Original headings, display limits, worksheet order/names, fields, precision and unknowns; complete commentary; literal Excel text and continuation rows; same filenames, output locations, chart scopes and publication staging. |
| Side effects | Sources remain read-only. The new in-memory entry point reads no settings/files/clock and does not mutate inputs; renderers do not mutate results. Existing stage functions still populate the supplied Review. |

## Smallest useful changes

- Reuse `Review`, adding `pnl_daily` to retain the already calculated chart
  records and their full constituent references. No second result container.
- Extract `analyze_pnl` inside `runners.py`. The runner keeps file loading,
  source manifests, commentary, settings and artifact publication.
- Move `prepare` beside source loading and duplicate handling, retaining the
  original `calculations.prepare` import.
- Move workbook formatting into sibling `excel.py`, retaining the original
  `reporting` imports. Markdown remains in `reporting.py`; neither writer adds
  analytical rules. In-memory Markdown accepts absent file evidence.

PnL, attribution, adjustment and validation calculations remain cohesive in
their existing modules. No framework, registry, new directory or methodology
change was introduced. The chart-ready records and workbook projection already
existed; the result now carries both for their existing consumers.

## Preservation evidence

Before editing production code, two synthetic six-file datasets were captured:
ordinary 40-date data and edge cases with duplicates, invalid dates/amounts,
incomplete PC dates, multiple PCs/GOPs, fractional values, opposite extremes,
tied drivers, blank drivers, repeated adjustments, original validation labels,
long literal text and XML-incompatible controls.

After refactoring, comparisons matched every original Review field and table
order, worksheet cell value/type/style/number format, worksheet widths/filters/
freeze panes, complete Markdown, chart metadata, plotted line values and labels.
Only the two generated artifact paths were omitted from Markdown comparison.
Workbook ZIP timestamps were not compared; worksheet contents and formatting
were compared explicitly. Source file hashes stayed unchanged. The new
`pnl_daily` field was excluded from the old-field comparison and tested directly.
The comparison script and snapshots are retained under the worktree's ignored
`artifacts/pnl_baseline.py` and `artifacts/pnl-preservation/` paths.

Validation uses the package's documented isolated uv Python 3.12 environment,
including the local `langchain-core==1.6.10` override. Production pins, the
corporate index, package metadata and the suite environment are unchanged.

- Before refactoring: 119 focused analysis/chart/MCP tests passed.
- New in-memory and renderer regressions: 7 passed, including z-score equality,
  repeated source locators, unknown populations, non-mutation on success/error,
  full commentary, exact workbook amounts and compatibility re-exports.
- Combined analysis, chart, PnL/risk MCP, server, fixture-order and structured
  report-evidence suite: **332 passed** in 185.30 seconds, including the seven
  new regressions. The existing LangChain MCP beta warning remains.
- Package-wide Ruff lint and format checks, plus `git diff --check`, passed.
- Wheel and source distribution built using the cached public build tooling.
  Both archives include `excel.py` and exclude local credential files.
- A fresh uv environment outside the checkout installed the rebuilt wheel.
  All 90 installed package Python files matched the wheel bytes. With the
  isolated local environment providing dependencies only, installed imports,
  compatibility exports, in-memory analysis and the six-file runner passed;
  the latter wrote Markdown, a workbook, an evidence manifest and a real PNG.
  The verification script is retained in `artifacts/verify_pnl_wheel.py`.

Commands run from `packages/data-package-agent/`:

```powershell
$agentUv = @('run', '--project', '../../artifacts/foundry-agent', '--locked', '--python', '3.12')
uv @agentUv python -m pytest -c pyproject.toml tests/analysis `
    tests/test_pnl_mcp.py tests/test_risk_metrics_mcp.py tests/test_mcp_server.py `
    tests/test_analysis_fixture_collection.py tests/test_review_reporting.py `
    -q --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv ruff check .
uv @agentUv ruff format --check .
git diff --check
uv build --python 3.12 --no-sources --default-index https://pypi.org/simple --offline
```

The build's command-line index selects cached public build dependencies only;
it does not change corporate configuration. The original `main` checkout
remained clean at the baseline commit.

## Pre-commit review

Independent standards and guideline reviews examined the complete staged diff
against `0ec42c0`. Standards: **0 actionable findings**. Guideline/specification:
**0 actionable findings**. The reviews covered compatibility imports, numerical
population and ordering rules, serialization, result ownership, flat module
responsibilities and unnecessary abstractions. The guideline reviewer also
verified that both retained before/after snapshot pairs have identical hashes.
No code fixes were needed, so the validation above applies to the reviewed code.
The fetched PR base `origin/main` still matched the baseline; no unrelated commits
were included.

No live model calls were made. Synthetic checks do not establish corporate
dependency, identity, proxy, shared-drive or Azure acceptance; those remain
unverified. Hosted CI was not run.
