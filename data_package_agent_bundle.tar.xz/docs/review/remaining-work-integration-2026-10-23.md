# Remaining branch and worktree review — 2026-10-23

The review used `main` at `8b12cbf` as its fixed baseline. Every remaining local
branch, the closed remote PR #15 branch, and all six secondary worktrees were
inspected before selecting changes. Independent standards and specification
reviews found no remaining actionable issues in the accepted integration.

## Integrated changes

- `16a48d6` registers the existing opt-in analysis fixtures through a test plugin.
  The previous directory-local registration could lose `captured_charts` when
  pytest file arguments interleaved analysis and parent-directory MCP tests.
  The original ordering failed with one passed test and one missing-fixture
  error. All six file-order permutations now pass.
- `db1d1c6` merges `codex/risk-commentary-reporting` (`0d92354`) while retaining
  the current notebook helper, PnL section bindings, post-trade tools and file
  discovery. Complete risk commentary is supplied as literal source text;
  numerical references use SGMR/Colibris IDs with record-number fallbacks.
  The workbook has eight numerical evidence sheets. See the
  [risk interface and migration contract](../skills.md#risk-metrics-analysis).
- A combined-report regression uses the actual PnL and risk runners to verify
  that PnL numerical citations and literal risk-commentary citations retain
  independent source ownership. Embedded filenames, headings and fences in
  commentary do not become numerical evidence.

## Reviewed material not reapplied

| Source | Disposition |
| --- | --- |
| `codex/open-pr-live-review` (`afdaca4`) | Every non-merge commit is patch-equivalent to a change already on main. |
| `codex/review-prs-13-14` (`d356066`) | Every non-merge commit is patch-equivalent to an existing change. |
| `codex/review-pr22-pr23` (`909b128`) | Historical integration merges; the originating fixes are already present. |
| `codex/review-open-prs-integration` (`504007f`) | Probe sampling, tool-catalog checks and historical documentation are already represented in current code and tests. |
| Closed PR #15, `codex/mcp-template-skills-test-layout` (`2f28e54`) | Superseded by current application-folder skills and `devtools/tests/foundry/data_package_agent/`. Reapplying its older paths and analyses would regress the current layout. |
| Dirty `middleware-review` | Planning-middleware removal, historical dashboard handling and builder coverage are already present, with newer todo and request middleware retained. |
| Dirty `812e` and `market-activity-review` CSV copies | Identical local edits replace 4,524 FO and 4,524 MPC labels with synthetic unmapped labels. Keep the user-selected FO/MPC baseline. |
| Dirty PnL plans and the older audit checklist | Superseded proposals restore removed cumulative, mapping and commentary-analysis rules. Keep the maintained contracts. |
| `812e` untracked audit guide and source notes | Byte-identical copies of documents already tracked on main. |

## Verification

Validation used the isolated uv Python 3.12 environment and the documented local
`langchain-core==1.6.10` override. Production dependency pins, corporate indexes
and the manager/wrapper environment were unchanged.

- Full agent and dashboard suite: **717 tests and 4 subtests passed**.
- Separate mocked Foundry suite: **47 tests passed**.
- Focused risk, chart, MCP, notebook and evidence tests: **193 passed**;
  the additional combined-catalog regression also passed.
- The fixture-order regression passed all six permutations on the integrated
  checkout. It runs only two selected numerical tests in each subprocess.
- Package-wide Ruff lint/format checks, changed development helper checks and
  `git diff --check` passed.
- Wheel and source distribution builds passed. Archive inspection verified the
  fixture-plugin source layout and exclusions for local/development artifacts.
- An isolated installed wheel outside the checkout passed public-export checks
  and generated a synthetic risk report with source IDs, complete commentary,
  eight workbook sheets and actual PNG files.

The existing LangChain MCP beta warning remains. No paid provider calls were
made. Corporate dependency, identity, proxy, shared-drive and Azure acceptance
remain unverified.

## Recovery

Before cleanup, a verified Git bundle retained all branch references. Each old
worktree's tracked edits, untracked files and non-recreatable ignored artifacts
were saved with checksums and a binary patch. Generated environments and caches
are excluded from those file snapshots. The local recovery bundle, snapshots,
per-source decisions and test XML live under the suite's ignored
`artifacts/remaining-work-review-d1db205a79184b5599cf57d451483c05/` directory.
Historical verification records retain their original dates and limitations.
