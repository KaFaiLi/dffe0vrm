# Context tools removal and validation

Date: **2026-10-14**. Branch: `codex/remove-context-lab`.

## Change and migration

The context inspection package, its three diagnostic MCP tools, and their unit
tests were removed. At this branch's original validation point, the bundled server
exposed `ping`, `server_time`, `add`, and `search_items`. The integrated analytical
skills additionally register four analysis tools, `read_analysis_result`, and
`reopen_analysis_evidence`, giving ten MCP tools. Agent skill tools remain available
through their existing registration path. The original measurements below retain
their historical scope.

Imports from `mcp_agent_template.context_lab` and calls to `estimate_token_cost`,
`inspect_payload`, or `generate_filler` must be removed from downstream code.
No compatibility aliases retain those removed capabilities.

The notebook's `tool_catalog(tools)` keeps its signature and metadata table,
including HTML escaping, but no longer displays lint scores or warnings.
The unused `tokens` installation extra and the explicit `tiktoken` dependency
in `all` were removed. Corporate indexes, provider extras and references,
runtime dependencies, Python requirements, and pytest/Ruff settings are unchanged.

Historical migration plans and recorded inventories retain their original
measurements with notes identifying the removed diagnostics and superseded
token/lint proposals. Earlier seven-tool live evidence describes earlier code.

## Verification

From `packages/data-package-agent/`, use the isolated Python 3.12 uv environment
documented in [package guidance](../../AGENTS.md#authorized-local-live-test):

```powershell
uv @agentUv python -m pytest -c pyproject.toml tests dashboard/tests -q `
    --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv ruff check .
uv @agentUv ruff format --check .
uv build --no-config --default-index https://pypi.org/simple --no-sources
```

- Full agent/dashboard suite: **251 passed**, plus **4 subtests passed**.
  The existing LangChain MCP beta warning remains.
- Focused probe, HTTP/stdio MCP, and notebook suite: **27 passed**.
- Package Ruff lint and formatting checks passed; `git diff --check` passed.
- Wheel and source distribution built successfully. Archive inspection found
  none of the removed modules or their unit-test file.
- The wheel was installed into a separate uv environment outside the checkout.
  Imports resolved from the installed package; the removed context package was
  unavailable. A scripted model drove the real agent graph and MCP subprocess
  through `add(19, 23)`, and the final answer was `42`.

The offline Azure probe regressions exercise the real SDK, manager, agent graph,
and MCP subprocess with synthetic SSE over MockTransport. They verify the
remaining MCP tools plus the three skill tools are sent to the model, successful
single and parallel addition, unchanged encrypted usage/cost auditing, and
original HTTP 429 behavior without retries.

The tested editable environment used Python 3.12.12, agent 0.1.0, manager 0.4.0,
LangChain 1.4.5, langchain-core 1.6.10, LangGraph 1.2.15, FastMCP 4.1.0, and
OpenAI 3.24.0. Public dependencies were resolved in the documented isolated
environment. The agent still has no corporate lockfile pending corporate
resolution; it is outside the suite lockfile's dependency graph.

No billable model calls or corporate Azure acceptance were run. These results
verify offline execution and installed packaging, not live provider compatibility
or corporate identity, proxy, and shared-drive integration.
