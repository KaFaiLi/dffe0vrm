# Post-trade structure validation — 2026-10-23

Historical evidence for the refactor implemented on 22 October 2026 in
`codex/post-trade-design`, using suite commit `0b65c80` as the comparison
baseline, and its 23 October follow-up. Extracted from the structure guide;
these comparisons and commands describe that validation, not checks rerun for
the documentation cleanup. See the [current structure guide](../post-trade-analysis.md)
and [development setup](../../README.md) for ongoing work.

## Recorded verification


The pre-refactor source was retained in ignored development artifacts and
compared at a fixed snapshot against the implementation. Both the existing
280-row synthetic Parquet dataset and a 142-row synthetic edge-case dataset
produced identical existing case columns, duplicate disclosures, all eleven
original summary tables, ordered queues and Markdown. Every workbook ZIP member
also matched byte-for-byte except `docProps/core.xml`, which contains generated
document timestamps and was excluded. This verifies the selected synthetic
populations, not every possible input or live/corporate compatibility.

The focused regression suite covers analysis, attribution, both report
interfaces, non-mutation, explicit snapshots, queue identity after reindexing,
real MCP stdio/HTTP calls, concurrent reports, errors and observability. The PR
is based directly on published `main`; unrelated PnL/file-discovery changes and
their tool-catalog expectations are outside this change.

The follow-up review on 23 October removed queue reconstruction and added
regressions for caller-supplied queue frames and source row IDs. Validation uses
Python 3.12.12 with the documented local `langchain-core==1.6.10` override;
production dependency pins were not changed.

Use the isolated Python 3.12+ uv environment documented in the package's
`AGENTS.md`; keep it separate from the suite environment and corporate pins:

```powershell
$agentUv = @('run', '--project', '../../artifacts/foundry-agent', '--locked', '--python', '3.12')
uv @agentUv python -m pytest -c pyproject.toml `
    tests/analysis/test_fox_analysis.py tests/analysis/test_hit_search_analysis.py `
    tests/analysis/test_fox_pipeline.py tests/test_post_trade_review_mcp.py `
    tests/test_mcp_server.py tests/test_serve.py tests/test_observability.py `
    -q --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv ruff check .
uv @agentUv ruff format --check .
uv build --python 3.12 --no-sources --default-index https://pypi.org/simple --offline
```

The build command selects the local public dependency cache for build tooling;
it does not edit the configured corporate index or package metadata. Wheel and
source archives were inspected, and wheel imports plus synthetic analysis were
checked from an isolated environment outside the source checkout. No live LLM,
corporate identity, network-share or provider acceptance was exercised.
