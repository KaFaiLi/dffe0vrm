# Risk-metrics demo inputs and live check — 2026-10-17

The five supplied risk-metrics demo inputs are now tracked under
`devtools/test_source/risk_metrics/` and `devtools/test_source/risk_commentary/`.
The development runner adds `--agent-case risk-metrics`, following the existing
PnL and post-trade skill/agent/MCP review pattern. Production analysis, provider
configuration, dependency pins and encryption are unchanged.

The first authorized live attempt **did not complete**: the provider returned
HTTP 503 on the first model request. There was no retry, mode change or fallback.
No live agent interpretation or live analysis workbook was produced. The complete
five-source deterministic preflight and offline mocked agent/MCP checks succeeded
separately; these results must not be described as a successful live agent review.

## Inputs and deterministic preflight

The supplied baseline contains 12,528 SGMR observations across 48 series and 261
dates from 2025-07-01 to 2026-06-30, 50 selected Colibris events, and 160 quarterly
commentary records (53 risk metrics, 53 stress tests and 54 VaR/SVaR).

The public `run_risk_metrics_analysis` runner processed all five original paths
and produced the returned Markdown and a nine-sheet workbook. The full run and
independent readback of every sheet took 74.625 seconds locally. SHA-256 checks
confirmed that all five original files remained unchanged.

The workbook contains 12,528 SGMR detail rows, 288 series/period review rows,
50 excess rows, 175 commentary rows including retained background text, 210
reconciliation rows and 80 review candidates. Numeric summary observations include:

- Three absolute-bound exceedances, one breach episode and two changed-limit series.
- Three metric-outlier candidates, two large metric changes, one volatility-regime
  change and one repeated-warning-proximity candidate.
- Seven events recorded open and fourteen open-event/recorded-deadline candidates.
- Six commentary records with pending validation and fifteen repeated-wording groups.
- Zero confirmed Colibris/SGMR observation links; all fifty event links remain unresolved.

These are calculated screens over the supplied sources, not approved materiality,
SLA or control-failure conclusions. Selected Colibris events cannot establish daily
breach frequency. Source IDs, labels, metric types and directional bounds remain
separate, and commentary proximity cannot establish resolution or lineage. There is
no seeded held-out answer key for this baseline, so these counts do not measure
analytical accuracy or a false-positive rate.

Preflight evidence remains ignored under
`artifacts/risk-metrics-preflight/ae44970daef244afb976f2bd1ed61fa4/`:
`preflight.json` and the `2a6c95d3c88a452c828be921713d0b0c/` Markdown/workbook pair.

## Live attempt and measurement boundaries

Command from the suite root:

~~~powershell
uv run --project artifacts/foundry-agent --locked --no-sync --python 3.12 python devtools/foundry_lab/run.py --operation data-package-agent --agent-case risk-metrics --model gpt-6-luna --config packages/genai-api-manager/local_dev.json --pricing MODELS_PRICE1K_AZURE.json --run-live
~~~

The runner copied exactly five input files and the application `risk-metrics`
skill into a new run directory. The fixed prompt requested a completed evidence-based
review, without giving the preflight results or any answer key. It required loading
the skill, reading both references, calling the real five-path MCP tool once and
returning the actual Markdown/workbook paths.

The real sibling `socgenai_llm` provider used Azure v1 Responses through the sibling
manager's internal streaming route, with `reasoning.effort="max"`,
`reasoning.summary="detailed"`, omitted sampling/output-token limits and zero SDK
retries. The model was priced before dispatch. Limits were twelve model requests,
twelve tool calls, 45 seconds per SDK request, 180 seconds per tool, a 360-second
agent deadline and a 390-second outer deadline. The EUR 5 recorded-cost threshold
remains post-response accounting rather than a hard spending cap.

The attempt stopped after 13.563 seconds with sanitized error metadata
`InternalServerError`, HTTP 503. One dispatch was attempted; no completed provider
response, token usage, reasoning summary or calculated charge was available.
Those measurements are unknown, not zero. The logger accepted/wrote zero events,
reported zero drops/write/enqueue errors, drained its queue and closed. Its zero
recorded ledger is not evidence that the provider billed nothing. Audit
usage/cost verification could not pass because no provider response was received.

All five source and copied-input hashes remained unchanged. The failed run is
`c071afa0485e496da355973b232ef8de`; its safe `summary.json`, fixed prompt and copied
inputs remain under ignored `devtools/foundry_lab/output/`. Raw provider errors,
credentials and endpoint URLs are not included in the validation report.

The isolated runtime used Python 3.12+, agent 0.1.0, manager 0.4.0,
socgenai-llm 2.5.0, langchain-core 1.6.10 and OpenAI SDK 3.24.0. The local core
override is separate from production pins and corporate dependency resolution.

## Offline verification

Eleven focused risk/PnL development regressions passed. Risk coverage exercises
the actual agent and MCP subprocess against synthetic Azure JSON and SSE over
mocked HTTP, including both Responses transports, the mandatory live gate,
unpriced-model rejection, missing-source rejection, one-attempt HTTP 429 behavior,
all-five-input verification and rejection of a workflow missing the methodology
reference. Successful mocked cases verify returned/saved Markdown equality, both
artifact paths, unchanged inputs and matching encrypted audit usage/cost/ledger.
The PnL regressions also exercise the extracted shared audit verifier.

The final broader checks passed separately in their required environments:

- **42 isolated Foundry development tests**, including those eleven focused cases,
  using `devtools/tests/foundry/data_package_agent/pytest.ini`.
- **73 risk-metrics package tests**, including the actual MCP transport and the
  directional-bound approval regressions, with the loopback-only socket allowlist.
- **14 root offline portable-bundle/test-path regressions** using the suite's
  `--offline` profile. These preserve the corporate-test and development-data boundary.

Changed development Python files passed Ruff lint and formatting checks, and
`git diff --check` passed. No corporate identity, proxy, shared-drive access,
corporate dependency resolution, provider billing or corporate live acceptance
is established by these local checks.
