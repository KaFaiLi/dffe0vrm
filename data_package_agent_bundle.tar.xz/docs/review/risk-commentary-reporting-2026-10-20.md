# Risk commentary and source references — 2026-10-20

Implemented on `codex/risk-commentary-reporting` in its own managed worktree.

## Behavior

The existing five-path Python/MCP interface is retained. SGMR and Colibris still
receive the numerical, workflow and identifier-based reconciliation checks.
Commentary Markdown is supplied in full as literal source blocks for direct agent
review, with UTF-8/BOM handling and normalized line endings. Its records are not
parsed, counted, deduplicated or automatically matched. Arbitrary Markdown,
embedded code fences and long source text are retained as evidence.

Risk Markdown and Excel no longer include source hashes. Chart references and
evidence rows use the source filename plus SGMR `id` or Colibris `excessId`.
Missing or repeated IDs retain a one-based record number to keep observations
distinct. Internal integrity checks and encrypted audit behavior are unchanged.
Consolidated report citations use report/line numbers; their catalog keys remain
internal. Complete commentary source blocks can be cited without reassigning
embedded references to another source.

The workbook now has eight sheets. The former Commentary Review sheet,
commentary summary measures and commentary reconciliation rows are removed.
The current contract and migration notes are in [the skill guide](../skills.md#risk-metrics-analysis).

## Verification

- Risk analysis regressions: 75 passed.
- Mocked real-agent/MCP risk probes: 8 passed, covering both Responses transports,
  complete commentary delivery, mandatory live gates and error handling.
- Full agent/dashboard run: 620 passed and four subtests passed; one existing
  chart assertion still expected an absolute path. It was updated for the
  requested filename/ID reference format. The complete chart file then passed
  all 17 tests. No unresolved test failures remain; the full suite was not
  repeated after that assertion-only update.
- Package and changed development Python Ruff lint/format checks passed.
- Wheel and source distribution built using the documented public-index build
  override with offline resolution. Public imports and a synthetic risk report
  were exercised from the installed wheel in an isolated uv environment outside
  the checkout. Archive exclusion checks passed.
- The five supplied demo files were run through the actual deterministic runner.
  Their bytes were unchanged. The output retained 12,528 SGMR observations,
  three absolute-bound exceedances, two changed-limit series and 36 charts.
  The eight-sheet workbook contains 74 numerical/workflow candidates and 50
  SGMR/Colibris reconciliation rows. Complete commentary text is present in the
  returned/saved Markdown. All chart PNGs decoded and their references use IDs.

Generated demo outputs and the verification record are under ignored
`artifacts/risk-enhancement-demo/` in this worktree. The full test log and JUnit
record are under ignored `artifacts/risk-enhancement-tests.*`.

All checks used the isolated Python 3.12+ environment with the local
langchain-core 1.6.10 override. Production pins were not changed. The existing
LangChain MCP beta warning was emitted. No new paid live call was performed;
corporate dependency resolution and corporate Azure acceptance remain unverified.
