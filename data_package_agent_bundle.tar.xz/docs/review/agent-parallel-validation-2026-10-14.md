# Parallel agent prompt validation — 2026-10-14

Historical local evidence, extracted from the agent prompt guide. The usage,
runtime versions, output allowance and test counts below describe that run;
they are not current defaults or a fresh validation of this checkout. Use the
[current prompt and scheduling guide](../agent-prompts.md) and
[development setup](../../README.md) for today's workflow.


The opt-in runner's `--operation data-package-agent --agent-case parallel`
scenario passed once against the exact `gpt-6-luna` deployment, using the revised
prompt from this development checkout. The first model turn requested
`add(a=19, b=23)` and `add(a=7, b=11)` together. The real MCP tools returned 42
and 18, and the final response matched the fixed expected answer `42,18`.

Both outgoing requests carried `parallel_tool_calls=True` and the same system
prompt SHA-256, `38f5765b68445ae272a2d9bd9de3b8358f7ed0be37f1634e458aab8999d9d484`.
Passive LangChain tool callbacks recorded 2.562 and 2.781 seconds for the two
MCP tool invocations, with **2.562 seconds of overlap**. These intervals include
client/transport/server startup and tool result handling; they are not isolated
server arithmetic timings or a performance benchmark.

| Request | Input | Cache reads | Cache writes | Output | Calculated EUR |
| --- | ---: | ---: | ---: | ---: | ---: |
| Tool selection | 1,573 | 0 | 1,570 | 53 | 0.230410 |
| Final response | 1,649 | 1,570 | 76 | 6 | 0.030598 |
| Total | 3,222 | 1,570 | 1,646 | 59 | 0.261008 |

Cache reads and writes are subsets of input, not additional input tokens.
Costs use the local configured EUR prices per 1,000 tokens. Both encrypted audit
records decrypted successfully and matched reported usage, calculated costs,
and the process-local ledger. No events were dropped, no writes or enqueues
failed, the queue drained, and the writer closed. The run used at most two
model requests, two tool calls, 128 output tokens per request, and zero SDK
retries. No request was replayed.

The isolated runtime was agent 0.1.0, manager 0.4.0, LangChain 1.4.5,
langchain-core 1.6.10, LangGraph 1.2.15, FastMCP 4.1.0, and OpenAI SDK 3.24.0.
The safe run summary (`devtools/foundry_lab/output/99ef08a81c654382bff8b1fde9dc29e5/summary.json`)
and sensitive encrypted logs remain in ignored local output. This verifies one
local Foundry task and overlapping MCP invocations. It does not verify provider
billing, broad prompt quality, Responses live support, corporate identity,
proxy, gateway, or shared-drive acceptance.

This live run used commit `c5fee9c`, before integrating the subsequent builder
and telemetry simplifications from `main`. The integrated branch retains the
same assembled system-prompt hash and parallel request/execution policy. Its
combined code passed all 239 agent/dashboard tests with loopback-only sockets,
including offline agent/MCP/provider regressions, along with Ruff lint and
formatting checks. The paid live call has not been repeated after that integration.
