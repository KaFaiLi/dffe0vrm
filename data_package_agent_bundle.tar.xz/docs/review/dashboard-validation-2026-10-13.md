# SQLite dashboard integration validation

Date: 2026-10-13. Package: `private_suite/packages/data-package-agent`.

Copied the 16 tracked files from `mcp_agent_template donor/dashboard/` at commit
`782b3c03af3585458a555b958fe91dc7de821824`. The viewer is a standalone Python
stdlib application with the donor's conversation, usage, model-request, tool,
activity, trace, log, metric, and recorder-health views. Agent branding,
documentation, and Python formatting follow the destination project.

The source dashboard, agent runtime, SQLite schema, provider adapters, package
dependencies, corporate index, and test/build/lint configuration are unchanged.
The viewer's default database resolves to the agent package's
`.mcp_agent_template/observability/observability.sqlite3`. `--db`, `--port`, and the donor's
`MCP_AGENT_TEMPLATE_OBS_DB` override remain available. Connections retain `mode=ro`,
`query_only=ON`, live WAL reads, and the closed-recording immutable fallback.

## Automated checks

| Check | Result |
| --- | --- |
| `uv run --no-sync python -m unittest discover -s dashboard/tests -v` | 28 copied dashboard tests passed |
| Full agent and dashboard pytest through the ignored cached-dependency runner | 149 passed, 1 existing LangChain MCP beta warning, 35.85 seconds |
| `uv run --locked --no-sync ruff check .` from the suite root | Passed |
| `uv run --locked --no-sync ruff format --check .` from the suite root | 234 Python files formatted |
| `node --check dashboard/static/app.js` and `node --check dashboard/static/request.js` | Passed |
| Agent build using cached Hatchling and Python 3.12 with `uv build --offline --no-build-isolation` | Wheel and source distribution built |
| Archive inspection | Runtime modules and metadata preserved; dashboard excluded from wheel and included in source distribution |
| `git diff --check` | Passed |

The configured corporate dependency installation remains unavailable on this
workstation, as recorded in the [suite migration report](../../../../docs/data-package-agent-migration.md).
Agent runtime tests used the same local dependency overlays: Python 3.12.12,
FastMCP 4.0.10, langchain-core 1.6.5, LangGraph 1.2.12, pytest 9.1.1,
pytest-asyncio 1.4.0, and Hatchling 1.32.4. FastMCP and langchain-core are below
the declared minimums; compatibility with a fully resolved declared environment
remains unverified. The dashboard and its 28 standalone tests require only stdlib
Python and do not depend on that cache or corporate access.

The normal combined command, after corporate dependency resolution, is:

```powershell
uv run pytest tests dashboard/tests -q
```

New integration tests check the package default path and read a fresh database
written by the actual agent recorder. They verify conversation output, model
requests, usage reconciliation, tools, logs, process health, metrics, and spans.
They query during active recording and again after recorder shutdown, reject
database writes, and verify the closed database's SHA-256 is unchanged and no
WAL/SHM sidecars are created by inspection.

## Fresh recording and HTTP inspection

A scripted model used the actual local stdio MCP `add` tool with 2 and 3,
received the real result, and returned 5. This is a synthetic model invocation
with real local transports; no authenticated provider call was made.

- Run ID: `beec6d12-8ec3-4d9e-b9e8-abb05a4f23cb`.
- Database: `.mcp_agent_template/dashboard-validation-648136d1/records/observability.sqlite3`.
- Retained projections: 1 run, 62 events, 22 spans, 3 processes, and 8 metric points.
- Usage: 2 reported native calls, 8 input tokens, 4 output tokens; stored-summary reconciliation agrees.
- All three recorded processes stopped healthy with zero unrecorded observations.
- Read-only database SHA-256: `60cd14fac89c05946984a8992eab7b6b61ca9498b5a5beddbad45e0be645eee4`.

An actual localhost HTTP server returned successful JSON for database information,
run list/detail, conversation, usage, tools, requests, spans, logs, processes, and
metrics. The conversation retained the tool result and final 5; the completed
`add` group and both native model calls were present. Inspection left the source
database hash unchanged. The temporary HTTP server shut down and joined its thread.
The full local report is `.mcp_agent_template/validation/dashboard-smoke.json`.

## Browser and local viewer

The copied frontend rendered the fresh conversation, real tool result, final 5,
and correctly reconciled 12-token usage in the in-app browser. Browser warning
and error logs were empty. A separate viewer was opened against the package's
default SQLite database at `http://127.0.0.1:8765`, and its All logs view displayed
the actual recorded MCP server logs and selectable complete evidence.

The default database currently contains server observations without root agent
conversations. Its empty conversation list reflects the recorded data; the All
logs view works independently of agent runs. New invocations become visible
through the existing polling behavior when recorded into this database.

Local browser images are retained at
`.mcp_agent_template/validation/dashboard-preview.jpg` and
`.mcp_agent_template/validation/dashboard-logs.jpg`. The running viewer's process metadata
and stdout/stderr are retained in `.mcp_agent_template/validation/dashboard-service.*`.
It binds only to `127.0.0.1` and requires no model credentials.
