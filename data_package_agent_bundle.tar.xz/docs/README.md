# Data Package Agent documentation

Internal development documentation for the agent in `private_suite`.
Start with the [package README](../README.md) for environment setup, configuration,
MCP/Python integration and tests. [AGENTS.md](../AGENTS.md) defines contribution
requirements and the isolated local/live workflow.

New developers and coding agents can start with the
[architecture and onboarding guide](architecture/README.md). It explains the
system structure/design, agent loop, middleware, individual tool contracts and
all four application skills without requiring source-code reading. The
[documentation plan](architecture/PLAN.md) records its scope and validation.

## Maintained guides

| Task | Guide |
| --- | --- |
| Understand the complete project before changing it | [Architecture reading path](architecture/README.md), [onboarding walkthrough](architecture/onboarding.md) |
| Find an individual callable or application skill | [Tool catalog](architecture/tools/README.md), [skill catalog](architecture/skills/README.md) |
| Load application skills and call analysis tools | [Skills and tool contracts](skills.md) |
| Extend deterministic post-trade calculations and reports | [Post-trade structure](post-trade-analysis.md) |
| Integrate P&L sources and interpret numerical evidence | [P&L analysis](pnl-analysis.md) |
| Integrate risk sources and in-memory analysis | [Risk analysis structure](risk-metrics-analysis.md), [dataset contract](../skills/risk-metrics/references/dataset.md), [methodology](../skills/risk-metrics/references/methodology.md) |
| Run the cross-source notebook and validate a consolidated report | [Market activity review](market-activity-review.md) |
| Understand prompt assembly, todos and parallel execution | [Agent prompts](agent-prompts.md) |
| Configure input-history compaction | [Context compaction](context-compaction.md) |
| Work with saved PNG charts and evidence manifests | [Analysis visualizations](analysis-visualizations.md) |
| Own recorders, add middleware or inspect recordings | [Observability](observability.md), [dashboard](../dashboard/README.md) |
| Update callers after compatibility removal | [26 October removal and migration guide](legacy-removal.md) |
| Run synthetic and MCP regressions | [Test guidance](../tests/README.md), [validation commands](../README.md#test-and-validate) |

These guides describe the checked-in interfaces. Corporate dependency integration
is still pending; synthetic tests, local live evidence and corporate acceptance
are separate validation boundaries. No package lockfile or corporate acceptance
is implied by a dated report.

## Historical material

Historical files retain their dates, source snapshots, unsuccessful outcomes and
validation limits. Use them to understand decisions or reproduce the recorded
investigation, rather than as current setup commands or an active backlog.

| Material | Entry point |
| --- | --- |
| Superseded donor comparison and migration/P&L plans | [Archive](archive/README.md) |
| Original logging and middleware integration | [13 October record](review/logging-middleware-validation-2026-10-13.md) |
| Parallel prompt/MCP experiment | [14 October record](review/agent-parallel-validation-2026-10-14.md) |
| Notebook/chart integration, rejected live drafts and offline replay | [19 October record](review/market-activity-review-validation-2026-10-19.md) |
| Post-trade structure and fixed-snapshot comparisons | [22–23 October record](review/post-trade-structure-validation-2026-10-23.md) |
| P&L simplification and output-preservation comparisons | [23 October record](review/pnl-simplification-2026-10-23.md) |
| Branch/worktree integration decisions | [23 October record](review/remaining-work-integration-2026-10-23.md) |
| Dated implementation reviews and validation reports | [Review directory](review/) |
| Source research and design investigations | [Research directory](research/) |

The market-activity audit research is a dated background framework and includes
a local source variant. The deployed [market-review skill](../skills/market-activity-review/SKILL.md)
and the notebook's actual source manifest own the current workflow. External
regulatory references in that research have not been refreshed by this cleanup.
