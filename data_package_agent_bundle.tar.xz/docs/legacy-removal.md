# Removal of legacy compatibility support — 2026-10-26

This follows the [test cleanup](review/legacy-test-review-2026-10-26.md).
The requested exception is the old LLM adapter: both
`llm/genai_manager_model.py` and `llm/genai_manager.py` remain byte-for-byte
unchanged, including explicit provider selection. Its dependency declarations
and shared `tool_text` behavior are also preserved.

Normal agent execution still uses `socgenai_llm`, Responses and detailed reasoning
summaries. Budgets, parallel dispatch, cancellation, current recording, analysis
calculations, report contents and standalone charts retain their active paths.
No corporate configuration, package dependency pin or local credential changed.

## Removed entry points and caller updates

Paths under `src/mcp_agent_template/` below are package-relative imports.

| Removed support | Current entry point or action |
| --- | --- |
| Historical `docs/research/otel_gap_probes.py` and `docs/review/data-package-agent-review-probes-2026-10-14.py` runners | Their dated Markdown evidence is retained. Use maintained observability/MCP tests and the separate offline agent probe suite; retrieve the old scripts from Git history only to reproduce that dated investigation. |
| `scripts/setup_genai_manager.py` | Use the package's documented uv setup. The old adapter itself is retained; its one-off .pth cleanup script is removed. |
| `analysis.fox.fox_analysis` script module | `python -m mcp_agent_template.analysis.fox.runners` |
| `analysis.fox.duplicate_analysis` | Import `deduplicate_case_ids` and `DUPLICATE_DETAIL_COLUMNS` from `analysis.fox.preprocessing`. |
| `analysis.fox.utils.create_aging_bucket` | `analysis.fox.preprocessing.create_aging_bucket` |
| `analysis.fox.markdown_report.format_analysis_markdown` and its `AGING_BUCKET_ORDER` re-export | `runners.analyze_cases` then `markdown_report.render_markdown`; constants belong to `preprocessing`. |
| `analysis.fox.export.export_report` | `export.write_workbook` with the current `AnalysisResult`. |
| FOX summary fallbacks for unprepared frames or absent duplicate evidence | Pass prepared/scored pipeline outputs. The active collector remains because both report writers need its calculated tables and owned queues. |
| `analysis.pnl.calculations.prepare` | `analysis.pnl.loading.prepare` |
| Workbook helpers re-exported by `analysis.pnl.reporting` | `analysis.pnl.excel.export_workbook`, `evidence_rows` and `TEXT_PART_SIZE` |
| `analysis.risk_metrics.sgmr.Observation` | `analysis.risk_metrics.models.Observation` |
| `analysis.risk_metrics.report.export_workbook` and ignored `visualizations` argument | Import the writer from `analysis.risk_metrics.export`; call `report.markdown_report(review, workbook, markdown)`. |
| `analysis.charts.chart_section` and `Chart.preview_order` | Standalone chart export/index/manifest remains. The unused preview-order field is no longer written to manifests. |
| `Settings.allow_parallel_tool_calls` and its normalization | Remove the setting/environment option. Active middleware enforces parallel decisions; execution capacity still uses `agent_max_concurrent_tools`. |
| `RunLifecycleMiddleware` / `ToolExecutionMiddleware` and ignored general ordering keywords | Use `RuntimePolicyMiddleware(child_names=...)`. `ToolRoundPolicyMiddleware` takes the round limit only. |
| Old middleware reserved names and `build_sequential_policy_prompt`, including its `react_agent` re-export | Only current built-in names are reserved. Use current prompt assembly and `AgentSpec.concurrency` for child scheduling. |
| `observability.recording.runtime.InvocationScope` re-export | `agent.runtime.invocation.InvocationScope` |
| Default omitted `Skill.files` inventory | Discovery supplies the required inventory; direct construction must pass `files` explicitly, including `()` for Markdown-only skills. |
| Notebook/dashboard provider-metadata and token-only rendering fallbacks | Current Responses/normalized message blocks and recorded callback chunks provide answer and exposed summary text. |
| Historical period arguments in accepted review traces | Evidence capture accepts only current MCP tool argument names. Former PnL review dates and Python-only output overrides cannot establish tool evidence. |
| Unused `tool_results.tool_json` | Application code can parse the current textual result when it needs JSON. `tool_text` is retained unchanged for current messages and the protected old adapter. |

Current PnL source-column aliases, supported message string/block forms, child
`concurrency="sequential"`, optional paths and missing-data handling are active
functionality. They are not retired merely because they admit multiple input
shapes. Cross-source “compatibility” checks concern evidence comparability.

## Recording boundary

The writer, package reader and standalone dashboard now accept SQLite storage
version 2 only. Fresh databases are initialized directly, transactionally and
under the writer lock. New stores contain current tables/views without legacy
mirror tables or a migration-history table. Schema-creation failures roll back
and permit a fresh initialization attempt.

Existing version-2 databases retain their current table/view contract and contents.
They are not rewritten or stripped of extra tables. Version-1 recordings and
populated unversioned databases are rejected without changing their schema or
records. There is no automatic migration or version-1 reader. Use a previous
application version separately to inspect/export such recordings and a fresh
destination for new runs.

Observation JSON envelope/archive version 1 remains the current content format;
it is distinct from the SQLite storage version. The API manager's encrypted
audit format is outside this change.

## Validation

The current agent/dashboard and separately collected offline probe suites are
rerun in the isolated Python 3.12 environment. Meaningful additions cover
current-store reopening/appending, transactional schema-creation failure,
unsupported-schema rejection and unsupported MCP evidence arguments. Existing
runtime, analysis, MCP, cancellation, chart and dashboard tests remain.

Verified on 2026-10-26:

| Check | Result |
| --- | --- |
| Full agent and dashboard pytest suite | 707 passed, two subtests passed; 288.39 seconds |
| Separate offline agent probe regressions | 47 passed |
| Standalone standard-library dashboard tests | 37 passed with Python site initialization disabled |
| Dashboard JavaScript tests | 15 passed |
| Ruff lint and formatting | Passed |
| Git diff whitespace checks | Passed |
| Wheel and source distribution | Built and inspected; retired scripts/modules absent |
| Installed wheel outside the checkout | Current public imports passed; all 88 package Python files matched source bytes |
| Existing current-schema recording | Opened a v2 database produced by the preceding commit, appended through the new writer and recovered both complete payloads |
| Old LLM implementation and factory | Both files match the preceding commit byte for byte |

The existing LangChain MCP beta warning remains visible. No live provider calls
or corporate acceptance were run. The isolated environment uses Python 3.12.12,
OpenAI 3.24.0 and the local LangChain Core 1.6.10 override; corporate dependency
resolution remains unverified. Tests used mocked providers and local MCP/HTTP
transports with the documented socket restrictions.

Builds used cached public build tooling, without altering the corporate index
in package metadata:

```text
uv build --python 3.12 --no-sources --default-index https://pypi.org/simple --offline
```

The default-index offline build initially lacked a cached corporate hatchling
entry; the documented public-cache build above succeeded. Installed verification
used a fresh uv environment under the system temporary directory, the built wheel,
the actual sibling packages and the same local Core override. No global install
or production dependency changes were made.
