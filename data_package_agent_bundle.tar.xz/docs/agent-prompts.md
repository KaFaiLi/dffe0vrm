# Agent prompts and parallel tool calls

Both `build_agent()` and every node built by `build_agent_tree()` use the same
base prompt from `agent/prompts.py`. It defines task ownership, tool selection,
skill loading, verification, and concise reporting. Requests for a preview or
plan remain bounded by that request; execution tasks continue through completion
or an explicit blocker within the configured runtime limits.

The prompt is assembled as:

1. The shared base instructions.
2. LangChain's todo guidance and the package's invocation-lifetime instructions.
3. `AVAILABLE SKILLS` and the selected skills' names and descriptions.
4. For tree nodes, the optional `AgentSpec.system_prompt_extra`.

Full skill instructions and supporting-file contents are loaded through tools
on demand. With no selected skills, the catalog says
`No skills are currently available.` See [skill folders](skills.md) for the
metadata and tool-result formats. The base prompt directs the model to load a
matching skill, respect explicit user instructions, and treat ordinary retrieved
material as source data rather than instructions that redirect the task.

The wording adapts the public [Codex starter prompt](https://developers.openai.com/cookbook/examples/gpt-5/codex_prompting_guide)
and [GPT-6 prompting guidance](https://developers.openai.com/api/docs/guides/latest-model#prompting-best-practices)
for this tool and skill interface. The public Codex starter is documented for
GPT-5.3-Codex; the GPT-6 guidance recommends its prompting blocks across the family.
This is an application prompt for the configured model, not a verified copy of
a Luna-specific Codex system prompt. Offline checks verify assembly and runtime
behavior, not a measured improvement in live model task completion.

## Todo tracking

`build_agent()` and every node in `build_agent_tree()` automatically provide
LangChain's `write_todos(todos)` tool. Each item has `content: str` and a `status`
of `pending`, `in_progress`, or `completed`. Each call replaces the entire list;
passing `[]` clears it. Independent tasks may be `in_progress` together.

Use the checklist for complex work or an explicit request to track tasks. Simple
questions can be answered directly. Guidance asks the model to update progress,
revise obsolete tasks, explain blockers, and deliver the actual answer. There is
no completion gate: an agent can return with unfinished todos, and limits or
errors do not automatically mark work completed. There is no `blocked` status;
keep unfinished work incomplete and describe the blocker in the answer.

The tool updates native graph state. Inspect it through the existing APIs:

```python
bundle = await build_agent()
result = await bundle.ainvoke("Inspect the package, validate it, and summarize findings.")
todos = result.get("todos", [])  # Absent until the first successful write.
answer = result["messages"][-1].text

from contextlib import aclosing

async with aclosing(bundle.astream("Another task", stream_mode="values")) as stream:
    async for state in stream:
        print(state.get("todos", []))
```

Each invocation starts without todo state. Calling the same bundle again does
not resume its previous checklist; even a reused `thread_id` does not enable
checkpointing. Explicitly supplied message history is still visible to the model,
but there is no automatic restoration of todo state. Concurrent calls and each
worker invocation maintain independent lists. Workers receive their delegated
task, and their final tool artifact contains `agent`, `messages`, and `todos`.
Only their answer text goes back to the parent model; their checklist never
overwrites the parent's state. `bundle.ask()` continues to return a string.

Native validation returns tool errors for invalid inputs without changing the
checklist. Multiple `write_todos` calls in one model turn are all rejected, while
unrelated tools in that turn can still execute. Successful todo execution uses
the existing tool budget and capacity gates; todo turns also consume the normal
model and round allowances. No special extra budget or automatic retry is added.

`AgentTodoMiddleware` inherits LangChain's tools, state schema and duplicate-write
checks. It only bypasses the native model wrapper's prompt append: the shared
prompt builder owns those instructions so the default dispatched prompt agrees
with `bundle.system_prompt` and recorded definitions. Application middleware can
still intentionally change requests. The existing tool catalog, fingerprints,
recordings and graph streams include todo tools and results; no new dashboard,
notebook checklist view, storage table, or MCP-server tool is introduced.

Applications that previously supplied their own `write_todos` tool or
`TodoListMiddleware` must remove that duplicate. Tool names remain unique and
collisions fail during construction. Provider configuration and dependencies are
unchanged. See the [research comparison](research/todo-tools-design.md) for the
design choices. Historical live evidence below predates this todo addition and
does not validate its live model behavior.

## Parallel execution

Parallel tool calling is always available. The model can request multiple
independent tools in one turn, and all those calls are retained. Model dispatch
sets `parallel_tool_calls=True` through the native model-request settings for the
configured provider adapter. The agent does not replace a failed provider call
with another API or model.

The prompt encourages batching independent calls and waiting for prerequisites
or potentially conflicting operations. Parallel availability does not force
dependent operations to execute together. External-tool capacity, shared tool
and model budgets, tool-round limits, deadlines, and cancellation still apply.
When composing applications, provide the necessary locking or sequencing for
tools that modify the same resource.

Tree nodes default to `AgentSpec(concurrency="parallel")`. Explicit
`concurrency="sequential"`, positive integer limits, and custom concurrency
wrappers remain available for a parent's child calls. These do not serialize
the parent's ordinary tools or disable multiple model-selected calls.

## Migration from sequential defaults

- Remove `ALLOW_PARALLEL_TOOL_CALLS` and `Settings.allow_parallel_tool_calls`;
  parallel tool decisions are enforced by the active runtime policy.
- The obsolete `build_sequential_policy_prompt` helper and the former strict
  suffix are gone.
- Replace the old lifecycle/tool middleware pair with one
  `RuntimePolicyMiddleware(child_names=...)`. The split classes and ignored
  `sequential` / `allow_parallel_tool_calls` constructor keywords are removed.
- Builders install that combined policy for lifecycle, model parallelism and
  tool execution. See the [middleware guide](observability.md#native-middleware).
- An application model-request setting of `parallel_tool_calls=False` is
  overridden at dispatch. Other request settings are preserved.
- To limit a parent's child execution explicitly, set `AgentSpec.concurrency`.
  To bound ordinary external-tool execution, use `agent_max_concurrent_tools`.
  Neither limit reduces the model's proposed calls to a single call.

Provider deployment capability remains a server decision. Synthetic tests and
prompt changes do not establish corporate Azure compatibility or live quality.

## Historical validation

The [14 October parallel-agent check](review/agent-parallel-validation-2026-10-14.md)
records its exact prompt, overlapping MCP calls, usage and local runtime. It
predates native todo tracking and later integrations; it does not validate
current live behavior. Follow the [development README](../README.md#test-and-validate)
for current test commands.
