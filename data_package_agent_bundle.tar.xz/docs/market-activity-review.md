# Cross-source market activity review

Open [the notebook](../notebooks/market_activity_review.ipynb) in a Python 3.12+
Data Package Agent kernel. It demonstrates a main reviewer using the
[market-activity-review skill](../skills/market-activity-review/SKILL.md), three
specialists, cross-source challenge and one consolidated finding.

Use the package's documented corporate environment setup with the `dev` and
`socgenai-llm` extras. Keep this package separate from the suite-root environment;
the existing agent/wrapper dependency boundary still applies. Local Foundry
credentials and overrides belong only to the separately authorized development
workflow described in AGENTS.md. The notebook does not read those credentials.

## Run the demonstration

1. Run setup and preflight with `RUN_REVIEW=False`. Paths resolve from the suite,
   package or notebook directory. Inspect the source manifest and SHA-256 hashes.
2. Edit the source paths and optional definitions. PnL uses all supplied dates.
   The default manifest uses the current synthetic baseline, not seeded evaluation copies.
3. Supply `REVIEW_MAPPINGS` and `REVIEW_CRITERIA` only when backed by documented
   evidence. The empty defaults preserve the current gaps. A mapping declares
   source IDs, scope, period, measurement basis and a reference; a criterion
   declares the applicable requirement and reference. These are operator inputs,
   not findings inferred by the model. The PnL tool accepts six source paths and
   uses every supplied date independently for each dataset; it has no review-date
   or review-context JSON parameters.
4. When ready for billable corporate provider execution, set `RUN_REVIEW=True`
   and run execution/validation. The model is the configured deployment through
   `socgenai_llm`, Responses and detailed reasoning summaries. No sampling or
   output-token limits are added; SDK retries are zero. Existing call and time
   budgets remain in force. A provider may return no exposed reasoning summary.
5. Review the finding, cross-source matrix, coverage and cited evidence. A
   structurally valid report still needs auditor judgment and corroboration.

The three initial specialist analyses run concurrently when the main model calls
the three delegation tools together. The notebook sets child concurrency to
three; this does not force a live model to issue a particular tool sequence.
Scripted tests establish the executable orchestration and overlapping calls,
not the behavior or quality of an untested live model.

### Authorized local live execution

When live testing is explicitly authorized, use the suite development runner
from the repository root in the isolated environment described in `AGENTS.md`:

```powershell
uv run --project artifacts/foundry-agent --locked --python 3.12 python devtools/foundry_lab/run.py --operation data-package-agent --agent-case market-review --model gpt-6-luna --config <ignored-credential-json> --pricing <local-pricing-json> --run-live
```

This case executes the notebook's code cells, including the actual four-agent
tree, source preflight and final validation. It supplies only the local provider
constructor, runtime bounds and output directory. The notebook on disk remains
disabled with cleared outputs. The local kernel environment also needs IPython;
the package's `dev` extra includes it through `ipykernel`.

The run permits 64 model requests and 80 tool calls, with a 25-minute root
deadline, 15-minute child deadline, 180-second SDK timeout and zero SDK retries.
An outer 26-minute deadline allows cleanup. All models use Responses with
max/detailed reasoning and omit output-token limits and sampling parameters.
The default EUR 5 ledger threshold is post-response accounting, not a hard cap.
A failed provider dispatch stops new requests; already active siblings can finish.
Neither a failed request nor invalid final JSON is automatically replayed.

Ignored `devtools/foundry_lab/output/<run-id>/` contains a safe `summary.json`,
usage progress, tool-call metadata and the notebook's analysis directory. Valid
reports are written there only after the notebook validator succeeds. Audit
verification matches concurrent request usage/cost as a multiset, checks the
logger ledger and decrypts audit content internally without displaying keys or
plaintext. Calculated cost is not provider billing proof. Local Foundry evidence
does not establish corporate identity, proxy, shared-drive or dependency acceptance.

## Scope and evidence

The P&L/risk baseline covers July 2025–June 2026. Post-trade is an independent
case population with an expected 30 September 2026 snapshot. Actual tool reports
determine observed scope. Preserve MOCK team-role uncertainty, missing attribution
currency definitions and unresolved SGMR–Colibris identifiers. No case-to-trade
link is supplied. Missing mappings may prevent a consolidated control finding.

Children receive only their own topic skill and analysis tool. The main receives
its shared skill, delegation tools and a scoped tool-report evidence lookup,
without raw-file access. Children return observations with source IDs and useful
record/date/phrase search terms; saved full workbooks
are available for further review but are not automatically inspected by agents.
The main explicitly compares six source relationships and can ask a focused
follow-up with prior evidence. Fresh child invocations have no shared memory.
When current tools cannot resolve the question, the report requests evidence.

Confirmed or contradictory relationships require supplied compatible mapping
metadata and evidence from the compared source kinds. This is a provenance and
definition gate, not a row-level join engine. Matching labels or dates do not
establish causality. Unrelated observations remain supporting workpapers.

## Response contract and artifacts

The checkout-only helper [`notebooks/review_reporting.py`](../notebooks/review_reporting.py)
exposes `AuditReport`,
`capture_run_evidence`, `build_evidence_catalog`, `validate_audit_report` and
`render_audit_report`. It lives beside the notebook and is excluded from the installed
`mcp_agent_template` wheel. Imports from the former `mcp_agent_template.review_reporting`
location should use `notebooks.review_reporting` with this package folder on the Python
import path; the notebook sets up that path for suite, package and notebook launch directories.
The notebook uses `report_instructions(evidence_mode="catalog")`
and validates with that explicit mode. Its model draft selects evidence using
only `{id, catalog_id}` entries. A fresh catalog built from captured successful
tool reports supplies the final source ID, report-digest/line locator and exact
excerpt. Unknown IDs or manually supplied citation fields are rejected. This is
deterministic evidence selection, without a model repair call or modification of
quoted content. The final `AuditReport` still contains full evidence records.

The notebook's `lookup_review_evidence` extra tool searches only captured tool
reports by manifest source ID and optional literal text. It pages report rows
with `offset` and `page_size` (default 12, maximum 50) to bound tool data in model
context. It cannot open source files or workbooks. These record counts are
independent of the unchanged policy to omit LLM output-token limits. Existing
agent builders and analysis-tool APIs are unchanged. Direct callers retain the
default `evidence_mode="verbatim"` contract and its original report schema.

Every report contains three topic outcomes, all 36 D/P/R/T/C check IDs, six
cross-source comparisons and exactly one `final_finding`. Dispositions are
`supported_finding`, `further_evidence_required` and `no_finding_identified`.
The last requires no unresolved checklist items; it is still limited to the
stated scope. A supported finding requires applicable supplied criteria and
corroborated cross-source evidence. All three topics must be assessed, but they
need not all support the same issue. Causes remain unknown unless evidenced.

Validation checks strict JSON (including duplicate keys), complete registers,
supplied source/mapping/criterion identities, topic status against nested traces,
and current MCP analysis arguments against the configured source roles and paths.
Unsupported arguments, including former PnL review dates, cannot supply accepted evidence.
Catalog rows from multi-source reports require an unambiguous source filename
or path marker, or a supported renderer-owned numerical section binding. Risk
Excess governance rows bind by section to the single supplied Colibris source,
so excessId remains sufficient without a source_locator column. Ambiguous source
roles are not bound, and literal commentary cannot impersonate this section.
A single-source report can establish its own report-line
evidence without repeating a source filename in each row. Generated locators
identify the actual tool-report digest and line; they never claim raw-file
inspection. Exact report text remains server-owned. Legacy verbatim mode still
requires source-bound same-line locators/quotes, with only the documented,
unambiguous P&L full-path-to-filename compaction accepted as an equivalence.
Reports from a changed scope cannot certify the configured review population.
Their source-bound evidence and artifacts remain available, with the actual
arguments and canonical-scope flag retained in `execution.json`.
It also checks comparison
source kinds and actual artifacts within the invocation's output folder. It
does not prove calculation correctness, truthful management assertions, semantic
mapping validity, procedure sufficiency or the causal interpretation of evidence.
`level=tool_report` makes that evidence boundary explicit.

Each run uses a unique `ANALYSIS_RESULTS_DIR/market_review/<run-id>/` folder:

- `manifest.json`: supplied scope/definitions and input hashes.
- Topic subfolders: the tools' full Excel and Markdown outputs.
- `execution.json`: captured topic status, each analysis's actual arguments and
  canonical-scope flag, mandatory workpapers and optional linked chart artifacts;
  safe error type if stopped.
- `review.json` and `review.md`: written only after validation, from the same object.
- `validation_errors.json`: actionable diagnostics when the final output is invalid.

The report must list every primary workbook and Markdown report identified by
successful analysis results. Chart indexes, manifests and PNG previews linked
by those results are optional report entries. They must exist inside that
report's own `charts/` directory; unlinked paths, traversal and files from a
failed child's hidden trace do not qualify. An observation's topic is its primary
theme. Cross-source observations must cite topic-specific checks for exactly the
topics represented by their evidence, including the primary theme. Shared D/C
checks alone may span topics, but still need primary-theme evidence; adding a
shared check cannot widen a topic-specific observation's evidence scope.

Failed children do not erase successful siblings. The current tree adapter does
not expose failed children's partial internal traces; those steps cannot be
asserted as completed. A root interruption may leave artifacts without a final
report. No failed provider request or invalid JSON is automatically replayed.
Notebook streaming and provider cleanup run in `finally` blocks. Clear notebook
outputs before committing; generated files and local trace content are sensitive
like their source material and remain in ignored application output directories.

## Verification

`tests/test_review_reporting.py` checks evidence/coverage validation, single
findings, incompatible or invented links, partial outcomes and rendering.
`tests/test_market_review_notebook.py` executes notebook setup with temporary
synthetic inputs and the real four-agent tree with scripted models, including
concurrent analysis, targeted follow-up, capability isolation and failure/timeout
paths. Tests do not read development datasets or use provider credentials.

Run these and the relevant skill/agent tests in the package's isolated Python
3.12+ environment, plus package Ruff checks. Offline evidence is not live model
quality, provider compatibility or corporate identity/network acceptance.

## Historical validation

The [19 October validation record](review/market-activity-review-validation-2026-10-19.md)
retains implementation checks, source-variant provenance, unsuccessful live
attempts, chart runs and the offline revalidation of a saved catalog draft.
Those results do not certify the current checkout. Use the
[development README](../README.md#test-and-validate) for current test commands.
