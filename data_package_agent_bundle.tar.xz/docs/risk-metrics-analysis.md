# Risk metrics analysis structure

Implemented on 23 October 2026 in `codex/simplify-risk-metrics`, starting from
clean suite commit `0ec42c0cf3d47191e499c2f539bb36933482c5ea` in a new managed
worktree. That structural refactor preserved the methodology; subsequent report
and movement-analysis changes are described below.

The current returned and saved Markdown starts with Metric movements. It omits
Executive observations, Scope and availability, and all visualization sections,
chart previews and chart links. Summary counts remain in Excel's Summary sheet.
Source inventories and per-check availability remain in Sources and Methods; standalone
PNGs, `charts/index.md` and `charts/manifest.json` are still exported.
The unused `markdown_report(..., visualizations=...)` keyword has been removed. Calculations, input populations and the five-path tool interface are
unchanged by this presentation update. The current movement calculation separately
replaces the fixed 25% trigger with percentage-movement population `abs(z) >3`
flags for all comparable segments, retaining per-observation evidence in SGMR
Detail. Volatility-change and persistent-trend calculations are removed.

SGMR and Colibris are now analyzed independently. The reconciliation module,
`Review.reconciliation` field, Reconciliation worksheet, link summary counts and
linked-consumption/approval checks are removed. Python and MCP runner signatures
are unchanged; callers must stop expecting those removed results. Event usage
checks remain within Colibris. Excess governance Markdown traces events by
excessId and omits source_locator/reperformed_usage columns; complete event
evidence remains in Excel. Markdown uses short formulas, units and notes;
complete calculation methods remain in Excel's Sources and Methods sheet.

SGMR limit-consumption analysis is removed from code and reports: utilization,
bound-exceedance, warning/proximity and breach-episode calculations, derived
fields, summary counts and availability entries are no longer produced.
`Observation` no longer has utilization/absolute/warning fields or a breach
property. Source limit columns remain raw evidence; series identity, date
coverage and independent limit-history/effective-date checks remain. Standalone
charts show one risk-value axis without limit-bound or utilization overlays.

Markdown and numerical workbook tables use separate `riskMetricName` and
`perimeterMnemonic` columns in place of the combined `scope` label. SGMR maps
`rmRiskMetricName` and `stranaPc` to these names; Colibris uses its matching source
fields. Labels preserve source spelling and missing values stay unknown. The
full analytical grouping key and source locators remain unchanged. The internal
`Observation.identifiers` property replaces `Observation.scope`; Series Review
also uses these canonical column names instead of `metric_name` and `pc`.

Prioritized follow-up is removed from Markdown. Dedicated Metric value outliers
and Days with movement and value outliers sections expose the value screen and
its exact-observation intersection with movement flags. The joint day list is
complete, including more than 15 rows. Excel adds Value Outliers and Movement and
Value Outliers worksheets; the existing independent check evidence remains.

## Contract inventory

- Keep `run_risk_metrics_analysis` and its five source paths, optional
  keyword-only `output_dir`, defaults, Markdown return and MCP schema.
  Invalid files/headers still raise `ValueError`; write errors propagate.
  The MCP adapter retains its existing error translation.
- Read SGMR Parquet and optional UTF-8 Colibris CSV with the same case-insensitive
  header validation. Compare complete raw rows for exact duplicates before
  parsing. Preserve conflicting grains/IDs, source values, duplicate locations
  and original one-based row ordinals. Do not filter official-stamp values.
- Keep the full series key, scenario axes, units, date coverage and limit history.
  Current movement populations and thresholds are documented below. No risk totals or currency conversion
  are added. Missing/invalid values stay unknown. See the
  [methodology](../skills/risk-metrics/references/methodology.md).
- The reference date remains the latest valid SGMR date, including dates from
  conflicted observations. Calendar ages describe recorded event states, not a
  historical reconstruction. No wall-clock snapshot is introduced.
- Preserve candidate ordering by review priority, source filename, original
  record ordinal and check, including stable ties and multi-record references.
  Display labels and repeated source IDs do not replace row identity.
- Preserve remaining Markdown headings, 15-row detail limits, 350-character
  table-cell abbreviation, complete commentary blocks and the nine Excel sheets. The
  joint-outlier day table is complete rather than capped at 15 rows. Excel
  strings remain literal, with 32,000-character continuation parts and numeric
  measures only on the first part. Worksheet order, filters and styles remain.
- Preserve report filenames, unique run directories, chart selection, chart
  evidence/index/manifest, staged publication and source
  file bytes. No LLM calls are part of analysis.

## Smallest useful changes

The existing calculation modules already have distinct responsibilities. Keep
SGMR identity/date coverage/history in `sgmr.py`, movement screens in `dynamics.py` and independent
Colibris rules in `workflow.py`.
The original refactor left their predicates, formulas and candidate explanations
unchanged. The current movement and report contracts are described below.

Within the existing flat directory:

| File | Responsibility |
| --- | --- |
| `sources.py` | File loading and shared raw-table preparation: headers, duplicates, parsing, source references |
| `models.py` | Existing `Review`, source/record types and the shared `Observation` record |
| `runners.py` | In-memory `analyze_tables`, shared calculation sequence and file/output orchestration |
| `report.py` | Markdown and shared methods/display wording |
| `export.py` | Excel cells, continuation rows, sheets and styles |
| `charts.py` | Existing source-linked chart presentation |
| `commentary.py` | Existing complete source-document loading |

No new result class, reporting directory, configurable rules or pipeline
framework is introduced. `Review.observations` retains the actual calculated
observations for charts, with references to the same retained source records.
It avoids reconstructing them from report detail rows or repeated business IDs.

File and in-memory entry points share preparation and the private analysis
sequence. The file loader still validates each input in the existing order and
retains CSV strings verbatim. It does not round-trip CSV through inferred
DataFrame types. Both writers consume the existing calculated report tables;
Markdown-only counts and display selections remain presentation work.

Import `export.export_workbook` directly. The Excel writer reuses methods wording
and display formatting from `report.py`; no extra presentation module is needed.
Import `Observation` from `models`. The old report-writer wrapper and
`sgmr.Observation` re-export have been removed.
Existing low-level loader and analysis calls remain compatible, with the same
accumulator behavior.

## Runtime resource ownership

Risk source loading avoids whole-file Python byte buffers and complete temporary
row lists. Parquet is read directly into one columnar frame and iterated by row.
Colibris CSV uses two streaming passes on one open file handle: first count all
supplied IDs, then prepare records. This keeps duplicate source references and
original row ordinals unchanged. Sources should remain stable throughout a run.
In-memory inputs retain deep-copy protection for nested caller-owned values.

Deduplication retains fixed-size SHA-256 fingerprints instead of complete JSON
strings for every row. A matching fingerprint always triggers comparison of the
original canonical row encoding, so collisions cannot merge different records.
All raw fields, duplicates, conflicts and parsing disclosures remain available.

The risk workbook uses write-only cells and incremental evidence conversion.
Preflight keeps at most 100 prepared rows for the existing column-width rule and
checks worksheet capacity before writing a sheet. All nine sheets, literal
strings, exact values, continuation records, styles and filters are preserved.
openpyxl's temporary worksheet XML is removed after a successful save; failures
also attempt cleanup without replacing the original export error. The shared
list-returning evidence helper remains compatible for PnL and other callers.

Risk figures release cached text-renderer references before clearing artists,
including failed saves, so completed Agg pixel buffers do not wait for cyclic
garbage collection. Every series still uses the complete supplied SGMR calendar;
movement segmentation reuses one read-only date-position lookup across series.
These changes reduce intermediate storage and repeated work. The complete
Review still grows with the supplied population and retained evidence; this is
not a constant-memory analysis or a memory limit.

## In-memory Python use

```python
from pathlib import Path

import polars as pl

from mcp_agent_template.analysis.risk_metrics import analyze_tables
from mcp_agent_template.analysis.risk_metrics.export import export_workbook
from mcp_agent_template.analysis.risk_metrics.report import markdown_report

# Raw source columns, supplied in memory by the caller.
sgmr = pl.DataFrame(
    {
        "limId": ["LIMIT-A"],
        "stranaNodeName": ["PORTFOLIO-A"],
        "rmRiskIndicator": ["VAR"],
        "consoValueDate": ["2025-01-01"],
        "consoValue": [10.25],
    }
)
review = analyze_tables(sgmr, sgmr_name="synthetic.parquet")
workbook = Path("risk_metrics_analysis.xlsx")
markdown = Path("risk_metrics_analysis.md")
export_workbook(review, workbook)
markdown.write_text(markdown_report(review, workbook, markdown), encoding="utf-8")
```

`analyze_tables` reads no settings, clock or files and writes nothing. Optional
Colibris is a raw Polars frame; `None` means omitted, while a header-only frame
with `excessId` means a supplied empty population. Names are nonblank source
labels only. Required columns and an SGMR row are validated; unavailable optional
fields disable dependent measures. The minimal example intentionally lacks
series definitions, so its movement and level-statistics checks stay unavailable.

Each call owns copied records, observations and report rows. Caller frames remain
unchanged, and separate results share no mutable records. `Review` is mutable;
renderers treat its contents as read-only. The numerical entry point does not
interpret or load commentary. Use the existing file runner for the complete
five-source workflow, automatic output directories, charts and publication.
Standalone writers require an existing parent directory.

## Calculation walkthrough

The tool reviews supplied SGMR risk measurements and selected Colibris excess
events. It does not calculate VaR, SVaR, stress losses or exposures from positions,
reprice instruments, validate a risk model, convert currencies or add portfolio
risk values together. All calculations below are deterministic; commentary
interpretation belongs to the calling agent or auditor.

### Source preparation and analytical populations

SGMR is required; Colibris and the three commentary documents are optional. All
supplied dates and perimeters are used, including official-stamp values. Column
matching is case-insensitive. Original values and source references are retained.
Exact full-row duplicates are removed before parsing and their locations are
disclosed. Invalid dates, nonfinite numbers, invalid booleans, negative duration
fields and invalid versions remain unknown rather than becoming zero.

A statistical series is identified by limit ID, portfolio, PC, risk indicator,
metric name, unit, version and the additional definition/scenario axes in
`sgmr.AXIS_FIELDS` (for example scenario, underlying, tenor and currency axes).
Different scenarios or versions never share a statistical baseline.
Non-identical records sharing limit/portfolio/indicator/version/axes/date are
flagged as conflicting observations, including disagreements in unit, metric
name or PC. The tool does not select an authoritative record; affected rows are
retained as evidence and excluded from dependent aggregate calculations.

The reference date is the latest valid SGMR observation date, including valid
dates in conflicting records. It is not today's date. The observed-date calendar
is the union of supplied valid SGMR dates; no business or holiday calendar is
invented. A missing expected date, invalid required value or conflicting row
breaks a consecutive statistical run.

### Source-date coverage

All-period and calendar-quarter summaries retain source row counts, conflict
counts, definition axes and observed dates. Date coverage is
`distinct nonconflicting series dates / distinct observed SGMR dates`; it is
screened strictly below 95%. Coverage measures supplied-date presence, not the
validity of every risk amount. Series inception or closure may explain gaps.

### Metric movement calculations

Percentage movements are calculated for every comparable consecutive pair in
every risk series, including segments shorter than 20 observations. A comparable
row has a valid date/value and the required identity, metric definition, unit and
nonnegative integer version; PC may be absent. Valid bounds are not required.
The existing 20-observation gate applies only to risk-level statistics and level
shifts, not to the new movement calculations.

For each pair, calculate `movement[t] = (v[t] - v[t-1]) / abs(v[t-1])`. Use every
known movement in that same contiguous segment to calculate population mean
`mu = sum(movement) / N` and population standard deviation
`sigma = sqrt(sum((movement - mu)^2) / N)`. Then calculate
`z[t] = (movement[t] - mu) / sigma` and flag strictly `abs(z[t]) > 3`.
Both tails are included and equality is excluded. Signed movement values and
signed z-scores remain in the evidence. No fixed 25% change trigger remains.

No observation is dropped from SGMR Detail. Segment starts, invalid/conflicting
observations and zero previous values have unknown movement/score values with
explicit reasons. Nonfinite derived movements are disclosed and excluded from
the baseline. Known movements with zero dispersion retain their calculated
movement but have unknown scores and flags. A one-movement population therefore
has an unknown z-score. The baseline is not pooled across series or across gaps.
Each scored detail row retains its predecessor date/locator, population count,
mean and standard deviation; Series Review and Markdown summarize each segment.

For example, ten zero movements followed by a 100% movement have mean `1/11`,
population standard deviation `sqrt(10)/11`, and final z-score `sqrt(10)`, which
is flagged. Nine zero movements followed by a 100% movement give exactly `z=3`,
which is not flagged. Equivalent negative moves retain negative z-scores and
are screened using their absolute values.

The retained risk-level analyses use segment values `v[0] ... v[n-1]`:

| Analysis | Calculation and trigger |
| --- | --- |
| Distribution | `mean = sum(v) / n`; population standard deviation `sd = sqrt(sum((v - mean)^2) / n)`, using `ddof=0`; retain minimum and maximum. |
| Outlier | `z = (v - mean) / sd`; flag strictly `abs(z) > 3`. Zero dispersion makes the z-score unavailable. |
| Sustained level shift | At every split with 20 values before and 20 after, calculate relative change `(mean_after - mean_before) / abs(mean_before)` and effect `abs(mean_after - mean_before) / ((sd_before + sd_after) / 2)`. Require absolute relative change at least 20% and effect at least 2.5. A zero prior mean is ineligible; a nonzero shift with zero dispersion qualifies with an explicit zero-dispersion label. |

A level shift needs at least 40 observations. Only the strongest qualifying
split per segment is retained, ranked by `abs(relative change) * effect`, with
earlier splits winning ties. A qualifying zero-dispersion split ranks ahead of
finite-effect splits. Level and movement outliers are retained individually.
Volatility-change and persistent-trend analyses are not calculated: their
candidate types, rolling deviations, slope/projection/R-squared columns and
chart interval shading are removed. All retained screens use the
complete supplied segment retrospectively; they are descriptive, not forecasts,
formal significance tests or approved materiality thresholds.

SGMR Detail retains each observation's signed `value_z_score`, `value_outlier`,
`value_population_count`, `mean_value`, `value_population_stddev` and `value_status`.
Segments shorter than 20 values retain their count with
`insufficient_comparable_observations`; constant eligible segments retain their
baseline and `zero_value_dispersion`. Invalid/conflicting observations stay unknown.
Availability and Summary record the number of scored values and detected outliers.

`movement_and_value_outlier` is true only when both calculated flags are true
on the same retained source row. It is false when either screen is known false,
and otherwise unknown. No flags are combined across dates, series or identical
display labels. The joint Markdown table and worksheet list all true rows by
observation date, retaining riskMetricName, perimeterMnemonic, units, value,
percentage movement, both signed z-scores and exact source references. Multiple
matching metrics or scenarios on one date remain separate observations.

### Limit history and source consistency

The tool compares initial and current lower/upper bounds and consecutive dated
current bounds. Numeric equality uses both relative and absolute tolerance
`1e-8`. A known bound difference creates a review candidate. Initial/current
regimes are distinguished by their bounds and supplied start date; successive
dated changes retain both original observations. Neither check establishes
approval or a retrospective effective date.

Further checks identify observations before a supplied limit start or after its
end, and disagreements between explicit BU/SBU/GPC/PC fields and `flatStrana`
JSON. Malformed hierarchy JSON is a data-quality disclosure. A previous-value
date on or after the current date, or over seven calendar days earlier for a
DAILY limit, is also disclosed. Temporary bounds remain unapplied because their
timing and precedence have not been established.

### Colibris usage, aging and workflow

After exact deduplication, missing or repeated excess IDs are flagged and excluded
from derived event measures. Original records remain in Excel. For usable IDs:

- Recorded-open age is `SGMR reference date - creation date`; recorded-closed age
  is `closure date - creation date`. Unknown state/missing dates leave age unknown;
  a negative age is flagged and not reported as a valid duration.
- Explanation lag is `explanation date - creation date`; validation lag is
  `validation date - explanation date`. These are calendar-day differences.
- Reperformed usage is `abs(last consumption) / abs(limit)` when consumption and
  bound have compatible signs, using the same directional rule as SGMR. Source
  `usage` must explicitly contain `%` and is divided by 100. Flag a difference
  strictly above 1.5 percentage points, or a reported maximum usage more than
  one percentage point below the reperformed last usage. Boundary comparisons
  include a `1e-12` floating-point allowance.
- Recurrence means at least three usable events sharing normalized perimeter,
  indicator, metric name, unit, limit type and the same numeric bound. No time
  window is applied; this is a count in the selected event population, not a daily
  breach rate.
- State checks flag open events with closure dates, closed events without closure
  dates, and a closed flag combined with workflow status OPEN. Sequence checks
  flag explanation before creation, validation before explanation and closure
  before creation.
- Recorded-open events with explanation/technical-validation deadlines before
  the SGMR reference date are follow-up candidates. Explicitly unsatisfactory
  validation or LoD2 flags are also candidates.
- A stated limit-increase workflow is checked for a nonblank/nonzero increase ID,
  request date and trader/risk approval dates. Missing evidence and approvals
  dated before the request are flagged.

These checks use recorded states and dates. They do not reconstruct historical
states, validate a business-day SLA or infer a control failure from a missing
field. Lags can be retained as negative evidence even when age is unavailable.

### Evidence, commentary and report outputs

Source/check availability classifies omitted sources or missing required fields
as unavailable. Where the schema exists, it counts rows with all listed usable
fields and marks partial populations explicitly; statistical availability is
updated with known movement and z-score counts independently of the retained
20-observation level-statistics gate. These are diagnostics, not a
blanket switch that disables other calculations which have sufficient fields.

Data quality retains individual parsing, duplicate, conflict and statistical-
eligibility disclosures. Candidates may overlap: one observation can have a
hierarchy conflict and also be a movement outlier.
They are sorted by review order, source filename, original row ordinal and check;
the order is not a policy severity rating and candidate counts are not distinct
control-failure counts.

The nine Excel sheets retain Summary, Series Review, Value Outliers,
Movement and Value Outliers, Excess Review,
Review Candidates, Data Quality, SGMR Detail and Sources and
Methods. Markdown starts with Metric movements and retains the subsequent
value-outlier and joint-day sections, Excess governance, concise notes and complete
literal commentary, with 15-row detail excerpts except the complete joint-day list,
and 350-character table-cell abbreviation. Prioritized follow-up, Executive observations,
Scope and availability and chart sections are omitted only from Markdown.
Full methods stay in Excel rather than being repeated in Markdown; only truncated
tables get a row-count footer. Excess governance uses excessId without the source
locator or reperformed-usage display columns. Independent event checks and their
full underlying evidence remain in Excel.
Standalone charts reuse the calculated value series and exact-locator candidate
markers; they introduce no additional risk calculation. Every chart displays the
union of all valid supplied SGMR dates, retaining gaps outside its own series'
observations. Chart metadata date bounds describe that displayed calendar;
series coverage remains in the numerical evidence. Commentary is supplied
whole to the agent, without automated record extraction, counts, scoring or
causal matching to numerical observations.

## Historical preservation evidence

The following records the 23 October structural refactor. Its legacy-import
checks and earlier command outputs are historical; use the
[current removal guide](legacy-removal.md) for the 26 October interfaces.


Four synthetic datasets were captured before editing: directional equality and
fractional exceedances with duplicate/conflicting IDs, invalid dates, long
literal text and commentary; comparable statistical series with separate
scenario axes; minimal fields with unknown values; and an empty candidate
population with omitted Colibris.

The 23 October refactor's before/after comparison matched every legacy `Review`
field, ordered rows, complete Markdown, every workbook XML member and every
generated chart artifact.
Only the run-directory path and workbook creation/modified timestamps were
normalized. Source-column sets were compared in sorted order because sets have
no ordering contract. The added `observations` field is covered separately by
ownership and chart regressions. All synthetic source bytes remained unchanged.

The local capture script and outputs are in ignored
`artifacts/risk-refactor/` at the suite root. Maintained regressions are in
`tests/analysis/test_risk_metrics_in_memory.py`, alongside the existing file,
workbook, chart, commentary and MCP suites.

Validation uses the isolated Python 3.12+ uv environment from
[AGENTS.md](../AGENTS.md), with its local-only `langchain-core==1.6.10`
override. Production dependency pins and corporate indexes are unchanged.
No live provider or corporate acceptance is implied.

Commands run from `packages/data-package-agent/`:

```powershell
$riskUv = @('run', '--project', '../../artifacts/foundry-agent', '--locked', '--python', '3.12')
uv @riskUv python -m pytest -c pyproject.toml tests dashboard/tests -q `
    --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @riskUv python -m pytest -c pyproject.toml `
    tests/analysis/test_risk_metrics.py tests/analysis/test_risk_metrics_in_memory.py `
    tests/analysis/test_charts.py tests/test_risk_metrics_mcp.py -q `
    --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @riskUv ruff check .
uv @riskUv ruff format --check .
git diff --check
uv build --python 3.12 --no-sources --default-index https://pypi.org/simple --offline
```

The build uses cached public build tooling without changing the corporate index.
Installed checks use a fresh wheel path outside the checkout and an isolated
`uv run --no-project --isolated --python 3.12 --offline` environment, with the
wheel and local `langchain-core==1.6.10` override. All current risk-module files
must match the wheel and checkout byte for byte. The probe
checks legacy imports, the runner signature, directional equality, both Excel
entry points and the full file/Markdown/workbook/PNG path. This detects a stale
cached install even when the distribution version remains unchanged.

Recorded results:

| Check | Result |
| --- | --- |
| Original focused risk/chart/MCP baseline | 100 passed |
| Initial full agent and dashboard suite | 729 passed; four subtests passed |
| Publication full agent and dashboard suite | 730 passed; four subtests passed |
| Final focused risk/in-memory/chart/MCP suite | 113 passed |
| Four synthetic before/after datasets | All legacy evidence, Markdown, workbook XML and chart artifacts matched |
| Ruff lint and format; Git whitespace check | Passed |
| Wheel and source distribution | Built; archive contents checked |
| Fresh installed wheel | Twelve modules matched; imports, numerical analysis, reports and PNGs passed |
| Stricter workbook comparison after publication review | All 13 in-memory regressions passed |

The initial full-suite run preceded the final Object-column ownership regression.
The publication full-suite run and final focused run include that regression and
the resulting deep-copy fix; file-based preparation is unchanged by the fix.
Test runs emitted the existing LangChain MCP beta warning. Local runtime was
Python 3.12.12, Polars 2.0.0, NumPy 2.5.4, openpyxl 3.1.5 and Matplotlib 3.11.2.
Hosted CI and corporate/live
acceptance were not run.

Publication review compared the staged implementation against the same freshly
fetched `origin/main` baseline on two independent axes. Standards review found
no actionable violations or unnecessary abstractions. Requirements review found
no analytical or interface regressions. One test gap was corrected: the
maintained workbook comparison now normalizes only creation/modified timestamps,
preserving all other core metadata in the comparison. The 13 in-memory tests
were rerun after that refinement; no production changes were needed during review.
