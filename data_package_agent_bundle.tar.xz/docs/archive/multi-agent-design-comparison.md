# Multi-agent design comparison: Data-Package-Agent and mcp_agent_template

> Historical comparison, 13 October 2026. This describes the pre-integration
> source trees, including sequential defaults and missing runtime policies that
> have since changed. Recorded workstation paths and line numbers refer to those
> snapshots. Use the [development README](../../README.md),
> [agent runtime guide](../agent-prompts.md) and
> [recording/middleware guide](../observability.md) for current integration.

Donor names in this historical comparison use `mcp_agent_template` terminology.
Donor source references identify paths at the recorded commit, rather than files
in the current package.

Reviewed on **2026-10-13** against the local source trees:

- Data-Package-Agent: `P:/Alan/Github/Data-Package-Agent` (no Git metadata available).
- mcp_agent_template: `mcp_agent_template donor`, commit
  `782b3c03af3585458a555b958fe91dc7de821824`, with a clean working tree at inspection.

This compares implemented behavior, using source, current documentation, and existing test
definitions. It does not treat planned features as implemented. No benchmarks, test runs, or
authenticated model calls were performed; performance and cost tradeoffs below are architectural
inferences, not measured results.

## Overall assessment

**Data-Package-Agent favors simple, recursive composition. mcp_agent_template favors controlled execution
of concurrent work.** Both run native LangChain `create_agent` graphs backed by LangGraph; neither
implements a separate agent reasoning loop.

Data-Package-Agent is easier to understand and supports specialists that delegate to their own
specialists. mcp_agent_template has stronger request isolation, shared resource limits, cancellation,
structured results, and evidence delivery. Its current delegation topology is deliberately flat:
only the primary may delegate.

For a small, known hierarchy used interactively, Data-Package-Agent is a reasonable design.
For a reusable runtime handling overlapping requests, parallel tasks, or consequential tool
effects, mcp_agent_template is the stronger foundation. Nested delegation remains a real capability that
would be lost in a direct migration.

## 1. How the designs work

### Data-Package-Agent: specialists exposed as individual tools

`AgentSpec` describes an agent's children, capabilities, model, instructions, limits, and scheduling.
`build_agent_tree()` discovers one shared MCP tool catalog, recursively builds children before
parents, and exposes each child as an `ask_<name>(task)` tool. Each call starts a fresh child
conversation. The parent receives the final text; a separate tool artifact carries the child's
full message trace for inspection.

```mermaid
flowchart TD
    R[Root agent] -->|ask_researcher task| A[Researcher]
    R -->|ask_reviewer task| B[Reviewer]
    A -->|ask_catalog task| C[Catalog specialist]
    A --> T[MCP and skill tools]
    B --> T
    C --> T
```

The diagram represents an example allowed topology, not a shipped business workflow. The tree
is configured at build time; agents choose tasks and delegation calls at runtime. Ordinary
tool calls and delegation are sequential by default. Per-parent child concurrency applies only
after `allow_parallel_tool_calls=True` enables parallel tool decisions and execution.

Sources: [AgentSpec and tree builder](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:79),
[child tool and result capture](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:248).

### mcp_agent_template: one dispatcher and a registry of specialist profiles

`build_agent()` resolves trusted `AgentProfile` definitions, validates and compiles every enabled
specialist, and adds one `delegate_tasks(tasks)` tool to the primary. Each task selects a profile
and supplies a task key, goal, context, constraints, and expected output. A batch starts fresh
child invocations, queues excess work, waits for all outcomes, and returns them in input order.
Children cannot delegate.

```mermaid
flowchart TD
    R[Primary agent] -->|delegate_tasks batch| D[Invocation-owned child scheduler]
    D --> A[Fresh researcher invocation]
    D --> B[Fresh analyst invocation]
    D --> C[Fresh reviewer invocation]
    A --> O[Ordered outcomes with status, result, and evidence]
    B --> O
    C --> O
    O --> R
```

Profiles and graph templates are static at build time; task instances and batches are dynamic.
This is not dynamic creation of arbitrary agent roles. A single dispatcher call can run children
concurrently while ordinary tool calls remain sequential.

Sources: `primary and specialist construction`,
`dispatcher`,
`child scheduler`.

## 2. Comparison at a glance

| Dimension | Data-Package-Agent | mcp_agent_template |
| --- | --- | --- |
| Topology | Configured recursive parent/child tree. | Primary plus a flat specialist registry. |
| Model-facing delegation | One `ask_<name>` tool per child; one free-text `task`. | One `delegate_tasks` tool; structured batch briefings and profile selection. |
| Delegation policy | Prompt says matching specialties must be delegated. | Prompt favors direct work for simple tasks and delegation for substantial independent work. |
| Parallel children | Requires enabling parallel ordinary tool calls; per-parent sequential, parallel, integer, or custom wrapper. | Independent child capacity; parallel batches work with sequential ordinary tools. |
| Scheduling ownership | Semaphores captured by compiled graph middleware. | New ordering gates, child registry, and capacity per root invocation. |
| Aggregate limits | Approximate graph recursion limit per agent; child execution timeout. | Shared model/tool/admission budgets, root deadline, child timeout, and external-operation capacity. |
| Child results | Final text plus a full trace artifact on success. | Versioned statuses, text or validated structured values, evidence, and optional artifact references. |
| Failure reporting | Exceptions and timeouts become textual tool errors. | Explicit per-child outcomes; successful siblings and available partial evidence survive child failures. |
| Capability defaults | Omitted selections expose all discovered tools and skills. | Explicit specialists default to none; built-in `general` explicitly selects broad capabilities. |
| Construction | Single-agent and tree builders assemble graphs separately. | Roots and specialists share one node factory and required policy stack. |
| Memory | Fresh child conversations; no builder-level checkpointer/store options. | Optional native root persistence/store; children explicitly disable checkpointing. |
| Visibility | Nested notebook traces arrive with completed child tool results. | Live child events, bounded presentation, and optional complete redacted recording. |

The sections below explain these tradeoffs and their source evidence.

## 3. Data-Package-Agent: pros and cons

### Pros

- **Natural nested specialization.** A researcher can own narrower specialists without making
  the root manage every detail. Per-node tool and skill selections, instructions, models,
  timeouts, and concurrency make the hierarchy expressive.
- **Small delegation interface.** `ask_researcher(task)` is easy for a model and an application
  author to understand. A short tree definition provides considerable behavior with little setup.
- **Flexible scheduling seam.** A parent can use an integer capacity or supply a custom async
  wrapper for its delegation calls. mcp_agent_template's dispatcher offers a more prescribed scheduler.
- **Straightforward sequential reasoning.** The default policy keeps one requested tool call
  per model turn, letting the next decision use the previous result. This helps explain a
  small workflow, although it does not guarantee deterministic model answers.
- **Useful notebook inspection with few runtime requirements.** Successful child results carry
  full nested message traces. The parent model sees the answer rather than the entire trace.
  Message updates with the same ID replace earlier snapshots correctly.

Sources: [configuration and scheduling](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:79),
[one-call policy](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:154),
[nested trace rendering](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/notebook.py:412).

### Cons

- **Parallelism is coupled to a broad switch.** Enabling concurrent child calls also enables
  parallel ordinary tool calls throughout the tree. Nested fan-out has no root-wide child or
  external-operation capacity; each parent controls only its own delegation calls.
- **Separate requests can contend for the same gates.** Sequential middleware and child
  concurrency wrappers allocate semaphores when the graph is built. Reusing a compiled tree
  across overlapping requests therefore shares those gates. This is neither isolated request
  scheduling nor an explicitly configured application-wide quota.
- **No aggregate cost or duration contract.** Each agent gets its own recursion allowance, and
  each delegation gets an execution timeout. Repeated or nested calls can multiply total work.
  There is no shared model-call budget, tool-call budget, cumulative admission limit, or root
  deadline. Waiting for middleware capacity occurs outside the child tool's timeout.
- **Result and failure contracts are weak.** Successful results are unvalidated text; a child
  without a final text answer can return an empty success. On failure, captured partial
  messages are not returned as an artifact. The parent must interpret an error string rather
  than consume explicit status and evidence fields.
- **Maintenance locality is weaker than the public story suggests.** `build_agent()` and
  `build_agent_tree()` reuse helpers but independently assemble prompts, tools, middleware,
  and `create_agent`. The tree builder checks complete tool-name collisions; the single-agent
  builder has no equivalent explicit check. Skill discovery also repeats at each tree node.
- **Capability and lifecycle rules depend more on caller discipline.** Omitted allowlists grant
  all discovered capabilities. The builder always performs MCP discovery, even for a tree
  whose nodes select no MCP tools. The bundle provides no explicit owned invocation/close
  interface comparable to mcp_agent_template. Actual transport behavior depends on the MCP adapter;
  sharing an adapter object does not establish that one persistent subprocess serves all calls.

Sources: [build-time gates](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:67),
[child concurrency gates](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:135),
[child timeout and extraction](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:248),
[tree assembly](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:319),
[single-agent assembly](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:335).

## 4. mcp_agent_template: pros and cons

### Pros

- **Parallel work without parallel ordinary tools.** The primary submits one batch, and the
  scheduler runs children within a separate capacity limit. Each child keeps its own ordering
  gate. Delegation does not hold an external-operation permit while waiting, avoiding a
  parent/child capacity deadlock.
- **Explicit resource ownership.** A fresh `RunContext` isolates independent root requests;
  descendants share aggregate budgets and the root deadline. Admissions reserve a whole batch
  before starting children. The scheduler owns tasks and cancels and joins them on shutdown.
  MCP calls use explicitly closed isolated sessions, with invocation-owned sessions for process
  handles where reuse is necessary.
- **Stronger deliverable contract.** Each outcome distinguishes completion, failure, timeout,
  budget exhaustion, interruption, and cancellation. Native structured outputs preserve actual
  values, including false, zero, empty, and null results. Oversized structured results use a
  scoped artifact store when configured or fail explicitly rather than silently lose the result.
- **Evidence survives partial failure.** Outcomes separate model-authored summaries from tool
  observations and blocked operations. The primary can see useful evidence even when a child
  exhausts its budget. Optional stored evidence and diagnostic recording have separate meanings.
- **Better locality for policy and validation.** Root and child graphs use `build_node()` and
  the same required middleware. All enabled specialists are compiled and checked before the
  root is returned. Profiles are immutable definitions; tasks cannot rewrite their models,
  schemas, capabilities, or limits. `mcp_tools=[]` permits entirely local construction.
- **More deliberate context and visibility controls.** Explicit specialists default to no
  capabilities unless defaults grant them; tools can be registered for specialists without
  exposing them to the primary. Skill discovery is shared per canonical directory. Progressive
  schema exposure, bounded results, and live child events support larger catalogs and runs.
  Recording, when enabled, retains complete credential-redacted observations separately.

Sources: `shared budgets and child context`,
`execution policy`,
`owned scheduling`,
`MCP session ownership`,
`result delivery`,
`profile defaults`,
`shared factory`.

### Cons

- **No recursive delegation.** Specialists cannot own sub-specialists. The primary must flatten
  a hierarchy, brief later stages itself, and coordinate dependencies through successive batches.
  That can concentrate routing and synthesis work in the primary.
- **More concepts and configuration obligations.** Profiles, runtime contexts, policy,
  extensions, revision identities, evidence, artifacts, persistence, and recording make the
  Python interface substantially wider. Required revision declarations improve compatibility
  checks but add setup and maintenance work for custom models, tools, and hooks.
- **Batch completion waits for the slowest admitted task.** Live progress helps visibility, but
  the primary receives the batch result after all tasks finish or reach a terminal status.
  There is no first-result return, background supervision, or child continuation handle.
- **Fresh children are less suitable for continuing collaboration.** Each task starts a new
  history and needs a complete briefing. No automatic parent/sibling transcript transfer or
  child memory exists. Root checkpointing does not make child execution durable; replay can
  repeat child work and requires reconciliation of uncertain external effects.
- **Bounds introduce delivery tradeoffs.** Summaries and inline evidence may be shortened with
  omission metadata. Recovering complete evidence or large structured values requires a
  configured artifact store and remaining retrieval budget. Extra schema-search and retrieval
  calls also consume the shared budget. There is still no hard monetary or token-spend ceiling.
- **More operational interaction and overhead.** Every enabled specialist compiles at build
  time, including unused profiles. Ordinary stdio MCP calls open isolated sessions, which can
  add process startup latency. Budgets, authorization, retention, evidence, and recording require
  integration coverage. These costs are plausible from the design; their magnitude is unmeasured.

Sources: `builder and revision requirements`,
`batch waiting and outcome contract`,
`memory and current limitations`,
`transport lifecycle`.

## 5. Important qualifications

1. **Neither design is a peer-to-peer swarm.** Work flows through a parent or primary and
   returns through tool results. Neither provides direct sibling messaging or automatic worktrees.
2. **Fresh conversations do not isolate side effects.** Tools, model clients, and configured
   filesystem locations can be shared. Allowlists are not an OS sandbox. mcp_agent_template explicitly
   requires concurrency-safe injected dependencies and advises separate batches for conflicting
   writes; Data-Package-Agent also needs application-level discipline when parallelism is enabled.
3. **One dispatcher does not imply constant prompt size.** mcp_agent_template advertises profile
   descriptions, capabilities, and output contracts inside its dispatcher description. Its
   metadata can still grow with the specialist registry, despite using one delegation tool.
4. **Defaults affect routing differently.** Data-Package-Agent prompts mandatory delegation for
   a matching specialty, which can encourage unnecessary child calls for simple work. mcp_agent_template
   prompts direct handling of simple tasks. Both are model guidance rather than proof that the
   model will choose the best decomposition.
5. **Data-Package-Agent has two interface inconsistencies worth addressing.** Its
   `AgentBundle.all_tools` omits `extra_tools` even though graph construction registers them.
   Its CLI and server graph entrypoints call `build_agent()`, so they do not automatically use
   an `AgentSpec` tree. Applications must select `build_agent_tree()` explicitly.

Sources: `mcp_agent_template delegation guidance`,
[tree delegation guidance](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:173),
[Data-Package-Agent bundle](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:289),
[CLI](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/cli.py:20),
[server graph entrypoint](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/graph.py).

## 6. Which design fits which need?

| Need | Better fit | Reason |
| --- | --- | --- |
| Small interactive prototype with a known hierarchy | Data-Package-Agent | Compact declarations and nested delegation. |
| A specialist that coordinates its own specialists | Data-Package-Agent | Implemented recursive topology. |
| Multiple simultaneous requests on one reusable bundle | mcp_agent_template | Invocation-owned scheduling and budgets. |
| Independent parallel checks with sequential tool policy | mcp_agent_template | Child concurrency is separate from ordinary tool parallelism. |
| Typed outputs, partial failure recovery, or evidence inspection | mcp_agent_template | Explicit result, status, and evidence contracts. |
| Persistent root tasks with controlled tool effects | mcp_agent_template | Native persistence and effect-policy integration, with ephemeral-child caveats. |

**Recommendation for Data-Package-Agent:** use mcp_agent_template as the execution foundation if the package
is intended to grow into a shared application runtime. Configure profiles for the existing
specialist roles and keep genuinely dependent work in successive batches. Preserve corporate
provider and package configuration through explicit adapters; this comparison does not recommend
replacing those settings.

If nested delegation is an essential requirement, retain the tree topology and bring the strongest
runtime ideas into it: one shared node factory, invocation-owned gates, root-wide budgets and
deadlines, structured outcomes with partial evidence, and explicit transport cleanup. A nested
extension of mcp_agent_template would also need inherited budgets, owned descendant cancellation, and a rule
that delegating parents release capacity needed by their children; nesting cannot safely be added
by merely exposing `delegate_tasks` on every specialist.

## 7. Evidence and validation limits

Data-Package-Agent's inspected tests cover tree validation, wrapper concurrency, child tool
errors/timeouts, message replacement, and prompt injection. They do not construct and invoke a
complete multi-agent tree in `test_multi_agent.py`.

mcp_agent_template's inspected tests exercise real native graph composition with scripted models, including
parallel children under sequential tools, independent simultaneous roots, shared budgets,
cancellation on a continuing event loop, queue timeouts, structured outputs, and partial evidence.
This provides a broader regression design, but reading test definitions is not a fresh passing run.

- [Data-Package-Agent multi-agent tests](P:/Alan/Github/Data-Package-Agent/tests/test_multi_agent.py)
- `mcp_agent_template delegation tests`
- `mcp_agent_template child-runtime tests`
- `mcp_agent_template specialist-contract tests`
- `mcp_agent_template child-evidence tests`

The report's local source links and referenced line locations were checked. No source code,
dependencies, provider settings, or corporate configuration were changed. Answer quality,
latency, token usage, and real-provider reliability would require a controlled evaluation of the
same workloads on both designs.
