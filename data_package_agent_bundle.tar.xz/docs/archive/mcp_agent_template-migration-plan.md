# mcp_agent_template migration gap analysis and plan

> Superseded migration plan, 13–14 October 2026. This is a design record,
> not an active backlog or setup guide. Python, provider, tool and runtime
> statements below belong to the original snapshots. Use the
> [development README](../../README.md), [current guides](../README.md) and
> [recording/middleware guide](../observability.md) for the implemented system.

Implementation update (2026-10-13): the user approved Python 3.12, SQLite logging
and native middleware. That scope is implemented; see [current usage](../observability.md)
and [validation](../review/logging-middleware-validation-2026-10-13.md).
The comparisons below describe the original snapshot. Workspace/process tools,
shared skill caching, persistence and the later feature backlog remain proposed.

Implementation update (2026-10-14): context inspection helpers and their three
diagnostic MCP tools were removed. At that point the server had four example tools, and
the notebook catalog displays tool metadata without lint scores. Token-helper and
tool-linting proposals below are superseded; their source references describe the
historical snapshot only. Result-helper and runtime compaction proposals are separate.

Donor names in this historical analysis use `mcp_agent_template` terminology.
Donor source references identify paths at the recorded commit, rather than files
in the current package.

Analysis date: 2026-10-13. Scope: source-level comparison of the current Data-Package-Agent checkout with the local mcp_agent_template checkout. This document proposes migrations; it does not implement them or change runtime/configuration files.

Evidence shorthand: **T:** means P:/Alan/Github/Data-Package-Agent; **H:** means mcp_agent_template donor. References include repository-relative paths and one-based line numbers. Source behavior and existing test assertions were inspected; tests and authenticated provider invocations were not run for this documentation task.

## Recommendation and snapshot

Migrate mcp_agent_template mechanisms incrementally into this repository. The shared package name and agent stack make small ports practical, but a wholesale directory replacement would import a different provider, Python floor, configuration model, tool catalog, and delegation contract.

mcp_agent_template was inspected at clean Git HEAD **782b3c03af3585458a555b958fe91dc7de821824**. The target checkout has no Git metadata. The target contains 35 Python files under src/tests; mcp_agent_template contains 146, including 89 source files. These are inventory counts, not a measure of quality or test coverage.

The target already has native create_agent graphs, stderr logging, skill discovery/loading, child agent trees, single-call planning/execution policy, token estimation, description linting, and notebook traces with same-ID replacement. Its seven server tools are demonstration/diagnostic tools: ping, server_time, add, search_items, estimate_token_cost, inspect_payload, and generate_filler. mcp_agent_template adds operational capabilities around that same foundation ([T:agent/react_agent.py:335](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:335); [T:agent/multi_agent.py:319](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:319); [T:notebook.py:535](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/notebook.py:535); [T:mcp_server/tools/example_tools.py:47](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/mcp_server/tools/example_tools.py:47); [T:mcp_server/tools/context_tools.py:34](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/mcp_server/tools/context_tools.py:34); `H:docs/architecture.md:1`).

### First migration batch

| Priority | Candidate | Why it is easy to isolate | Proposed target change | Effort |
| --- | --- | --- | --- | --- |
| 1 | Credential redaction and owned stderr logging | Pure redaction uses stdlib/Pydantic already present; no recorder is needed. | logging_utils.py plus a small privacy module; configure managed entrypoints. | Low; adapt Python 3.11 logging |
| 2 | Complete tool-name validation | mcp_agent_template Counter-based validation is small; target tree already does most of it. | Share validation between build_agent and build_agent_tree before constructing graphs. | Low |
| 3 | One skill discovery per canonical directory | Skill loader source is already identical after newline normalization. Reuse factory caching logic. | Build-owned SkillCatalog shared by every tree node; resolve relative node paths consistently. | Low |
| 4 | Current-turn planning directive | A local history scan fixes reinjection for later user turns. | Both planning hooks; retain ephemeral model-input injection. | Low |
| 5 | Read-only workspace tools | Self-contained FastMCP functions using existing libraries. | New mcp_server/tools/workspace.py; register an explicitly supplied workspace. | Low for four read tools |
| 6 | HTTP helper ownership fixes | Close log handles, reap on failed startup/kill, centralize cleanup. | serve.py and its tests; graceful stdin shutdown is a separate entrypoint change. | Low for cleanup subset |
| 7 | Small token/result helper improvements | Independent utility changes without an agent-runtime dependency. | payload_stats(model=...); safe non-text placeholders while retaining existing dict-text support. | Low |
| 8 | Bounded incremental notebook view | Presentation logic can be ported without changing model/provider execution. | Keep notebook.py exports and ask_<name> artifacts; adapt mcp_agent_template update/throttle/eviction logic. | Medium |

Source basis: `H:logging_utils.py:14`; `H:observability/privacy.py:31`; `H:agent/factory.py:63,81`; `H:agent/runtime/middleware.py:31`; `H:mcp_server/tools/workspace.py:39,146`; `H:serve.py:52,95`; `H:context_lab/tokens.py:43`; `H:tool_results.py:10`; `H:notebook/stream.py:22`. Proposed target paths in this document do not yet exist unless explicitly identified as current files.

## Constraints and migration approach

- Preserve the target corporate package index, internal dependency URLs/pins, provider selection and adapters, and build/test/lint configuration. The target AGENTS.md explicitly prohibits configuration changes without a user request ([T:AGENTS.md:41](P:/Alan/Github/Data-Package-Agent/AGENTS.md:41)). New optional dependencies or settings are future implementation decisions, not changes made by this plan.
- Keep the target Python 3.11 floor. mcp_agent_template declares Python 3.12 and uses incompatible syntax/behavior, including a recursive PEP 695 type alias and replacement LogRecord filters ([T:pyproject.toml:6](P:/Alan/Github/Data-Package-Agent/pyproject.toml:6); `H:pyproject.toml:9`; `H:src/mcp_agent_template/agent/runtime/retention.py:13`; `H:src/mcp_agent_template/logging_utils.py:24`).
- Port individual mechanisms into the existing native create_agent construction seams. Both repositories already use native middleware; migrating a new agent loop is unnecessary ([T:src/mcp_agent_template/agent/react_agent.py:384](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:384); [T:src/mcp_agent_template/agent/multi_agent.py:427](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:427); `H:src/mcp_agent_template/agent/factory.py:206`).
- Use low/medium/high as relative effort: **low** is an isolated port using current dependencies; **medium** changes graph composition or invocation contracts; **high** introduces coordinated lifecycle/storage/resource subsystems. These are engineering estimates from source coupling, not measured delivery times.

### Compatibility gates

| Gate | Evidence | Migration implication |
| --- | --- | --- |
| Python syntax and runtime behavior | Target requires 3.11; mcp_agent_template requires 3.12. A 3.11 grammar scan rejects `H:agent/runtime/retention.py:13` and `H:mcp_server/execution/backends.py:23`. `H:logging_utils.py:24` relies on replacement records; `H:mcp_server/execution/manager.py:87` explicitly requires a Python 3.12 worker. | Translate PEP 695 aliases/generics and logging semantics; decide and test worker support separately. The grammar scan does not prove runtime compatibility. |
| Dependency interfaces | [T:pyproject.toml:12](P:/Alan/Github/Data-Package-Agent/pyproject.toml:12) declares FastMCP >=4.0.11, langchain[mcp] >=1.4.0, LangGraph >=1.2.11, httpx2. `H:pyproject.toml:11` declares FastMCP >=4.0.10, LangChain >=1.4.2, MCP >=2.2, OTel API and jsonschema. `H:agent/composition.py:17` imports httpx.Timeout. | Shared major versions reduce porting work, but resolved API compatibility is untested. Keep the existing MCPAdapter/httpx2 path initially. Review any direct MCP/httpx/OTel/jsonschema imports before approving dependencies. |
| Corporate model configuration | Target supports genai_manager and socgenai_llm; mcp_agent_template defaults to DeepSeek ([T:llm/genai_manager.py:66](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/llm/genai_manager.py:66); [T:config.py:31](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/config.py:31); `H:config.py:50`). | Keep the target model factory and both adapter contracts. Do not copy mcp_agent_template config.py, llm/, pyproject.toml, uv.lock, or provider-specific evaluation defaults wholesale. |
| Windows execution | `H:mcp_server/execution/manager.py:48` rejects shell execution outside POSIX. Python uses Windows Job Objects, and backends.py:23 also has a 3.12 syntax dependency. | Workspace/plan ports are suitable early Windows work. execute_command cannot be enabled on this Windows host unchanged. Python execution requires the coherent process/runtime/session stack. |
| Existing delegation contract | Target permits nested AgentSpec trees and ask_<name> tools. mcp_agent_template uses foreground delegate_tasks with precompiled profiles and nondelegating children ([T:agent/multi_agent.py:79,319](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:79); `H:agent/react_agent.py:66`). | Reuse budgets/provenance concepts while preserving existing trees. A move to the mcp_agent_template delegation model is a separate behavior migration. |

## Logging and observability gap analysis

The target already has useful logging: RichHandler sends logs to stderr, setup is guarded, and agent/model/server/skill modules emit operational messages. Its HTTP helper also redirects child stdout/stderr to a log file. The gap is redaction, invocation correlation, recorded evidence, and explicit ownership, rather than a missing logger ([T:src/mcp_agent_template/logging_utils.py:17](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/logging_utils.py:17); [T:src/mcp_agent_template/agent/react_agent.py:349](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:349); [T:src/mcp_agent_template/serve.py:95](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/serve.py:95)).

| Area | Current target | mcp_agent_template capability and source | Recommended migration | Effort |
| --- | --- | --- | --- | --- |
| Stderr logging and embedding ownership | Rich stderr logging exists. Library agent/tree/server builders call setup_logging; the global configured flag is process-owned. | Entrypoints own setup; existing host root handlers are respected, optional console/console-level injection is supported, and managed FastMCP/Uvicorn loggers propagate through one filtered handler. `H:logging_utils.py:35`; `H:mcp_server/server.py:80`. | Keep the target logger API; move setup to CLI/server entrypoints, allow explicit console injection, and apply propagation rules only to managed processes. | Low |
| Credential redaction | No credential filter or structured redactor in logging_utils. Rich tracebacks are enabled. | Redactor handles secret-key fields, environment secret values, bearer/basic auth, URL credentials, exceptions, binary payloads, Pydantic/native data, and records redacted paths. `H:observability/privacy.py:21,35,50,57`. | Port the pure redactor and a Python 3.11-compatible owned handler that copies/sanitizes records and exception text before rendering. Do not copy the 3.12 replacement-filter behavior unchanged. | Low |
| Run/model/tool correlation | Messages and nested child artifacts can be viewed, but the bundle config only installs a recursion limit; there is no target recording scope or capture callback. [T:agent/react_agent.py:310](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:310); [T:agent/multi_agent.py:274](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:274). | ContextVars separate runtime, scope, tool, model round, and request IDs; invocation-owned callbacks preserve native run/parent IDs. `H:observability/context.py:11,36`; `H:observability/capture/callbacks.py:31,39`. | Start with opt-in invocation IDs and callback ownership in AgentBundle. Propagate child scope/config explicitly; preserve user-supplied callbacks. | Medium |
| Model/tool capture middleware | Target middleware changes planning and execution, without dedicated capture stages. | ObservationMiddleware records rounds/tool outcomes; RequestObservationMiddleware identifies retry attempts; EffectiveRequestMiddleware records the request immediately before model dispatch. `H:observability/capture/middleware.py:49,82,90`. | Adopt capture separately from execution policy, after the common factory seam exists. Capture requested/effective/native stages honestly; callbacks do not observe the provider HTTP body. `H:observability/capture/callbacks.py:63`. | Medium |
| Local durable telemetry | Operational log output and notebook traces; no observability package/SQLite recorder. | LocalStore records processes, runs, events, logs, captures, spans and metric points; explicit health, flush, writer-failure handling and read-only queries. `H:observability/recording/storage.py:18,54,86,109,233`. | Introduce storage as an explicit optional subsystem with temporary-directory tests. Add runtime lifecycle ownership before attaching log/callback/capture sinks. | High end-to-end; storage alone medium |
| Usage and timing | Target provider messages already expose usage metadata; no central aggregation is installed. [T:tests/test_genai_manager_model.py:469](P:/Alan/Github/Data-Package-Agent/tests/test_genai_manager_model.py:469). | Native callbacks aggregate usage once, preserve missing/partial coverage, measure first visible content/tool/reasoning output and duration. `H:observability/capture/callbacks.py:18,71,90,117`. | Reuse the aggregation rules and verify them against the existing corporate adapter contract. Missing usage must remain unknown, not become zero. | Medium after recording scope |
| Inspection/export | No recorder inspection CLI. | Read-only CLI exports JSON/JSONL and reports recording status; cost estimation is offline with an explicitly supplied price table. `H:observability/cli.py:25,84,104`. | Add inspection/export only after the storage schema is stable. Avoid coupling the first logging improvement to a dashboard. | Medium after recorder |
| Shutdown and cancellation | CLI directly calls bundle.ask; server has no recorder lifecycle to flush. [T:agent/cli.py:20](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/cli.py:20); [T:mcp_server/server.py:51](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/mcp_server/server.py:51). | Recorder startup/close joins owned background work despite repeated cancellation; stream context is detached while yielding to the consumer; server HTTP lifespan closes recording. `H:observability/recording/runtime.py:59,163,358,549`; `H:observability/capture/server.py:6`. | Add explicit async context manager/close to bundle and entrypoints; cancellation must re-raise after cleanup. Include early stream close and failed partial startup. | Medium/high with recorder |

Table source paths without the package prefix mean src/mcp_agent_template/ beneath the indicated H:/T: repository.

### Important adoption details

**Python 3.11 logging compatibility.** mcp_agent_template CredentialFilter copies and returns a replacement LogRecord. Its source explicitly relies on Python 3.12 behavior. A direct copy on the target floor would not provide the intended handler-local replacement. Prefer a managed handler that copies and sanitizes the record before forwarding it to RichHandler. Test real handler output and host-handler isolation; the mcp_agent_template unit test invokes the filter directly and is insufficient by itself to validate Python 3.11 logging integration (`H:src/mcp_agent_template/logging_utils.py:24`; `H:tests/observability/test_inspection.py:75`).

**Do not import the entire observability graph for basic redaction.** The mcp_agent_template logging filter imports observability.context, which imports opentelemetry.trace. The target does not declare OpenTelemetry. The redactor itself uses stdlib plus existing Pydantic, so keep the initial logging port independent of OTel. Full capture needs opentelemetry-api and local recording needs the optional SDK; new dependency/configuration changes require a separate implementation request (`H:src/mcp_agent_template/logging_utils.py:16`; `H:src/mcp_agent_template/observability/context.py:9`; `H:src/mcp_agent_template/observability/privacy.py:19`; `H:pyproject.toml:20,25`; [T:pyproject.toml:12](P:/Alan/Github/Data-Package-Agent/pyproject.toml:12)).

**Credential redaction is narrower than corporate data redaction.** mcp_agent_template mode is full_redacted, defaults to local recording, and intentionally stores complete payloads without truncation/sampling/automatic deletion. Its redactor identifies credentials, not arbitrary confidential business content. Do not inherit that default silently for the corporate target. Define the target capture policy, application-root-relative output directory, and disk/queue monitoring before enabling full recordings. The store uses an unbounded queue; this preserves evidence but creates disk/memory pressure under sustained load (`H:src/mcp_agent_template/observability/config.py:11`; `H:src/mcp_agent_template/observability/privacy.py:21`; `H:src/mcp_agent_template/observability/recording/storage.py:55,60,101`).

**Provider coverage remains explicit.** mcp_agent_template callbacks record native messages and exposed invocation parameters, and label the provider HTTP body not_observed. Keep the target corporate GenAI adapter intact and test available usage/reasoning/tool metadata rather than claiming wire-level request capture. Callback cleanup also preserves an unknown model completion when cancellation prevents a native terminal callback (`H:src/mcp_agent_template/observability/capture/callbacks.py:63,159`; `H:tests/observability/test_requests.py:251`; [T:tests/test_genai_manager_model.py:469](P:/Alan/Github/Data-Package-Agent/tests/test_genai_manager_model.py:469)).

## Middleware design gap analysis

Three layers should stay distinct:

1. **Agent execution policy:** native AgentMiddleware that changes model inputs, tool-call selection, budgets, context or retained results.
2. **Agent observation:** wrappers/callbacks that record requests, results and waits without deciding execution policy.
3. **MCP/HTTP boundaries:** embedded framework dispatch and ASGI lifespan handling, which are transport/lifecycle mechanisms, not replacements for agent middleware.

The target already supplies planning, after-model single-call trimming, and async/sync tool serialization; its tree builder also supports child-only concurrency wrappers ([T:src/mcp_agent_template/agent/react_agent.py:77,101,117,133](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:77); [T:src/mcp_agent_template/agent/multi_agent.py:135](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:135)). mcp_agent_template separates policies into named classes and installs one ordered factory stack, including application extensions and reserved-name validation (`H:src/mcp_agent_template/agent/factory.py:46,55,176`; `H:src/mcp_agent_template/agent/composition.py:24`).

| Candidate | Gap and benefit | Source -> proposed target | Effort and dependency notes |
| --- | --- | --- | --- |
| Common composition seam and extension validation | Single-agent and tree construction repeat create_agent wiring. Share required middleware order and reject application name/tool collisions before building either graph. | `H:agent/factory.py:46,55,63,176` and `H:agent/composition.py:24` -> new T:agent/factory.py plus both existing builders. | Medium. Port the seam/validation, not the entire mcp_agent_template factory, which imports authorization, catalog/loading, artifacts, persistence and capture systems. The target tree already validates its combined tool namespace; keep that behavior. [T:agent/multi_agent.py:391](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:391). |
| Current-turn planning directive | Target planning checks whether any AIMessage exists in all history; guidance will not reinject for a later user turn when history is passed to the native graph. mcp_agent_template scans only since the latest HumanMessage and injects ephemerally. | `H:agent/runtime/middleware.py:31` -> [T:agent/react_agent.py:181](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:181) and [T:agent/multi_agent.py:173,](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:173) or a shared new planning class. | Low. Adapt the history scan; do not require observation emit or RunContext merely to fix planning. |
| Invocation-owned ordering | Target semaphore/lock is created when middleware is built, so independent requests sharing a graph can contend on the same gate. The tree child-concurrency wrapper also captures a shared semaphore. mcp_agent_template ordering belongs to a fresh RunContext. | `H:agent/runtime/context.py:81,97,149` and `H:agent/runtime/middleware.py:152` -> new slim T:agent/runtime/context.py, bundle invocation methods and serialization middleware. | Medium. Fresh root context per run; children receive deliberate shared budget/own ordering. Preserve or explicitly document the target's existing synchronous middleware behavior. |
| Exact round limits | Target max_iterations maps to an approximate recursion limit, and callers may override config. mcp_agent_template counts tool rounds in the current user turn, rejects the next round before side effects, and allows the final answer. | `H:agent/runtime/middleware.py:55` -> [T:agent/react_agent.py:154,310](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:154) and shared factory. | Medium. Retain the native recursion limit as a safety bound; do not treat it as the business budget. Remove mcp_agent_template child-evidence/capture dependencies from a minimal port. |
| Shared tool/model budgets and root deadline | Target has recursion limits and child-call timeout, without root-wide reservations across descendants or bounded external operation capacity. mcp_agent_template reserves before effects and distinguishes model/tool budget, ordering and capacity. | `H:agent/runtime/context.py:45,81,162`; `H:agent/runtime/middleware.py:119,152` -> slim runtime context, bundle and child wrapper. | Medium/high. Parent delegation must not hold a capacity permit while waiting for a child that needs that permit. Full source also couples to policy, evidence, persistence and process ownership. |
| Result retention | Target nested child artifacts can retain full traces; no global native-output boundary caps tool messages/artifacts. mcp_agent_template preserves IDs/status and normalizes ToolMessage/list/Command output shapes. | `H:agent/runtime/retention.py:25,49` and `H:agent/runtime/middleware.py:264` -> new T:agent/runtime/retention.py and result wrapper. | Medium. Rewrite the Python 3.12 type alias for 3.11. Apply retention after trusted transforms; capture original/transformed/effective output before reducing model-facing data. |
| Context window protection | Context token utilities exist, without runtime message-window management. mcp_agent_template protects message groups/current user turn, supports context policy/compaction and model profile limits. | `H:agent/runtime/context_policy.py:94,221,263` -> optional future T:agent/runtime/context_policy.py. | High for full compaction. Depends on compaction grouping, instruction injection, context state, model budgets and observability. A narrow native message-trimming policy is a smaller independent first step. |
| Authorization/effect recovery | mcp_agent_template policy checks, principal context and persisted operation effects are additional controls, not generic logging wrappers. | `H:agent/runtime/authorization.py`; factory stack at `H:agent/factory.py:190`. | High. Design around actual target tools/effects and persistence; defer blanket adoption until those needs exist. |

The complete mcp_agent_template stack is not a collection of independent drop-in decorators: ToolExecutionMiddleware reaches context, authorization, child evidence, progress, persistence and process waiters, while ResultRetentionMiddleware reaches artifacts and child evidence. Extract a minimal coherent policy layer first (`H:src/mcp_agent_template/agent/runtime/middleware.py:18,175,184,224,273`).

## Tools and supporting capability gaps

mcp_agent_template has eleven optional standalone workspace/process/Python/plan tool names and five runtime-dependent framework tool names. Its normal server enables no tool groups by default. Copy tool implementations into the target registration style rather than adopting that catalog/default policy automatically; target MCP tests currently require demo tools (`H:mcp_server/server.py:39`; [T:mcp_server/server.py:35](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/mcp_server/server.py:35); [T:tests/test_mcp_server.py:15](P:/Alan/Github/Data-Package-Agent/tests/test_mcp_server.py:15)).

### MCP tool inventory and migration mapping

| mcp_agent_template tool(s) | Current target equivalent | Source -> proposed target | Migration assessment |
| --- | --- | --- | --- |
| list_directory, find_files, read_file, search_files | None. search_items returns synthetic catalog results, not workspace search. | `H:mcp_server/tools/workspace.py:146` -> new file at the same relative package location; register in target server.py. | **Low.** Construct Workspace from an explicitly supplied root. Keep path containment, UTF-8 checks, symlink policy, sorted paging and long-line cursors. No mcp_agent_template RunContext/recorder is needed. |
| write_file, apply_patch | None. | `H:mcp_server/tools/workspace.py:89,234` -> same workspace module. | **Low/medium.** Keep SHA-256 conflict checks, exclusive creation, locks and atomic replacement together. Verify Windows and the deployment filesystem; annotations alone do not authorize writes. |
| update_plan | Planning hooks inject instructions, but store no structured task progress. | `H:mcp_server/tools/plan.py:12,24` and `H:agent/runtime/plan.py:21` -> new tool plus native plan middleware/state. | **Low for validation handler; medium end-to-end.** Successful structured results must reach ToolMessage.artifact, metadata must survive MCP adaptation, and Command must preserve result/call ID. Invalid updates leave state unchanged. |
| execute_command | None. | `H:mcp_server/tools/processes.py:43` plus execution/manager.py and backends.py -> future process subsystem. | **High on this host.** /bin/sh is POSIX-only. A PowerShell adapter would be new implementation work, not an easy copy. Requires owned processes, invocation sessions, deadline/capacity policy and cleanup. |
| execute_python | None. | `H:mcp_server/tools/python.py:13` plus execution/{manager,backends,windows}.py -> same relative modules after compatibility adaptation. | **High end-to-end.** Direct source delivery and Windows Job ownership are useful; the tool function alone is insufficient. Worker validation currently requires 3.12. Fresh interpreter per call, not a persistent REPL. |
| read_process, cancel_process | None. | `H:mcp_server/tools/processes.py:68,81`; `H:agent/runtime/mcp_sessions.py:11` -> process tools plus invocation-owned transport. | **High with execution.** Ownership metadata is hidden from model arguments; process handles cannot cross root/child scopes. Keep independent stdout/stderr offsets, timeout, cancellation and reaping behavior. |
| load_skill | Existing local load_skill and list_skills tools. | `H:mcp_server/tools/skills.py:12`; `H:agent/framework_mcp.py:25`; `H:mcp_server/runtime.py:72` -> optional embedded MCP bridge. | **Low for content policy; medium for changing transport.** Existing loader already works. mcp_agent_template exposes no skill tools for an empty catalog and returns complete instructions or a clear size error. Preserve list_skills unless its removal is explicitly part of the migration. |
| search_tools | All discovered schemas are exposed eagerly; no dynamic search/exposure. | `H:agent/tool_catalog.py:48,71`; `H:agent/runtime/tool_loading.py:36`; `H:mcp_server/tools/discovery.py:22` -> new catalog/exposure/discovery modules. | **Medium/high.** Useful once the real catalog is large. Selection belongs to invocation/state, while the native executor retains the complete authorized catalog. Requires namespace/policy/context-budget integration. |
| delegate_tasks | ask_<name> tools already delegate to a nested tree. | `H:mcp_server/tools/delegation.py:79`; H:agent/delegation/{profiles,runtime,evidence}.py -> optional new delegation interface. | **High; defer replacement.** Batch outcomes, typed child evidence and shared budgets are valuable, but the root/profile scheduling model differs. Port individual protections into existing child wrappers first. |
| read_artifact, search_artifact | Nested ToolMessage.artifact exists for traces; no scoped retrievable artifact store/tools. | `H:agent/artifacts.py:22` and `H:mcp_server/tools/artifacts.py:15` -> future evidence store/tools. | **Medium/high.** Add complete scoped application evidence when large tool/child results require retrieval. Depends on run ownership, retention and trusted framework binding; diagnostic SQLite is not the artifact store. |

The standalone six workspace tools and update_plan are the best tool ports. Runtime-dependent skill/discovery/delegation/artifact handlers use an embedded FastMCP server and a trusted ToolRuntime binding; they cannot be copied into the current standalone server and expected to control an agent invocation. The binding preserves native failure/cancellation/Command semantics outside model-visible arguments (`H:agent/framework_mcp.py:25`; `H:mcp_server/runtime.py:30,46,72`; `H:docs/framework-mcp-tools.md:1`).

### Other reusable designs

| Area | Actual gap | Proposed migration and source | Effort |
| --- | --- | --- | --- |
| Shared factory and explicit catalogs | Single and tree builders repeat assembly; neither accepts an explicit MCP catalog to bypass discovery. Tree namespace validation exists, single-agent validation does not. | Extract validate_tools and a small build_node interface. Allow mcp_tools=None for discovery and mcp_tools=[] for local-only construction in both paths (`H:agent/factory.py:63,105`; `H:agent/react_agent.py:46`; [T:agent/react_agent.py:349](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:349); [T:agent/multi_agent.py:391](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:391)). | Low for validation; medium for factory/catalog interface |
| Skill discovery ownership | Target loader is already the same normalized source, and Skill is already frozen. Tree nodes rescan directories; relative spec.skills_dir uses process cwd. | Adopt `H:agent/factory.py:81` caching/selection. Use one immutable catalog per canonical application path per build; empty skill selection skips discovery ([T:skills/loader.py:16](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/skills/loader.py:16); [T:agent/multi_agent.py:354](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/multi_agent.py:354)). | Low |
| Application-root and settings propagation | Target derives root from package __file__. Stdio inherits env but does not serialize caller Settings; HTTP only forwards transport/host/port. | Adapt `H:config.py:31,183,188` path/env methods and `H:serve.py:95`. Preserve target corporate fields/defaults; add only explicitly approved root/options. Test installed-package paths and child settings, not just editable checkout ([T:config.py:17](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/config.py:17); [T:agent/react_agent.py:254](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:254); [T:serve.py:87](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/serve.py:87)). | Medium; configuration change requires explicit request |
| MCP transport ownership | MCPAdapter performs discovery/calls, but repo code does not define its lifecycle contract or bundle cleanup. This is an ownership gap, not evidence that the adapter leaks. | First test existing adapter success/failure/cancellation. Borrow isolated session cleanup from `H:agent/mcp_client.py:103` only where needed. Process tools separately require H:agent/runtime/mcp_sessions.py. Preserve HTTP timeout meanings/httpx2 ([T:agent/react_agent.py:243](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:243)). | Medium; process sessions high |
| HTTP process/log ownership | Parent log handle is opened without a closing context; failed startup/kill paths do not consistently wait/reap; context manager duplicates cleanup. | Port the isolated `H:serve.py:52,75,95` resource patterns into [T:serve.py:52,71,131](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/serve.py:52). Forward typed settings later. Graceful EOF shutdown also needs `H:mcp_server/__main__.py:19`. | Low cleanup; medium full helper |
| Notebook/CLI traces | Notebook already replaces same-ID messages, but iterates full values history and retains all cards. CLI prints final answers only. | Port bounded delta rendering, native removal handling, refresh throttling and final flush from `H:notebook/stream.py:22`; later adapt `H:agent/cli/trace.py:20,220`. Keep target reasoning rendering and child artifact shape ([T:notebook.py:535](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/notebook.py:535); [T:agent/cli.py:20](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/cli.py:20)). | Medium |
| Native persistence and memory | Bundle accepts config but builder does not expose checkpointer/store. Default calls begin fresh histories. | First expose native injected checkpointer/store through common construction; then consider `H:agent/persistence.py:45` and `H:agent/memory.py` for durable task/resume/memory contracts. Keep logs/evidence/resources separate from conversation memory ([T:agent/react_agent.py:321,384](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/agent/react_agent.py:321)). | Medium native wiring; high durable recovery |
| Project instruction context | No runtime application-root instruction snapshot is injected into built agents; repository AGENTS.md instructions for the coding assistant do not provide that runtime feature. | Adapt immutable opt-in snapshot/loading from `H:agent/instructions.py:30,82,131,` replacing its authorization.digest/emit dependencies as appropriate. Keep complete UTF-8 content, explicit source identity and precedence; do not let file text grant execution permissions. | Medium |
| Structured outputs and application extensions | Target builders accept model/tools but expose no middleware/state/context/response-format interface. | Reuse `H:agent/composition.py:24` validation principles after common factory. Preserve native message reducer, reserve required middleware names, include middleware-generated tool names in validation. Verify corporate model capabilities without editing its adapter. | Medium |
| Context and token utilities | Token estimation and tool linting already exist. Linter differs only in its docstring; payload_stats only lacks the mcp_agent_template optional model argument. | Retain existing modules; add the small model argument if useful ([T:context_lab/tokens.py:43](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/context_lab/tokens.py:43); `H:context_lab/tokens.py:43`). Dynamic trimming/compaction is the larger runtime feature described above. | Low utility; high compaction |
| Tool result extraction | Target handles a direct dict with text; mcp_agent_template removes that case and adds non-text block placeholders. | Port only the safe placeholder behavior, preserving target dict support and tool_json fallback ([T:tool_results.py:16](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/tool_results.py:16); `H:tool_results.py:10`). | Low |
| Read-only dashboard | No dashboard; mcp_agent_template dashboard is stdlib/vanilla JS and reads the recorder schema. | Copy dashboard/ only after compatible recorder/schema/export exist. Keep it outside the runtime package; verify schema/read-only/live-WAL behavior (`H:dashboard/README.md:1`; `H:dashboard/records.py`). | Low code coupling; medium after recorder, no immediate value before it |
| Evaluation and test support | Target has unit/provider/stdio tests but no scenario/evaluation pipeline. | Reuse scripted models/local MCP fixture patterns from H:tests/support and failure/concurrency suites. H:evals has a separate Python 3.13 environment and a mcp_agent_template-specific adapter/DeepSeek judge; adapt suites and corporate provider integration rather than production dependencies (`H:evals/pyproject.toml:5`; `H:evals/mcp_agent_template_adapter.py:35`; `H:evals/README.md:1`). | Low test-pattern reuse; high complete eval application |

Neither the target demo catalog nor mcp_agent_template workspace/execution tools implement a data-package-specific ingestion, validation or packaging workflow. These migrations provide reusable infrastructure; domain tools and their data contracts still need separate requirements ([T:mcp_server/tools/example_tools.py:83](P:/Alan/Github/Data-Package-Agent/src/mcp_agent_template/mcp_server/tools/example_tools.py:83); `H:mcp_server/server.py:39`).

## Logging and middleware dependency order

1. **Logging foundation:** port the pure redactor; provide Python 3.11-safe sanitized stderr rendering; move setup to entrypoints. Keep corporate adapters/dependencies intact. Deliver acceptance tests for actual emitted log/traceback content and embedding isolation.
2. **Shared middleware seam:** factor common native graph construction while preserving existing prompts/tools/tree API; validate complete namespaces and required/application middleware names. Bring over current-turn planning without pulling in the mcp_agent_template runtime.
3. **Invocation policy:** introduce fresh root invocation context and deliberate child propagation; replace shared middleware gates; enforce tool-round limits. Then add reservation budgets/deadline/capacity if the implementation scope authorizes the required new options.
4. **Native result retention:** cap model-facing messages/artifacts at one boundary with accurate omission markers; preserve native IDs, status and Command semantics. Keep complete diagnostic evidence separately when capture is enabled.
5. **Optional recording foundation:** decide corporate capture policy and local paths; introduce explicit recorder lifecycle, storage health and Python-compatible optional dependencies. Do not enable full capture before redaction and shutdown behavior pass.
6. **Capture and inspection:** wire task-local scopes, native callbacks, ordered round/request/effective capture and child propagation; add JSON/JSONL inspection/export. Verify retries, streaming usage and partial coverage against the existing corporate provider contract.
7. **Advanced policies:** context compaction, persisted effects and integrated process-aware capacity are separate larger projects with their own contracts; do not bundle them into the quick logging migration.

## Acceptance tests to bring over or adapt

These tests are implementation gates for future migration work, not results already obtained in the target. Use scripted models, temporary directories and real local MCP transports; no credentials are needed for the default tests.

| Migration | Required observable behavior | mcp_agent_template test references |
| --- | --- | --- |
| Logging/redaction | Logging and exceptions redact synthetic secrets in actual stderr output; stdout remains valid JSON-RPC. Existing host handlers receive their original records; repeated setup does not add duplicates. Run on Python 3.11. | `H:tests/observability/test_inspection.py:75`; `H:tests/observability/test_capture.py:80`; extend beyond the direct filter test. |
| Planning | Each user turn with retained history gets one ephemeral directive, and it is absent from persisted conversation state. Same behavior through single and tree builders. | `H:tests/agent/test_agent_runtime.py:223`. |
| Namespace/factory | Single and tree builders reject duplicate ordinary/skill/child/middleware/structured tool names before graph construction. Local/empty supplied catalog avoids MCP discovery. | `H:tests/agent/test_agent_composition.py:35,52`. |
| Ordering/budgets | Independent root invocations overlap; calls within a sequential root remain ordered. No tool starts beyond its round/shared budget; final answer remains possible. Child budget cannot exceed root allocation. | `H:tests/agent/test_run_limits.py:30,62`; `H:tests/agent/test_agent_runtime.py:61,129`. |
| Cancellation/deadlines | Cancel running and waiting tools on a continuing event loop; all permits/resources close, CancelledError survives, and the next invocation succeeds. Parent-to-child capacity does not deadlock. | `H:tests/agent/test_run_limits.py:133,175`; `H:tests/observability/test_lifecycle.py:69`. |
| Retention | Preserve IDs/status/non-message Command updates for ToolMessage, list and Command outputs. Mark reductions explicitly; full capture precedes model-facing caps. | `H:tests/agent/test_retention_shapes.py`; `H:tests/observability/test_capture.py:23`. |
| Scope isolation/capture | Simultaneous root sessions never mix logs/usage. Consumer work between streamed yields is not attributed to the agent. Retry overrides get separate effective-request identities. Unknown usage/outcomes remain explicit. | `H:tests/observability/test_lifecycle.py:26,51`; `H:tests/observability/test_requests.py:131,251`. |
| Recorder failures/shutdown | Disk/write/serialization failures report degraded/partial telemetry without changing a valid agent answer. Flush and shutdown settle threads/handlers through partial startup and repeated cancellation. | `H:tests/observability/test_storage.py:18,73`; `H:tests/observability/test_capture.py:132`; `H:tests/observability/test_startup_ownership.py:20,57,88`. |
| Real MCP propagation/export | Stdio and HTTP tool execution are correlated with client/server records; normal shutdown flushes valid JSON/JSONL exports and reports completeness honestly. | `H:tests/observability/test_lifecycle.py:139`; `H:tests/observability/test_inspection.py:33`; `H:tests/presentation/test_cli_shutdown.py:34`. |

During implementation, keep the target test layout and Ruff configuration, preserve its provider contract tests, and run its documented pytest/lint/format checks for the final change. Do not copy mcp_agent_template's DeepSeek settings, dependency floors or validation configuration into the corporate target.

Additional acceptance gates for tools and supporting designs:

| Work item | Acceptance check | Donor tests to adapt |
| --- | --- | --- |
| Workspace read/write tools | Escape/symlink rejection; UTF-8/binary handling; stable pagination and lossless long-line cursors; exclusive create; stale hash rejection; no partial writes after a failed multi-replacement patch; concurrent writes on supported Windows filesystem. | `H:tests/mcp/test_workspace_tools.py:16,53,75` |
| Plan handler and native state | One active step, unique steps, clear plan, failure leaves state untouched; parallel updates resolve by native call order; root/child isolation; optional same-thread checkpoint restore. Check real MCP metadata/structured-content propagation before installing middleware. | `H:tests/agent/test_mcp_plan.py:17,51,63` |
| Server/transport ownership | Log handle closes after success or failed spawn; readiness exceptions reap children; kill escalation waits; occupied-port shutdown is explicit. Adapter discovery/calls close on errors/cancellation while the loop continues; test stdio and HTTP. | `H:tests/mcp/test_serve.py:45,65,81,101,116,128`; `H:tests/mcp/test_mcp_lifecycle.py:96,195` |
| Skill/factory composition | One discovery for canonical path aliases; independent builds do not share selection; empty selection skips discovery; duplicate namespaces rejected consistently; explicitly empty MCP catalog makes no connection. | `H:tests/agent/test_agent_composition.py:35,52,99,139,149,169` |
| Presentation | Bounded top-level/nested cards, same-ID replacement, native message removals, linear work for deltas, refresh throttling, final flush on failure/cancellation, unchanged child artifacts not rerendered. | `H:tests/presentation/test_notebook_trace.py:66,89,116,153,184,201,233` |
| Python/process capability, if selected | Real Windows Job assignment/failure, descendant cleanup after parent exit, cancellation during launch/source delivery, interpreter/source validation, deadlines including startup, cross-owner denial and budget permit release. | `H:tests/mcp/test_python_tools.py:126,166,196,221,238,284,301`; `H:tests/agent/test_process_ownership.py` |

## Phased migration backlog

All items below are **proposed and not implemented**. Relative effort includes adapting tests, but excludes corporate access/dependency approval lead time. Complete each stage as a focused, reviewable change; independent low-effort utilities can be separate changes.

| Stage | Scope and concrete deliverable | Prerequisites | Relative effort | Exit condition |
| --- | --- | --- | --- | --- |
| P0: establish baseline | Record current dependency resolution through the corporate index; run current tests/lint; restore the declared README; replace absent bundled-skill test inputs with temporary fixtures or restore the intended bundles. Record existing failures before migration. | Existing package access; explicit request for any configuration changes. | Low | Existing failures are understood; provider tests preserved; build has its required README. |
| P1: isolated foundations | Redactor and Python 3.11-safe managed logging; complete namespace validation in both builders; canonical skill discovery cache; per-user-turn planning fix; optional payload_stats/non-text helper improvements. | P0; no new external dependency required for the narrow ports. | Low per item | Actual stderr redaction, embedding isolation, planner/namespace/cache behavior tests pass. |
| P2: practical tools and cleanup | Register four read-only workspace tools; then guarded write/patch if selected. Fix HTTP helper log/child ownership. Supply explicit root through composition; only add Settings fields if requested. | P1; agreed workspace root and supported deployment filesystem. | Low/medium | Real FastMCP workspace operations and startup/shutdown failure tests pass; existing demo catalog remains intentionally handled. |
| P3: common factory and invocation policy | Extract shared node construction, explicit catalog injection and application middleware validation. Add slim invocation context, fresh ordering gates, exact round counting and root/child budget/deadline propagation. Keep existing tree public behavior. | P1; agree asynchronous/synchronous behavior and any new runtime options. | Medium | Concurrent independent roots, sequential intra-root calls, shared descendant budgets and cancellation pass through both builders. |
| P4: plan, retained results and traces | Wire update_plan into native state; add result/trace retention and incremental bounded notebook display. Pass through injected native checkpointer/store if selected. | P2/P3; verified MCP artifact/metadata contract; Python 3.11 retention adaptation. | Medium | Plans restore/clear correctly when persistence is supplied; tool pairs/Command fields survive; display limits do not delete graph history. |
| P5: optional observability | Define capture policy/output paths; add recorder health/flush/shutdown; install scopes, callbacks and ordered capture; add usage/export inspection. Keep provider adapters untouched. | P1/P3/P4; explicitly requested dependency/settings changes and corporate capture policy. | High end-to-end | Complete synthetic redacted evidence, correlation/usage reconciliation and degraded-recording behavior pass; configured-provider validation is recorded honestly. |
| P6: optional Python execution | Migrate process manager, platform backends, ownership metadata and invocation sessions as one coherent feature. Support Windows Python; do not enable unchanged POSIX shell tools here. | P2/P3; worker-version decision; Python syntax adaptation; approved capability/configuration. | High | Process tree/owner/deadline/cancellation tests pass on Windows; successful/erroring Python calls report correct exit codes and clean up resources. |
| P7: demand-driven extensions | Choose dynamic tool loading, full context compaction, scoped artifacts/memory, durable effect recovery, profile delegation, dashboard, or independent evals only for demonstrated target needs. | Relevant runtime/persistence/recorder stages; feature-specific contracts. | Medium/high | Each feature has its own behavior/failure tests and a concrete consumer; no unnecessary mcp_agent_template subsystem imported. |

Recommended near-term scope is **P0-P2**, then the common factory in P3. Logging/capture improvements do not require replacing the corporate model adapters; file tools do not require process execution. Full observability and Python execution should be separately reviewable projects.

### Proposed module layout

Preserve the current package/public entrypoints. Add modules only when their stage needs them:

~~~text
src/mcp_agent_template/
  logging_utils.py                # managed stderr handler, redaction integration
  privacy.py                     # proposed pure redactor; no OTel imports
  agent/
    factory.py                   # proposed shared composition/namespace checks
    react_agent.py               # current single-agent entrypoint/provider composition
    multi_agent.py               # current AgentSpec tree entrypoint
    runtime/
      context.py                 # proposed invocation budget/order ownership
      middleware.py              # proposed named runtime policies
      retention.py               # proposed native-result projection
      plan.py                    # proposed native plan-state projection
  mcp_server/
    tools/
      workspace.py               # proposed first useful MCP group
      plan.py                    # proposed structured task-plan validation
      python.py, processes.py     # later, only with complete execution ownership
    execution/                   # later platform/process service
  observability/                 # later optional recording/capture/inspection
~~~

Prefer a small shared interface over copying the large mcp_agent_template factory. For example, the factory should receive model, selected tool catalog, immutable skills and explicit middleware; invocation methods should own fresh context and cleanup. Caller/provider selection stays in existing composition. Console rendering stays outside execution policy.

### Rollout and deferred decisions

- Keep migrations additive and feature selection explicit. Remove old wrappers only after both build paths use their replacement; do not retain two independently enforced ordering/budget systems.
- Preserve target tool names and nested child artifact format unless a particular migration intentionally changes them and updates users/tests.
- Do not adopt mcp_agent_template's no-tools-by-default server, DeepSeek defaults, Python floor, test configuration, or dependency manifest by copying files. These would change current contracts.
- Validate MCPAdapter behavior before replacing it. The custom mcp_agent_template MCP bridge is useful for explicit lifecycle/structured artifacts, but is not required for the first workspace ports.
- A dashboard depends on matching recorder schema; full evals depends on a separate Python 3.13 environment, corporate model adapter and revised scenarios. Neither belongs in the first migration batch.

## Baseline and verification record

Observed target baseline gaps:

1. README.md is declared in pyproject.toml but missing, so the documented packaging prerequisite is unmet ([T:pyproject.toml:5](P:/Alan/Github/Data-Package-Agent/pyproject.toml:5); [T:AGENTS.md:20](P:/Alan/Github/Data-Package-Agent/AGENTS.md:20)).
2. tests/test_skills.py expects skills/catalog_search and skills/tool_authoring, but neither SKILL.md exists in this checkout. These are likely fixture failures once the suite runs, not executed test results ([T:tests/test_skills.py:12,36](P:/Alan/Github/Data-Package-Agent/tests/test_skills.py:12)).
3. No .venv, uv.lock, or Git metadata is present. Reproducible dependency resolution and Git diff comparison cannot be claimed from this snapshot. Do not transplant the mcp_agent_template lockfile.

Checks performed for this analysis:

- Inventoried both repositories and inspected implementation/test sources across logging, capture, middleware, composition, transports, workspace/process/plan/framework tools, skills, presentation, persistence and evaluations.
- Compared normalized utility source: skills/loader.py is unchanged; context_lab/tool_linter.py differs only in its introductory docstring; token and result helpers have the small deltas described above.
- Used installed Python 3.13 ast.parse with feature_version=(3,11) on all 89 mcp_agent_template source modules. Only retention.py:13 and execution/backends.py:23 failed that syntax gate. This checks grammar only; replacement logging records, worker validation, resolved dependencies and provider behavior need runtime tests.
- Validated existing source-reference paths and line bounds; proposed new target paths are identified separately.
- Rechecked SHA-256 hashes of the pre-existing target source, tests, scripts, pyproject.toml and AGENTS.md after writing this plan. No implementation/configuration changes were made.

This analysis used source inspection and document checks only. Dependencies were not installed; runtime tests, lint, builds and authenticated calls were not run. Corporate configuration is unchanged.

For future implementation, run from the target root using its configured corporate index:

~~~powershell
uv sync --extra dev
uv run pytest
uv run pytest tests/test_mcp_server.py
uv run ruff check .
uv run ruff format --check .
uv build
~~~

Run uv build after the missing README is restored. Keep the full target suite as the final regression check. Use scripted models and temporary workspaces by default; if provider/capture/process behavior is migrated, additionally validate an actual configured corporate-provider invocation with the selected real tools/transport, inspect flushed outputs, and record unavailable credentials/services or incomplete evidence as validation gaps. Do not execute the mcp_agent_template DeepSeek live matrix unchanged.
