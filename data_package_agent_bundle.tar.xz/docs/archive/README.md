# Superseded design documents

Internal historical records. These documents describe earlier source trees and
interfaces; they are retained for design provenance, not implementation tasks.
Use the [maintained documentation index](../README.md) for current development.

| Document | Status and replacement |
| --- | --- |
| [Multi-agent design comparison](multi-agent-design-comparison.md) | 13 October 2026 comparison of pre-integration source trees. Current runtime behavior is in [agent prompts](../agent-prompts.md) and [middleware](../observability.md). |
| [Donor migration plan](mcp_agent_template-migration-plan.md) | 13–14 October 2026 proposal. Logging/runtime work and later changes have superseded its inventory and backlog. Use the [development README](../../README.md). |
| [P&L implementation plan](pnl-analysis-implementation-plan.md) | 17 October 2026 design snapshot. Review-date filtering and earlier grouping rules are obsolete; use the [P&L guide](../pnl-analysis.md). |

Recorded workstation paths, commit IDs and line numbers refer to the original
investigations. Old provider choices, tool names and output allowances are not
current defaults. The implemented post-trade structure guide now lives with the
[maintained guides](../post-trade-analysis.md).
