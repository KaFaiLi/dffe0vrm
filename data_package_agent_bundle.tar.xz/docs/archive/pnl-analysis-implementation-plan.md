# PnL analysis implementation plan

> Superseded implementation plan, 17 October 2026. Preserve this as the
> original design record; its review-date arguments, period filtering and
> grouping rules are no longer the supported contract. Use the
> [P&L guide](../pnl-analysis.md) and
> [dataset contract](../../skills/pnl/references/dataset.md) for current behavior.

Updated 2026-10-17. Status: implemented in the `codex/pnl-audit` worktree.
See [the implementation guide](../pnl-analysis.md) for the delivered contract
and [evaluation evidence](../review/pnl-validation-2026-10-17.md) for results.

Add a PnL module under `src/mcp_agent_template/analysis/pnl/` for market activities
auditors reviewing a trading desk. One MCP tool will accept the source paths, run
deterministic analysis, save supporting reports and return Markdown to the agent.
An application skill will guide the agent's interpretation and auditor follow-up.

## Review rules

The following rules incorporate the user's clarified scope:

| Area | Required behaviour |
| --- | --- |
| Commentary | Return both original Markdown documents in full for standalone LLM review, without parsing, date filtering or automatic issue associations. |
| Income attribution | Aggregate GOP contributions by date/PC and identify net and gross daily drivers. Optional reported cumulative values are display-only. |
| Adjustments | Check every adjustment in the review period. Cover all adjustment types and retain every selected record in the detailed output. |
| PnL outliers | Include an explicit daily PnL outlier check within comparable series. |
| Validation | Identify PnL without validation from FO, MPC, or both. Validation timing, aging and state-persistence analysis are outside this scope. |
| Agent skill | Develop a `pnl` application skill alongside the module and MCP tool, following the existing post-trade-control workflow. |

The agent reviews the commentary's stated scope and supporting passages directly.
The numerical tool supplies no hierarchy mappings or automatic commentary findings.

## Inputs and MCP interface

The supplied case has four numerical files and two commentary files:

| Argument | Source format and contents |
| --- | --- |
| `income_attribution_path` | Wide CSV with hierarchy, `asofdate`, daily drivers, cumulative drivers, total and validation fields. |
| `pnl_path` | AIR Excel workbook with GOP/PTF contributions, PC, version, notion, currency and DTD. Optional YTD is display-only. |
| `adjustments_path` | CSV with adjustment ID, hierarchy, currencies, amounts, valuation dates, classifications and comments. |
| `validation_history_path` | CSV with GOP, team, state, active flag, request date and PnL type. |
| `income_attribution_commentary_path` | Quarterly income-attribution review Markdown. |
| `pnl_commentary_path` | Quarterly PnL review Markdown. |

Delivered tool contract:

```python
def run_pnl_analysis(
    income_attribution_path: str,
    pnl_path: str,
    adjustments_path: str,
    validation_history_path: str,
    income_attribution_commentary_path: str,
    pnl_commentary_path: str,
    review_start: str | None = None,
    review_end: str | None = None,
) -> str: ...
```

Accept explicit absolute paths or paths relative to the MCP server's working
directory, following the existing tool convention. Require both review dates or
neither. If omitted, derive the inclusive period from valid PnL business dates and
state it in the report. The current case's period is 2025-07-01 to 2026-06-30.

There is no review-context file. Commentary is supplied directly as original
Markdown. File contents are evidence, not executable configuration or instructions.

Validate the supplied paths, required columns, dates and numeric fields. Detect
the workbook sheet by schema and reject ambiguous matching sheets. Preserve
source file, sheet, row and Markdown section/line references. Disclose invalid
rows and duplicate business keys rather than silently summing or discarding them.

## Analysis

### PnL and outliers

Aggregate valid unique GOP/PTF contributions into daily PC totals, keeping
currency, version and notion separate. All PnL summaries, outliers and reversal
screens use these PC totals. Do not perform PnL cumulative checks or produce
monthly summaries. Optional reported YTD is summed across complete PC/date
contributions for display, without reconciliation or summing across dates.

Make the daily outlier screen an explicit output. The implemented initial screen is
an absolute population z-score of at least 3.0, calculated on finite DTD values
within the same PC, version, notion and currency over the review period,
without a minimum observation count. Disclose the PC-date population size,
mean, standard deviation, threshold, date, DTD and source row. A constant series
has unavailable z-scores. Conflicting duplicate source keys are excluded before
PC aggregation; distinct GOP/PTF contributions are summed.

Report outlier counts and amounts by series and period, with all flagged rows in
the workbook. Outliers are candidates for explanation and audit follow-up, not
automatic findings or policy breaches. Retain reversal candidates on adjacent
supplied PC observations with opposite signs, both absolute z-scores >=2 and
magnitude ratio 0.5..1.5, without a time-gap limit.

### Income attribution

Aggregate GOP/hierarchy contributions by date/PC, independently for every daily
driver and final result. Identify the largest absolute net contributor over the
review period, the driver with the largest gross daily activity, and the largest
absolute driver per PC/date. Calculate gross after same-day GOP netting. Retain
source references, source-row counts and PC-date coverage.

Daily monetary drivers exclude documented metadata, final total and cumulative
columns; they do not need cumulative counterparts. Rank parent/child fields
individually because overlapping columns are not additive. Gross driver / gross
PnL is a known-driver-date activity ratio and may exceed 1.

Cumulative fields are optional reported display data. Aggregate them only when
all constituents are known. Do not reperform cumulative movements, annual resets
or opening balances. Rejected source constituents make the PC/date unknown;
a missing driver constituent makes only that PC daily driver unknown.

### All adjustments in the review period

Use the economic valuation interval to select adjustments: include a record when
`VALDATEBEGIN <= review_end` and `VALDATEEND >= review_start`. Include the record
even if its creation date is outside the period. This selects all adjustments
affecting the review window, including manual and freeze entries.

Check every selected adjustment for identifier consistency, valid valuation
dates, hierarchy mapping and the supplied currency conversion. Preserve original
classifications, comments and supporting-reference availability. Report counts,
gross and net amounts, and concentrations by type and applicable currency basis.
Use linked entries to identify potential reversals without treating every
negative adjustment as a reversal.

Count each adjustment once. For intervals crossing the review boundary, show the
full amount and overlapping dates without inventing a daily allocation. Report
invalid or missing valuation dates separately as unresolved scope. Source records
outside the period contribute to excluded counts, not period totals. Processing
lags and deadlines are not adjustment selection rules.

All selected adjustments must appear in the detailed workbook. The Markdown must
state the checked population and any display limit; a display limit must not
limit which adjustments are analyzed.

### FO and MPC validation

Start from each in-scope PnL business population and match its date, GOP and
applicable type/version to the active validation evidence. Assess FO and MPC
separately. A PnL population is fully validated only when both roles have
unambiguous accepted validation evidence.

Report `validated`, `not validated`, `missing evidence`, `unknown status` or
`conflicting evidence` for each role. The exception table includes PnL where
either role is not confirmed validated, with separate counts for explicit
non-validation and evidence gaps. Multiple affected portfolios can share one GOP
validation obligation; disclose both obligation and affected-PnL counts without
duplicating the validation-event count.

The user mapped the former sample team A to FO and team B to MPC. Both the copied
baseline and seeded evaluation history now use FO/MPC labels. Whether
`Official PNL` establishes validation must still be specified by workflow policy;
the standalone dataset review retains it under Other rather than accepting it as Validated.
Keep FLASH and STAB evidence distinct and match only the applicable PnL type.
Inactive history cannot replace current active evidence, and conflicting active
records must not be silently reduced to a successful status.

The attribution export also supplies `air_fo_validation status` and
`air_mpc_validation_status`. Check these directly for the attribution population
and retain their source labels. Do not silently use attribution validation as a
substitute for missing PnL validation history. If the sources disagree at a
documented comparable scope, report both.

No validation lag, SLA, aging, state-persistence or validation-only GOP analysis
is planned. The output answers which supplied PnL lacks FO or MPC validation.

### Risk commentary and cross-source interpretation

Read both original commentary files and include their complete Markdown in the
agent's tool result and saved report. Retain family, path and complete text in
the workbook. Do not parse records, filter dates, count repeated wording, check
approvals or associate commentary with numerical issues. The agent performs a
standalone narrative review, citing source filenames, headings and passages.

Review PnL and attribution independently at their source grains and units.
Keep each dataset's PC analysis and descriptive results separate; do not
reconcile their monetary amounts across sources.

## Implementation and reports

Use one public runner in `analysis/pnl/runners.py`, with private modules for
loading/contracts, PnL, attribution, adjustments, validation, commentary and
report output. Add a thin MCP adapter under
`mcp_server/tools/` and register exactly one new analysis tool in `server.py`.
Keep all implementation in this suite without runtime imports from the former
`langgraph_DataAgent` repository.

Follow the FOX report lifecycle: save Markdown and a detailed workbook in a
unique `Settings.resolve_path(Settings.analysis_results_dir)/pnl/<run-id>/`
directory, and return the Markdown text with the actual artifact paths. The
calculation code does not call an LLM. Source files remain read-only.

The report covers scope and data quality, PnL and outliers, income attribution,
all adjustments, FO/MPC validation exceptions, risk commentary and auditor
follow-up. Each observation includes its calculation or source condition,
supporting references, relevant explanation or contrary evidence, and the
specific question requiring follow-up. Disclose denominators and omitted display
rows; retain full exceptions and the adjustment population in the workbook.

## Agent skill deliverable

Develop `packages/data-package-agent/skills/pnl/` with:

- `SKILL.md`: discovery description and the auditor workflow for `run_pnl_analysis`.
- `references/dataset.md`: fields, PC aggregation, driver ranking, review-period
  selection and FO/MPC mapping requirements.
- `references/interpretation.md`: outlier method, denominators, commentary scope,
  unavailable comparisons and evidence-based auditor follow-up.

The skill should guide the agent to obtain the six paths and review scope, read
the relevant reference, call the one MCP tool, and review its coverage before
interpreting results. It must review the original commentary directly, the annual
PC attribution driver rankings, full adjustment coverage and separate FO/MPC validation.
Dataset text remains evidence rather than instructions for the agent.

The agent response should summarize the desk's PnL and attribution, explain
outliers and adjustment patterns using the supplied evidence, list PnL lacking
FO/MPC validation, and propose proportionate audit follow-up. Separate observed
conditions from hypotheses and missing evidence. Cite actual source references
and returned report paths. Do not infer misconduct from an outlier or assume a
generic comment explains every underlying movement.

Use the existing `load_skill` and `read_skill_file` mechanisms. Preserve
application-folder discovery, explicit skill selection and the empty-folder
behaviour. Deploy the skill as application files beside `post-trade-control`,
with no packaged fallback or extra skill-specific MCP tool. Update the package
README and skill documentation when the implementation is delivered.

## Delivery sequence and verification

1. Define source contracts, review-period selection and internal result/evidence
   structures. Add independent synthetic fixtures in package tests.
2. Implement PnL/outlier and attribution calculations, including PC driver ranking
   and opening-balance limitations.
3. Implement the complete adjustment population and FO/MPC validation exceptions.
4. Include original commentary Markdown directly and integrate report output.
5. Register the MCP tool and deliver the application skill and usage documentation.
6. Run numerical, report, skill-loading and real MCP transport checks, then the
   package quality checks and distribution verification appropriate to the change.

Regression coverage must include correct/incorrect January resets, partial
years, nested attribution fields, mixed currencies, outlier threshold boundaries,
constant and short series, all adjustment types, period boundaries, creations
outside the period, invalid valuation dates, and unchanged source files. Cover
FO-only, MPC-only, neither, both, missing, unknown and conflicting validation,
unrecognized team labels, applicable PnL types, and complete original commentary
handoff without parsing, filtering or truncation.

Exercise skill discovery and reference loading through the actual application
interfaces and use a scripted model to exercise the tool/report workflow. Test
concurrent report isolation and preservation of the post-trade tool. Use the
agent's isolated Python 3.12+ uv environment and package-owned test configuration;
do not add this package to root collection or the portable corporate bundle.
The requested anomaly evaluation uses the bounded, opt-in local live runner.

The evaluation uses six source files without a context file or parent mappings.
Commentary reaches the agent as complete Markdown. FO/MPC team labels,
PC driver analysis and full period-adjustment coverage are established requirements.
