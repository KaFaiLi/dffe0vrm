# Onboarding, worked review and contributor change map

## Start with the correct environment

Read the [package contributor instructions](../../AGENTS.md) and
[setup guide](../../README.md#set-up-your-environment). Work from
`packages/data-package-agent/` in Python 3.12+ with its own uv environment.
The agent requires langchain-core >=1.6.10 while the sibling wrapper pins 1.6.6;
corporate resolution remains unverified and there is no package lockfile. Do not
add the agent to the root environment or silently change production pins.

The intended corporate setup is `uv sync --extra dev --extra socgenai-llm` with
access to the configured index/internal repositories. For local development use
the checked-in isolated uv template and exact instructions in
[isolated local development](../../README.md#isolated-local-development).
That environment's local override is not corporate acceptance. No provider call
is needed to inspect documentation, run deterministic analysis or use synthetic tests.

Choose an explicit writable APP_ROOT, deploy the required skill folders and
references, and configure output/recording destinations. Normal agent execution
uses socgenai_llm, Responses and detailed reasoning summaries; provider identity,
trusted pricing/proxy and encrypted audit settings belong to the sibling libraries.
An agent `.env` alone does not provision them. Use an approved priced deployment,
omit sampling/output-token defaults, and keep credentials out of tracked files.

## Choose an integration level

| Need | Interface | LLM execution? |
| --- | --- | --- |
| Compute from prepared data | In-memory analysis APIs in [structure/design](structure-and-design.md) | No |
| Create analysis artifacts directly | Domain file runners | No |
| Integrate with an MCP client | `mcp-agent-server` or module entry point, stdio/HTTP | No for the shipped tools |
| Ask questions and interpret tool evidence | `build_agent` + AgentBundle, or `mcp-agent-chat` | Yes |
| Coordinate topic specialists | AgentSpec + build_agent_tree | Yes during invocation |
| Produce the example consolidated validated report | Market-review notebook with explicit source manifest | Yes when RUN_REVIEW is enabled |

The stdio server waits for protocol input; it is not an interactive chat prompt.
HTTP requires a separately running server at the configured /mcp endpoint.
The [package README](../../README.md#start-and-integrate) has complete executable
startup and provider-owning Python examples.

## Worked example: a post-trade request

Assume APP_ROOT is `/review/app`, the server cwd is `/review`, and a synthetic
source is `/review/app/input/post-trade/cases.parquet`. The request is to review
the supplied post-trade cases and explain follow-up. The calls below show the
expected reasoning path; a live model may use a different valid sequence.

1. The caller invokes `bundle.ainvoke(request)`. The bundle allocates a new context,
   starts its managed observation scope and supplies the user message to the graph.
2. The model sees the skill catalog and calls `load_skill(name="post-trade-control")`.
   It reads both dataset and interpretation references with read_skill_file.
   These local calls return text, consume ordinary tool allowance and run no analysis.
3. If the folder was not established, `list_files(folder_path="input/post-trade")`
   returns `input/post-trade/cases.parquet`, relative to APP_ROOT. The model must
   resolve it to the absolute `/review/app/input/post-trade` folder for analysis;
   passing the bare relative folder would instead use server cwd.
4. The model calls `run_post_trade_review(folder_path="/review/app/input/post-trade")`.
   Runtime policy reserves capacity/budget. MCPAdapter sends the protocol request
   to FastMCP, which selects the matching Parquet and invokes deterministic FOX analysis.
5. Analysis validates/prepares rows, removes exact duplicates, captures one local
   snapshot, calculates workflow/age/score/summary evidence and saves Markdown/Excel.
   The tool returns the saved Markdown with actual paths. No provider is used inside it.
6. The next model request contains that tool result. The model checks population
   reconciliation and describes observations with counts, denominators, IDs,
   snapshot, counterevidence and specific follow-up. It identifies workbook-only
   evidence as uninspected when no reader is available.
7. A final assistant message ends the loop. ainvoke returns native history/todos;
   ask would return text only. The invocation finalizes observation and closes
   its owned recorder. The application's provider context manager owns model cleanup.

A processing case aged 45 days with no decision/closure scores 3 and enters the
priority queue. That identifies a review candidate. An auditor still needs the
applicable SLA and case history before calling it a breached requirement. If
closure exists, age uses closure minus execution even for a processing row.

For PnL, replace the folder call with **six required source paths**, including
original commentary. For risk, supply required SGMR and omit genuinely absent
optional sources. Each uses every supplied date; do not imply period filtering.
Use the [individual tool references](tools/README.md) before composing arguments.

## Diagnose common problems

| Symptom | Check / next step |
| --- | --- |
| Skill catalog empty | APP_ROOT, SKILLS_DIR, complete deployed folders, per-node selection and readable SKILL.md; rebuild after catalog changes |
| Unknown tool/skill or duplicate tool | Verify actual catalog and selection; remove colliding names, including custom write_todos |
| Discovery succeeds but analysis cannot find input | Compare APP_ROOT with server cwd; use established absolute paths |
| FOX has zero/multiple matches | Supply a folder with exactly one immediate-child schema-matching Parquet; inspect the stated schema error |
| PnL refuses a source | Correct six-file/schema/EUR/Notion/amount issue; do not rewrite currencies or discard failing rows |
| Risk has few/no flags | Read screen availability, series definitions, segment breaks, dispersion and value minimum count; unknown is not zero |
| Root stops before MCP transport timeout | Root/child deadline and call budgets can expire first; transport settings do not extend them |
| RunContext already used | Allocate a fresh context or use bundle invocation helpers |
| Follow-up child forgot earlier review | Include prior evidence in the new task; each child call is a fresh conversation |
| Reports saved but details not in answer | Returned Markdown has evidence/display boundaries; a generated file is not automatically read |
| No reasoning summary text | Detailed summary was requested; provider reasoning tokens do not guarantee exposed summary text |
| SQLite contains business content | Expected with full redacted plaintext capture; choose OBS_MODE=off when local recording is unwanted and manage existing artifacts separately |
| Notebook emits validation errors | Use supplied source/mapping/criterion IDs and actual catalog evidence; retain validation_errors.json and do not auto-repair with another provider call |

## Where to make a change

| Intended change | Primary owner | Contracts/checks to keep aligned |
| --- | --- | --- |
| New server tool | mcp_server/tools and server.py | Docstring/schema, this tool catalog, relevant skills, tests/test_mcp_server.py and tool integration tests |
| New skill/reference | Deployed skills folder and optional loader behavior | Discovery/containment, selected tool availability, skill catalog and tests/test_skills.py |
| Prompt/todo policy | agent/prompts.py, runtime/todos.py | Prompt assembly, state/collision behavior, agent-prompts guide and todo tests |
| Agent/delegation/budget change | agent/factory.py, multi_agent.py and runtime modules | Shared counters, deadlines, concurrency, cancellation, cleanup and middleware/agent tests |
| Analysis rule | Domain preparation/calculation owner in [structure/design](structure-and-design.md) | Population, dates, units, missingness, formulas, tool descriptions, deployed skill references and domain tests |
| Report/chart change | Domain renderer/export/charts and shared chart module | Same calculated result, complete evidence, display caps, literal text, staging and visualization guide |
| Capture/storage change | observability modules | Privacy, recorder ownership, current-schema startup/restart, rejected schemas, dashboard and observability tests |
| Consolidated report contract | notebooks/review_reporting.py and notebook wiring | Catalog provenance, complete checks/comparisons, source arguments/artifacts and review-report/notebook tests |

Run relevant package tests and Ruff checks for behavioral/code changes, using the
isolated environment described in AGENTS.md. Corporate commands are:

```text
uv run pytest tests dashboard/tests -q
uv run ruff check .
uv run ruff format --check .
git diff --check
```

In the isolated local setup, replace uv run with its documented project/locked
invocation and network restrictions. The package does not implement the root
manager/wrapper's `--offline` pytest flag. No billable live call is part of these
synthetic checks. Do not add/run tests solely for prose changes. Build/install
verification is required when packaging/layout changes, rather than for new docs.
Historical local success is separate from current synthetic evidence, live model
quality and corporate dependency/network/identity acceptance.
