# Data Package Agent architecture

Data Package Agent turns supplied financial-control extracts into reproducible
analysis reports, then lets an LLM agent use those reports and application skills
to answer review questions. This guide explains the running system for new
developers and coding agents. Source links are optional implementation pointers;
the explanations stand on their own.

The package directory is `data-package-agent`, its distribution is
`mcp-agent-template`, and its Python import is `mcp_agent_template`.

## Read in this order

| Step | Guide | What you should understand afterward |
| --- | --- | --- |
| 1 | [Structure and design](structure-and-design.md) | Responsibilities, process boundaries, deployment and design choices |
| 2 | [Agent loop](agent-loop.md) | Build, invoke, choose tools, delegate, terminate and clean up |
| 3 | [Middleware](middleware.md) | Where policies run and why their order matters |
| 4 | [Tool catalog](tools/README.md) | Every shipped model-visible tool, its inputs and its evidence boundary |
| 5 | [Skill catalog](skills/README.md) | How instructions load and how each analysis review works |
| 6 | [Onboarding and worked example](onboarding.md) | Setup, tracing a real workflow, troubleshooting and making changes |

[PLAN.md](PLAN.md) records the documentation plan, baseline and validation.
The [existing guide index](../README.md) links detailed domain methodology and
historical evidence. This folder describes current behavior; dated reports
describe only their recorded runs.

## The system in one picture

```mermaid
flowchart TD
    U[User / Python caller / CLI / notebook] --> B[AgentBundle invocation]
    S[Application skill folders] --> L[Local skill tools]
    B --> G[Native LangChain / LangGraph loop]
    G --> M[Ordered middleware]
    M --> P[socgenai_llm / API manager / Azure Responses]
    P --> G
    G --> L
    G --> C[MCPAdapter / FastMCP client]
    C --> F[FastMCP server: stdio or HTTP]
    F --> A[Deterministic analysis and file discovery]
    D[Read-only supplied datasets] --> A
    A --> R[Markdown / Excel / optional PNG artifacts]
    R --> G
    G --> O[Final assistant answer]
    G -. optional local capture .-> Q[SQLite recordings and dashboard]
```

The model selects actions and interprets evidence. Analysis tools perform the
calculations without calling an LLM. The server can be used directly by another
MCP client, and Python callers can run analysis without building an agent.

## Vocabulary

| Term | Meaning here |
| --- | --- |
| MCP | Model Context Protocol: discovery and invocation interface between client and tool server |
| Tool | A named callable with a model-visible schema and result; may be MCP, local, middleware-provided or a child agent |
| Skill | Application instructions and supporting files; loading a skill reads text rather than executing analysis |
| AgentBundle | Compiled graph plus selected tools, model, settings, metadata and safe invocation helpers |
| AgentSpec | Declarative configuration of one node in an agent tree |
| RunContext | Single-use invocation state, including scheduling and compaction state |
| RunBudget | Root/shared tool and model counts, capacity and deadline for a delegation tree |
| Tool round | One assistant turn proposing one or more tools; several calls can consume one round |
| Middleware | Hooks around model calls, tool calls and graph lifecycle |
| Artifact | Saved report/image, or a tool's application-side trace payload; a saved path does not imply its contents were inspected |
| APP_ROOT | Application configuration/path root; distinct from the server working directory |
| PC / GOP / PTF | Source hierarchy/grouping identifiers; their business meanings and mappings must be supplied |
| SGMR / Colibris / FOX | Risk-measurement, excess-event and post-trade case source families respectively |

The standard server has four tools. A standard unfiltered single agent adds
three skill tools and `write_todos`, for eight tool names. Application extras
and generated delegation tools expand that list. The notebook adds its own
evidence lookup; it is not part of the standard server.
