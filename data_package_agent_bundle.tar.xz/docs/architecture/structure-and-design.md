# Structure and design

## Responsibilities and package layout

Paths in this table are relative to the package directory. No source reading is
needed to use the responsibility map.

| Location | Owns | Does not own |
| --- | --- | --- |
| `src/mcp_agent_template/config.py` | Typed environment/`.env` settings and path resolution | Provisioning provider credentials |
| `src/mcp_agent_template/agent/` | Public builders, bundles, prompts, tree composition and CLI | Financial calculations |
| `src/mcp_agent_template/agent/runtime/` | Invocation lifecycle, shared limits, scheduling, todos and compaction | Durable conversation memory |
| `src/mcp_agent_template/llm/` | Central model factory and explicit compatibility adapter | Automatic provider/model fallback |
| `src/mcp_agent_template/mcp_server/` | FastMCP startup, transport and thin tool adapters | Analysis methodology |
| `src/mcp_agent_template/analysis/fox/` | Post-trade preparation, scoring, summaries and report writers | Transaction settlement verification |
| `src/mcp_agent_template/analysis/pnl/` | PnL/attribution calculations, adjustment/validation checks and reporting | Cross-source monetary reconciliation |
| `src/mcp_agent_template/analysis/risk_metrics/` | SGMR series, independent Colibris workflow screens and reporting | Recalculation of risk models from positions |
| `src/mcp_agent_template/analysis/charts.py` | Shared headless PNG export and chart metadata | LLM interpretation of charts |
| `src/mcp_agent_template/skills/` | Skill discovery, inventory, bounded reads and local tool creation | Packaged business skill content |
| `src/mcp_agent_template/observability/` | Redaction, capture, SQLite storage, correlation and OpenTelemetry integration | The manager's encrypted provider audit |
| `src/mcp_agent_template/notebook.py` | Notebook tool catalog, skill cards and nested trace display | Validating the market-review report schema |
| `skills/` | Four deployed application skills and their references | Python importable runtime code |
| `notebooks/` | Market-review example and `review_reporting.py` schema/evidence helpers | Installed wheel APIs |
| `dashboard/` | Standalone read-only localhost SQLite viewer | Running or modifying agent tasks |
| `tests/`, `dashboard/tests/` | Synthetic, integration and dashboard regressions | Local Foundry credentials or development probes |
| `docs/` | Maintained contracts, architecture, research and dated evidence | Runtime state |

The suite also contains sibling `socgenai-llm` and `genai-api-manager` packages.
The agent has its own Python 3.12+ uv project. Keep its environment and tests
separate from the root manager/wrapper environment.

## Entry points and process boundaries

| Entry point | Behavior |
| --- | --- |
| `mcp-agent-server` / `python -m mcp_agent_template.mcp_server` | Starts FastMCP; waits for protocol requests and needs no LLM for analysis |
| `mcp-agent-chat "..."` | Builds an agent and invokes the provider; no-argument mode runs a CLI prompt loop |
| `build_agent()` | Asynchronously discovers tools/skills and compiles one agent |
| `build_agent_tree(AgentSpec(...))` | Compiles child nodes and wraps them as tools on their parents |
| `AgentBundle.ask`, `ainvoke`, `astream` | Execute with fresh context and managed observation scope |
| File-based analysis runners | Load sources, calculate and write reports without any agent |
| In-memory analysis functions | Calculate from prepared data without settings, clock or file access |
| `agent.graph.make_graph` | Optional compiled-graph factory for LangGraph integration; raw invocation still needs a fresh RunContext and the caller's server configuration |
| Market-review notebook | Configures a four-agent application, evidence lookup and validated consolidated outputs |

With **stdio**, the adapter launches the current Python interpreter with
`-m mcp_agent_template.mcp_server`. It forces child transport to stdio and passes
resolved output/configuration paths through the subprocess environment. Transport
sessions are adapter-owned (`keep_alive=False`); do not build another subprocess
per tree node. With **HTTP**, start the server separately and configure the agent
for the same host/port (`http://127.0.0.1:8000/mcp` by default). The client uses
streamable HTTP, with separate tool/read timeouts.

Skill reading and native todos run in the agent process. Domain tools execute
in the MCP server process. An agent tree shares a discovered MCP client/tool set;
each node has its own graph, prompt, selected skills and model configuration.

## Design decisions

**Use native graphs and public middleware.** The project builds on
`langchain.agents.create_agent`, preserving native message/state/stream behavior.
The package adds execution policy through hooks rather than implementing a
second ReAct engine. Single and tree builders use the same factory to prevent
prompt, budget and recording behavior from diverging.

**Keep adapters thin and calculations reusable.** MCP adapters validate the call
shape, resolve output settings and translate common input/access failures to
tool errors. Domain modules own preparation, calculations and rendering. Each
analysis builds one shared result consumed by Markdown and Excel; PnL/risk chart
writers use that same evidence. This keeps outputs consistent and supports
deterministic in-memory use.

**Separate instructions from execution.** System prompts initially contain only
skill names/descriptions. Agents fetch full instructions and references on demand.
Changing a skill changes review guidance; changing a calculation requires Python
changes and behavioral validation. Reading a script asset never executes it.

**Centralize the provider path.** Normal agent execution uses
`llm.genai_manager.get_chat_model` → `socgenai_llm.GenAIChatModel` → sibling API
manager → Azure v1 Responses. Detailed reasoning summaries are requested;
sampling and output-token limits are omitted by default. Explicit caller options
are preserved. Extra provider request options use `model_kwargs`. An explicit
`genai_manager` adapter is retained unchanged by explicit user request; failures do not trigger a
provider/model/API switch. Injected scripted models/tools support offline checks.

**Bound a whole task, including delegation.** Root and children share call budgets
and deadline. Child isolation cannot reset allowances. Capacity limits control
execution even though the model can propose parallel calls. See [agent loop](agent-loop.md).

**Keep evidence and conclusions distinct.** Tools describe supplied populations
and flag review candidates. Skills guide interpretation, counterevidence and
follow-up. Criteria, source mappings, materiality and causal conclusions require
additional evidence. Similar dates or labels alone do not create lineage.

## Paths, deployment and data ownership

| Path use | Base / boundary |
| --- | --- |
| Application `.env` | `<APP_ROOT>/.env`; process environment and explicit settings can override values |
| Default APP_ROOT | Package directory in a source checkout; current working directory for an installed wheel |
| `SKILLS_DIR` (default `skills`) | Relative to APP_ROOT, or absolute; per-node overrides supported |
| `list_files` | Relative to APP_ROOT; target must remain inside APP_ROOT |
| Domain analysis source arguments | Absolute, or relative to MCP server working directory; not confined to APP_ROOT |
| `ANALYSIS_RESULTS_DIR` | Relative to APP_ROOT, or absolute; default `.mcp_agent_template/analysis` |
| SQLite `OBS_DIR` | Relative to APP_ROOT, or absolute; default `.mcp_agent_template/observability` |

Deploy complete skill folders separately from the wheel, including references.
Missing or empty selected directories yield no skills. The notebook/report helper
is checkout-only. Reports and recordings are application data, never installed
under `site-packages` by default. Report files remain until the operator removes
them; there is no automatic retention policy.

Source files are read-only. Post-trade writes a Markdown/Excel pair; PnL and risk
also write standalone charts, index and manifest. PnL/risk stage their outputs
privately and publish the run together after successful rendering. A failed
call is incomplete analysis, regardless of any files it may have left.

Local recording defaults to `OBS_MODE=local` and captures complete redacted
payloads in **plaintext SQLite**. Business content can remain sensitive after
credential redaction. `OBS_MODE=off` disables that local recording. The API
manager's encrypted audit is a separate system; neither replaces the other.
See [observability](../observability.md) and [dashboard](../../dashboard/README.md).

## Analysis internals as a change map

| Domain | Preparation | Calculations | Output |
| --- | --- | --- | --- |
| FOX | `preprocessing.py`: schema, pruning, duplicates, normalized facts and snapshot-based ages | `risk_analysis.py`: workflow/scoring/queues; `summary_analysis.py`: aggregates; `hit_search_analysis.py`: item measures | `markdown_report.py`, `export.py`; orchestrated by `runners.py` |
| PnL | `loading.py`: source parsing and constituent validation; `tree.py`: observed desk hierarchy | `calculations.py`: PC PnL and independent drivers; `controls.py`: adjustments and validation | `reporting.py`, `excel.py`, `charts.py`; orchestrated by `runners.py` |
| Risk | `sources.py`/`models.py`: parsed records, raw evidence, identities and availability | `sgmr.py`: source checks; `dynamics.py`: segments/outliers/level shifts; `workflow.py`: Colibris; `commentary.py`: source text | `report.py`, `export.py`, `charts.py`; orchestrated by `runners.py` |

Public calculation paths are `analysis.fox.runners.analyze_cases` (explicit
snapshot), `analysis.pnl.runners.analyze_pnl` (canonical prepared records), and
`analysis.risk_metrics.runners.analyze_tables` (in-memory tables). Their result
objects own mutable frames/records: treat shared results as read-only while
rendering. Detailed contracts and examples remain in the
[post-trade](../post-trade-analysis.md), [PnL](../pnl-analysis.md) and
[risk](../risk-metrics-analysis.md) guides.
