# list_files

Read-only MCP file discovery. Use it to locate established source paths inside
the application root; it does not inspect schemas or contents.

| Parameter | Required | Default | Meaning |
| --- | --- | --- | --- |
| `folder_path: str` | No | `"."` | APP_ROOT-relative directory, or absolute directory contained in APP_ROOT |
| `recursive: bool` | No | `false` | Include files below subdirectories |

Example call and synthetic result:

```json
{"folder_path":"input/risk","recursive":true}
```

```json
{"folder_path":"input/risk","recursive":true,"files":["input/risk/notes.md","input/risk/sgmr.parquet"]}
```

Results are sorted, forward-slash APP_ROOT-relative file paths, even when the
requested folder is nested. Hidden regular files are included; directory
entries and symlinks/junctions encountered during traversal are skipped. An
empty folder returns `files: []`. No files are read or changed; no report is
written and no LLM is called.

Blank/null-byte paths, missing directories, resolved paths outside APP_ROOT,
access failures and incomplete traversal produce errors with no partial list.
Resolved-path checks are containment checks, not an OS filesystem sandbox
against concurrent mutation. Results are not truncated; use narrow folders to
control response size.

If APP_ROOT is `/review/app` and the server cwd is `/review`, turn
`input/risk/sgmr.parquet` into `/review/app/input/risk/sgmr.parquet` before passing
it to analysis. Analysis inputs use the different server-cwd rule.

Implementation owner:
[`filesystem_tools.py`](../../../src/mcp_agent_template/mcp_server/tools/filesystem_tools.py).
