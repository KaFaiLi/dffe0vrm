# Tool catalog

Tools are the callable capabilities shown to the model. A skill tells the agent
how to use evidence; a tool performs an operation. MCP transport is one source
of tools, rather than a synonym for every callable in the agent.

| Tool | Runs in | Purpose / availability |
| --- | --- | --- |
| [list_files](list-files.md) | MCP server | Discover filenames within APP_ROOT |
| [run_post_trade_review](run-post-trade-review.md) | MCP server | Analyze one FOX case dataset selected from a folder |
| [run_pnl_analysis](run-pnl-analysis.md) | MCP server | Review six supplied PnL/control/commentary files |
| [run_risk_metrics_analysis](run-risk-metrics-analysis.md) | MCP server | Review SGMR and optional excess/commentary sources |
| [list_skills](list-skills.md) | Agent process | List that node's selected skill catalog |
| [load_skill](load-skill.md) | Agent process | Load instructions and supporting-file inventory |
| [read_skill_file](read-skill-file.md) | Agent process | Read one inventoried reference/asset |
| [write_todos](write-todos.md) | Native agent middleware | Replace invocation-local todo state |
| [ask_&lt;name&gt;](extensions-and-delegation.md) | Child agent graph | Generated only for configured children |
| [lookup_review_evidence](lookup-review-evidence.md) | Market-review notebook | Search captured successful report evidence; notebook-only extra |
| Application extras / middleware tools | Application-defined | Explicit extensions, with unique names |

The standard server registers exactly the first four names in
[`server.py`](../../../src/mcp_agent_template/mcp_server/server.py). Local skill
tools and todos are added by the agent factory. A tree can restrict each node's
MCP catalog while retaining its local tools. There is no standard arithmetic,
shell, arbitrary file-reading or workbook-reading tool. The synthetic `add`
fixture belongs to development probes and is not shipped as an application tool.

## Common contracts

All three analysis tools are deterministic and leave sources unchanged. Their
successful result is the saved Markdown text, with actual report paths. They
write source-derived artifacts under a unique run folder within the configured
`ANALYSIS_RESULTS_DIR`. PnL/risk charts are separate artifacts and do not appear
as image previews or chart links in the returned Markdown.

Analysis inputs use absolute paths or the **MCP server working directory**.
`list_files` instead returns **APP_ROOT-relative** paths. Convert discovered
paths to absolute paths when those bases differ. Relative output settings use
APP_ROOT. MCP analysis schemas expose no output-directory override.

Use exact documented parameter names; no analysis tool accepts a date filter.
Each reviews its full supplied population. Common input/access failures become
FastMCP `ToolError`; the adapter presents server failures as native error-status
ToolMessages so the model can explain or recover. Other exceptions can still
propagate. Correct a stated input/access problem before retrying.

A successful write proves artifact generation, not workbook/image inspection.
The supplied catalog has no general reader for those files. Generated excerpts
are review evidence at the tool-report level. Statistical flags, source breach
labels and recorded workflow states need criteria and corroboration before
becoming audit conclusions.

Named-call examples on these pages describe model/MCP arguments. They are not
standalone Python imports of nested server functions. For direct Python use,
use the file runners or in-memory APIs linked from
[structure and design](../structure-and-design.md).
