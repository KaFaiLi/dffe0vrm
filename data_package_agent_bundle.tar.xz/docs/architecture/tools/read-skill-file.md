# read_skill_file

Local agent tool that reads one supporting file from a selected skill's inventory.

| Parameter | Required | Default | Meaning |
| --- | --- | --- | --- |
| `name: str` | Yes | — | Exact selected skill name |
| `path: str` | Yes | — | Relative file path listed by load_skill |
| `encoding: "auto" \| "utf-8" \| "base64"` | No | `"auto"` | Decode text or preserve bytes |

```json
{"name":"pnl","path":"references/dataset.md","encoding":"auto"}
```

The result is an object with `name`, `relative_path`, absolute `path`,
`mime_type`, `size_bytes`, actual `encoding` and `content`. `auto` returns UTF-8
when decodable text contains no null bytes, otherwise base64. Explicit base64
preserves bytes; explicit UTF-8 errors on invalid decoding. Text is never
silently truncated. Each file is limited to **1,048,576 bytes (one MiB)**.

Both slash styles are accepted. Paths must be inventoried and relative;
absolute paths, traversal/dot components, null bytes, colons and Windows
drive/alternate-stream paths are rejected. Every read rechecks resolved
containment, regular-file status and size, including changed symlink targets.
This is scoped asset reading, not a generic file reader or OS sandbox.

Unknown skills, unavailable files, invalid paths, excessive size and decoding
failures become handled `ToolException` results. Use the inventory and stated
encoding rather than repeated guessed paths. Reading a script returns its text
or bytes and never executes it. Source files are unchanged; no MCP or LLM call
is made.

Owners: [`tools.py`](../../../src/mcp_agent_template/skills/tools.py),
[`loader.py`](../../../src/mcp_agent_template/skills/loader.py).
