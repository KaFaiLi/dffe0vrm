# run_post_trade_review

Analyze FOX post-trade control-case evidence and return an auditor-oriented
Markdown report. Load [post-trade-control](../skills/post-trade-control.md) and
its dataset/interpretation references before using the results.

| Parameter | Required | Meaning |
| --- | --- | --- |
| `folder_path: str` | Yes | Existing directory, absolute or relative to server cwd |

```json
{"folder_path":"/review/input/post-trade"}
```

The tool scans **immediate children** for Parquet files. Exactly one must contain
all eight case-sensitive columns:

| Required column | Used for |
| --- | --- |
| `Case_Id` | Source case identity; not guaranteed unique |
| `control_logical_code` | Control grouping |
| `control_description` | Source control description |
| `control_execution_date` | Execution period and age basis |
| `status` | Normalized outcome/workflow state |
| `final_decision` | Normalized decision, including source-labelled breaches |
| `historic_comments_count` | Nonnegative whole-number count or null |
| `hit_search_items` | Comma-separated source attribution |

The filename is unrestricted. Other readable Parquet schemas are ignored; an
unreadable Parquet schema fails selection. Optional `closure_date`,
`isautoclosed` and `historic_comments_markdown` enrich the review.

## Population and calculations

All supplied rows/dates are analyzed. No date, control or snapshot argument exists.
Preparation drops unused fields and prunes unrelated sparse columns before exact
duplicate comparison. Exact retained-column duplicates are removed; non-identical
rows sharing Case_Id remain distinct. Run-local `Analysis_Row_ID` values
distinguish retained records in Excel.

One current server-local timestamp anchors ages. A valid closure date takes
precedence for **every** status: age is closure minus execution, otherwise
snapshot minus execution. Missing execution dates leave age unknown. The report
combines population reconciliation, control/outcome concentration, execution-month
patterns, backlog, workflow checks, comment/auto-close signals, hit-search
attribution and overlapping scored review queues. The
[skill reference](../skills/post-trade-control.md) explains scores and denominators.

## Return, artifacts and limits

Success returns the exact saved Markdown, including source/snapshot and actual
artifact paths. It writes:

```text
ANALYSIS_RESULTS_DIR/fox/<run-id>/
  FOX_audit_analysis.md
  FOX_audit_analysis.xlsx
```

The workbook has **Overview**, **Control Analysis**, **Monthly Trends**,
**Hit Search Analysis** and **Processed Data**. Processed Data retains all
analyzed rows, used fields, normalized results and queue flags; it is not an
unmodified source copy. No charts are generated. Markdown displays ten controls
by volume and at most fifteen priority rows. Displayed rows are not an audit sample.

This tool calls no LLM and preserves input files. Empty datasets, invalid comment
counts, schema/selection errors and input/output access failures produce errors.
Use one unambiguous matching source and correct the reported issue. Repeating an
unchanged call does not retrieve omitted workbook rows; a later rerun can change
snapshot-based ages. Source breach labels and scores are screening evidence,
not verified failures or approved audit severity.

Contract: [dataset](../../../skills/post-trade-control/references/dataset.md),
[interpretation](../../../skills/post-trade-control/references/interpretation.md).
Owners: [MCP adapter](../../../src/mcp_agent_template/mcp_server/tools/post_trade_review_tools.py),
[analysis structure](../../post-trade-analysis.md).
