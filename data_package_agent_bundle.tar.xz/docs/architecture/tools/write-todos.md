# write_todos

Native middleware tool for tracking multi-step work within one invocation.
It is supplied automatically to every built agent and is not an MCP server tool.

| Parameter | Required | Meaning |
| --- | --- | --- |
| `todos` | Yes | Complete replacement list of `{content: str, status: ...}` items |
| Item `status` | Yes | `pending`, `in_progress` or `completed` |

```json
{"todos":[{"content":"Load PnL references","status":"completed"},{"content":"Review returned evidence","status":"in_progress"}]}
```

The native tool returns a graph state update and confirmation ToolMessage.
Inspect state with `result.get("todos", [])` after `bundle.ainvoke`. Each write
replaces the entire list; `[]` clears it. Independent tasks may be in progress
together. There is no `blocked` state or automatic completion gate.

Invalid inputs leave the list unchanged. Multiple write_todos calls in one
model turn are all rejected by native validation, while unrelated calls may
still execute. Successful todo calls consume normal tool/model/round budgets
and capacity; there is no extra allowance or retry.

State is independent for each root and child invocation. A new call to the same
bundle does not restore the previous list. A child's successful artifact retains
its own final todos; the parent model receives only its answer text. Todo writes
do not create a durable task system or mark underlying work complete.

Use for complex work or explicit tracking requests. The market-review example
asks its agents to omit todo/planning updates for that fixed demonstration.
Do not add another tool with the same name or duplicate TodoListMiddleware.
See [prompts and todo contract](../../agent-prompts.md).

Owner: [`runtime/todos.py`](../../../src/mcp_agent_template/agent/runtime/todos.py).
