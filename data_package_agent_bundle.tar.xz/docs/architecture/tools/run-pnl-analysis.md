# run_pnl_analysis

Review supplied EUR desk PnL, independent attribution drivers, adjustments,
validation history and original commentary. Load [pnl](../skills/pnl.md) and its
two references first. Every argument below is required, with no default.

| Parameter | Accepted source and required fields |
| --- | --- |
| `income_attribution_path: str` | Wide CSV: `asofdate`, `bu/sbu/grppc100/grppc200/grppc300/td/pc/ggop/gop`, and at least one daily monetary driver |
| `pnl_path: str` | CSV or XLSX with exactly one matching sheet: `Value Date` (`ValuationDate` alias), `Notion`, `GOP`, `PC`, `Currency`, `DTD` |
| `adjustments_path: str` | CSV: `ADJUSTMENTID`, `GOP`, `PTF`, `PC`, `CCY`, `AMOUNTINEUR`, `VALDATEBEGIN`, `VALDATEEND` |
| `validation_history_path: str` | CSV: `gop`, `team`, `state`, `api_request_date`, `pnlType` |
| `income_attribution_commentary_path: str` | Existing original UTF-8 `.md` attribution commentary |
| `pnl_commentary_path: str` | Existing original UTF-8 `.md` PnL commentary |

```json
{
  "income_attribution_path":"/review/input/attribution.csv",
  "pnl_path":"/review/input/pnl.xlsx",
  "adjustments_path":"/review/input/adjustments.csv",
  "validation_history_path":"/review/input/validation.csv",
  "income_attribution_commentary_path":"/review/input/attribution.md",
  "pnl_commentary_path":"/review/input/pnl.md"
}
```

All paths are absolute or server-cwd-relative. The tool accepts no review-date,
context, mapping or output-path arguments. Each dataset uses all its supplied
dates independently. All four tabular sources must contain rows. CSVs are UTF-8
(BOM accepted), comma-delimited with headers. Required headers match without
regard to case; duplicate names/inconsistent row widths fail. XLSX reads cached
values without recalculating formulas. Numerical dates accept ISO dates/timestamps
and Excel dates; validation history also accepts MM/DD/YYYY.

## Input rules and principal checks

Every PnL row must use EUR and one common nonblank Notion **before exclusions**.
PTF and Version are optional; Version is unused. Unique date/PC/GOP/PTF
contributions sum to daily PC PnL. Rejected/duplicate constituents leave the
identifiable PC/date unknown. Optional hierarchy columns produce the complete
observed desk tree, including numerically excluded rows.

| Check | Group / rule |
| --- | --- |
| PnL outliers | Known daily PC totals; absolute population z-score `>= 3` |
| PnL reversals | Adjacent supplied PC dates, opposite signs, both absolute z-scores `>= 2`, magnitude ratio `0.5..1.5`; no time-gap limit |
| Attribution outliers | Each PC/driver's independent known daily amounts; absolute population z-score `>= 3` |
| Adjustment activity | Daily CREATIONDATE record counts; z-score strictly `> 3` |
| Repeated adjustments | Matching supplied fields except ID, unused AMOUNT and internal fields; candidates retained in totals |
| Validation | Every history row counted within team/PnL-type groups; exact state labels and grouped DEValidated counts |

No minimum observation count is imposed on these screens; empty/constant series
have unavailable scores. Every adjustment needs finite numeric AMOUNTINEUR;
it is used directly in EUR without FX checking. Optional CREATIONDATE is required
for a row to enter daily counts. The count calendar is supplied PnL dates union
valid creation dates, including zero activity only on that union. Valuation dates
do not substitute for missing creation dates.

Attribution drivers can overlap; source currency/scale is not inferred from PnL
EUR. Driver totals are not added into a PnL decomposition. Validation has no
date/active filter, deduplication or latest-state selection. Full interpretation
and missing-constituent rules are in the [skill page](../skills/pnl.md).

## Return and saved evidence

Success returns the saved Markdown with full desk tree, PnL summaries/candidates,
attribution outliers, adjustment/validation summaries, both complete original
commentaries and actual report paths.

```text
ANALYSIS_RESULTS_DIR/pnl/<run-id>/
  pnl_review.md
  pnl_review.xlsx
  charts/index.md
  charts/manifest.json
  charts/chart-*.png
```

Numerical summary/candidate rows have no row-count display cap; ordinary cells
can be abbreviated after 350 characters. Daily/raw evidence, exact decimal text,
Desk data exclusions, source references and hashes remain in Excel. Commentary
is complete, unparsed and not automatically associated with numerical observations.
Daily EUR PC/year charts mark the existing all-date PnL outliers; there are no
YTD or attribution charts, and no chart links/previews in main Markdown.

The analysis preserves sources and calls no LLM. Missing files/schemas, ambiguous
worksheets, empty tabular sources, invalid scope, no valid PnL rows, invalid
AMOUNTINEUR or file-access failures produce errors. Correct the reported issue;
do not relabel currencies, drop records or fabricate commentary to force success.
An unchanged repeat cannot inspect workbook-only evidence.

Cumulative checks, monthly PnL summaries, attribution trends, amount-based
adjustment screens and cross-source monetary reconciliation are not performed.
Source validation labels/statistical candidates do not establish failed approval
or cause. See [dataset](../../../skills/pnl/references/dataset.md),
[interpretation](../../../skills/pnl/references/interpretation.md),
[PnL guide](../../pnl-analysis.md) and
[MCP adapter](../../../src/mcp_agent_template/mcp_server/tools/pnl_tools.py).
