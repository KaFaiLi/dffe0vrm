# load_skill

Local agent tool that retrieves the complete instructions for one selected skill.

| Parameter | Required | Meaning |
| --- | --- | --- |
| `name: str` | Yes | Exact discovered skill name |

```json
{"name":"pnl"}
```

The text result contains the instruction body without YAML frontmatter. If
supporting files exist, it also includes the absolute skill folder, complete
relative-file inventory and guidance to use `read_skill_file`. If no supporting
files exist, only instructions are returned.

This uses the build-time parsed skill body and inventory. It does not execute
scripts or load all reference contents. It writes nothing and makes no MCP or
LLM request. Loading does not add a new analysis tool: callable tools were
selected separately at graph construction.

An unknown name raises a handled `ToolException` listing available names. Select
from `list_skills`; do not guess a filesystem path. Read required references
before analysis or interpretation. Explicit user instructions take precedence
over skill guidance. See the [skill catalog](../skills/README.md).

Owner: [`skills/tools.py`](../../../src/mcp_agent_template/skills/tools.py).
