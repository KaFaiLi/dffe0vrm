# Application tools and child-agent delegation

## Generated `ask_<name>`

Each configured child AgentSpec creates a StructuredTool on its parent named
`ask_<name>`. Its description comes from the child's description. For example,
the market-review notebook configures `ask_pnl`, `ask_risk_metrics` and
`ask_post_trade`; the standard single-agent catalog has none of these names.

| Parameter | Required | Meaning |
| --- | --- | --- |
| `task: str` | Yes | Complete question/task and necessary source paths, scope and prior evidence |

```json
{"task":"Review the supplied SGMR at /review/input/sgmr.parquet. Load risk-metrics and its references; report observations, unavailable checks and actual saved paths."}
```

Each call starts a fresh child conversation with only the task input, rather
than inheriting the parent's transcript or previous child conversation. The child
uses its own selected tools/skills/model and independent todo/compaction state.
It shares the root model/tool allowances and deadline. Delegation itself reserves
a tool call; the child's calls reserve additional shared calls. Parent child-call
concurrency is configured separately from ordinary external-tool capacity.

The tool uses `content_and_artifact`: content is the final non-tool-bearing
assistant answer; the application-side artifact is
`{"agent": name, "messages": [...], "todos": [...]}`. The artifact is invisible
to the parent model but available for nested traces and notebook evidence capture.
No final text yields empty content. Timeout is the node's explicit call_timeout
or the configured default, still bounded by root time. Failures/timeouts become
handled ToolException results; external cancellation propagates. The current
adapter does not expose failed children's partial traces.

Delegation can cause provider calls and analysis writes. It is not itself a
deterministic analysis operation. Use [agent-loop](../agent-loop.md) for builder
validation, selections and budget details, and
[`multi_agent.py`](../../../src/mcp_agent_template/agent/multi_agent.py) for implementation ownership.

## Extra tools and middleware-provided tools

`build_agent(extra_tools=[...])` and `AgentSpec.extra_tools` accept LangChain
BaseTool implementations. Application middleware can expose tools as well.
All tool names must be unique within each node, including MCP, skill, todo,
child and application names. Collisions fail before graph construction completes.

Document an extension's schema, accepted inputs, effects, errors, path bases,
timeouts, resource ownership and interpretation limits. Native runtime policy
applies budget/capacity checks around normal graph execution; it cannot provide
an OS sandbox or undo an extension's side effects. Place same-resource locking
or sequencing in the extension/application where needed.

For an MCP extension, add a registration module under `mcp_server/tools/` and
register it in `server.py`; keep calculations in an appropriate domain module.
Update catalogs, integration expectations and affected skills together. No
arbitrary command-execution capability is supplied by the existing project.
