# list_skills

Local agent tool: `list_skills()` takes no arguments and returns a text list of
the selected skill names and one-line descriptions. When none are selected or
discovered, it returns `No skills are available.`

```json
{}
```

A normal checkout catalog contains `market-activity-review`, `pnl`,
`post-trade-control` and `risk-metrics`. A tree node can expose only a subset.
The result describes the node's build-time catalog; it does not rescan disk,
read full instructions, run scripts, call MCP or invoke an LLM.

Use the exact returned name in [load_skill](load-skill.md). A missing skill
usually means the selected directory is empty/missing, the file was unreadable,
or the node selected a different catalog. Rebuild after changing the deployed
catalog. See [skill discovery](../skills/README.md).

Owner: [`skills/tools.py`](../../../src/mcp_agent_template/skills/tools.py).
