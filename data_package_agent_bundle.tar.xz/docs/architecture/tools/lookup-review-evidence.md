# lookup_review_evidence

Checkout-only extra tool defined by the market-review notebook and attached to
its main reviewer. It searches captured successful analysis **report text**;
it is not registered on the standard MCP server or installed as a standalone API.

| Parameter | Required | Default | Meaning |
| --- | --- | --- | --- |
| `source_id: str` | Yes | — | Exact source ID in the notebook manifest |
| `query: str` | No | `""` | Case-insensitive literal substring in report excerpts |
| `offset: int` | No | `0` | Nonnegative result offset |
| `page_size: int` | No | `12` | Page size from 1 to 50 |

```json
{"source_id":"SGMR","query":"2026-06","offset":0,"page_size":12}
```

Use IDs from the actual manifest; the example is synthetic. The result is a
JSON string containing `source_id`, `offset`, `total`, `next_offset`,
`candidates` and `required_artifacts` for the topic. Candidates include catalog
IDs and server-owned source/report-line evidence. Search by record ID, date or
distinctive phrase, then paginate using next_offset until the needed evidence
has been inspected.

The tool rebuilds the catalog from captured successful tool-report traces for
the current run. It does not read raw input files, workbooks or images, invoke
analysis again, or call an LLM. Unknown source IDs, invalid pagination or a missing
execution raise handled ToolException results. Empty results can reflect absent
captured evidence; they do not prove that source records are absent.

In catalog mode, final draft evidence entries contain only `id` and `catalog_id`.
The validator inserts the exact stored source, locator and excerpt and rejects
invented IDs or manually supplied citation fields. Locators identify report
digest/line evidence, not raw-source inspection. Numerical section ownership
prevents commentary headings from creating numerical provenance.

Use the [market-review skill guide](../skills/market-activity-review.md) and
[report contract](../../market-activity-review.md) for validation boundaries.
Owners: [notebook](../../../notebooks/market_activity_review.ipynb) and
[`review_reporting.py`](../../../notebooks/review_reporting.py).
