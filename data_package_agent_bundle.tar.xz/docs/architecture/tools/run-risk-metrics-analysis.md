# run_risk_metrics_analysis

Review observed SGMR risk values and optional independent Colibris events and
commentary. Load [risk-metrics](../skills/risk-metrics.md) and its two references.

| Parameter | Required | Default | Source |
| --- | --- | --- | --- |
| `sgmr_path: str` | Yes | — | Nonempty SGMR Parquet |
| `colibris_path: str \| None` | No | `None` | UTF-8 excess-event CSV |
| `risk_metrics_commentary_path: str \| None` | No | `None` | UTF-8 risk commentary Markdown |
| `stress_test_commentary_path: str \| None` | No | `None` | UTF-8 stress commentary Markdown |
| `var_svar_commentary_path: str \| None` | No | `None` | UTF-8 VaR/SVaR commentary Markdown |

```json
{"sgmr_path":"/review/input/sgmr.parquet","colibris_path":"/review/input/colibris.csv"}
```

Paths are absolute or server-cwd-relative. All supplied dates/perimeters are
included, with no filtering or output-path arguments. Omit absent optional
sources; supplying an invalid file fails. A supplied header-only Colibris CSV is
an empty population, distinct from omission.

SGMR requires `limId`, `stranaNodeName`, `rmRiskIndicator`, `consoValueDate`,
`consoValue`. Comparable outlier series also need populated `rmRiskMetricName`,
`limUnit` and nonnegative integer `consoVersion`. Optional `stranaPc` supplies the
displayed perimeter. Colibris requires `excessId`; additional fields determine
which workflow/usage checks are available. Headers ignore case and surrounding
whitespace; ambiguous/blank headers fail. Extra columns and invalid individual
values remain evidence, with parsed unknowns and disclosures.

## Calculations and missing data

Series preserve limit, portfolio, PC, indicator, metric, unit, version and supplied
scenario/definition axes. Display labels `riskMetricName` and
`perimeterMnemonic` do not define a statistical population. The supplied SGMR
date union is the calendar; missing expected dates, invalid/incomparable values
and conflicts break segments. Exact duplicates are removed with their locations
disclosed; conflicting records are retained without selecting authority.

| Screen | Rule |
| --- | --- |
| Movement | `(current - previous) / abs(previous)`; population z-score over known movements in the segment, flag `abs(z) > 3` |
| Value | Population z-score over the segment's values; at least 20 consecutive comparable observations, flag `abs(z) > 3` |
| Joint day | Both flags true on the **same observation**; matching dates across different series cannot create one |

Movement scoring includes short segments. Zero previous value leaves movement
unknown. Zero dispersion leaves scores/flags unknown. A missing required flag
leaves the joint flag unknown unless another flag is known false. Equality at
`abs(z) == 3` is excluded. Ratios use `0.1 = 10%`.

Independent auxiliary checks cover date coverage, hierarchy, limit history and
effective dates, sustained level shifts, plus Colibris states, calendar aging,
explanation/validation, deadlines, approval chronology, recurrence and usage.
The reference date is the latest valid SGMR date, including conflicting rows.
Omission disables only dependent checks. Detailed thresholds are on the
[skill page](../skills/risk-metrics.md) and in maintained methodology.

## Return and artifacts

Success returns saved `risk_metrics_analysis.md` and links actual Markdown/Excel
paths within `ANALYSIS_RESULTS_DIR/risk_metrics/<run-id>/`. The returned sections
are Metric movements, Metric value outliers, Days with movement and value
outliers, Excess governance, Data quality, notes and supplied literal commentary.
The joint-day table is complete; other detail tables show at most 15 rows and
abbreviate cells over 350 characters. Excess governance uses excessId, without
source_locator or reperformed_usage display columns.

`risk_metrics_analysis.xlsx` has nine sheets:

| Sheet | Purpose |
| --- | --- |
| Summary | Populations and screen/outlier counts |
| Series Review | Coverage and movement/value segment statistics |
| Value Outliers | All flagged value observations and baselines |
| Movement and Value Outliers | All joint observations, chronologically |
| Excess Review | Complete event evidence and raw source fields |
| Review Candidates | Independent checks, qualifications and follow-up |
| Data Quality | Record-level disclosures and unavailable reasons |
| SGMR Detail | Every retained observation, raw values, scores, flags and predecessor |
| Sources and Methods | Input inventory, availability and methodology |

Standalone risk-value PNGs, `charts/index.md` and `charts/manifest.json` are saved
beside the reports. Main Markdown contains no chart links/previews. Numerical
references use SGMR id or Colibris excessId, with record-number fallbacks; source
hashes are not published. Commentary is complete source text, without extraction,
scoring, automatic matching or an Excel commentary sheet.

The tool preserves sources and calls no LLM. Input/format/schema/access errors
fail explicitly; missing optional fields leave dependent measures unavailable.
There is no SGMR limit-consumption/breach/proximity calculation, volatility-change
or persistent-trend screen, nor SGMR–Colibris reconciliation. Supplied units
are retained; no FX conversion, additive risk total or risk-model reproduction
is performed. Flags do not establish approved materiality or SLA failures.

Contracts: [dataset](../../../skills/risk-metrics/references/dataset.md),
[methodology](../../../skills/risk-metrics/references/methodology.md),
[risk guide](../../risk-metrics-analysis.md).
Owner: [MCP adapter](../../../src/mcp_agent_template/mcp_server/tools/risk_metrics_tools.py).
