# Architecture documentation plan

## Goal and baseline

Give a new developer or coding agent a complete conceptual and operational map of
Data Package Agent without requiring source-code reading. The Python import is
`mcp_agent_template`; the distribution is `mcp-agent-template`. Documentation work
starts from `main` commit `1f5f849` (pulled on 25 October 2026).

This is documentation work: preserve runtime behavior, dependencies, production
configuration, existing guides, and dated validation evidence.

## Ordered work

1. **Inspect the current contracts.** Inventory public builders, MCP registrations,
   local tools, skill folders, middleware order, settings, analysis runners and
   notebook/report interfaces. Cross-check existing guides and synthetic tests.
2. **Explain the system and its design.** Create an architecture index and a
   structure/design guide covering package responsibilities, entry points, data
   flow, provider boundaries, deployment assets and extension points.
3. **Explain execution.** Document single-agent and child-agent construction,
   model/tool iteration, state, shared budgets, concurrency, termination, cleanup,
   middleware ordering, optional compaction and recording.
4. **Document every shipped tool.** Create a tool catalog and an individual page
   for each of the four MCP tools, three local skill tools and native `write_todos`.
   Explain generated child-agent tools, injected application tools and the
   notebook-only evidence lookup. Each page
   covers purpose, inputs/defaults, path rules, outputs, side effects, errors,
   examples and interpretation limits.
5. **Document every application skill.** Create a skill catalog and individual
   pages for `post-trade-control`, `pnl`, `risk-metrics` and
   `market-activity-review`. Include source requirements, reference-loading order,
   tool mapping, calculations, missing-data behavior, artifacts and evidence
   limits. Explain discovery and separately deployed skill assets.
6. **Make onboarding practical.** Add a worked analysis walkthrough, setup and
   troubleshooting guidance, and a contributor change map. Link the architecture
   entry point from the package README and documentation index.
7. **Validate the documentation.** Check all new relative links and source paths;
   compare tool parameters and catalogs with current registrations, schemas and
   tests; inspect examples and numerical statements against maintained analysis
   contracts; run `git diff --check`. Do not run billable provider calls or add/run
   tests solely for prose edits, as required by package `AGENTS.md`.

## Intended layout

```text
architecture/
  README.md                       # Reading path, glossary and system map
  PLAN.md                         # This plan and completion evidence
  structure-and-design.md         # Module map, boundaries and design decisions
  agent-loop.md                   # Build, invoke, delegate and close
  middleware.md                   # Hook order and policy/recording ownership
  onboarding.md                   # Setup, worked flow and change/troubleshooting map
  tools/
    README.md                     # Complete catalog and contract conventions
    list-files.md
    run-post-trade-review.md
    run-pnl-analysis.md
    run-risk-metrics-analysis.md
    list-skills.md
    load-skill.md
    read-skill-file.md
    write-todos.md
    extensions-and-delegation.md
    lookup-review-evidence.md
  skills/
    README.md                     # Discovery, loading, deployment and catalog
    post-trade-control.md
    pnl.md
    risk-metrics.md
    market-activity-review.md
```

## Acceptance criteria

- A reader can explain what runs locally, what crosses MCP, and what calls an LLM.
- A reader can trace a request through model, middleware, tools and final answer.
- Every shipped tool and application skill has a discoverable reference.
- Analysis references explain source formats, populations, date behavior, units,
  principal calculations, optional/missing sources, complete evidence artifacts
  and limits on conclusions, with links to detailed maintained methodology.
- Path containment is accurate: `list_files` is scoped to `APP_ROOT`; analysis
  source paths are absolute or relative to the server working directory.
- Examples preserve Responses API/detailed reasoning requirements, omit default
  output-token limits, use synthetic data and distinguish local validation from
  corporate acceptance.
- Existing domain guides remain authoritative for detailed methodology; new
  architecture pages explain them and link to them instead of moving history.
- Documentation links resolve and the final diff contains only intended prose.

## Completion and validation

Completed on 25 October 2026 against the baseline above. All seven ordered work
items are complete. The delivered folder contains 22 Markdown pages: this plan,
the architecture index, four design/runtime/onboarding guides, the tool catalog
and ten tool/extension references, plus the skill catalog and four skill references.
The package README and documentation index link the new entry point.

Validation performed:

- Checked all 158 local links and seven linked heading anchors across the new
  pages and both updated indexes; all resolve.
- Parsed all 11 fenced JSON examples across those documents; all are valid JSON.
- Compared the four MCP registrations and their parameter names with the source
  adapters and the existing stdio integration test's expected catalog.
- Compared the three local skill-tool signatures and the notebook-only lookup
  signature with their implementations; confirmed all four deployed skills have
  individual references.
- Checked documented runtime defaults against Settings and middleware order
  against the shared factory. Cross-checked analysis populations, thresholds,
  missingness and artifacts against current adapters, runners, renderers and
  maintained skill/dataset/methodology guides.
- Checked whitespace in every new page and ran `git diff --check` for tracked
  changes; no issues were reported. Reviewed the change inventory: documentation
  only, with no runtime, dependency, configuration or notebook changes.

No application tests, lint/build commands or live provider calls were run for
these prose-only changes, following the package's completion instructions.
Documentation checks do not establish corporate dependency resolution, Azure
compatibility or live agent quality. Source descriptions and fingerprints are
implementation references, not new validation claims.
