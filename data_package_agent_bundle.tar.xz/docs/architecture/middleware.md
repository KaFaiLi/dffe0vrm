# Middleware and runtime policy

Middleware wraps native LangChain requests and lifecycle hooks. The factory
installs the following stack for both single agents and tree nodes, in the
listed order. Model/tool wrappers enter from the outside toward dispatch and
unwind with the result; lifecycle hooks are scheduled by the native graph.

| Order | Layer | Responsibility |
| --- | --- | --- |
| 1 | `ObservationMiddleware` | Capture round input and measure tool calls, waiting, handled errors and outcomes without rewriting results |
| 2 | `ToolRoundPolicyMiddleware` | In `after_model`, count tool-bearing assistant turns since the most recent user message; reject excess rounds before execution |
| 3 | `AgentTodoMiddleware` | Native todo tool/state and duplicate-write validation; bypass the native wrapper's extra prompt append because the shared prompt already includes it |
| 4 | Application middleware | Caller-supplied request/tool transformations and policies; tree construction may insert child concurrency here |
| 5 | `ContextCompactionMiddleware`, when enabled | Bound outgoing model input by summarizing eligible history while preserving protected content |
| 6 | `RuntimePolicyMiddleware` | Begin single-use context, force parallel tool availability, reserve tool budget and acquire external capacity |
| 7 | `EffectiveRequestMiddleware` | Reserve model allowance and capture the final effective request immediately before dispatch |

This order makes the initial round snapshot and final request distinguishable.
Application transformations and compaction run before final capture; final
capture sees enforced `parallel_tool_calls=True`. Model reservation runs even
when local recording is disabled. Moving policy layers can double-charge calls,
capture the wrong request or permit side effects before rejection.

## Model path

The observation layer opens a model-round scope. Application wrappers may alter
the request. Optional compaction estimates text, instructions, tool definitions
and structured-output schema size. Runtime policy enables parallel tools.
Effective-request capture reserves a model call, records the actual dispatch
request when recording is active, then invokes the provider.

Compaction triggers at 80% of the explicit input budget and aims for 60%, keeping
two recent groups when possible by default. Complete tool-call/result groups
stay atomic. Summary output has no project-imposed token cap unless the caller
explicitly sets one. Original graph history and artifacts remain unchanged.
Summaries are lossy memory, not exact evidence copies. Unbounded provider-side
history overrides and unsupported non-text media fail explicitly when compaction
is enabled. See [context compaction](../context-compaction.md) for full constraints.

## Tool path

Observation wraps the call and recognizes error-status ToolMessages, including
handled validation errors. Native todo checks can reject conflicting writes.
Application/child scheduling wrappers apply their policies. Runtime policy
reserves one shared tool call before execution and returns a handled error if
the quota is exhausted. Ordinary tools acquire shared external capacity;
delegation skips that permit so a waiting parent does not block its child's
tools. Async execution is bounded by the root deadline.

`ChildConcurrencyMiddleware` uses invocation-local gates and only the selected
child tool names. Sequential/limited child execution does not serialize ordinary
tools. Custom wrappers must preserve handler execution, cancellation, returned
native messages and their own resource ownership deliberately.

## Extension rules

Pass middleware through `build_agent(..., middleware=(... ,))` or the tree
builder. Names must be unique and cannot use reserved built-in names. Any tools
supplied by middleware participate in the same global per-node name-collision
check as MCP, skill, child and application tools. A custom `write_todos` or
another native TodoListMiddleware would collide with the provided tool.

`tool_call_middleware(async_wrapper, name=...)` adapts an async tool-call wrapper
to the native extension API. Give it a stable unique name. Custom graphs and
public builders use `RuntimePolicyMiddleware`; the former split lifecycle/tool
adapters have been removed. Preserve effective-dispatch middleware for model quotas.

## MCP and recording are additional layers

FastMCP independently installs `MCPObservationMiddleware` on its server. It
captures protocol/tool activity in the server process. It does not install the
agent's todos, child scheduler, history compaction or root call limits on direct
MCP clients. Those belong to agent invocation policy.

`InvocationScope` surrounds graph driving, owns correlation and records terminal
outcomes. Callbacks capture native model/graph events and usage. The recording
runtime owns sinks and flushing; graph construction alone starts no recorder.
The dashboard reads saved SQLite data without invoking models or tools.

Credential redaction does not remove all business content. The default local
store is plaintext, separate from the API manager's encrypted provider audit.
For event schemas, ownership and current recording support use
[observability](../observability.md), and for inspection use the
[dashboard guide](../../dashboard/README.md).
