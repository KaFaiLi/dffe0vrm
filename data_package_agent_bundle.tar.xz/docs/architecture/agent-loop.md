# Agent construction and execution loop

## Construction prepares capabilities

`await build_agent(settings, ...)` discovers the MCP catalog unless `mcp_tools`
is injected, discovers the selected application skill directory, builds local
skill tools and creates the model unless a model is injected. The shared factory
adds application tools, child tools when applicable, and middleware-provided
tools. Duplicate tool names fail construction.

The system prompt combines base task guidance, native todo guidance and
invocation-lifetime instructions, then the selected skill names/descriptions.
Tree nodes can append `system_prompt_extra`. Full skill bodies/references enter
history only when read through tools. Application middleware can deliberately
transform outgoing requests.

The factory records a redaction-safe definition and SHA-256 fingerprint from
model/tool descriptors, prompt, middleware and execution policy. It compiles a
native graph and returns an `AgentBundle`, including the definition, selected
catalogs, settings snapshot and recursion limit. Construction does not invoke
the LLM or start a recorder by itself, though MCP discovery can open a transport.

## One invocation

```mermaid
sequenceDiagram
    participant U as Caller
    participant B as Bundle / InvocationScope
    participant G as Native graph
    participant M as Middleware
    participant L as Model
    participant T as Selected tools
    U->>B: ask / ainvoke / astream
    B->>B: Fresh context, shared root budget, recording scope
    B->>G: User message or supplied native input
    loop Until final answer or termination
        G->>M: Model request
        M->>M: Optional compaction, policy, model reservation, capture
        M->>L: Effective request with tools
        L-->>G: Assistant message
        alt Assistant proposes tools
            G->>M: Check tool-round allowance
            M->>M: Reserve each tool, acquire capacity
            M->>T: Execute selected calls
            T-->>G: Tool results / handled tool errors
        else Assistant has no tool calls
            G-->>B: Final native state
        end
    end
    B->>B: Finish outcome; close/flush owned scope
    B-->>U: Text, native state, or stream events
```

`ask(str)` returns the last assistant text. `ainvoke(str | dict)` returns native
state, usually with `messages` and, after a todo write, `todos`. `astream` keeps
the scope open while yielding native events in the requested mode/shape. Use
`contextlib.aclosing` if the consumer may stop early.

Each convenience invocation claims a fresh single-use `RunContext`. Reusing a
bundle is supported; reusing a context is rejected. Calling the raw graph needs
`context=bundle.new_context()` and explicit lifecycle/configuration management;
the graph alone does not provide the bundle's observation wrapper.

There is no automatic conversation restoration, checkpoint persistence or
shared todo memory across calls. A reused `thread_id` does not enable it. To
continue a conversation, supply the desired native history explicitly; each
execution still receives a new context. CLI prompt-loop turns are separate
invocations.

## Independent limits

Defaults below come from `Settings`; applications can choose other positive
limits. These are execution limits, separate from provider token capacity and
the manager's spending accounting.

| Setting | Default | What consumes it / scope |
| --- | --- | --- |
| `agent_max_iterations` | 10 | Tool-bearing assistant turns per node/current user turn; multiple calls in a turn count as one round |
| `agent_max_tool_calls` | 100 | Tool reservations across the root and all descendants, including local tools and delegation |
| `agent_max_model_calls` | 64 | Main and compaction-summary model reservations across the whole tree |
| `agent_max_concurrent_tools` | 8 | Shared external-tool capacity; child delegation does not hold this permit while waiting |
| `agent_run_timeout` | 300 seconds | Root monotonic deadline shared by descendants |
| `agent_call_timeout` | 120 seconds | Default delegated child-call timeout, bounded by remaining root time |
| `mcp_tool_timeout` / `mcp_read_timeout` | 600 / 900 seconds | Transport timeouts; they do not extend the root invocation deadline |

Reservations are not refunded after failure/cancellation. Tool-budget exhaustion
returns an error ToolMessage before dispatch. Model-budget exhaustion stops the
model request. An extra tool round raises `GraphRecursionError` before that
round's side effects. The graph recursion ceiling is derived from middleware
count and rounds, with headroom for hook steps; it is not the exact round policy.
Deadlines/cancellation stop graph driving, but do not promise rollback of a
remote operation or forcibly terminate arbitrary synchronous filesystem work.

Parallel tool calls are enabled at dispatch. Former false/sequential settings
on general runtime policy have been removed. Actual overlap depends on model selection, native scheduling,
available permits and tool implementation. Applications must sequence operations
that conflict on the same resource.

## Agent trees

`AgentSpec` defines a node's name/description, children, optional model,
prompt addition, MCP tool names, skill names, extra tools and policy overrides.
`tool_names=None` selects all discovered MCP tools; `[]` selects none.
`skill_names` uses the same all/empty distinction. The three local skill tools
and native todo tool still exist when the selected skill catalog is empty.
Unknown selected names, cycles and conflicting tool names fail construction.

The builder discovers MCP tools once, caches skill catalogs by resolved folder
and builds nodes bottom-up. Every child becomes
[`ask_<name>(task)`](tools/extensions-and-delegation.md). Each call starts a fresh
child conversation with its delegated task, own todos, own scheduling gates and
own compaction cache. It shares the root budget/deadline and correlation tree.
Include earlier evidence in a follow-up task; previous child calls are not memory.

The parent sees the child's final answer text. Application-side artifacts retain
the successful child's full message trace and final todos. Failures/timeouts
become handled child-tool errors; failed-child partial traces are not exposed by
this adapter. Successful siblings remain usable.

`AgentSpec.concurrency` controls only that parent's child calls: `parallel`,
`sequential`, a positive integer, or a custom callable. Ordinary tools keep their
shared external capacity policy. Explicit `middleware=` on `build_agent_tree`
is applied to the root; child scheduling middleware is added where required.

## Compaction, observation and cleanup

Compaction is disabled until an explicit input budget is supplied. It projects
older complete message/tool groups into summaries for outgoing model input;
native state retains full history. Protected instructions, schemas and the
latest user request remain intact. Summary requests use the same node provider,
charge shared model-call allowance and obey deadlines. If protected inputs
cannot fit, `ContextLimitExceeded` stops dispatch. See
[middleware](middleware.md) and [full compaction contract](../context-compaction.md).

Bundle calls use a supplied open recorder, an active recorder, or an owned local
recorder according to settings. Owned recorders close and flush on exit;
caller-supplied recorders remain caller-owned. Terminal recording distinguishes
completion, interruption, failure, timeout, cancellation and early closure.
Observation is not proof that every requested procedure completed.

Close early-stopped streams, and explicitly own/close provider models using the
provider's context manager, as in the [Python integration example](../../README.md#python-and-cli-agent).
Do not assume a bundle invocation closes an application-supplied model or
separately managed HTTP server.
