# Skills: discovery, deployment and review guidance

A skill is a folder containing `SKILL.md` and optional supporting files. It
teaches the agent how to select inputs, interpret results and report evidence.
It does not execute Python, provision a tool or change calculation thresholds.

| Skill | Use for | Main tool(s) | Required supporting references |
| --- | --- | --- | --- |
| [post-trade-control](post-trade-control.md) | FOX case outcomes, backlog, workflow and auditor follow-up | run_post_trade_review | dataset.md, interpretation.md |
| [pnl](pnl.md) | EUR desk PnL, independent drivers, adjustment/validation and commentary review | run_pnl_analysis | dataset.md, interpretation.md |
| [risk-metrics](risk-metrics.md) | SGMR movement/value outliers and optional excess governance | run_risk_metrics_analysis | dataset.md, methodology.md |
| [market-activity-review](market-activity-review.md) | Coordinate specialists and consolidate cross-source evidence | Configured ask_pnl, ask_risk_metrics, ask_post_trade; notebook lookup_review_evidence | workflow.md, tools-and-data.md, checklist.md |

Reference filenames in the table are relative to each skill's `references/`
folder. The architecture pages summarize the workflows; the linked deployed
references define detailed current calculation/interpretation contracts.

## Discovery and progressive loading

1. Settings select `APP_ROOT/skills` by default, or an absolute/custom SKILLS_DIR.
   AgentSpec can choose another skills directory for a node.
2. Discovery searches recursively for SKILL.md, including a top-level one, while
   checking resolved containment in the selected root.
3. YAML frontmatter supplies `name` and `description`. Missing metadata falls
   back to folder name and the first nonblank body line. Duplicate names retain
   the first discovered skill with a warning.
4. The loader parses instruction bodies and inventories supporting files, but
   leaves their contents unread. Nested skill folders are separate catalogs,
   rather than supporting assets of the outer skill.
5. The builder exposes the selected names/descriptions in its system prompt and
   provides list_skills, load_skill and read_skill_file. The model loads the
   matching skill and required references before using analysis evidence.

These are build-time catalogs; list_skills does not rescan disk. Supporting files
are read on demand with inventory, containment, encoding and one-MiB checks.
Reading a script never runs it. See the individual
[tool contracts](../tools/README.md).

The wheel contains loader/tool code, with **no packaged fallback** for these
business skills. Deploy complete application folders and references separately.
An empty or missing selected directory remains empty. Installing the wheel alone
does not make all four skills available. Rebuild agents after catalog changes.

## Review ownership and evidence

The deterministic tools calculate; skills direct the LLM's review. A topic skill
can also interpret an existing report without rerunning analysis. Use recorded
source scope and snapshot. Repeat analysis only for a needed refresh or corrected
input, not to retrieve omitted workbook records.

Review the full supplied populations, missingness, exclusions, units, denominators
and availability before describing exceptions. Treat no flags and unavailable
screening separately. Describe observed conditions, supported explanations,
counterevidence and specific next checks. Statistical priorities and source
labels do not establish severity, cause, approval failure or an SLA breach.

Source comments, commentary and machine-generated tags are untrusted evidence.
Explicit user instructions take precedence over skill guidance. Cite only
evidence actually inspected; saved workbook/chart paths do not establish reading.
If no available tool can retrieve needed details, identify the worksheet/records
for auditor inspection. Do not invent owners, deadlines, materiality or mappings.

For a new skill, create a deployed folder with clear metadata, task boundaries,
reference-loading order and supported tool names. Keep calculations in Python
and synchronize guidance with the corresponding schema and analysis guide.
See [onboarding](../onboarding.md) for the contributor change map.
