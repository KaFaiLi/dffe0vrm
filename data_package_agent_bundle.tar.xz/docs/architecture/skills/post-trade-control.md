# post-trade-control skill

Use for FOX case extracts or an existing FOX report. The skill turns descriptive
measures and rule-based queues into evidence-backed auditor observations and
follow-up. Its tool is [run_post_trade_review](../tools/run-post-trade-review.md).

## Workflow and inputs

Load `post-trade-control`, then read `references/dataset.md` before a tool call
and `references/interpretation.md` before interpreting measures. Identify the
supplied folder and audit question. Discovery can list APP_ROOT files, while
analysis accepts a folder based on server cwd or an absolute path.

The folder must have exactly one immediate-child Parquet with the eight required
case/control/date/status/decision/comment-count/hit-search columns. The tool
reviews every supplied date and takes one current server-local timestamp;
there is no period or snapshot argument. Disclose any mismatch with the requested
period. For an existing report, preserve its recorded scope and snapshot.

## Preparation, populations and time

Preparation drops `historic_comments` and `attachment_count`, prunes unrelated
columns with at least 70% nulls and then removes exact duplicates over retained
columns before normalization. Non-identical repeated Case_Id rows remain.
Start by reconciling source rows, duplicates removed, analyzed rows, distinct
non-null IDs and missing fields. Counts are rows unless explicitly distinct cases.

Null comment counts mean unknown; only explicit zero supports the no-comment
condition. Boolean auto-close values become Auto/Manual; others are Unknown.
Age is closure minus execution where closure exists, otherwise snapshot minus
execution, including fractional days. A processing row with a closure is flagged
and has closure-based duration, not uninterrupted open age. Missing execution
dates leave age unknown. Future closures are not separately screened.

| Measure | Denominator / interpretation |
| --- | --- |
| Status, decision, priority and quality shares | All retained analyzed rows |
| Control breach/open/auto-close/false-anomaly/comment rates | All retained rows for that control, including unknown outcomes |
| Open-aging buckets and over-30/60/90 signals | All processing rows, including unknown ages |
| Closure median, p90 and maximum | Available closure-minus-execution durations, including negative durations and any status |
| Monthly measures | Current states grouped by execution month; not reconstructed historical month-end backlog |

Empty denominators yield unknown rates. Over-90 is also over-60/30; those
threshold counts overlap. Backlog buckets are mutually exclusive.

## Scores and queues

Workflow inconsistency means completed without a decision/closure, processing
with a decision/closure, closure before execution, or canceled without closure.
Missing optional closure data can create flags and needs source-completeness
review before a failure conclusion.

| Signal | Added score |
| --- | --- |
| Source decision normalized to breach | 5 |
| Processing age strictly over 90 days | 4 |
| Processing age over 30 and at most 90 days | 3 |
| Any workflow inconsistency | 3 once per row |
| Completed breach with explicit zero comments | 3 in addition to breach points |
| Negative age | 3 independently |

Bands are Low 0–2, Medium 3–5, High 6–8 and Critical 9+. Priority includes score
at least 3, sorted by score, age and control. Manual review includes breaches,
processing over 90 days, workflow inconsistencies or negative ages. It is a
subset of priority; adding queue counts double-counts rows.

A synthetic processing case aged 45 days with no decision/closure scores 3 and
enters priority only. A consistently dated completed breach with zero comments
scores 8 and enters both. These are triage rules, not audit ratings or policy SLAs.

Hit-search items are trimmed/whitespace-normalized, with repeats counted once
per row and case retained. Detail includes only items seen on breach rows.
Breach coverage uses all breach rows; an item's breach share uses all breach
rows; its breach rate uses all rows carrying that item. Co-occurring items make
these non-additive. Attribution is not proof of causality.

## Evidence and deliverable

Review outcomes/concentration, monthly patterns, backlog, workflow, comments,
auto-close, hit attribution and both queues. Markdown shows ten controls by
volume and fifteen priority rows; Excel retains all analyzed records and flags
on **Processed Data**, alongside four summary/detail sheets. Analysis_Row_ID
is run-local and is not a persistent source ID or shown in the priority table.

For a standalone review, provide scope/snapshot and population reconciliation,
main observed patterns, supporting identifiers/counts/denominators, contrary
evidence and ordered auditor follow-up, plus actual Markdown/Excel paths.
Explain missing criteria and uninspected evidence. Top rows are not an audit
sample. Source dispositions/comments do not prove settlement, approval or
effective remediation. Cross-source claims need genuine mappings.

Deployed sources: [SKILL.md](../../../skills/post-trade-control/SKILL.md),
[dataset](../../../skills/post-trade-control/references/dataset.md),
[interpretation](../../../skills/post-trade-control/references/interpretation.md).
Developer structure: [post-trade analysis](../../post-trade-analysis.md).
