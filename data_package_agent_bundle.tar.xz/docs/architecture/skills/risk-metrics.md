# risk-metrics skill

Use for SGMR measurement outliers, optional Colibris excess governance and risk
commentary, or interpretation of existing risk reports. Its tool is
[run_risk_metrics_analysis](../tools/run-risk-metrics-analysis.md).

## Workflow and populations

Load `risk-metrics`, then read `references/dataset.md` to select sources/locate
outputs and `references/methodology.md` before interpreting scores/workflows.
SGMR Parquet is required; Colibris CSV and three commentary Markdown files are
optional. Omit absent optional sources, including commentary already available
in the conversation. Invalid supplied files fail explicitly. All supplied dates
and perimeters are included; there are no filtering arguments.

SGMR observations and Colibris selected events are independent populations.
The tool does not reproduce risk models from positions, convert currencies,
create additive portfolio risk totals or reconcile SGMR to Colibris.

Comparable SGMR series preserve limit, portfolio, PC, indicator, metric, unit,
version and populated scenario/definition axes such as tenor/bucket/currency.
The report's `riskMetricName` and `perimeterMnemonic` labels map from
rmRiskMetricName/stranaPc; labels do not merge statistical populations. Keep
VaR, SVaR, stress and exposure measures separate.

The calendar is the union of valid supplied SGMR dates, without an invented
business-day calendar. Missing expected dates, invalid/incomparable observations
and conflicts break segments. Undated rows cannot be scored. Exact raw
duplicates are removed/disclosed; conflicting observations remain unscorable
for dependent calculations. Baselines never cross series/segment boundaries.

## Outlier calculations

```text
movement[t] = (value[t] - value[t-1]) / abs(value[t-1])
movement_z[t] = (movement[t] - mean(segment movements)) / population_stddev
value_z[t] = (value[t] - mean(segment values)) / population_stddev
```

Population deviation divides squared deviations by N. Movement screens include
short segments and flag both tails at `abs(z) > 3`. A segment's first row has no
predecessor; previous zero or nonfinite movement remains unknown. Zero dispersion
or one known movement leaves the score unavailable.

Value screens require at least **20 consecutive comparable observations** and
also flag `abs(z) > 3`, excluding equality. Short segments and zero dispersion
retain explicit unavailable reasons. Joint outliers require both flags on the
**exact same retained observation**. A known false component makes joint false;
otherwise an unknown required component leaves joint unknown. Same dates/labels
on other rows cannot combine flags. Count observations separately from distinct dates.

Review movement, value and intersection results separately. A value may remain
unusual after a spike with an ordinary next movement. These retrospective
descriptive screens are not forecasts, significance tests or approved materiality.

## Other retained checks

| Check | Trigger / basis |
| --- | --- |
| Date coverage | Nonconflicting distinct series dates / valid observed SGMR dates; strictly below 95% flags coverage |
| Sustained level shift | Candidate splits with 20 values before/after; relative mean change at least 20% and effect at least 2.5, using average window population deviation |
| Limit history/timing | Current/initial and consecutive bounds and effective dates; equality tolerance `1e-8` |
| Hierarchy/consistency | Explicit hierarchy versus flatStrana, invalid fields and inconsistent prior-value dates |
| Colibris aging | Closed: closure minus creation; open: latest valid SGMR date minus creation, for nonconflicting IDs |
| Chronology/deadlines | State contradictions, reversed sequences, open past recorded deadlines and incomplete/reversed increase approvals |
| Validation | Explicit unsatisfactory first-level or LoD2 flags and recorded evidence dates |
| Within-Colibris usage | `abs(last value) / abs(limit)` with usable same-direction bound; explicit-percent reported usage differs by over 1.5 percentage points, or maximum is over 1 point below last usage |
| Recurrence | At least three nonconflicting selected events with same perimeter, indicator, metric, unit, limit type and bound |

For level shifts a zero prior mean is unavailable; a nonzero shift with zero
dispersion can qualify with a label. The strongest change-times-effect split is
retained, earliest on ties. Limit changes do not prove approval or temporary-bound
precedence. Colibris negative/unknown ages remain unavailable. Reference date
uses the latest valid SGMR value date, including conflicting rows. Recorded-open
status does not reconstruct historical backlog or establish SLA failure.

SGMR utilization/bound-breach/proximity/episode calculations, fixed 25% movement
triggers, volatility-change, persistent-trend and cross-source reconciliation
are absent. Independent limit-history/event-usage checks remain supported.

## Evidence and response

Report the current sections: Metric movements, Metric value outliers, Days with
movement and value outliers, Excess governance and Data quality, with pertinent
dates, units, signed scores and references. Use SGMR id or Colibris excessId
(record-number fallback where needed). Do not recreate removed executive,
scope/availability, priority, limit-consumption or visualization report sections.

Joint-day Markdown is complete; other detail tables show at most 15 rows.
Nine Excel sheets retain all observations, baselines, signed scores, unavailable
reasons, raw source fields and auxiliary checks. There are no published source
hashes or commentary worksheet. Standalone chart index/manifest and PNGs remain
separate, without main-report chart links.

Commentary is complete unprocessed source text, without extraction, scoring or
automatic matching. Attribute narrative to its document/IDs/excerpts. Similar
dates/perimeters do not establish event lineage, approved changes or resolution.
Apply criteria and corroboration before control-failure conclusions. Link actual
returned Markdown/Excel paths and claim file/image inspection only when performed.

Deployed sources: [SKILL.md](../../../skills/risk-metrics/SKILL.md),
[dataset](../../../skills/risk-metrics/references/dataset.md),
[methodology](../../../skills/risk-metrics/references/methodology.md).
Developer detail: [risk guide](../../risk-metrics-analysis.md).
