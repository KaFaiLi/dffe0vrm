# market-activity-review skill

This skill coordinates PnL, risk and post-trade specialists into one consolidated
assessment. The main reviewer owns scope, cross-source challenge and the final
finding. Topic specialists provide observations/evidence, rather than three
independent final findings.

## Required application wiring

The reference application is the checkout-only
[market-review notebook](../../../notebooks/market_activity_review.ipynb).
It supplies a source manifest, optional MappingBasis/Criterion definitions,
final JSON schema and these capabilities:

| Node | Selected skill | MCP analysis tools | Other capabilities |
| --- | --- | --- | --- |
| market_reviewer | market-activity-review | None | ask_pnl, ask_risk_metrics, ask_post_trade, lookup_review_evidence |
| pnl | pnl | run_pnl_analysis | Local skill tools and native todo tool |
| risk_metrics | risk-metrics | run_risk_metrics_analysis | Local skill tools and native todo tool |
| post_trade | post-trade-control | run_post_trade_review | Local skill tools and native todo tool |

The root also has local skill tools/todos. Child concurrency is three; parallel
selection is available but the model still chooses when to delegate. The example
asks agents to omit todo/planning updates. Installing the skill alone does not
create children, lookup or report validation. General builders keep all MCP
tools/skills unless explicit selections narrow them.

## Workflow

1. Load the skill and all three references: workflow.md, tools-and-data.md and
   checklist.md. Establish source populations, dates/snapshots, units, manifest
   identities and any genuinely supplied mappings/criteria.
2. Delegate independent initial topic reviews together with complete source
   paths, supported full-date scope, relevant checklist IDs and limitations.
   Children load their topic skill/references before analysis.
3. Retain observations, coverage, identifiers/dates, denominators, counterevidence,
   search terms and actual saved paths. Use
   [lookup_review_evidence](../tools/lookup-review-evidence.md) to inspect captured
   successful report rows and select only returned catalog IDs.
4. Perform the six comparisons below. Keep contextual/ambiguous/unlinked results
   explicit when compatible identities or evidence are absent.
5. Ask a targeted follow-up only when supported tools or existing evidence can
   resolve a material question. Child calls are fresh: include prior evidence.
   If the required procedure is unavailable, record an evidence request instead
   of rerunning unchanged analysis.
6. Produce the application-schema JSON with every checklist ID, all comparisons
   and exactly one final_finding. Validate before saving final JSON/Markdown.

| Comparison ID | Question / evidence prerequisite |
| --- | --- |
| pnl_attribution | Review PC PnL and independent driver outliers; units/taxonomy needed for any supported relationship |
| pnl_adjustments_validation | Compare results, creation-date activity and separately counted validation states; obtain inclusion/approval/correction lineage |
| pnl_risk | Compare mapped scope, dates and units; obtain effective desk/book mappings and positions/pricing support |
| risk_excess_workflow | Identify external lineage/definitions needed to compare SGMR with selected Colibris events; the current tool does not reconcile them |
| numbers_commentary | Compare actual numerical evidence with complete original narrative and claimed supporting documents |
| post_trade_activity | Require case-to-trade/book/desk links before relating cases to PnL/risk/adjustments |

Relationships are **confirmed**, **contradictory**, **contextual**, **ambiguous**
or **unlinked**. Confirmed/contradictory comparisons require supplied compatible
MappingBasis.id and at least two source references from the compared source
kinds. Mapping metadata is an operator assertion subject to review, not a
row-level join engine or proof of causality.

## Coverage, provenance and finding

The checklist has 36 D/P/R/T/C checks: source/data coverage, PnL procedures,
risk procedures, post-trade procedures and consolidation. Every check must be
assessed, including unavailable procedures. Missing audit extracts are evidence
gaps, not automatically failed bank controls. No generic source/workbook reader
is supplied on these allowlists.

Catalog-mode drafts select evidence using only `{id, catalog_id}`. Server-owned
catalogs provide exact source IDs, report-digest/line locators and quotes. The
validator rejects invented IDs, manual citation fields, wrong sources/scope,
incompatible mappings, incomplete registers and missing required artifacts.
Renderer-owned numerical section bindings cannot be impersonated by commentary
headings. Evidence is `level=tool_report`; it does not claim raw-record inspection.

Exactly one final finding uses `supported_finding`, `further_evidence_required`
or `no_finding_identified`. A supported finding needs applicable supplied criteria
and corroborated cross-source evidence. Every topic must be assessed, but unrelated
observations need not support one common cause. Unresolved checks prevent the
example's no-finding disposition. Separate condition, criterion, evidenced cause
(otherwise unknown), effect, potential exposure and recommendation. Do not invent
ratings, owners, deadlines, materiality or management commitments.

## Outputs, execution and limits

The notebook starts with `RUN_REVIEW=False`. Preflight inspects the manifest and
hashes before provider execution. Enabled runs use the configured wrapper,
Responses and detailed reasoning, with no sampling/output-token defaults and no
automatic replay of provider failures or invalid JSON.

Each `ANALYSIS_RESULTS_DIR/market_review/<run-id>/` contains manifest.json,
topic artifacts and execution.json. Validated outputs are review.json/review.md;
invalid final drafts produce validation_errors.json. Successful sibling reports
survive a failed child. Failed-child partial traces are unavailable; root
interruption can leave workpapers without a final report. Primary successful
Markdown/workbooks are mandatory final artifacts; qualifying linked charts are
optional. Structural/provenance validation does not certify truth, semantic
mapping, calculation correctness or auditor sufficiency.

Deployed sources: [SKILL.md](../../../skills/market-activity-review/SKILL.md),
[workflow](../../../skills/market-activity-review/references/workflow.md),
[tools and data](../../../skills/market-activity-review/references/tools-and-data.md),
[checklist](../../../skills/market-activity-review/references/checklist.md).
Full application/report contract: [market activity review](../../market-activity-review.md).
