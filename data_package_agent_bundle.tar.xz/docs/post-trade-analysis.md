# Post-trade analysis structure

The post-trade implementation uses a flat `analysis/fox/` package. Markdown and
Excel share one calculated result; the MCP and file-based entry points use the
same pipeline. See [skills and source contracts](skills.md#application-skills-and-analysis)
for inputs, generated reports and interpretation limits.

## Auditor-facing tool and skill guidance

`run_post_trade_review(folder_path)` is the folder-only MCP entry point. It scans
immediate children for one schema-matching Parquet file, analyzes every supplied
date and returns the saved Markdown with actual artifact paths. Input paths use
the server working directory; configured output paths use Settings resolution.
The tool captures one current server-local snapshot and has no date-filter or
snapshot argument. It preserves sources and performs no LLM calls.

The application [post-trade-control skill](../skills/post-trade-control/SKILL.md)
guides source selection, evidence-backed observations and auditor follow-up.
Its [dataset reference](../skills/post-trade-control/references/dataset.md) defines
schema, preparation and the five standard workbook sheets. Its
[interpretation reference](../skills/post-trade-control/references/interpretation.md)
defines workflow checks, scoring, queue overlap, denominators, time semantics,
hit-search attribution and where to inspect evidence. Deploy the whole skill
folder so both references remain available through `read_skill_file`.

These descriptions follow the current shared result and report writers. They do
not add screens, change scores, filter a review period or create a workbook
retrieval tool. Markdown's ten-control/fifteen-priority limits apply to displayed
detail; all analyzed rows remain in the workbook's Processed Data sheet. Source
labels and triage priorities require corroboration before an audit conclusion.

## Module ownership

```text
analysis/fox/
    __init__.py
    models.py                 # One AnalysisResult dataclass
    preprocessing.py          # Loading, validation, duplicates and case facts
    risk_analysis.py          # Workflow checks, scoring and review queues
    summary_analysis.py       # Shared aggregate and report measures
    hit_search_analysis.py    # Source item attribution
    markdown_report.py        # Markdown layout for AnalysisResult
    export.py                 # Excel layout for AnalysisResult
    runners.py                # In-memory analysis, file runner and CLI
    utils.py                  # Small shared helpers
```

`models.py` defines the shared result. Duplicate handling belongs to
preprocessing; use that owning module directly. Workflow checks and scoring
stay together in `risk_analysis.py`. There is no reporting subfolder or separate
policy, check, triage or pipeline framework.

## Data flow and Python use

`run_fox_analysis` loads the Parquet source and captures one current server-local
timestamp. `analyze_cases` validates/prunes, removes exact duplicates, assigns
run-local row IDs, prepares facts, scores cases and collects summary tables.
`render_markdown` and `write_workbook` consume that result. The file runner saves
the two reports and returns the saved Markdown string, as before.

For an explicit, reproducible snapshot:

```python
from pathlib import Path

import pandas as pd

from mcp_agent_template.analysis.fox.export import write_workbook
from mcp_agent_template.analysis.fox.markdown_report import render_markdown
from mcp_agent_template.analysis.fox.preprocessing import load_cases
from mcp_agent_template.analysis.fox.runners import analyze_cases

source = Path("cases.parquet")
result = analyze_cases(load_cases(source), snapshot_at=pd.Timestamp("2026-10-19 12:34:56"))
workbook = Path("review.xlsx")
markdown = Path("review.md")
write_workbook(result, workbook, input_file=source)
markdown.write_text(render_markdown(result, source, workbook, markdown), encoding="utf-8")
```

The in-memory function does not read settings, read the clock or write files.
Its explicit snapshot must be valid; missing/unknown timestamps raise `ValueError`.
The standalone writers require existing parent directories. Use
`run_fox_analysis` for automatic output directories and the normal current-time
snapshot. None of these calculations invoke an LLM.

`AnalysisResult` contains `cases`, `summaries`, `duplicate_details`, `snapshot_at`,
`source_row_count`, `priority_cases` and `manual_review`. The two queues are owned,
ordered frame snapshots retained from scoring, so rendering does not reconstruct
them from IDs or indexes. A repeated `Case_Id` is not a unique row identifier.
The result owns its case, duplicate and queue frames;
renderers treat all result frames as read-only. Dataclasses do not make pandas
objects immutable.

The summary dictionary retains its existing nine grouped/executive tables and
two hit-search tables. Shared presentation measures are collected as `population`,
`review_signals`, `open_aging`, `quality_signals`, `priority_counts`,
`execution_period` and `control_descriptions`. Their columns and populations are
documented in `collect_analysis_result`. Formatting, layout and display limits
remain in the report writers.

## Current interfaces and preserved meaning

The MCP tool, `run_fox_analysis` arguments and return type remain. Use
`runners.main` / `python -m mcp_agent_template.analysis.fox.runners` for the CLI.
The `fox_analysis` module, frame-based `export_report` and
`format_analysis_markdown` functions, `duplicate_analysis` re-export and
`utils.create_aging_bucket` forwarding helper have been removed. Use
`analyze_cases`, `write_workbook`, `render_markdown` and the preparation module.

`prepare_cases` returns its frame/timestamp pair and workflow flags and accepts
an optional explicit `snapshot_at`. It derives `execution_month` before scoring.
`score_and_select_reviews` returns the scored frame and two queues with explicit
membership flags. `build_summaries` requires that prepared/scored frame and does
not mutate it. The executive `Input columns` measure excludes row-identity/queue
support columns so it continues to describe the same source/preparation population.

The following remain unchanged:

- Pruning precedes duplicate removal and normalization. IDs are assigned after
  duplicate comparison. Non-identical records sharing a case ID remain separate.
- Age uses closure minus execution when closure exists, otherwise the captured
  local timestamp minus execution, including fractional days and unknown dates.
- Multiple workflow inconsistencies add +3 once per row. Negative age can add
  its separate +3. Open-age scoring bands are mutually exclusive; queues overlap.
- Control rates use all retained rows for that control. Open-aging shares use
  processing rows. Monthly medians use case durations, not control medians.
- The five standard workbook tabs, named tables, literal Excel text, report headings,
  top-ten control/top-fifteen priority displays, artifact names and output paths
  retain their existing contracts.

Long text no longer relies on Excel's truncation behavior. Values exceeding
32,000 characters after XML-control escaping have a marked preview in the main
table and complete numbered parts in an optional `Text Evidence` sheet. Each part
identifies the source sheet/table, Excel row, column and `Analysis_Row_ID` when
available. Concatenate `text` in `text_part` order for an `evidence_record`.
`Processed Data` still has exactly one row per retained case. Source objects are
unchanged. Shared value preparation and continuation rules live in
`analysis/excel_evidence.py`; PnL and risk retain their existing continuation-row
layouts and numerical measures appear only on the first part.

## Extending the analysis

| Change | Owner |
| --- | --- |
| Source parsing or derived case facts | `preprocessing.py` |
| Workflow condition, score contribution or queue criterion | `risk_analysis.py` |
| Population, control, backlog or trend measure | `summary_analysis.py` |
| Hit-search arithmetic | `hit_search_analysis.py` |
| Report column, section or worksheet layout | `markdown_report.py` or `export.py` |

Use ordinary named functions. Keep each score's predicate, weight and explanation
in the scoring module; the report's rule description uses those constants.
Aging bucket labels come from preprocessing. Document populations, denominators,
units, exclusions and missingness beside calculations, then test the observable
result. New classes, folders and configurable rule systems are unnecessary for
the current rule set.

## Test changes

Use the isolated Python 3.12+ environment from the
[development README](../README.md#isolated-local-development), then run from the
package directory:

```powershell
uv @agentUv python -m pytest -c pyproject.toml `
    tests/analysis/test_fox_analysis.py tests/analysis/test_hit_search_analysis.py `
    tests/analysis/test_fox_pipeline.py tests/test_post_trade_review_mcp.py `
    tests/test_mcp_server.py tests/test_serve.py tests/test_observability.py `
    -q --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv ruff check .
uv @agentUv ruff format --check .
git diff --check
```

These tests use synthetic sources and local MCP transports. The
[22–23 October validation record](review/post-trade-structure-validation-2026-10-23.md)
retains the fixed-snapshot comparisons, installed-package checks and their limits.
