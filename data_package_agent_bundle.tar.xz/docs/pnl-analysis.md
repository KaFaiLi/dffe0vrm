# PnL analysis for market activities auditors

`run_pnl_analysis` runs deterministic checks and returns Markdown. It saves the
same report and a workbook with complete tables in a unique
`ANALYSIS_RESULTS_DIR/pnl/<run-id>/` directory. All inputs remain read-only.
The Markdown starts with the observed desk hierarchy from all supplied PnL
rows; the workbook retains every distinct hierarchy path and its provenance.
PnL is reviewed at daily PC level after aggregating valid GOP/PTF contributions.
PnL amounts must be EUR, and each run requires one nonblank notion across all
supplied PnL rows. Currency must be EUR on every row; there is no conversion or
currency-specific route. Version is optional metadata and does not split PC series.
Attribution independently sums each daily driver across GOP contributions by date and PC,
then screens each PC/driver history for outliers. Attribution series summaries and
trends are not calculated or exported.
Final attribution PnL and cumulative values are unused.
Both original commentary Markdown files are handed to the agent in full for
standalone LLM review and retained as complete source text in the workbook.
Standalone Matplotlib PNG figures show only daily PC PnL from that same PnL file,
with existing outliers marked and labelled by date and z-score. They are saved
under `charts/`, alongside a chart index and source-evidence manifest. Chart
previews and links are omitted from the Markdown returned to the LLM. See
[analysis visualizations](analysis-visualizations.md) for scopes and runtime requirements.
The caller supplies these paths:

| Argument | File |
| --- | --- |
| income_attribution_path | Wide income attribution CSV |
| pnl_path | AIR PnL XLSX with one matching sheet, or CSV |
| adjustments_path | Adjustment CSV |
| validation_history_path | FO/MPC validation-history CSV |
| income_attribution_commentary_path | Quarterly attribution review Markdown |
| pnl_commentary_path | Quarterly PnL review Markdown |

Attribution requires at least one daily contribution column. Its final PnL
column is optional and unused, as are cumulative and validation-status columns.

All supplied dates are used independently for each dataset. Attribution dates
are not restricted to the PnL calendar. No review period is selected or checked,
and adjustments have no period-overlap labels. Existing source-date, amount and
duplicate validation still applies to numerical calculations.

Migration: remove `review_start` and `review_end` from Python and MCP calls; these
arguments are no longer accepted. The workbook Desk data table no longer has
`in review period`, and adjustment tables no longer have `review period status`
or `period overlap`. Relative paths resolve against the MCP
server's working directory. Missing columns, unreadable files and ambiguous
matching sheets produce actionable errors.

Deploy [the pnl skill](../skills/pnl/SKILL.md) as application files in
`APP_ROOT/skills/pnl/`. The skill uses `load_skill` and `read_skill_file`;
there is no bundled fallback. Load the skill and its
[dataset contract](../skills/pnl/references/dataset.md) before the analysis.

Migration: the `Population` sheet is now `Desk data`, with `dataset` replacing
its `population` column. `population stddev` is now `standard deviation`.
The `Attribution series`, `Attribution trends` and `Attribution trend history`
sheets are removed. Daily attribution evidence and outliers remain. Variance
still divides by the number of known observations; thresholds are unchanged.

## Tool selection and review workflow

The MCP schema describes every required file argument, including formats,
required columns and scope. All six files are required; commentary is not an
optional enrichment. Use the supplied manifest or established paths.
`list_files` can discover paths under `APP_ROOT`, but cannot inspect contents;
its relative paths use `APP_ROOT`, while analysis paths use the server working
directory. Use absolute paths when these bases differ. The MCP tool has no
output-directory override; the Python runner alone accepts `output_dir`.

The tool calls no LLM and does not modify sources. Correct input/access errors
before rerunning. Missing sources, ambiguous sheets or an invalid EUR/Notion
scope are not invitations to fabricate commentary, change currency labels or
discard records. Repeating an unchanged call cannot inspect additional workbook
evidence. When interpreting an existing report, retain its recorded source scope
and request a fresh run only when needed. A failed PnL call remains incomplete
coverage even if sibling risk/post-trade analyses succeeded.

Use the [dataset reference](../skills/pnl/references/dataset.md) for call shape
and source requirements, and the
[interpretation reference](../skills/pnl/references/interpretation.md) for measure
denominators, named evidence worksheets and follow-up. A standalone assessment
should cover scope, observed conditions, supporting/counterevidence, unavailable
checks, specific follow-up and the actual saved artifact paths. In a combined
review, provide that evidence in the main reviewer's requested format.

Separate a screen with candidates, a screen with no candidates, and an unavailable
screen. Markdown rounds scores, so use the tool's existing flags: PnL/attribution
use absolute z-score >=3, while adjustment counts use z-score strictly >3 before
rounding. Saving a workbook or chart does not establish inspection. The current
agent allowlists have no generic workbook reader; request inspection of the named
sheet/records when returned text cannot support a conclusion. Applicability of
policy, causes and control failures require evidence beyond a statistical flag.

## Desk analytical structure

The runner builds distinct hierarchy paths directly from its already loaded PnL
rows, using the same selected worksheet or CSV as the numerical review. It does
not reread the workbook or require another input file. All supplied rows contribute,
including invalid dates or amounts and duplicate
business keys excluded from numerical calculations.

Recognised levels, in order, are `BU → SBU → GPC1 → GPC2 → GPC3 → PC → GOP`.
TD, GGOP and PTF are omitted from both the tree and its workbook sheet.
Only columns present in the PnL source are used; upper levels
are optional and are not inferred from attribution or other datasets. Header
matching ignores case. Identifiers retain their case and are trimmed consistently
with PnL grouping. Blank identifiers display as `(blank)` in the tree and remain
empty in the workbook. Control characters are escaped in the tree display.

The **Desk analytical structure** Markdown section appears after scope and sources,
before the checks. Its fenced text tree includes every path without the numerical
12-row or 350-character cell limits. The **Desk hierarchy** workbook sheet contains
one row per distinct path, its `source rows` count and the first original row
`reference` supporting that path. Repeated daily observations, versions and
currencies do not duplicate an otherwise identical path. Source order is retained.

Multiple observed parent paths for the same identifier remain separate. Because
the hierarchy covers all supplied desk data, it is not a dated or current
organisation snapshot. Use it to understand which lower-level entities sit beneath
a PC; it does not change numerical aggregation, create issue associations or
establish mappings between independent datasets.

## Checks and interpretation

- PnL source rows are validated for unique date/PC/GOP/PTF keys, then GOP/PTF
  contributions are summed by date/PC. PTF and Version are optional source fields.
  Mixed or blank Notion values and any Currency other than EUR fail before numerical exclusions;
  these fields appear once in Markdown and in the workbook's **PnL scope** sheet.
  Version values
  may vary or be blank and do not affect uniqueness or aggregation.
  Every PnL summary, outlier and reversal screen uses these PC daily totals.
  Observations count PC dates, with contributing source counts and references retained.
  If a constituent row is rejected, its PC/date total remains unknown and is
  excluded from screening; the Desk data table counts these incomplete PC dates.
- PnL outliers use absolute z-score >= 3 within each PC.
  Screens use all valid desk data with no minimum
  observation count. Constant values have unavailable z-scores. Reversals
  compare adjacent supplied PC dates with opposite signs, absolute z-scores >= 2
  and magnitude ratio 0.5..1.5, without a time-gap limit.
- PnL cumulative checks and monthly summaries are not performed. WTD/MTD/QTD are
  unused optional source columns. Optional reported YTD is summed across PC
  contributions only when complete and retained in the workbook without reconciliation.
- Attribution source keys remain date and full hierarchy for duplicate detection.
  Valid GOP contributions are summed independently for each daily driver by date/PC.
  Every PC/driver uses its known-date mean and standard deviation for outlier screening. Both tails use absolute z-score >= 3, including equality. Statistics
  use all supplied dates without an additional minimum count. Empty and constant
  histories have unavailable z-scores; zero-valued daily amounts remain visible.
  Flags count driver/date observations and may overlap across correlated or
  parent/child fields; they are not distinct control failures.
- Attribution series summaries, rolling trends, fitted changes and R-squared are
  removed from calculations, Markdown and Excel. The **Attribution daily** sheet
  retains daily amounts, z-scores, screen availability and source references;
  **Attribution outliers** retains flagged observations and their baseline evidence.
- Daily attribution driver discovery excludes documented hierarchy/date/validation
  metadata, internal fields, the final total and cumulative columns. A daily-only
  driver is included. Parent/child drivers can overlap and are never added together.
  Every driver is screened separately, including all-zero and daily-only columns.
- A rejected attribution constituent leaves the whole identifiable PC/date unknown.
  A missing driver constituent leaves that driver unknown for the PC/date; partial
  driver sums are not reported. Daily evidence covers non-rejected PC dates; Desk data
  counts incomplete PC dates separately.
  Neither a missing nor invalid final attribution PnL amount excludes valid drivers:
  `Final Result Acc DTD` is optional and unused. No net/gross driver ranking,
  leading-driver selection or ratio to PnL is calculated.
  Entirely blank driver columns remain in the evidence as unknown daily amounts with unavailable screening. Blank source columns in adjustments and validation
  are also retained; only an all-blank optional PnL Version column is removed.
- Attribution cumulative columns are optional and unused. There are no cumulative
  checks, annual-reset tests or opening-balance requirements.
- Adjustments are one desk's dataset. All supplied rows remain in the workbook,
  summaries and statistical screens across all dates. Missing IDs and invalid
  valuation intervals remain data-quality findings. No PnL or desk mapping is performed.
- The adjustment summary groups every supplied row by `SOURCE` and `NATURE`.
  Labels are trimmed and case-sensitive; missing or blank values share an empty
  label. Markdown shows only source, nature and count. The workbook retains the
  grouped counts and net `AMOUNTINEUR` amounts in EUR, regardless of original `CCY`.
- Adjustment calculations use supplied, complete numeric `AMOUNTINEUR` values
  directly in EUR. `AMOUNT` is an optional, unused source field;
  no original-`AMOUNT` completeness or FX conversion check is performed. Missing
  or nonnumeric `AMOUNTINEUR` fails the run. Original `CCY`
  values do not partition EUR summaries or daily counts.
- Adjustment IDs are assumed unique. Repeated-entry candidates match the other
  source fields under different IDs, excluding unused `AMOUNT` and internal
  fields. Values are compared exactly as supplied, without EUR normalization;
  candidates remain included in totals.
- Adjustment screening counts records by CREATIONDATE and flags only
  z-scores strictly greater than 3, with no minimum observation count. A score
  equal to 3 is excluded. Empty or constant daily counts have unavailable
  z-scores. Supplied PnL dates contribute zero-activity observations; valid creation
  dates outside that calendar are also included. Daily net and gross EUR amounts
  remain descriptive workbook evidence. Amount-magnitude and gross-amount screens
  and adjustment reversal classification are not performed.
  `CREATIONDATE` is optional in the input schema; rows with missing/invalid values
  remain in full records and SOURCE/NATURE totals but cannot enter daily counts.
  Neither valuation dates nor today's date substitute for a missing creation date.
  The calendar does not fill other dates between observations.
- PnL validation is a standalone review of every supplied validation-history row.
  The summary counts records separately by team and PnL type (STAB/FLASH) for the
  four states: Not Validated, Waiting Official PNL, Validated and DEValidated.
  Each state percentage is `100 * state count / records` within its team/type group.
  State labels are used exactly as
  supplied; additional labels are summarized under Other when present, retaining
  their original values in record details. Team and PnL-type grouping trims
  whitespace and ignores case; blank and additional types remain separate groups.
- The workbook retains records whose state differs from exactly Validated,
  including Other, without a separate summary aggregate. DEValidated has its own
  detail table and flags and is already included in group totals.
  The active flag and PnL dates do not filter the
  dataset. No PnL/attribution matching, latest-state selection, deduplication,
  validation SLA or aging analysis is performed. Attribution validation fields
  are optional source metadata and are not checked.
- Commentary is loaded as complete Markdown without record parsing, date
  selection, approval checks, repetition screens or automatic issue associations.
  The agent reviews explanations, recorded approvals and supporting references
  directly from the original documents, using source filenames, headings and quotes.

No review context or parent-GOP mappings are required or accepted. PnL validation
uses its supplied dataset without state overrides. Cross-dataset monetary
comparison is not performed. Each dataset retains its source amounts and units,
and adjustments are not added to reported PnL.

PnL statistics use floating point; attribution aggregation, distribution statistics,
and z-scores use Decimal. Monetary sums, adjustment
arithmetic and adjustment count statistics use Decimal. Workbook decimal amounts are exact text
representations, with separate descriptive labels and source references.
The workbook retains daily PC PnL and attribution tables, full adjustment and
validation records, hashes, desk-data counts and source references. No monthly
PnL or cumulative-check tables are generated. Source text is literal workbook
text rather than executable formulas.

Markdown is a focused review: scope and filenames, all desk tree paths, EUR PC PnL
summaries/outliers/reversals, attribution outliers, adjustments, validation summaries
and both original commentary documents. Routine daily tables and Desk data counts
remain workbook-only. Hashes, references and source-row counts are omitted.
Notion and EUR appear once in run scope; Version is omitted. Values with more than
two decimal places are rounded in Markdown while Excel retains exact values.
Empty checks distinguish no flags from unavailable screening.

Attribution output migration: series summaries and all trend calculations are
removed. `Attribution daily` retains one date/PC/driver row with amount, z-score,
screen availability, constituent count and source references. Missing amounts and
scores remain null. `Attribution outliers` retains flagged observations and the
mean/deviation used by their screen. There are no series or trend sheets, fitted
changes, R-squared or rolling histories. Existing daily/outlier consumers retain
those entry points; consumers of removed sheets must stop requesting them.

All adjustment records remain in the workbook with every supplied column and
complete cell text. All adjustments contribute to totals and creation-date counts
when their creation date is valid. Markdown daily adjustment activity shows
CREATIONDATE values with count z-score > 3 only, ranked by count z-score, without
a twelve-row cap. Display columns are date, adjustment count and count z-score. Each
adjustment contributes once on its creation date; valuation dates do not create
daily groups or observations. The calendar combines supplied PnL dates and valid
creation dates, including creation dates outside the PnL calendar. Duplicate issue-detail
sections are not repeated. Full methodology notes remain in the workbook.

Validation Markdown contains counts and percentages by team/PnL type and a
DEValidated summary grouped by team/GOP/PnL type. Percentages display to two
decimal places and may not sum to exactly 100% after rounding; workbook percentages
retain Decimal precision in percentage points. There is no **Not labelled Validated**
column or **Validation state counts** section/table. Raw exception and devalidated
rows remain in the workbook. A source state other than `Validated`, including
`Official PNL`, does not establish missing history or failed approval.

Numerical summaries and selected candidates are shown completely; other ordinary
table cells may be abbreviated after 350 characters. Original commentary
is appended as Markdown outside these limits, preserving all headings, paragraphs
and formatting in the agent's tool result and saved report. The workbook's
Commentary sources table retains family, path and complete Markdown. Excel text beyond
32,000 characters uses numbered `report_record`/`text_part` continuation rows;
numeric measures appear only on the first part. XML-incompatible control
characters are escaped visibly as `\uXXXX` rather than discarded.

For structured market reviews, the evidence catalog binds numerical summary
rows to the source owning each renderer-defined section. This preserves
tool-report provenance without adding locators to Markdown. Original commentary
ends that numerical scope, so its own headings cannot impersonate calculation
sections. These citations describe tool outputs, not raw-source inspection.

## Calculation structure

For Python calculation without files or settings, use
`mcp_agent_template.analysis.pnl.runners.analyze_pnl(pnl_rows, attribution_rows,
adjustment_rows, validation_rows)`. Supply canonical records as returned by
`loading.load_table`, including `_ref` source locators; this entry point does not
perform file-schema loading. It returns the existing `Review` type with calculated
tables, issues, notes, supplied calendars and `pnl_daily` chart records. It does
not mutate inputs or access files, settings or the clock. All four desk datasets
retain the rules above; there is no snapshot or review-date argument.

`run_pnl_analysis` remains the six-file entry point. It loads sources, calls the
in-memory analysis, attaches file hashes and original commentary, and stages the
same Markdown, workbook and chart artifacts. `reporting.markdown` and
`excel.export_workbook` consume the shared result without changing it; an
in-memory review may omit source manifests/commentary. Treat mutable result
records as read-only when sharing them between renderers.

The layout remains flat. Loading owns preparation and duplicate validation;
`calculations.py` owns PC PnL and independent attribution; `controls.py` owns
adjustments and validation. `reporting.py` owns Markdown layout, `excel.py` owns
workbook formatting, and `charts.py` uses the retained daily PnL records.
Use `loading.prepare` and `excel.export_workbook`, `excel.evidence_rows` and
`excel.TEXT_PART_SIZE` directly; former re-exports have been removed. See the
[refactor contract and validation](review/pnl-simplification-2026-10-23.md).

## Synthetic evaluation

From the suite root, use the isolated uv environment described in AGENTS.md:

~~~powershell
uv run --project artifacts/foundry-agent --locked python devtools/pnl_evaluation/generate.py
~~~

The generator creates `devtools/test_source/pnl_review/input/` with five
deliberate cases, including legacy cases outside the current analysis scope. It replaces MOCK_TEAM_A with FO and MOCK_TEAM_B with MPC
in the copied baseline history and seeds the evaluation case. Cumulative
attribution errors are no longer seeded or scored; attribution cumulative values
are unused by analysis. The answer key sits outside input and is not sent to
the agent. Original commentary is returned directly for the agent's narrative review.

An authorized live evaluation uses the existing opt-in runner:

~~~powershell
uv run --project artifacts/foundry-agent --locked python devtools/foundry_lab/run.py --operation data-package-agent --agent-case pnl --model gpt-6-luna --config <ignored-local-config> --pricing <local-pricing-json> --run-live
~~~

The fixed synthetic prompt uses the real agent, MCP stdio, sibling socgenai_llm
wrapper and Azure Responses with max/detailed reasoning. Bounds are twelve model
calls, twelve tool calls, zero SDK retries, a
240-second agent deadline and a 270-second outer deadline. The existing EUR 5
post-response accounting threshold is not a hard spending cap. Unpriced models
are rejected before dispatch; there is no automatic retry or fallback.
Output-token limits are omitted, following the suite policy; provider limits
still apply independently of request, timeout and spending controls.

The run saves synthetic agent output, tool traces and a safe usage/cost summary
under the ignored Foundry output directory. Provider prompt/response audit uses
the existing encryption pipeline. Completion, numerical anomaly detection and
agent interpretation are assessed separately. Local evidence does not establish
corporate acceptance or provider billing.

See [the completed evaluation](review/pnl-validation-2026-10-17.md) for numerical
detection, the agent's interpretation, live usage/costs and verification limits.
