# PnL and risk PNG charts

Both analysis runners return Markdown strings. PnL accepts six source paths and
uses all supplied dates; the former review-date arguments have been removed.
Each successful run saves its Markdown, Excel evidence workbook and
a `charts/` directory together. `charts/index.md` displays every figure;
`charts/manifest.json` records complete scopes, source locators, dates, units,
qualifications and linked findings. The retired inline-preview selector and
its unused `preview_order` manifest field have been removed. Both PnL and risk charts are standalone
artifacts: their returned and saved Markdown reports contain no visualization
section, image previews or chart links. Keep the charts directory together when
copying figures; index images are relative to the index.

The charts are Matplotlib PNG figures, not screenshots of reports. They use white
backgrounds and 200 dpi export resolution (2,800 pixels wide). Chart labels are
literal text, with math and TeX parsing disabled; Markdown labels are escaped.
Image files and manifests contain source-derived data and require the
same access controls and retention handling as the input files.

## PnL

Only daily PC PnL is plotted. Each standalone PNG uses the same loaded PnL
worksheet or CSV as the desk hierarchy. GOP/PTF contributions are summed by
date/PC, using the same complete daily PC totals as statistical screening.
Each PC has a daily line chart per calendar year. Amounts must be EUR and Notion
must be single-valued; Version is optional metadata and does not split series.
YTD, attribution factors and year-end snapshots are not plotted.

Diamonds highlight the existing PnL outliers, with their dates and z-scores
labelled on the line. The markers match the exact PC and date in the numerical
review. Scores use all supplied desk dates (absolute z-score >= 3); the annual chart split does not recalculate
them. These are statistical review candidates. Constant series have no outlier
markers. The evidence manifest retains each plotted outlier and its references.

The returned and saved PnL Markdown contains no chart section, image previews
or chart links. Standalone PNGs are saved under
`ANALYSIS_RESULTS_DIR/pnl/<run-id>/charts/chart-*.png`. The separate
`charts/index.md` and `charts/manifest.json` remain available beside the PNGs.

Missing values, rejected duplicate grains and incomplete PC dates remain gaps
on the supplied-date calendar. No holiday calendar is invented. The run's Currency
supplies the amount unit; source values are not rescaled. Currency and Notion
are retained in the workbook PnL scope sheet, and each chart retains every
contributing GOP/PTF source reference.

## Risk

VaR, SVaR and stress-test series are plotted, along with other metric series
referenced by existing review candidates. The complete series identity includes
limit, portfolio, PC, indicator, definition, unit, version and populated scenario
axes. No portfolio or non-additive risk totals are created.

Each chart has one panel showing observed risk values in their supplied units.
Limit-bound lines, utilization panels, breach/proximity markers and warning
thresholds are removed with the limit-consumption analysis. Missing, conflicting
and incomparable observations break lines. Every chart uses the union of valid
dates supplied across SGMR, including dates before and after its own series'
observations. These dates remain gaps for that series; no additional calendar
dates or values are invented. Chart index/manifest date bounds describe this
full displayed calendar, not the individual series' coverage.

Symbols identify movement screens, independent limit-history changes and other
review candidates. Movement-outlier markers use percentage-change
population `abs(z) >3` flags at the current observation in their exact series.
Volatility-change and persistent-trend screens and their interval shading are removed.
Links use source identifiers and full series identities. Unmatched workflow
findings stay in the evidence report rather than being attached to a guessed
observation. Risk commentary is supplied directly to the agent and creates no
automatic chart markers. The manifest retains each linked candidate and its
qualification; review order is not policy severity.

## Runtime and validation

Matplotlib is an agent-package dependency, managed with `uv`. PNG export uses
the headless Agg canvas directly. It needs no browser, JavaScript, CDN resources
or model calls. Direct Figure objects avoid GUI windows and leave the caller's
pyplot backend unchanged. See the [Matplotlib Agg example](https://matplotlib.org/stable/gallery/user_interfaces/canvasagg.html).

Rendering consumes figures lazily and clears each figure after export, including
on export failure. Save failures retain their exception and traceback, but clear
unwound frame locals so retained exceptions do not keep Agg pixel buffers alive.
Risk figures additionally release the renderer caches held by their text artists
before clearing them, freeing completed pixel buffers without process-wide
garbage collection. This cleanup does not change PnL figure behavior or PNG
resolution, labels, dates, markers and evidence metadata.
A process-local lock serializes chart generation and rendering
across report threads because Matplotlib has shared state. Synchronous export
also works when called within an active asyncio loop. Markdown, workbook,
PNG files and indexes are generated in a private staging folder and published
together only after success. Concurrent runs use independent folders. Rendering
errors propagate; no successful report is returned with missing images.

Use the Python 3.12+ isolated uv environment in [AGENTS.md](../AGENTS.md) locally.
The root manager/wrapper environment remains independent. Numerical regressions
stub PNG serialization; dedicated chart tests inspect production Matplotlib figures
and exercise actual headless rendering, while MCP tests run the normal report
path. No live Azure requests are required.

Shared analysis fixtures are registered through `tests/conftest.py` as an opt-in
test plugin. This keeps their visibility stable when file arguments interleave
analysis tests with parent-directory MCP tests. A subprocess regression checks
all six permutations of the risk, chart and risk-MCP files while running only
two numerical tests, without live model calls.
