# mcp_agent_template: OpenTelemetry gap analysis

The one-off Python probe for this dated investigation was removed in the
[26 October compatibility cleanup](../legacy-removal.md). Its source is preserved
in Git history at commit `b5dd347`; commands and results below describe that snapshot.


> Historical research snapshot, 14 October 2026. Recommendations, source
> inventories and measurements below describe that baseline. They are not an
> active backlog or the current runtime contract. See the
> [recording/middleware guide](../observability.md),
> [prompt/runtime guide](../agent-prompts.md) and [documentation index](../README.md).

Date: **2026-10-14**. Baseline:
`40360ed966967fe292105ac4578fdff5228c6864` on `KaFaiLi/private_suite/main`.
Scope: `packages/data-package-agent`, its `mcp_agent_template` settings,
invocation/capture/storage implementation, default provider adapter, and dashboard.
Upstream design and source IDs are in the
[integration research](langchain-langgraph-opentelemetry.md).
The [design simplification review](template-design-simplification-analysis.md)
separately assesses redundant implementations and measured recording duplication.

## Assessment

The template has working local OTel tracing/metrics and rich SQLite recording.
Real stdio and HTTP experiments verified cross-process MCP trace continuity.
The main correctness gaps are **usage normalization in the default Chat
Completions adapter** and **silent span loss with host sampling/attribute limits**.
Standard schema projection, remote export, and portable run attribution require
additional design, but are not evidence that local recording is absent.

Recommendations below are proposed follow-up work. This change implements the
research reports and reproducible diagnostics only; corporate configuration,
runtime behavior, dependency declarations, and lockfiles are unchanged.

## Current design and settings

| Setting or entry point | Current value/behavior | Implication |
| --- | --- | --- |
| `OBS_MODE` | `local` by default; accepts `local` or `off` only | No remote/OTLP mode. `off` disables the owned recorder and does not create its database. |
| `OBS_DIR` | `.mcp_agent_template/observability` | SQLite database is resolved against `APP_ROOT`; subprocesses receive the absolute observation directory. |
| `OBS_SERVICE_NAME` | `data-package-agent` | Used for local process identity, trace provider initialization, and per-runtime metric resources. |
| `OBS_FLUSH_INTERVAL_MS` | 250; minimum 0 | Controls local writer batching; not an OTLP export interval. |
| `OBS_METRIC_INTERVAL_SECONDS` | 5; greater than 0 | Controls the recorder's private periodic metric reader. |
| `obs.capture` | Only `full_redacted` | Complete business content can remain; credential redaction is not content classification or encryption. |
| `LOG_LEVEL` | `INFO` | Controls owned console logging; model/tool capture remains independent of log filtering. |
| Default model path | `GENAI_PROVIDER=genai_manager`, `GENAI_USE_RESPONSES_API=false` | The verified Chat Completions normalization gap affects the configured default adapter. |
| OTel setup | API/SDK dependencies; custom local span processor and metric exporter | No OTLP exporter dependency, OTel LoggerProvider, or standard exporter bootstrap. |
| Managed tracing context | `langsmith.tracing_context(enabled=False)` | LangSmith environment flags alone cannot enable its bridge inside owned execution. |
| `AgentBundle` calls | Automatically own recording or reuse an opened recorder | Raw graph execution needs explicit runtime/context ownership. |
| Host tracing | `ObservabilityRuntime.local(settings, tracer_provider=provider)` | Host must install that provider before first registration; its sampler/limits/processors remain authoritative. |
| Capture policy | No payload caps, recording sampling, or automatic deletion in owned configuration | Unbounded payloads, queues and retained data need operational capacity planning. |

Settings evidence:
[typed observation policy](../../src/mcp_agent_template/observability/config.py),
[environment/path propagation](../../src/mcp_agent_template/config.py),
[provider/metric wiring](../../src/mcp_agent_template/observability/recording/otel.py),
[managed context](../../src/mcp_agent_template/observability/context.py).

```mermaid
flowchart LR
    B[Bundle invocation] --> I[InvocationScope and application run IDs]
    I --> G[Native LangChain agent / LangGraph]
    G --> C[ObservationCallback: model usage and graph events]
    G --> M[Observation middleware: rounds, dispatch, tools]
    C --> R[Runtime: redaction, event IDs, metrics]
    M --> R
    R --> O[OTel provider and local processors]
    O --> Q[Single-writer queue]
    Q --> S[SQLite]
    S --> V[CLI exports and read-only dashboard]
    G --> F[FastMCP native client/server tracing]
    F --> O
```

Invocation, round, request-attempt, native callback, and trace/span IDs represent
different boundaries. Child invocations reuse inherited observation callbacks;
duplicate model-start delivery is guarded. Root totals include child usage once.
Model content is captured through callbacks, effective dispatch requests through
the innermost middleware, and server requests/results through FastMCP middleware.
OTel spans and ordinary Python logs are serialized to the local schema rather
than all being emitted through standard OTLP signal exporters.

## Gap register

Priority means **P1** correctness/observability trust, **P2** interoperability or
operational readiness, and **P3** optional capability. A conditional gap becomes
required only if its stated deployment goal is adopted. Evidence distinguishes
executed probes, source inspection, and unverified external behavior.

| ID | Priority / status | Gap and impact | Recommended action and acceptance criterion |
| --- | --- | --- | --- |
| G01 | P1 / reproduced | Default Chat Completions responses keep raw provider usage in `response_metadata`, but have no `AIMessage.usage_metadata`. Recorder summary shows one model call, zero calls with usage, and unknown consumption even with valid provider counts. | Normalize documented Chat Completions usage at the adapter boundary. A synthetic response with input 100/output 40 must produce those totals and one usage-bearing call; absent usage must remain unknown. Test the default adapter through the recorder, not only a scripted model supplying pre-normalized usage. |
| G02 | P1 / reproduced | Borrowed host sampling and limits contradict an unconditional full-span recording claim. `ALWAYS_OFF` records zero spans; a two-attribute limit drops the internal session routing tag and also records zero local spans. Both cases report `telemetry_complete=complete` and zero recorder errors. | Report trace coverage separately from event-write completeness. Detect non-recording spans/dropped routing attributes; use a robust routing mechanism or explicitly document host constraints. Acceptance: sampled/limited cases identify missing trace coverage without discarding events or replacing the host provider. |
| G03 | P2 / source + probe | Selected GenAI fields are present on model spans, but local agent/tool spans lack standard operation/name/error projection. Model spans lack provider, response model/ID/finish reason and request metadata projection. Mostly `mcp_agent_template.*` instruments require custom dashboards. | Add a versioned mapping from existing events to a chosen GenAI snapshot. Keep local schema compatibility. Acceptance: representative agent/model/tool errors and successes have the agreed required/available fields, correct span kinds and documented metric units/boundaries. |
| G04 | P2 / source + probe | Cross-process trace context works; application `run_id`/`root_run_id` do not propagate. Server request events have null run IDs. CLI exports include them as process events, potentially including unrelated calls from the same long-lived HTTP server; dashboard run-event queries filter by root ID. | Add explicit allowlisted correlation metadata or associate unscoped events by trace/span plus process identity. Acceptance: two concurrent roots using one HTTP server see only their own server requests/results, with no credentials or prompts in propagation metadata. |
| G05 | P2 / reproduced | `LocalSpanProcessor` redacts its SQLite serialization only. Another processor on the shared provider receives the original attributes/events. An in-memory exporter received a synthetic secret while SQLite stored `[REDACTED]`. | Before any remote/exporter integration, define sanitized instrumentation inputs or a sink-specific exporter projection. Do not rely on processor ordering to sanitize a shared span. Acceptance: every enabled remote sink receives only permitted fields, including exception/status/resource/link content. |
| G06 | P2 / reproduced | The process-global trace provider resource keeps the first recorder's service name. Later recordings with another `OBS_SERVICE_NAME` have that old resource name and the new `mcp_agent_template.service.name`; metric resources are per-runtime. | Define one process service identity, or support explicit provider partitioning without replacing global host ownership. Acceptance: sequential/concurrent recorder services produce a documented consistent trace/metric identity; diagnose incompatible settings. |
| G07 | P2 / source | `on_chain_*` callbacks save graph events but create no native node spans or parent-run span map. Model span parentage follows active application operations, not the complete callback tree. Provider work is not automatically current beneath the callback's model span. | Decide whether node-level OTel topology is required. Add native-run parent mapping or dispatch context where needed. Acceptance: nested runnable/tool/model and worker-thread spans have intended parentage without leaving active context in the stream consumer. |
| G08 | P2 / source + probe | Responses totals are normalized, but cached/reasoning details are omitted from `usage_metadata`; Chat Completions totals are unknown as in G01. The estimator consumes normalized usage and can miss retained raw token categories. | Preserve documented token detail subsets and provenance. Acceptance: input 100 with cache-read 20 and output 40 with reasoning 10 retain totals 100/40 and the subsets without double counting. Unknown/unsupported prices remain unresolved. |
| G09 | P2 / source | The recorder creates its own MeterProvider and has no host meter injection seam or OTel LoggerProvider. Host trace processors do not export these metrics or SQLite log events automatically. | If standard three-signal export is desired, add explicit meter/logger ownership and readers/exporters. Acceptance: trace-correlated logs and metrics reach a local test collector and shutdown flushes only owned resources. |
| G10 | P2 / source | Local queue and retained full-content data are unbounded. Redaction/serialization also occurs on callback/span-end paths; a slow disk or large stream can increase memory and latency despite background writes. | Benchmark payload/stream/concurrency/slow-disk workloads; expose alerts and an explicit configurable overload/retention policy if required. Preserve the current complete-capture default until intentionally changed. Acceptance: publish queue/memory/latency measurements and stated loss/durability behavior. |
| G11 | P2 / source + experiment limits | The agent has no lockfile. Research used public dependencies that satisfy its bounds, not the configured corporate index or Git-provider installations. Root/wrapper core pin 1.6.6 conflicts with agent minimum 1.6.10. | Resolve and lock the agent independently in the corporate environment. Acceptance: normal corporate `uv sync`, relevant tests/build, provider acceptance and selected instrumentor compatibility run on that exact environment. Do not merge the agent into the root environment as part of telemetry work. |
| G12 | P3 / conditional | There is no owned OTLP/export mode; standard endpoint variables alone do not configure it. LangSmith tracing is deliberately suppressed. | If remote monitoring is requested, add an explicit opt-in sink with exporter dependencies, auth/TLS/timeouts and bounded shutdown. Acceptance: local mode has no newly introduced export, off creates no recorder, a local collector receives spans, and exporter failure preserves agent behavior. |
| G13 | P3 / conditional | `make_graph()` returns a raw compiled graph; the bundle recorder/context wrapper is absent. Automatic recording does not cover arbitrary host/server graph invocation. | Provide or document a host lifecycle/context integration for this entry point if LangGraph Server/Studio is supported. Acceptance: actual hosted invoke/stream creates a fresh application context, records outcomes, and flushes on host shutdown. |
| G14 | P3 / source | Hidden provider retry/HTTP/stream work is outside callback capture. The local default adapter has no native token-stream implementation; graph streaming is not proof of model chunk telemetry. | Document provider-specific coverage and instrument supported provider seams only when needed. Acceptance: separate logical attempts, SDK retries, first chunk, first visible output, cancellation and authoritative usage in synthetic provider transport tests; validate live coverage separately. |

## Repository evidence by gap

| Gaps | Files / observed behavior |
| --- | --- |
| G01, G08, G14 | [Default provider conversion](../../src/mcp_agent_template/llm/genai_manager_model.py): `_openai_response_to_ai_message` sets raw usage in response metadata; `_responses_usage_metadata` returns only three totals. [Callback observer](../../src/mcp_agent_template/observability/capture/callbacks.py): successful usage is read from generation message `usage_metadata`. [Estimator](../../src/mcp_agent_template/observability/cost.py) reads the normalized event usage. |
| G02, G05, G06, G09 | [OTel recording](../../src/mcp_agent_template/observability/recording/otel.py): `_PROVIDER` persists process-wide; `_SESSION` is a span attribute used for local routing; local redaction happens in `on_end`; metric provider is allocated per recorder. [Runtime](../../src/mcp_agent_template/observability/recording/runtime.py): completeness checks recording errors/writer health rather than sampled-out or dropped spans. |
| G03, G07 | [Semantic mapping](../../src/mcp_agent_template/observability/semantics.py), [callbacks](../../src/mcp_agent_template/observability/capture/callbacks.py), [middleware](../../src/mcp_agent_template/observability/capture/middleware.py), [invocation spans](../../src/mcp_agent_template/observability/recording/runtime.py). Graph callback events retain native IDs but do not create graph-node spans. |
| G04 | [MCP middleware](../../src/mcp_agent_template/observability/capture/mcp.py), [transport construction](../../src/mcp_agent_template/agent/react_agent.py), [archive query](../../src/mcp_agent_template/observability/cli.py), [dashboard event query](../../dashboard/server.py). Native FastMCP provides trace context, while server capture does not establish an application invocation scope. |
| G10 | [Queue/writer](../../src/mcp_agent_template/observability/recording/storage.py): unbounded `queue.Queue`, no automatic retention. [Redactor](../../src/mcp_agent_template/observability/privacy.py): complete recursive projection before admission to the writer. |
| G11, G12 | [Agent metadata](../../pyproject.toml), [prior validation limitations](../review/logging-middleware-validation-2026-10-13.md), [suite integration boundary](../../../../AGENTS.md). |
| G13 | [Raw graph entry point](../../src/mcp_agent_template/agent/graph.py), [bundle ownership](../../src/mcp_agent_template/agent/bundle.py). |

## Executed checks

All model inputs and responses were synthetic. No authenticated corporate model
or external telemetry backend was called. Local MCP subprocesses and loopback HTTP
were exercised. The authoritative diagnostic output is
[otel-gap-evidence-2026-10-14.json](otel-gap-evidence-2026-10-14.json).

| Check | Result | What it proves |
| --- | --- | --- |
| Existing agent and dashboard tests | **149 passed**, one `langchain.mcp` beta warning, 16.58 seconds | Current unit/local transport/dashboard contracts pass in the specified research environment. |
| Default Chat Completions adapter + real recorder | Raw usage 100 input/40 output retained; normalized usage null; calls-with-usage 0 | G01 is reproduced through production adapter/callback/recorder code without credentials. |
| Responses adapter + real recorder | Normalized totals 100/40; cache-read 20 and reasoning 10 remain only in raw metadata | Total normalization works on this path; G08 is reproduced. |
| Agent invokes real stdio MCP `add(2, 3)` | Answer 5; five server-process spans in the agent trace, parent IDs resolved in recorded spans | Native cross-process trace propagation works; no custom propagation patch is justified by this check. |
| Same operation through loopback HTTP | Answer 5; five server-process spans in the agent trace, parent IDs resolved | Trace continuity also works over HTTP. |
| Server application attribution | Request trace IDs match the agent; request run IDs are null in both transports | G04 is an application correlation gap, not a missing W3C trace carrier. |
| Installed host provider with `ALWAYS_OFF` | Zero local/host spans, run complete, zero recording errors | G02 sampling-related coverage ambiguity. |
| Installed host provider with `max_attributes=2` | Six host spans, zero local spans, run complete, zero recording errors | Session routing attribute eviction silently defeats local span capture. |
| Host provider with separate in-memory exporter | Six local/host spans; exporter keeps synthetic secret, SQLite replaces it | Local redaction does not sanitize sibling exporters (G05). No remote upload occurred. |
| Later service-name settings in one process | Trace resource remains `data-package-agent`; custom span service is `service-a`/`service-b` | G06 resource identity mismatch. |
| FastMCP baggage injection | Carrier contains traceparent but not synthetic baggage | Application attribution cannot currently rely on baggage injection alone. |
| Published research artifacts | Ruff and formatting passed; 38 relative links and JSON syntax verified; all four published probe cases reproduced the captured behavior | Reports and checkout-based diagnostics are internally consistent. |

### Environment and reproducibility

| Component | Research version |
| --- | --- |
| Python | 3.12.14 |
| LangChain / core | 1.4.5 / 1.6.10 |
| LangGraph | 1.2.15 |
| FastMCP / MCP | 4.0.11 / 2.3.0 |
| httpx2 | 2.13.1 |
| OTel API / SDK / semantic-conventions package | 1.45.1 / 1.45.1 / 0.66b1 |
| LangSmith | 0.14.8, tracing disabled during tests/probes |
| pytest / pytest-asyncio / Ruff | 9.1.1 / 1.4.0 / 0.16.9 |

These versions satisfy the agent's declared relevant bounds, improving on the
prior below-minimum cache experiment. They do not establish corporate index,
internal Git-provider, Windows/proxy, billing or production compatibility. The
research environment was a separate uv project under `/workspace/scratch`; no
repository index, provider reference or lockfile was changed.

The `otel_gap_probes.py` probe script (now in Git history) runs each host case in a fresh interpreter
because OTel provider registration is process-global. It subclasses the default
provider with synthetic responses, uses the existing scripted model fixture for
MCP, and writes only a diagnostic JSON summary. Run from the agent package root
after resolving its normal dependencies in the intended environment:

```bash
PYTHONPATH=src:. LANGSMITH_TRACING=false LANGCHAIN_TRACING_V2=false \
  uv run pytest -c pyproject.toml tests dashboard/tests -q

for case in integration sample-off limits exporter; do
  PYTHONPATH=src:. LANGSMITH_TRACING=false LANGCHAIN_TRACING_V2=false \
    uv run python docs/research/otel_gap_probes.py "$case" "/tmp/otel-$case.json"
done
```

The original experiments used `uv run --project
/workspace/scratch/otel-research/validation --locked` in place of `uv run`.
The `integration` case creates temporary recording directories, performs stdio
and localhost HTTP calls, and closes their processes. Host cases use only an
in-memory exporter. The script reports behavior, not a blanket pass/fail verdict;
some recorded outcomes are the gaps being investigated. Trace IDs and counts
can vary with dependency versions.

## Follow-up sequence

1. **Correct observable consumption and coverage:** G01, G02, G08. Add meaningful
   regressions at adapter/recorder boundaries and preserve unknown usage. Separate
   event durability from span availability in recorder health.
2. **Make local traces easier to interpret:** G03, G04, G06, and the needed part
   of G07. Version the semantic projection, retain local events, and keep transport
   spans distinct from logical model/tool accounting.
3. **Verify operational limits and the corporate environment:** G10, G11. Publish
   overhead/slow-storage evidence and generate the agent's independent lockfile
   from the existing approved configuration.
4. **Add remote observability only if selected:** address G05/G09 together with
   G12; choose one LangChain tracing owner. Use a local collector and synthetic
   data first, then verify the intended backend's schema, sampling, parentage,
   failure handling and privacy boundaries.

Full automated SDK HTTP tracing, hosted graph lifecycles, and extra instrumentors
remain conditional capabilities (G13/G14). Existing cancellation, redaction,
child-usage deduplication, writer degradation, stdio cleanup, HTTP shutdown and
dashboard checks are strengths to preserve, not gaps to reimplement.
