# Todo tools: implementation research and selected design

> Dated implementation research, 14 October 2026. Use the
> [maintained todo contract](../agent-prompts.md#todo-tracking) for integration
> and tests; external comparisons below retain their original research scope.

Research date: **2026-10-14**. Scope: `packages/data-package-agent` only.
The selected design uses LangChain's existing `TodoListMiddleware` for a local
execution checklist on every agent. It does not introduce a task scheduler,
shared task database, completion gate, or separate progress UI.

## Primary-source comparison

| Reference | Interface and behavior | Evidence and implication |
| --- | --- | --- |
| Codex | `update_plan` replaces a list of `{step, status}` items; optional `explanation`; three statuses. | Inspected open-source handler and event consumer. A compact checklist can be independent of execution control. |
| Claude Code | Legacy `TodoWrite` replaces a list; current Task tools create, patch, get, and list records by ID. | Official interfaces and documentation, not inspected core handler source. Shared tasks solve a larger coordination problem. |
| LangChain | `write_todos` replaces graph state with `{content, status}` items and returns a tool message. | Inspected versioned middleware source and synthetic graph behavior. It directly fits this package's agent factory. |
| Deep Agents | Uses LangChain's todo middleware; planning is opt-in starting in v0.7. | Official documentation plus subagent source. Todo state isolation is separate from tool availability. |
| Arize Alyx | Write/update/read tools, four statuses, repeated plan context, and a finish gate. | First-party architecture article, without a published implementation or reproducible evaluation. These are optional design choices. |

### Codex

At revision `c6327eba6a5a31304c289f2121cc74f56f9a441b`, the
[protocol types](https://github.com/openai/codex/blob/c6327eba6a5a31304c289f2121cc74f56f9a441b/codex-rs/protocol/src/plan_tool.rs)
define `pending`, `in_progress`, and `completed`, without IDs or dependencies.
The [tool description](https://github.com/openai/codex/blob/c6327eba6a5a31304c289f2121cc74f56f9a441b/codex-rs/core/src/tools/handlers/plan_spec.rs)
asks for at most one active step; the
[handler](https://github.com/openai/codex/blob/c6327eba6a5a31304c289f2121cc74f56f9a441b/codex-rs/core/src/tools/handlers/plan.rs)
parses and emits a session/turn event without enforcing that count. It treats
the execution checklist separately from Codex Plan mode.

The [event consumer](https://github.com/openai/codex/blob/c6327eba6a5a31304c289f2121cc74f56f9a441b/codex-rs/exec/src/event_processor_with_jsonl_output.rs#L513)
replaces the displayed items and ends their display lifecycle when the turn
ends; this is not an all-items-completed gate. The
[rollout policy](https://github.com/openai/codex/blob/c6327eba6a5a31304c289f2121cc74f56f9a441b/codex-rs/rollout/src/policy.rs)
retains function calls/results but excludes the separate `PlanUpdate` event.
That is conversation-history evidence, not a standalone durable task store.

### Claude Code

The [official SDK reference](https://code.claude.com/docs/en/agent-sdk/typescript#tool-input-types)
describes legacy `TodoWrite` items with `content`, `status`, and `activeForm`.
Current `TaskCreate` assigns an ID; `TaskUpdate` patches that ID, including
status, owner, and dependency relationships. `TaskGet` and `TaskList` read the
records. Statuses remain `pending`, `in_progress`, and `completed`, with
`deleted` available as an update operation. Blocking dependencies are separate
from status. The
[SDK changelog](https://github.com/anthropics/claude-agent-sdk-typescript/blob/273b4c87f832a82300e1f9e5db57acd835b862a5/CHANGELOG.md#03142)
records the switch from snapshots to ID-based tasks in v0.3.142.

[Task-list documentation](https://code.claude.com/docs/en/interactive-mode#task-list)
describes persistence across compaction and named lists under `~/.claude/tasks/`.
[Agent-team documentation](https://code.claude.com/docs/en/agent-teams#assign-and-claim-tasks)
describes shared lists, dependency-aware claiming, and file locking against
duplicate claims. Teams and ordinary subagents are distinct. These are published
behavioral contracts; the inspected public Claude Code repository did not expose
the core task implementation. They do not establish that a shared task system is
needed here.

### LangChain and Deep Agents

The [LangChain 1.4.0 middleware source](https://github.com/langchain-ai/langchain/blob/langchain%3D%3D1.4.0/libs/langchain_v1/langchain/agents/middleware/todo.py)
defines `PlanningState.todos` and validates `{content, status}` items with the
three statuses above. `write_todos` returns a `Command` replacing the complete
list and adding a matching `ToolMessage`; an empty list clears it. The
`after_model` hook rejects multiple writes in one model response because their
replacement order would be ambiguous. Sync and async paths use the same rule.
There is no enforced single-active-item constraint or finish gate. The default
guidance permits independent active items and discourages planning trivial work.
[Official middleware documentation](https://docs.langchain.com/oss/python/langchain/middleware/built-in#to-do-list)
documents configurable tool and system guidance.

[Deep Agents documentation](https://docs.langchain.com/oss/python/deepagents/overview#task-planning)
now makes planning opt-in starting in v0.7; earlier defaults should not be treated
as current behavior. Its
[subagent source](https://github.com/langchain-ai/deepagents/blob/master/libs/deepagents/deepagents/middleware/subagents.py)
includes `todos` in `_EXCLUDED_STATE_KEYS`, excluding it from isolated child
inputs and returned updates. Forked children have a different inheritance path.
The source link tracks `master`, inspected on the research date. This supports
explicit per-invocation ownership rather than assuming every child shares the
parent's checklist.

### Arize

The [Alyx article](https://arize.com/blog/how-to-build-planning-into-your-agent/)
adds `blocked`, injects the current plan after the system prompt every iteration,
and rejects finishing with pending or active items. It allows blocked items at
the finish boundary and describes flexible replanning after user redirection.
These are useful alternatives, but the article's claims about Claude/Cursor are
not source-code evidence. Its reported improvements are qualitative rather than
a reproducible benchmark. This change adopts structured tracking without its
additional read/update tools, injected current-plan message, or hard finish gate.

## Selected package behavior

- Install the native todo middleware automatically for every agent construction
  path, including delegated agents. Each invocation owns its checklist; parent,
  sibling, and subsequent invocations do not inherit mutable todo state.
- Preserve native `write_todos` names, schema, full replacement, state updates,
  tool results, validation, and duplicate-write handling. No dependency, owner,
  ID, or `blocked` extension is added. Todo calls coexist with ordinary tools.
- Keep todo guidance in the shared system-prompt builder. A thin middleware
  subclass bypasses only the native sync/async model-prompt append so guidance
  appears once and `bundle.system_prompt` agrees with the provider prompt and
  probe hash. It does not reimplement the tool or state-management hooks.
- Guidance encourages useful multi-step planning, prompt progress updates,
  honest handling of incomplete work, and a substantive final answer. Final
  responses are not blocked by unchecked items; existing execution limits and
  error handling remain authoritative.
- Expose updates through native graph state and existing tool traces. Add no
  persistent checklist store, dashboard panel, or notebook rendering contract.
  State availability alone is not evidence of durable storage or improved model
  task completion.

## Verification and limits

Research inspected the installed LangChain **1.4.5**, langchain-core **1.6.10**,
and LangGraph **1.2.15** environment and the package's minimum LangChain **1.4.0**
source. Four synthetic graph probes passed: full replacement, fresh-invocation
reset, invalid-status rejection, and duplicate writes alongside an ordinary
tool. These checks exercised framework behavior without live model requests.

Implementation validation on **2026-10-14** passed **282 agent/dashboard tests
and 4 subtests**, including 17 new todo cases. Coverage includes construction
paths, concurrent invocation and child isolation, native validation, unrelated
tool execution alongside rejected writes, budgets, state/stream/artifact output,
recording, and single-copy prompt guidance/hash agreement. Existing synthetic
Azure/MCP Foundry probe regressions also passed. The sole suite warning was the
existing LangChain MCP beta warning.

Checks ran from the agent package using the isolated Python **3.12.12** uv
environment documented in `AGENTS.md`, with real sibling packages and the
local-only `langchain-core==1.6.10` override. Production pins were unchanged.
The command used the loopback allowlist, not live provider requests:

```powershell
uv run --project ../../artifacts/foundry-agent --locked --python 3.12 python -m pytest `
    -c pyproject.toml tests dashboard/tests -q --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv run --project ../../artifacts/foundry-agent --locked --python 3.12 ruff check .
uv run --project ../../artifacts/foundry-agent --locked --python 3.12 ruff format --check .
git diff --check
uv build --no-sources --default-index https://pypi.org/simple
```

Ruff, formatting, whitespace checks, wheel and source builds passed. Archive
inspection confirmed the todo module was included and credential JSON files
were absent. A separate uv environment installed the wheel outside the checkout,
imported the existing public agent exports, and completed a synthetic todo graph
round trip with the installed package.

Minimum-version source inspection is not an executed minimum-version
compatibility suite. No live planning-quality test or corporate acceptance run
was performed; synthetic checks do not establish those or provider billing.
