# LangChain/LangGraph and OpenTelemetry: integration research

> Historical research snapshot, 14 October 2026. Recommendations, source
> inventories and measurements below describe that baseline. They are not an
> active backlog or the current runtime contract. See the
> [recording/middleware guide](../observability.md),
> [prompt/runtime guide](../agent-prompts.md) and [documentation index](../README.md).

Research date: **2026-10-14**. Repository reviewed:
`KaFaiLi/private_suite`, commit
`40360ed966967fe292105ac4578fdff5228c6864`.
The `mcp_agent_template` setting means the package and its runtime configuration
under `packages/data-package-agent`, including its corporate provider adapters.

## Findings and recommendation

LangChain/LangGraph expose execution through callbacks, runnable configuration,
and agent middleware. Their documented OpenTelemetry path uses the **LangSmith
SDK** to translate those executions into OTel spans. Two alternatives,
**OpenInference** and **OpenLLMetry**, instrument the same shared callback layer
with different schemas and additional hooks. Installing `opentelemetry-sdk` alone
does not create LangChain graph/model/tool instrumentation or an OTLP exporter.

This template already implements a fourth path: public LangChain callbacks and
middleware, native FastMCP tracing, and an OTel SDK recorder that persists locally
to SQLite. It provides useful application capture without requiring a telemetry
backend. Keep that architecture as the default. Correct the verified usage and
span-completeness gaps before adding an optional remote backend. Select one owner
for each model/graph/tool span and apply privacy policy before adding exporters.

See the [gap analysis](mcp-agent-template-otel-gap-analysis.md) for priorities,
repository evidence, experiments, and acceptance criteria. This delivery changes
documentation and adds research probes; it does not enable a remote service or
change production settings or dependencies.

## The integration layers

```mermaid
flowchart TD
    A[LangGraph execution and LangChain models/tools]
    A --> B[Runnable callbacks: run ID and parent run ID]
    A --> C[Agent middleware: effective requests and policy boundaries]
    B --> D[Chosen tracing adapter]
    C --> D
    D --> E[OTel tracer provider: spans, resource, sampler, limits]
    E --> F[Local SQLite processor]
    E -. optional .-> G[Batch processor and OTLP exporter]
    G --> H[Collector: processing and routing]
    H --> I[Observability backend]
    A --> J[FastMCP client]
    J --> K[MCP params._meta: traceparent and tracestate]
    K --> L[FastMCP server with its own OTel provider]
    L --> F
```

The diagram shows the integration choices; remote export is proposed, not active
in the template. A remote MCP service needs its own sink and does not share the
agent's local database automatically.

| Layer | Responsibility | Boundary to preserve |
| --- | --- | --- |
| Framework execution | Graph nodes, model calls, tools, retries, streams, interrupts | A graph update is not necessarily a model token or a provider HTTP request. |
| Instrumentation | Translate execution callbacks/middleware into spans and measurements | Keep native run IDs distinct from OTel trace/span IDs and application run IDs. |
| OTel SDK | Context, parentage, sampling, attribute limits, processors/readers | Context propagation and span export are separate operations. |
| Export/collection | Serialize, batch, retry, route to backends | An SDK dependency or endpoint environment variable alone does not install an exporter. |
| Backend | Trace views, metrics, search, evaluation | Backend ingestion schemas differ even when transport is OTLP. |

Callbacks provide `run_id` and `parent_run_id`. A tracer can maintain a map of
native runs to OTel spans to reconstruct the framework tree. Middleware can
capture the final request after planning and application policy have altered it,
and can distinguish tool queueing from execution. Both are needed for this
template's application-specific recording [S1, S2, S3].

Do not attach a span in one callback and assume another callback will detach it
in the same task. Async callbacks, worker threads, cancellation, and stream
consumers can cross execution contexts. OpenInference explicitly avoids that
pattern. The template similarly activates context only around owned execution
and detaches it before yielding stream events [S5]. For a provider HTTP span to
be a child of a particular model span, establish that context at the provider
dispatch boundary; callback metadata alone does not establish it.

## Integration options

| Route | How it works | Semantics and capabilities | Fit for this template |
| --- | --- | --- | --- |
| LangSmith SDK OTel bridge | LangChain tracing creates LangSmith runs; the SDK converts run operations to OTel spans, with native parent mapping and OTel context integration. | LangSmith-specific attributes plus GenAI fields; supports an alternate OTLP endpoint and hybrid tracing. | Best if LangSmith is the selected backend. Current managed execution disables this path. |
| OpenInference | `LangChainInstrumentor` wraps `BaseCallbackManager.__init__` and installs an inheritable `BaseTracer`; maps native run parents to spans. | OpenInference fields such as `openinference.span.kind`, input/output, LLM metadata; OTel-compatible export to Phoenix or other consumers. | Useful for Phoenix or the OpenInference ecosystem. Requires separate content policy and compatibility checks. |
| OpenLLMetry / Traceloop | `LangchainInstrumentor` installs a callback handler and wraps graph invocation, command, and middleware seams. | GenAI and Traceloop fields, model metrics, graph-specific detail; uses its own semantic-convention package. | Useful for a Traceloop-compatible backend. More patching surface to validate against the corporate stack. |
| Existing template recorder | Explicit invocation scopes, async callbacks, public agent middleware, FastMCP tracing, custom span processor/metric exporter. | Full redacted application events, selected GenAI model fields, custom `mcp_agent_template.*` metrics, SQLite inspection. | Recommended default for local diagnostics and existing dashboard compatibility. |

OpenInference/OpenLLMetry instrumentation works through `langchain-core`, which
LangGraph uses for runnable execution. A custom corporate `BaseChatModel` can
therefore expose model operations without a vendor-specific HTTP instrumentor.
That does not guarantee provider body, hidden SDK retries, cache detail, or
streaming visibility: those depend on what the adapter actually exposes.

OpenInference's declared compatibility includes LangChain 1.x. OpenLLMetry's
current source contains LangGraph-specific hooks. Neither instrumentor was
installed into the template or executed in these experiments; compatibility
claims are source/documentation evidence, not a corporate acceptance result.

### LangSmith configuration and ownership

The official guide documents `langsmith>=0.3.18` and recommends
`langsmith>=0.4.25` for OTel fixes. The public release observed during research
was `0.14.8`; the `otel` extra supplies the SDK and OTLP/HTTP exporter [S1, S10].

Its documented environment path is:

```dotenv
LANGSMITH_TRACING=true
LANGSMITH_OTEL_ENABLED=true
LANGSMITH_OTEL_ONLY=true
OTEL_EXPORTER_OTLP_ENDPOINT=http://127.0.0.1:4318
OTEL_SERVICE_NAME=data-package-agent
```

This is an upstream configuration example, **not a working switch for the current
template**: `local_execution()` uses `tracing_context(enabled=False)`, and the
template has no exporter setup. LangSmith's normal OTel mode can also send native
LangSmith traces; `LANGSMITH_OTEL_ONLY=true` selects OTel-only delivery. A host
should configure its provider and processors before creating tracing clients.
The current SDK detects an existing global provider and can use it rather than
installing a second one [S4].

For OTLP/HTTP, `OTEL_EXPORTER_OTLP_ENDPOINT` is a base URL; the exporter appends
`/v1/traces`. `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` is the complete signal URL.
LangSmith's hosted base endpoint is `https://api.smith.langchain.com/otel` with
authentication and project headers. A collector can fan out one emitted span
stream to multiple backends. Fan-out does not require enabling several framework
instrumentors [S1].

LangSmith's OTel ingestion buffers children whose ancestors have not yet arrived;
if an ancestor is never exported, its descendants can expire without appearing.
HTTP acceptance alone does not establish trace visibility. Sampling and routing
must keep the required ancestors in the same destination [S1].

### OpenInference and OpenLLMetry ownership

OpenInference accepts an explicit `tracer_provider` and privacy `TraceConfig`.
It records an OTel span for a native run and maintains a native-parent span map.
Its default does not force separation from an existing runtime trace, but it
does not make every callback-created span current across the executed function
[S5]. Its OpenInference schema is a separate contract from OTel GenAI semantics.

OpenLLMetry installs an inheritable callback handler, adds duration/token
instruments, and wraps LangGraph invocations and other seams [S6]. Its README
states that prompt/completion/embedding content is captured by default;
`TRACELOOP_TRACE_CONTENT=false` disables that content path. The template's local
redactor does not automatically sanitize another instrumentor's exporter.

Enabling either alongside the existing model callback can create parallel
representations of the same operation. Usage metrics must have one counting
authority. Extra HTTP spans may be useful, but their duration/usage should not
be added to logical model totals.

## FastMCP and distributed context

FastMCP has native client/server spans and uses the installed OTel provider.
Its API-only default is effectively no-op until an SDK is configured. It
propagates `traceparent` and `tracestate` in MCP `params._meta`, which works for
both stdio and Streamable HTTP. HTTP headers alone do not cover every JSON-RPC
message exchanged in a streaming connection [S7, S8].

FastMCP supports `native`, `propagation_only`, and `off` telemetry modes.
`propagation_only` preserves incoming context while suppressing FastMCP spans;
`off` suppresses both. Keep native transport spans unless another MCP-aware layer
owns them. An application tool-policy span and a transport span can describe
different boundaries; several layers are not automatically a defect.

The template's actual FastMCP **4.0.11** probes verified that server spans
continue the agent trace over both transports. They also verified that server
request events have no application `run_id`. W3C context and application run
ownership are different: the template's Python `ContextVar` state does not travel
to the child process.

The current MCP semantic conventions recommend propagation of configured
propagators, including baggage when used. FastMCP 4.0.11's injection helper
copies only `traceparent`/`tracestate`; the baggage probe confirmed omission.
Do not assume placing application run IDs in OTel baggage solves their transport.
An extension would need explicit, allowlisted application metadata or verified
upstream baggage support, with no credential/prompt values in the carrier [S8].

## Semantic conventions and measurement design

GenAI/MCP conventions are **Development** specifications. During this research
the old OTel GenAI web pages linked to the new
`open-telemetry/semantic-conventions-genai` repository. The analysis pins its
`4e8a2812139b2a999d959e3650e24dfc64e21943` snapshot rather than treating current
documentation as a stable contract [S8]. SDK version `1.45.1` and GenAI convention
revision are distinct version axes.

| Operation | Mapping in the researched convention snapshot | Practical interpretation |
| --- | --- | --- |
| Model inference | `chat`/other applicable `gen_ai.operation.name`; provider and request model; response/usage/error fields when available | `CLIENT` for outbound inference, with `INTERNAL` allowed for operations fully inside the process. |
| Local agent invocation | `invoke_agent`, `gen_ai.agent.name`, `INTERNAL` | Application run identity remains separate; use a real conversation identifier only when available. |
| Tool execution | `execute_tool`, tool name/call ID, `INTERNAL` | Separate logical tool work from MCP wire boundaries and queue waits. |
| MCP exchange | `mcp.method.name`, tool/prompt target, client/server span kinds | Continue context through `params._meta`; attribute transport/session/protocol when exposed. |
| Errors | Error status plus low-cardinality `error.type` when applicable | Handled tool errors and cancellation need explicit outcome rules. |
| Content | Instructions/messages/tool arguments/results are opt-in fields | Preserve rich local capture; use a deliberate projection for remote telemetry. |

The current snapshot defines inference duration and first-chunk histograms as
`gen_ai.client.inference.duration` and
`gen_ai.client.inference.time_to_first_chunk`. Token consumption uses
`gen_ai.client.inference.usage.*` counters, with separate per-operation token
histograms. Its general `gen_ai.client.operation.duration` explicitly excludes
inference. Older integrations may still emit `gen_ai.client.operation.duration`
or `gen_ai.client.token.usage`. Choose and record a convention snapshot; do not
rename instruments based only on an older backend example [S8].

The template's `mcp_agent_template.model.first_token.duration` measures the first visible
content, reasoning, or tool-call fragment, excluding role/usage-only frames.
The convention's first **chunk** measurement has a different boundary. Preserve
the existing measurement and add a separately defined first-chunk measurement
if needed. Callback fragments are not necessarily single tokens, so fragment
counts cannot establish output-token throughput.

Report absent usage as unknown. Cached input and reasoning output are subsets
of totals; adding subsets to total token counts doubles consumption. Monetary
cost also requires the relevant price table, currency, rate units, and version.
The recorder's optional per-million-token estimate is distinct from the suite
manager's encrypted audit and per-1,000-token accounting contract.

## Sources and provenance

All sources below were read on **2026-10-14**. Main-branch source snapshots are
research evidence and are not an assertion that those commits are the installed
corporate dependencies. Experiment versions are in the
[evidence JSON](otel-gap-evidence-2026-10-14.json).

| ID | Primary source | What it establishes |
| --- | --- | --- |
| S1 | [LangSmith: trace with OpenTelemetry](https://docs.langchain.com/langsmith/trace-with-opentelemetry) | Supported bridge, SDK prerequisites, endpoint configuration, hybrid mode, fan-out, distributed-parent ingestion behavior. |
| S2 | [LangGraph observability](https://docs.langchain.com/oss/python/langgraph/observability) | Framework's documented LangSmith tracing path. |
| S3 | [LangChain middleware overview](https://docs.langchain.com/oss/python/langchain/middleware/overview) | Public model/tool middleware extension points. |
| S4 | [LangSmith SDK source, commit 9966fd6](https://github.com/langchain-ai/langsmith-sdk/tree/9966fd69a631369398d7598d8d725868f9c74339/python/langsmith/_internal/otel), and [client provider selection](https://github.com/langchain-ai/langsmith-sdk/blob/9966fd69a631369398d7598d8d725868f9c74339/python/langsmith/client.py) | Run-to-span translation, native-parent mapping, global provider reuse, exporter setup. |
| S5 | [OpenInference documentation](https://arize-ai.github.io/openinference/python/instrumentation/openinference-instrumentation-langchain/), [instrumentor/tracer source, commit e116ec7](https://github.com/Arize-ai/openinference/tree/e116ec7d345e04d27ebb588fdd16936fdb185673/python/instrumentation/openinference-instrumentation-langchain/src/openinference/instrumentation/langchain) | LangChain 1.x compatibility, callback installation, parent maps, context attachment rationale. |
| S6 | [OpenLLMetry LangChain source/README, commit 94d3f04](https://github.com/traceloop/openllmetry/tree/94d3f04bd9a7eec0804562fe8126c01a4f342b18/packages/opentelemetry-instrumentation-langchain) | Callback/graph hooks, metrics, content defaults, instrumentor provenance. |
| S7 | [FastMCP telemetry guide](https://gofastmcp.com/servers/telemetry), [source snapshot e2fcc41](https://github.com/PrefectHQ/fastmcp/tree/e2fcc412001ff7414095c5dc282f94c70299a612/fastmcp_slim/fastmcp) | Native tracing, propagation and telemetry modes; separately checked against installed FastMCP 4.0.11. |
| S8 | [GenAI conventions, commit 4e8a281](https://github.com/open-telemetry/semantic-conventions-genai/tree/4e8a2812139b2a999d959e3650e24dfc64e21943/docs/gen-ai) | Development status, inference/agent/tool/MCP spans, metric definitions, opt-in content and baggage guidance. |
| S9 | [OpenTelemetry Python propagation](https://opentelemetry.io/docs/languages/python/propagation/), [SDK trace source v1.45.1](https://github.com/open-telemetry/opentelemetry-python/blob/v1.45.1/opentelemetry-sdk/src/opentelemetry/sdk/trace/__init__.py) | Context injection/extraction and provider/processor roles. |
| S10 | PyPI metadata: [LangSmith](https://pypi.org/pypi/langsmith/json), [OpenInference](https://pypi.org/pypi/openinference-instrumentation-langchain/json), [OpenLLMetry instrumentor](https://pypi.org/pypi/opentelemetry-instrumentation-langchain/json), [OTel SDK](https://pypi.org/pypi/opentelemetry-sdk/json) | Observed public releases: 0.14.8, 0.1.79, 0.62.4, and 1.45.1 respectively; dependency ownership and extras. |
