# Audit checklist for the 17 October 2026 development datasets

> Dated research worksheet. The open procedures and local source variant below
> belong to that inventory, not a current execution checklist. Use the deployed
> [market-review skill](../../skills/market-activity-review/SKILL.md), its
> references and the [notebook guide](../market-activity-review.md) for the
> maintained workflow and actual source manifest.

Prepared 17 October 2026 from the current files in `devtools/test_source/` and the existing analysis-tool contracts. This work programme converts the [audit research](market-activity-audit-guide.md) into 36 checks that identify the actual input fields, procedure and evidence to retain.

The supplied populations are synthetic development data. The inventory and readiness observations below were checked directly against the files. The substantive audit procedures remain **not performed**; all checkboxes are intentionally open. Complete a checkbox only after recording the result, supporting evidence and review disposition. A completed procedure may still have exceptions or insufficient evidence.

The inventory used a local validation-history variant containing `MOCK_TEAM_A/B`.
The tracked baseline uses FO/MPC labels; that local CSV edit is not included in
the review implementation. See [the recorded input provenance](../review/market-activity-review-validation-2026-10-19.md#first-live-attempt--19-october-2026).
Recheck the actual team labels and accepted-state definitions before applying
the role-mapping limitations below.

## Scope and available data

Use the baseline P&L and risk sources for 1 July 2025 through 30 June 2026. Review the post-trade cases separately using their 30 September 2026 extract snapshot. The post-trade population was independently generated and has no structured desk, trade or P&L linkage. Partial overlap in dates does not make these one connected population.

The separate `pnl_review/input/` folder is a seeded evaluation copy, not additional baseline activity. Do not combine its rows with the baseline. Answer keys are evaluation aids and must remain outside the audit evidence population; they were not used to prepare this checklist.

| Source ID | Current source | Directly checked inventory |
| --- | --- | --- |
| PNL | [AIR P&L workbook](../../../../devtools/test_source/pnl/AIR_PNL_PC_Filtered_Jul2025_Jun2026.xlsx), `Sheet1!A1:S3133` | 3,132 data rows, 261 dates, 12 PTFs and 12 GOPs; FLASH version only; EUR, USD and JPY |
| IA | [Income attribution](../../../../devtools/test_source/income_attribution/attribution.csv) | 3,132 rows, 67 fields, 261 dates, 12 GOPs; no currency column |
| ADJ | [P&L adjustments](../../../../devtools/test_source/pnl/pnl_adjustment_2025-07-01-2026-06-30.csv) | 24 rows and distinct adjustment IDs; valuation dates through 30 June 2026, creation dates through 1 July 2026 |
| VAL | [Validation history](../../../../devtools/test_source/pnl/validation_history_07-01-2025-30-06-2026.csv) | 9,048 rows, 365 request dates; FLASH and STAB; source team labels differ from the tool's FO/MPC roles |
| IA-C | [Attribution commentary](../../../../devtools/test_source/risk_commentary/quarterly_reviews_summary_ia_comment.md) | 53 record blocks across 2025Q3–2026Q2 |
| PNL-C | [P&L commentary](../../../../devtools/test_source/risk_commentary/quarterly_reviews_summary_pnl_comment.md) | 53 record blocks across 2025Q3–2026Q2 |
| SGMR | [Risk consumption](../../../../devtools/test_source/risk_metrics/SGMR_consumption_combined_2025-07-01-2026-06-30.parquet) | 12,528 rows, 149 fields, 48 limit IDs, 12 portfolio labels, 261 dates; VAR, SVAR, STRESS TEST and EXPOSURE; `limUnit=MEUR` |
| COL | [Selected Colibris excess events](../../../../devtools/test_source/risk_metrics/Filtered_Colibris_All_Maket_Excesses_with_llm_tags.csv) | 50 distinct events; 38 absolute-threshold and 12 relative-threshold labels; selected excess population |
| RISK-C | [Risk-metrics commentary](../../../../devtools/test_source/risk_commentary/quarterly_reviews_summary_risk_metrics_comment.md) | 53 record blocks across 2025Q3–2026Q2 |
| STRESS-C | [Stress commentary](../../../../devtools/test_source/risk_commentary/quarterly_reviews_summary_stress_test_comment.md) | 53 record blocks across 2025Q3–2026Q2 |
| VAR-C | [VaR and SVaR commentary](../../../../devtools/test_source/risk_commentary/quarterly_reviews_summary_var_svar_comment.md) | 54 record blocks across 2025Q3–2026Q2 |
| PTC | [Post-trade case Parquet](../../../../devtools/test_source/post_trade_control/dataset/post_trade_cases.parquet) | 280 raw rows, 278 after exact-row deduplication, 277 distinct Case_Id values and 12 control codes; 11 fields |

### Readiness observations that change the audit approach

1. **Validation roles need a mapping.** VAL contains `MOCK_TEAM_A` and `MOCK_TEAM_B`, with states `Validated` and `Official PNL`. The P&L tool matches the roles `FO` and `MPC`; its context schema does not include team aliases. Obtain the role definitions before using a traceable mapped working copy or an independently documented manual join. Do not silently modify the source. Accept `Official PNL` only if the workflow establishes that it constitutes the relevant approval.
2. **P&L and attribution are reviewed independently.** IA has no currency column. Each dataset retains its own source units and independent PC analysis. Cumulative values are display-only. The tool performs no monetary comparison between IA and PNL.
3. **Risk cross-source linkage is unresolved.** A direct identifier inventory found zero COL `sgmrId` matches to SGMR `limId`/`consoId`/`id`, and zero SGMR `colibrisId` matches to COL `excessId`. Similar dates, metrics or PC labels can identify candidates, not confirmed event-to-observation links.
4. **Post-trade dates need a separate consistency check.** Two raw case rows have missing or unparseable execution dates. The latest valid execution date is 30 September 2026, but closure dates extend to 15 December 2026. Retain these as date-quality questions; do not use future closure evidence to establish resolution at the snapshot.
5. **Control descriptions are not transaction evidence.** PTC labels include capture, confirmation and settlement controls, but its rows are cases. They do not contain the complete executed-trade population, counterparty confirmations, settlement messages or collateral movements.

## How to use the checklist

**Available** means the supplied fields support the stated screen. **Conditional** means an essential mapping, definition, history or policy is missing. **Additional review** identifies work beyond the existing tool's automatic checks. None of these labels is an audit result.

For every check record: `Check ID | scope and denominator | method/tool and version | evidence reference | observed exception | contrary evidence | result | follow-up owner | due date | reviewer | review date`.

Use results such as `Not performed`, `No exception in performed procedure`, `Exception for investigation`, `Insufficient evidence` or `Not applicable with rationale`. Leave owner and due date unassigned until agreed. Tool scores, statistical flags and aging bands are screening aids, not approved audit severity or policy breaches. Retain source row/sheet references and distinguish counts of rows, distinct cases, role obligations and findings.

## Establish the evidence population

- [ ] **D01 Preserve the source and review perimeter — Available.** Record the twelve source paths above, SHA-256 hashes, extraction context, period/snapshot and file counts. Preserve originals and write any preparation to separate working copies. Reconcile loaded, rejected, duplicate and retained rows. **Retain:** source manifest, population reconciliation and any transformation log. The PTC CSV is a readable copy of the Parquet, not extra cases.

- [ ] **D02 Verify keys and usable fields — Available.** Check missing/invalid dates, amounts, IDs and ambiguous headers. For PNL use date/version/notion/PTF/currency and verify GOP/PC assignments; for IA use date and the complete hierarchy; for SGMR retain limit, portfolio, metric, unit, version and populated axes; for COL use `excessId`; for PTC distinguish exact-row duplicates from repeated `Case_Id`. **Retain:** rejected/conflicting row registers. Preserve unknown values rather than replacing them with zero or selecting an arbitrary duplicate.

- [ ] **D03 Approve the meaning of fields and joins — Conditional.** Obtain the team/state dictionary, version-to-PnL-type mapping, GOP/PTF/PC hierarchy, currency/scale basis, risk-unit and scenario definitions, and applicable policy materiality/SLA. Record each mapping's owner, effective period and source. **Retain:** approved definitions plus unresolved dependencies. Baseline VAL team labels and `Official PNL` require explicit resolution; the seeded evaluation context cannot supply authority.

- [ ] **D04 Validate period coverage and denominators — Available with calendar qualification.** Compare the 261 observed PNL/IA/SGMR dates and per-series coverage. VAL contains 365 dates and STAB records, whereas PNL contains only FLASH. Create obligations from actual in-scope PNL keys; do not count every history row as an expected sign-off or treat weekends as automatically missing trading data. **Retain:** coverage by series and unmatched history. Obtain an authoritative business calendar and book inception/closure dates before concluding completeness.

## P&L and income attribution

- [ ] **P01 Establish the reported P&L PC series — Available.** Use PNL `Value Date`, `Version`, `Notion`, `PTF`, `GOP`, `PC`, `Currency` and `DTD`. Sum valid unique GOP/PTF contributions by date/PC/currency/version/notion. **Retain:** PC daily totals, constituent source references and separate currency/version/notion populations. Accounting-ledger reconciliation needs additional records.

- [ ] **P02 Investigate unusual daily PC P&L — Available.** Use PC daily DTD totals. The tool screens absolute population z-score **>=3** without a minimum observation count. Review positive and negative extremes and reversal candidates. **Retain:** date/PC/currency/version/notion, amount, PC-date denominator, screen parameters and constituent source references. Request position, pricing or booking evidence for the cause.

- [ ] **P03 Review PC P&L movements — Available.** Inspect PC daily totals and adjacent-observation reversal candidates. PnL cumulative checks and monthly summaries are outside the current analysis. Optional reported YTD is displayed as source aggregates without reconciliation.

- [ ] **P04 Identify PC attribution drivers — Available.** Sum each daily driver and final result across GOP contributions by date/PC. Rank absolute net contributions, retain gross activity after same-day GOP netting, and identify daily leading drivers. **Retain:** PC/date, driver, net/gross amounts, PC-date coverage and constituent references. Cumulative columns are optional display data, without movement/reset checks. Parent/child fields are not automatically additive.

- [ ] **P05 Review unexplained P&L and attribution coverage — Additional review; amounts available.** Inspect IA `Unexplained`, `Market Effect`, `FX`, `Theta/FIN`, `N&M`, `Other`, `No IA`, `ia_not_running` and `ia_not_relevant`, with `Final Result Acc DTD`. Rank absolute unexplained values, persistent signed residuals and reliance on other/unattributed categories by PC after GOP aggregation. **Retain:** selected rows and the precise denominator for any ratio. Use absolute amounts where net P&L is near zero. Obtain the taxonomy before interpreting flags or claiming a driver-level reconciliation; these amounts do not replace sensitivity-based revaluation.

- [ ] **P06 Cover all adjustments affecting the period — Available.** Select ADJ rows where `VALDATEBEGIN <= 2026-06-30` and `VALDATEEND >= 2025-07-01`; separately flag invalid intervals. Check all adjustment types, including entries created after period end. Inspect `ADJUSTMENTID`, `CREATIONDATE`, `SOURCE`, `TYPE`, `NATURE`, `PNLCOMPONENT` and comments. **Retain:** selected/excluded/unresolved population with source rows. Keep full amounts; do not prorate them or add them to reported P&L merely because the interval overlaps.

- [ ] **P07 Reperform adjustment amounts and mappings — Available.** For ADJ calculate `AMOUNT * EXCHANGERATE` and compare with `AMOUNTINEUR`, requiring a positive usable rate. Match `PTF`, `GOP`, `PC` and `CCY` to PNL within the valuation interval. **Retain:** actual/expected EUR, conversion difference and mapping status for all 24 source adjustments. The tool's tolerance is `max(EUR 0.01, abs(expected EUR) * 1e-8)`; this is calculation tolerance, not audit materiality. An internally consistent rate still needs independent market-rate corroboration.

- [ ] **P08 Challenge adjustment rationale and reversals — Available screen; approval conclusion conditional.** Group ADJ by source, portfolio and currency; review gross positive/negative activity, net amount, recurring entries, period-end timing and candidate reversals. Inspect `ADJUSTMENTLINKID`, `DEALID`, `DOCUMENTID`, `INCIDENTID`, `COMMENTS` and available classification fields. **Retain:** adjustment IDs and rationale/support requests. The existing reversal screen is a narrow heuristic; manually review linked entries and subsequent-period reversals outside it. A document reference does not mean the document was inspected; creator identity does not prove independent approval.

- [ ] **P09 Verify separate FO and MPC P&L validation — Conditional on D03.** Build one obligation per PNL GOP/date/version and per required role. Join VAL `gop`, `api_request_date`, `pnlType`, `team`, `active` and `state`; FLASH maps from `PUBLISHED_WW_FLASH`. Classify validated, explicitly unsuccessful, missing, unknown and conflicting evidence separately. **Retain:** role-level obligations, supporting active records and affected PNL rows. The baseline MOCK teams cannot be silently treated as FO/MPC. Current active evidence does not establish validation by an earlier deadline; timing needs workflow definitions and history.

- [ ] **P10 Review attribution and commentary validations separately — Available; narrative corroboration conditional.** Inspect IA `air_fo_validation status` and `air_mpc_validation_status` independently of P09. For IA-C/PNL-C inspect event date, desk/perimeter, review note, managerial validation and Evidence ID. Match scope before using narrative to explain a P&L event. **Retain:** numeric record, commentary line range, claim, contrary evidence and requested support. Attribution validation and managerial validation do not replace P&L sign-off; absence from selected commentary does not prove no review occurred.

- [ ] **P11 Review P&L and income attribution independently — Available.** Retain PC PNL daily observations separately from PC IA driver observations, in each dataset's source units. **Retain:** separate populations, dates, source references, driver rankings and explanatory evidence. No cumulative checks or cross-source monetary reconciliation are performed. Do not treat hypo_pnl_dtd as certified regulatory HPL.

## Risk consumption and excess management

- [ ] **R01 Establish comparable risk series — Available.** Partition SGMR by `limId`, `stranaNodeName`, `stranaPc`, `rmRiskIndicator`, `rmRiskMetricName`, `limUnit`, `consoVersion` and populated scenario/bucket axes. Check `flatStrana` against explicit hierarchy fields. **Retain:** series inventory, dates, missing values and hierarchy conflicts. The current population has VAR, SVAR, STRESS TEST and EXPOSURE labels; do not rename these as Greeks or expected shortfall without definitions. Do not add VaR/SVaR/stress across portfolios as if additive.

- [ ] **R02 Recalculate directional limit consumption — Available screen.** Use SGMR `consoValue`, `limMinValue`, `limMaxValue` and `limType`. For nonnegative values use a positive upper bound; for negative values use the absolute negative lower bound. Utilisation is `abs(value)/abs(applicable bound)`; invalid/missing bounds are unavailable. **Retain:** date/series, signed amount, direction, bound and utilisation. The current absolute-bound screen flags utilisation **>1**; equality is permitted by this screen. Confirm the governing policy before calling it an authorised or unauthorised excess.

- [ ] **R03 Check effective limits and changes — Available candidates; approval conclusion conditional.** Compare `consoValueDate` with `limStartDate`/`limEndDate`; inspect initial/current/temporary min/max values and discontinuities. **Retain:** out-of-period observations and changed-bound candidates. Temporary values must not replace current limits without effective-date and precedence evidence. Obtain the relevant approved limit versions; a date or a populated temporary bound alone does not establish permission.

- [ ] **R04 Review persistent proximity to limits — Available.** Use valid `limRelativeThreshold`, otherwise disclose the tool's 90% warning default. Review three consecutive observed near-limit dates, recurrence and dates with coverage gaps. **Retain:** complete run dates, warning source, utilisation and denominator. Missing observations break runs. These are attention screens, not a supplied policy warning level or proof of intentional avoidance.

- [ ] **R05 Review risk movements and concentrations — Available descriptive screen.** Examine SGMR risk series separately for spikes, changes, shifts, volatility and trends; compare date-aligned commentary without asserting causality. The current defaults include z-score **>3**, change **>=25%**, and at least 20 contiguous comparable observations for statistical eligibility. **Retain:** source series, window, before/after values and methodology. Investigate changing limits, source completeness and definitions before inferring increased risk-taking. Stress and exposure amounts remain model outputs, not independently reproduced valuations.

- [ ] **R06 Reperform selected excess-event usage — Available.** For COL compare `excessLastConsoValue`, `limitValue`, `unit`, explicit percentage `usage` and `excessMaxUsage`. Keep absolute and relative-threshold events distinct. **Retain:** event ID, signed exposure, stated bound, recalculated usage and parsing/definition gaps. The current comparison screen uses 1.5 percentage points, not 1.5%; a maximum more than 1 point below last usage is another candidate. A relative movement trigger is not automatically an absolute-limit breach.

- [ ] **R07 Review excess backlog and chronology — Available screen; historical status conditional.** Use COL `excessStillOpen`, `excessWorkflowStatus`, creation/close dates and last-consumption date. At the tool's 30 June 2026 reference date, calculate qualified age for recorded-open events and duration for closed events; identify contradictory states or reversed sequences. **Retain:** event register with dates and unavailable measures. COL is a selected 50-event extract, not the denominator for all trading activity; its current flags do not reconstruct the daily open backlog or prove an SLA breach.

- [ ] **R08 Challenge excess explanations and validation — Available field review; policy conclusion conditional.** Inspect COL `lastExcessExplanationCause`, action plan, deadline, solution and dates; first-level and LoD2 satisfactory flags, decision details and dates; and limit-increase request/trading/risk approval fields. **Retain:** absent/contradictory evidence, recorded deadlines, request IDs and specific follow-up. Separate source assertions from corroboration; LLM explanation tags are not validation. Assess lateness or approval sufficiency only against applicable policy and complete history.

- [ ] **R09 Reconcile SGMR with Colibris — Conditional; currently no explicit ID overlap.** Seek a genuine `sgmrId` to `limId`/`consoId`/`id` link, or `colibrisId` to `excessId`, then require compatible date, scope, metric, unit, limit type and directional bound. **Retain:** confirmed, ambiguous, semantic-only and unmatched categories separately. With the current zero identifier overlap, request lineage before concluding that an SGMR observation is explained by, approved through or missing from COL. Date/metric/PC resemblance cannot establish a match.

- [ ] **R10 Corroborate risk commentary — Available narrative review; mapping conditional.** Review RISK-C, STRESS-C and VAR-C record dates, desk/perimeter, metric, review notes, managerial validations and Evidence IDs. Link to R01/R05 only with supported scope and timing; preserve differing desk labels. **Retain:** claims and counterevidence with exact source line ranges. A statement that risk reduced requires comparable exposure evidence; repeated wording alone does not establish inadequate review.

## Post trade control case management

- [ ] **T01 Resolve duplicate cases and unknown fields — Available.** Preserve all 280 source rows, identify the two exact duplicate rows, and reconcile the 278 retained rows with 277 distinct `Case_Id` values. Compare non-identical repeated IDs across status, decision, dates and comments; do not select an authoritative version without history. Validate nonnegative whole-number `historic_comments_count`, keeping null distinct from zero. **Retain:** duplicate locations, conflicting versions and unknown-field register.

- [ ] **T02 Analyse outcomes by control — Available.** Group PTC by `control_logical_code`, `status` and `final_decision`; retain the `control_description`. Show row and distinct-case counts with denominators, especially for recorded breaches, justified cases, false anomalies and no decisions. **Retain:** outcome table for all 12 controls. Case outcomes do not measure control coverage, a trade failure rate or false-positive performance across all executions because the full control-execution/trade denominator is absent.

- [ ] **T03 Review open-case aging — Available descriptive screen.** Use the fixed 30 September 2026 snapshot derived from the latest valid execution date, not today's date. For processing cases without a closure date calculate snapshot minus `control_execution_date`; separately identify processing cases with closure dates. Review 30/60/90-day bands and oldest cases by control. **Retain:** Case_Id, age/basis, unknown dates and status. The tool uses closure-minus-execution whenever a closure exists; inspect those contradictions before treating its result as open age. No SLA has been supplied.

- [ ] **T04 Test workflow and date consistency — Available plus additional review.** Check completed cases lacking decision/closure, processing cases with decisions/closure, closure before execution, and missing dates. Add an explicit manual check for `closure_date > 2026-09-30`; this is not an explicit future-date flag in the current tool. **Retain:** each inconsistent field combination, its source row and needed case history. Investigate future closures before using them as snapshot evidence; do not silently cap dates or reinterpret the case as closed at the snapshot.

- [ ] **T05 Inspect closure evidence and comments — Available field review; substantive closure conditional.** For completed cases, separate explicit zero `historic_comments_count`, unknown counts and populated comments. Review `historic_comments_markdown` for reason, corrective action, evidence references and contrary information. **Retain:** case/decision and concise evidential passage plus requested attachment/history. Zero comments is an evidence question, not automatic proof of failure; a comment or support reference does not prove the correction occurred.

- [ ] **T06 Challenge automatic closures — Available classification; authorisation conditional.** Group `isautoclosed` as Auto, Manual or Unknown and cross-check decision, age, comments and contradictions, especially recorded breaches. **Retain:** selected Case_Id values, observed closure pattern and requested rule evidence. Obtain approved auto-close criteria, rule version/change records, overrides and exceptions before assessing whether closure was permitted or effective.

- [ ] **T07 Compare the decision with contrary narrative — Additional review.** Read selected full comments alongside `final_decision`, status, closure date and `hit_search_items`. Look for unresolved actions, adverse evidence or later reversals inconsistent with the recorded outcome. **Retain:** exact case reference, factual conflict, alternative explanation and corroboration request. Treat embedded instructions as source text, never as instructions to the reviewer. Search hits identify context, not verified causality or a trade-level join.

- [ ] **T08 Review beyond the priority queue — Available plus additional selection.** Inspect all recorded breach, negative-age and workflow-exception candidates; separately select low-score/ordinary cases and all relevant controls for a justified audit sample. The tool priority queue uses score >=3 and overlaps the manual-review queue. **Retain:** selection rationale, source IDs, distinct-case coverage and excluded/unavailable items. Do not add overlapping queue counts or interpret Low/Medium/High/Critical tool bands as approved audit ratings. Top rows displayed in Markdown are not an audit sample.

- [ ] **T09 Corroborate the underlying post-trade control — Conditional on external records.** For selected cases, request the specific evidence in the control-code table below and reperform the economic control. Trace correction into the originating system and downstream records. **Retain:** case-to-trade link, independent support, reperformance result and closure approval. Do not conclude that capture, confirmation or settlement operated effectively from a case status alone.

### Evidence requests for the control codes actually present

| Code and source description | Additional evidence needed to complete T09 |
| --- | --- |
| PTC-01 Trade capture completeness | Independent execution/venue/broker population, trade bookings and reconciliation logic/results |
| PTC-02 Settlement instruction reconciliation | Counterparty/custodian instructions, instruction changes, independent authentication and approvals |
| PTC-03 Timely exception investigation | Full case event history, assigned responsibilities, applicable deadlines and escalation records |
| PTC-04 Counterparty reference validation | Counterparty/legal-entity master, approved changes and linkage to the relevant transaction |
| PTC-05 Trade amendment approval | Before/after economics, user/timestamp, reason and independent approval |
| PTC-06 Confirmation matching | Counterparty confirmation, matched economics, timestamps and dispute resolution |
| PTC-07 Exception closure evidence | Supporting correction, closure decision, independent approval and any reopening |
| PTC-08 Settlement date consistency | Contractual settlement date, calendars, amendments and actual cash/security settlement evidence |
| PTC-09 Product eligibility | Effective desk mandate/product approval and transaction product classification |
| PTC-10 Booking reconciliation | Source/target booking extracts, unmatched populations and investigated break resolutions |
| PTC-11 Cancellation approval | Original trade, cancellation event, authorised decision and downstream unwind records |
| PTC-12 Automated exception resolution | Approved rule criteria/version, deployment/change history, execution logs and override/reopen records |

## Combine and conclude only within supported scope

- [ ] **C01 Investigate connected P&L and risk signals — Conditional.** After obtaining an effective-dated GOP/PTF-to-SGMR portfolio/PC mapping, compare unusual P&L, adjustments and risk changes at a compatible date/scope. Keep the four risk definitions separate and preserve any one-to-many joins. SGMR uses MEUR while PNL has row currencies; monetary comparisons or ratios need an approved common-currency/scale conversion. **Retain:** mapping, matched population and hypotheses requiring evidence. Do not combine the independent post-trade case population without a genuine case-to-trade/desk link. Coincidence is not evidence that an excess caused P&L or that a case resolved it.

- [ ] **C02 Complete the evidence and findings register — Available after execution.** For every performed check reconcile its population, exceptions and unavailable results to full output/source records. Record the observed fact, applicable criterion, effect or unquantified exposure, cause supported by evidence, contrary evidence, agreed action and reviewer decision. **Retain:** the workpaper fields above and source locations. Distinguish confirmed misstatement/control failure from unresolved data limitations and management assertions. Do not convert a clean screening result into assurance over untested valuation or settlement controls.

## Procedures that require additional data

These are evidence requests, not failed controls. They translate the broader research into the next scope extension.

| Audit objective | Missing evidence | What cannot yet be concluded |
| --- | --- | --- |
| Independent economic P&L explanation | Opening/intraday positions, trades, cash flows, aligned market data, sensitivities and valuation models | That reported profit is supported by the actual risk taken, or that an attribution residual is a valuation error |
| P&L to financial accounting | Product-control certified P&L, ledger/subledger and journal detail, reconciliation policies | That the extracted P&L agrees with the books and records |
| IPV and valuation adjustments | Independent quotes, valuation inputs, model approvals, reserve calculations and sign-offs | That marks, reserves or day-one profits are justified |
| VaR/SVaR model validity and stress adequacy | Horizon/confidence/calibration definitions, model/data lineage, backtesting P&L, scenarios and independent validation | That the risk numbers are correctly modelled, capture tail risk or support regulatory capital |
| Regulatory PLA or expected shortfall | Formally defined APL/HPL/RTPL series, aligned valuations, model tests and ES calculations | That `hypo_pnl_dtd` is regulatory HPL or that the current four risk labels include ES |
| Approved excesses and timely sign-off | Full limit/workflow history, authority matrix, policies, SLAs and calendars | That an observed excess was authorised or that a missing/late-looking record violated policy |
| Counterparty exposure and collateral | Legal netting sets, agreements, current/future exposure, margin calls and settled collateral | That collateral is sufficient, enforceable or received |
| Confirmation, clearing and settlement | Complete trade population, external confirmations, clearing acknowledgements, custody/payment records | That transactions were agreed, accepted and finally settled |
| End-to-end connected events | Effective desk/book mapping and case/excess-to-trade lineage across sources | That the three extracts describe the same economic event |

## Existing tool coverage and execution order

Use the existing deterministic tools for the checks they implement. Additional review and evidence requests remain separate; no live LLM call is needed merely to calculate the file-based screens.

| Tool | Current source arguments | Main coverage and constraints |
| --- | --- | --- |
| `run_pnl_analysis` | `income_attribution_path=IA`, `pnl_path=PNL`, `adjustments_path=ADJ`, `validation_history_path=VAL`, `income_attribution_commentary_path=IA-C`, `pnl_commentary_path=PNL-C`; all supplied dates | PC PNL outliers/reversals; independent PC attribution driver rankings; full adjustment EUR analysis; standalone validation-history summary and devalidated flags; original commentary handoff. No cumulative or cross-source monetary checks. |
| `run_risk_metrics_analysis` | `sgmr_path=SGMR`, `colibris_path=COL`, `risk_metrics_commentary_path=RISK-C`, `stress_test_commentary_path=STRESS-C`, `var_svar_commentary_path=VAR-C` | Series/consumption/statistical screens, workflow and source-link candidates; complete commentary text is passed directly to the agent without parsing. Analyses all supplied dates; no narrower review-date parameter. No independent model recalculation |
| `run_post_trade_review` | `folder_path` = absolute path to `devtools/test_source/post_trade_control/dataset/` | Case population, deduplication, outcomes, aging, workflow, comments, auto-close and review queues. T04 future-closure check and T07 substantive narrative review require additional work. T09 needs underlying records |

Source IDs above refer to the linked files in the inventory; pass their actual absolute paths, not the labels. Read the package skill contracts before a run. Resolve D03 dependencies on documented working copies/context only; preserve raw-file hashes. Use the report paths returned by each tool.

Run D01–D04 first, then the independent P&L/risk/case screens, then the conditional reconciliations and evidence follow-ups. Inspect full output workbooks before drawing population-wide conclusions: P&L Markdown tables show at most 12 rows with limited examples; risk detail tables show at most 15; post-trade Markdown shows the top 10 controls and 15 priority rows. The current PTC population has 12 controls, so its visible control table cannot cover all controls.

The numerical tolerances and screening defaults above are the current implementation's definitions. Full formulas and limits are documented in the [P&L dataset contract](../../skills/pnl/references/dataset.md), [P&L interpretation guide](../../skills/pnl/references/interpretation.md), [risk dataset contract](../../skills/risk-metrics/references/dataset.md), [risk methodology](../../skills/risk-metrics/references/methodology.md) and [post-trade dataset contract](../../skills/post-trade-control/references/dataset.md). They support consistent screening; audit materiality, policy applicability, sampling and final conclusions require separate evidence and judgement.
