# Template redundancy and design simplification analysis

> Historical research snapshot, 14 October 2026. Recommendations, source
> inventories and measurements below describe that baseline. They are not an
> active backlog or the current runtime contract. See the
> [recording/middleware guide](../observability.md),
> [prompt/runtime guide](../agent-prompts.md) and [documentation index](../README.md).

Date: **2026-10-14**. Reviewed baseline:
`e96108d8d92ad896856e087ba7685a84f94ecb5b` in `KaFaiLi/private_suite`.
Scope: the Data Package Agent's `mcp_agent_template` runtime, builders,
observability, provider adapters, development metadata and presentation code.

Implementation follow-up, **2026-10-14**: D01–D05 and D07–D08 have been addressed
in a separate worktree. D06 was explicitly excluded by the user. See the
[implementation and validation report](../review/template-design-simplification-validation-2026-10-14.md)
for the migration contract, implemented scope and local validation limits.
The measurements and findings below describe the reviewed baseline.

Later cleanup, **2026-10-14**: context inspection helpers and their MCP diagnostic
tools were removed. At that point the catalog had four example tools and the notebook
catalog displays metadata without lint scores. The baseline inventory below and
its JSON evidence retain the original measurements.

## Verdict

The template has accumulated the responsibilities of a small agent runtime.
For a starter that connects an agent to MCP tools, the default path requires
substantial middleware, invocation ownership, telemetry and presentation knowledge.
Its concrete tool catalog still consists of demonstrations and context utilities.
Further infrastructure should follow a real application use case.

The strongest simplification opportunities are identifiable duplication:
superseded policy helpers, two builder preparation paths, planning closures used
only to extract a directive, overlapping provider adapters, and repeated full
telemetry payloads. These create maintenance and storage costs beyond the
behavior they provide.

Several complex mechanisms have good reasons to exist. Shared budgets, separate
decision/execution ordering, cancellation-safe shutdown, credential redaction,
child attribution, and native MCP tracing protect documented contracts. Preserve
those guarantees while reducing implementations and representations of them.

This was an analysis and proposed refactoring sequence at the reviewed baseline.
Configuration and dependencies remain unchanged by the implementation follow-up. The
[OpenTelemetry gap analysis](mcp-agent-template-otel-gap-analysis.md) covers
correctness and interoperability; this review covers design cost and redundancy.

## Measured size and duplication

The runtime contains **52 Python modules and 7,088 physical lines**, including
comments, docstrings and blank lines. These counts describe maintenance surface;
they do not measure complexity, usefulness or execution overhead by themselves.

| Runtime area | Modules | Physical lines | Interpretation |
| --- | ---: | ---: | --- |
| Observability | 19 | 2,659 | 37.5% of runtime source; an application recorder subsystem in its own right. |
| Agent construction/runtime | 12 | 1,654 | Includes active invocation policy and legacy helper implementations. |
| LLM layer | 3 | 938 | Local adapter alone is 795 lines despite a shared adapter option. |
| Top-level modules | 6 | 1,074 | Includes the 620-line notebook presentation module. |
| MCP server | 6 | 354 | Primarily demonstration tools and server plumbing. |
| Skills | 3 | 212 | Small loader/catalog subsystem. |
| Context utilities | 3 | 197 | Token estimation and tool linting. |

The default factory installs **seven required middleware objects**, including
five model-call wrappers. An application can add more. A skill-less agent still
gets a planning middleware whose directive is `None`. This is evidence of a
large default execution surface, rather than proof that every wrapper is wasted.

### Serialized payload experiment

A scripted native model called a local synthetic tool returning 40,020 bytes per
result. No provider, MCP transport or external service was contacted. The normal
recorder ran with its default full-content policy; one variant used `ainvoke`,
and two used `astream(stream_mode="values")`.

| Scenario | Distinct tool-result bytes | Total serialized payload-column bytes | Bytes copied into `captures` | Tool-payload marker occurrences across tables |
| --- | ---: | ---: | ---: | ---: |
| One tool round, `ainvoke` | 40,020 | 767,892 | 303,601 | 17 |
| One tool round, values stream | 40,020 | 933,723 | 386,503 | 21 |
| Four tool rounds, values stream | 160,080 | 6,487,102 | 2,718,958 | 156 |

In the four-round sample, all **72 capture rows had byte-identical payloads to
their corresponding event rows**. Capture mirroring accounted for **41.9%** of
the measured serialized column bytes. Additional repetition came from growing
message histories in graph callbacks, stream snapshots, model-round inputs,
effective requests, native model input and tool results.

The total includes events, captures, logs, feedback, run payloads/summaries,
spans and metric collections. It includes useful metadata as well as repeated
tool content, so the 40.5x ratio to original tool bytes is an amplification
observation, not a claim that all additional data is unnecessary. These are
single synthetic recordings, not disk-size, RAM, latency or production throughput
benchmarks. No recorder errors occurred. Complete measurements are in
[template-design-evidence-2026-10-14.json](template-design-evidence-2026-10-14.json).

## Prioritized findings

**High** means concrete duplication worth addressing early. **Medium** means
simplification needs a contract or workload decision. **Low** means cleanup or
presentation improvement. Proposed removal always requires checking external
imports and preserving the supported behavior.

| ID | Priority | Evidence and design cost | Simplification and validation |
| --- | --- | --- | --- |
| D01 | High | Legacy `sequential_tool_node`, `single_tool_call_hook`, planning/post-model adapters, and `_make_concurrency_wrapper` coexist with `PlanningMiddleware`, `ToolRoundPolicyMiddleware`, `ToolExecutionMiddleware` and `ChildConcurrencyMiddleware`. Active builders use the newer policy. Some older tests exercise only the old helpers. | Retire private obsolete paths and deprecate importable helpers if necessary. Keep active-builder regressions for ordering, trimming, independent roots and child capacity. Preserve the small tool-wrapper adapter still used for caller-supplied concurrency. |
| D02 | High | Both builders prepare MCP/skills/model/prompt/tools, extract a planning directive, and construct nearly the same bundle. The shared `build_graph` already consolidates native graph assembly, but preparation remains duplicated. The tree builder also performs an O(n²) duplicate-name check before the shared factory's `Counter` check. | Factor the remaining repeated preparation into a small internal helper. Build single agents and tree leaves from that path while preserving public signatures, root-only application middleware and diagnostics. Reuse the existing namespace validator with an agent-specific error prefix. Avoid another general builder framework. |
| D03 | High | `make_skill_planner_hook` and `make_delegation_hook` return state-aware closures. Builders invoke them with an empty dummy state to recover a `SystemMessage`, then `PlanningMiddleware` performs the real current-turn check again. | Return `SystemMessage | None` directly from one directive builder. Keep current-turn logic in the active middleware. Verify the directive appears once per user turn and is absent from persisted history. Preserve existing helper imports through a compatibility wrapper if required. |
| D04 | High | `events.payload` is copied into `captures`, `logs` and `feedback`; `runs` also repeats selected event payloads. Inspected CLI/dashboard queries predominantly read `events`/`runs`/`spans`, and every capture payload in the experiment was an exact event copy. | First replace exact capture mirroring with a view or event reference, retaining read/export contracts. Handle schema versioning and historical databases explicitly. Add lossless round-trip, read-only dashboard and live-WAL checks. Do not promise a measured I/O saving from column-byte counts. |
| D05 | High | Callback capture, application middleware and invocation streaming retain overlapping full histories and results. `capture.stream` alone contributed 978,247 event bytes in the four-round sample before the captures-table copy. Equivalent content is repeatedly serialized/redacted. | Define canonical payload ownership: effective request, native response, tool outcome and final state. Represent other observations with identities/deltas/references where semantics permit. Preserve pre-policy versus effective request differences and native artifacts. Begin with lossless deduplication, not sampling or truncation. |
| D06 | Medium | The 795-line local `GenAIManagerChatModel` implements message/request/result conversion alongside the optional shared `socgenai_llm.GenAIChatModel`, which already owns these responsibilities in the suite. The earlier probes demonstrated divergent usage normalization. | Select one canonical Azure adapter after compatibility work. Keep the agent's model selection layer thin and retain compatibility for existing local adapter users. Compare request precedence, tool schemas, refusal/errors, usage, streaming and client lifetime before consolidation. Current core pins prevent simply importing the sibling wrapper into the agent environment. |
| D07 | Medium | A 772-line observability runtime owns both sinks and graph invocation/stream driving. `RunContext` carries observation references; `InvocationScope` reads execution deadlines and writes callback configuration. This coupling makes raw native graph use require extra context knowledge. | Keep execution policy and recording identity separate, but make their interaction explicit at the existing bundle invocation boundary. One owner should drive invocation and terminal outcomes. Remove pure forwarding methods/unconsumed fields where safe. Retain cancellation shielding, stream detachment and flush ownership; do not flatten lifecycle logic blindly. |
| D08 | Medium | The tree reparses the same skills directory per node. A separate loop builds a child bundle for every tree occurrence, even though catalogs are immutable and MCP tools are already shared. | Cache parsed skill catalogs within one tree build, keyed by resolved path; apply independent selections per node. Measure real large-tree workloads before caching compiled agents/models or adding a global cache with invalidation rules. Preserve child invocation isolation. |
| D09 | Medium | The default path exposes overlapping-looking limits: rounds, native recursion, root model/tool counts, external capacity, child capacity, root timeout, child timeout and transport timeouts. The recursion formula depends on middleware count; default factory recursion limit is 194, while the bundle fallback is 32 and config prose still describes roughly iterations × 3. | Document each limit's units and scope; centralize the recursion calculation and remove the stale fallback when every bundle has an explicit bound. Preserve distinct resource constraints. Add a clear effective-limits diagnostic rather than another policy engine. |
| D10 | Low/Medium | `notebook.py` combines decorative widgets, reasoning/message interpretation, nested artifact rendering and stream ownership. It rerenders the entire message history for every values snapshot and retains all cards. A fixed-height panel bounds the viewport, not memory or rendering work. The dashboard provides another inspection UI with different live/durable behavior. | Keep notebook presentation optional and reuse existing message interpretation. Update changed messages/deltas, preserve same-ID replacements and child artifacts, and introduce view pagination/virtualization if real workloads need it. Choose which viewer to extend for a demonstrated use case. Do not merge live notebook rendering into the SQLite dashboard backend. |
| D11 | Low | Unconsumed donor/generalization remnants include `schema_descriptor`, `summary_request`, a second `fingerprint` function, `SERVER_KEY` and `_invocation_manager`. Agent definitions are also fully retained for each run despite a build fingerprint/source field. | Remove unconsumed helpers/fields after import review. Keep one fingerprint algorithm and store reusable definitions once with explicit references if repeated-run volume warrants it. `response_descriptor` remains used by request snapshots and should be retained. |
| D12 | Low | Dev tools are repeated across the `dev` extra, `all` extra and `dev` dependency group with different floors; Ruff is in the extras but absent from the group. Developer commands and historical documents can imply different package roots or obsolete behavior. | Define one approved development workflow and update current guides to link it. Treat plans/old comparisons as dated evidence. Preserve corporate indexes, Git refs, pins and configuration until a separately scoped change is authorized. |

### Concrete obsolete-path inventory

The candidate definition spans total **170 physical lines**, including docstrings.
That is about 2.4% of runtime source. This is a modest cleanup estimate; it does
not justify rewriting the entire package or claiming a large performance gain.

| File | Candidate definitions | Checked repository usage |
| --- | --- | --- |
| [agent/react_agent.py](../../src/mcp_agent_template/agent/react_agent.py) | `sequential_tool_node`, `_sequential_tool_call_wrapper`, `sequential_tool_middleware`, `_PlanningMiddleware`, `_PostModelMiddleware`, `planning_middleware`, `post_model_middleware`, `single_tool_call_hook` | Some have direct tests; others are referenced only by the legacy helper chain. Active builders install the newer runtime middleware. |
| [agent/multi_agent.py](../../src/mcp_agent_template/agent/multi_agent.py) | `_make_concurrency_wrapper` | Direct tests call it; the active builder uses invocation-owned `ChildConcurrencyMiddleware` or a caller wrapper. |
| [agent/composition.py](../../src/mcp_agent_template/agent/composition.py) | `schema_descriptor` | No checked runtime/test call site. Other descriptor functions remain active. |
| [capture/build.py](../../src/mcp_agent_template/observability/capture/build.py) | `fingerprint` | No checked import/call of this helper. The factory computes a fingerprint independently. Identically named local variables are not calls to this helper. |
| [capture/requests.py](../../src/mcp_agent_template/observability/capture/requests.py) | `summary_request` | No checked call site; the template currently has no summary/compaction caller. |

Definitions, AST name-load references, tests and active factory paths were inspected.
Static reference counts do not resolve dynamic imports, external consumers or
same-name variables automatically; the evidence file includes those limitations.
The retained `_ToolCallMiddleware`/`tool_call_middleware` pair supports callable
child concurrency and is outside the removal estimate.

## Complexity to preserve

| Mechanism | Why it exists | Refactoring boundary |
| --- | --- | --- |
| Tool decision trimming and execution gate | One limits model choices per turn; the other prevents execution overlap. Existing requirements explicitly select both. | Consolidate implementations of each, while retaining both contracts. |
| Root budget and child/external gates | A shared root allowance limits the entire tree; delegation must release external capacity so children can use it. | Keep reservations before side effects and invocation-owned gates. |
| Exact tool rounds and native recursion safety | Business rounds and graph node steps have different units. Middleware changes the native step count. | Centralize calculation/documentation, preserve separate protections. |
| Application run, model round, request attempt and OTel span IDs | Retries, children and native callbacks represent different boundaries. | Keep identities with demonstrated consumers; define joins explicitly. |
| Recorder shutdown and cancellation handling | Existing tests cover partial startup, repeated cancellation, writer errors and clean continuation. | Preserve cleanup/error semantics through any relocation. |
| Native FastMCP tracing plus application tool spans | Transport requests and logical application policy can have distinct boundaries. | Keep upstream tracing; remove duplicate representations only after boundary review. |
| Manager monetary budget and agent call limits | Provider spending and agent operations are different accounting domains. | Keep manager charging authoritative and agent limits as execution policy. |
| Explicit reusable recorder | A long-lived application can reuse it across calls; CLI/server already do this. | Use the existing lifetime seam to avoid unnecessary one-shot recorder churn. |

These requirements distinguish purposeful defensive code from unnecessary
generalization. Extra instrumentation layers, a custom graph scheduler, another
provider registry, or a new persistence framework would increase the maintenance
surface before these measured issues are resolved.

## A smaller target design

```mermaid
flowchart TD
    S[Settings and provider selection] --> B[Shared node preparation]
    T[Agent tree specification] --> B
    B --> G[Native create_agent graph]
    G --> P[One active implementation per execution policy]
    C[Bundle invocation boundary] --> G
    C --> R[Application-owned recorder]
    R --> E[Canonical events and payload references]
    E --> D[SQLite read model]
    D --> V[CLI and optional viewers]
```

This retains native graph execution, tree composition and local recording. It
reduces repeated preparation and capture/storage representations. It does not
require replacing LangChain MCPAdapter or inventing a new framework.

The desired authority is one shared provider adapter for Azure semantics, one
node preparation path, one current-turn directive decision, one implementation
of each runtime policy, one invocation owner and one canonical persisted payload.
Separate views and transport observations can continue to reference that data.

## Refactoring order and migration cost

1. **Low-risk cleanup:** remove unconsumed private fields/helpers; document and
   deprecate public legacy helpers; move their meaningful tests onto the active
   builders. Estimated candidate spans are 170 lines, not a guaranteed deletion.
2. **Consolidate preparation:** return directives directly; share node preparation
   and namespace validation; cache skill parsing within a build. Verify single
   and tree-leaf equivalence with explicit intended differences.
3. **Remove exact persisted copies:** introduce compatible views/references for
   mirrored capture payloads. Version the storage migration and prove historical
   exports/dashboard queries still read complete data.
4. **Reduce repeated capture work:** measure canonical payload/delta designs on
   realistic histories, nested artifacts and retries. Keep full redacted capture,
   provenance and pre/post-policy distinctions. Any capture-policy change needs
   an explicit product decision.
5. **Consolidate provider ownership:** resolve the agent/shared-wrapper dependency
   contract separately, then migrate through a compatibility layer. This is the
   highest-risk simplification because it can change provider behavior and lifetime.
6. **Optimize presentation and settings:** update changed messages rather than
   rendering whole histories; unify developer guidance and effective-limit
   diagnostics. Benchmark before adopting more caches or subsystems.

Before changing runtime behavior, keep regressions for concurrent roots,
root/child token accounting, sequential decisions/execution, gates/budgets,
timeouts, early stream closure, redaction, handled tool errors, schema conflicts,
historical/read-only SQLite access and partial recorder failure. Prior 149-test
results are recorded in the OTel report; those tests were not rerun for this
documentation-only follow-up, and no refactoring performance gain is claimed.

## Evidence and reproduction

The main implementation references are
[graph factory](../../src/mcp_agent_template/agent/factory.py),
[policy middleware](../../src/mcp_agent_template/agent/runtime/middleware.py),
[runtime context](../../src/mcp_agent_template/agent/runtime/context.py),
[bundle](../../src/mcp_agent_template/agent/bundle.py),
[recorder](../../src/mcp_agent_template/observability/recording/runtime.py),
[SQLite writer](../../src/mcp_agent_template/observability/recording/storage.py),
[callbacks](../../src/mcp_agent_template/observability/capture/callbacks.py),
[local provider adapter](../../src/mcp_agent_template/llm/genai_manager_model.py),
[shared wrapper design](../../../socgenai-llm/docs/socgenai-llm-design.md),
[notebook renderer](../../src/mcp_agent_template/notebook.py), and
[development metadata](../../pyproject.toml).

The shared wrapper's core pin is 1.6.6; the agent requires at least 1.6.10.
Its corporate Git-installed wrapper reference must also be verified independently.
The side-by-side source review establishes overlapping responsibilities, not
drop-in compatibility with the installed corporate provider.

Reproduce basic static counts from the agent package root with standard Python:

```python
from collections import Counter
from pathlib import Path

root = Path("src/mcp_agent_template")
files = list(root.rglob("*.py"))
lines = Counter()
for path in files:
    relative = path.relative_to(root)
    area = relative.parts[0] if len(relative.parts) > 1 else "(top level)"
    lines[area] += len(path.read_text(encoding="utf-8").splitlines())
print(len(files), sum(lines.values()), dict(lines))
```

To verify exact capture mirroring on a synthetic recording, use:

```sql
SELECT COUNT(*) AS identical_rows
FROM captures AS c JOIN events AS e ON c.event_id = e.event_id
WHERE c.payload = e.payload;

SELECT event_name, COUNT(*) AS rows,
       SUM(LENGTH(CAST(payload AS BLOB))) AS payload_bytes
FROM events GROUP BY event_name ORDER BY payload_bytes DESC;
```

The payload probe can be reproduced with the agent's installed dependencies and
existing scripted model fixture. Run from the package root with `PYTHONPATH=src:.`
and LangSmith tracing disabled, as in the earlier OTel experiments:

```python
import asyncio
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from langchain_core.messages import AIMessage
from langchain_core.tools import tool

from mcp_agent_template.agent import build_agent
from mcp_agent_template.config import Settings
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.recording.storage import read_rows
from tests.support.models import ScriptedModel


@tool
async def payload(index: int) -> str:
    """Return a large synthetic payload for recorder volume inspection."""
    return f"SYNTHETIC_PAYLOAD_{index}:" + "x" * 40000


async def main():
    with TemporaryDirectory() as temporary:
        for rounds, streamed in ((1, False), (1, True), (4, True)):
            settings = Settings(
                _env_file=None,
                app_root=Path(temporary) / f"{rounds}-{streamed}",
                obs={"flush_interval_ms": 0},
            )
            responses = [
                AIMessage(
                    content="",
                    tool_calls=[
                        {"name": "payload", "args": {"index": index}, "id": f"call-{index}"}
                    ],
                )
                for index in range(rounds)
            ] + [AIMessage(content="complete")]
            async with ObservabilityRuntime.local(settings) as recorder:
                bundle = await build_agent(
                    settings,
                    model=ScriptedModel(responses=responses),
                    mcp_tools=[],
                    extra_tools=[payload],
                    observability=recorder,
                )
                if streamed:
                    async for _ in bundle.astream("synthetic request", stream_mode="values"):
                        pass
                else:
                    await bundle.ainvoke("synthetic request")
            sizes = {}
            for table in (
                "events",
                "captures",
                "logs",
                "feedback",
                "runs",
                "spans",
                "metric_points",
            ):
                rows = read_rows(recorder.path, f"SELECT payload FROM {table}")
                sizes[table] = sum(len((row["payload"] or "").encode()) for row in rows)
            summaries = read_rows(recorder.path, "SELECT summary FROM runs")
            total = sum(sizes.values()) + sum(
                len((row["summary"] or "").encode()) for row in summaries
            )
            print(
                json.dumps(
                    {
                        "rounds": rounds,
                        "streamed": streamed,
                        "payload_bytes": total,
                        "tables": sizes,
                    }
                )
            )


asyncio.run(main())
```

These measurements used the same isolated public-PyPI uv environment as the
earlier OTel probes: Python 3.12.14, LangChain/core 1.4.5/1.6.10, LangGraph 1.2.15,
OTel SDK 1.45.1. They establish local structural repetition with synthetic data.
Corporate/provider acceptance, production workload overhead and the effect of
any proposed refactoring remain unverified.
