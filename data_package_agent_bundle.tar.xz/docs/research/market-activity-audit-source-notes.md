# Market activity audit risk and post trade source notes

Research date: 17 October 2026. Scope: cross-asset investment-bank trading activity,
with global prudential principles and selected US, EU and UK examples. These notes
support the adjacent [audit guide](market-activity-audit-guide.md); they do not
establish the compliance status of any bank. No desk data was supplied or tested.

Basel standards are an international baseline. Legal obligations require an
applicability assessment by regulated entity, jurisdiction, instrument,
counterparty classification, clearing status, business date and exemptions.
Regulatory reporting, internal risk management and accounting can have different
perimeters and P&L definitions. The procedures below are proposed audit work,
not verbatim regulatory requirements.

## Risk measurement and P&L definitions

| Topic | Source-supported finding | Practical audit implication |
| --- | --- | --- |
| FRTB P&L definitions | Basel APL includes intraday and new/modified trades and time effects, with specified exclusions. HPL revalues the prior day's closing positions using current closing market data. RTPL uses the desk risk model's valuation engines and risk factors, including non-modellable risk factors. [MAR10.31–10.33](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/10/inforce/2023-01-01/published/2020-03-27) | Obtain an explicit bridge from reported desk P&L to APL and HPL; do not treat regulatory APL as the unadjusted accounting number. |
| Backtesting and PLA | Backtesting compares one-day VaR with APL and HPL. Regulatory PLA compares RTPL with HPL, using Spearman correlation and a Kolmogorov–Smirnov distribution test over 250 observations. The HPL used in PLA and backtesting must match. Time effects must be treated consistently between HPL and RTPL. [MAR32.4, .20–.35](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/32/inforce/2023-01-01/published/2020-03-27) | Separate daily economic P&L explanation from regulatory PLA. Retain original exception history, permitted adjustments and approval evidence. Investigate missing risk factors, pricing-engine differences and mismatched snapshots. |
| Expected shortfall | The Basel IMA specifies daily ES, a one-tailed 97.5% confidence level, a 10-day base horizon, liquidity horizons of 10/20/40/60/120 days and calibration to stress. These are regulatory parameters, not universal settings for every management metric. [MAR33.2–.7](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/33/inforce/2023-01-01/published/2020-06-05) | Record the confidence level, horizon, portfolio scope, calibration period and currency before comparing figures. A one-day VaR and liquidity-adjusted regulatory ES cannot be compared as if identical measures. |
| Nonlinear, basis and proxy risk | Risk models must capture relevant nonlinearities, correlation and basis risk. Proxy use requires justification. [MAR31.4–.5 and .24](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/31/inforce/2023-01-01/published/2020-06-05) | Supplement net sensitivities with gross exposures, tenor buckets, option stresses, hedge-basis stresses and concentration analysis. Review proxy quality when market conditions change. |
| Counterparty credit risk | BCBS's final December 2024 guidelines call for continuing due diligence, effective mitigation, complementary exposure metrics and governance. Exposures should incorporate enforceability of netting/collateral and aggregate across products, desks and books. [Final guidelines, especially paragraphs 41–42](https://www.bis.org/bcbs/publ/d588.pdf) | Review counterparty groups and legal netting sets separately. Combine current exposure, future exposure, collateral and stress information; a single headline number is inadequate. |
| Risk data | Basel risk-data principles address accuracy, completeness, timeliness and adaptability. They require source reconciliations and controls over manual workarounds. [SRP36.18 and .27](https://www.bis.org/committees/bcbs/basel-framework/standard/srp/36/inforce/2019-12-15/published/2019-12-15) | Reconcile trade populations and book hierarchies before statistical analysis. Track data lineage, exclusions, stale inputs and end-user spreadsheet changes. |

Working distinctions for analysis:

- VaR is a modelled loss quantile over a specified horizon. ES describes average
  losses in the tail beyond that quantile for a continuous loss distribution.
  Neither is a guaranteed maximum loss. Basel's terminology supplies the formal
  definitions. [MAR10](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/10/inforce/2023-01-01/published/2020-03-27)
- A sensitivity is a local response to a risk-factor movement. First-order
  measures can miss nonlinear losses under large shocks; model requirements
  therefore matter alongside the reported Greek. [MAR31](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/31/inforce/2023-01-01/published/2020-06-05)
- Initial margin addresses potential future exposure; variation margin addresses
  current exposure. Margin calculations depend on the applicable legally
  enforceable netting agreement. [MGN20.8 and .14](https://www.bis.org/committees/bcbs/basel-framework/standard/mgn/20/inforce/2019-12-15/published/2019-12-15)

## Post-trade obligations and control design

### Confirmations and reconciliation

EU EMIR risk-mitigation techniques for non-centrally cleared OTC derivatives
include timely confirmation, reconciliation, compression, dispute resolution and
collateral exchange. Requirements vary with counterparty category and portfolio
size. The ESMA overview is a navigation aid; use the applicable legislation for
the legal test. [ESMA overview](https://www.esma.europa.eu/post-trading/clearing-obligation-and-risk-mitigation-techniques-under-emir)

For US swap dealers and major swap participants, CFTC confirmation requirements
distinguish acknowledgements from executed confirmations, counterparty types,
and transactions accepted by relevant execution/clearing venues. Transmission
and receipt timestamps must be retained. The regulation also defines execution
day, so local holidays and time zones matter. [17 CFR 23.501](https://www.ecfr.gov/current/title-17/chapter-I/part-23/subpart-I/section-23.501)

CFTC portfolio-reconciliation frequency depends on counterparty type and swap
count. Section 23.502 contains material-term and valuation-dispute procedures,
regulatory notification criteria and recordkeeping requirements; it excludes
swaps cleared by a derivatives clearing organization. [17 CFR 23.502](https://www.ecfr.gov/current/title-17/chapter-I/part-23/subpart-I/section-23.502)

Proposed audit procedures:

1. Rebuild the eligible population from executed trades, then reconcile to the
   confirmation platform, clearing acceptances and operations exceptions.
2. Match economics: legal entity, counterparty, instrument, direction, notional,
   price/rate, currency, trade/value dates and settlement instructions.
3. Measure overdue items by number, notional, market value, age and risk;
   distinguish missing records from disputed economics and technical failures.
4. Sample amendments, cancellations, novations and backdated trades. Verify that
   a replacement record does not erase the original exception's age.
5. Test resolution through corrected source records and external agreement.
   Closing a ticket alone does not demonstrate economic agreement.

### Margin and collateral

Basel's non-cleared margin framework connects margin to current/future exposure,
calls for effective netting agreements and legal opinions, timely dispute
resolution, and collateral that remains liquid and valuable after haircuts in
stress. [MGN20.8, .25–.29](https://www.bis.org/committees/bcbs/basel-framework/standard/mgn/20/inforce/2019-12-15/published/2019-12-15)

Proposed audit procedures: reconcile valuation and positions to each margin
call; independently apply the governing agreement's thresholds, minimum transfer
amount, eligible collateral, FX conversion and haircuts; distinguish calculated,
agreed, instructed and actually settled collateral. Trace disputes to valuation
or population causes. Test concentration, collateral-value deterioration and
funding needs under joint market/counterparty stress. Regulatory minimum margin
and house risk appetite should be assessed separately.

### Settlement and failed trades

The US SEC shortened the standard settlement cycle for most broker-dealer
transactions to T+1, with compliance from 28 May 2024. Rule 15c6-2 addresses
institutional trade allocations, confirmations and affirmations by trade-date
end through specified agreements or policies and procedures. These provisions
are scoped rules, not a universal settlement cycle for all products.
[SEC final rule](https://www.sec.gov/files/rules/final/2023/34-96930.pdf)

Basel FX guidance promotes payment-versus-payment where practicable and otherwise
requires attention to the amount and duration of remaining principal risk. It
distinguishes principal, replacement-cost, liquidity, operational and legal
risks. [BCBS FX settlement guidance](https://www.bis.org/publications/201302-guidelines-supervisory-guidance-managing-risks-associated-settlement-foreign-exchange-transactions)

Basel treats delivery-versus-payment and non-DvP failures differently, including
different exposure and ageing mechanics. [CRE70](https://www.bis.org/committees/bcbs/basel-framework/standard/cre/70/inforce/2019-12-15/published/2019-12-15)

Proposed audit procedures: trace each cash/security leg from instruction to final
settlement evidence; reconcile custodian, clearing broker, CCP and cash-account
statements; review independent approval of standing-instruction changes; check
cash/stock availability and cutoffs. Analyse failed trades by economic exposure,
duration, recurrence, counterparty and root cause. A matched instruction is not
proof of settlement. A five-day capital threshold is not permission to ignore
earlier fails. Keep settlement principal risk distinct from mark-to-market risk.

## Implementation timing: examples verified in this research

- **UK:** PRA PS1/26 states that Basel 3.1 rules take effect on 1 January 2027,
  while the market-risk internal models approach takes effect on 1 January 2028.
  [PRA final policy, paragraphs 1.23–1.24](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/january/implementation-of-the-basel-3-1-final-rules-policy-statement)
- **EU:** Regulation 2025/1496 defers the new market-risk own-funds requirements
  until 1 January 2027. [Official Journal text](https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX%3A32025R1496)
- **EU subsequent development:** the Commission announced temporary amendments
  on 4 June 2026 for intended application from 2027; that announcement still
  described parliamentary/Council scrutiny as pending. This research did not
  establish the later legal status of every amendment. Do not use the announcement
  alone as evidence that all its provisions are in force.
  [Commission announcement](https://finance.ec.europa.eu/news/commission-adopts-temporary-adjustments-basel-iii-market-risk-rules-safeguard-eu-banks-2026-06-04_en)

## Common audit errors to prevent

The following are analytical cautions derived from the distinctions above:

- Comparing financial P&L, APL, HPL and RTPL without reconciling population,
  valuation adjustments, cash flows, currencies and snapshots.
- Treating low net delta as low total risk while ignoring gross positions,
  nonlinearities, concentrated tenor exposures or an unstable hedge basis.
- Using a falling VaR as evidence of de-risking without checking changed data,
  missing trades, model changes and the stress-loss profile.
- Netting across entities or agreements without enforceability evidence.
- Treating a margin call or accounting receivable as collateral already received.
- Reporting only exception counts; small counts can conceal material exposure,
  while cancellations and rebooking can hide persistent exceptions.
- Treating a service provider's processed/accepted flag as proof that the trade,
  collateral or regulatory report is complete and economically correct.
- Applying a jurisdiction's rule to every global desk or mistaking Basel's
  publication/effective date for the local legal implementation date.

## Evidence limitations

Primary sources were checked through official BIS/BCBS, ESMA, SEC, eCFR,
EUR-Lex, European Commission and Bank of England publications. The eCFR pages
displayed currency through 14–15 October 2026, rather than a certified legal
opinion as of 17 October. Several BIS legacy PDF URLs now redirect to publication
pages; detailed text retrieval from some replacement PDFs timed out. Final
publication pages, indexed final-document excerpts and current Basel Framework
chapters were used where available. The 2026 draft consolidated-guidelines
pages were not treated as newly binding final rules. No confidential trading
records, client information, credentials or production systems were accessed.
