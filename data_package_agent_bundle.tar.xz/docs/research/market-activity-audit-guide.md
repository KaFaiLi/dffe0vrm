# Trading desk P&L risk and post trade audit guide

Research date: 17 October 2026. Audience: investment-bank market activities auditors.

A trading desk audit should establish whether profits are supported by genuine transactions, defensible valuations and the risks actually taken, and whether those transactions are confirmed, collateralised, settled and reported correctly. P&L, risk and operations evidence must be connected at trade, book, legal-entity and time level.

This guide covers rates, FX, credit, equities, commodities, structured products and financing activities. It combines global supervisory principles with selected US, UK, EU, Hong Kong, Singapore and mainland China references. Local obligations depend on entity, product, counterparty, location and effective date; this is not an exhaustive legal inventory. The audit procedures and numerical examples below are an analytical framework, not prescribed universal regulatory thresholds. No actual desk dataset has been assessed.

Use the [current data audit checklist](market-activity-audit-checklist.md) to apply this framework to the available synthetic P&L, SGMR/Colibris and post-trade case extracts. It identifies executable screens, missing mappings and the additional evidence needed for substantive audit conclusions.

## Business workflow and ownership

A useful audit unit is the desk together with its booking entities, books, traders, sales channels, products, hedges, funding arrangements and supporting systems. Begin with a walkthrough of a normal trade and an exception from execution through cash settlement and financial reporting.

| Stage | Typical business activity | Evidence and audit question |
| --- | --- | --- |
| Mandate and onboarding | Approve products, counterparties, documentation, trading authority and limits | Is the actual strategy permitted, with valuation, risk and operational capability established before trading? |
| Quote and execute | Price a client transaction or hedge; execute on a venue, electronically or by voice | Does independent execution evidence support the economics, timestamp, counterparty and authorised trader? |
| Capture and enrich | Book trade economics, allocations, legal entity, settlement instructions and identifiers | Is capture complete and timely across front office, risk and operations? Are amendments traceable? |
| Confirm and clear | Match economics with the counterparty; submit eligible trades for clearing | Was the transaction agreed and, where relevant, accepted by the clearing house? What happened to rejects? |
| Manage positions and risk | Aggregate positions, calculate exposures, hedge and monitor limits | Are all exposures captured, including intraday peaks and risks obscured by netting? |
| Value and explain P&L | Mark positions, calculate income, explain changes and assess adjustments | Can an independent reviewer reproduce the material drivers and challenge pricing inputs? |
| Margin and collateral | Calculate calls, resolve disputes and deliver eligible collateral | Does the collateral actually received cover the contractual call after haircuts and settlement? |
| Settle and service | Exchange cash or securities; process coupons, resets, exercises and maturities | Did the correct asset and amount move to the correct beneficiary on the correct date? |
| Reconcile and report | Reconcile systems and external records; report to finance, management and regulators | Are breaks resolved with evidence, and are corrections reflected in every affected record? |

These stages overlap: margin, risk monitoring, reconciliations and lifecycle processing recur while a position remains open. A trade-date control can operate before contractual settlement; “post trade” does not mean “after settlement.”

Trading management owns business activity and risk-taking decisions. Product control/market activities control typically validates P&L and valuation; operations handles confirmation, settlement and reconciliations; market and credit risk challenge exposures and limits; finance owns financial reporting; compliance oversees applicable conduct requirements. The exact allocation and line-of-defence classification must be established from the bank's governance documents. Internal audit provides independent assurance and should not become the daily control approver. [IIA governance roles](https://www.theiia.org/en/resources/statements-of-position).

The ECB's assessment separates the level of market risk from the quality of its controls and includes valuation and CVA risk. This is a useful structure for an audit: a profitable, low-volatility desk can still have weak controls. [ECB market risk SREP methodology](https://www.bankingsupervision.europa.eu/activities/srep/2024/html/ssm.srep202412_marketrisksrepmethodology.en.html).

## Product knowledge needed for analysis

For each product, an auditor should be able to describe its cash flows, price drivers, valuation method, hedge, funding needs, settlement mechanism and major failure modes. The table is a proposed learning and scoping checklist, not a statement that every bank trades every product.

| Business | Economics and knowledge to acquire | Exposures and audit focus |
| --- | --- | --- |
| Rates | Bonds, swaps, futures and swaptions; discount and forward curves; day counts, compounding, clean versus dirty prices, accrued interest | DV01/PV01 by currency and tenor, curve and basis risk, convexity, option volatility, fixing and coupon events |
| FX | Spot, forwards, swaps, NDFs and options; quotation direction, forward points, currency calendars, fixing sources | Currency delta, rates and cross-currency basis, volatility/skew, settlement principal exposure and liquidity by currency |
| Credit | Corporate bonds, CDS and indices; spread versus risk-free curve, default/recovery, accrued premiums and credit events | CS01 by issuer/sector/tenor, jump-to-default, cash/CDS basis, concentration, stale marks and liquidity |
| Equities | Cash shares, futures, options, swaps and convertibles; dividends, borrow costs and corporate actions | Delta, gamma, vega, correlation, dividend and borrow exposure; short availability, exercise and delivery |
| Commodities | Futures, swaps and options; delivery location, grade, units, seasonality, storage and transportation where relevant | Curve/location/quality basis, optionality, position concentrations, physical delivery obligations and price discontinuities |
| Structured and exotic products | Embedded options, barriers, callable features and path dependence; model calibration and observation schedules | Nonlinear and discontinuous exposures, correlation, model uncertainty, day-one valuation and hedge slippage |
| Repo and securities financing | Collateral, haircuts, repo rates, manufactured payments, recalls, substitution and maturity mismatch | Counterparty and collateral concentration, margin, wrong-way risk, funding rollover and settlement failures |
| Prime brokerage | Client financing and derivatives, margin methodology, liquidation rights and cross-product relationships | Client leverage, concentrated collateral, exposure aggregation, wrong-way risk and close-out liquidity |

Basis risk is the risk that an exposure and its hedge do not move together. It deserves explicit attention even when net directional exposure is small. Notional is a useful scale measure but does not by itself measure the amount at risk. Product definitions and sensitivity scaling should come from the bank's approved product and model documentation, supported by exchange specifications where applicable.

## Reviewing trading P&L

### Establish comparable numbers

Record the legal entity, desk/book hierarchy, valuation date and cutoff, reporting currency, FX conversion basis, units, source system, report version and P&L definition before making comparisons. Distinguish daily movements from WTD/MTD/QTD/YTD totals. Do not sum cumulative snapshots. Reconstruct a cumulative movement only with comparable opening/closing balances and an understood reset calendar.

Keep separate the trader estimate, product-control validated P&L, accounting P&L, economic attribution and regulatory P&L series. The labels “official,” “clean,” “actual” and “validated” are not substitutes for a data dictionary. Document fees, intraday trades, funding, valuation adjustments, reserves and FX translation included in each series.

### Build a mutually exclusive P&L bridge

An illustrative daily bridge is:

```text
Reported desk P&L
  = market movements on opening positions
  + carry, accrual and time effects
  + new business and intraday trading contribution
  + fees and commissions
  - funding, borrow and transaction costs
  + valuation adjustment and reserve movements
  + booking corrections and other identified effects
  + unexplained residual
```

Adapt categories to the desk's accounting and attribution policy. Some systems already include funding or accrual in another bucket. Realised/unrealised classification is a separate view, not an additional pair of terms to add to the bridge. A settlement payment or collateral transfer is not automatically income. Do not add an adjustment file to reported P&L until its inclusion status and accounting treatment are established.

Reconcile front-office P&L to validated P&L, then to the relevant accounting/subledger and general-ledger balances, retaining differences by cause and owner. An attribution total that agrees with reported P&L is useful but does not prove either source is correct: both may contain the same missing trade or pricing error.

For derivatives desks, obtain the policy for valuation adjustments collectively called XVA. Common labels include CVA for counterparty credit, DVA for own credit and FVA for funding. Establish which adjustments are included in the trade mark, allocated by a central desk, booked separately or excluded from a particular management view. The valuation adjustment, its hedge P&L and any regulatory capital charge are different amounts. Do not assume every adjustment has the same accounting treatment under IFRS and US GAAP.

### Reperform the material drivers

Use opening sensitivities and aligned market moves as an initial reasonableness test. For a smooth, locally approximated valuation:

```text
Change in value approximately equals
  sum(first-order sensitivity × risk-factor move)
  + half the quadratic sensitivity contribution, including relevant cross terms
  + time effect
```

For options, this motivates delta, gamma, vega and theta attribution. Define whether sensitivities are per unit, percentage move, volatility point or basis point; include quantities, contract multipliers and currency conversion exactly once. For large moves, barriers, defaults or material cross-factor effects, use controlled full revaluation rather than relying on a local approximation. Options exposures are sensitive to the quality and completeness of the Greeks used. [CME on options risk sensitivities](https://www.cmegroup.com/articles/2025/precision-risk-management-starts-with-quality-greeks.html).

One basis point is 0.01 percentage point. DV01 expresses the value impact of a one-basis-point yield change; systems differ in whether they store a signed response or a positive magnitude. [CME basis-point value explanation](https://www.cmegroup.com/education/courses/introduction-to-sofr/understanding-the-importance-of-basis-point-value).

**Synthetic rates example.** Assume signed opening PV01 of minus EUR 25,000 for a +1 bp parallel shift and an actual parallel yield move of -8 bp. The first-order market contribution is +EUR 200,000.

| Component | EUR |
| --- | ---: |
| Rates movement | 200,000 |
| Carry and accrual | 30,000 |
| New business | 60,000 |
| Funding | -15,000 |
| Valuation adjustment movement | -25,000 |
| Explained total | 250,000 |
| Reported P&L | 310,000 |
| Unexplained residual | 60,000 |

The residual is an investigation amount, not an established misstatement. Check curve shape changes, convexity, intraday inventory, omitted cash flows, market-data cutoffs, booking corrections and model differences. Require evidence for the explanation and trace the resolution into the affected reports.

### Challenge valuation and adjustments

Under IFRS 13, fair value reflects an orderly exit transaction using market-participant assumptions at the measurement date. A trader's expected profit or intended holding period is not enough to establish a mark. [IFRS 13 overview](https://www.ifrs.org/issued-standards/list-of-standards/ifrs-13-fair-value-measurement/).

Daily marking and independent price verification (IPV) are distinct. Basel CAP50 calls for independent verification at least monthly, or more frequently depending on the activity, and consideration of valuation adjustments. Its prudent valuation adjustments may extend beyond financial-reporting adjustments; establish which changes affect accounting P&L and which affect capital. [Basel prudent valuation guidance](https://www.bis.org/committees/bcbs/basel-framework/standard/cap/50/inforce/2019-12-15/published/2019-12-15).

Proposed tests:

1. Select material and difficult-to-value positions; reproduce marks using an appropriately independent source or approved model. Assess market depth, quote age, bid/offer and input observability.
2. Compare IPV coverage with the full population, including off-system trades and inputs that are interpolated, extrapolated or overridden. Investigate exclusions.
3. Trace reserve and adjustment opening balances, increases, releases, transfers and closing balances. Examine methodology, supporting evidence, preparer/approver independence and accounting dates.
4. Challenge day-one profit recognition against applicable accounting policy and input observability. Examine model-change benefits, stale prices and quarter-end reserve releases.
5. Link recurrent P&L residuals to valuation/model review, rather than repeatedly accepting the same generic explanation.

## Reviewing risk metrics

| Metric | Meaning | Audit procedure |
| --- | --- | --- |
| Delta / DV01 / CS01 | Local response to underlying prices, interest rates or credit spreads | Verify sign, scale, currency, factor mapping and tenor buckets; independently bump selected positions |
| Gamma / convexity | Curvature of value as a factor moves | Identify risks that grow as markets move; test nonlinear exposures and hedge rebalancing assumptions |
| Vega and volatility surface exposure | Response to changes in implied volatility | Examine maturity and strike buckets, skew and missing surface points; verify volatility-point scaling |
| VaR | A loss quantile for a specified horizon, confidence level and model | Confirm parameters and population; inspect backtesting, exceptions, model changes and data quality |
| Expected shortfall | Average loss across the defined tail of the loss distribution | Check calibration, tail observations, liquidity horizons and concentration; distinguish internal measures from capital calculations |
| Stress loss | Loss under specified historical or hypothetical scenarios | Test scenario relevance, basis/correlation breakdown, nonlinear revaluation and credible management actions |
| Gross and net concentrations | Exposure before/after recognised offsets | Look through issuers, sectors, currencies, tenors and counterparties; challenge apparent diversification |
| Counterparty exposure / PFE | Current exposure and possible future exposure at specified horizons | Verify netting sets, legal enforceability, collateral, simulation assumptions and wrong-way risk |
| Liquidity and margin measures | Ability to fund calls and exit positions | Examine stressed margin, liquidation time, market depth and funding by currency and legal entity |
| Limit utilisation and stop-loss | Use of approved risk capacity and loss triggers | Apply the limit effective at the exposure timestamp; assess intraday breaches, approval scope and expiry |

Potential future exposure (PFE) is a forward exposure measure whose horizon and confidence level must be specified. Wrong-way risk arises when exposure becomes larger as the counterparty's credit quality worsens. Aggregate related exposures while preserving legally valid netting boundaries; review due diligence, collateral and complementary stress measures. [BCBS counterparty credit risk guidelines](https://www.bis.org/bcbs/publ/d588.pdf).

VaR is not a maximum possible loss. For example, a modelled one-day 99% VaR of EUR 2 million describes a quantile, not a guarantee that tomorrow's loss will remain below EUR 2 million. An exception is not automatically model failure or an unauthorised limit breach; exception patterns and underlying causes matter. Stress testing examines outcomes outside ordinary model conditions. [OCC derivatives and trading guidance](https://www.occ.treas.gov/news-issuances/bulletins/1999/bulletin-1999-2.html).

Risk aggregation requires compatible units and scope. Do not add portfolio VaRs as though they were an aggregated VaR, or add DV01, CS01 and vega into one exposure number. Record whether limits are gross, net, directional, two-sided or scenario-based. A simple utilisation ratio is valid only where exposure and limit share a definition. A zero or absent limit needs a policy-specific treatment, not automatic division or a green status.

### Separate daily explanation from regulatory model tests

Under the Basel internal models framework, actual P&L (APL), hypothetical P&L (HPL) and risk-theoretical P&L (RTPL) are distinct defined series. HPL uses a static prior-day portfolio, subject to the framework's detailed treatment of time, cash flows and adjustments. RTPL uses the risk model's valuation representation and factors. Regulatory P&L attribution (PLA) compares RTPL with HPL; VaR backtesting uses the relevant APL and HPL series. Do not substitute the management P&L bridge or ordinary accounting P&L without the required reconciliation. [Basel MAR32](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/32/inforce/2023-01-01/published/2020-03-27).

Basel's revised internal models capital approach uses 97.5% expected shortfall with prescribed liquidity-horizon treatment. That does not mean every internal dashboard must use that parameter or that every jurisdiction has implemented the framework on the same date. [Basel MAR33](https://www.bis.org/committees/bcbs/basel-framework/standard/mar/33/inforce/2023-01-01/published/2020-06-05).

### Investigate P&L and risk together

- High profit with low end-of-day risk: reconstruct intraday positions, turnover, new business, reserve releases and off-system exposures.
- Stable net sensitivity with increasing gross exposure: test offset validity, basis risk, hedge maturity mismatch and unwind liquidity.
- Falling VaR during increasing stress losses: examine model calibration, missing factors and portfolio composition rather than inferring safety from VaR alone.
- A large limit increase just before a breach disappears: test approval timing, rationale, expiry and monitoring against the previous limit.
- Smooth profits with rising collateral disputes or valuation uncertainty: challenge both mark quality and the economic source of earnings.

These are investigative hypotheses. None independently establishes misconduct.

## Testing post trade controls

The matrix below translates supervisory themes into proposed audit work. Frequency and deadlines must be taken from the applicable rules, contracts and the bank's approved procedures.

| Control area | Failure to investigate | Evidence and reperformance |
| --- | --- | --- |
| Capture completeness | Missing, duplicate, late or incorrectly allocated trades | Compare independent venue/broker feeds with booking and risk populations in both directions; retain cancelled and rejected events |
| Confirmation | Unagreed economics or fictitious hedges | Match counterparty evidence to trade economics and versions; inspect unmatched aging, disputes and subsequent amendments |
| Clearing | Rejected trade treated as cleared | Trace submission, acceptance, novation and allocation; test exposure treatment while acceptance is pending |
| Cancel and amend | Backdating, concealment or artificial profit | Reconstruct event history, user access, reason, approval and changes to P&L/risk; test repeated cancel/rebook patterns |
| Internal and intercompany trades | One-sided bookings or unsupported offsets | Match both legs and identifiers; distinguish consolidated elimination from each entity's legal exposure |
| Collateral and margin | Under-collateralisation, disputes or late delivery | Recalculate calls from the agreement, marks and collateral balances; test haircuts, eligibility, thresholds, settlement and dispute escalation |
| Settlement | Wrong amount, wrong beneficiary, principal loss or fails | Trace standing settlement instruction changes, dual approval, payment messages and custodian/nostro evidence; quantify fails by value and age |
| Lifecycle events | Missed fixing, reset, coupon, exercise, corporate action or maturity | Compare contractual schedules and external announcements with system events, cash flows and resulting positions |
| Reconciliations | Persistent or falsely cleared breaks | Independently reproduce selected breaks; inspect aging, owner, monetary exposure, investigation and evidence of closure |
| Regulatory reporting | Omitted, rejected, late or economically incorrect reports | Reconcile reportable trades to submissions and repository acknowledgements; test corrections and lifecycle events |
| Post-trade surveillance | Trading patterns outside mandate or potentially abusive behaviour | Test surveillance population coverage, relevant alerts, independent investigation and escalation; corroborate with execution/order records where in scope |
| Access and segregation | Trader can change prices, approve own controls or release payments | Examine entitlements, privileged activity, service accounts and change logs against independent approvals |
| Exception governance | Alerts closed without resolving exposure | Trace detection through escalation, decision and remediation; test reopened and recurring items across systems |

For FX, payment-versus-payment links the two currency payments and reduces principal settlement risk. Review transactions outside that mechanism and the remaining liquidity, replacement-cost, operational and legal exposures. A zero market-risk delta does not eliminate the amount at risk during settlement. [Basel FX settlement guidance](https://www.bis.org/publications/201302-guidelines-supervisory-guidance-managing-risks-associated-settlement-foreign-exchange-transactions).

For securities, identify the applicable delivery-versus-payment arrangements and settlement cycle for each market/product. US T+1 applies to most covered broker-dealer securities transactions; it is not a universal deadline for all securities or OTC derivatives. [SEC T+1 implementation statement](https://www.sec.gov/newsroom/press-releases/2024-62).

Distinguish collateral calls from cash actually settled. Variation margin, initial margin and settlement payments have different purposes and accounting treatments; establish the contractual and accounting treatment for each arrangement before analysing P&L or exposure.

## Data required and analytical design

Obtain a complete population for the audit period, opening positions/balances, relevant lookback history and sufficient subsequent events to test reversals and closure. Retain source versions and extraction timestamps. Avoid requesting only the exceptions management has already identified.

| Dataset | Minimum useful fields | Key linkage |
| --- | --- | --- |
| Organisation and mandates | Entity, desk/book hierarchy with effective dates, trader authorities, products and strategies | Book and person at the event date |
| Trade and lifecycle history | Stable trade ID, parent/version, economics, execution/booking timestamps, status, event type, user and source | Trade plus event/version; both internal legs |
| Positions and market data | Quantity, notional, mark, price source, curves/surfaces, timestamp, valuation model/version | Trade or position, valuation date and market-data snapshot |
| P&L and attribution | Daily/cumulative flag, component, currency, units, report version and validation state | Entity/book/date/currency/basis/version |
| Adjustments and reserves | Signed amount, category, effective interval, creation/posting dates, rationale, inclusion status, approval and reversal | Adjustment ID to trade/book, P&L and ledger |
| Risk and limits | Metric/factor/bucket, unit/sign, exposure timestamp, model version, limit ID/value/effective dates | Same scope, factor, unit and timestamp |
| Approvals and commentary | Role, user, state history, timestamp, covered report/version, narrative and supporting evidence | Exact control obligation and report version |
| Operations and collateral | Confirmation/clearing statuses, settlement due/actual, break IDs, calls, balances, disputes and netting sets | Trade, cash movement, counterparty and agreement |
| Finance and external records | Subledger/GL, journals, cash/custody/clearing records, report submissions/acks | Independently reconciled totals and stable references |

BCBS 239 provides the foundation for assessing data governance, aggregation and reliable risk reporting. Apply it by testing the lineage and completeness of the data used to support each conclusion. [BCBS 239](https://www.bis.org/publications/201301-guidelines-principles-effective-risk-data-aggregation-and-risk-reporting).

Before calculating indicators, reconcile row counts and control totals, test uniqueness at the intended grain, inspect missing dates and unmatched joins, and verify that joining event histories has not multiplied monetary amounts. Preserve missing values as unknown. A missing exposure, missing approval or missing limit is not zero risk or successful control execution.

Recommended initial analytics:

1. **P&L bridge residuals:** absolute and signed residuals by book/day, persistent bias, concentrations and subsequent reversals. Where useful, normalise by an approved materiality scale; percentages of near-zero net P&L are unstable.
2. **Adjustment behaviour:** gross positive and negative amounts, recurring entries, quarter-end clustering, releases, aged balances, preparer/approver concentration and next-period reversal. A gross adjustment activity measure is not necessarily its incremental P&L effect.
3. **Risk-limit history:** utilisation, breach size and duration, repeated temporary excesses, limit changes and intraday versus closing exposures.
4. **Control timeliness:** completion before the documented deadline, correct role and report version, later reopens and contradictory statuses. A final approval does not establish approval by the original deadline.
5. **Trade behaviour:** late capture, economic amendments, unusual settlement deferrals, off-market prices and missing internal matches.
6. **Operations exposure:** confirmation backlogs, settlement fails, collateral disputes and reconciliation breaks, by count, gross amount, age and counterparty. Do not net unrelated exceptions away.
7. **Combined signals:** unexplained profit plus an old break; a reserve release plus delayed validation; low closing risk plus high intraday margin; a cancellation plus disappearance of an exception.

Statistical outliers are screening tools. Choose comparable populations and allow for changing volatility, seasonality and business mix. A fixed z-score threshold is not an audit materiality standard or evidence of error. Always examine material values and risk-relevant events even when a statistical model does not flag them.

For commentary, match narrative scope, date, currency and version before comparing it with numbers. A parent-desk quarterly comment may explain a business trend but does not certify each child book/day or establish trade-level causality. Separate an independently supported explanation from management's assertion.

## Audit execution and reporting

Use a sequence that tests evidence reliability before drawing economic conclusions:

1. Agree the desk perimeter, time period, materiality, applicable obligations and audit objectives. Review prior findings, incidents, new products, system/model changes and business growth.
2. Walk through representative normal and exceptional transactions. Map systems, ownership, handoffs and reconciliations, including outsourced/shared-service activities.
3. Establish population completeness and data lineage. Resolve or quantify limitations before treating analytics as comprehensive.
4. Assess control design: population covered, frequency, independence, trigger, evidence, escalation and remediation requirements.
5. Test operation through reperformance and records across the period. Combine material/high-risk selections with a justified sample of ordinary activity; targeted exceptions alone do not support a population-wide error rate.
6. Reconstruct P&L and risk on selected dates, including volatile days and period ends. Follow linked operational exceptions to independent evidence.
7. Challenge explanations with controllers, risk and operations. Record competing explanations and the evidence that resolves them.
8. Quantify impact and root cause. Separate confirmed misstatement/loss from possible exposure and from a control-design deficiency.
9. Report severity using the bank's methodology, with the affected population, criteria, evidence, cause, consequence, accountable owner, target date and validation plan.
10. Retest remediation using subsequent transactions and evidence that the corrected process operates effectively.

Suggested engagement outputs are a business/process map, risk-and-control matrix, reconciled population inventory, analytical exception register, P&L/risk case studies and an issues/remediation log. Each exception should carry a source reference, economic amount where measurable, status, owner and evidence of disposition.

For a proposed daily management dashboard, show P&L and residuals, material adjustment movements, risk/limit breaches, missing validations, aged confirmation/reconciliation items, settlement fails and margin disputes. Show the as-of time, coverage and data-quality exceptions alongside the indicators. The auditor tests this management control without taking over its operation.

## Lessons from enforcement and supervision

The FSA's 2012 UBS notice describes inadequate challenge of large P&L suspensions, unexplained increases in profitability, late trade booking and reconciliation exceptions that were cleared without sufficient investigation. It also identifies failures in cancel/amend reporting and supervision. The practical lesson is to test what happened after an alert, and to combine signals across control functions. [FSA final notice to UBS](https://www.fca.org.uk/publication/final-notices/ubs-ag.pdf).

The ECB's 2025 supervisory report identifies weaknesses in IPV, valuation adjustments, day-one profit deferral, limit frameworks, counterparty exposure models and collateral management. These are relevant scoping themes, not evidence that a particular desk has those weaknesses. [ECB supervisory annual report 2025](https://www.bankingsupervision.europa.eu/press/other-publications/annual-report/html/ssm.ar2025~6ee989dc7e.en.html).

## Jurisdiction and rule applicability

Build an obligation register with authority, provision/version, entity/product scope, effective date, control owner and required evidence. Distinguish law/rules, supervisory guidance, voluntary codes, contractual obligations and internal policy.

| Framework or jurisdiction | Application to the audit |
| --- | --- |
| Global Basel principles | Use valuation, risk-data, market-risk and settlement guidance as a control foundation; check domestic adoption before calling a practice a legal requirement |
| United States | Identify the banking/securities/derivatives regulator and entity type; map applicable capital, confirmation, reconciliation, margin, reporting and settlement rules. SEC T+1 is a scoped securities rule |
| European Union | Map CRR/CRD, EMIR, MiFID/MiFIR and CSDR as applicable; separate prudential rules from transaction/reporting and settlement obligations |
| United Kingdom | Map PRA prudential requirements, FCA conduct rules and applicable UK derivatives/reporting rules separately from EU rules |
| Hong Kong | Use the relevant HKMA/SFC perimeter. HKMA's current TA-2 repository entry identifies FX risk management guidance for authorised institutions. [HKMA TA-2](https://brdr.hkma.gov.hk/eng/doc-ldg/docId/20220118-2-EN) |
| Singapore | MAS market-risk guidance covers strategy, policies, measurement, monitoring and control. Identify the separate notices/regulations applying to the legal entity and product. [MAS guidance](https://www.mas.gov.sg/regulation/guidelines/guidelines-on-risk-management-practices--market-risk) |
| Mainland China | Distinguish CSRC-regulated activities from banking/interbank and FX perimeters. The CSRC's trial derivatives measures announced in May 2026 take effect on 16 November 2026, after this research date; do not treat them as already effective. [CSRC announcement](https://www.csrc.gov.cn/csrc/c100028/c7632835/content.shtml) |

The companion [source notes](market-activity-audit-source-notes.md) contain additional rule references, including selected EU/UK implementation dates and US derivatives controls. A global desk should maintain a separate applicability record for each booking entity and transaction population.

## Practical learning sequence

| Step | Knowledge to build | Demonstration of competence |
| --- | --- | --- |
| 1 | Trade lifecycle, desk mandate and ownership | Trace a real or synthetic trade from execution through valuation, risk, settlement and ledger |
| 2 | Instrument economics and market conventions | Explain cash flows, price drivers, sensitivity sign/units and the hedge's residual risks |
| 3 | P&L, accounting and valuation | Reconcile a daily bridge, explain cash versus P&L, and challenge a mark or adjustment |
| 4 | Market and counterparty risk | Interpret sensitivities, VaR/ES, stress, concentration, limits, netting and collateral |
| 5 | Post-trade controls | Reperform a confirmation, margin call, settlement reconciliation and exception escalation |
| 6 | Audit evidence and data analysis | Produce a reproducible exception investigation with source lineage and a justified conclusion |

Begin with one linear trade, one option and one financing trade. Extend the same evidence chain to complex portfolios. The ability to explain how the numbers were generated, reproduce the material calculations and corroborate management's explanation is the core analytical skill.
