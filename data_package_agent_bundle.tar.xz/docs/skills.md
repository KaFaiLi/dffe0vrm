# Skill folders

Set `Settings.skills_dir` to a skills collection or a single skill folder.
Relative paths resolve against `Settings.app_root`. Each skill requires
`SKILL.md`; all other files and folders are optional:

```text
skills/
└── my-skill/
    ├── SKILL.md
    ├── references/
    │   ├── api-guide.md
    │   ├── examples.md
    │   └── troubleshooting.md
    ├── scripts/
    │   ├── generate.py
    │   └── validate.sh
    ├── templates/
    │   ├── component.tsx.template
    │   └── test.spec.ts.template
    └── assets/
        ├── logo.png
        └── config.json
```

`SKILL.md` can include YAML frontmatter with `name` and `description`. Without
frontmatter, the folder name and first nonempty body line supply those values.
For example:

```markdown
---
name: my-skill
description: Generate a component using the documented API and templates.
---
Read references/api-guide.md before using templates/component.tsx.template.
Use assets/config.json for the component settings.
```

Use the description to explain both the skill's purpose and when the agent
should select it. Only `name` and `description` are extracted from frontmatter;
additional metadata such as `author`, `version`, or `tags` is not retained or
presented to the model. The Markdown body supplies the full workflow.

## What the agent sees

The system prompt's `AVAILABLE SKILLS` section contains a compact catalog:

```text
You have access to the following skills (load one before using it):
- my-skill: Generate a component using the documented API and templates.

Call `load_skill(name=...)` to read a skill's full instructions, then follow them. Read supporting files on demand with `read_skill_file(name=..., path=...)`.
```

`list_skills()` returns the same name/description entries without the surrounding
guidance. The system catalog contains neither full instructions nor supporting
content. Tree nodes see only the skills selected for that node.

For the example above, `load_skill(name="my-skill")` returns the following text
(with the actual absolute folder path in place of this illustrative path):

```text
Read references/api-guide.md before using templates/component.tsx.template.
Use assets/config.json for the component settings.

Skill folder: C:\agent\skills\my-skill
Supporting files:
- assets/config.json
- assets/logo.png
- references/api-guide.md
- references/examples.md
- references/troubleshooting.md
- scripts/generate.py
- scripts/validate.sh
- templates/component.tsx.template
- templates/test.spec.ts.template

Read needed files with read_skill_file(name=..., path=...). Paths are relative to this skill folder. Scripts are not automatically executed.
```

Frontmatter is stripped from the loaded instructions. A Markdown-only skill
returns just its instructions. For a supporting Markdown file containing the
17-byte text `# Query examples` followed by a newline, the file tool returns:

```json
{
  "name": "my-skill",
  "relative_path": "references/examples.md",
  "path": "C:\\agent\\skills\\my-skill\\references\\examples.md",
  "mime_type": "text/markdown",
  "size_bytes": 17,
  "encoding": "utf-8",
  "content": "# Query examples\n"
}
```

After loading the skill's instructions and inventory, the agent can read
independent supporting files in parallel. It waits when one file determines
which other file or operation is needed.

## Discovery and file tools

Discovery loads only the main instructions and a sorted inventory of relative
file paths. Supporting content stays on disk until requested, including nested
files and files in other optional folders. A directory containing its own
`SKILL.md` is a separate skill; its files are excluded from its parent's inventory.
Rebuild the agent after adding or renaming files to refresh the inventory.

Agents receive three tools:

- `list_skills()` returns names and short descriptions.
- `load_skill(name="my-skill")` returns the main instructions, absolute skill
  folder and supporting-file inventory. Skills containing only `SKILL.md` retain
  their original instruction-only result. An unknown name returns an actionable
  tool message with `status="error"`, so the agent can choose an available skill
  and continue the same run. Direct tool invocation with an argument dictionary
  returns the error text; the underlying Python function still raises `ToolException`.
- `read_skill_file(name="my-skill", path="references/api-guide.md")` returns
  `name`, `relative_path`, absolute `path`, `mime_type`, `size_bytes`, `encoding`
  and `content`. Paths are relative to the selected skill, with either slash style.

The default `encoding="auto"` returns UTF-8 text where possible, or base64 for
non-UTF-8 content and content containing NUL bytes. Use `encoding="base64"` for
exact binary bytes, or `encoding="utf-8"` to require text. Binary assets such as
PNG files are available as base64 with their MIME type. Each read is limited to
1,048,576 bytes; larger files return an explicit error instead of truncated content.

File access is limited to inventoried files of the skills selected for that
agent. Absolute paths, traversal, Windows drive/alternate-stream paths and
symlink/junction targets outside the skill folder are rejected. A resource that
disappears or cannot be read produces an actionable tool error. Expected read
failures return a tool message with `status="error"`, allowing the agent to choose
another file or encoding and continue the same run. Direct `read_skill_file`
tool invocation with an argument dictionary returns the error text; Python
`Skill.read_file()` callers still receive exceptions. Single agents and tree
nodes use the same tools, respecting each node's selected skills.

## Application skills and analysis

The `market-activity-review` skill coordinates the three topic skills and provides
shared business workflow, a tool/data catalogue and 36 stable audit checks. Its
references are self-contained within the skill folder. The main agent challenges
cross-source evidence and returns one consolidated finding; topic agents supply
supporting observations. See [the notebook guide](market-activity-review.md) for
the explicit capability allowlists and validated JSON/Markdown report contract.
When deploying the demo, copy all four skill folders to the application folder;
they remain application files rather than bundled wheel resources.

Skills are read only from the selected application folder: `Settings.skills_dir`
defaults to `APP_ROOT/skills`. A missing or empty folder provides no skills.
There is no `_bundled_skills` directory, packaged fallback or implicit merge.
Explicit `AgentSpec.skills_dir` overrides and `AgentSpec.skill_names` selections
continue to work; an empty name list excludes all skills.

The checkout's default folder includes
[`post-trade-control`](../skills/post-trade-control/SKILL.md), an auditor workflow
for reviewing FOX control-case extracts and composing an evidence-based response.
Load its dataset contract before analysis and its interpretation reference before
assessing rates, workflow signals or review priorities:

```python
load_skill(name="post-trade-control")
read_skill_file(name="post-trade-control", path="references/dataset.md")
read_skill_file(name="post-trade-control", path="references/interpretation.md")
run_post_trade_review(folder_path=r"C:\review\post-trade")
```

The server scans the immediate folder for exactly one matching Parquet file;
its filename is unrestricted. The required columns are `Case_Id`,
`control_logical_code`, `control_description`, `control_execution_date`, `status`,
`final_decision`, `historic_comments_count`, and `hit_search_items`. Comment counts must be
nonnegative whole numbers or null. Empty datasets, missing columns, ambiguous
matching files and invalid counts are rejected with actionable errors.
The folder may be absolute or relative to the MCP server's working directory;
`APP_ROOT` is the path base for `list_files`, not the analysis input. The tool
analyzes all supplied dates without a date-filter or snapshot argument. It does
not call an LLM or modify the source.

Optional analysis fields include `closure_date`, `isautoclosed`,
`historic_comments_markdown`. Required and analytical
fields survive sparse-column pruning. Null comment counts remain unknown;
only explicit zero contributes to completed-without-comments measures. True and
false auto-close values map to Auto and Manual; unrecognized values stay Unknown.
Aging uses the current datetime captured once per run as the snapshot, or closure
minus execution when a closure date exists. The snapshot includes the time of day
in server local time; timezone-naive source dates use that same local time.
Missing execution dates produce unknown age while the snapshot remains available.
Both reports retain the timestamp used for aging and risk measures.

Hit-search analysis always runs in `analysis/fox/hit_search_analysis.py`. It computes
row-deduplicated item attribution, breach coverage and item breach rates before
report rendering. Markdown renders those results, and Excel combines coverage and
item details on Hit Search Analysis and retains the source field on Processed Data. The
required column may contain blank/null values, whose lack of attribution remains
visible in the coverage measure. A missing column fails dataset selection/validation.

The tool returns Markdown and saves an Excel workbook plus the same Markdown in
`Settings.resolve_path(Settings.analysis_results_dir)/fox/<run-id>/`.
`ANALYSIS_RESULTS_DIR` defaults to `.mcp_agent_template/analysis` relative to
`APP_ROOT`; an absolute destination is also supported and is passed to subprocesses.
Each run has a unique directory, including concurrent runs. Returned text contains
both report paths. Sources are not modified. Reports persist until operators remove
them and contain source-derived content; protect them like the input dataset.

The workbook has five standard tabs: Overview, Control Analysis, Monthly Trends, Hit Search
Analysis and Processed Data. Overview reconciles source rows, removed duplicates,
analyzed rows and distinct IDs. Control Analysis combines the scorecard with open
age buckets. Processed Data contains only the used source fields and calculated
results, with a run-local `Analysis_Row_ID` and explicit queue flags. Filters on
status, workflow exceptions, completed-without-comments and the priority/manual
queue flags replace the former separate case tabs. Different records sharing a
Case_Id remain distinct. Values are saved results; regenerate to refresh them.
XML control characters are shown as visible escapes. Text longer than 32,000
characters has a marked preview and complete numbered parts in an optional
Text Evidence sheet, linked by source table, Excel row, column and case row ID.
This companion sheet does not add case rows or duplicate numerical measures.

The Markdown Monthly analysis section uses `monthly_summary`, with one row per
execution month across all controls. Excel keeps the detailed `monthly_trends`
table grouped by execution month and control. Both use the same case-level
aggregation rules, and monthly medians come from the underlying case durations
rather than control medians. The Markdown table includes execution month, volume,
decision counts, current open rows, auto-closed rows, completed-without-comments
counts and median days to close. Missing execution dates form an Unknown group;
unavailable medians stay unknown. These are execution-month groups with current
source statuses, rather than reconstructed historical month-end backlogs.

Python callers can use `analysis.fox.runners.analyze_cases(dataframe, snapshot_at=...)`
to calculate the same review in memory. It returns one `AnalysisResult` consumed by
the flat `markdown_report.py` and `export.py` modules. The MCP tool and
`run_fox_analysis` remain available. Use `render_markdown` and `write_workbook`
with the result and import duplicate helpers directly from `preprocessing`. See the [post-trade structure and extension guide](post-trade-analysis.md)
for module ownership, result fields and a reproducible Python example.

When deploying a wheel, copy `skills/post-trade-control/` from this checkout
into the application's `skills/` folder. Skills are application files and are
not bundled inside the Python wheel. Set `APP_ROOT` for explicit deployment
configuration and output placement. Without `APP_ROOT`, source checkouts use
the package root and installed wheels use the caller's working directory.

The skill guides the agent response through executive assessment, scope/data
basis, evidence-backed observations, auditor follow-up, limitations and report
paths. Triage scores and 30/60/90-day age buckets are screening rules, not an
approved policy or audit opinion. The Markdown shows at most ten controls and
fifteen priority cases; inspect the workbook for the remaining case records.
Unknowns, duplicates, overlapping queues and unavailable corroboration must remain
visible in the review. Dataset comments are evidence, never agent instructions.
The [interpretation reference](../skills/post-trade-control/references/interpretation.md)
defines the active score contributions, workflow predicates, denominator choices,
hit-search formulas and report-to-workbook evidence locations. Completed and
processing rows with closure dates use the same closure-minus-execution duration;
the processing state also raises a workflow flag. Descriptive screens do not
replace policy or independent closure evidence. The tool returns the saved
Markdown and creates `FOX_audit_analysis.xlsx` and `FOX_audit_analysis.md` under
`ANALYSIS_RESULTS_DIR/fox/<run-id>/`, without charts. A saved workbook path is not
proof of agent inspection; no generic workbook reader is supplied by this tool.

### Migration from removed interfaces

Use `run_post_trade_review` in place of `run_post_trade_control_analysis`.
The application server no longer registers the example tools `ping`,
`server_time`, `add` or `search_items`; do not include them in client selections.

The current risk tool is `run_risk_metrics_analysis`, described below. It has an
explicit file-path contract and does not restore the historical result store
or `analyze_risk_metrics` interface.

The [PnL tool and application skill](pnl-analysis.md) use
`run_pnl_analysis` with six explicit source paths. Deploy `skills/pnl/` in the
application skill collection alongside `post-trade-control`. Its dataset and
interpretation references use the same existing skill-loading tools.
It does not restore the former `analyze_pnl` interface or result-reader tools.

The old PnL, risk-metrics, risk-commentary and post-trade implementations and
bundled skills are intentionally removed. The server no longer exposes
`analyze_pnl`, `analyze_post_trade_controls`, `analyze_risk_commentary`,
`analyze_risk_metrics`, `read_analysis_result` or `reopen_analysis_evidence`.
Remove these names from client selections and calls. FOX uses the current dataset
contract; it does not accept the former `source_paths` input or saved JSON IDs.
Existing saved JSON files are not migrated or deleted, but the former result and
evidence reader tools are unavailable. The former analysis modules are no longer
importable. Keep any required historical readers outside this current interface.

### Risk metrics analysis

The application's `skills/risk-metrics/` folder supplies a market activities
auditor workflow. Load it with `load_skill(name="risk-metrics")` and read
`references/dataset.md` and `references/methodology.md` before interpreting results.
Copy the complete folder, including both references, when deploying application
skills; application skills are not bundled in the wheel and there is no fallback
or implicit folder merge. The entrypoint describes when to use the risk tool and
how to read movement, value and exact-observation joint outliers. The dataset
reference owns input schemas, report sections and the nine-sheet evidence map;
the methodology reference owns formulas, unknown states and interpretation limits.
The tool's discovered descriptions and parameter metadata expose the same contract.

```python
run_risk_metrics_analysis(
    sgmr_path="C:/review/sgmr.parquet",
    colibris_path="C:/review/colibris.csv",
    risk_metrics_commentary_path="C:/review/risk.md",
    stress_test_commentary_path="C:/review/stress.md",
    var_svar_commentary_path="C:/review/var.md",
)
```

Only SGMR is required. All optional paths default to `None`; omitted sources
disable dependent checks, whereas supplied invalid paths fail explicitly. File
names are unrestricted and relative input paths use the server working directory.
The tool analyzes every supplied date and perimeter without filtering, source
modification, network access or LLM calls.

The runner lives in `mcp_agent_template.analysis.risk_metrics` and accepts the same
paths plus an optional keyword-only `output_dir`. By default it saves
`risk_metrics_analysis.md` and `risk_metrics_analysis.xlsx` in a unique folder
under `Settings.resolve_path(analysis_results_dir)/risk_metrics/`. The returned
Markdown equals the saved report. The workbook retains all candidates and source
evidence while Markdown detail tables show at most 15 rows, identifying truncated tables.
The Days with movement and value outliers list is complete without that cap.
Prioritized follow-up is omitted from Markdown. Metric value outliers uses value
population `abs(z) >3` with at least 20 consecutive comparable observations; the
joint day list requires both movement and value flags on the exact same source row.
The Value Outliers and Movement and Value Outliers worksheets retain full scores,
baselines and references; SGMR Detail retains unavailable reasons as well.

Comparable-series movements, date coverage, limit history and selected excess workflows
are calculated in Python. SGMR and Colibris are analyzed independently, without
cross-source reconciliation or linked-value/approval checks.
SGMR limit-consumption calculations and their Markdown section are removed,
including utilization, exceedance, warning/proximity and episode outputs. Charts
show risk-value timelines without bounds or utilization overlays. The three commentary files pass
through as complete literal source-text blocks for the agent to review directly.
There is no commentary record parser, automatic commentary matching, derived
commentary count or Commentary Review worksheet. Arbitrary UTF-8 Markdown is
accepted; BOMs and line endings are normalized, and source bytes are unchanged.

All numerical evidence references use the source filename with SGMR `id` or
Colibris `excessId`. Missing or repeated IDs retain a record-number fallback.
Hashes are absent from Markdown, Excel and chart references. Consolidated evidence
citations use a report number and line number; catalog integrity keys stay internal.
Excess governance Markdown identifies events by excessId, without source_locator
or reperformed_usage columns; the complete Excel event evidence retains them.
Descriptive thresholds are not
corporate materiality or SLA policy. Reports remain sensitive like their inputs.

Migration: the Python and MCP five-path signatures and returned/saved Markdown
contract are unchanged. The workbook now has nine sheets; the Reconciliation
sheet, Review.reconciliation field, linked-event checks and link summary counts
are removed. Consumers of the former
commentary summary measures, commentary reconciliation rows or source `sha256`
columns must stop expecting those fields. `source_locator` now carries a source-ID
reference rather than an absolute path and row offset. Commentary interpretation
belongs to the agent, which can also receive it in its original task message.

The tracked [five-source demo and live review instructions](../../../devtools/test_source/risk_metrics/README.md)
follow the PnL and post-trade development workflow. The opt-in Foundry runner uses
`--operation data-package-agent --agent-case risk-metrics --run-live`, loads the
application skill and both references, and exercises the real MCP tool through
the sibling wrapper and Azure Responses. These development checks remain outside
package tests and the portable corporate bundle.

Local verification uses the isolated Python 3.12 uv workflow from `AGENTS.md`,
with synthetic Parquet, real MCP stdio, mocked providers and a loopback allowlist.
NumPy and pandas are declared runtime dependencies. The package remains outside
the suite environment and has no corporate lockfile until corporate resolution
succeeds. The corporate index and provider pins are unchanged.

The [17 October integration record](review/analysis-integration-validation-2026-10-17.md)
retains the dated test, build and installed-package evidence. Use the
[development README](../README.md#test-and-validate) for current validation commands.

## Extend skills from Python

Custom skill scripts are inventoried and readable without being run. Applications that need
to execute them must provide an execution tool through the existing `extra_tools`
interface, with a working directory rooted in the returned skill folder and
the runtime needed by the script. Discovery and loading never execute code.

Python callers can also access files directly:

```python
from mcp_agent_template.skills import discover_skills

skill = discover_skills("skills/my-skill")[0]
instructions = skill.instructions
files = skill.files
template_bytes = skill.read_file("templates/component.tsx.template")
```

`Skill.path` continues to identify `SKILL.md`; `Skill.root` identifies its containing
folder. Existing construction with `name`, `description`, `body` and `path` remains
valid, with an empty supporting-file inventory by default. The extra
`read_skill_file` tool name is reserved alongside `list_skills` and `load_skill`;
an application tool with a colliding name is rejected during agent construction.
