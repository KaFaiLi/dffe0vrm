# FOX dataset and result contract

## Folder and source schema

`run_post_trade_review(folder_path)` scans the immediate folder for
Parquet files and requires exactly one with all these columns (case-sensitive):

| Column | Meaning |
| --- | --- |
| `Case_Id` | Case identifier; counts are rows unless explicitly labeled distinct |
| `control_logical_code` | Control identifier |
| `control_description` | Supplied control description |
| `control_execution_date` | Execution date used for the period and aging basis |
| `status` | Source status, normalized to completed, processing, canceled or unknown |
| `final_decision` | Source decision, normalized to justified, false anomaly, breach, no decision or other |
| `historic_comments_count` | Nonnegative whole-number comment count; null means unknown |
| `hit_search_items` | Comma-separated source-attributed items; null or blank values mean no supplied items |

The filename is unrestricted. Other readable Parquet files without this schema
are ignored; an unreadable Parquet schema fails discovery. Subfolders are not
searched. Pass a folder, not a file. Absolute paths or paths relative to the MCP
server's working directory are accepted; input paths do not resolve against
`APP_ROOT` and are not confined to it. `list_files`, when available for discovery,
uses the separate `APP_ROOT` containment boundary and does not read file contents.

All supplied dates are analyzed; there is no date, control or snapshot argument.
Empty datasets, malformed Parquet, missing required columns, ambiguous matching
files and invalid comment counts produce errors. No LLM is called and the source
remains unchanged.

Useful optional columns are `closure_date`, `isautoclosed`,
`historic_comments_markdown`. Boolean true/false auto-close
values (or their string forms) become Auto/Manual; other or missing values are
Unknown. A null comment count never proves that a completed case has no comments.
Fields used in these calculations survive sparse-column pruning; unrelated fields
with at least 70% nulls may be dropped.

## Population preparation and snapshot

Exact duplicates are compared after dropping `historic_comments` and
`attachment_count` and pruning unrelated fields with at least 70% nulls, but
before normalization and derived row IDs. Equality therefore concerns the
retained source columns, not all original bytes or only the later exported
columns. Exact duplicate rows are removed. Non-identical repeated `Case_Id`
records remain, with their differing values disclosed in Markdown. They are not
automatically resolved into one latest record. Row totals must not be represented
as counts of unique cases. Missing IDs remain in row counts and are disclosed.

The snapshot is the current datetime captured once when preparing the analysis,
using server local time, including the time of day. Timezone-naive source dates
are interpreted in that same local time. Both reports retain this run timestamp.
Age uses closure minus execution when closure exists, otherwise snapshot minus
execution. Missing/unparseable execution dates make age unknown; the snapshot
remains available even if no execution dates are valid. Processing cases with closure
dates are separately flagged as workflow inconsistencies.

See [interpretation.md](interpretation.md) for the exact workflow checks, additive
scores, queue selection, rate denominators and aging qualifications. Unknown
dates/counts remain unknown; they do not establish satisfactory control operation.

## Returned report and saved artifacts

Each successful call returns the saved Markdown text, including actual source,
workbook and Markdown paths. It writes `FOX_audit_analysis.md` and
`FOX_audit_analysis.xlsx` to a unique `fox/<run-id>/` directory. There are no
post-trade charts or JSON result-reader IDs. Use the actual returned paths;
filenames and paths do not provide a workbook-reading capability.

The workbook contains five standard tabs:

- **Overview:** population reconciliation (source rows, exact duplicates removed,
  analyzed rows and distinct case IDs), snapshot, review signals, status, decisions,
  automatic closure and age buckets by status.
- **Control Analysis:** one row per control, combining the control scorecard and
  mutually exclusive open-backlog age buckets, including unknown ages.
- **Monthly Trends:** execution-month and control summaries.
- **Hit Search Analysis:** attribution coverage and breach-item counts/rates.
- **Processed Data:** one row per retained analyzed record, with only the used
  input fields and calculated results. `Analysis_Row_ID` distinguishes retained
  records within a run even when they share a Case_Id. Rows are ordered by score,
  age and control. Filter `status_normalized`, `has_workflow_exception`,
  `completed_without_comments_derived`, `in_priority_queue` and `in_manual_review`
  to reproduce the previous detail tabs. Comments up to 32,000 characters after
  XML-control escaping remain in their cells. Longer values have marked previews
  and complete parts in the optional Text Evidence sheet described below.

When present, **Text Evidence** contains all parts of each oversized value,
including the first. Group by `evidence_record` and concatenate `text` in
`text_part` order (`1/2`, `2/2`, etc.). `source_sheet`, `source_table`,
`source_row` (the Excel row), `source_column` and `Analysis_Row_ID` where available
link back to the main table. Processed Data remains one row per analyzed case;
the companion records do not repeat scores or monetary measures. XML-incompatible
control characters are retained as visible `\uXXXX` escapes. Source files and
in-memory analysis results are unchanged.

Processed Data includes the eight required source fields plus available
`closure_date`, `isautoclosed` and `historic_comments_markdown`, alongside the
normalized values, aging, exception and review results. Dates/text reflect existing
preparation. Missing values remain blank/unknown. Unrelated source columns are
excluded from the export without changing ingestion or deduplication. Named Excel
tables have filters; identifying columns and headers are frozen on detail sheets.
Workbook values are a saved analysis, so rerun the tool to refresh calculations.

Use the report's actual output paths. Default retention is under
`APP_ROOT/.mcp_agent_template/analysis/fox/`,
with a distinct directory per run; `ANALYSIS_RESULTS_DIR` can change the base.
Reports remain until the operator removes them and contain source-derived data.

Hit-search analysis runs for every dataset; Markdown and Excel use the same
calculated coverage and item tables. Blank values remain visible through
breach-item coverage and do not disable analysis. Processed Data also retains
the source `hit_search_items` field. Item populations, formulas and overlap are
defined in [interpretation.md](interpretation.md#hit-search-attribution).

The report limits the control table to ten rows and the priority table to fifteen.
The Markdown monthly analysis has one row per execution month across all controls.
Excel's Monthly Trends table retains the execution-month/control detail. Both use
the same case-level aggregation rules; overall monthly closure medians are computed
from the underlying durations, never from control medians. The summary covers
volume, justified/false-anomaly/breach/no-decision outcomes, open rows, auto-closed
rows and completed-without-comments rows. Open counts reflect current source status
grouped by execution month, not historical month-end backlog. Missing execution
dates form an Unknown month group; unavailable closure medians remain unknown.
Hit-search items are source attribution, not verified causality; co-occurring
items and overlapping queues must not be added together as disjoint populations.
Source comments can be included in report previews and in the workbook. Handle
the artifacts with the same care as the input dataset.
