# Post-trade measures and audit interpretation

Use this reference when interpreting a FOX report. The rules below describe the
current deterministic implementation; they are not supplied policy, SLA,
materiality or an audit rating framework. Input and artifact details are in
[dataset.md](dataset.md).

## Populations, rates and time

| Measure | Population and meaning |
| --- | --- |
| Status, decision and priority-band shares | Retained analyzed rows, including non-identical repeated case IDs |
| Control population share | Rows for that control / all analyzed rows |
| Control breach, false-anomaly, open, auto-close and completed-without-comments rates | Rows meeting the condition / all retained rows for that control, including unknown outcomes; not just completed rows |
| Open-age bucket shares and open-over-30/60/90 signals | Processing rows / all processing rows; unknown ages remain in the denominator |
| Workflow, negative-age and completed-without-comments quality shares | Rows meeting the condition / all analyzed rows |
| Monthly measures | Current source statuses and outcomes grouped by execution month, across all controls in Markdown and by control in Excel |
| Median, p90 and maximum days to close | Available closure-minus-execution durations, regardless of status, including negative values; unavailable durations are excluded |

Do not confuse the all-status **Cases aged over 30/60/90 days** review measures
with processing-only **Open over 30/60/90 days** signals. Threshold counts are
nested: over 90 is also over 60 and over 30. The backlog buckets are mutually
exclusive; their labels use whole days, but comparisons retain fractional days.
The first bucket includes negative ages, which have a separate quality flag.
An empty denominator yields an unknown rate, not zero.

Age is closure minus execution when a valid closure exists, otherwise the single
server-local run snapshot minus execution. A processing row with a closure date
therefore has a closure-based duration and a workflow flag; its age is not an
uninterrupted open duration. Unknown execution dates leave age unknown. Completed
rows without valid closure dates use snapshot age while their days-to-close
duration remains unknown. The tool does not separately screen closures after the
snapshot; request supporting date evidence when this matters.

Monthly open counts are current processing rows assigned to execution-month
cohorts. They do not reconstruct month-end backlog or historical state changes.
Monthly closure medians use underlying row durations, not averages of control
medians. Outcome, open, auto-close and comment counts can overlap. The Auto flag
is counted as supplied even if the source status is not completed; it does not
independently verify automatic closure or approval.

## Workflow checks and score contributions

The workflow flag combines any of these conditions:

- completed with no normalized decision or no valid closure date;
- processing with a normalized decision or a valid closure date;
- closure before execution;
- canceled without a valid closure date.

One row can have several messages but receives the workflow contribution only
once. Here a decision means any normalized value other than `no decision`;
`other` is not proof of a recognized approval. Missing optional closure data can
create workflow flags; investigate source completeness before claiming a failure.

| Signal | Points |
| --- | --- |
| Source decision normalized to breach | +5 |
| Processing with age strictly over 90 days | +4 |
| Processing with age strictly over 30 and at most 90 days | +3 |
| Any workflow inconsistency above | +3 once per row |
| Completed breach with explicit zero comments | +3 in addition to breach points |
| Negative age, including future execution without closure | +3 independently |

Open-age bands are mutually exclusive. A closure before execution can contribute
both workflow and negative-age points. Unknown age or comment count does not
satisfy the respective numerical condition. A completed row with zero comments
is a reported signal, but receives the additional comment points only when its
decision is breach.

Bands are Low 0–2, Medium 3–5, High 6–8 and Critical 9+. The priority queue
contains scores at least 3, ordered by score descending, age descending and
control ascending. Manual review contains breaches, processing rows over 90
days, workflow inconsistencies or negative ages, ordered by score then age
descending. Manual review is a subset of the current priority queue; the two
counts must not be added. Processing age between 30 and 90 days alone enters
the priority queue without entering manual review.

For example, a processing row aged 45 days with no decision or closure receives
3 points and enters only the priority queue. A completed breach with zero
comments and otherwise consistent dates receives 8 points and enters both
queues. These illustrate deterministic screening, not confirmed audit findings.

## Hit-search attribution

Comma-separated items are trimmed and internal whitespace is normalized.
Repeated occurrences of the same item count once per retained row; capitalization
is retained. Non-identical repeated case IDs still contribute separate rows.
Only items present on at least one breach row appear in item detail.

- **Breach-item coverage:** breach rows with any nonblank item / all breach rows.
- **Share of breach rows:** breach rows carrying an item / all breach rows,
  including those with no supplied item.
- **Breach rate among item rows:** breach rows carrying an item / all retained
  rows carrying that item, across all statuses and decisions.

Co-occurring items make counts and shares non-additive. Blank attribution stays
visible in coverage; with no breaches the breach-denominator rates are unknown.
For a synthetic example, if 4 of 10 breach rows carry item A and 20 total rows
carry A, its breach share is 40% and its item breach rate is 20%. These are
different questions, and neither verifies that A caused a breach. Compare the
source attribution with comments and independent case/trade evidence.

## Evidence locations and follow-up

| Review question | Returned report / saved evidence | Corroboration to request |
| --- | --- | --- |
| Scope, missingness and row reconciliation | Scope and data basis; Overview | Extract lineage, completeness and applicable period |
| Control concentration and outcome rates | Control concentration; Control Analysis | Control design, denominator completeness and source classification rationale |
| Execution-month patterns | Monthly analysis; Monthly Trends | Historical state/closure records before claiming backlog trends |
| Aging and inconsistent workflow | Open-case age buckets; Workflow and completion signals; Processed Data | Policy deadlines, case history and actual closure/approval records |
| Comment and auto-close signals | Highest-priority rows when displayed; Overview and Processed Data | Full case rationale, approval and automatic-closure rules |
| Attributed breach items | Hit-search item analysis; Hit Search Analysis and Processed Data | Case comments and supporting trade evidence |
| Case selection and repeated IDs | Duplicate disclosure and Highest-priority rows; Processed Data queue flags and Analysis_Row_ID | Distinguishing record fields and resolution of conflicting source records |

The returned Markdown shows at most ten controls by volume and fifteen priority
rows. Comments for those priority rows are included in full when available;
score reasons and hit-search previews can be shortened. All analyzed records
and queue flags remain in Processed Data, but that sheet exports selected fields
and is not a raw-source archive. Use the original source when required fields
are absent from the export. `Analysis_Row_ID` is local to a run, not a persistent
source identifier or an ID displayed in the priority Markdown table.

Cite only records and artifacts actually inspected. A generated file path
establishes where saved evidence can be reviewed, not that it has been read.
If the current tools cannot inspect the needed workbook rows, state the
limitation and name the records/filters for auditor follow-up; do not rerun the
same folder-only tool to obtain unsupported procedures or new evidence.
