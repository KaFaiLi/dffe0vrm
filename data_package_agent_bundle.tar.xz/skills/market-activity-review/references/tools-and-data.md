# Available tools and source boundaries

Use the manifest supplied by the notebook, not paths inferred from this reference.
All three tools preserve source files and return analysis Markdown with
actual paths to full Excel/Markdown artifacts. The PnL tool also returns both
complete original commentary documents directly for LLM review. Skills are
loaded using `load_skill`; supporting files use `read_skill_file`.

## P&L specialist

Skill: `pnl`; tool: `run_pnl_analysis`.

Required arguments: `income_attribution_path`, `pnl_path`, `adjustments_path`,
`validation_history_path`, `income_attribution_commentary_path`,
`pnl_commentary_path`. All supplied dates are reviewed independently for each
dataset. No review-date arguments, review context or parent-GOP mappings are accepted.
All six files are required, including both original commentaries. Absolute paths
and paths relative to the MCP server's working directory are accepted. Resolve
`list_files` results against the known `APP_ROOT` if its path base differs. An
input error needs the stated correction; do not relabel currencies, omit records,
fabricate commentary or repeat unchanged calls. Retain completed sibling reports
and mark the PnL review incomplete if it cannot run.

The report starts with the desk hierarchy derived from all loaded PnL rows,
including rows excluded from numerical calculations. It
describes observed membership, not dated ownership or a cross-source mapping.
PnL summaries, outliers and reversals use daily PC totals after GOP/PTF
aggregation. Currency must be EUR and Notion must be single-valued across every
PnL input row before exclusions. They appear in Markdown/Excel run scope; Version
does not split series. There is no conversion or currency-specific analysis.
Attribution independently aggregates each daily driver to date/PC and reports
outliers using all known daily amounts. Daily evidence and screen availability
remain in Excel. Attribution series summaries and trend calculations/sheets are
removed; do not request or claim them.
Final attribution PnL and cumulative columns are optional and unused; cumulative
checks and monthly PnL summaries are not performed. Detailed methodology belongs
in the `pnl` skill's dataset and interpretation references.

Validation teams labelled `MOCK_TEAM_A/B` have no supplied FO/MPC meaning.
Already labelled FO/MPC records retain their supplied roles; inspect the actual
input rather than assuming the local research variant applies. Validation states
are Not Validated, Waiting Official PNL, Validated and DEValidated. The summary
counts supplied rows and calculates state percentages separately by team and PnL
type (STAB/FLASH), grouping extra state labels under Other. State comparisons are
exact, including case and whitespace; team/type grouping is trimmed and
case-insensitive. Each percentage uses
the record count within that team/type group as its denominator. Blank/additional
types are retained. Original labels remain in workbook records; no separate
state-count section or not-labelled-Validated aggregate is generated. For example,
Official PNL is not silently reinterpreted as either approved or failed.
DEValidated counts are grouped separately by team/GOP/PnL type and are already
part of the summary totals. Raw validation records remain in the workbook. There is no active/date
filtering, latest-state selection, deduplication or PnL/attribution matching.

Adjustments use one desk's supplied AMOUNTINEUR directly in EUR. Every supplied
row contributes to dataset totals. All individual records remain in the workbook.
Markdown displays summaries, repeated-entry candidates and CREATIONDATE values
whose daily count z-score is strictly greater than 3 (equality is excluded).
There are no amount-based adjustment screens. Count screens use CREATIONDATE only,
using supplied PnL dates plus valid creation dates. Valuation dates do not define
a daily view or substitute for missing creation dates. Creation dates outside
the PnL calendar remain included. No review-period overlap is checked or labelled.
Rows with missing/invalid CREATIONDATE remain in full records and SOURCE/NATURE
totals but cannot enter the daily screen. No other calendar days are filled.

PnL and attribution retain their source units; attribution currency is unspecified
and there is no cross-source monetary reconciliation. Routine daily tables, hashes,
desk-data tables, references and source-row counts are workbook-only. Generated
Markdown shows all numerical summary/candidate rows, rounds displayed values and
may abbreviate long table cells. Use existing flags rather than reclassifying
rounded scores. Source-owned numerical sections provide evidence-catalog bindings;
do not invent row locators when the summary omits them.
Both complete commentary documents are returned unchanged,
without record parsing, date filtering, approval checks or automatic issue associations.
The report ends with actual `pnl_review.xlsx` and `pnl_review.md` paths. Daily EUR
PC/year PNGs and a chart index/manifest are saved under `charts/` beside them;
no image previews or chart links are returned. No attribution/YTD charts exist.
Workbook-only evidence and images remain uninspected unless actually retrieved.

## Risk specialist

Skill: `risk-metrics`; tool: `run_risk_metrics_analysis`.

Required `sgmr_path`; optional `colibris_path`, `risk_metrics_commentary_path`,
`stress_test_commentary_path`, `var_svar_commentary_path`. Omit genuinely absent
optional files; supplied invalid paths fail. There is no date/perimeter filtering
parameter: disclose the full analyzed population.

SGMR provides observed risk values, series identities, metric/unit and limit definitions.
Colibris is a selected excess-event workflow population, not a denominator for
all risk observations. Commentary is supplied as complete unprocessed text for
the specialist to review directly. Do not claim automated commentary counts or
matching. Numerical references use SGMR `id` and Colibris `excessId`, without hashes. Keep
VAR, SVAR, STRESS TEST and EXPOSURE separate. These are not independently
validated model outputs, Greeks or expected shortfall.

Review percentage-movement and value population abs(z) >3 screens separately.
Movement scoring covers short comparable segments; value scoring requires at
least 20 consecutive comparable observations. Days with movement and value
outliers includes every exact observation with both flags, without the ordinary
15-row Markdown cap. A date or matching display labels cannot combine different
rows' flags. Identify results with riskMetricName and perimeterMnemonic.

SGMR and Colibris are analyzed independently, without cross-source reconciliation
or SGMR limit-consumption calculations. Risk aging uses the latest valid SGMR
value date and event states as recorded. Preserve supplied units; do not assume
every file uses the baseline MEUR unit. The nine-sheet workbook retains all
observations, scores, baselines, availability and independent workflow checks.
Workbook rows omitted from returned text have not been inspected by the agent.
Markdown omits Prioritized follow-up, Executive observations, Scope and
availability, Limit consumption and chart sections.

## Post-trade specialist

Skill: `post-trade-control`; tool: `run_post_trade_review(folder_path)`.

Supply the directory containing exactly one matching Parquet file. Required
fields: `Case_Id`, `control_logical_code`, `control_description`,
`control_execution_date`, `status`, `final_decision`, `historic_comments_count`,
`hit_search_items`. Optional fields include closure date, auto-close flag and comments.

The baseline case population is independently generated, has no structured
trade/desk linkage, and has a latest execution date of 30 September 2026.
The analysis snapshot is the current datetime captured once per run in server
local time, so open aging changes with the run time; use the timestamp in the reports.
Exact duplicate rows differ from nonidentical repeated case IDs. Keep null
comment counts distinct from zero. Closure dates can extend beyond the snapshot.
The tool does not explicitly flag future closures; that procedure needs additional
review outside the current agent tools. Repeating the folder-only tool cannot
add that calculation; record an evidence request instead. A follow-up can clarify
an existing excerpt, but cannot expand the analysis tool's supported procedures.
When closure exists the tool uses closure-minus-execution even for a
processing case: do not label that measure open age without checking the state.

Priority bands are triage aids, not approved audit severity. The Markdown's top
controls/cases are a display limit, not an audit sample. Case status and comments
do not prove confirmation, cash settlement, complete control coverage or effective
remediation. Ask for transaction records and independent closure evidence.

## What is not available

There is no generic raw-file/workbook retrieval tool on these agent allowlists.
Complete positions, independent marks, accounting ledgers, model validation,
regulatory PLA/ES inputs, confirmations, collateral and settlement records are
absent from the baseline. Do not assert assurance over these areas. Seeded
evaluation copies are separate populations; answer keys are never audit evidence.

Snapshots and row counts in research are dated inventory observations. Actual
tool results determine the current run's scope. No source file is rewritten to
make a mapping work; any supplied working copy needs documented lineage.
