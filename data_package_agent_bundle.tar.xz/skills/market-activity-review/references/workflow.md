# Workflow and cross-source challenge

## Business process and responsibilities

Trading starts with an authorized transaction and accurate booking. Operations
enriches economic and settlement details, matches confirmations, monitors
clearing/settlement, investigates breaks and retains closure support. Front
office explains trading results; independent product control reviews valuation,
P&L, adjustments and sign-offs. Market risk monitors comparable risk series,
limits, stress measures and excess investigations. Internal audit tests these
controls against applicable criteria and corroborates management assertions.
Actual role names and approval authority must come from the supplied governance.

Follow the evidence chain: booking/positions → valuation/P&L → risk consumption
→ investigation/approval → corrective action and independent closure evidence.
The current extracts cover parts of this chain, not the complete transaction
population. A recorded case disposition is not proof of economic settlement.

## Six required comparisons

| Report comparison | Procedure and prerequisites | Follow-up evidence |
| --- | --- | --- |
| pnl_attribution | Review EUR PC daily P&L summaries/outliers/reversals and each PC attribution driver's full-history outliers independently. Both outlier screens use absolute z-score >=3, with no minimum observation count; missing/constant histories have unavailable scores. Daily attribution evidence and screen availability stay in Excel. Series summaries and trend calculations/sheets are not available. This report entry does not perform monetary reconciliation or establish attribution units. | Separate source definitions, driver taxonomy and units, daily evidence and valuation support. |
| pnl_adjustments_validation | Review reported results, adjustment summaries and creation dates with count z-score >3. Separately review validation state counts and percentages by team and PnL type (STAB/FLASH), plus grouped DEValidated counts. State labels are not proof of failed approval. Cross-source links require additional evidence. Never add adjustments to reported P&L without inclusion rules. | Independent approval, correction lineage and historical validation timing. |
| pnl_risk | Compare unusual P&L dates and adjustment CREATIONDATE activity with comparable exposure/limit movements after mapping portfolios and PC/GOP scope. Valuation-period labels do not define the adjustment activity date. Keep P&L currency separate from risk MEUR and risk metrics separate from one another. | Effective-dated desk/book mapping, positions, pricing and risk-factor changes. |
| risk_excess_workflow | Link SGMR consumption to Colibris by genuine identifiers, then check scope, dates, metric, unit and bound. Relative triggers are not absolute-limit breaches. | Event lineage, limit versions and approval history. |
| numbers_commentary | Review the complete original PnL/attribution commentary as source evidence. Assess explanations and recorded approvals directly; substantiate any numerical relationship explicitly. No automatic issue associations or parent mappings are supplied. | Claimed attachments and independent support for explanations. |
| post_trade_activity | Compare booking/amendment/settlement cases with P&L, adjustments or risk only where a genuine case-to-trade/book/desk link exists. | Case-to-trade linkage, confirmations, settlement evidence and correction records. |

Classify each comparison:

- **Confirmed:** identity and comparison basis are supported, and the evidence
  supports the stated relationship. This does not automatically establish cause.
- **Contradictory:** comparable, linked records contain an evidenced inconsistency.
- **Contextual:** relevant narrative or co-occurrence, without confirmed linkage.
- **Ambiguous:** several plausible links or unresolved scope/basis definitions.
- **Unlinked:** no supported connection in the supplied evidence.

Confirmed/contradictory entries need the operator's `MappingBasis.id` and at
least two source references; unresolved compatibility limits prevent those
classifications. Mapping metadata is an auditable assertion supplied by the
operator, not a new join engine or proof that every source row was reconciled.

## One finding

Construct a common issue only when the evidence supports it. For example,
linked correction, P&L and approval records could support an adjustment-control
finding if an applicable approval requirement and its violation are established.
Unrelated settlement cases cannot be appended as evidence of the same cause.

State cause as unknown when only symptoms are visible. Distinguish actual loss
from potential exposure and avoid adding overlapping exception counts. Preserve
counterevidence and explain how it changes the conclusion. An evidence gap may
justify further audit work without establishing a bank-wide control deficiency.

The notebook's main agent has no arbitrary file-reading tool. Its scoped
`lookup_review_evidence` tool indexes only captured successful analysis results.
The model selects catalog IDs; the server supplies exact source-bound report
lines and locators. A single-source report can supply its own report-line
evidence. Multi-source rows need an unambiguous source marker or a source-owned
PnL numerical-section binding supplied by the renderer. Original commentary
headings cannot create numerical bindings. References to full workbooks identify
available artifacts, not additional inspected evidence. Ask for targeted support
or mark checks unperformed when the available reports cannot establish them.

## Research basis

This workflow operationalizes the suite's market activity audit research and
36-item checklist prepared on 17 October 2026. It uses supervisory principles
as context, not as automatically applicable legal criteria:

- Basel risk data aggregation and reporting: https://www.bis.org/publ/bcbs239.htm
- Basel market-risk framework: https://www.bis.org/basel_framework/standard/MAR.htm
- CPMI-IOSCO infrastructure principles: https://www.bis.org/cpmi/publ/d101a.htm

No online research is performed by the demo agents. Obtain current, applicable
requirements separately before supplying a `Criterion` for a supported finding.
