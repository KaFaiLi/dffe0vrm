# Review checklist: 36 stable check IDs

Record one result for every ID. Use `exception_identified`,
`no_exception_identified`, `insufficient_evidence`, `not_performed` or
`not_applicable`, with a basis and evidence references. A tool call does not
automatically complete every check in its topic. Partial procedures must retain
their untested part as insufficient evidence or not performed.

Evidence locators/excerpts in the JSON must be exact text from the tool report.
Label them `tool_report`; do not imply independent raw-record retrieval. Record
populations, exclusions, units and denominators. Never use display truncation as
a sample or an absence of displayed exceptions as a clean full-population test.

| ID | Procedure | Available capability and boundary |
| --- | --- | --- |
| D01 | Preserve source and perimeter | Manifest, dates/snapshots and row reconciliation; source hashing/independent extraction assurance need separate evidence. |
| D02 | Verify keys and usable fields | Review reported missing/invalid fields, conflicting keys and duplicates; unknown is not zero. |
| D03 | Establish meanings and joins | Require role/state, hierarchy, version, currency/scale and policy definitions; record unresolved dependencies. |
| D04 | Validate coverage and denominators | Compare comparable series; PnL validation counts supplied history rows independently. Calendar and inception/closure completeness need support. |
| P01 | Establish EUR P&L series | Review the full supplied desk tree and daily PC totals after GOP/PTF aggregation. Currency must be EUR and Notion single-valued; Version does not split series. Daily evidence and references remain workbook-only. |
| P02 | Investigate daily extremes | PC daily-total absolute z-score >=3 with no minimum observation count; constant values have unavailable z-scores. Cause requires position/pricing/booking evidence. |
| P03 | Review P&L PC movements | Review PC daily totals and reversal candidates. PnL cumulative checks and monthly summaries are outside this analysis; reported YTD is workbook-only display data and no YTD charts are generated. |
| P04 | Screen each PC attribution driver | Aggregate GOP contributions by date/PC and review absolute z-score >=3 outliers using all known daily amounts. Missing values remain unknown; parent/child drivers are not additive and final/cumulative PnL is unused. Daily evidence and screen availability remain in Excel. Series summaries and trend analysis are not performed. |
| P05 | Review unexplained attribution | Review a supplied residual/unexplained daily driver only when its meaning is documented. The tool does not calculate a residual, additive decomposition or ratio to final PnL. Obtain taxonomy/units and inspect daily evidence for unavailable screens before drawing a coverage conclusion. |
| P06 | Cover all supplied adjustments | All supplied rows contribute across all dates, with no review-period overlap check. Missing IDs and invalid valuation intervals remain data-quality findings. No automatic proration or addition to reported P&L. |
| P07 | Review adjustment creation-date counts | Review summaries and CREATIONDATE values with daily count z-score >3, including creation dates outside the PnL calendar; no valuation-date or amount-based screen. Full adjustment records and EUR amounts remain in the workbook. Matching rows under different IDs are repeated-entry candidates. AMOUNTINEUR must be numeric; no FX or PnL/desk mapping check is performed. |
| P08 | Challenge rationale/reversals | PnL reversal candidates are heuristic and do not classify adjustment reversals. Adjustment rationale, approvals, inclusion in reported PnL and referenced documents require corroboration. |
| P09 | Review PnL validation dataset | Review state counts and percentages by team and PnL type (STAB/FLASH) and grouped DEValidated counts. Percentages use each team's type-specific record count. Source labels do not prove missing history or failed approval. No PnL/attribution matching, active filtering or historical-timeliness conclusion. |
| P10 | Review original commentary | Read both complete PnL/attribution Markdown documents directly. Assess explanations, recorded approvals and supporting references with exact source quotes. No automatic parsing or issue associations are supplied. |
| P11 | Review P&L and attribution independently | Retain independent desk datasets, definitions, units and per-driver outlier observations. Cross-source monetary reconciliation is outside this analysis. |
| R01 | Establish risk series | Keep limit/portfolio/metric/unit/version/scenario axes; do not add VaR or different risk measures blindly. |
| R02 | Identify unsupported limit-consumption checks | SGMR limit-consumption analysis is not performed. Do not claim tool-generated utilization ratios, bound-exceedance checks or breach episodes. |
| R03 | Review effective limits | Dates and changed limits are candidates; approval and temporary-limit precedence need history. |
| R04 | Identify unsupported proximity checks | Warning thresholds and sustained-proximity screens are removed. Any requested proximity procedure needs additional evidence outside the tool. |
| R05 | Review movement/value outliers and joint days | Review successive percentage-movement population abs(z) >3 in every comparable segment, and value population abs(z) >3 with at least 20 consecutive comparable values. Joint days require both flags on the exact same observation; review the complete list with riskMetricName and perimeterMnemonic, without merging series by date. Retained level shifts stay separate. No fixed 25% trigger, volatility-change or persistent-trend screen. |
| R06 | Reperform selected excess usage | Keep absolute and relative events separate; 1.5 percentage-point discrepancy screen, not 1.5%. |
| R07 | Review excess chronology/backlog | Calendar aging uses the latest valid SGMR date and event states as recorded, without reconstructing historical backlog or inventing an SLA. |
| R08 | Challenge explanation/approval | Review recorded action, deadline, LoD2 and approvals; tags are not independent validation. |
| R09 | Keep SGMR and Colibris independent | The risk tool analyzes these populations independently and performs no cross-source reconciliation. Record any required external mapping or comparison as unavailable rather than claiming a tool-generated link. |
| R10 | Corroborate risk commentary | Supported scope/timing, exact references and contrary evidence; repetition is not proof of inadequate review. |
| T01 | Resolve duplicates/unknowns | Exact rows versus conflicting repeated Case_Id; retain nulls and uncertainty about authoritative version. |
| T02 | Analyze control outcomes | Row/distinct-case denominators; case outcomes do not establish full control/trade coverage. |
| T03 | Review open aging | Source snapshot, missing dates and processing-with-closure contradictions; no assumed SLA. |
| T04 | Review workflow/date consistency | Tool flags plus additional future-closure check; the latter is not automatically performed. |
| T05 | Challenge closure support | Zero versus unknown comments; narrative/evidence references do not prove correction or inspection. |
| T06 | Challenge automated closure | Auto/Manual/Unknown patterns; authorized rules, changes and overrides require additional evidence. |
| T07 | Compare decisions with narrative | Selected full comments and contrary evidence; unavailable omitted records remain unreviewed. |
| T08 | Review beyond priority queue | Additional justified ordinary-case/control sample; do not add overlapping queues or treat scores as audit severity. |
| T09 | Reperform economic control | Requires case-to-trade linkage and confirmations/settlement/correction support, absent from baseline. |
| C01 | Connect P&L/risk/post-trade evidence | Effective mappings, compatible periods/units and preserved one-to-many ambiguity; independent cases remain unlinked. |
| C02 | Consolidate and challenge finding | Reconcile performed/unavailable work and evidence; one supported common issue or further-evidence assessment. |

For additional evidence request the specific missing item and intended test:
positions/independent prices for valuation, certified P&L and ledger for accounting,
model definitions/backtesting for risk validity, authority/SLA history for approval,
and trade/confirmation/clearing/custody/payment records for post-trade controls.
Leave action owners and due dates unassigned until actually agreed.
