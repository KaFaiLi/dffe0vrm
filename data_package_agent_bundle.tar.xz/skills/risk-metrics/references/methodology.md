# Risk calculations and interpretation

## Populations and comparability

SGMR is a population of supplied risk measurements; Colibris is a selected
excess-event population. Analyze them independently. The tool does not reproduce
VaR, SVaR, stress losses or exposure from positions, convert currencies or create
portfolio risk totals.

Each SGMR series keeps its limit ID, portfolio, PC, indicator, metric name,
unit, version and populated definition/scenario axes. These include measure,
scenario, underlying, bucket, tenor and currency specifications when supplied.
The two report labels do not define a statistical population.

The calendar is the union of valid supplied SGMR dates, without an invented
business/holiday calendar. Missing expected dates and dated invalid/incomparable
or conflicting observations break consecutive segments; undated rows are unscorable.
Exact raw duplicates are removed and disclosed; conflicts are retained and
excluded from dependent calculations. Baselines never cross a segment or series boundary.

## Movement outliers

For every comparable consecutive pair, calculate:

```text
movement[t] = (value[t] - value[t-1]) / abs(value[t-1])
mu = sum(known movements) / N
sigma = sqrt(sum((movement - mu)^2) / N)
movement_z[t] = (movement[t] - mu) / sigma
flag = abs(movement_z[t]) > 3
```

Use all known percentage movements in the same segment, including segments
shorter than 20 observations. The standard deviation is population-based
(`ddof=0`); equality at either z boundary is excluded. Ratios retain their scale:
`0.1 = 10%`. Both tails and signed scores are retained.

A segment start has no predecessor. Zero previous values and nonfinite derived
movements remain unavailable and are excluded from the movement baseline.
Known constant movements retain their movement values but have unknown scores
and flags because dispersion is zero. A one-movement population also has an
unknown z-score. SGMR Detail retains the predecessor, population count,
mean/deviation and explicit status.

## Metric-value outliers and joint days

A value screen requires at least 20 consecutive comparable observations:

```text
mu_value = sum(values) / n
sigma_value = sqrt(sum((value - mu_value)^2) / n)
value_z[t] = (value[t] - mu_value) / sigma_value
value_flag = abs(value_z[t]) > 3
joint_flag = movement_flag is true AND value_flag is true on the same observation
```

Use the complete segment's values, not the distribution of percentage changes.
Both tails are included and equality is excluded. Short segments retain their
population count with `insufficient_comparable_observations`; zero-dispersion
eligible segments retain their baseline with `zero_value_dispersion`.
Signed scores, flags and unavailable reasons remain in SGMR Detail.

Joint flags are true only when both screens are true on the exact same retained
source row. A known false flag makes the joint flag false; otherwise an
unavailable required flag leaves it unknown. Do not match a value outlier to
another row's movement outlier by date, metric/perimeter labels or scenario
resemblance. The joint-day list is chronological and complete; several matching
observations on one date remain separate rows.

Read individual outliers alongside the intersection. A value can remain unusual
after a spike even when its next percentage movement is ordinary. These are
retrospective descriptive screens over supplied segments, not forecasts,
formal significance tests or approved materiality thresholds.

## Retained auxiliary checks

| Check | Calculation or trigger |
| --- | --- |
| Source-date coverage | Distinct nonconflicting series dates / all valid observed SGMR dates; flag strictly below 95%. Inception/closure may explain gaps. |
| Sustained level shift | At each split with 20 values before and 20 after, require absolute mean change / absolute prior mean at least 20% and effect at least 2.5. Effect is absolute mean difference / average population deviation of the two windows. A zero prior mean is unavailable; a nonzero shift with zero dispersion qualifies with a label. Keep the strongest qualifying change-times-effect split, earliest on ties. |
| Limit history and timing | Compare current/initial and consecutive dated bounds with relative and absolute equality tolerance `1e-8`; check stated effective dates. A bound change or effective date does not establish approval. Temporary-bound timing/precedence is not inferred. |
| Hierarchy and source consistency | Compare explicit PC/BU/SBU/GPC fields with `flatStrana`; disclose conflicting grains, invalid fields and inconsistent prior-value dates. |
| Colibris calendar aging | For nonconflicting IDs, closure minus creation when recorded closed, or latest valid SGMR date minus creation when recorded open. Unknown states, missing dates and negative intervals remain unavailable. |
| Colibris chronology and validation | Check contradictory states, reversed explanation/validation/closure sequences, open events past recorded deadlines, explicitly unsatisfactory first-level/LoD2 flags and incomplete/reversed limit-increase chronology. |
| Within-Colibris usage | `abs(last value) / abs(limit)` requires nonconflicting IDs and a usable same-direction bound. Parse reported `usage` only with an explicit percent sign. Flag a difference above 1.5 percentage points, or a reported maximum more than 1 point below last usage. |
| Recurring selected excesses | At least three nonconflicting events with the same perimeter, indicator, metric name, unit, limit type and bound. Counts describe selected events, not daily breach frequency. |

SGMR limit-consumption/utilization, bound-exceedance, warning/proximity and breach-
episode calculations are not performed. The fixed 25% movement trigger,
volatility-change and persistent-trend screens are absent. SGMR-Colibris
cross-source reconciliation and linked-value/approval checks are not performed.
These limits do not disable independent coverage, limit-history or event-usage checks.

## Evidence and conclusions

The reference date is the latest valid SGMR value date, including dates on
conflicting rows. Recorded open status does not reconstruct historical backlog;
aging or a passed recorded deadline alone does not prove an SLA failure.
Missing explanation/approval evidence needs the applicable rules and complete
history before concluding a failed control. Full check evidence remains in Excel;
the Markdown has no Prioritized follow-up or overall severity score.

Commentary is supplied in full for direct agent review. Attribute claims to
their document and evidence IDs/excerpts, and compare only supported dates,
units, metrics and perimeters. Treat proposed label equivalences, LLM tags and
narrative assertions as unverified. Repeated wording is not a quality score;
a statement that supporting material is attached does not prove it was inspected.
Do not infer SGMR-Colibris lineage from similar dates or names.
