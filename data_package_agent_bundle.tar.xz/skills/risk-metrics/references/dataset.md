# Risk tool inputs and exported evidence

## Invocation

```python
run_risk_metrics_analysis(
    sgmr_path="C:/review/sgmr.parquet",
    colibris_path="C:/review/colibris.csv",  # optional
    risk_metrics_commentary_path="C:/review/risk.md",  # optional
    stress_test_commentary_path="C:/review/stress.md",  # optional
    var_svar_commentary_path="C:/review/var.md",  # optional
)
```

Only `sgmr_path` is required; optional arguments default to `None`. Use absolute
paths or paths relative to the MCP server's working directory. Filenames are
unrestricted. All supplied dates and perimeters are analyzed; no review-date or
perimeter-filter arguments exist. The analysis preserves input files and makes
no network or LLM calls.

The discovery tool `list_files` returns paths relative to `APP_ROOT`, which can
differ from the server working directory. Resolve those results against their
discovery root before passing them to the analysis tool; prefer absolute paths.

SGMR must be a nonempty Parquet table with `limId`, `stranaNodeName`,
`rmRiskIndicator`, `consoValueDate` and `consoValue`. Colibris must be a UTF-8
CSV with `excessId`; a supplied header-only CSV is an empty population, distinct
from omission. Commentary inputs must be UTF-8 Markdown. A BOM is accepted.

Headers are case-insensitive with leading/trailing whitespace ignored; blank or
ambiguous names are rejected. Supplied invalid paths, formats or required headers
fail explicitly. Individual invalid values are retained as raw evidence with
unknown parsed values and data-quality disclosures. Extra columns are preserved.

| Analysis | Additional fields and meaning |
| --- | --- |
| Comparable SGMR series | Populated `rmRiskMetricName`, `limUnit` and nonnegative integer `consoVersion`; populated metric/scenario axes distinguish separate definitions. `stranaPc` may be absent. |
| Hierarchy | Explicit PC/BU/SBU/GPC fields and `flatStrana` JSON. |
| Limit history and timing | `limStartDate`, `limEndDate`, current/initial min/max bounds; temporary bounds are retained without inferred precedence. |
| Event states and calendar aging | `excessStillOpen`, `excessCreationDate`, `excessCloseDate` and recorded workflow status. |
| Within-Colibris usage | `excessLastConsoValue`, `limitValue`, `unit`, explicit percentage `usage`; `excessMaxUsage` is in percentage points. |
| Explanation and validation evidence | Explanation creation/deadline fields, cause/action plan, validation dates and satisfactory flags, including separate LoD2 fields. |
| Limit-increase chronology | `increaseId`, `increaseWorkflowStatus`, request creation and trading/risk approval dates. |

Omitting an optional source disables its dependent checks. Missing optional
columns can make a check partial or unavailable without disabling independent
calculations. Read Sources and Methods for the actual availability.

## Report identities and source references

Tables use separate `riskMetricName` and `perimeterMnemonic` columns. SGMR maps
`rmRiskMetricName` and `stranaPc` to these names; Colibris uses its own corresponding
fields. Source spelling is preserved and missing labels remain unknown. Full
series identities still control calculations; the display labels never merge
different limits, units, versions or scenarios.

Numerical references use the source filename plus SGMR `id` or Colibris
`excessId`. Missing or repeated IDs retain an original one-based data-record
number to distinguish rows; the CSV header is excluded. Exact duplicate rows
are removed with their original locations disclosed. Conflicting versions are
retained without selecting an authoritative record. Hashes are not published.

## Returned Markdown

The return value equals the saved `risk_metrics_analysis.md`.

| Section | Contents and display limits |
| --- | --- |
| Metric movements | Segment summaries of percentage movements, baseline mean/deviation, maximum absolute z-score and flag counts; at most 15 rows. |
| Metric value outliers | Dated flagged values with units, signed value z-scores and source references; at most 15 rows. |
| Days with movement and value outliers | Every exact observation with both flags: date, metric/perimeter, units, value, movement, both signed scores and reference. No 15-row cap; multiple matching metrics on one date remain separate. |
| Excess governance | Selected events identified by `excessId`, metric/perimeter, recorded-open state, calendar age and explanation/validation lags; at most 15 rows. No `source_locator` or `reperformed_usage` display columns. |
| Data quality | Counts by disclosure type; at most 15 rows. Full affected-record detail is in Excel. |
| Notes | Concise interpretation and evidence notes. |
| Commentary supplied for agent review | Complete literal source-text blocks for supplied documents, without table limits. |
| Saved reports | Actual Markdown and Excel artifact links. |

Truncated tables identify how many rows are displayed. Markdown abbreviates
cells beyond 350 characters; full text remains in Excel. Empty result tables
must be read alongside availability, not treated as proof that an unavailable
check found no exceptions. Markdown omits Executive observations, Scope and
availability, Prioritized follow-up, Limit consumption and visualizations.

Commentary can have arbitrary Markdown. File validation checks existence,
extension and decoding, normalizing line endings without changing source bytes.
The tool does not extract records, count, deduplicate, score, validate or
automatically match commentary. There is no commentary worksheet.

## Excel and standalone charts

Each run saves `risk_metrics_analysis.xlsx` alongside the Markdown under
`ANALYSIS_RESULTS_DIR/risk_metrics/<unique-run-id>/`. A relative output setting
resolves against `APP_ROOT`; concurrent runs have separate directories.

| Worksheet | Complete evidence |
| --- | --- |
| Summary | Source populations, scored observation counts and outlier counts. |
| Series Review | All-period/quarter coverage and separate movement/value segment statistics, with full series definitions. |
| Value Outliers | Every value-outlier observation, both statistical baselines, flags and source/predecessor references. |
| Movement and Value Outliers | Every joint-outlier observation in date order, with both signed scores and baselines. |
| Excess Review | All selected events, workflow measures, within-Colibris usage checks and raw source fields. |
| Review Candidates | Full independent statistical, source-consistency and workflow checks, qualifications and corroboration actions. Review order is not policy severity. |
| Data Quality | Individual parsing, duplicate, conflict and unavailable-statistics disclosures. |
| SGMR Detail | Every retained observation, raw fields, signed movement/value scores, populations, baselines, predecessor, flags and unavailable statuses. |
| Sources and Methods | Source inventory, per-check availability and calculation/interpretation methods. |

Excel preserves source text as literal cells. Text beyond 32,000 characters
uses continuation rows, with numeric measures only on the first part.

Standalone risk-value PNGs, `charts/index.md` and `charts/manifest.json` remain in
the same run directory. The manifest retains full series identities, references
and linked review checks. Every chart uses all valid dates supplied across SGMR;
dates outside its own series' observations remain gaps. Manifest date bounds
describe the displayed calendar, not the series' coverage. Main Markdown
contains no chart previews or links.
Copy the full run directory to preserve the separate chart index's relative links.
