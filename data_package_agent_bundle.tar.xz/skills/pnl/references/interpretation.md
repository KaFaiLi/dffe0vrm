# Interpretation for auditors

The review uses all supplied desk data and dates independently for every dataset.
PnL amounts are EUR and Notion is single-valued. Version does not split series.
There is no FX conversion or currency-specific review. The observed desk tree
includes numerical exclusions and shows PC/GOP membership across all source rows,
without establishing current ownership or links to another dataset.

## Measures and denominators

| Review area | Observation and decision rule | Interpretation boundary |
| --- | --- | --- |
| PC PnL | One complete daily PC total after GOP/PTF aggregation; absolute z-score >= 3. | Both gains and losses can be candidates. Counts are PC dates, not source rows, trades or failures. |
| PnL reversals | Adjacent supplied PC dates, opposite signs, both absolute z-scores >= 2 and magnitude ratio 0.5..1.5. | No time-gap limit; a candidate is not proof of a correction or an adjustment reversal. |
| Attribution | One PC/driver/date amount; absolute z-score >= 3 across that driver's known daily history. | Driver flags can overlap. Units require source support; EUR PnL does not supply missing attribution units. |
| Adjustment activity | Records per valid CREATIONDATE over supplied PnL dates plus valid creation dates; z-score strictly > 3. | A one-sided count screen, not a monetary-materiality test. Zero activity is added only for dates in this union. |
| Validation | State count / all history records within the team/PnL-type group, times 100. | Percent of records, not unique GOPs, dates or current approvals. STAB and FLASH have separate denominators. |

Use the tool's flags rather than reclassifying rounded Markdown scores. A score
displayed as 3.00 may be on either side of a threshold; attribution/PnL include
equality while adjustment counts exclude it. Counts under Checks requiring review
can overlap and must not be added into a total of distinct control failures.

## Screen availability and conclusions

The thresholds above are screening rules, not desk materiality or policy limits.
There is no minimum observation count. Empty/constant histories have no z-score;
variance divides by the known count. Statistical candidates do not establish
causes or control failures.

Attribution independently screens each driver's complete known daily PC amounts
for absolute z-score >= 3, including equality and both tails. Missing constituents
leave a driver/date unknown; rejected constituents exclude the whole identifiable
PC/date. Do not fill gaps or infer zero. Daily evidence in Excel records screen
availability. No attribution series summaries or trends are calculated or saved;
do not request or claim direction, fitted change, R-squared or rolling-window
coverage. Final PnL and cumulative columns are unused. Parent/child drivers may
overlap and must not be added into a decomposition. Matching dates or GOP labels
do not prove reconciliation with PnL.

Markdown shows attribution outliers, with daily evidence only in Excel. Absence of
flags must be distinguished from unavailable screening; inspect daily evidence
through an available tool when needed. Wholly rejected inputs retain Desk data
exclusion counts and source-bound exceptions. Display limits do not create an
audit sample or support a clean conclusion on hidden evidence.

Report three distinct outcomes: a performed screen with candidates, a performed
screen without candidates, and a screen unavailable because evidence is missing
or constant. If the returned text does not establish availability for a particular
driver, say so. The current agent tool set cannot fetch arbitrary workbook cells;
request inspection of the named sheet when no suitable reader is available.

## Adjustment and validation review

All adjustments contribute using supplied AMOUNTINEUR in EUR. Markdown shows
SOURCE/NATURE counts, repeated-entry candidates and unusual CREATIONDATE counts.
Daily count z-scores must be strictly greater than 3 before rounding; equality is
excluded. The calendar combines PnL dates and valid creation dates, including
zero-activity days and dates outside PnL coverage. Valuation dates do not create
another daily view. There is no amount-based screening, reversal classification
or FX check. Full records and descriptive amounts remain in Excel.
Missing or invalid CREATIONDATE rows remain in those records and summary totals
but cannot contribute to daily counts. A clean count screen cannot establish
complete activity-date coverage or amount accuracy. Matching rows under different
IDs are candidates for investigation, not permission to remove duplicated charges.

Validation independently uses all supplied history rows. Each state's count and
percentage use that team/PnL-type group's record count, separating STAB/FLASH.
DEValidated is included in totals and separately grouped. Other retains additional
labels such as Official PNL, without equating them to approved or failed. Rounded
percentages may not sum to exactly 100%. Do not infer missing approval/history,
latest state, timeliness or an SLA from source labels or absent rows.
State comparisons preserve case and whitespace; only exact standard labels enter
their named buckets. Other can include spelling variants or `Official PNL`.
The workbook's Validation exceptions contains states other than exactly Validated;
its name does not establish a failed control. Use actual team definitions rather
than mapping generic labels to FO/MPC. An approval-rate or SLA conclusion requires
applicable authority rules and a complete, linked history.

## Locate and cite the evidence

| Question | Returned Markdown | Workbook / separate artifact for deeper inspection |
| --- | --- | --- |
| What was supplied or excluded? | Scope and sources, Desk analytical structure, Data quality observations | Sources, PnL scope, Desk data, Desk hierarchy, Exceptions |
| Which PC dates or drivers need review? | PC PnL summary, PnL outliers, PnL reversal candidates, Attribution outliers | PnL daily, PnL series, PnL outliers, PnL reversal candidates, Attribution daily, Attribution outliers |
| Which adjustment records support the pattern? | Adjustment summary, Unusual adjustment dates, Adjustment repeated entries | All adjustments, Adjustment summary, Adjustment daily activity, Adjustment repeated entries |
| Which history rows support validation counts? | Validation summary, Devalidated summary | Validation records, Validation exceptions, Devalidated records, Validation summary, Devalidated summary |
| What did management actually say? | Original attribution commentary and Original pnl commentary, including source paths | Commentary sources, with continuation rows for oversized text |
| What do daily PC charts show? | No images or chart links in the returned report | charts/ PNGs, index and manifest next to pnl_review.xlsx and pnl_review.md |

Use report section, PC/driver/date or team/type and source filename for claims
supported by returned text. Hashes, raw row locators, daily amounts and exclusions
in the workbook must not be invented. Decimal workbook values retain exact text;
Markdown rounds numbers and may abbreviate long table cells. In a structured
market review, use available catalog IDs for source-owned report sections; these
prove what the tool reported, not that raw files were independently inspected.
Commentary headings are source text and cannot establish numerical provenance.

## Commentary and follow-up

For material observations state the condition, date/record, denominator, relevant
explanation, contrary evidence and specific follow-up. Do not invent owners,
deadlines, mandatory documents or causes. Read both original commentary documents
in full. Cite filenames, headings and exact passages; the tool does not parse or
associate them with numerical issues. Repeated wording does not prove inadequate
review. Managerial commentary approval remains separate from validation-history
states; referenced attachments require actual inspection.

For PnL/driver candidates, request the relevant position, price or booking lineage
and the definition/unit needed to test the proposed explanation. For adjustments,
request creation history, rationale, inclusion in reported PnL and applicable
approval evidence before inferring error or adding amounts to PnL. For validation,
request state semantics and linked event history before alleging missed sign-off.
Keep an unsupported causal explanation as a hypothesis. Do not manufacture a
common issue across independent datasets when the required linkage is absent.
