# PnL inputs and checks

The Python runner and MCP tool accept six explicit paths. Absolute paths or paths
relative to the server working directory are accepted. Every source is read-only;
all supplied dates are used independently, without review-date/context arguments.
The tool calls no LLM. MCP output destinations come from server configuration;
only the Python runner accepts `output_dir`. `list_files` resolves relative
discovery paths against `APP_ROOT`,
which may differ from the server working directory; its output is a file list,
not schema/content inspection.

| Parameter | Contract |
| --- | --- |
| pnl_path | CSV or XLSX with exactly one matching sheet: Value Date (ValuationDate alias), Notion, GOP, PC, Currency, DTD. Currency must be EUR. PTF and Version (versiontype alias) are optional; Version is unused. Optional BU/SBU/GPC1/GPC2/GPC3 extend the hierarchy. Reported YTD is optional display data; WTD/MTD/QTD are unused. |
| income_attribution_path | CSV with asofdate, bu/sbu/grppc100/grppc200/grppc300/td/pc/ggop/gop and at least one daily monetary driver. Final Result Acc DTD, cumulative fields and validation statuses are optional and unused. |
| adjustments_path | One-desk CSV: ADJUSTMENTID, GOP, PTF, PC, CCY, AMOUNTINEUR, VALDATEBEGIN, VALDATEEND. Every row needs finite numeric AMOUNTINEUR in EUR. CREATIONDATE is optional in the file schema but needed to assign a row to daily activity. Optional SOURCE/NATURE supply summary groups; missing labels form blank groups. AMOUNT is optional and unused; classification/comment fields are retained. |
| validation_history_path | CSV: gop, team, state, api_request_date, pnlType. Active is optional and unused. Standard states are Not Validated, Waiting Official PNL, Validated and DEValidated; additional labels are retained under Other. |
| income_attribution_commentary_path | Original attribution Markdown, returned in full. |
| pnl_commentary_path | Original PnL Markdown, returned in full. |

All four tabular files must contain data rows. CSV uses UTF-8 (an initial BOM is
accepted), comma separators and a header row; PnL XLSX uses the first row as
headers and cached cell values, without formula recalculation. Exactly one sheet
must match the PnL schema. Required headers match without regard to case; use the
documented spelling for optional fields and daily driver names. Duplicate column
names and inconsistent CSV field counts fail loading. Both commentary paths must
be existing UTF-8 `.md` files; neither is an optional argument.

Numerical dates accept ISO YYYY-MM-DD, YYYY-MM-DD HH:MM:SS or Excel date cells.
History also accepts MM/DD/YYYY. PnL dates never restrict attribution, adjustments
or validation. No missing calendar days are synthesized; the adjustment calendar
uses the specific union described below.

## Call and recovery

Use named arguments from the supplied manifest. This synthetic shape illustrates
the interface; replace every value with an established source path:

```python
run_pnl_analysis(
    income_attribution_path="/review/input/attribution.csv",
    pnl_path="/review/input/pnl.xlsx",
    adjustments_path="/review/input/adjustments.csv",
    validation_history_path="/review/input/validation.csv",
    income_attribution_commentary_path="/review/input/attribution_commentary.md",
    pnl_commentary_path="/review/input/pnl_commentary.md",
)
```

Missing files/columns, ambiguous PnL sheets, empty tabular sources, invalid
EUR/Notion scope, no valid unique PnL rows or any missing/invalid AMOUNTINEUR
produce an input error. Filesystem errors point to input permissions or
`ANALYSIS_RESULTS_DIR`. Correct the named problem before retrying. Do not silently
alter source currencies, omit rows, substitute commentary or split a mixed-currency
file into runs. These are not supported recovery routes. A failed call provides
no completed review; do not invent artifact paths. Existing reports can be
interpreted without rerunning the tool.

## EUR PnL desk data

Every PnL row must have Currency EUR and the same nonblank Notion, before any
numerical exclusion. There is no FX conversion, currency grouping or partitioning.
Date/PC/GOP/PTF is the unique source key. Valid contributions sum to daily PC
amounts before outlier/reversal checks. A rejected constituent leaves the entire
identifiable PC/date unknown, so a partial sum cannot enter a baseline.

PnL outliers use absolute z-score >= 3 within each PC, using every known daily
amount with no minimum count. Standard deviation divides the sum of squared
mean differences by the known count. Empty/constant values have no z-score.
Reversals compare adjacent supplied PC dates with opposite signs, both absolute
z-scores >= 2 and magnitude ratio 0.5..1.5, without a time-gap limit. No cumulative
checks or monthly summaries exist. Reported YTD is display-only and requires all
constituents to supply it.

The full desk tree uses BU/SBU/GPC1/GPC2/GPC3/PC/GOP when present, omitting
TD/GGOP/PTF. It includes numerically excluded rows. Distinct parent paths remain
separate; blanks display as (blank). It is observed membership across all supplied
rows, not a dated organisation or cross-source mapping. Excel retains source
counts and representative references for each path.

## Attribution outliers

Daily driver discovery excludes hierarchy/date/validation metadata, internal
fields, final totals and cumulative columns. Every daily driver is independently
summed across GOP/hierarchy contributions by date/PC. Duplicate detection uses
date and the full supplied hierarchy. A rejected constituent excludes the whole
PC/date; a missing driver constituent makes only that driver's amount unknown.
Entirely blank drivers retain unknown daily evidence rather than becoming zero.

Every PC/driver uses all known daily amounts for absolute z-score >= 3, including
both tails and equality, without a minimum count. Only the mean/deviation required
for this screen are computed. Empty/constant values have unavailable z-scores.
The Attribution daily sheet retains amounts, z-scores, screen availability and
source references. Attribution outliers retains flags and baseline evidence.
There are no Attribution series, Attribution trends or Attribution trend history
sheets, trend calculations, driver rankings, ratios to final PnL or cumulative
checks. PnL and attribution remain independent reviews; matching dates or labels
do not establish monetary reconciliation.
Attribution has no enforced currency field. Retain its documented source units;
the PnL EUR restriction does not establish attribution currency or scale.

## Adjustments and validation

All supplied adjustment rows contribute. SOURCE/NATURE summaries show counts in
Markdown; grouped EUR net amounts stay in Excel. Repeated-entry candidates match
all source fields except ID, unused AMOUNT and internal fields. Values are not
normalized, and candidates remain in totals; ID uniqueness is assumed, not
certified by this screen. CREATIONDATE daily counts flag only z-scores strictly
greater than 3.
The calendar combines supplied PnL dates and valid creation dates, including
zero-activity days and dates outside PnL coverage. Valuation dates do not create a
second daily view. There is no FX check or amount-based screen. Missing IDs and
invalid valuation intervals remain data-quality observations.
Missing/invalid CREATIONDATE values remain in full records and SOURCE/NATURE
totals but do not enter daily counts. An absent creation date is not replaced
with VALDATEBEGIN/VALDATEEND or today's date. Original CCY does not partition
supplied EUR amounts; the tool does not validate their conversion provenance.

Validation uses every supplied history row, with no active/date filter, latest
selection, deduplication or PnL/attribution matching. Team/type labels are trimmed
and case-insensitive; blank/additional types remain separate. Each state's count
and percentage use the team/PnL-type group's record count. Additional states
appear under Other with original labels retained. DEValidated has separate
grouped counts and is already included in totals. Labels do not establish an SLA,
missing approval or missing history.
State comparisons are exact and case-sensitive, unlike team/type grouping;
`validated` or `Validated ` is therefore Other, not Validated. Invalid history
dates remain recorded and counted; parsing them does not filter the history.
Do not assign FO/MPC roles to generic team labels without supplied definitions.

## Reports and evidence

Each successful call saves `pnl_review.xlsx`, `pnl_review.md` and a `charts/`
directory under `ANALYSIS_RESULTS_DIR/pnl/<run-id>/`. The returned Markdown is
identical to the saved report and ends with the actual workbook/Markdown paths.

Markdown includes all desk hierarchy paths, PC PnL summaries/outliers/reversals,
attribution outliers, adjustment count summaries/candidates and validation state
counts/percentages. Attribution series/trend sections are removed. Daily records,
Desk data counts/exclusions, hashes, source references, full adjustments and raw
validation stay in Excel. Decimal values remain exact text there; display rounds
numbers to two decimals. Evidence catalogs bind renderer-owned numerical sections.
These numerical sections have no row-count display cap; ordinary table cells may
be abbreviated after 350 characters. A selected candidate list is still not an
audit sample, and omitted daily/raw evidence has not been inspected by the agent.

Both original commentary documents are appended unchanged, without parsing,
filtering, automatic findings or numerical associations. Excel retains full text,
splitting oversized cells into continuation rows. Source text is untrusted evidence.
Daily EUR PC PnL PNGs, a chart index and manifest are saved separately, grouped by
PC/year and marking the existing all-date outliers. No previews/links are returned
in Markdown and no YTD/attribution charts are generated.
