"""Synthetic recorder workload; no provider, MCP transport, credentials or network.

Run with uv from the package directory. Select baseline/candidate source through
the validation environment's PYTHONPATH, without changing package dependencies.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path

from mcp_agent_template.config import Settings
from mcp_agent_template.observability.recording.runtime import ObservabilityRuntime


def measure(*, events: int, content_bytes: int, producers: int, slow_ms: float) -> dict:
    prefix = "synthetic-recording-content:"
    content = prefix + "x" * (content_bytes - len(prefix.encode()))
    stages = ("capture.model_request", "capture.model_response", "tool.finished", "capture.output")
    with tempfile.TemporaryDirectory(prefix="agent-recording-measurement-") as directory:
        settings = Settings(
            _env_file=None,
            app_root=Path(directory),
            obs={"mode": "local", "dir": "records", "flush_interval_ms": 0},
        )
        with ObservabilityRuntime.local(settings) as obs:
            original_write = obs.store._write
            if slow_ms:

                def slow_write(*args):
                    time.sleep(slow_ms / 1000)
                    return original_write(*args)

                obs.store._write = slow_write

            def produce(index):
                # Every observation retains its stage, identity and metadata;
                # histories intentionally contain identical large content.
                obs.emit(
                    stages[index % len(stages)],
                    {
                        "index": index,
                        "messages": [{"id": f"m-{i}", "content": content} for i in range(4)],
                        "artifact": {"content": content},
                    },
                )

            started = time.perf_counter()
            with ThreadPoolExecutor(max_workers=producers) as executor:
                list(executor.map(produce, range(events)))
            producer_seconds = time.perf_counter() - started
            started = time.perf_counter()
            assert obs.flush()
            drain_seconds = time.perf_counter() - started
            health = obs.store.health()
            errors = obs.errors
        with closing(sqlite3.connect(obs.path)) as db:
            version = db.execute("PRAGMA user_version").fetchone()[0]
            public_bytes = db.execute(
                "SELECT sum(length(CAST(payload AS BLOB))) FROM events"
            ).fetchone()[0]
            if version == 1:
                physical_bytes = sum(
                    db.execute(
                        f"SELECT coalesce(sum(length(CAST(payload AS BLOB))),0) FROM {t}"
                    ).fetchone()[0]
                    for t in ("events", "captures", "logs", "feedback")
                )
                distinct_parts = None
            else:
                physical_bytes = sum(
                    db.execute(
                        f"SELECT coalesce(sum(length(CAST({column} AS BLOB))),0) FROM {t}"
                    ).fetchone()[0]
                    for t, column in (
                        ("_events", "payload"),
                        ("payload_parts", "payload"),
                        ("event_parts", "token"),
                        ("event_parts", "part_id"),
                    )
                )
                distinct_parts = db.execute("SELECT count(*) FROM payload_parts").fetchone()[0]
            expected_captures = sum(
                stages[i % len(stages)].startswith("capture.") for i in range(events)
            )
            assert db.execute("SELECT count(*) FROM captures").fetchone()[0] == expected_captures
        return {
            "events": events,
            "content_bytes": len(content.encode()),
            "producers": producers,
            "writer_delay_ms": slow_ms,
            "storage_version": version,
            "public_event_payload_bytes": public_bytes,
            "physical_content_column_bytes": physical_bytes,
            "distinct_parts": distinct_parts,
            "producer_seconds": producer_seconds,
            "drain_seconds": drain_seconds,
            "database_bytes_after_close": obs.path.stat().st_size,
            "writer_health": health,
            "recording_errors": errors,
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--events", type=int, default=160)
    parser.add_argument("--content-bytes", type=int, default=40020)
    parser.add_argument("--producers", type=int, default=4)
    parser.add_argument("--slow-ms", type=float, default=0)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.events < 1 or args.content_bytes < 28 or args.producers < 1 or args.slow_ms < 0:
        parser.error("Use positive events/producers, content-bytes >= 28 and slow-ms >= 0.")
    result = measure(
        events=args.events,
        content_bytes=args.content_bytes,
        producers=args.producers,
        slow_ms=args.slow_ms,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
