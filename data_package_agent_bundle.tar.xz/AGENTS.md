# Data Package Agent Guidance

## Scope and Ownership

This Python 3.12+ package provides FastMCP tools, deterministic data analysis,
and native LangChain/LangGraph agents. Its distribution is `mcp-agent-template`
and its Python import is `mcp_agent_template`; preserve these public names.
The suite-root [AGENTS.md](../../AGENTS.md) also applies.

This directory is an independent uv project within the single `private_suite`
Git repository. Keep its environment, package metadata, build outputs and tests
separate from the suite-root manager/wrapper environment. There is currently no
package `uv.lock`; do not claim locked corporate resolution until it succeeds.
Do not create a nested repository or add this package to the root environment,
shared pytest collection, portable corporate test bundle or existing
manager/wrapper distribution verifiers.

## Required Agent LLM Path

- Use the real `socgenai_llm.GenAIChatModel` for agent LLM execution, constructed
  through `llm/genai_manager.py` and its `get_chat_model` factory.
- Select the Responses API (`genai_use_responses_api=True`) and request exposed
  reasoning summaries with `reasoning.summary="detailed"`.
- For authorized local summary tests, use `reasoning.effort="max"`, a fixed
  synthetic task, bounded time, zero retries and no automatic replay. Reasoning
  tokens do not guarantee exposed summary text; never invent a summary.
- Omit sampling parameters for reasoning-enabled calls. Route extra request
  options through the wrapper's `model_kwargs`; undeclared constructor keywords
  are ignored by the wrapper. The factory separates constructor fields from
  request options and preserves explicit caller options.
- Omit `max_tokens`, `max_completion_tokens` and `max_output_tokens` by default,
  including in examples, live probes and compaction summaries. Preserve explicit
  caller limits and their tests. Input budgets, request/tool limits, deadlines
  and spending controls are separate policies.
- Keep the `genai_manager` adapter without a runtime fallback. Its dedicated
  compatibility tests were removed at the user's request; normal agent tests use
  the shared wrapper. Synthetic models and injected tools remain appropriate for
  offline tests. See the [legacy-test review](docs/review/legacy-test-review-2026-10-26.md).
  A later explicit user instruction can select another mode.

## Project Structure and Module Organization

Paths below are relative to this package unless marked otherwise.

- `src/mcp_agent_template/agent/`: public `build_agent` and `build_agent_tree`
  builders, `AgentSpec`, `AgentBundle`, prompt assembly and CLI. Both builders
  share graph/middleware composition in `factory.py`.
- `src/mcp_agent_template/agent/runtime/`: invocation ownership, shared budgets,
  tool scheduling, native todo tracking and opt-in history compaction.
- `src/mcp_agent_template/llm/`: shared provider factory and compatibility adapter.
- `src/mcp_agent_template/mcp_server/`: stdio/HTTP server and MCP tool adapters.
  Register tool groups in `server.py`; keep analysis logic in `analysis/`.
- `src/mcp_agent_template/analysis/`: post-trade analysis in `fox/`, PnL analysis
  in `pnl/`, risk analysis in `risk_metrics/`, and shared chart utilities.
- `src/mcp_agent_template/skills/`: application skill discovery and the
  `list_skills`, `load_skill` and `read_skill_file` agent tools.
- `src/mcp_agent_template/observability/`: settings/privacy, capture middleware
  and callbacks, SQLite recording, OpenTelemetry integration and inspection CLI.
- `src/mcp_agent_template/config.py`: typed runtime settings and path resolution;
  `notebook.py`: notebook execution, tool catalog and trace helpers.
- `skills/`: application instructions and references for `pnl`,
  `post-trade-control`, `risk-metrics` and `market-activity-review`.
- `notebooks/market_activity_review.ipynb` and `notebooks/review_reporting.py`:
  checkout-only cross-source review workflow and validated JSON/Markdown reports.
- `dashboard/`: standalone stdlib read-only SQLite viewer and `dashboard/tests/`.
- `tests/`: corporate-usable synthetic unit, analysis and MCP integration tests;
  `scripts/`: recording-benchmark utilities; `docs/`: package guides,
  research, plans and dated validation evidence.
- `../../devtools/foundry_lab/` and
  `../../devtools/tests/foundry/data_package_agent/`: suite-owned local probes and
  their separate regressions. Never import these from package tests or production code.

## Current Runtime and Tool Contracts

- Prefer `AgentBundle.ask`, `ainvoke` and `astream` for execution. `ask` returns
  text; `ainvoke` returns native state. Each root invocation owns a fresh,
  single-use `RunContext`. Raw graph calls require an explicit fresh context;
  close streams explicitly when stopping early.
- Child agents share root model/tool budgets and the root deadline, with separate
  node scheduling and compaction state. Failed/cancelled reservations are not
  refunded. Preserve these limits when changing delegation or middleware.
- Parallel tool calling is enabled; the former `allow_parallel_tool_calls`
  setting and general sequential-policy keywords have been removed.
  Runtime tool capacity and explicit child concurrency
  still constrain execution. Model-emitted parallel calls alone do not prove overlap.
- Native `write_todos` is an agent middleware tool, independent for each
  invocation. History compaction is disabled unless an input budget is supplied.
  Compaction changes outgoing model inputs, preserves native history and protected
  instructions, and charges summary calls to the shared model-call budget.
  See [prompts and todos](docs/agent-prompts.md) and
  [context compaction](docs/context-compaction.md).

The application MCP server currently registers four tools:

- `list_files(folder_path=".", recursive=False)`: discovers files within
  `APP_ROOT` without reading contents. Results are sorted project-relative paths;
  traversal excludes symlink/junction entries and rejects paths outside the root.
  Preserve containment checks without claiming an OS filesystem sandbox.
- `run_post_trade_review(folder_path)`: selects exactly one Parquet file matching
  the post-trade schema and returns Markdown, saving Excel/Markdown under
  `ANALYSIS_RESULTS_DIR/fox/<run-id>/`.
- `run_pnl_analysis(...)`: accepts six explicit source paths and uses all supplied
  dates independently; no review-date arguments are accepted. It saves complete
  workbook evidence, Markdown and standalone daily PC PnL PNGs under
  `ANALYSIS_RESULTS_DIR/pnl/<run-id>/`; chart previews are omitted from the returned Markdown.
- `run_risk_metrics_analysis(sgmr_path, ...)`: accepts required SGMR Parquet and
  optional Colibris CSV/three commentary Markdown sources. It saves Markdown,
  complete Excel evidence and charts under `ANALYSIS_RESULTS_DIR/risk_metrics/<run-id>/`.

Analysis tools accept absolute source paths or paths relative to the MCP server's
working directory; `list_files` resolves relative paths against `APP_ROOT`.
Do not describe the analysis tools as confined to `APP_ROOT`. Analysis is
deterministic and does not call an LLM or modify source files. Preserve documented
grouping, units, source populations, missing-source handling and evidence limits;
statistical review candidates do not establish control failures. Read the relevant
[PnL](docs/pnl-analysis.md), [skills and post-trade](docs/skills.md),
[risk methodology](skills/risk-metrics/references/methodology.md) and
[visualization](docs/analysis-visualizations.md) contracts before changing analysis.

Skills load from the selected application folder (`APP_ROOT/skills` by default),
without a packaged fallback; empty/missing folders remain empty. Deploy application
skills separately from the wheel. Preserve inventory and containment checks when
reading references. Source checkouts default `APP_ROOT` to this package directory;
installed wheels default to the working directory. The market-review notebook
keeps provider execution disabled by default; see its
[workflow and report contract](docs/market-activity-review.md).

Local SQLite recording defaults to enabled (`OBS_MODE=local`), with credential
redaction and complete payload capture. It is plaintext storage and can still
contain sensitive business content. Keep it separate from the manager's encrypted
audit contract. `OBS_MODE=off` disables it. Preserve recorder ownership, shutdown,
cancellation and current-schema reads; inspect
[observability](docs/observability.md) and [dashboard](dashboard/README.md) before
changing recording. Graph construction/import alone must not start a recorder.

## Coding Style, Docstrings and Comments

- Use four-space indentation, type annotations and a 100-character line limit.
  Follow the configured Ruff Python 3.12 rules (`E`, `F`, `I`, `UP`, `B`). Use
  `snake_case` for modules/functions, `PascalCase` for classes and
  `UPPER_SNAKE_CASE` for constants. Keep responsibilities in the modules above.
- **Required for new or changed code:** add or update descriptive module and
  class docstrings and function/method docstrings, including private helpers.
  Public interfaces and nontrivial implementations need detailed contracts;
  a concise purpose statement is sufficient only for self-evident helpers.
- Follow the existing Google-style `Args`, `Returns`/`Yields` and `Raises`
  sections where applicable. Explain parameter meaning and constraints, defaults,
  return structure, missing/empty values, expected failures and side effects.
  Include units, path bases, mutation, resource ownership, async/cancellation or
  thread-safety rules when relevant; do not merely repeat the type annotations.
- Treat MCP tool docstrings and parameter descriptions as the model-facing API.
  Document accepted source formats, required/optional inputs, date/scope rules,
  generated artifacts, output locations, source preservation and interpretation
  limits. Keep descriptions synchronized with schemas and actual behavior.
- Add implementation comments for non-obvious decisions and invariants: why an
  aggregation uses a particular population, how missing data is treated, why
  middleware ordering matters, or how budgets, cancellation, path containment
  and compatibility workarounds are preserved. Put comments beside the relevant
  logic and explain the reason, not each obvious statement.
- For analysis calculations, document grouping keys, population/date filters,
  units/currencies, formulas or statistical assumptions, exclusions and limits
  on interpretation. Cite a maintained contract/reference when one exists.
- Update docstrings and comments in the same change as the behavior they explain.
  Use synthetic examples, never credentials or real business records. Review
  documentation accuracy as part of completion: current Ruff checks do not
  enforce docstring coverage or quality. Improve documentation in the code being
  changed without adding unrelated repository-wide rewrites.

## Build, Test, and Development Commands

Run package commands from `packages/data-package-agent/`. Preserve the configured
corporate index, internal provider references and dependency pins. The intended
corporate workflow is:

```text
uv sync --extra dev --extra socgenai-llm
uv run pytest tests dashboard/tests -q
uv run ruff check .
uv run ruff format --check .
uv build
```

`uv run pytest` selects `tests/` only; include `dashboard/tests` explicitly.
`uv run pytest tests/test_mcp_server.py` exercises real stdio server wiring.
`uv run mcp-agent-server` starts the MCP server, using stdio by default;
`uv run mcp-agent-chat "List your tools"` invokes the configured provider and
requires authorized live access. `uv run --no-sync python dashboard/server.py`
starts the read-only localhost viewer on port 8765. It can also run with Python
3.12+ alone, without installing the agent's third-party dependencies.

The agent requires `langchain-core>=1.6.10`, while the sibling wrapper pins
`langchain-core==1.6.6`. Corporate dependency resolution remains unverified;
the local override below is not a production fix. Preserve package configuration
unless the user requests a change. When corporate resolution succeeds, maintain
the package lockfile and use locked commands for reproducible validation.

### Isolated local development environment

Use the checked-in local uv template to load all three sibling packages editable
in a separate Python 3.12+ environment. It pins `openai==3.24.0`, overrides only
the local `langchain-core` to 1.6.10 and resolves public dependencies. Keep the
generated environment and lockfile under ignored artifacts:

```powershell
New-Item -ItemType Directory -Path ../../artifacts/foundry-agent -Force | Out-Null
Copy-Item -LiteralPath ../../devtools/foundry_lab/agent_environment.toml `
    -Destination ../../artifacts/foundry-agent/pyproject.toml
uv sync --project ../../artifacts/foundry-agent --python 3.12
$agentUv = @('run', '--project', '../../artifacts/foundry-agent', '--locked', '--python', '3.12')
```

This does not create a corporate agent lockfile or alter package dependency pins.
Record actual runtime versions for live evidence; versions and test counts in
older validation reports are snapshots, not current guarantees.

For non-billable regression checks in that environment:

```powershell
uv @agentUv python -m pytest -c pyproject.toml tests dashboard/tests -q `
    --allow-hosts=127.0.0.1,::1 --allow-unix-socket
uv @agentUv python -m pytest `
    -c ../../devtools/tests/foundry/data_package_agent/pytest.ini `
    ../../devtools/tests/foundry/data_package_agent -q
uv @agentUv ruff check .
uv @agentUv ruff format --check .
```

The template includes `pytest-socket`. The host allowlist blocks non-loopback
connections in the pytest process while permitting Windows asyncio's loopback
socket pair and dashboard HTTP tests; it is not a network sandbox for subprocesses.
Do not substitute `--disable-socket`, which prevents that Windows event loop from
starting. This package has its own pytest configuration and does not implement
the manager/wrapper's `--offline` profile. Keep collection separate from root.

## Authorized Local Live Test

Run billable local checks only when the user authorizes them. From this package
directory, use the isolated `$agentUv` setup above and the suite's opt-in runner:

```powershell
uv @agentUv python ../../devtools/foundry_lab/run.py `
    --operation data-package-agent `
    --config ../genai-api-manager/local_dev.json `
    --pricing ../../MODELS_PRICE1K_AZURE.json `
    --model gpt-6-luna --run-live
```

The ignored credential JSON accepts `foundry_api_key` and `foundry_endpoint`
(`foundry_enpoint` is also accepted). Use `--config` for another file with that
schema; do not copy credentials into tracked files or print credentials, endpoint
URLs, raw provider errors or encrypted-log keys. Validate the deployment against
the local pricing JSON before dispatch; never switch model/provider/API on failure.

The default `add` case requires one `add(19, 23)` call and answer `42`.
`--agent-case parallel` requires two actual overlapping additions and answer
`42,18`. These cases permit two model calls, one/two tool calls respectively,
45 seconds per SDK request, a 120-second root deadline and 150-second outer
timeout, with zero SDK retries. The runner uses the real sibling wrapper,
manager, Azure v1 Responses transport, accounting and encrypted audit writer,
substituting local authentication only. The ordinary add/parallel probe disables
the separate SQLite recorder and external tracing.

Other supported `--agent-case` values are `workflow`, `post-trade-control`, `pnl`,
`risk-metrics` and `market-review`. Their request/tool/time bounds differ; inspect
the selected runner and relevant guide before dispatch. The add, parallel,
dashboard and workflow checks use `devtools.foundry_lab.agent_server`, which adds
a synthetic `add` tool to the application server. Domain review probes use the
application server directly; never ship the development fixture.

`--operation data-package-agent-dashboard` enables local SQLite recording and
redacted provider HTTP JSON capture for its fixed synthetic Sudoku/addition task.
`--agent-transport native` explicitly selects non-streaming Responses;
`internal-stream` is the normal agent probe transport. Do not replay a failure
through the alternative. All agent probes use max/detailed reasoning and omit
output-token limits and sampling parameters. Treat local plaintext recordings as
sensitive even after credential redaction.

Safe summaries and sensitive audit/recording artifacts live under ignored
`../../devtools/foundry_lab/output/<run-id>/`. Report actual usage and calculated
cost, distinct from provider billing proof. Local success does not establish
corporate identity, proxy, shared-drive, route or dependency acceptance.
Historical evidence is documented in the
[Responses/workflow validation](docs/review/live-agent-workflow-and-dashboard-validation-2026-10-14.md),
[dashboard checks](docs/review/dashboard-thinking-and-requests-validation-2026-10-14.md),
[parallel prompt evidence](docs/review/agent-parallel-validation-2026-10-14.md),
[PnL validation](docs/review/pnl-validation-2026-10-17.md),
[risk validation](docs/review/risk-metrics-demo-validation-2026-10-17.md) and
[market-review guide](docs/market-activity-review.md). Preserve their dates and
limitations; historical output-token limits are not current defaults, and old
Chat-only runs do not verify Responses or today's code.

## Testing and Completion

- Keep package `tests/` corporate-usable and independent of `devtools`, local
  Foundry settings, credentials and runners. Foundry tests, including mocked
  probes, belong under `../../devtools/tests/foundry/data_package_agent/` and run
  with their own `pytest.ini` in the isolated environment.
- Use pytest and pytest-asyncio (`asyncio_mode="auto"`). Name tests
  `test_<behavior>` in `test_*.py`. No numeric coverage threshold is configured.
  Stub provider calls; use synthetic datasets, temporary paths and explicit
  settings to avoid loading local credentials or contacting services.
- MCP integration tests launch the real server without LLM credentials. Keep
  expected tool catalogs and signatures aligned with `server.py` registrations.
  Skill/chart containment tests simulate resolved paths without requiring OS
  symlink privileges; report that boundary accurately.
- Cover changed success/failure behavior through production code: budgets,
  parallel dispatch, cancellations and cleanup for runtime changes; populations,
  units, missing inputs, saved evidence and chart outputs for analysis changes;
  redaction and current-schema read/write behavior for recording changes. Dedicated
  historical migrations and storage-v1 reads were removed on 2026-10-26.
  Cover unsupported-schema rejection and current-store restart behavior. Close owned
  models, streams, subprocesses and recorders.
- Run relevant tests, Ruff lint/format checks, and `git diff --check`. Build wheel
  and source distributions for packaging changes and verify installed public
  imports outside the source tree. Do not add or run tests solely for prose edits.
- Update affected docstrings, comments, user guides, skills and examples together.
  Report checks actually run and remaining limitations, separating synthetic
  tests, local live evidence and corporate acceptance.

## Commit, Pull Request and Configuration Guidelines

Commit in the suite repository with concise imperative subjects for focused
changes. PRs should explain the problem, resulting behavior, related issue and
validation results, including checks not run. Preserve corporate package indexes,
internal dependency references, provider settings and build/test/lint
configuration unless the user explicitly requests changes. Never commit
credentials, sensitive corporate data, recordings or generated local environments.
