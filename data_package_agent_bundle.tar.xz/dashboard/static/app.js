/* Read-only browser projections. Recorded content is always rendered as text. */
const $ = id => document.getElementById(id);
const number = new Intl.NumberFormat();
const params = new URLSearchParams(location.search);
const state = {
  selected: params.get('run') || '', agent: params.get('agent') || '', tab: params.get('tab') || 'conversation',
  global: params.get('global') || '', selection: params.get('selection') || '', window: params.get('window') || '24h', database: null,
  offset: Math.max(0, Number(params.get('offset')) || 0), navPages: [''], eventPage: {after: params.get('after') || '', before: params.get('before') || ''}, page: null,
  category: params.get('category') || '', severity: params.get('severity') || '', search: params.get('q') || '',
  paused: false, follow: false, version: 0, navVersion: 0, inspectorVersion: 0,
  usage: null, transcript: null, detail: null, inspector: 'usage', refreshing: false, refreshPending: false, initialized: false, initialLoadComplete: false,
  requestDetail: null, requestCursor: null, requestView: params.get('requestView') || 'body', requestBodyStage: params.get('bodyStage') || 'provider', requestOwner: null, requestOpenVersion: 0, requestFollow: false,
};
if (!['conversation','thinking','usage','activity','tools','requests','trace','overview'].includes(state.tab)) state.tab = 'conversation';
if (!['body','native','effective','original','response','tools','skills','changes','definition','raw'].includes(state.requestView)) state.requestView='body';
if (!['provider','native','effective','original'].includes(state.requestBodyStage))state.requestBodyStage='provider';
if (!['','events','logs','processes','metrics','feedback'].includes(state.global)) state.global = '';
if (!['1h','24h','7d','all'].includes(state.window)) state.window = '24h';
function node(tag, className = '', text = '') { const el = document.createElement(tag); if (className) el.className = className; if (text !== null && text !== undefined) el.textContent = String(text); return el; }
function button(text, action, className = '') { const b = node('button', className, text); b.type = 'button'; b.addEventListener('click', act(action)); return b; }
function act(fn) { return (...args) => Promise.resolve().then(() => fn(...args)).catch(e => error(e.message)); }
function fmt(value) { return value === null || value === undefined ? 'Unavailable' : number.format(value); }
function duration(value) { if (typeof value !== 'number') return 'Unavailable'; return value < 1 ? `${Math.round(value * 1000)} ms` : value < 60 ? `${value.toFixed(1)} s` : `${(value / 60).toFixed(1)} min`; }
function dateTime(value) { return value == null ? 'Unavailable' : new Date(value * 1000).toLocaleString(); }
function clock(value) { return value == null ? '—' : new Date(value * 1000).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit',fractionalSecondDigits:3}); }
function shortId(value) { return value ? String(value).slice(0,8) : '—'; }
function query(values) { return new URLSearchParams(Object.entries(values).filter(([,v])=>v!=='' && v!==null && v!==undefined)).toString(); }
function owner() { return state.agent || state.selected; }
function runPath(suffix) { return `/api/runs/${encodeURIComponent(owner())}/${suffix}`; }
function kind(category) { return node('span', `category ${category}`, state.database?.categories[category] || category); }
function badge(status) { const safe = /^[a-z_]+$/.test(status || '') ? status : 'unknown'; return node('span', `pill ${safe}`, status || 'unknown'); }
function error(message) { $('error-banner').textContent = message; $('error-banner').classList.remove('hidden'); $('connection').textContent = 'Refresh failed'; }
async function api(path) { const response = await fetch(path,{cache:'no-store'}); const value = await response.json(); if (!response.ok) throw new Error(value.error || `HTTP ${response.status}`); return value; }
function urlState() { const p = query({run:state.selected,agent:state.agent,tab:state.tab,global:state.global,window:state.window,offset:state.offset||'',category:state.category,severity:state.severity,q:state.search,selection:state.selection,db:state.database?.identity,after:state.eventPage.after,before:state.eventPage.before,process:$('process-filter').value,logger:$('logger-filter').value,since:$('event-since').value,until:$('event-until').value,unscoped:$('unscoped').checked?'1':'',runSearch:$('run-search').value,runStatus:$('run-status').value,request:$('request-dialog').open?state.requestCursor:'',requestRun:$('request-dialog').open?state.requestOwner:'',requestView:$('request-dialog').open?state.requestView:'',bodyStage:$('request-dialog').open?state.requestBodyStage:''}); history.replaceState(null,'',`/?${p}`); }
function facts(entries) { const dl = node('dl','facts'); for (const [name,value] of entries) { const row = node('div'); row.append(node('dt','',name),node('dd','',value)); dl.append(row); } return dl; }
function keyed(el,key,value) { el.dataset.key = key; el._signature = JSON.stringify(value); return el; }
function reconcile(holder, children) {
  const old = new Map([...holder.children].map(el=>[el.dataset.key,el]));
  for (const [index,fresh] of children.entries()) {
    let el = old.get(fresh.dataset.key);
    if (!el || el._signature !== fresh._signature) {
      const disclosureState = new Map(el ? [...el.querySelectorAll('details')].filter(d=>d.dataset.key).map(d=>[d.dataset.key,d.open]) : []);
      for (const d of fresh.querySelectorAll('details')) if (disclosureState.has(d.dataset.key)) d.open = disclosureState.get(d.dataset.key);
      el = fresh;
    }
    if (holder.children[index] !== el) holder.insertBefore(el,holder.children[index] || null);
    old.delete(fresh.dataset.key);
  }
  while (holder.children.length > children.length) holder.lastChild.remove();
}
function empty(text, showAll = false) { const el = node('div','empty',text); if (showAll) el.append(button('Show all recorded runs',()=>{$('window').value='all';state.window='all';state.navPages=[''];return loadRuns();})); return el; }
function exportDocument(value, name, jsonl = false) {
  const records = value.records || value.sessions || [value];
  const unique = [...new Map(records.map((r,i)=>[r.event_id || `${r.trace_id||''}:${r.span_id||''}:${r.cursor||i}`,r])).values()];
  const manifest={source:state.database?.path,database_identity:state.database?.identity,selection:name,
    run_id:value.run_id||(!state.global?owner():null),view:state.global||state.tab,navigation:location.search,
    coverage:value.coverage||'stored records',exported_at:new Date().toISOString()};
  const content = jsonl ? [JSON.stringify({manifest}),...unique.map(r=>JSON.stringify(r))].join('\n')+'\n' : JSON.stringify({manifest,...value},null,2)+'\n';
  const link = node('a'); link.href=URL.createObjectURL(new Blob([content],{type:jsonl?'application/x-ndjson':'application/json'}));link.download=`${name.replace(/[^a-z0-9_-]/gi,'_')}.${jsonl?'jsonl':'json'}`;link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
}
function fields(value) {
  const container = node('div','record-fields');
  if (!value || typeof value !== 'object') { container.append(node('pre','message-text',String(value)));return container; }
  for (const [name,content] of Object.entries(value)) {
    if (content === undefined) continue;
    const row=node('div','record-field');row.append(node('strong','',name.replaceAll('_',' ')));
    if (content && typeof content==='object') row.append(disclosure('Expand complete value',content));
    else if (String(content).length>700) row.append(disclosure('Expand complete text',String(content)));
    else row.append(node('p','',content===null?'Unavailable':String(content)));
    container.append(row);
  }
  return container;
}
function showInspector(title, children, mode='record') { state.inspector=mode;document.body.classList.remove('inspector-closed');$('inspector-title').textContent=title;$('inspector-content').replaceChildren(...children); }
function expandInspector() {
  const dialog=$('inspector-dialog');
  if(dialog.open){dialog.close();return;}
  const scroll=$('inspector-content').scrollTop;
  dialog.append($('inspector-panel'));
  $('expand-inspector').textContent='Restore sidebar ↙';
  $('expand-inspector').setAttribute('aria-label','Restore details sidebar');
  document.body.classList.add('inspector-expanded');
  dialog.showModal();
  $('inspector-content').scrollTop=scroll;
}
function restoreInspector() {
  const scroll=$('inspector-content').scrollTop;
  $('inspector').append($('inspector-panel'));
  $('expand-inspector').textContent='Expand ↗';
  $('expand-inspector').setAttribute('aria-label','Expand details');
  document.body.classList.remove('inspector-expanded');
  $('inspector-content').scrollTop=scroll;
  if(!document.body.classList.contains('inspector-closed'))$('expand-inspector').focus({preventScroll:true});
}
function setInspectorWidth(width) {
  const maximum=Math.max(320,Math.min(880,window.innerWidth-660));
  width=Math.round(Math.max(320,Math.min(maximum,width)));
  document.documentElement.style.setProperty('--inspector-width',`${width}px`);
  $('inspector-resize').setAttribute('aria-valuemax',maximum);
  $('inspector-resize').setAttribute('aria-valuenow',width);
}
function inspectRecord(title, record, primary) {
  const actions=node('div','inspector-actions');actions.append(button('Export JSON',()=>exportDocument(record,title)),button('Export JSONL',()=>exportDocument(record,title,true)),button('Copy JSON',()=>navigator.clipboard.writeText(JSON.stringify(record,null,2))));
  const raw=disclosure('Complete stored record',record); raw.dataset.key='complete-record';
  const search=node('input');search.type='search';search.placeholder='Search selected payload';search.setAttribute('aria-label','Search selected payload');
  const match=node('p','dim');search.addEventListener('input',()=>{const needle=search.value.toLowerCase();const text=JSON.stringify(record,null,2);const at=text.toLowerCase().indexOf(needle);match.textContent=!needle?'':at<0?'No match in complete selected payload':text.slice(Math.max(0,at-40),at+needle.length+160);});
  showInspector(title,[actions,fields(primary || record.payload?.data || record),search,match,raw]);
}
async function openEvent(cursor) { const version=++state.inspectorVersion;const record=await api(`/api/events/${cursor}`);if(version!==state.inspectorVersion)return;state.selection=`event:${cursor}`;urlState();inspectRecord(`${record.event_name} · #${cursor}`,record,record.payload?.data); }
async function openMessage(key) { const version=++state.inspectorVersion;const record=await api(`${runPath('conversation')}?${query({item:key})}`);if(version!==state.inspectorVersion)return;inspectRecord('Complete recorded message',record,record.message);if(record.presentation?.thinking_summary){const summary=disclosure('Thinking summary',record.presentation.thinking_summary,true);$('inspector-content').prepend(summary);} }
async function openThinking(call) {
  const version=++state.inspectorVersion;
  const detail=await api(`/api/runs/${encodeURIComponent(call.run_id)}/thinking?${query({id:call.id})}`);
  if(version!==state.inspectorVersion)return;
  const summary=disclosure('Complete thinking summary',detail.thinking_summary||'No summary recorded.',true);
  inspectRecord('Model thinking summary',detail,{model:call.model,outcome:call.status,source:detail.thinking_source});
  $('inspector-content').prepend(summary);
}
async function openTool(id) { const version=++state.inspectorVersion;const record=await api(`${runPath('tools')}?${query({id})}`);if(version!==state.inspectorVersion)return;
  const body=node('div');for(const r of record.records||[])body.append(disclosure(`${r.event_name} · #${r.cursor}`,r.payload?.data,['tool.call.started','tool.finished'].includes(r.event_name)));
  inspectRecord(`${record.name} · ${record.status}`,record,{call_id:record.id,status:record.status,duration:record.duration,attempts:record.attempts,coverage:record.coverage});$('inspector-content').append(body);
}
function showUsage(value = state.usage?.total, title = 'Conversation usage', call = null) {
  ++state.inspectorVersion;
  if(!value)return;
  const box=node('div');box.append(node('div','usage-value',fmt(value.total_tokens)),node('p','dim','known tokens'));
  box.append(facts([['Input',fmt(value.input_tokens)],['Output',fmt(value.output_tokens)],['Native calls',fmt(value.model_calls)],['Usage reported',`${value.calls_with_usage} of ${value.model_calls}`],['Partial / unknown',`${value.partial_calls} / ${value.missing_calls}`]]));
  const children=[box];
  if(call){children.push(fields({model:call.model,purpose:call.purpose||'Unavailable',outcome:call.status,duration:duration(call.duration),first_token:duration(call.first_token),usage:call.usage,round_id:call.round_id,request_id:call.request_id,native_call_id:call.native_id}));if(call.request_cursor)children.push(button('Inspect complete model request',()=>openRequest(call.request_cursor,call.run_id),'text-button'));}
  else children.push(node('p','dim',`${state.usage?.scope||'Selected agent'}. Each native call is counted once; partial amounts are labelled.`));
  if(state.usage)children.push(disclosure(`Summary reconciliation: ${state.usage.reconciliation}`,{recorded_summary:state.usage.recorded_summary,difference:state.usage.summary_difference}));
  children.push(button('View conversation total',()=>showUsage(),'text-button'));
  showInspector(title,children,call?'usage-call':title==='Conversation usage'?'usage':'usage-round');
}
function totalFor(calls) { const result={model_calls:calls.length,calls_with_usage:0,partial_calls:0,missing_calls:0,input_tokens:0,output_tokens:0};for(const c of calls){if(c.usage_coverage==='reported')result.calls_with_usage++;else if(c.usage_coverage==='partial')result.partial_calls++;else result.missing_calls++;for(const k of ['input_tokens','output_tokens'])if(typeof c.usage?.[k]==='number')result[k]+=c.usage[k];}result.total_tokens=result.input_tokens+result.output_tokens;return result; }
async function loadRuns() {
  const version=++state.navVersion;
  const page=await api(`/api/runs?${query({window:state.window,after:state.navPages.at(-1),limit:30,q:$('run-search').value,status:$('run-status').value})}`);
  if(version!==state.navVersion)return;
  state.runPage=page;
  $('run-count').textContent=page.items.length;
  const rows=page.items.map(run=>{
    const el=button('',()=>selectRun(run.run_id),'run-item');el.classList.toggle('active',run.run_id===state.selected&&!state.global);
    el.append(node('span','run-title',run.title));const meta=node('div','run-meta');meta.append(node('span','',dateTime(run.started)),badge(run.completion));el.append(meta,node('small','',`${fmt((run.summary?.input_tokens||0)+(run.summary?.output_tokens||0))} known tokens · ${shortId(run.run_id)}`));
    return keyed(el,run.run_id,{run,active:run.run_id===state.selected&&!state.global});
  });
  reconcile($('run-list'),rows.length?rows:[keyed(empty('No runs in this window.',true),'empty',state.window)]);
  $('runs-prev').disabled=state.navPages.length===1;$('runs-next').disabled=!page.has_more;
  if(!state.selected&&!state.global&&page.items.length)await selectRun(page.items[0].run_id);
  urlState();
}
function setPageDefaults() {state.inspectorVersion++;state.selection='';state.offset=0;state.eventPage={};state.page=null;state.follow=false;state.transcript=null;state.version++;$('new-records').classList.add('hidden');}
async function selectRun(id) {state.selected=id;state.agent=id;state.global='';state.tab='conversation';state.inspector='usage';setPageDefaults();urlState();await Promise.all([loadRuns(),loadRunHeader()]);await loadView();}
async function loadRunHeader() {
  if(!state.selected||state.global)return;
  const id=state.selected;
  const detail=await api(`/api/runs/${encodeURIComponent(id)}?spans=0`);
  if(state.selected!==id||state.global)return;
  state.detail=detail;const selected=detail.runs.find(r=>r.run_id===owner())||detail.runs[0];
  if(!detail.runs.some(r=>r.run_id===state.agent))state.agent=state.selected;
  $('page-title').textContent=selected.agent_name?`${selected.agent_name} conversation`:'Recorded conversation';
  $('page-subtitle').textContent=`${dateTime(selected.started)} · run ${selected.run_id}${selected.thread_id?` · thread ${selected.thread_id}`:''}`;
  $('recorded-state').textContent=`Last recorded: ${selected.completion}`;
  const previous=$('agent').value;const options=detail.runs.map(run=>{let depth=0,parent=run.parent_run_id;const seen=new Set();while(parent&&!seen.has(parent)){seen.add(parent);depth++;parent=detail.runs.find(r=>r.run_id===parent)?.parent_run_id;}const option=node('option','',`${'↳ '.repeat(depth)}${run.agent_name} · ${shortId(run.run_id)}`);option.value=run.run_id;return option;});
  if(JSON.stringify([...$('agent').options].map(o=>[o.value,o.text]))!==JSON.stringify(options.map(o=>[o.value,o.text])))$('agent').replaceChildren(...options);
  $('agent').value=state.agent||previous;
}
function viewChrome() {
  const isEvents=!!state.global&&['events','logs','feedback'].includes(state.global)||!state.global&&state.tab==='activity';
  $('agent-controls').classList.toggle('hidden',!!state.global||!state.selected);$('main-tabs').classList.toggle('hidden',!!state.global||!state.selected);
  $('event-controls').classList.toggle('hidden',!isEvents);$('legend').classList.toggle('hidden',!isEvents);$('usage-total').classList.toggle('hidden',!!state.global||!state.selected);
  $('page-controls').classList.remove('hidden');$('follow').classList.toggle('hidden',!isEvents&&!['conversation','thinking'].includes(state.tab));$('jump-form').classList.toggle('hidden',!isEvents);
  $('follow').setAttribute('aria-pressed',String(state.follow));$('follow').textContent=state.follow?'Following latest':'Follow latest';
  for(const tab of document.querySelectorAll('[data-tab]')){tab.classList.toggle('active',tab.dataset.tab===state.tab);tab.setAttribute('aria-current',tab.dataset.tab===state.tab?'page':'false');}
  for(const item of document.querySelectorAll('[data-global]'))item.classList.toggle('active',item.dataset.global===state.global);
  if(state.global){$('page-title').textContent={events:'System events',logs:'All logs',processes:'Recorder & processes',metrics:'Metric snapshots',feedback:'Feedback'}[state.global];$('page-subtitle').textContent=`${state.database?.filename||'SQLite'} · independent of selected conversation`;}
}
function configurePager(page, size=50) {
  state.page=page;state.pageSize=size;$('page-prev').disabled=state.offset===0;$('page-next').disabled=!page.has_more;
  $('page-label').textContent=`Page ${Math.floor(state.offset/size)+1}${page.total_items!=null?` · ${page.total_items} messages`:''}`;
}
function roundActivity(round, call) {
  const details=node('details','round-activity');details.dataset.key=`activity:${call.id}`;
  details.append(node('summary','',round.kind==='round'?'Recorded round activity':'Recorded native-call activity'));
  const scope=owner();let loaded=false;
  details.addEventListener('toggle',act(async()=>{
    if(!details.open||loaded)return;
    if(!call.round_id&&!call.native_id){loaded=true;details.append(node('p','dim','No round or native-call ID was recorded. Inspect unlinked evidence in Activity.'));return;}
    loaded=true;const loading=node('p','dim','Loading linked evidence…');details.append(loading);
    try{const page=await api(`/api/runs/${encodeURIComponent(scope)}/activity?${query({round:call.round_id||'',native:call.round_id?'':call.native_id||'',limit:25})}`);
      if(!details.isConnected)return;loading.remove();
      for(const event of page.items){const row=button('',()=>openEvent(event.cursor),'inline-activity');row.append(kind(event.category),node('span','',event.label),badge(event.outcome));details.append(row);}
      if(!page.items.length)details.append(node('p','dim','No explicitly linked records. Other evidence remains in Activity.'));
      if(page.has_after)details.append(button('More records in Activity',()=>{state.tab='activity';setPageDefaults();return loadView();},'text-button'));
    }catch(e){loaded=false;loading.textContent=e.message;}
  }));
  return details;
}
async function showMetricHistory(name, process, offset=0) {
  const version=++state.inspectorVersion;
  const result=await api(`/api/metric-series?${query({name,process,offset,limit:50})}`);
  if(version!==state.inspectorVersion)return;
  const rows=result.items.map(m=>[dateTime(m.timestamp),m.point.value??`count ${m.point.count??'—'} · sum ${m.point.sum??'—'}`,String(m.temporality??'gauge'),disclosure('Attributes / full point',m)]);
  const controls=node('div','inspector-actions');controls.append(button('Newer',()=>showMetricHistory(name,process,Math.max(0,offset-50))),button('Older',()=>showMetricHistory(name,process,result.next_offset)));controls.firstChild.disabled=offset===0;controls.lastChild.disabled=!result.has_more;
  showInspector(name,[node('p','dim',result.coverage),table(['Recorded','Value','Temporality','Evidence'],rows),controls]);
}
function renderConversation(value) {
  state.transcript=value;const elements=[];const calls=new Map(value.calls.map(c=>[c.id,c]));const rounds=new Map();for(const r of value.rounds)for(const c of r.calls)rounds.set(c.id,r);
  const mounted=new Set();
  for(const item of value.items){
    for(const id of item.calls){const call=calls.get(id),round=rounds.get(id);if(!call||!round||mounted.has(round.id))continue;mounted.add(round.id);const label=node('div','round-label');label.append(kind('llm'),node('span','',`${round.kind==='round'?'Round':'Call'} ${round.number} · ${call.model||'Model unavailable'}${call.purpose==='summary'?' · Summary':''}`));label.append(button(`${fmt(round.usage.input_tokens)} in · ${fmt(round.usage.output_tokens)} out · ${round.usage.calls_with_usage}/${round.usage.model_calls} reported`,()=>showUsage(round.usage,`${round.kind} ${round.number}`,round.calls.length===1?call:null)));elements.push(keyed(label,`round:${round.id}`,round));}
    const article=node('article',`message ${['user','assistant','tool','system'].includes(item.role)?item.role:'system'}`);
    const head=node('div','message-head');head.append(node('span','',`${item.role==='user'?'You':item.role==='assistant'?'Assistant':item.role==='tool'?'Tool result':item.role}${item.name?` · ${item.name}`:''}`));
    if(item.role==='user'){const turn=value.turns.find(t=>t.id===item.turn_id);if(turn)head.append(node('span','',`Turn ${turn.number}${turn.usage?'':' · prior context / usage unavailable'}`));}
    article.append(head);
    if(item.thinking_available){const summary=disclosure(`Thinking summary${item.streaming?' · streaming':''}`,item.thinking_preview,item.streaming);summary.classList.add('thinking-summary');summary.dataset.key=`thinking:${item.key}`;if(!item.thinking_complete)summary.append(button('Read complete summary',()=>openMessage(item.key),'text-button'));article.append(summary);}
    if(item.preview)article.append(node('pre','message-body',item.preview));
    else article.append(node('p','dim',item.tool_calls?.length?'Requested tool execution.':item.streaming?'Waiting for answer text…':item.structured_content?'Structured response · open message details.':item.thinking_available?'No answer text recorded.':'(No text content)'));
    const actions=node('div','message-actions');actions.append(button(item.content_complete?'Message details':'Read complete message',()=>openMessage(item.key),'text-button'));
    for(const id of item.calls){const call=calls.get(id);actions.append(button(`Usage · ${call?.usage_coverage||'unknown'}`,()=>showUsage(totalFor([call]),'Model call usage',call),'text-button'));if(call?.request_cursor)actions.append(button('Request body ↗',()=>{state.requestView='body';return openRequest(call.request_cursor,call.run_id);},'text-button'));}
    if(item.role==='tool'&&item.tool_call_id)actions.append(button('Tool execution',()=>openTool(item.tool_call_id),'text-button'));
    article.append(actions);
    for(const id of item.calls){const round=rounds.get(id);if(round)article.append(roundActivity(round,calls.get(id)));}
    for(const tool of item.tool_calls||[])article.append(button(`Tool call · ${tool.name||'Tool'} ↗`,()=>openTool(tool.id),'text-button tool-proposal'));
    elements.push(keyed(article,item.key,{item,calls:item.calls.map(id=>calls.get(id))}));
    const itemIndex=value.items.indexOf(item),next=value.items[itemIndex+1];
    if(item.turn_id&&((next&&next.turn_id!==item.turn_id)||(!next&&!value.has_more))){const turn=value.turns.find(t=>t.id===item.turn_id);if(turn){const summary=node('div','turn-usage',`Turn ${turn.number} · ${turn.usage?`${fmt(turn.usage.total_tokens)} known tokens · ${turn.usage.calls_with_usage}/${turn.usage.model_calls} calls reported usage`:'usage unavailable for prior context'}`);elements.push(keyed(summary,`turn:${turn.id}`,turn));}}
  }
  for(const round of value.rounds.filter(r=>!mounted.has(r.id))){const row=node('div','round-label');row.append(kind(round.calls.length?'llm':'middleware'),node('span','',`${round.kind==='round'?'Round':'Call'} ${round.number} · ${round.calls.length?'no linked transcript message':'no linked native call'}`),button('Inspect recorded activity',()=>round.calls.length?showUsage(round.usage,'Recorded call usage',round.calls[0]):openRequest(round.cursor,owner())));elements.push(keyed(row,`round:${round.id}`,round));}
  if(!elements.length)elements.push(keyed(empty('No attributable conversation messages recorded. Inspect model calls or raw activity for available evidence.'),'empty',value.snapshot));
  reconcile($('content'),elements);$('content').className='transcript';
  $('view-note').textContent=`${value.source} · ${value.total_turns} user turns · ${value.total_rounds} rounds/calls · ${value.unattributed_calls} calls without turn attribution. Prior context is retained once.`;
  configurePager(value);
  if(state.follow&&!$('request-dialog').open)$('content').lastElementChild?.scrollIntoView({block:'end'});
}
function renderThinking(page) {
  const rows=page.items.map((call,index)=>{
    const row=node('article','model-call');
    const head=node('div','data-row-head');
    head.append(kind('llm'),node('h2','',`${call.model||'Model unavailable'} · call ${page.offset+index+1}`),badge(call.status==='incomplete'?'running':call.status));
    row.append(head,node('p','dim',`${call.purpose||'Purpose unavailable'} · ${clock(call.timestamp)} · ${shortId(call.native_id||call.id)}`));
    const timing=node('div','call-facts');
    timing.append(facts([['Duration',duration(call.duration)],['First output',duration(call.first_token)],['Input',fmt(call.usage?.input_tokens)],['Output',fmt(call.usage?.output_tokens)],['Usage',call.usage_coverage]]));
    row.append(timing);
    if(call.thinking_available){const summary=disclosure(`Thinking summary · ${call.thinking_source}`,call.thinking_preview,true);summary.classList.add('thinking-summary');summary.dataset.key=`thinking:${call.id}`;if(!call.thinking_complete)summary.append(button('Read complete summary',()=>openThinking(call),'text-button'));row.append(summary);}
    else row.append(node('p','thinking-unavailable',call.status==='incomplete'?'Waiting for a recorded thinking summary…':'No thinking summary was exposed in this recording.'));
    const actions=node('div','message-actions');
    if(call.request_cursor)actions.append(button('Request body ↗',()=>{state.requestView='body';return openRequest(call.request_cursor,call.run_id);},'text-button'),button('Response & usage ↗',()=>{state.requestView='response';return openRequest(call.request_cursor,call.run_id);},'text-button'));
    actions.append(button('Usage details',()=>showUsage(totalFor([call]),'Model call usage',call),'text-button'));row.append(actions);
    return keyed(row,call.id,call);
  });
  reconcile($('content'),rows.length?rows:[keyed(empty('No native model calls recorded for this agent.'),'empty',page.offset)]);
  $('content').className='model-timeline';
  $('view-note').textContent=`${page.total_calls} native calls · ${page.summary_calls} with thinking summaries. ${page.coverage}`;
  configurePager(page);
  if(state.follow&&!$('request-dialog').open)$('content').lastElementChild?.scrollIntoView({block:'end'});
}
function table(headers, rows) {const wrap=node('div','table-scroll'),t=node('table'),head=node('tr');headers.forEach(h=>head.append(node('th','',h)));const thead=node('thead');thead.append(head);t.append(thead);const body=node('tbody');for(const cells of rows){const tr=node('tr');for(const cell of cells){const td=node('td');td.append(cell instanceof Node?cell:document.createTextNode(String(cell)));tr.append(td);}body.append(tr);}t.append(body);wrap.append(t);return wrap;}
function renderUsage(value) {
  const calls=value.calls;const rows=calls.map(c=>[button(`${c.model||'Model unavailable'} · ${shortId(c.id)}`,()=>showUsage(totalFor([c]),'Model call usage',c),'text-button'),`${shortId(c.run_id)} · ${c.purpose||'unknown purpose'}`,c.round_id?shortId(c.round_id):'No round ID',fmt(c.usage?.input_tokens),fmt(c.usage?.output_tokens),c.usage_coverage,badge(c.status)]);
  $('content').replaceChildren(table(['Native call','Agent / purpose','Round','Input','Output','Coverage','Outcome'],rows));
  const agents=node('section','section');agents.append(node('h2','','Usage by agent'),table(['Agent','Native calls','Input','Output','Coverage'],value.agents.map(a=>[button(shortId(a.run_id),async()=>{state.agent=a.run_id;$('agent').value=a.run_id;state.tab='conversation';setPageDefaults();await loadRunHeader();await loadView();},'text-button'),fmt(a.model_calls),fmt(a.input_tokens),fmt(a.output_tokens),`${a.calls_with_usage}/${a.model_calls}`])));$('content').append(agents);
  $('view-note').textContent=`${value.scope}. Known totals include labelled partial usage. Summary reconciliation: ${value.reconciliation}.`;
  configurePager(value);
}
function eventFilters(){return {after:state.eventPage.after||'',before:state.eventPage.before||'',latest:state.follow||state.eventPage.latest?'1':'',limit:100,category:state.global==='logs'?'log':state.global==='feedback'?'feedback':state.category,severity:state.severity,q:state.search,process:$('process-filter').value,logger:$('logger-filter').value,since:$('event-since').value?Date.parse($('event-since').value)/1000:'',until:$('event-until').value?Date.parse($('event-until').value)/1000:'',unscoped:$('unscoped').checked?'1':'',window:state.global?state.window:'all'};}
function renderEvents(page) {
  const rows=page.items.map(event=>{const el=button('',()=>openEvent(event.cursor),`event-row ${event.category}`);el.append(node('span','event-time',clock(event.timestamp)));const body=node('div');const title=node('div','event-title');title.append(kind(event.category),node('strong','',event.label));body.append(title,node('div','event-preview',event.preview||event.record_error||''),node('div','event-name',`${event.event_name} · #${event.cursor} · ${event.run_id?`run ${shortId(event.run_id)}`:'unscoped'}${event.process_instance_id?` · process ${shortId(event.process_instance_id)}`:''}${event.duration!=null?` · ${duration(event.duration)}`:''}`));el.append(body,badge(event.outcome));return keyed(el,String(event.cursor),event);});
  reconcile($('content'),rows.length?rows:[keyed(empty('No records match these filters. Older data may be outside the time window.'),'empty',eventFilters())]);state.page=page;$('page-prev').disabled=!page.has_before;$('page-next').disabled=!page.has_after;$('page-label').textContent=page.items.length?`Events #${page.first_cursor}–${page.last_cursor}`:'No events';
  $('view-note').textContent='Database arrival order · search covers event metadata and complete log messages; open a record to search its complete payload. All categories remain available.';
}
function renderTools(page) {
  const list=node('div','data-list');for(const tool of page.items){const row=node('article','data-row tool');const head=node('div','data-row-head');head.append(kind('tool'),button(tool.name,()=>openTool(tool.id),'text-button'),badge(tool.status));row.append(head,node('p','',tool.args_preview||'Arguments unavailable'),node('p','',`${tool.attempts.length} recorded attempts · ${duration(tool.duration)} · ${tool.started?'call start recorded':'no call start recorded'}`));list.append(row);} $('content').replaceChildren(page.items.length?list:empty('No tool calls with recorded call IDs. Unlinked evidence remains in Activity.'));$('view-note').textContent='Logical calls and attempts are separate. Error results remain errors even when a wrapper completed.';configurePager(page);
}
function renderRequests(page) {
  const list=node('div','data-list');for(const request of page.items){const row=node('article','data-row');const label=request.event_name==='model.started'?'Native call':request.correlation==='unavailable'?'Unlinked request evidence':request.event_name==='model.round.started'?'Round · native request unavailable':'Request · native call unavailable';row.append(button(`${label} · ${request.model||'Model unavailable'}`,()=>openRequest(request.cursor,owner()),'text-button'),node('p','',`${request.purpose||'Purpose unavailable'} · ${shortId(request.run_id)} · ${clock(request.timestamp)} · #${request.cursor} · correlation ${request.correlation}`));list.append(row);}$('content').replaceChildren(page.items.length?list:empty('No model-request records for this selection.'));$('view-note').textContent='Open complete original, effective and native requests, tools, skills, transformations and responses.';state.page=page;$('page-prev').disabled=!(state.requestPages?.length>1);$('page-next').disabled=!page.has_more;$('page-label').textContent=`Page ${state.requestPages?.length||1}`;
}
function renderTrace(page) {
  const spans=page.items,root=state.detail?.runs.find(r=>r.run_id===state.detail.root_run_id),start=root?.started||Math.min(...spans.map(s=>s.started)),end=root?.ended||Math.max(...spans.map(s=>s.ended));const range=Math.max(.001,end-start);const list=node('div');
  for(const span of spans){const row=button('',async()=>{const version=++state.inspectorVersion;const record=await api(`/api/traces/${encodeURIComponent(span.trace_id)}/spans/${encodeURIComponent(span.span_id)}`);if(version===state.inspectorVersion)inspectRecord(span.name,record);},'trace-row');let depth=0,parent=span.parent_span_id;const visited=new Set();while(parent&&!visited.has(parent)){visited.add(parent);depth++;parent=spans.find(s=>s.trace_id===span.trace_id&&s.span_id===parent)?.parent_span_id;}const name=node('span','',`${span.parent_span_id?'↳ ':''}${span.name}`);name.style.paddingLeft=`${Math.min(depth,8)*8}px`;name.title=span.parent_span_id?`Parent span: ${span.parent_span_id}`:'Root span';const track=node('span','trace-track');track.setAttribute('aria-label',`Starts ${(span.started-start).toFixed(3)} seconds after root start`);const bar=node('span','trace-bar');bar.style.left=`${Math.max(0,Math.min(100,(span.started-start)/range*100))}%`;bar.style.width=`${Math.max(.15,Math.min(100,(span.ended-span.started)/range*100))}%`;if(String(span.status).includes('ERROR'))bar.style.background='var(--danger)';track.append(bar);row.append(name,track,node('span','',duration(span.ended-span.started)));list.append(row);}
  $('content').replaceChildren(spans.length?list:empty('No completed native spans recorded.'));$('view-note').textContent='Completed spans aligned to root wall time. Overlapping durations are not additive. Select a span for recorded parentage, attributes, events and links.';configurePager(page);
}
function renderOverview(records) {
  const run=records.run,values=run.payload?.data||{},summary=run.summary?.data||{};
  const list=node('div');list.append(node('h2','','Recorded run'),fields({...values,input:undefined,...summary,summary:summary.summary}));list.append(disclosure('Complete run input',values.input),disclosure('Complete source records',records));
  const tree=node('section','section');tree.append(node('h2','','Agent tree'));const byId=new Map((state.detail?.runs||[]).map(r=>[r.run_id,r]));for(const r of byId.values()){const row=node('div','tree-row');let depth=0,p=r.parent_run_id;const seen=new Set();while(p&&byId.has(p)&&!seen.has(p)){seen.add(p);depth++;p=byId.get(p).parent_run_id;}row.style.paddingLeft=`${Math.min(depth,12)*12}px`;row.append(button(`${r.parent_run_id?'↳ ':''}${r.agent_name} · ${shortId(r.run_id)}`,async()=>{state.agent=r.run_id;state.tab='conversation';setPageDefaults();await loadRunHeader();await loadView();},'text-button'),badge(r.completion));tree.append(row);}list.append(tree);
  if(records.thread_segments.length){const segment=node('section','section');segment.append(node('h2','','Recorded thread invocations'),node('p','dim',records.continuity));for(const r of records.thread_segments)segment.append(button(`${dateTime(r.started)} · ${shortId(r.run_id)} · ${r.completion}`,()=>selectRun(r.run_id),'text-button'));list.append(segment);}
  $('content').replaceChildren(list);$('page-controls').classList.add('hidden');$('view-note').textContent='Stored input, output, limits and diagnostics. Current source files are never used to reconstruct this run.';
}
async function renderGlobal(page, version) {
  const list=node('div','data-list');
  for(const row of page.items){const item=node('article','data-row');if(state.global==='processes'){
    const head=node('div','data-row-head');head.append(button(`${row.service||'Process'} · PID ${row.pid} · ${shortId(row.process_instance_id)}`,async()=>{const v=++state.inspectorVersion;const r=await api(`/api/processes/${encodeURIComponent(row.process_instance_id)}`);if(v===state.inspectorVersion)inspectRecord('Recorded process health',r,r.process);},'text-button'),badge(row.health));item.append(head,node('p','',`Heartbeat ${dateTime(row.heartbeat)} · ${row.stopped?`stopped ${dateTime(row.stopped)}`:'no stop recorded'} · ${fmt(row.unrecorded)} unrecorded`));
  }else{item.append(button(`${dateTime(row.timestamp)} · ${shortId(row.collection_id)}`,async()=>{const v=++state.inspectorVersion;const r=await api(`/api/metrics/${encodeURIComponent(row.collection_id)}`);if(v!==state.inspectorVersion)return;inspectRecord('Metric snapshot',r,{process:row.process_instance_id,collection:row.collection_id,recorded_at:dateTime(row.timestamp),note:'Values preserve SDK temporality. Snapshots are not summed.'});const groups=node('div');for(const m of r.series||[]){const detail=disclosure(`${m.name} · ${m.unit||'no unit'}`,m,true);detail.append(button('Inspect recorded history',()=>showMetricHistory(m.name,row.process_instance_id),'text-button'));groups.append(detail);}$('inspector-content').append(groups);},'text-button'),node('p','',`Process ${shortId(row.process_instance_id)} · complete snapshot available`));}list.append(item);}
  if(version!==state.version)return;$('content').replaceChildren(page.items.length?list:empty(page.coverage||'No records available.'));$('view-note').textContent=state.global==='processes'?'Last recorded process health across this database. Heartbeat age does not establish OS liveness.':page.coverage;configurePager(page);
}
async function loadView() {
  const version=++state.version;viewChrome();urlState();$('content').className='';$('new-records').classList.add('hidden');
  if(!state.global&&!state.selected){$('content').replaceChildren(empty('Choose a recorded run. If this window is empty, show all recorded runs.',true));$('page-controls').classList.add('hidden');return;}
  const name=state.global||state.tab;
  try{
    let usagePromise=!state.global?api(`${runPath('usage')}?${query({offset:state.tab==='usage'?state.offset:0,limit:50})}`).then(value=>({value}),error=>({error})):null;
    let page;
    if(['events','logs','feedback','activity'].includes(name))page=await api(`${state.global?'/api/events':runPath('activity')}?${query(eventFilters())}`);
    else if(name==='conversation')page=await api(`${runPath('conversation')}?${query({offset:state.offset,limit:50})}`);
    else if(name==='thinking')page=await api(`${runPath('thinking')}?${query({offset:state.offset,limit:50})}`);
    else if(name==='usage'){const resolved=await usagePromise;if(resolved.error)throw resolved.error;page=resolved.value;}
    else if(name==='tools'||name==='trace')page=await api(`${runPath(name==='trace'?'spans':'tools')}?${query({offset:state.offset,limit:50})}`);
    else if(name==='requests')page=await api(`${runPath('requests')}?${query({after:state.requestPages?.at(-1)||0,limit:25})}`);
    else if(name==='overview')page=await api(runPath('records'));
    else page=await api(`/api/${name}?${query({offset:state.offset,limit:50,process:$('process-filter').value})}`);
    const resolvedUsage=usagePromise?await usagePromise:null;if(resolvedUsage?.error)throw resolvedUsage.error;const usage=resolvedUsage?.value;
    if(version!==state.version)return;
    if(usage){state.usage=usage;$('usage-total').textContent=`${fmt(usage.total.total_tokens)} known tokens ↗`;if(state.inspector==='usage')showUsage();}
    if(['events','logs','feedback','activity'].includes(name))renderEvents(page);
    else if(name==='conversation')renderConversation(page);
    else if(name==='thinking')renderThinking(page);
    else if(name==='usage')renderUsage(page);
    else if(name==='tools')renderTools(page);
    else if(name==='requests')renderRequests(page);
    else if(name==='trace')renderTrace(page);
    else if(name==='overview')renderOverview(page);
    else await renderGlobal(page,version);
    if(state.follow&&['conversation','thinking'].includes(name)&&page.has_more){state.offset=Math.floor(((page.total_items??page.total_calls)-1)/50)*50;return loadView();}
  }catch(e){if(version===state.version){error(e.message);throw e;}}
}
async function refresh(force=false) {
  if(state.refreshing||state.paused&&!force)return;state.refreshing=true;
  try{
    const db=await api('/api/database'),previous=state.database;state.database=db;
    if(!state.initialized){if(params.get('db')&&params.get('db')!==db.identity){state.selected='';state.agent='';state.global='';state.offset=0;state.selection='';}state.initialized=true;setupCategories(db);}
    if(previous&&previous.identity!==db.identity){state.selected='';state.agent='';state.detail=null;state.usage=null;state.navPages=[''];state.inspector='usage';setPageDefaults();$('process-filter').value='';$('logger-filter').value='';state.requestOpenVersion++;$('request-dialog').close();showInspector('Database changed',[node('p','dim','Choose a record from the current database.')],'usage');}
    $('database-info').replaceChildren(node('p','mono',db.path),node('p','',`Schema ${db.schema_version} · read only`),node('p','',`${dateTime(db.first_run)} – ${dateTime(db.last_run)}`),fields(db.counts));
    if(!state.initialLoadComplete){const selection=state.selection;await loadRuns();if(state.selected&&!state.detail)await loadRunHeader();await loadView();if(selection.startsWith('event:'))await openEvent(Number(selection.slice(6)));if(Number(params.get('request'))>0&&(!params.get('db')||params.get('db')===db.identity)&&await openRequest(Number(params.get('request')),params.get('requestRun')||owner())===false)throw new Error('Selected request refresh failed.');}
    else if(force||state.refreshPending||previous.watermark!==db.watermark){await loadRuns();if(force||state.refreshPending||state.follow){await loadRunHeader();await loadView();}else $('new-records').classList.remove('hidden');if($('request-dialog').open&&state.requestCursor&&(force||state.refreshPending||state.follow||state.requestFollow)&&await refreshRequest()===false)throw new Error('Selected request refresh failed.');}
    state.refreshPending=false;state.initialLoadComplete=true;
    $('connection').textContent=state.paused?'Refresh paused':`Updated ${new Date().toLocaleTimeString()}`;$('error-banner').classList.add('hidden');
  }catch(e){state.refreshPending=true;error(e.message);}finally{state.refreshing=false;}
}
function setupCategories(db){for(const [key,label] of Object.entries(db.categories)){const option=node('option','',label);option.value=key;$('category').append(option);$('legend').append(kind(key));}$('category').value=state.category;$('severity').value=state.severity;$('event-search').value=state.search;}
function pageMove(direction){const name=state.global||state.tab;if(['events','logs','feedback','activity'].includes(name)){state.follow=false;state.eventPage=direction>0?{after:state.page.last_cursor}:{before:state.page.first_cursor};}else if(name==='requests'){state.requestPages ||= [0];if(direction>0)state.requestPages.push(state.page.next_cursor);else if(state.requestPages.length>1)state.requestPages.pop();}else{state.follow=false;state.offset=Math.max(0,state.offset+direction*(state.pageSize||50));}return loadView();}
function debounce(fn){let timeout;return()=>{clearTimeout(timeout);timeout=setTimeout(act(fn),250);};}
$('window').value=state.window;
for(const [id,key] of [['process-filter','process'],['logger-filter','logger'],['event-since','since'],['event-until','until'],['run-search','runSearch'],['run-status','runStatus']])$(id).value=params.get(key)||'';
$('unscoped').checked=params.get('unscoped')==='1';
$('window').addEventListener('change',act(async()=>{state.window=$('window').value;state.navPages=[''];await loadRuns();if(state.global){setPageDefaults();await loadView();}}));
for(const id of ['run-search','run-status'])$(id).addEventListener(id==='run-search'?'input':'change',debounce(()=>{state.navPages=[''];return loadRuns();}));
$('runs-prev').addEventListener('click',act(()=>{if(state.navPages.length>1)state.navPages.pop();return loadRuns();}));$('runs-next').addEventListener('click',act(()=>{if(state.runPage?.has_more)state.navPages.push(state.runPage.next_anchor);return loadRuns();}));
for(const tab of document.querySelectorAll('[data-tab]'))tab.addEventListener('click',act(()=>{state.tab=tab.dataset.tab;setPageDefaults();state.requestPages=[0];return loadView();}));
for(const tab of document.querySelectorAll('[data-global]'))tab.addEventListener('click',act(()=>{state.global=tab.dataset.global;setPageDefaults();state.eventPage={latest:true};state.inspectorVersion++;state.inspector='record';showInspector('Database evidence',[node('p','dim','Select a record for its complete stored detail.')]);return Promise.all([loadRuns(),loadView()]);}));
$('agent').addEventListener('change',act(async()=>{state.agent=$('agent').value;setPageDefaults();state.requestPages=[0];state.inspector='usage';await loadRunHeader();await loadView();}));
for(const id of ['category','severity','event-search','process-filter','logger-filter','event-since','event-until','unscoped'])$(id).addEventListener(id.includes('search')||id.includes('filter')?'input':'change',debounce(()=>{state.category=$('category').value;state.severity=$('severity').value;state.search=$('event-search').value;setPageDefaults();return loadView();}));
$('page-prev').addEventListener('click',act(()=>pageMove(-1)));$('page-next').addEventListener('click',act(()=>pageMove(1)));
$('follow').addEventListener('click',act(()=>{state.follow=!state.follow;state.eventPage={};return loadView();}));
$('pause').addEventListener('click',()=>{state.paused=!state.paused;$('pause').textContent=state.paused?'Resume refresh':'Pause refresh';$('connection').textContent=state.paused?'Refresh paused':'Refresh resumed';});
$('refresh').addEventListener('click',act(()=>refresh(true)));$('new-records').addEventListener('click',act(async()=>{await loadRunHeader();await loadView();}));$('usage-total').addEventListener('click',()=>showUsage());
$('expand-inspector').addEventListener('click',expandInspector);
$('inspector-dialog').addEventListener('close',restoreInspector);
$('close-inspector').addEventListener('click',()=>{state.inspectorVersion++;state.inspector='closed';document.body.classList.add('inspector-closed');if($('inspector-dialog').open)$('inspector-dialog').close();});
const inspectorResize=$('inspector-resize');
inspectorResize.addEventListener('pointerdown',event=>{
  if(event.button!==0)return;
  event.preventDefault();inspectorResize.setPointerCapture(event.pointerId);inspectorResize.focus();
  document.body.classList.add('inspector-resizing');
});
inspectorResize.addEventListener('pointermove',event=>{
  if(inspectorResize.hasPointerCapture(event.pointerId))setInspectorWidth(window.innerWidth-event.clientX);
});
for(const name of ['pointerup','pointercancel','lostpointercapture'])inspectorResize.addEventListener(name,event=>{
  if(inspectorResize.hasPointerCapture(event.pointerId))inspectorResize.releasePointerCapture(event.pointerId);
  document.body.classList.remove('inspector-resizing');
});
inspectorResize.addEventListener('dblclick',()=>setInspectorWidth(380));
inspectorResize.addEventListener('keydown',event=>{
  const width=$('inspector').getBoundingClientRect().width;
  const sizes={ArrowLeft:width+32,ArrowRight:width-32,Home:380,End:880};
  if(event.key in sizes){event.preventDefault();setInspectorWidth(sizes[event.key]);}
});
window.addEventListener('resize',()=>setInspectorWidth(Number(inspectorResize.getAttribute('aria-valuenow'))));
setInspectorWidth(380);
$('jump-form').addEventListener('submit',e=>{e.preventDefault();const cursor=Number($('jump-cursor').value);if(Number.isSafeInteger(cursor)&&cursor>0)act(()=>openEvent(cursor))();});
$('close-request').addEventListener('click',()=>{$('request-dialog').close();state.requestOpenVersion++;});$('request-dialog').addEventListener('close',()=>{state.requestOpenVersion++;urlState();});
$('refresh-request').addEventListener('click',act(refreshRequest));
$('follow-request').addEventListener('click',act(async()=>{state.requestFollow=!state.requestFollow;$('follow-request').textContent=state.requestFollow?'Following this call':'Follow this call';$('follow-request').setAttribute('aria-pressed',String(state.requestFollow));if(state.requestFollow)await refreshRequest();}));
$('export-request').addEventListener('click',()=>exportRequest());$('export-request-jsonl').addEventListener('click',()=>exportRequest(true));
for(const tab of document.querySelectorAll('[data-request-view]'))tab.addEventListener('click',()=>{state.requestView=tab.dataset.requestView;renderRequest();urlState();});
refresh();setInterval(()=>refresh(),3000);
