function jsonBlock(value) { return node("pre", "request-json", JSON.stringify(value, null, 2)); }
function dataOf(record) { return record?.payload?.data; }
function requestBodySnapshot(detail) {
  return JSON.stringify({
    available: ['provider', 'native', 'effective', 'original'].filter(stage => detail[stage]),
    selected: detail[state.requestBodyStage],
  });
}
function disclosure(title, value, open = false) {
  const details = node("details", "request-disclosure");
  details.open = open;
  details.append(node("summary", "", title));
  // Mount complete payload only when opened; no slicing or truncation.
  const mount = () => { if (details.open && details.children.length === 1) details.append(typeof value === "string" ? node("pre", "message-text", value) : jsonBlock(value)); };
  details.addEventListener("toggle", mount);
  mount();
  return details;
}

async function openRequest(cursor, owner = state.agent || state.selected, preserve = false) {
  const version = ++state.requestOpenVersion;
  if(!preserve)state.requestDetail = null;
  state.requestOwner = owner;
  state.requestCursor = cursor;
  if(!preserve){$("request-title").textContent = `Loading request #${cursor}…`;$("request-content").replaceChildren();}
  if (!$("request-dialog").open) $("request-dialog").showModal();
  try {
    const detail = await api(`/api/runs/${encodeURIComponent(owner)}/requests/${cursor}`);
    if (state.requestOpenVersion !== version || !$("request-dialog").open) return;
    $("request-content").querySelector('.request-refresh-error')?.remove();
    // Keep changes made while the refresh was in flight, including reading position.
    const previousBody = preserve && state.requestView==='body' && state.requestDetail ? requestBodySnapshot(state.requestDetail) : null;
    const scroll = preserve ? $("request-content").scrollTop : 0;
    const bodyScroll = preserve ? $("request-content").querySelector('.body-json')?.scrollTop || 0 : 0;
    const disclosureState = new Map(preserve ? [...$("request-content").querySelectorAll('details')].map(d=>[d.querySelector('summary')?.textContent,d.open]) : []);
    const search = preserve ? $("body-search")?.value || '' : '';
    state.requestDetail = detail;
    $("request-title").textContent = `${dataOf(detail.native)?.model || "Model request"} · ${detail.context.purpose || "unknown purpose"}`;
    $("request-identity").textContent = `Run ${detail.run_id} · round ${detail.context.round_id || "unavailable"} · request ${detail.context.request_id || "unavailable"}`;
    const coverage = $("request-coverage");
    coverage.replaceChildren();
    for (const [key, value] of Object.entries(detail.coverage)) coverage.append(node("span", `coverage-item ${value === "captured" || value === "explicit" ? "captured" : ""}`, `${key.replaceAll("_", " ")}: ${value.replaceAll("_", " ")}`));
    const bodyUnchanged=previousBody!==null&&previousBody===requestBodySnapshot(detail)&&state.requestView==='body'&&$("request-content").querySelector('.body-json');
    if(!bodyUnchanged){
      renderRequest();
      for(const d of $("request-content").querySelectorAll('details'))if(disclosureState.has(d.querySelector('summary')?.textContent))d.open=disclosureState.get(d.querySelector('summary')?.textContent);
      if(search&&$("body-search")){$("body-search").value=search;$("body-search").dispatchEvent(new Event('input'));}
      $("request-content").scrollTop=scroll;
      const body=$("request-content").querySelector('.body-json');if(body)body.scrollTop=bodyScroll;
    }
    urlState();
    return true;
  } catch (cause) {
    if(state.requestOpenVersion!==version||!$("request-dialog").open)return;
    const holder=$("request-content"),message=node("p","error-banner request-refresh-error",cause.message);
    if(preserve&&state.requestDetail){const previous=holder.querySelector('.request-refresh-error');if(previous)previous.textContent=cause.message;else holder.append(message);}
    else holder.replaceChildren(message);
    return false;
  }
}

async function refreshRequest() {
  if(!state.requestCursor)return;
  const refreshed=await openRequest(state.requestCursor,state.requestOwner,true);
  if(refreshed===false)state.refreshPending=true;
  return refreshed;
}

function renderRequestBody(holder, detail) {
  const labels={provider:'Provider HTTP body',native:'Native model call',effective:'Effective request',original:'Original request'};
  const available=Object.keys(labels).filter(stage=>detail[stage]);
  if(!available.length){holder.append(node('p','empty','No single request body was captured for this selection. Inspect raw records or select a native call.'));return;}
  if(!available.includes(state.requestBodyStage))state.requestBodyStage=available[0];
  const stage=state.requestBodyStage,record=detail[stage],body=stage==='provider'?dataOf(record).body:dataOf(record),text=JSON.stringify(body,null,2);
  const controls=node('div','body-toolbar'),select=node('select');select.setAttribute('aria-label','Request body stage');
  for(const [key,label] of Object.entries(labels)){const option=node('option','',label+(detail[key]?'':' · unavailable'));option.value=key;option.disabled=!detail[key];select.append(option);}
  select.value=stage;select.addEventListener('change',()=>{state.requestBodyStage=select.value;renderRequest();urlState();});
  const notice=node('span','dim');
  controls.append(select,button('Copy body',async()=>{await navigator.clipboard.writeText(text);notice.textContent='Copied complete JSON';}));
  controls.append(button('Download body',()=>{const link=node('a');link.href=URL.createObjectURL(new Blob([text+'\n'],{type:'application/json'}));link.download=`request-${detail.selected_cursor}-${stage}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);}),notice);
  holder.append(controls,node('p','request-explanation',stage==='provider'?`Recorded provider HTTP JSON · event #${record.cursor}. Stored redactions apply; headers and endpoint URLs are excluded.`:`Complete recorded ${labels[stage].toLowerCase()} payload · event #${record.cursor}. ${detail.provider?'The provider HTTP body is available in the stage selector.':'The provider HTTP body was not recorded.'}`));
  const search=node('input');search.id='body-search';search.type='search';search.placeholder='Find in complete request JSON';search.setAttribute('aria-label','Find in request body');
  const count=node('span','dim',`${text.split('\n').length} lines · ${number.format(text.length)} characters`),searchRow=node('div','body-search');searchRow.append(search,count);holder.append(searchRow);
  const pre=node('pre','request-json body-json',text);pre.tabIndex=0;pre.setAttribute('aria-label','Complete captured request JSON');holder.append(pre);
  search.addEventListener('input',()=>{const needle=search.value.toLowerCase(),lower=text.toLowerCase(),at=needle?lower.indexOf(needle):-1;if(at<0){pre.textContent=text;count.textContent=needle?'No matches':`${text.split('\n').length} lines`;return;}let matches=0,pos=0;while((pos=lower.indexOf(needle,pos))>=0){matches++;pos+=needle.length;}const mark=node('mark','',text.slice(at,at+needle.length));pre.replaceChildren(document.createTextNode(text.slice(0,at)),mark,document.createTextNode(text.slice(at+needle.length)));count.textContent=`${matches} match${matches===1?'':'es'} · first highlighted`;mark.scrollIntoView({block:'center'});});
  holder.append(disclosure('Recorded redaction paths',record.payload.redactions||[]));
}

function renderMessages(holder, record, native = false, presentation = null) {
  if (!record) { holder.append(node("p", "empty", "No single snapshot is available for this selection. See coverage and raw records, or select a native call from Model requests.")); return; }
  const data = dataOf(record);
  const batches = native ? (data.messages || []) : [[...(data.system_message ? [data.system_message] : []), ...(data.messages || [])]];
  batches.forEach((messages, batch) => messages.forEach((message, index) => {
    const card = node("article", "message-card");
    const role = message.type || message.role || "unknown";
    card.append(node("div", "message-role", `${role} · message ${index + 1}${batches.length > 1 ? ` · batch ${batch + 1}` : ""}${message.name ? ` · ${message.name}` : ""}`));
    if(presentation?.thinking_summary){const summary=disclosure('Thinking summary',presentation.thinking_summary,true);summary.classList.add('thinking-summary');card.append(summary);}
    if(presentation)card.append(node('pre','message-text',presentation.text||'No answer text recorded.'));
    else card.append(typeof message.content === "string" ? node("pre", "message-text", message.content) : jsonBlock(message.content));
    card.append(disclosure("Complete native message fields", message));
    holder.append(card);
  }));
  const fields = {...data};
  delete fields.messages;
  delete fields.system_message;
  holder.append(disclosure("Configuration and stage metadata", fields), disclosure("Redaction paths", record.payload.redactions));
}

function renderRequest() {
  const detail = state.requestDetail;
  if (!detail) return;
  const view = state.requestView, holder = $("request-content");
  holder.replaceChildren();
  for (const tab of document.querySelectorAll("[data-request-view]")) {
    tab.classList.toggle("active", tab.dataset.requestView === view);
    tab.setAttribute("aria-selected", String(tab.dataset.requestView === view));
  }
  if(view==='body')renderRequestBody(holder,detail);
  else if (["native", "effective", "original"].includes(view)) {
    const descriptions = {native: `Messages exposed at the native model callback. ${detail.provider?'The recorded HTTP JSON is available under Request body.':'No provider HTTP body was recorded.'}`, effective: "Complete request after middleware and context projection, before native model binding.", original: "Complete request entering the model wrappers, before planning guidance and context changes."};
    holder.append(node("p", "request-explanation", descriptions[view]));
    renderMessages(holder, detail[view], view === "native");
    if (view === "native" && detail.completion) holder.append(disclosure("Completion, response, and usage", detail.completion));
  } else if (view === "response") {
    const stream=detail.stream_presentation;
    if(stream?.thinking_summary&&!(detail.response_messages||[]).some(m=>m.presentation.thinking_summary)){
      const summary=disclosure('Thinking summary · captured stream',stream.thinking_summary,true);summary.classList.add('thinking-summary');holder.append(summary);
    }
    if (!detail.completion) {
      holder.append(node("p", "empty",detail.native?"Waiting for a linked completion. Streamed content below is partial.":"No explicitly linked completion recorded."));
      if(stream?.text)holder.append(node('pre','message-text',stream.text));
    }
    else {
      const response = dataOf(detail.completion);
      holder.append(fields({model: response.model, outcome: response.completion,
        duration: duration(response.duration), usage: response.usage || response.partial_usage || 'Unavailable',
        usage_coverage: response.usage_coverage || 'Unavailable'}));
      for (const item of detail.response_messages || []) renderMessages(holder, {payload:{data:{messages:[item.message]},redactions:detail.completion.payload.redactions}},false,item.presentation);
      holder.append(disclosure("Complete response and usage", detail.completion));
    }
  } else if (view === "tools") {
    for (const [title, tools] of [["Effective model-facing tools", dataOf(detail.effective)?.tools], ["Native bound tools", dataOf(detail.native)?.invocation_params?.tools]]) {
      holder.append(node("h4", "", title));
      if (!tools) holder.append(node("p", "request-explanation", "Not exposed at this stage."));
      else if (!tools.length) holder.append(node("p", "request-explanation", "No tools at this stage."));
      else for (const tool of tools) holder.append(disclosure(tool.name || tool.function?.name || tool.type || "Tool definition", tool));
    }
    holder.append(disclosure("Tool choice and response format", {tool_choice: dataOf(detail.effective)?.tool_choice, response_format: dataOf(detail.effective)?.response_format, native_parameters: dataOf(detail.native)?.invocation_params}));
  } else if (view === "skills") {
    holder.append(node("p", "request-explanation", "Available, loaded, and present in this request are separate facts. Presence does not establish that instructions were followed."));
    if (!detail.definition) holder.append(node("p", "empty", "Skill catalog unavailable for this recorded run."));
    else if (!detail.skills.length) holder.append(node("p", "empty", "No skills in this agent definition."));
    for (const skill of detail.skills) {
      const card = node("article", "message-card");
      card.append(node("h4", "", skill.name), node("p", "skill-status", `Available · ${skill.loaded ? "Loaded" : "Not loaded"} · ${skill.presence.replaceAll("_", " ")}`), node("p", "", skill.description),
        disclosure("Full skill body", skill.body, true), disclosure("Exact included messages", skill.included_messages), disclosure("Load attempts and outcomes", skill.load_attempts));
      holder.append(card);
    }
  } else if (view === "changes") {
    const before = dataOf(detail.original), after = dataOf(detail.effective);
    const changed = before && after ? ["system_message", "messages", "tools", "model", "model_settings", "response_format", "tool_choice"].filter(key => JSON.stringify(before[key]) !== JSON.stringify(after[key])) : null;
    holder.append(node("p", "request-explanation", changed ? `Changed components: ${changed.join(", ") || "none"}. Both complete snapshots are retained.` : "A comparison requires both original and effective snapshots."));
    const columns = node("div", "request-comparison");
    columns.append(disclosure("Original request — full snapshot", detail.original), disclosure("Effective request — full snapshot", detail.effective));
    holder.append(columns);
    const transforms = detail.records.filter(event => event.event_name.startsWith("context.") || event.event_name === "capture.planning_directive");
    for (const event of transforms) holder.append(disclosure(`${event.event_name} · #${event.cursor}`, event, true));
    if (!transforms.length) holder.append(node("p", "request-explanation", "No explicit context or planning transformations recorded for this selection."));
  } else if (view === "definition") {
    if (!detail.definition) holder.append(node("p", "empty", "Definition unavailable. Historical content is not reconstructed from current files."));
    else {
      const definition = detail.definition_data ?? dataOf(detail.definition);
      holder.append(node("h4", "", "Full system prompt"), node("pre", "message-text", definition.system_prompt));
      if (definition.planning_directive != null) holder.append(disclosure("Planning directive", definition.planning_directive, true));
      holder.append(disclosure("Complete run-linked definition", detail.definition));
    }
  } else holder.append(disclosure("Complete selected request and related records", detail, true));
}

function exportRequest(jsonl = false) {
  if (!state.requestDetail) return;
  const detail = state.requestDetail;
  const records = [detail.definition, ...detail.records, ...detail.load_events].filter(Boolean);
  const unique = [...new Map(records.map(record => [record.event_id || record.cursor, record])).values()];
  const manifest = {source:state.database?.path,database_identity:state.database?.identity,
    run_id:detail.run_id,selected_cursor:detail.selected_cursor,context:detail.context,
    coverage:detail.coverage,exported_at:new Date().toISOString()};
  const content = jsonl ? [JSON.stringify({manifest}), ...unique.map(record => JSON.stringify(record))].join("\n") + "\n" : JSON.stringify({manifest,...detail}, null, 2) + "\n";
  const url = URL.createObjectURL(new Blob([content], {type: jsonl ? "application/x-ndjson" : "application/json"}));
  const link = node("a");
  link.href = url;
  link.download = `model-request-${detail.selected_cursor}.${jsonl ? "jsonl" : "json"}`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
