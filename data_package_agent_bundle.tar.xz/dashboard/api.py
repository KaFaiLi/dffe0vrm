"""HTTP query validation for the dashboard's inspection projections."""

from __future__ import annotations

import math
import time
from typing import Any

try:
    from . import inspection
    from .conversation_view import conversation, thinking, usage
except ImportError:
    import inspection
    from conversation_view import conversation, thinking, usage

WINDOWS = {"1h": 3600, "24h": 86400, "7d": 604800, "all": None}


def route(db: Any, path: str, query: dict, database_path: Any) -> tuple[bool, dict | None]:
    def text(name: str, default: str = "") -> str:
        value = query.get(name, [default])[0]
        if len(value) > 2048:
            raise ValueError("Query value too long")
        return value

    def integer(name: str, default: int = 0, maximum: int = 2**63 - 1) -> int:
        value = int(text(name, str(default)))
        if not 0 <= value <= maximum:
            raise ValueError(f"Invalid {name}")
        return value

    def timestamp(name: str, default: float | None = None) -> float | None:
        value = text(name)
        result = float(value) if value else default
        if result is not None and (not math.isfinite(result) or result < 0):
            raise ValueError(f"Invalid {name}")
        return result

    def since() -> float:
        window = text("window", "all")
        if window not in WINDOWS:
            raise ValueError("Unknown time window")
        seconds = WINDOWS[window]
        return timestamp("since", time.time() - seconds if seconds else 0)

    def events(root_id: str = "", category: str = "") -> dict:
        return inspection.event_list(
            db,
            root_id=root_id or text("root"),
            run_id=text("agent"),
            after=integer("after"),
            before=integer("before"),
            limit=integer("limit", 100, 250) or 1,
            latest=text("latest") == "1",
            process=text("process"),
            category_filter=category or text("category"),
            severity=text("severity"),
            logger=text("logger"),
            q=text("q"),
            since=since(),
            until=timestamp("until"),
            unscoped=text("unscoped") == "1",
            round_id=text("round"),
            native_id=text("native"),
        )

    if path == "/api/database":
        return True, inspection.database_info(db, database_path)
    if path == "/api/runs":
        return True, inspection.run_list(
            db,
            since=since(),
            after=text("after"),
            limit=integer("limit", 30, 100) or 1,
            q=text("q"),
            status=text("status"),
            thread_id=text("thread"),
        )
    if path in ("/api/events", "/api/feedback"):
        return True, events(category="feedback" if path.endswith("feedback") else "")
    if path == "/api/metric-series":
        if not text("name"):
            raise ValueError("Metric name required")
        return True, inspection.metric_history(
            db, text("name"), text("process"), integer("offset"), integer("limit", 50, 100) or 1
        )
    if path == "/api/processes" or path.startswith("/api/processes/"):
        selected = path[len("/api/processes/") :] if path.startswith("/api/processes/") else ""
        return True, inspection.processes(
            db, integer("offset"), integer("limit", 50, 100) or 1, selected
        )
    if path == "/api/metrics" or path.startswith("/api/metrics/"):
        collection = path[len("/api/metrics/") :] if path.startswith("/api/metrics/") else ""
        result = inspection.metrics(
            db, integer("offset"), integer("limit", 25, 100) or 1, text("process"), collection
        )
        if result and "records" in result:
            result["series"] = inspection.metric_series(result["records"])
        return True, result
    if path.startswith("/api/traces/"):
        parts = path.split("/")
        if len(parts) == 6 and parts[4] == "spans":
            return True, inspection.span_detail(db, parts[3], parts[5])
        return True, None
    if path.startswith("/api/runs/"):
        parts = path[len("/api/runs/") :].split("/")
        if len(parts) != 2 or parts[1] not in (
            "conversation",
            "thinking",
            "usage",
            "records",
            "tools",
            "spans",
            "activity",
        ):
            return False, None
        run_id, view = parts
        if inspection.scope(db, run_id) is None:
            return True, None
        offset, limit = integer("offset"), integer("limit", 50, 100) or 1
        if view == "conversation":
            return True, conversation(db, run_id, offset, limit, text("item") or None)
        if view == "thinking":
            return True, thinking(db, run_id, offset, limit, text("id") or None)
        if view == "usage":
            return True, usage(db, run_id, offset, limit)
        if view == "records":
            return True, inspection.run_records(db, run_id)
        if view == "tools":
            selected = text("id") or None
            groups = inspection.tool_groups(db, run_id, selected=selected)
            if selected:
                return True, groups[0] if groups else None
            return True, {
                "items": groups[offset : offset + limit],
                "has_more": len(groups) > offset + limit,
                "offset": offset,
                "total": len(groups),
            }
        if view == "spans":
            return True, inspection.span_list(db, run_id, offset, limit)
        run = inspection.scope(db, run_id)
        # Child selections must not widen silently to their siblings.
        if run["parent_run_id"]:
            query = {**query, "agent": [run_id]}
        return True, events(root_id=run["root_run_id"])
    return False, None
