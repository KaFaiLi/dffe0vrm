"""Read-only projections of explicitly correlated model observations (stdlib only)."""

try:
    from .message_view import present_message, stream_parts
    from .records import document, json_sql
except ImportError:
    from message_view import present_message, stream_parts
    from records import document, json_sql


def scope_of(db, run_id):
    return db.execute("SELECT run_id,root_run_id FROM runs WHERE run_id=?", (run_id,)).fetchone()


def _definition_data(definition: dict | None) -> dict:
    """Project current or historically nested definitions without altering raw evidence."""
    data = (definition or {}).get("payload", {}).get("data", {})
    if not isinstance(data, dict):
        return {}
    if (
        data.get("schema_version") == 1
        and isinstance(data.get("data"), dict)
        and isinstance(data.get("redactions"), list)
    ):
        return data["data"]
    return data


def request_list(db, run_id, after, limit):
    scope = scope_of(db, run_id)
    if scope is None:
        return None
    # Project list fields in SQL: never transfer complete prompts into list responses.
    payload, native_payload = json_sql("e.payload"), json_sql("n.payload")
    rows = db.execute(
        f"""
        SELECT e.cursor,e.timestamp,e.run_id,e.event_name,
               json_extract({payload},'$.context.round_id') round_id,
               json_extract({payload},'$.context.request_id') request_id,
               json_extract({payload},'$.context.purpose') purpose,
               json_extract({payload},'$.data.native_run_id') native_run_id,
               CASE WHEN e.event_name='model.started' THEN coalesce(
                 json_extract({payload},'$.data.model'),
                 json_extract({payload},'$.data.metadata.ls_model_name'))
                    ELSE json_extract({payload},'$.data.model.name') END model,
               CASE WHEN json_extract({payload},'$.context.request_id') IS NOT NULL
                     OR json_extract({payload},'$.context.round_id') IS NOT NULL THEN 'explicit'
                     ELSE 'unavailable' END correlation,
               r.agent_name
        FROM events e JOIN runs r ON r.run_id=e.run_id
        WHERE e.root_run_id=? AND (?=? OR e.run_id=?) AND e.cursor>? AND (
          e.event_name='model.started' OR
          (e.event_name='capture.model_request' AND NOT EXISTS (
            SELECT 1 FROM events n WHERE n.run_id=e.run_id AND n.event_name='model.started'
            AND json_extract({native_payload},'$.context.request_id')=
              json_extract({payload},'$.context.request_id')
          )) OR
          (e.event_name='model.round.started' AND NOT EXISTS (
            SELECT 1 FROM events n WHERE n.run_id=e.run_id
            AND n.event_name IN ('capture.model_request','model.started')
            AND json_extract({native_payload},'$.context.round_id')=
              json_extract({payload},'$.context.round_id')
          ))
        ) ORDER BY e.cursor LIMIT ?
    """,
        (scope["root_run_id"], run_id, scope["root_run_id"], run_id, after, limit + 1),
    ).fetchall()
    items = [dict(row) for row in rows[:limit]]
    return {
        "items": items,
        "has_more": len(rows) > limit,
        "next_cursor": items[-1]["cursor"] if items else None,
    }


def request_detail(db, run_id, cursor):
    """Read one model request and its explicitly correlated evidence.

    Return None when the run or selected request is outside the requested scope
    or absent. The result retains the raw definition record and adds
    ``definition_data`` for display, unwrapping historical nested envelopes;
    missing definitions produce an empty display mapping. Queries do not modify
    stored records or reconstruct missing evidence from current application files.
    """
    scope = scope_of(db, run_id)
    if scope is None:
        return None
    selected = db.execute(
        """SELECT * FROM events WHERE cursor=? AND root_run_id=?
        AND (?=? OR run_id=?) AND event_name IN
        ('model.started','capture.model_request','model.round.started')""",
        (cursor, scope["root_run_id"], run_id, scope["root_run_id"], run_id),
    ).fetchone()
    if selected is None:
        return None
    selected = document(selected)
    owner = selected["run_id"]
    context = selected["payload"].get("context", {})
    round_id, request_id = context.get("round_id"), context.get("request_id")
    native_id = selected["payload"].get("data", {}).get("native_run_id")
    payload = json_sql()
    records = [
        document(row)
        for row in db.execute(
            f"""SELECT * FROM events WHERE run_id=? AND (
        (json_extract({payload},'$.context.request_id')=? AND ? IS NOT NULL) OR
        (json_extract({payload},'$.context.round_id')=? AND ? IS NOT NULL
          AND (json_extract({payload},'$.context.request_id') IS NULL OR ? IS NULL)) OR
        (json_extract({payload},'$.data.native_run_id')=? AND ? IS NOT NULL) OR cursor=?
        ) ORDER BY cursor""",
            (
                owner,
                request_id,
                request_id,
                round_id,
                round_id,
                request_id,
                native_id,
                native_id,
                cursor,
            ),
        )
    ]
    definition_row = db.execute(
        """SELECT * FROM events WHERE run_id=?
        AND event_name='capture.run_definition' ORDER BY cursor LIMIT 1""",
        (owner,),
    ).fetchone()
    definition = document(definition_row) if definition_row else None
    definition_data = _definition_data(definition)
    valid_records = [e for e in records if not e["payload"].get("record_error")]
    originals = [e for e in valid_records if e["event_name"] == "model.round.started"]
    effective = [e for e in valid_records if e["event_name"] == "capture.model_request"]
    selected_effective = effective[0] if len(effective) == 1 else None
    natives = [e for e in valid_records if e["event_name"] == "model.started"]
    native = next(
        (e for e in natives if e["payload"]["data"].get("native_run_id") == native_id), None
    )
    if native is None and len(natives) == 1:
        native = natives[0]
    messages = native["payload"]["data"].get("messages", []) if native else []
    messages = (
        [m for batch in messages for m in batch]
        if native
        else (
            selected_effective["payload"]["data"].get("messages", []) if selected_effective else []
        )
    )
    history = messages + (originals[0]["payload"]["data"].get("messages", []) if originals else [])
    # Only explicit call IDs establish that a loaded skill is in this call's input.
    loads = [
        document(row)
        for row in db.execute(
            f"""SELECT * FROM events WHERE run_id=? AND cursor<?
        AND ((event_name='tool.call.started' AND json_extract({payload},'$.data.name')='load_skill')
          OR (event_name='tool.finished'
              AND json_extract({payload},'$.data.call.name')='load_skill'))
        ORDER BY cursor""",
            (owner, native["cursor"] if native else cursor),
        )
    ]
    skills = []
    for skill in definition_data.get("skills", []):
        attempts = [
            e
            for e in loads
            if (
                e["payload"]["data"].get("call", e["payload"]["data"]).get("args", {}).get("name")
                == skill["name"]
            )
        ]
        successes = [
            e
            for e in attempts
            if e["event_name"] == "tool.finished"
            and not e["payload"]["data"].get("error_results")
            and e["payload"]["data"].get("result", {}).get("status") == "success"
        ]
        call_ids = {e["payload"]["data"]["call"]["id"] for e in successes}
        # Checkpoint history can contain a load from an earlier invocation. Pair
        # native AI/tool messages rather than guessing from current catalog text.
        historical_calls = {
            call["id"]
            for message in history
            if isinstance(message, dict)
            for call in message.get("tool_calls", [])
            if call.get("name") == "load_skill"
            and call.get("args", {}).get("name") == skill["name"]
        }
        historical_results = [
            m
            for m in history
            if isinstance(m, dict)
            and m.get("type") == "tool"
            and m.get("tool_call_id") in historical_calls
            and m.get("status") == "success"
        ]
        call_ids.update(m["tool_call_id"] for m in historical_results)
        included = [
            m
            for m in messages
            if isinstance(m, dict) and m.get("type") == "tool" and m.get("tool_call_id") in call_ids
        ]
        skills.append(
            {
                **skill,
                "load_attempts": attempts,
                "loaded": bool(successes or historical_results),
                "presence": (
                    "present"
                    if included
                    else "removed_or_not_retained"
                    if successes or historical_results
                    else "load_failed_or_pending"
                    if attempts
                    else "not_loaded"
                ),
                "included_messages": included,
            }
        )
    finished = [
        e
        for e in records
        if e["event_name"] == "model.finished"
        and (
            not native
            or e["payload"]["data"].get("native_run_id")
            == native["payload"]["data"]["native_run_id"]
        )
    ]
    coverage = {
        "definition": "captured" if definition else "unavailable",
        "round_input": "captured" if originals else "unavailable",
        "effective_request": "captured"
        if selected_effective
        else "multiple_requests"
        if effective
        else "unavailable",
        "native_model_input": "captured"
        if native
        else "multiple_calls"
        if natives
        else "not_observed"
        if request_id or round_id
        else "unavailable",
        "correlation": "explicit"
        if request_id or round_id
        else "native_call_only"
        if native_id
        else "unavailable",
        "provider_http_body": "not_observed",
    }
    if native:
        coverage.update(native["payload"]["data"].get("coverage", {}))
    provider_requests = [
        e
        for e in records
        if e["event_name"] == "capture.provider_request"
        and request_id is not None
        and e["payload"].get("context", {}).get("request_id") == request_id
    ]
    provider = provider_requests[0] if len(provider_requests) == 1 else None
    coverage["provider_http_body"] = (
        "captured" if provider else "multiple_requests" if provider_requests else "not_observed"
    )
    completion = finished[-1] if finished else None
    response = (completion or {}).get("payload", {}).get("data", {}).get("response")
    generations = response.get("generations", []) if isinstance(response, dict) else []
    response_messages = [
        {"message": g["message"], "presentation": present_message(g["message"])}
        for batch in generations or []
        if isinstance(batch, list)
        for g in batch
        if isinstance(g, dict) and isinstance(g.get("message"), dict)
    ]
    stream_records = [
        e
        for e in records
        if native
        and e["event_name"] == "capture.model.stream"
        and e["payload"]["data"].get("native_run_id")
        == native["payload"]["data"].get("native_run_id")
    ]
    stream = [stream_parts(e["payload"]["data"]) for e in stream_records]
    stream_presentation = {
        "text": "".join(p["text"] for p in stream),
        "thinking_summary": "".join(p["thinking_summary"] for p in stream),
        "sources": [e["cursor"] for e in stream_records],
    }
    return {
        "root_run_id": scope["root_run_id"],
        "run_id": owner,
        "selected_cursor": cursor,
        "context": context,
        "coverage": coverage,
        "definition": definition,
        "definition_data": definition_data,
        "original": originals[0] if originals else None,
        "effective": selected_effective,
        "native": native,
        "provider": provider,
        "skills": skills,
        "completion": completion,
        "response_messages": response_messages,
        "stream_presentation": stream_presentation,
        "records": records,
        "load_events": loads,
    }
