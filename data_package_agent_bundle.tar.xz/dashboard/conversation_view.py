"""Conversation and usage projections over recorded messages, without runtime imports."""

from __future__ import annotations

import json
from typing import Any

try:
    from .message_view import present_message, stream_parts
    from .records import data, document, json_sql, preview, scope, usage_total
except ImportError:
    from message_view import present_message, stream_parts
    from records import data, document, json_sql, preview, scope, usage_total


def model_calls(
    db: Any, run_id: str, *, descendants: bool = False, messages: bool = False
) -> list[dict]:
    """Pair native calls using recorded IDs, never arrival proximity."""
    payload = json_sql("e.payload")
    response = f"json_extract({payload},'$.data.response.generations')" if messages else "NULL"
    rows = db.execute(
        f"""
        SELECT e.cursor,e.event_name,e.run_id,e.timestamp,e.trace_id,e.span_id,
          json_extract({payload},'$.data.native_run_id') native_id,
          json_extract({payload},'$.context.round_id') round_id,
          json_extract({payload},'$.context.request_id') request_id,
          json_extract({payload},'$.context.purpose') purpose,
          coalesce(json_extract({payload},'$.data.model.name'),
                   json_extract({payload},'$.data.model'),
                   json_extract({payload},'$.data.metadata.ls_model_name')) model,
          json_extract({payload},'$.data.duration') duration,
          json_extract({payload},'$.data.completion') completion,
          json_extract({payload},'$.data.usage') usage,
          json_extract({payload},'$.data.partial_usage') partial_usage,
          json_extract({payload},'$.data.usage_coverage') usage_coverage,
          {response} generations,
          (SELECT json_extract(m.value,'$.id')
             FROM json_each({payload},'$.data.messages') b, json_each(b.value) m
             WHERE e.event_name='model.started' AND json_valid(m.value)
               AND coalesce(json_extract(m.value,'$.type'),json_extract(m.value,'$.role'))
                 IN ('human','user')
             ORDER BY CAST(b.key AS INTEGER) DESC,CAST(m.key AS INTEGER) DESC LIMIT 1) human_id
        FROM events e WHERE e.{"root_run_id" if descendants else "run_id"}=?
          AND e.event_name IN ('model.started','model.finished','model.first_token')
        ORDER BY e.cursor
    """,
        (run_id,),
    ).fetchall()
    calls: dict[tuple, dict] = {}
    for row in rows:
        r = dict(row)
        identity = r["native_id"] or (
            f"span:{r['trace_id']}:{r['span_id']}"
            if r["span_id"] and r["trace_id"]
            else f"event:{r['cursor']}"
        )
        key = (r["run_id"], identity)
        call = calls.setdefault(
            key,
            {
                "id": identity,
                "run_id": r["run_id"],
                "cursor": r["cursor"],
                "request_cursor": None,
                "timestamp": r["timestamp"],
                "status": "incomplete",
                "native_id": r["native_id"],
                "round_id": None,
                "request_id": None,
                "purpose": None,
                "model": None,
                "human_id": None,
                "usage": None,
                "usage_coverage": "unknown",
                "duration": None,
                "first_token": None,
                "sources": [],
                "message_ids": [],
                "messages": [],
                "started": False,
            },
        )
        call["sources"].append(r["cursor"])
        for field in ("round_id", "request_id", "purpose", "model", "human_id"):
            if r[field] is not None:
                call[field] = r[field]
        if r["event_name"] == "model.started":
            call["request_cursor"] = r["cursor"]
            call["started"] = True
        elif r["event_name"] == "model.first_token":
            call["first_token"] = r["duration"]
        else:
            call["completion_cursor"] = r["cursor"]
            call["status"] = r["completion"] or "unknown"
            call["duration"] = r["duration"]
            raw_usage = r["usage"] or r["partial_usage"]
            try:
                parsed_usage = json.loads(raw_usage) if isinstance(raw_usage, str) else None
            except ValueError:
                parsed_usage = None
            call["usage"] = parsed_usage if isinstance(parsed_usage, dict) else None
            call["usage_coverage"] = (
                "reported" if r["usage"] else "partial" if r["partial_usage"] else "unknown"
            )
            if not call["usage"]:
                call["usage_coverage"] = "unknown"
            elif not all(
                isinstance(call["usage"].get(k), (int, float))
                for k in ("input_tokens", "output_tokens")
            ):
                call["usage_coverage"] = "partial"
            generations = json.loads(r["generations"]) if r["generations"] else []
            call["messages"] = [
                g["message"]
                for batch in generations
                if isinstance(batch, list)
                for g in batch
                if isinstance(g, dict) and isinstance(g.get("message"), dict)
            ]
            call["message_ids"] = [m["id"] for m in call["messages"] if m.get("id")]
    result = list(calls.values())
    if messages:
        add_call_content(db, run_id, result)
    return result


def add_call_content(db: Any, run_id: str, calls: list[dict]) -> None:
    """Retain exposed stream summaries even when terminal answer messages omit them."""
    by_native = {c["native_id"]: c for c in calls if c["native_id"]}
    fragments: dict[str, list] = {}
    p = json_sql()
    if by_native:
        for row in db.execute(
            f"""SELECT cursor,json_extract({p},'$.data') values_json FROM events
                WHERE run_id=? AND event_name='capture.model.stream' ORDER BY cursor""",
            (run_id,),
        ):
            values = json.loads(row["values_json"]) if row["values_json"] else {}
            if not isinstance(values, dict):
                continue
            identity = values.get("native_run_id")
            if identity in by_native:
                fragments.setdefault(identity, []).append(
                    {"cursor": row["cursor"], **stream_parts(values)}
                )
    for call in calls:
        parts = fragments.get(call["native_id"], [])
        summaries = [present_message(m)["thinking_summary"] for m in call["messages"]]
        terminal = "\n\n".join(s for s in summaries if s)
        stream_summary = "".join(p["thinking_summary"] for p in parts)
        call["thinking_summary"] = terminal or stream_summary
        call["thinking_source"] = (
            "native response"
            if terminal
            else "stream fragments"
            if stream_summary
            else "unavailable"
        )
        call["thinking_cursors"] = (
            [call["completion_cursor"]]
            if terminal
            else [p["cursor"] for p in parts if p["thinking_summary"]]
        )
        call["stream_message"] = None
        if parts:
            call["sources"].extend([parts[0]["cursor"], parts[-1]["cursor"]])
        if not call["messages"] and parts:
            text = "".join(p["text"] for p in parts)
            if text or stream_summary:
                call["stream_message"] = {
                    "type": "ai",
                    "id": f"stream:{call['native_id']}",
                    "content": text,
                    "additional_kwargs": {"reasoning_content": stream_summary},
                }
                call["message_ids"].append(call["stream_message"]["id"])
                call["fragment_cursors"] = [p["cursor"] for p in parts]


def call_preview(call: dict) -> dict:
    result = {
        k: v
        for k, v in call.items()
        if k not in ("messages", "stream_message", "thinking_summary", "fragment_cursors")
    }
    summary = call.get("thinking_summary", "")
    result.update(
        thinking_preview=preview(summary, 1600),
        thinking_available=bool(summary),
        thinking_complete=len(summary) <= 1600,
    )
    return result


def thinking(
    db: Any, run_id: str, offset: int = 0, limit: int = 50, identity: str | None = None
) -> dict | None:
    if scope(db, run_id) is None:
        return None
    calls = model_calls(db, run_id, messages=True)
    if identity is not None:
        call = next((c for c in calls if c["id"] == identity), None)
        return (
            {**call_preview(call), "thinking_summary": call["thinking_summary"]} if call else None
        )
    return {
        "run_id": run_id,
        "items": [call_preview(c) for c in calls[offset : offset + limit]],
        "offset": offset,
        "total_calls": len(calls),
        "summary_calls": sum(bool(c["thinking_summary"]) for c in calls),
        "has_more": offset + limit < len(calls),
        "coverage": "Recorded model-exposed summaries; missing summaries are not inferred.",
    }


def usage(db: Any, run_id: str, offset: int = 0, limit: int = 50) -> dict | None:
    run = scope(db, run_id)
    if run is None:
        return None
    is_root = run_id == run["root_run_id"]
    calls = model_calls(db, run_id, descendants=is_root)
    by_agent: dict[str, list] = {}
    for call in calls:
        by_agent.setdefault(call["run_id"], []).append(call)
    summary = run["summary"].get("data", {}).get("summary", {})
    total = usage_total(calls)
    differences = {
        k: total[k if k == "model_calls" else "reported_" + k] - summary[k]
        for k in ("model_calls", "input_tokens", "output_tokens")
        if isinstance(summary.get(k), (int, float))
    }
    return {
        "run_id": run_id,
        "scope": "root and descendants" if is_root else "selected agent only",
        "total": total,
        "calls": calls[offset : offset + limit],
        "total_calls": len(calls),
        "has_more": offset + limit < len(calls),
        "offset": offset,
        "agents": [{"run_id": owner, **usage_total(items)} for owner, items in by_agent.items()],
        "recorded_summary": summary,
        "summary_difference": differences,
        "reconciliation": "different"
        if any(differences.values())
        else "agrees"
        if differences
        else "unavailable",
    }


def input_messages(run: dict) -> list[dict]:
    value = data(run).get("input", {})
    value = value.get("messages", []) if isinstance(value, dict) else []
    return [m for m in value if isinstance(m, dict)] if isinstance(value, list) else []


def transcript(db: Any, run_id: str) -> dict | None:
    """Build a source-linked sequence; final graph output is authoritative when present."""
    run = scope(db, run_id)
    if run is None:
        return None
    calls = model_calls(db, run_id, messages=True)
    inputs = input_messages(run)
    p = json_sql()
    output = db.execute(
        f"""SELECT * FROM events WHERE run_id=? AND event_name='capture.output'
        AND json_type({p},'$.data.messages')='array' ORDER BY cursor DESC LIMIT 1""",
        (run_id,),
    ).fetchone()
    latest_output = document(output) if output else None
    initial_ids = {m.get("id") for m in inputs if m.get("id")}
    sequence: list[tuple[dict, dict]] = []
    if latest_output:
        sequence = [
            (
                m,
                {
                    "table": "events",
                    "cursor": latest_output["cursor"],
                    "index": i,
                    "field": "data.messages",
                },
            )
            for i, m in enumerate(data(latest_output)["messages"])
            if isinstance(m, dict)
        ]
    else:
        sequence = [
            (m, {"table": "runs", "run_id": run_id, "index": i, "field": "data.input.messages"})
            for i, m in enumerate(inputs)
        ]
        additions = []
        for call in calls:
            # Compaction responses are model evidence, not graph conversation messages.
            if call["purpose"] == "summary":
                continue
            for i, message in enumerate(call["messages"]):
                additions.append(
                    (
                        call.get("completion_cursor", call["cursor"]),
                        i,
                        message,
                        {
                            "table": "events",
                            "cursor": call.get("completion_cursor"),
                            "index": i,
                            "field": "data.response.generations",
                        },
                    )
                )
        # Tool responses belong to their recorded call ID.
        # Request histories are not new messages.
        for row in db.execute(
            "SELECT * FROM events WHERE run_id=? AND event_name='tool.finished' ORDER BY cursor",
            (run_id,),
        ):
            record = document(row)
            result = data(record).get("result")
            if not isinstance(result, dict):
                continue
            update = result.get("update")
            if isinstance(update, dict) and isinstance(update.get("messages"), list):
                # Native state tools (including write_todos) return a Command.
                results = update["messages"]
                field = "data.result.update.messages"
            else:
                results = [result]
                field = "data.result"
            for i, message in enumerate(results):
                if not isinstance(message, dict) or not (
                    message.get("type") == "tool" or message.get("tool_call_id")
                ):
                    continue
                additions.append(
                    (
                        row["cursor"],
                        i,
                        message,
                        {
                            "table": "events",
                            "cursor": row["cursor"],
                            "field": field,
                            "index": i,
                        },
                    )
                )
        # Completed messages replace streamed answers; summaries remain separate.
        for call in calls:
            if call["purpose"] == "summary":
                continue
            message = call["stream_message"]
            if message is None:
                continue
            cursors = call["fragment_cursors"]
            additions.append(
                (
                    cursors[0],
                    0,
                    message,
                    {
                        "table": "events",
                        "cursor": cursors[0],
                        "field": "data.chunk.message",
                        "stream_call_id": call["native_id"],
                        "fragment_cursors": cursors,
                    },
                )
            )
        sequence.extend(
            (m, source) for _, _, m, source in sorted(additions, key=lambda item: item[:2])
        )

    items, identities = [], {}
    for message, source in sequence:
        identity = message.get("id")
        key = (
            f"message:{identity}"
            if identity
            else f"source:{source['table']}:{source.get('cursor', run_id)}:{source['index']}"
        )
        if identity and key in identities:
            existing = items[identities[key]]
            existing["message"] = message
            existing["sources"].append(source)
            continue
        identities[key] = len(items)
        items.append({"key": key, "message": message, "sources": [source]})
    by_message = {}
    for call in calls:
        for identity in call["message_ids"]:
            by_message.setdefault(identity, []).append(call)
    turns, current = [], None
    message_turns = {}
    for item in items:
        message = item["message"]
        role = message.get("type") or message.get("role") or "unknown"
        item["role"] = {"human": "user", "ai": "assistant"}.get(role, role)
        if item["role"] == "user":
            current = item["key"]
            turns.append({"id": current, "number": len(turns) + 1, "usage": None})
        item["turn_id"] = current
        item["prior_context"] = (
            message.get("id") in initial_ids or item["sources"][0]["table"] == "runs"
        )
        item["calls"] = [c["id"] for c in by_message.get(message.get("id"), [])]
        item["presentation"] = present_message(message)
        linked = by_message.get(message.get("id"), [])
        item["thinking_source"] = "recorded message"
        if not item["presentation"]["thinking_summary"] and len(linked) == 1:
            item["presentation"]["thinking_summary"] = linked[0]["thinking_summary"]
            item["thinking_source"] = linked[0]["thinking_source"]
            item["thinking_sources"] = linked[0]["thinking_cursors"]
        item["streaming"] = bool(item["sources"][0].get("stream_call_id")) and any(
            c["status"] == "incomplete" for c in linked
        )
        if message.get("id"):
            message_turns[message["id"]] = current
    for call in calls:
        call["turn_id"] = message_turns.get(call["human_id"])
        if not call["turn_id"]:
            matching = {message_turns[mid] for mid in call["message_ids"] if mid in message_turns}
            if len(matching) == 1:
                call["turn_id"] = matching.pop()
        call.pop("messages", None)
    # A recorded round identity also links its auxiliary summary/retry calls.
    round_turns: dict[str, set] = {}
    for call in calls:
        if call["round_id"] and call["turn_id"]:
            round_turns.setdefault(call["round_id"], set()).add(call["turn_id"])
    for call in calls:
        candidates = round_turns.get(call["round_id"], set())
        if call["turn_id"] is None and len(candidates) == 1:
            call["turn_id"] = next(iter(candidates))
    rounds: dict[str, dict] = {}
    for call in calls:
        key = call["round_id"] or f"native:{call['id']}"
        group = rounds.setdefault(
            key,
            {
                "id": key,
                "kind": "round" if call["round_id"] else "call",
                "number": len(rounds) + 1,
                "calls": [],
                "cursor": call["cursor"],
            },
        )
        group["calls"].append(call)
    for row in db.execute(
        f"""SELECT cursor,json_extract({p},'$.context.round_id') id
        FROM events WHERE run_id=? AND event_name='model.round.started' ORDER BY cursor""",
        (run_id,),
    ):
        if row["id"] and row["id"] not in rounds:
            rounds[row["id"]] = {
                "id": row["id"],
                "kind": "round",
                "number": 0,
                "calls": [],
                "cursor": row["cursor"],
            }
    ordered_rounds = sorted(rounds.values(), key=lambda r: r["cursor"])
    for i, group in enumerate(ordered_rounds):
        group["number"] = i + 1
        group["usage"] = usage_total(group["calls"])
    for turn in turns:
        selected = [c for c in calls if c["turn_id"] == turn["id"]]
        turn["usage"] = usage_total(selected) if selected else None
    for group in ordered_rounds:
        group["calls"] = [call_preview(c) for c in group["calls"]]
    return {
        "run_id": run_id,
        "root_run_id": run["root_run_id"],
        "thread_id": run.get("thread_id"),
        "items": items,
        "turns": turns,
        "rounds": ordered_rounds,
        "calls": [call_preview(c) for c in calls],
        "usage": usage_total(calls),
        "unattributed_calls": sum(c["turn_id"] is None for c in calls),
        "source": "final output snapshot" if latest_output else "run input and native results",
        "coverage": (
            "No cross-run continuity inferred; messages without IDs retain source-local identity."
        ),
        "snapshot": latest_output["cursor"]
        if latest_output
        else max((c for call in calls for c in call["sources"]), default=0),
    }


def conversation(
    db: Any, run_id: str, offset: int = 0, limit: int = 50, item_key: str | None = None
) -> dict | None:
    value = transcript(db, run_id)
    if value is None:
        return None
    if item_key is not None:
        item = next((i for i in value["items"] if i["key"] == item_key), None)
        return {"run_id": run_id, **item} if item else None
    count = len(value["items"])
    selected = value["items"][offset : offset + limit]
    selected_calls = {identity for item in selected for identity in item["calls"]}
    selected_turns = {item["turn_id"] for item in selected}
    selected_rounds = [
        r for r in value["rounds"] if any(c["id"] in selected_calls for c in r["calls"])
    ]
    if offset == 0:
        selected_rounds.extend(
            r
            for r in value["rounds"]
            if r not in selected_rounds
            and (
                not r["calls"]
                or all(not c["message_ids"] or c["purpose"] == "summary" for c in r["calls"])
            )
        )
        selected_rounds = selected_rounds[:limit]
    selected_rounds.sort(key=lambda r: r["cursor"])
    selected_calls.update(c["id"] for r in selected_rounds for c in r["calls"])
    for item in selected:
        message = item.pop("message")
        presentation = item.pop("presentation")
        content, summary = presentation["text"], presentation["thinking_summary"]
        item.update(
            {
                "preview": preview(content, 1600),
                "thinking_preview": preview(summary, 1600),
                "thinking_available": bool(summary),
                "thinking_complete": len(summary) <= 1600,
                "message_id": message.get("id"),
                "name": message.get("name"),
                "tool_call_id": message.get("tool_call_id"),
                "tool_calls": [
                    {"id": c.get("id"), "name": c.get("name")}
                    for c in message.get("tool_calls", [])
                ],
                "content_complete": isinstance(content, str) and len(content) <= 1600,
                "structured_content": presentation["structured_content"],
            }
        )
    # The transcript is paged; usage is always for the complete recorded invocation.
    return {
        **value,
        "items": selected,
        "total_items": count,
        "offset": offset,
        "total_turns": len(value["turns"]),
        "total_rounds": len(value["rounds"]),
        "turns": [t for t in value["turns"] if t["id"] in selected_turns],
        "rounds": selected_rounds,
        "calls": [c for c in value["calls"] if c["id"] in selected_calls],
        "has_more": offset + limit < count,
        "next_offset": offset + limit,
    }
