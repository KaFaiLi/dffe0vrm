# Data Package Agent Observatory

A standalone, read-only conversation and evidence browser for the agent's
observability SQLite file. It uses Python's standard library and vanilla
HTML/CSS/JavaScript. It does not import the agent runtime or change recording.

## Run

From `private_suite/packages/data-package-agent/` (Python 3.12 or later):

```powershell
python dashboard/server.py
```

Open <http://127.0.0.1:8765>. The default database is
`.mcp_agent_template/observability/observability.sqlite3`. Choose another recording or port:

```powershell
python dashboard/server.py --db 'P:/path/to/observability.sqlite3' --port 8766
```

The viewer requires no third-party packages or corporate dependency installation.
With the package's uv environment available, `uv run --no-sync python
dashboard/server.py` launches the same viewer. When the agent uses a custom
`APP_ROOT` or `OBS_DIR`, pass the corresponding database with `--db`.

`MCP_AGENT_TEMPLATE_OBS_DB` also sets the source. The service binds to `127.0.0.1`, opens
SQLite with `mode=ro` and `PRAGMA query_only=ON`, and reads live WAL data without
copying it. Closed recordings without WAL sidecars use short-lived immutable
connections; subsequent requests check for a writer again. Stop with Ctrl+C.
Database information shows the actual source, schema, date range and row counts.

## Read conversations and usage

The sidebar lists recorded root invocations, with search, outcome/time filters
and paging. **Conversation** shows user/assistant messages, tool results, model
rounds and expandable activity. **Agent** switches to a recorded child; **Run
details** shows the agent tree and links separate invocations sharing a thread ID.
There is no composer: this screen inspects recorded work.

- Final graph output is the authoritative transcript when stored. Otherwise the
  dashboard combines run input, native completions, tool results and unfinished
  stream text. Request history snapshots are not appended as new messages.
- Same-ID messages replace earlier versions. Different IDs with identical text
  remain distinct. Missing IDs retain source-local identity.
- Turns start at recorded user messages. Round labels require recorded round IDs;
  older native-only records display **Call**. Retries and summary calls remain
  visible. Missing correlation is labelled and never inferred from nearby times.
- **Usage** counts each native model call once. Root totals include descendants;
  a child selection shows only that agent. The transcript's turn totals belong
  to that selected agent. Totals do not change when paging or collapsing rows.
- Known totals include labelled partial amounts. Unknown calls stay unknown.
  Complete reported amounts reconcile against the stored run summary. Cache and
  reasoning subdivisions remain available in selected usage; they are not added
  again to input/output totals. No cost or context-capacity estimate is invented.
- Earlier input history may lack usage for this invocation. Thread IDs link
  invocation segments; they do not establish a single continuous or unbranched chat.

Transcript pages contain 50 message previews; long previews scroll, and **Read
complete message** fetches the complete selected message. Model requests and
selected evidence preserve stored fields and redaction information.

Assistant messages show **Thinking summary** separately from answer text when
the model exposes a recorded summary. Normalized reasoning/thinking blocks and
current Responses content blocks are supported; encrypted reasoning is not decoded
and missing summaries are not inferred. Provider metadata and token-only callbacks
are no longer used as rendering fallbacks. Stream summaries update with **Follow latest**;
final responses replace streamed answer fragments without duplicating messages.
An explicitly linked stream summary remains available if a final message omits it.
Long summary previews have a **Read complete summary** action.

**Model timeline** lists each native call for the selected agent, including calls
without transcript messages. It shows summary source, outcome, duration, first
observed output, usage coverage and direct request/response links. First output
uses the recorder's existing content/reasoning/tool-fragment boundary; it is not
provider-only latency. Token subdivisions are not added to input/output totals.

The details sidebar can be widened by dragging its left edge on desktop. Focus
that edge and use Left/Right arrows to resize, or Home to reset its width.
**Expand ↗** opens the same details in a large reading view (full screen on narrow
devices), preserving open sections. **Restore sidebar** or Escape returns them
to the sidebar. Long text wraps in one scrolling content area while the heading
and window controls remain visible.

## Inspect execution evidence

Categories have separate colours and text labels: **LLM**, **Middleware**,
**Tool**, **MCP**, **Delegation**, **System log**, **Run / system**, **Recorder**,
**Feedback**, and **Other**. Severity/outcome is a separate badge, so a tool error
retains its tool category.

- **Activity** lists arrival-ordered source events, 100 per page, with older/newer
  paging and cursor selection. Filters cover category, outcome, process, logger,
  time and unscoped records. Search covers projected metadata and complete log
  messages; the selected-payload search covers its complete stored document.
- **Tools** groups logical calls and attempts using explicit call IDs or a uniquely
  shared trace/span. Arguments, policy, original/transformed/effective results,
  error results and complete source records remain expandable. Unlinked transport
  records remain independently available in Activity.
- **Model requests** retains original/effective/native inputs, complete tools and
  skills, context transformations, agent definition and raw records. **Response
  & usage** displays the linked completion. Native callback capture does not
  establish the provider's exact HTTP body. When an explicitly correlated
  `capture.provider_request` event exists, **Provider HTTP body** displays its
  recorded JSON. Multiple captures with the same identity remain ambiguous.
- **Trace** shows paginated span timing relative to root wall time, parent links
  and full selected attributes, events and links. Overlapping durations are not
  added together. Native spans can arrive after the event feed.
- Global **System events**, **All logs**, **Recorder & processes**, **Metric
  snapshots**, and **Feedback** work independently of a selected conversation.
  Process health is last recorded state, not OS liveness. Metric history retains
  SDK temporality and individual points; cumulative snapshots are never summed.

**Export JSON/JSONL** exports complete selected evidence. Request exports retain
coverage and deduplicated source events. All captured content renders as inert
text; page/preview limits never truncate stored or selected/exported payloads.

Polling checks event, span, process, metric and file watermarks every three seconds.
By default arrivals display **New records available** without moving the current
page or selection. **Follow latest**, **Pause refresh**, and manual **Refresh**
control reading. Run/agent/tab/event selection and event filters are saved in the
URL and checked against the configured database identity when reopening.

The model request inspector opens on **Request body**, preferring a recorded
provider body when available. Choose the provider, native, effective or original
stage to view its complete recorded JSON. **Copy body** and
**Download body** include the entire selected payload; the search highlights a
match without shortening the JSON. Native, effective and original stages are
capture-stage payloads; only the provider stage contains observed HTTP JSON.
Request selection, inspector tab and body stage
are included in the URL for reopening. **Response & usage** shows exposed thinking
summaries and partial streamed answer text while awaiting a linked completion.
**Follow this call** refreshes the open inspector as records arrive, preserving
disclosure state, body search and reading position. **Pause refresh** pauses these
automatic updates too. Capture coverage and recorded redaction paths remain available.

## Authorized local Foundry dashboard check

The opt-in development runner has a separate `data-package-agent-dashboard`
operation. Follow the isolated Python 3.12+ uv setup in [AGENTS.md](../AGENTS.md)
and supply the ignored local credential JSON and suite-root pricing JSON:

```powershell
uv @agentUv python ../../devtools/foundry_lab/run.py `
    --operation data-package-agent-dashboard `
    --config ../genai-api-manager/local_dev.json `
    --pricing ../../MODELS_PRICE1K_AZURE.json `
    --model gpt-6-luna --run-live
```

This uses the real `socgenai_llm` wrapper, agent, MCP stdio tool, Azure Responses
SDK and encrypted manager audit. It separately enables the agent's local
SQLite recorder and captures SDK HTTP JSON through its normal redactor, inside
the explicit request context. Headers and endpoint URLs are excluded. The
plaintext SQLite recording is sensitive; keep it in the ignored output folder.
This hook belongs to the development probe, not the shipped provider adapter.

The fixed synthetic Sudoku task derives two integers, calls `add(19, 23)` once
and replies `42`. Bounds remain two model calls, one tool call, 45 seconds per SDK
request and 150 seconds overall, with zero SDK retries. Each request allows
4,096 output tokens and requests `reasoning={"effort":"max","summary":"detailed"}`.
The capture hook verifies those options before dispatch. Omission of
`--agent-transport` uses manager internal streaming; `--agent-transport native`
explicitly selects native non-streaming Responses for a controlled comparison.
Provider SSE summary counters distinguish a missing provider summary from a
downstream capture loss, and summary hashes verify complete capture.
There is no provider/model fallback or automatic replay. Open the resulting
`../../devtools/foundry_lab/output/<id>/records/observability.sqlite3` with `--db`.

The probe requires an exposed summary for its overall success flag. An empty
provider summary therefore leaves `success=false` even when the agent, tool,
HTTP capture and accounting succeed. The dashboard labels missing summaries
without inventing text. The [2026-10-14 validation](../docs/review/dashboard-thinking-and-requests-validation-2026-10-14.md)
records the short-task omission and the detailed summary obtained with the
harder task. Max effort does not guarantee a summary on every call.

### Bounded tree, todo, and compaction workflow

For an explicitly authorized broader local check, run the isolated uv environment
from the package's [AGENTS.md](../AGENTS.md) with this distinct case:

```powershell
uv @agentUv python ../../devtools/foundry_lab/run.py `
    --operation data-package-agent --agent-case workflow `
    --config ../genai-api-manager/local_dev.json `
    --pricing ../../MODELS_PRICE1K_AZURE.json --model gpt-6-luna --run-live
```

The real coordinator and worker each create and complete their own native
`write_todos` checklist. The coordinator delegates once; the worker calls the
real MCP `add(19, 23)` tool and returns `42`. A fixed synthetic earlier history
forces coordinator history compaction before the current task. Its input budget
is sized from the actual prompt/tool schemas and token estimator, with enough
headroom to use one history-summary request. Success requires that summary to
occur, the archive to disappear only from outgoing model input, and the full
native history and both independent todo/tool traces to remain intact.

This case permits at most **12 model requests across the tree, including
summaries, and 8 tool calls**. Main and summary calls allow 4,096 output tokens,
with max reasoning, detailed summaries, zero SDK retries, and no sampling
parameters. SDK requests have a 45-second timeout; the root has a 240-second
deadline and an outer 270-second timeout. The manager's existing spending guard
remains active. No model/provider fallback or automatic replay is used. The
offline fixture completes with nine requests and six tools; live choices may
differ within the same bounds and strict result checks.

The safe summary verifies encrypted audit usage/cost against every request and
the exact logger ledger. It checks the closed SQLite recording through the
dashboard API projections: the parent/child tree, each agent's thinking timeline,
request-ID-correlated summary hashes, per-agent usage, complete native todo
transcripts, exclusion of auxiliary history-summary messages from conversations,
and a read-only database hash. Provider-exposed reasoning summaries can be absent;
their actual character counts are recorded without invention. A history-compaction
summary and an exposed reasoning summary are separate observations.

All SQLite content is synthetic but remains sensitive plaintext under the
ignored output directory; encrypted manager logs remain separate. This local
workflow does not establish corporate acceptance or provider billing. Offline
regressions in `devtools/tests/foundry/data_package_agent/test_workflow_probe.py` (suite-relative) use the actual graph, MCP subprocess,
wrapper and SDK over `MockTransport`, including failure without replay.

## Read-only API

| Route | Purpose |
| --- | --- |
| `/api/database` | Source identity, schema, counts and watermark |
| `/api/runs` | Run search, filters and keyset paging (`after`) |
| `/api/runs/{id}?spans=0` | Lightweight run tree and summaries |
| `/api/runs/{id}/conversation` | Transcript page; `item` selects a complete message |
| `/api/runs/{id}/thinking` | Selected-agent model timeline; `id` selects a complete summary |
| `/api/runs/{id}/usage` | Complete totals with paginated native calls |
| `/api/runs/{id}/records` | Full run records and recorded thread segments |
| `/api/runs/{id}/activity` | Scoped events; optional `round` or `native` ID |
| `/api/events`, `/api/events/{cursor}` | Global filtered paging and full event |
| `/api/runs/{id}/tools` | Tool groups; `id` selects complete linked evidence |
| `/api/runs/{id}/requests[/{cursor}]` | Model-request metadata and selected detail |
| `/api/runs/{id}/spans` | Paginated root-trace metadata |
| `/api/traces/{trace}/spans/{span}` | Complete selected span |
| `/api/processes[/{id}]` | Recorded process/recorder health |
| `/api/metrics[/{collection}]` | Metric snapshots and selected series |
| `/api/metric-series?name=...&process=...` | Recorded history without aggregation |
| `/api/feedback` | Recorded feedback events |

List APIs use bounded `limit` and `offset` except cursor/keyset routes. Event
paging accepts `after` or `before`, optionally `latest=1`. Full selected details
are not payload-capped. The source schema must be supported; malformed event
JSON is retained as raw evidence with a visible error.

The viewer supports storage version 2 only. It exposes complete
`events`, `runs`, `captures`, `logs` and `feedback` through SQLite views backed
by canonical events/content parts. Inspection includes views in its counts and
reconstructs full selected payloads through ordinary SQLite queries. Opening
the viewer never migrates or modifies databases. Unsupported versions are rejected.
See the [recording guide](../docs/observability.md#storage-version-and-complete-reads)
for current-schema initialization and handling of version-1 recordings.

## Validation

The request inspector displays current definitions and older nested definition
envelopes through a read-only projection. Raw records and JSON/JSONL exports
retain their original structure. New definitions include the selected skill
inventory; missing historical inventories remain unknown rather than being
reconstructed from today's application files.

From the agent package directory:

```powershell
python -m unittest discover -s dashboard/tests -v
uv run pytest tests dashboard/tests -q
node --check dashboard/static/app.js
node --check dashboard/static/request.js
node --test dashboard/tests/test_request_refresh.cjs dashboard/tests/test_dashboard_refresh.cjs
git diff --check
```

The copied dashboard tests use isolated SQLite fixtures. Agent integration tests
in `tests/test_dashboard.py` also inspect fresh records produced by the real
agent recorder with scripted model responses. Include both directories in the
pytest command to run the agent suite and copied dashboard regressions without
changing project test configuration. No model credentials are needed.

The Node tests execute the dashboard refresh and request inspector with a minimal
DOM and API fixture. They cover request stages arriving or disappearing during
follow, retrying failed refreshes when the database has not changed, and scrolling
the mounted transcript. Manual refresh and following preserve request selection,
search, disclosures and scroll position, including changes made while a fetch is
pending. They use only Node built-ins.

The [live workflow and dashboard review](../docs/review/live-agent-workflow-and-dashboard-validation-2026-10-14.md)
records the four authorized scenarios, actual token usage and calculated costs,
dashboard findings, regression checks and local evidence boundaries.

`validate_recordings.py` is retained from the donor for reviewing recordings
identified by its live-matrix report format. The agent does not include the
donor's live-matrix runner; that optional validator does not invoke models itself.

Copied from `mcp_agent_template donor/dashboard/` at commit
`782b3c03af3585458a555b958fe91dc7de821824`, with agent branding, documentation,
and Python formatting adapted. See the
[integration validation](../docs/review/dashboard-validation-2026-10-13.md)
for results and limitations.
