"""Validate dashboard projections against a fresh authenticated live-matrix report.

This reader does not invoke models. Run the complete live matrix first; the input
report identifies the actual invocations and diagnostics being reviewed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path

from conversation_view import transcript
from server import ObservationDB


def inspect_scenario(folder: Path, scenario: dict) -> dict:
    path = folder / "observations/observability.sqlite3"
    observations = ObservationDB(path)
    original_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    result = {
        "name": scenario["name"],
        "database": str(path),
        "root_run_ids": [],
        "transcript_messages": 0,
        "native_calls": 0,
        "tool_calls": 0,
        "request_inspections": 0,
        "projection_ms": [],
        "log_levels": {},
        "recording_health": [],
        "exports": [],
    }

    def get(route: str, **params):
        started = time.perf_counter()
        handled, value = observations.inspect(route, {k: [str(v)] for k, v in params.items()})
        assert handled and value is not None, "Projection unavailable"
        result["projection_ms"].append(round((time.perf_counter() - started) * 1000, 2))
        return value

    with closing(observations.connect()) as db:
        runs = db.execute("SELECT * FROM runs ORDER BY started").fetchall()
        result["root_run_ids"] = [r["run_id"] for r in runs if r["parent_run_id"] is None]
        for row in runs:
            run = row["run_id"]
            first = get(f"/api/runs/{run}/conversation", limit=5)
            last = get(
                f"/api/runs/{run}/conversation", offset=max(0, first["total_items"] - 5), limit=5
            )
            assert first["usage"] == last["usage"], "Paging changed usage totals"
            full = transcript(db, run)
            assert first["total_items"] == len(full["items"]), "Transcript count differs"
            identities = [i["message"]["id"] for i in full["items"] if i["message"].get("id")]
            assert len(identities) == len(set(identities)), "Repeated message IDs in transcript"
            result["transcript_messages"] += len(full["items"])
            if full["items"]:
                selected = max(full["items"], key=lambda item: len(json.dumps(item["message"])))
                detail = get(f"/api/runs/{run}/conversation", item=selected["key"])
                assert detail["message"] == selected["message"], "Selected message is incomplete"
            usage = get(f"/api/runs/{run}/usage")
            if row["parent_run_id"] is None:
                assert usage["reconciliation"] == "agrees", "Root summary and native usage disagree"
                result["native_calls"] += usage["total"]["model_calls"]
            tools = get(f"/api/runs/{run}/tools", limit=100)
            result["tool_calls"] += tools["total"]
            for tool in tools["items"]:
                detail = get(f"/api/runs/{run}/tools", id=tool["id"])
                for record in detail["records"]:
                    stored = db.execute(
                        "SELECT payload FROM events WHERE cursor=?", (record["cursor"],)
                    ).fetchone()[0]
                    assert record["payload"] == json.loads(stored), (
                        "Tool evidence differs from SQLite"
                    )
            requests = observations.requests(run, 0, 100)
            for request in requests["items"]:
                detail = observations.request(run, request["cursor"])
                assert detail and detail["run_id"] == request["run_id"]
                if detail["native"]:
                    stored = db.execute(
                        "SELECT payload FROM events WHERE cursor=?", (detail["native"]["cursor"],)
                    ).fetchone()[0]
                    assert detail["native"]["payload"] == json.loads(stored), (
                        "Request payload incomplete"
                    )
                    result["request_inspections"] += 1
            spans = get(f"/api/runs/{run}/spans", limit=100)
            if spans["items"]:
                span = spans["items"][0]
                detail = get(f"/api/traces/{span['trace_id']}/spans/{span['span_id']}")
                stored = db.execute(
                    "SELECT payload FROM spans WHERE trace_id=? AND span_id=?",
                    (span["trace_id"], span["span_id"]),
                ).fetchone()[0]
                assert detail["payload"] == json.loads(stored), "Span payload incomplete"
        processes = db.execute("SELECT * FROM processes").fetchall()
        assert all(
            p["stopped"] and p["health"] == "healthy" and p["unrecorded"] == 0 for p in processes
        ), "Incomplete process recording"
        for row in db.execute(
            "SELECT payload FROM events WHERE event_name='telemetry.session_finished'"
        ):
            health = json.loads(row[0])["data"]
            assert (
                not health.get("failed")
                and not health.get("unrecorded")
                and not health.get("recording_errors")
            ), "Recorder error"
            result["recording_health"].append(
                {
                    k: health.get(k)
                    for k in (
                        "pending_records",
                        "pending_bytes",
                        "written_records",
                        "unrecorded",
                        "failed",
                        "recording_errors",
                        "peak_pending_bytes",
                        "write_seconds",
                    )
                }
            )
        levels = Counter()
        for row in db.execute("SELECT payload FROM events WHERE event_name='log'"):
            value = json.loads(row[0])["data"]
            levels[str(value.get("level"))] += 1
        result["log_levels"] = dict(levels)
        cursor, seen = 0, 0
        while True:
            page = get("/api/events", after=cursor, limit=250)
            if not page["items"]:
                break
            seen += len(page["items"])
            cursor = page["last_cursor"]
            if not page["has_after"]:
                break
        assert seen == db.execute("SELECT COUNT(*) FROM events").fetchone()[0], (
            "Event paging lost records"
        )
        result["events_paged"] = seen
        snapshots = get("/api/metrics", limit=1)
        if snapshots["items"]:
            key = snapshots["items"][0]["collection_id"]
            detail = get(f"/api/metrics/{key}")
            assert detail["records"], "Metric snapshot missing"
            result["metric_series_in_selected_snapshot"] = len(detail["series"])
        for root in result["root_run_ids"]:
            json_files = sorted(folder.glob(f"{root}-*.json"))
            jsonl_files = sorted(folder.glob(f"{root}-*.jsonl"))
            assert json_files and jsonl_files, "Live archive exports absent"
            archive = json.loads(json_files[-1].read_text())
            lines = [json.loads(line) for line in jsonl_files[-1].read_text().splitlines()]
            assert archive["recording_status"] == "complete"
            assert len(archive["events"]) == sum(line.get("table") == "events" for line in lines)
            for event in archive["events"]:
                stored = db.execute(
                    "SELECT payload FROM events WHERE event_id=?", (event["event_id"],)
                ).fetchone()
                assert stored and json.loads(stored[0]) == event["payload"], (
                    "Export payload mismatch"
                )
            result["exports"].extend([str(json_files[-1]), str(jsonl_files[-1])])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == original_hash, (
        "Dashboard changed SQLite"
    )
    timings = result.pop("projection_ms")
    result["projection_count"] = len(timings)
    result["max_projection_ms"] = max(timings, default=0)
    result["mean_projection_ms"] = round(sum(timings) / len(timings), 2) if timings else 0
    result["readonly_sha256"] = original_hash
    result["status"] = "passed"
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live-report", type=Path, required=True)
    parser.add_argument(
        "--retry-report",
        type=Path,
        action="append",
        default=[],
        help="A fresh rerun of a failed scenario; original results remain in the review manifest",
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    live = json.loads(args.live_report.read_text())
    root = Path(live["observation_root"])
    report = {
        "reviewed_at": datetime.now(UTC).isoformat(),
        "live_report": str(args.live_report),
        "live_started": live["started"],
        "observation_root": str(root),
        "retry_reports": [str(p) for p in args.retry_report],
        "scenarios": [],
    }
    retries = {}
    for path in args.retry_report:
        retry = json.loads(path.read_text())
        for scenario in retry["scenarios"]:
            retries[scenario["name"]] = (scenario, Path(retry["observation_root"]), str(path))
    for scenario in live["scenarios"]:
        original = scenario
        folder = root / scenario["name"]
        retry_path = None
        if scenario["status"] != "passed" and scenario["name"] in retries:
            scenario, retry_root, retry_path = retries[scenario["name"]]
            folder = retry_root / scenario["name"]
        try:
            assert scenario["status"] == "passed", "Actual invocation did not pass"
            result = inspect_scenario(folder, scenario)
        except Exception as exc:
            result = {
                "name": scenario["name"],
                "status": "failed",
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
        result["original_invocation_status"] = original["status"]
        if retry_path:
            result["retry_report"] = retry_path
            result["original_error"] = {k: original.get(k) for k in ("error_type", "error")}
        report["scenarios"].append(result)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
        print(
            json.dumps({k: result.get(k) for k in ("name", "status", "error_type", "error")}),
            flush=True,
        )
    feature = next((s for s in report["scenarios"] if s["name"] == "request_inspection"), None)
    report["fresh_request_feature_case"] = bool(
        feature
        and feature["status"] == "passed"
        and feature["native_calls"]
        and feature["tool_calls"]
    )
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    return int(
        not report["fresh_request_feature_case"]
        or any(s["status"] != "passed" for s in report["scenarios"])
    )


if __name__ == "__main__":
    raise SystemExit(main())
