"""Read-only browser for the Data Package Agent observability SQLite database."""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sqlite3
import time
from contextlib import closing
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlsplit

try:
    from .api import route
    from .inspection import event_detail
    from .records import category, envelope, outcome
    from .request_view import request_detail, request_list
except ImportError:  # Standalone `python dashboard/server.py` entrypoint.
    from api import route
    from inspection import event_detail
    from records import category, envelope, outcome
    from request_view import request_detail, request_list


HERE = Path(__file__).resolve().parent
DEFAULT_DB = HERE.parent / ".mcp_agent_template/observability/observability.sqlite3"
STATIC = HERE / "static"
SCHEMA_VERSION = 2
WINDOWS = {"1h": 3600, "24h": 86400, "7d": 604800, "all": None}
STATIC_FILES = {
    "/": "index.html",
    "/app.js": "app.js",
    "/style.css": "style.css",
    "/request.js": "request.js",
    "/favicon.svg": "favicon.svg",
}
RUN_COLUMNS = (
    "run_id,root_run_id,parent_run_id,process_instance_id,agent_name,trace_id,"
    "thread_id,started,ended,completion,summary"
)
CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
    "object-src 'none'; base-uri 'none'"
)


def decode(value: str | None) -> dict:
    return envelope(value)


def data_of(value: str | None) -> dict:
    data = decode(value).get("data", {})
    return data if isinstance(data, dict) else {}


def bounded_int(value: str, *, default: int, maximum: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return min(max(number, 0), maximum)


def event_label(name: str, data: dict) -> str:
    if name == "log":
        return str(data.get("logger") or "Log")
    if name.startswith("tool."):
        call = data.get("call")
        tool = (
            data.get("name")
            or data.get("tool")
            or (call.get("name") if isinstance(call, dict) else None)
        )
        if isinstance(tool, dict):
            tool = tool.get("name")
        return str(tool or name)
    if name.startswith("model."):
        model = data.get("model")
        return str((model.get("name") if isinstance(model, dict) else model) or name)
    if name.startswith("run."):
        return str(data.get("agent_name") or name)
    return name


def event_preview(name: str, data: dict) -> str:
    if name == "log":
        value = data.get("message", "")
    elif name == "tool.wait_finished":
        value = f"{data.get('kind', 'tool')} wait · {float(data.get('duration') or 0):.3f}s"
    elif name == "model.finished":
        value = (
            f"{data.get('completion', 'finished')} · usage {data.get('usage_coverage', 'unknown')}"
        )
    elif name == "run.finished":
        value = data.get("completion", "finished")
    elif name.startswith("delegation."):
        tasks = data.get("tasks")
        value = f"{len(tasks)} tasks" if isinstance(tasks, list) else name
    else:
        value = data.get("reason") or data.get("completion") or data.get("name") or ""
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False)
    return value[:240]


class ObservationDB:
    """One short-lived read-only SQLite connection per HTTP request."""

    def __init__(self, path: Path):
        self.path = path.expanduser().resolve()

    def connect(self) -> sqlite3.Connection:
        """Open a current-schema recording read-only; reject other versions without migration."""
        uri = f"file:{quote(str(self.path))}?mode=ro"
        # A closed WAL database may have no -wal/-shm files. SQLite can read
        # that checkpointed file as immutable; live writers use normal WAL reads.
        if (
            not Path(str(self.path) + "-wal").exists()
            and not Path(str(self.path) + "-shm").exists()
        ):
            uri += "&immutable=1"
        db = sqlite3.connect(uri, uri=True, timeout=1)
        try:
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA query_only=ON")
            db.execute("PRAGMA busy_timeout=1000")
            db.create_function("obs_category", 1, category, deterministic=True)
            db.create_function(
                "obs_outcome",
                2,
                lambda name, value: outcome(name, json.loads(value)),
                deterministic=True,
            )
            if db.execute("PRAGMA user_version").fetchone()[0] != SCHEMA_VERSION:
                raise ValueError("Unsupported observability schema version")
            return db
        except Exception:
            db.close()
            raise

    @staticmethod
    def since(window: str) -> float:
        if window not in WINDOWS:
            raise ValueError("Unknown time window")
        seconds = WINDOWS[window]
        return 0 if seconds is None else time.time() - seconds

    @staticmethod
    def run_row(row: sqlite3.Row) -> dict:
        result = {key: row[key] for key in row.keys() if key not in ("payload", "summary")}
        summary_data = data_of(row["summary"]) if "summary" in row.keys() else {}
        result["summary"] = summary_data.get("summary", {})
        result["telemetry_complete"] = summary_data.get("telemetry_complete")
        result["duration"] = summary_data.get("duration")
        return result

    def overview(self, window: str) -> dict:
        since = self.since(window)
        with closing(self.connect()) as db:
            roots = db.execute(
                f"SELECT {RUN_COLUMNS} FROM runs "
                "WHERE parent_run_id IS NULL AND started>=? ORDER BY started DESC",
                (since,),
            ).fetchall()
            tool_calls = db.execute(
                "SELECT COUNT(*) FROM events e JOIN runs r ON r.run_id=e.root_run_id "
                "WHERE r.parent_run_id IS NULL AND r.started>=? "
                "AND e.event_name='tool.call.started'",
                (since,),
            ).fetchone()[0]
            process_health = dict(
                db.execute(
                    "SELECT COUNT(*) AS count,COALESCE(SUM(unrecorded),0) AS unrecorded,"
                    "COALESCE(SUM(CASE WHEN health!='healthy' THEN 1 ELSE 0 END),0) AS unhealthy "
                    "FROM processes"
                ).fetchone()
            )
            latest_cursor = db.execute("SELECT COALESCE(MAX(cursor),0) FROM events").fetchone()[0]
        totals = {
            key: 0 for key in ("model_calls", "calls_with_usage", "input_tokens", "output_tokens")
        }
        outcomes: dict[str, int] = {}
        durations = []
        for row in roots:
            outcomes[row["completion"]] = outcomes.get(row["completion"], 0) + 1
            summary = self.run_row(row)["summary"]
            for key in totals:
                totals[key] += int(summary.get(key) or 0)
            if row["ended"] is not None:
                durations.append(row["ended"] - row["started"])
        wal = Path(str(self.path) + "-wal")
        try:
            wal_bytes = wal.stat().st_size
        except FileNotFoundError:
            wal_bytes = 0
        return {
            "window": window,
            "root_runs": len(roots),
            "outcomes": outcomes,
            "tool_calls": tool_calls,
            "usage": {
                **totals,
                "missing_calls": max(0, totals["model_calls"] - totals["calls_with_usage"]),
            },
            "mean_duration": sum(durations) / len(durations) if durations else None,
            "recent_runs": [self.run_row(row) for row in roots[:60]],
            "trend": [self.run_row(row) for row in reversed(roots[:18])],
            "process_health": process_health,
            "latest_cursor": latest_cursor,
            "database_bytes": self.path.stat().st_size,
            "wal_bytes": wal_bytes,
        }

    def run_detail(self, run_id: str, *, include_spans: bool = True) -> dict | None:
        with closing(self.connect()) as db:
            requested = db.execute(
                "SELECT root_run_id FROM runs WHERE run_id=?", (run_id,)
            ).fetchone()
            if requested is None:
                return None
            root_id = requested["root_run_id"]
            runs = db.execute(
                f"SELECT {RUN_COLUMNS} FROM runs WHERE root_run_id=? ORDER BY started,run_id",
                (root_id,),
            ).fetchall()
            traces = sorted({row["trace_id"] for row in runs if row["trace_id"]})
            spans = []
            if traces and include_spans:
                marks = ",".join("?" for _ in traces)
                spans = db.execute(
                    f"SELECT * FROM spans WHERE trace_id IN ({marks}) ORDER BY started,span_id",
                    traces,
                ).fetchall()
        return {
            "root_run_id": root_id,
            "runs": [self.run_row(row) for row in runs],
            "spans": [
                {
                    "trace_id": row["trace_id"],
                    "span_id": row["span_id"],
                    "parent_span_id": row["parent_span_id"],
                    "name": row["name"],
                    "started": row["started"],
                    "ended": row["ended"],
                    "kind": data_of(row["payload"]).get("kind"),
                    "status": data_of(row["payload"]).get("status"),
                }
                for row in spans
            ],
        }

    def events(self, root_id: str, after: int, limit: int, view: str) -> dict | None:
        if view not in ("flow", "logs", "all"):
            raise ValueError("Unknown event view")
        with closing(self.connect()) as db:
            exists = db.execute(
                "SELECT 1 FROM runs WHERE run_id=? AND parent_run_id IS NULL", (root_id,)
            ).fetchone()
            if exists is None:
                return None
            clause = {
                "flow": "AND event_name!='log' AND event_name NOT LIKE 'capture.%' "
                "AND event_name NOT LIKE 'telemetry.%'",
                "logs": "AND event_name='log'",
                "all": "",
            }[view]
            rows = db.execute(
                "SELECT cursor,timestamp,event_name,run_id,span_id,payload FROM events "
                f"WHERE root_run_id=? AND cursor>? {clause} ORDER BY cursor LIMIT ?",
                (root_id, after, limit + 1),
            ).fetchall()
        return self._event_page(rows, limit)

    def global_logs(self, after: int, limit: int) -> dict:
        with closing(self.connect()) as db:
            if after == 0:
                rows = list(
                    reversed(
                        db.execute(
                            "SELECT cursor,timestamp,event_name,run_id,span_id,payload FROM events "
                            "WHERE event_name='log' ORDER BY cursor DESC LIMIT ?",
                            (limit + 1,),
                        ).fetchall()
                    )
                )
                rows = rows[-limit:]
            else:
                rows = db.execute(
                    "SELECT cursor,timestamp,event_name,run_id,span_id,payload FROM events "
                    "WHERE event_name='log' AND cursor>? ORDER BY cursor LIMIT ?",
                    (after, limit + 1),
                ).fetchall()
        return self._event_page(rows, limit)

    @staticmethod
    def _event_page(rows: list[sqlite3.Row], limit: int) -> dict:
        items = []
        for row in rows[:limit]:
            data = data_of(row["payload"])
            name = row["event_name"]
            items.append(
                {
                    "cursor": row["cursor"],
                    "timestamp": row["timestamp"],
                    "event_name": name,
                    "run_id": row["run_id"],
                    "span_id": row["span_id"],
                    "label": event_label(name, data),
                    "preview": event_preview(name, data),
                    "level": data.get("level") if name == "log" else None,
                    "duration": data.get("duration")
                    if isinstance(data.get("duration"), (int, float))
                    else None,
                }
            )
        return {
            "items": items,
            "has_more": len(rows) > limit,
            "next_cursor": items[-1]["cursor"] if items else None,
        }

    def event(self, cursor: int) -> dict | None:
        with closing(self.connect()) as db:
            return event_detail(db, cursor)

    def requests(self, run_id: str, after: int, limit: int) -> dict | None:
        with closing(self.connect()) as db:
            return request_list(db, run_id, after, limit)

    def request(self, run_id: str, cursor: int) -> dict | None:
        with closing(self.connect()) as db:
            return request_detail(db, run_id, cursor)

    def inspect(self, path: str, query: dict | None = None) -> tuple[bool, dict | None]:
        with closing(self.connect()) as db:
            # A projection with several queries sees one committed snapshot.
            db.execute("BEGIN")
            return route(db, path, query or {}, self.path)


def make_handler(database: ObservationDB):
    class Handler(BaseHTTPRequestHandler):
        server_version = "DataPackageAgentDashboard/0.1"

        def log_message(self, format: str, *args) -> None:
            if len(args) > 1 and str(args[1]).startswith(("4", "5")):
                print(f"{self.address_string()} - {format % args}")

        def send_json(self, value: dict, status: HTTPStatus = HTTPStatus.OK) -> None:
            body = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", CSP)
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            parsed = urlsplit(self.path)
            path = unquote(parsed.path)
            query = parse_qs(parsed.query)

            def param(name: str, default: str) -> str:
                return query.get(name, [default])[0]

            try:
                if path in STATIC_FILES:
                    content = (STATIC / STATIC_FILES[path]).read_bytes()
                    content_type = (
                        mimetypes.guess_type(STATIC_FILES[path])[0] or "application/octet-stream"
                    )
                    self.send_response(HTTPStatus.OK)
                    self.send_header("Content-Type", content_type + "; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.send_header("Content-Security-Policy", CSP)
                    self.send_header("Referrer-Policy", "no-referrer")
                    self.end_headers()
                    self.wfile.write(content)
                    return
                if path.startswith("/api/"):
                    handled, result = database.inspect(path, query)
                    if handled:
                        self.send_json(
                            result if result is not None else {"error": "Record not found"},
                            HTTPStatus.OK if result is not None else HTTPStatus.NOT_FOUND,
                        )
                        return
                if path == "/api/overview":
                    self.send_json(database.overview(param("window", "24h")))
                    return
                if path == "/api/logs":
                    self.send_json(
                        database.global_logs(
                            bounded_int(param("after", "0"), default=0, maximum=2**63 - 1),
                            bounded_int(param("limit", "100"), default=100, maximum=250) or 1,
                        )
                    )
                    return
                if path.startswith("/api/events/"):
                    cursor = int(path.rsplit("/", 1)[-1])
                    result = database.event(cursor)
                    self.send_json(
                        result or {"error": "Event not found"},
                        HTTPStatus.OK if result else HTTPStatus.NOT_FOUND,
                    )
                    return
                if path.startswith("/api/runs/"):
                    rest = path[len("/api/runs/") :].split("/")
                    run_id = rest[0]
                    if not run_id or len(run_id) > 128:
                        raise ValueError("Invalid run ID")
                    if len(rest) == 1:
                        result = database.run_detail(
                            run_id, include_spans=param("spans", "1") != "0"
                        )
                    elif len(rest) == 2 and rest[1] == "requests":
                        result = database.requests(
                            run_id,
                            bounded_int(param("after", "0"), default=0, maximum=2**63 - 1),
                            bounded_int(param("limit", "50"), default=50, maximum=100) or 1,
                        )
                    elif len(rest) == 3 and rest[1] == "requests":
                        result = database.request(run_id, int(rest[2]))
                    elif len(rest) == 2 and rest[1] == "events":
                        result = database.events(
                            run_id,
                            bounded_int(param("after", "0"), default=0, maximum=2**63 - 1),
                            bounded_int(param("limit", "150"), default=150, maximum=250) or 1,
                            param("view", "flow"),
                        )
                    else:
                        result = None
                    self.send_json(
                        result or {"error": "Run not found"},
                        HTTPStatus.OK if result is not None else HTTPStatus.NOT_FOUND,
                    )
                    return
                self.send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
            except (ValueError, sqlite3.Error, OSError, json.JSONDecodeError) as exc:
                status = (
                    HTTPStatus.BAD_REQUEST
                    if isinstance(exc, ValueError)
                    else HTTPStatus.SERVICE_UNAVAILABLE
                )
                self.send_json({"error": str(exc)}, status)

    return Handler


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--db", type=Path, default=Path(os.environ.get("MCP_AGENT_TEMPLATE_OBS_DB", DEFAULT_DB))
    )
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    database = ObservationDB(args.db)
    if not database.path.is_file():
        parser.error(f"Observability database not found: {database.path}")
    with closing(database.connect()):
        pass
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(database))
    print(f"Dashboard: http://127.0.0.1:{server.server_port}", flush=True)
    print(f"Reading:   {database.path}", flush=True)
    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
