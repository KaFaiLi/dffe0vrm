"""Recorded provider and LangChain shapes render without inventing summary text."""

import unittest

from message_view import present_message, stream_parts


class MessageViewTests(unittest.TestCase):
    """Render current message content without inventing answer or reasoning text."""

    def test_normalized_summaries(self):
        """Separate normalized reasoning content from the answer."""
        messages = [
            {
                "content": [
                    {"type": "reasoning", "reasoning": "Check."},
                    {"type": "text", "text": "answer"},
                ]
            },
            {
                "content": [
                    {"type": "thinking", "thinking": "Check."},
                    {"type": "output_text", "text": "answer"},
                ]
            },
        ]
        for message in messages:
            with self.subTest(message=message):
                result = present_message(message)
                self.assertEqual(result["text"], "answer")
                self.assertEqual(result["thinking_summary"], "Check.")

    def test_encrypted_reasoning_and_other_modalities_are_not_guessed(self):
        message = {
            "content": [
                {"type": "reasoning", "encrypted_content": "opaque", "signature": "opaque"},
                {"type": "redacted_thinking", "data": "opaque"},
                {"type": "image", "url": "synthetic:image"},
            ]
        }
        result = present_message(message)
        self.assertEqual(result["text"], "")
        self.assertEqual(result["thinking_summary"], "")
        self.assertTrue(result["structured_content"])

    def test_structured_tool_chunks_do_not_fall_back_to_answer_text(self):
        """Keep tool argument chunks out of rendered answer text."""
        result = stream_parts(
            {
                "token": "tool args",
                "chunk": {
                    "message": {
                        "content": "",
                        "tool_call_chunks": [{"args": '{"label":'}],
                    }
                },
            }
        )
        self.assertEqual(result["text"], "")


if __name__ == "__main__":
    unittest.main()
