"""Behavioral coverage for conversation reconstruction and SQLite-only inspection."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import unittest
from contextlib import closing, contextmanager

import test_server as fixture
from records import category, outcome
from test_server import envelope


class InspectionTests(unittest.TestCase):
    """Inspect current-schema recordings through the dashboard's read-only API."""

    def setUp(self) -> None:
        """Reuse the current storage schema with a clean root conversation."""
        fixture.DashboardTests.setUp(self)
        with self.write() as db:
            db.execute("DELETE FROM _events")
            db.execute("DELETE FROM _runs")
        self.add_run("root", messages=[self.message("u1", "human", "Calculate 13 + 8")])

    @contextmanager
    def write(self):
        with closing(sqlite3.connect(self.path)) as db, db:
            yield db

    @staticmethod
    def message(identity, role, content, **extra):
        return {"id": identity, "type": role, "content": content, **extra}

    def add_run(
        self, identity, *, parent=None, messages=None, started=100, summary=None, thread=None
    ):
        """Insert one synthetic run into the current writer's private run table."""
        with self.write() as db:
            db.execute(
                "INSERT INTO _runs (run_id,root_run_id,parent_run_id,process_instance_id,"
                "agent_name,trace_id,thread_id,started,ended,completion,payload,summary) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    identity,
                    "root" if parent else identity,
                    parent,
                    "process",
                    "agent",
                    "trace",
                    thread,
                    started,
                    started + 10,
                    "completed",
                    envelope(
                        {"input": {"messages": messages or []}, "limits": {"max_tool_calls": 4}}
                    ),
                    envelope({"summary": summary or {}, "duration": 10}),
                ),
            )

    def event(self, name, values, *, run="root", context=None, span=None, trace="trace"):
        """Insert one synthetic event and return its arrival cursor."""
        body = {"data": values, "redactions": []}
        if context is not None:
            body["context"] = context
        with self.write() as db:
            row = db.execute(
                "INSERT INTO _events(event_name,timestamp,run_id,root_run_id,trace_id,"
                "span_id,process_instance_id,payload) VALUES (?,?,?,?,?,?,?,?)",
                (
                    name,
                    101,
                    run,
                    "root" if run in ("root", "child") else run,
                    trace,
                    span,
                    "process",
                    json.dumps(body),
                ),
            )
            return row.lastrowid

    def model(
        self,
        native,
        message,
        *,
        usage=None,
        partial=None,
        round_id="round1",
        run="root",
        purpose="agent",
        human="u1",
    ):
        context = {"round_id": round_id, "request_id": native + "-request", "purpose": purpose}
        start = self.event(
            "model.started",
            {
                "native_run_id": native,
                "model": "test-model",
                "messages": [[self.message(human, "human", "prompt")]],
            },
            run=run,
            context=context,
        )
        finish = self.event(
            "model.finished",
            {
                "native_run_id": native,
                "model": "test-model",
                "duration": 0.5,
                "completion": "completed",
                "usage": usage,
                "partial_usage": partial,
                "response": {"generations": [[{"message": message}]]},
            },
            run=run,
            context=context,
        )
        return start, finish

    def get(self, route, **params):
        handled, value = self.observations.inspect(route, {k: [str(v)] for k, v in params.items()})
        self.assertTrue(handled)
        return value

    def test_log_search_includes_text_beyond_preview(self):
        cursor = self.event("log", {"level": "INFO", "message": "prefix " * 100 + "FIND_SUFFIX"})
        page = self.get("/api/events", q="FIND_SUFFIX")
        self.assertEqual([item["cursor"] for item in page["items"]], [cursor])
        self.assertNotIn("FIND_SUFFIX", page["items"][0]["preview"])

    def test_header_can_exclude_unpaged_span_records(self):
        full = self.observations.run_detail("root")
        header = self.observations.run_detail("root", include_spans=False)
        self.assertEqual(header["runs"], full["runs"])
        self.assertTrue(full["spans"])
        self.assertEqual(header["spans"], [])

    def test_historical_nested_definition_is_projected_without_rewriting_evidence(self):
        """Display old double-wrapped definitions while exports retain the original record."""
        historical = {
            "schema_version": 1,
            "data": {"system_prompt": "Historical prompt", "skills": [{"name": "historic"}]},
            "redactions": ["$.system_prompt"],
            "stage": "agent_definition",
        }
        self.event("capture.run_definition", historical)
        start, _ = self.model("native1", self.message("a1", "ai", "answer"))
        before = hashlib.sha256(self.path.read_bytes()).hexdigest()
        detail = self.observations.request("root", start)
        self.assertEqual(detail["definition_data"], historical["data"])
        self.assertEqual(detail["definition"]["payload"]["data"], historical)
        self.assertEqual([skill["name"] for skill in detail["skills"]], ["historic"])
        self.assertEqual(hashlib.sha256(self.path.read_bytes()).hexdigest(), before)

    def test_final_output_is_one_transcript_not_repeated_request_snapshots(self):
        assistant = self.message("a1", "ai", "21", tool_calls=[])
        self.model("native1", assistant, usage={"input_tokens": 100, "output_tokens": 5})
        final = self.event(
            "capture.output",
            {"messages": [self.message("u1", "human", "Calculate 13 + 8"), assistant]},
        )
        for _ in range(4):
            self.event("capture.model_request", {"messages": [assistant] * 20})
        value = self.get("/api/runs/root/conversation")
        self.assertEqual([m["message_id"] for m in value["items"]], ["u1", "a1"])
        self.assertEqual(value["items"][1]["sources"][0]["cursor"], final)
        self.assertEqual(value["turns"][0]["usage"]["total_tokens"], 105)
        self.assertEqual(value["usage"]["model_calls"], 1)

    def test_same_id_replaces_but_equal_text_with_distinct_ids_survives(self):
        self.event(
            "capture.output",
            {
                "messages": [
                    self.message("u1", "human", "same"),
                    self.message("a1", "ai", "before"),
                    self.message("a1", "ai", "after"),
                    self.message("u2", "human", "same"),
                ]
            },
        )
        result = self.get("/api/runs/root/conversation")
        self.assertEqual([m["preview"] for m in result["items"]], ["same", "after", "same"])
        self.assertEqual(len(result["items"][1]["sources"]), 2)
        self.assertEqual(len(result["turns"]), 2)

    def test_missing_message_ids_use_authoritative_source_positions(self):
        self.model("n1", self.message(None, "ai", "answer"))
        self.event(
            "capture.output",
            {
                "messages": [
                    self.message(None, "human", "same"),
                    self.message(None, "ai", "answer"),
                    self.message(None, "human", "same"),
                ]
            },
        )
        result = self.get("/api/runs/root/conversation")
        self.assertEqual(len(result["items"]), 3)
        self.assertEqual(result["unattributed_calls"], 1)
        self.assertTrue(all(t["usage"] is None for t in result["turns"]))

    def test_paging_keeps_usage_and_full_selected_message(self):
        content = "字 <script>never run</script> " * 200 + "FINAL_SUFFIX"
        self.model(
            "n1",
            self.message("a1", "ai", content),
            usage={"input_tokens": 100, "output_tokens": 20},
        )
        messages = [self.message(f"u{i}", "human", str(i)) for i in range(510)] + [
            self.message("a1", "ai", content)
        ]
        self.event("capture.output", {"messages": messages})
        first = self.get("/api/runs/root/conversation", offset=0, limit=25)
        last = self.get("/api/runs/root/conversation", offset=500, limit=25)
        self.assertEqual(first["usage"], last["usage"])
        self.assertEqual(first["total_items"], 511)
        self.assertNotIn("FINAL_SUFFIX", json.dumps(last))
        detail = self.get("/api/runs/root/conversation", item="message:a1")
        self.assertEqual(detail["message"]["content"], content)

    def test_rounds_retries_summaries_and_partial_usage_are_distinct(self):
        self.event("model.round.started", {}, context={"round_id": "no-dispatch"})
        self.model(
            "attempt1",
            self.message("a1", "ai", "first"),
            usage={
                "input_tokens": 100,
                "output_tokens": 10,
                "input_token_details": {"cache_read": 80},
            },
        )
        self.model(
            "summary",
            self.message("s1", "ai", "summary"),
            usage={"input_tokens": 30, "output_tokens": 5},
            purpose="summary",
        )
        self.model(
            "attempt2",
            self.message("a2", "ai", "second"),
            partial={"input_tokens": 120, "output_tokens": 2},
        )
        result = self.get("/api/runs/root/conversation")
        self.assertEqual(len(result["rounds"]), 2)
        self.assertEqual(len(result["rounds"][1]["calls"]), 3)
        self.assertEqual(result["usage"]["total_tokens"], 267)
        self.assertEqual(result["usage"]["calls_with_usage"], 2)
        self.assertEqual(result["usage"]["partial_calls"], 1)
        self.assertEqual(result["usage"]["reported_input_tokens"], 130)

    def test_stream_fragments_are_one_message_replaced_by_completion(self):
        """Merge current callback chunks into one message and replace it on completion."""
        self.event("model.started", {"native_run_id": "stream", "messages": []})
        for token in ("hel", "lo"):
            self.event(
                "capture.model.stream",
                {"native_run_id": "stream", "chunk": {"message": {"content": token}}},
            )
        result = self.get("/api/runs/root/conversation")
        self.assertEqual(result["items"][-1]["preview"], "hello")
        self.assertEqual(result["items"][-1]["message_id"], "stream:stream")
        self.event(
            "model.finished",
            {
                "native_run_id": "stream",
                "completion": "completed",
                "response": {"generations": [[{"message": self.message("a", "ai", "hello!")}]]},
            },
        )
        result = self.get("/api/runs/root/conversation")
        self.assertEqual([m["preview"] for m in result["items"]], ["Calculate 13 + 8", "hello!"])

    def test_root_usage_counts_descendants_once_and_child_scope_is_exact(self):
        self.add_run("child", parent="root", messages=[self.message("cu", "human", "child")])
        self.model(
            "n1",
            self.message("a", "ai", "parent"),
            usage={"input_tokens": 100, "output_tokens": 10},
        )
        self.model(
            "n2",
            self.message("ca", "ai", "child"),
            run="child",
            human="cu",
            usage={"input_tokens": 20, "output_tokens": 4},
        )
        root = self.get("/api/runs/root/usage")
        child = self.get("/api/runs/child/usage")
        self.assertEqual(root["total"]["total_tokens"], 134)
        self.assertEqual(child["total"]["total_tokens"], 24)
        self.assertEqual(self.get("/api/runs/root/conversation")["usage"]["total_tokens"], 110)

    def test_thinking_blocks_are_separate_from_authoritative_answer_and_raw_evidence(self):
        """Keep normalized reasoning separate while preserving complete recorded evidence."""
        message = self.message(
            "a",
            "ai",
            [
                {
                    "type": "reasoning",
                    "summary": [{"type": "summary_text", "text": "Check the sum."}],
                },
                {"type": "text", "text": "21"},
            ],
        )
        start, _ = self.model("n1", message, usage={"input_tokens": 10, "output_tokens": 4})
        self.event(
            "capture.output", {"messages": [self.message("u1", "human", "question"), message]}
        )
        value = self.get("/api/runs/root/conversation")
        item = value["items"][-1]
        self.assertEqual(item["preview"], "21")
        self.assertEqual(item["thinking_preview"], "Check the sum.")
        self.assertFalse(item["streaming"])
        detail = self.get("/api/runs/root/conversation", item="message:a")
        self.assertEqual(detail["message"], message)
        response = self.observations.request("root", start)["response_messages"][0]
        self.assertEqual(response["presentation"]["text"], "21")
        self.assertEqual(response["presentation"]["thinking_summary"], "Check the sum.")

    def test_live_summaries_do_not_become_answer_tokens_and_survive_terminal_omission(self):
        start = self.event("model.started", {"native_run_id": "live", "messages": []})
        for summary in ("Check ", "the sum."):
            self.event(
                "capture.model.stream",
                {
                    "native_run_id": "live",
                    "token": summary,
                    "chunk": {
                        "message": {"content": [{"type": "reasoning", "reasoning": summary}]}
                    },
                },
            )
        active = self.get("/api/runs/root/conversation")["items"][-1]
        self.assertEqual(active["preview"], "")
        self.assertEqual(active["thinking_preview"], "Check the sum.")
        self.assertTrue(active["streaming"])
        self.event(
            "capture.model.stream",
            {
                "native_run_id": "live",
                "token": "ignored duplicate",
                "chunk": {"message": {"content": [{"type": "text", "text": "21"}]}},
            },
        )
        request = self.observations.request("root", start)
        self.assertEqual(request["stream_presentation"]["text"], "21")
        self.assertEqual(request["stream_presentation"]["thinking_summary"], "Check the sum.")
        self.event(
            "model.finished",
            {
                "native_run_id": "live",
                "completion": "completed",
                "response": {
                    "generations": [[{"message": self.message("final", "ai", "Answer: 21")}]]
                },
            },
        )
        value = self.get("/api/runs/root/conversation")
        self.assertEqual([i["preview"] for i in value["items"]], ["Calculate 13 + 8", "Answer: 21"])
        self.assertEqual(value["items"][-1]["thinking_preview"], "Check the sum.")
        self.assertEqual(value["items"][-1]["thinking_source"], "stream fragments")
        self.assertEqual(len(value["items"][-1]["thinking_sources"]), 2)
        self.assertEqual(value["usage"]["model_calls"], 1)
        self.assertEqual(value["usage"]["missing_calls"], 1)

    def test_terminal_summary_replaces_stream_and_full_thinking_is_selected_only(self):
        """Replace streamed reasoning blocks and fetch full terminal summaries only on selection."""
        summary = "short prefix " * 300 + "THINKING_FINAL_SUFFIX"
        self.event("model.started", {"native_run_id": "live", "messages": []})
        self.event(
            "capture.model.stream",
            {
                "native_run_id": "live",
                "token": "",
                "chunk": {"message": {"content": [{"type": "reasoning", "reasoning": "obsolete"}]}},
            },
        )
        self.event(
            "model.finished",
            {
                "native_run_id": "live",
                "completion": "completed",
                "response": {
                    "generations": [
                        [
                            {
                                "message": self.message(
                                    "final",
                                    "ai",
                                    [
                                        {"type": "text", "text": "answer"},
                                        {"type": "reasoning", "summary": [{"text": summary}]},
                                    ],
                                )
                            }
                        ]
                    ]
                },
            },
        )
        page = self.get("/api/runs/root/conversation")
        self.assertNotIn("THINKING_FINAL_SUFFIX", json.dumps(page))
        self.assertNotIn("obsolete", json.dumps(page))
        self.assertFalse(page["items"][-1]["thinking_complete"])
        detail = self.get("/api/runs/root/conversation", item="message:final")
        self.assertEqual(detail["presentation"]["thinking_summary"], summary)
        timeline = self.get("/api/runs/root/thinking")
        self.assertEqual(timeline["summary_calls"], 1)
        self.assertNotIn("THINKING_FINAL_SUFFIX", json.dumps(timeline))
        selected = self.get("/api/runs/root/thinking", id="live")
        self.assertEqual(selected["thinking_summary"], summary)
        self.assertEqual(selected["thinking_source"], "native response")

    def test_model_timeline_paging_scoping_and_absent_summaries(self):
        """Page normalized summaries within their own run without inventing absent text."""
        self.add_run("child", parent="root", messages=[])
        self.model("one", self.message("a", "ai", "answer"))
        self.model("two", self.message("b", "ai", [{"type": "reasoning", "reasoning": "Check."}]))
        self.model(
            "child-call",
            self.message("c", "ai", [{"type": "reasoning", "reasoning": "Child."}]),
            run="child",
        )
        first = self.get("/api/runs/root/thinking", limit=1)
        second = self.get("/api/runs/root/thinking", offset=1, limit=1)
        self.assertEqual(first["total_calls"], 2)
        self.assertTrue(first["has_more"])
        self.assertFalse(first["items"][0]["thinking_available"])
        self.assertEqual(first["items"][0]["usage_coverage"], "unknown")
        self.assertEqual(second["items"][0]["thinking_preview"], "Check.")
        self.assertEqual(self.get("/api/runs/child/thinking")["total_calls"], 1)
        self.assertIsNone(self.get("/api/runs/root/thinking", id="child-call"))
        self.assertIsNone(self.get("/api/runs/missing/thinking"))

    def test_thread_invocations_remain_separate_segments(self):
        """Keep same-thread runs distinct in current-schema conversation reads."""
        with self.write() as db:
            db.execute("UPDATE _runs SET thread_id='thread' WHERE run_id='root'")
        self.add_run("other", thread="thread", messages=[self.message("u2", "human", "other")])
        self.assertEqual(len(self.get("/api/runs/root/records")["thread_segments"]), 2)
        self.assertEqual(self.get("/api/runs/root/conversation")["total_items"], 1)
        self.assertIsNone(self.get("/api/runs/other/conversation", item="message:u1"))

    def test_native_call_id_links_completion_without_round_metadata(self):
        start = self.event("model.started", {"native_run_id": "old", "messages": []})
        self.event(
            "model.finished", {"native_run_id": "unrelated", "response": {"answer": "wrong"}}
        )
        finish = self.event(
            "model.finished", {"native_run_id": "old", "response": {"answer": "correct"}}
        )
        detail = self.observations.request("root", start)
        self.assertEqual(detail["completion"]["cursor"], finish)
        self.assertEqual(detail["coverage"]["correlation"], "native_call_only")

    def test_malformed_events_preserve_request_navigation_and_raw_evidence(self):
        """Retain navigation and raw corrupt payloads when JSON indexes are bypassed."""
        broken = [self.event(name, {}) for name in ("log", "tool.finished", "model.started")]
        with self.write() as db:
            # Disable JSON indexes only for this deliberate corruption fixture.
            db.execute("DROP INDEX events_request")
            db.execute("DROP INDEX events_round")
            for cursor in broken:
                db.execute("UPDATE _events SET payload=? WHERE cursor=?", ("{broken", cursor))
        start, finish = self.model("valid", self.message("answer", "ai", "Recorded answer"))
        requests = self.observations.requests("root", 0, 100)
        self.assertEqual([item["cursor"] for item in requests["items"]], [broken[-1], start])
        detail = self.observations.request("root", start)
        self.assertEqual(detail["native"]["cursor"], start)
        self.assertEqual(detail["completion"]["cursor"], finish)
        self.assertTrue(all(record["cursor"] not in broken for record in detail["records"]))
        for cursor in broken:
            raw = self.observations.event(cursor)["payload"]
            self.assertEqual(raw["record_error"], "Invalid JSON payload")
            self.assertEqual(raw["raw_payload"], "{broken")
        malformed_request = self.observations.request("root", broken[-1])
        self.assertIsNone(malformed_request["native"])
        self.assertEqual(malformed_request["coverage"]["correlation"], "unavailable")
        self.assertEqual(malformed_request["records"][0]["payload"]["raw_payload"], "{broken")

    def test_provider_body_requires_explicit_link_and_single_capture(self):
        start, _ = self.model("native", self.message("answer", "ai", "42"))
        body = {"model": "test-model", "input": [{"role": "user", "content": "captured request"}]}
        self.event("capture.provider_request", {"body": {"model": "unlinked"}})
        self.event(
            "capture.provider_request",
            {"body": {"model": "round-only"}},
            context={"round_id": "round1"},
        )
        self.assertIsNone(self.observations.request("root", start)["provider"])
        context = {"request_id": "native-request", "round_id": "round1"}
        self.event(
            "capture.provider_request",
            {"stage": "provider_http_body", "body": body},
            context=context,
        )
        detail = self.observations.request("root", start)
        self.assertEqual(detail["provider"]["payload"]["data"]["body"], body)
        self.assertEqual(detail["coverage"]["provider_http_body"], "captured")
        self.event("capture.provider_request", {"body": body}, context=context)
        detail = self.observations.request("root", start)
        self.assertIsNone(detail["provider"])
        self.assertEqual(detail["coverage"]["provider_http_body"], "multiple_requests")

    def test_event_classification_precedence_and_severity(self):
        for name, expected in [
            ("model.reserved", "middleware"),
            ("tool.wait_finished", "middleware"),
            ("capture.tool.transformed", "middleware"),
            ("capture.tool.started", "tool"),
            ("capture.mcp.result", "mcp"),
            ("child.finished", "delegation"),
            ("new.record", "other"),
        ]:
            self.assertEqual(category(name), expected)
        self.assertEqual(outcome("log", {"level": "CRITICAL"}), "error")
        self.assertEqual(category("model.finished"), "llm")
        self.assertEqual(outcome("model.finished", {"completion": "failed"}), "failed")
        self.assertEqual(
            outcome("log", {"level": "INFO", "message": "contains ERROR text"}), "info"
        )

    def test_backward_paging_filters_and_unscoped_events_survive_new_arrivals(self):
        for i in range(610):
            self.event("log", {"message": f"line {i}", "logger": "app", "level": "INFO"}, run=None)
        first = self.get("/api/events", category="log", latest=1, limit=100)
        second = self.get("/api/events", category="log", before=first["first_cursor"], limit=100)
        self.event("log", {"message": "new", "level": "INFO"}, run=None)
        forward = self.get("/api/events", category="log", after=second["last_cursor"], limit=100)
        self.assertEqual(
            [r["cursor"] for r in first["items"]], [r["cursor"] for r in forward["items"]]
        )
        self.assertTrue(second["has_before"])
        self.assertEqual(
            len(self.get("/api/events", unscoped=1, logger="app", q="line 609")["items"]), 1
        )
        self.assertEqual(self.get("/api/runs/root/activity")["items"], [])

    def test_run_keyset_paging_reaches_older_runs_despite_insertion(self):
        for i in range(70):
            self.add_run(f"run-{i}", started=200 + i)
        page = self.get("/api/runs", limit=30)
        self.add_run("newest", started=1000)
        second = self.get("/api/runs", limit=30, after=page["next_anchor"])
        third = self.get("/api/runs", limit=30, after=second["next_anchor"])
        ids = [r["run_id"] for p in (page, second, third) for r in p["items"]]
        self.assertEqual(len(ids), 71)
        self.assertEqual(len(set(ids)), 71)
        self.assertNotIn("newest", ids)

    def test_tool_error_result_is_not_overwritten_by_completed_wrapper(self):
        self.event(
            "tool.call.started",
            {"id": "call", "name": "add", "args": {"a": 13, "b": 8}},
            span="tool-span",
        )
        self.event(
            "tool.attempt.started",
            {"call": {"id": "call", "name": "add"}, "attempt": 1, "execution_id": "effect"},
            span="attempt",
        )
        self.event(
            "tool.finished",
            {"call": {"id": "call"}, "error_results": [{"error": "failure"}]},
            span="tool-span",
        )
        self.event(
            "tool.call.finished", {"completion": "completed", "duration": 0.5}, span="tool-span"
        )
        groups = self.get("/api/runs/root/tools")
        detail = self.get("/api/runs/root/tools", id="call")
        self.assertEqual(groups["items"][0]["status"], "error")
        self.assertEqual(detail["duration"], 0.5)
        self.assertEqual(len(detail["records"]), 4)
        self.add_run("other")
        self.assertIsNone(self.get("/api/runs/other/tools", id="call"))

    def test_malformed_event_remains_accessible_and_unknown_category_is_visible(self):
        """Expose unknown event types and deliberately corrupted payloads without data loss."""
        cursor = self.event("novel.event", {})
        with self.write() as db:
            # Disable JSON indexes only for this deliberate corruption fixture.
            db.execute("DROP INDEX events_request")
            db.execute("DROP INDEX events_round")
            db.execute("UPDATE _events SET payload=? WHERE cursor=?", ("not-json", cursor))
        item = self.get("/api/events")["items"][0]
        self.assertEqual(item["category"], "other")
        self.assertEqual(item["record_error"], "Invalid JSON payload")
        self.assertEqual(self.observations.event(cursor)["payload"]["raw_payload"], "not-json")

    def test_metrics_preserve_temporality_and_complete_snapshot(self):
        payload = {
            "resource_metrics": [
                {
                    "resource": {"service": "test"},
                    "scope_metrics": [
                        {
                            "scope": {"name": "sdk"},
                            "metrics": [
                                {
                                    "name": "calls",
                                    "unit": "1",
                                    "data": {
                                        "aggregation_temporality": 2,
                                        "data_points": [
                                            {"value": 3, "attributes": {"model": "test"}}
                                        ],
                                    },
                                }
                            ],
                        }
                    ],
                }
            ]
        }
        with self.write() as db:
            for i in range(2):
                db.execute(
                    "INSERT INTO metric_points VALUES (?,?,?,?,?)",
                    (f"collection{i}", 0, "process", 100 + i, envelope(payload)),
                )
        detail = self.get("/api/metrics/collection1")
        self.assertEqual(detail["series"][0]["temporality"], 2)
        self.assertEqual(detail["series"][0]["point"]["value"], 3)
        self.assertEqual(detail["records"][0]["payload"]["data"], payload)
        self.assertEqual(len(self.get("/api/metrics")["items"]), 2)
        history = self.get("/api/metric-series", name="calls", process="process")
        self.assertEqual([r["point"]["value"] for r in history["items"]], [3, 3])
        self.assertTrue(all(r["temporality"] == 2 for r in history["items"]))

    def test_usage_paging_retains_complete_totals(self):
        for i in range(65):
            self.model(
                f"call-{i}",
                self.message(f"a-{i}", "ai", str(i)),
                usage={"input_tokens": 10, "output_tokens": 2},
            )
        first = self.get("/api/runs/root/usage", limit=50)
        last = self.get("/api/runs/root/usage", offset=50, limit=50)
        self.assertEqual(len(first["calls"]), 50)
        self.assertEqual(len(last["calls"]), 15)
        self.assertEqual(first["total"], last["total"])
        self.assertEqual(last["total"]["total_tokens"], 780)

    def test_round_activity_is_explicitly_scoped(self):
        self.event(
            "capture.planning_directive", {"content": "round one"}, context={"round_id": "r1"}
        )
        self.event(
            "capture.planning_directive", {"content": "round two"}, context={"round_id": "r2"}
        )
        result = self.get("/api/runs/root/activity", round="r1")
        self.assertEqual(len(result["items"]), 1)
        self.assertEqual(result["items"][0]["category"], "middleware")

    def test_summary_usage_links_to_turn_through_recorded_round(self):
        self.model(
            "main",
            self.message("a", "ai", "answer"),
            usage={"input_tokens": 10, "output_tokens": 2},
        )
        self.model(
            "summary",
            self.message("s", "ai", "summary"),
            human="summary-prompt",
            purpose="summary",
            usage={"input_tokens": 4, "output_tokens": 1},
        )
        self.event(
            "capture.output",
            {
                "messages": [
                    self.message("u1", "human", "question"),
                    self.message("a", "ai", "answer"),
                ]
            },
        )
        result = self.get("/api/runs/root/conversation")
        self.assertEqual(result["turns"][0]["usage"]["total_tokens"], 17)
        self.assertEqual(result["unattributed_calls"], 0)

    def test_invalid_usage_shape_is_unknown_and_raw_record_is_preserved(self):
        _, finish = self.model(
            "broken", self.message("a", "ai", "answer"), usage="not-a-usage-object"
        )
        result = self.get("/api/runs/root/usage")
        self.assertEqual(result["total"]["missing_calls"], 1)
        self.assertEqual(
            self.observations.event(finish)["payload"]["data"]["usage"], "not-a-usage-object"
        )

    def test_watermark_tracks_non_event_changes_and_readonly_queries_do_not_write(self):
        before = self.get("/api/database")["watermark"]
        with self.write() as db:
            db.execute("UPDATE processes SET heartbeat=200")
        self.assertNotEqual(self.get("/api/database")["watermark"], before)
        original = hashlib.sha256(self.path.read_bytes()).hexdigest()
        for route in (
            "/api/database",
            "/api/runs/root/conversation",
            "/api/runs/root/usage",
            "/api/events",
            "/api/processes",
            "/api/metrics",
        ):
            self.get(route)
        self.assertEqual(hashlib.sha256(self.path.read_bytes()).hexdigest(), original)
        with closing(self.observations.connect()) as db:
            with self.assertRaises(sqlite3.OperationalError):
                db.execute("CREATE TABLE forbidden(x)")

    def test_invalid_filters_and_missing_run_are_explicit(self):
        self.assertIsNone(self.get("/api/runs/missing/conversation"))
        for query in (
            {"category": "bad"},
            {"since": "nan"},
            {"before": 1, "after": 2},
            {"limit": 999},
        ):
            with self.assertRaises(ValueError):
                self.get("/api/events", **query)
        with self.assertRaises(ValueError):
            self.get("/api/runs", after="not-an-anchor")


if __name__ == "__main__":
    unittest.main()
