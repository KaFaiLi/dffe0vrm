const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

// Only the DOM operations used by the request inspector are modeled here.
// Rendering, refresh decisions, search handlers and disclosure mounting execute
// from the shipped request.js, rather than being reimplemented in this fixture.
class Element {
  constructor(tag, className = '', text = '') {
    this.tagName = tag;
    this.className = className;
    this.children = [];
    this.listeners = new Map();
    this.attributes = {};
    this.dataset = {};
    this.scrollTop = 0;
    this.value = '';
    this.open = false;
    this.textContent = text;
    this.classList = {
      add: (name) => { this.className += ` ${name}`; },
      toggle: () => {},
    };
  }
  set textContent(value) { this.text = String(value); this.children = []; }
  get textContent() { return this.text + this.children.map(c => c.textContent).join(''); }
  append(...children) { for (const child of children) child.parent = this; this.children.push(...children); }
  replaceChildren(...children) { this.text = ''; this.children = []; this.append(...children); }
  remove() { if (this.parent) this.parent.children = this.parent.children.filter(child => child !== this); }
  setAttribute(name, value) { this.attributes[name] = value; }
  addEventListener(name, listener) {
    const listeners = this.listeners.get(name) || [];
    listeners.push(listener);
    this.listeners.set(name, listeners);
  }
  dispatchEvent(event) { for (const listener of this.listeners.get(event.type) || []) listener(event); }
  showModal() { this.open = true; }
  scrollIntoView() {}
  matches(selector) {
    if (selector.startsWith('.')) return this.className.split(/\s+/).includes(selector.slice(1));
    if (selector.startsWith('#')) return this.id === selector.slice(1);
    return this.tagName === selector;
  }
  querySelectorAll(selector) {
    return this.children.flatMap(child => [
      ...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector),
    ]);
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
}

function harness() {
  const elements = new Map([
    'request-dialog', 'request-content', 'request-title', 'request-identity', 'request-coverage',
  ].map(id => [id, new Element('div')]));
  const content = elements.get('request-content');
  const state = {
    requestOpenVersion: 0, requestView: 'body', requestBodyStage: 'provider',
    requestDetail: null, agent: 'run', selected: 'run',
  };
  let response;
  const requests = [];
  const node = (tag, className, text) => new Element(tag, className, text);
  const context = vm.createContext({
    state, node, number: new Intl.NumberFormat('en'),
    $: id => elements.get(id) || content.querySelector(`#${id}`),
    document: {
      querySelectorAll: () => [],
      createTextNode: text => new Element('#text', '', text),
    },
    Event: class { constructor(type) { this.type = type; } },
    button: (label, action) => {
      const element = node('button', '', label);
      element.addEventListener('click', action);
      return element;
    },
    api: async url => {
      requests.push(url);
      const value = await response;
      if (value instanceof Error) throw value;
      return structuredClone(value);
    },
    urlState: () => {},
  });
  vm.runInContext(readFileSync(path.join(__dirname, '../static/request.js'), 'utf8'), context);
  return {
    content, state, requests,
    async refresh(value, preserve = true) {
      response = value;
      return context.openRequest(1, 'run', preserve);
    },
    async refreshSelected(value) {
      response = value;
      return context.refreshRequest();
    },
  };
}

function detail({ native = true, provider = false } = {}) {
  const record = (cursor, data) => ({ cursor, payload: { data, redactions: [] } });
  return {
    run_id: 'run', selected_cursor: 1,
    context: { request_id: 'request', round_id: 'round', purpose: 'answer' },
    coverage: { provider_http_body: provider ? 'captured' : 'not_observed' },
    native: native ? record(1, { model: 'synthetic', messages: [], prompt: 'needle' }) : null,
    provider: provider ? record(2, { body: { model: 'synthetic', input: 'needle' } }) : null,
    effective: null, original: null,
  };
}

function option(h, value) {
  return h.content.querySelector('select')?.children.find(child => child.value === value);
}

test('follow enables a late provider capture while selected native content is unchanged', async () => {
  const h = harness();
  await h.refresh(detail(), false);
  assert.equal(h.state.requestBodyStage, 'native');
  assert.equal(option(h, 'provider').disabled, true);
  await h.refresh(detail({ provider: true }));
  assert.equal(option(h, 'provider').disabled, false);
  assert.match(h.content.querySelector('.request-explanation').textContent, /available in the stage selector/);
  const select = h.content.querySelector('select');
  select.value = 'provider';
  select.dispatchEvent({ type: 'change' });
  assert.equal(JSON.parse(h.content.querySelector('.body-json').textContent).input, 'needle');
});

test('same-data successful refresh restores the inspector after a transient fetch failure', async () => {
  const h = harness();
  await h.refresh(detail(), false);
  assert.equal(await h.refresh(new Error('synthetic fetch failure')), false);
  assert.match(h.content.textContent, /synthetic fetch failure/);
  assert.equal(await h.refresh(detail()), true);
  assert.ok(h.content.querySelector('.body-json'));
  assert.equal(h.content.querySelector('.error-banner'), null);
});

test('a transient follow failure preserves selected body reading state through recovery', async () => {
  const h = harness();
  await h.refresh(detail(), false);
  const body = h.content.querySelector('.body-json');
  const search = h.content.querySelector('#body-search');
  const disclosure = h.content.querySelector('details');
  search.value = 'needle';
  search.dispatchEvent({ type: 'input' });
  disclosure.open = true;
  disclosure.dispatchEvent({ type: 'toggle' });
  h.content.scrollTop = 75;
  body.scrollTop = 25;
  assert.equal(await h.refresh(new Error('synthetic transient failure')), false);
  assert.equal(h.content.querySelector('.body-json'), body);
  assert.equal(await h.refresh(detail()), true);
  assert.equal(h.content.querySelector('.body-json'), body);
  assert.equal(h.content.querySelector('#body-search'), search);
  assert.equal(search.value, 'needle');
  assert.ok(body.querySelector('mark'));
  assert.equal(h.content.querySelector('details'), disclosure);
  assert.equal(disclosure.open, true);
  assert.equal(h.content.scrollTop, 75);
  assert.equal(body.scrollTop, 25);
  assert.equal(h.content.querySelector('.request-refresh-error'), null);
});

test('manual refresh retains the selected request and body through a failed fetch', async () => {
  const h = harness();
  await h.refresh(detail(), false);
  const selected = h.state.requestDetail;
  const body = h.content.querySelector('.body-json');
  assert.equal(await h.refreshSelected(new Error('synthetic manual refresh failure')), false);
  assert.equal(h.state.requestDetail, selected);
  assert.equal(h.state.requestCursor, 1);
  assert.equal(h.state.requestOwner, 'run');
  assert.equal(h.state.refreshPending, true);
  assert.equal(h.content.querySelector('.body-json'), body);
  assert.equal(await h.refreshSelected(detail()), true);
  assert.equal(h.content.querySelector('.body-json'), body);
  assert.equal(h.content.querySelector('.request-refresh-error'), null);
  assert.deepEqual(h.requests, Array(3).fill('/api/runs/run/requests/1'));
});

test('manual refresh can retry an initially failed request with no loaded detail', async () => {
  const h = harness();
  assert.equal(await h.refresh(new Error('synthetic initial request failure'), false), false);
  assert.equal(h.state.requestDetail, null);
  assert.equal(h.state.requestCursor, 1);
  assert.equal(await h.refreshSelected(detail()), true);
  assert.equal(h.state.requestDetail.selected_cursor, 1);
  assert.ok(h.content.querySelector('.body-json'));
  assert.deepEqual(h.requests, Array(2).fill('/api/runs/run/requests/1'));
});

test('unchanged successful refresh preserves body nodes, search, disclosures and scrolling', async () => {
  const h = harness();
  await h.refresh(detail(), false);
  const body = h.content.querySelector('.body-json');
  const search = h.content.querySelector('#body-search');
  const disclosure = h.content.querySelector('details');
  search.value = 'needle';
  search.dispatchEvent({ type: 'input' });
  assert.ok(body.querySelector('mark'));
  disclosure.open = true;
  disclosure.dispatchEvent({ type: 'toggle' });
  h.content.scrollTop = 75;
  body.scrollTop = 25;
  await h.refresh(detail());
  assert.equal(h.content.querySelector('.body-json'), body);
  assert.equal(h.content.querySelector('#body-search'), search);
  assert.equal(search.value, 'needle');
  assert.ok(body.querySelector('mark'));
  assert.equal(h.content.querySelector('details'), disclosure);
  assert.equal(disclosure.open, true);
  assert.equal(h.content.scrollTop, 75);
  assert.equal(body.scrollTop, 25);
});

test('follow renders a native stage arriving after no request stage was available', async () => {
  const h = harness();
  await h.refresh(detail({ native: false }), false);
  assert.equal(h.content.querySelector('select'), null);
  await h.refresh(detail());
  assert.equal(option(h, 'native')?.disabled, false);
  assert.ok(h.content.querySelector('.body-json'));
});

test('follow disables a disappearing provider stage while retaining unchanged native content', async () => {
  const h = harness();
  h.state.requestBodyStage = 'native';
  await h.refresh(detail({ provider: true }), false);
  assert.equal(option(h, 'provider').disabled, false);
  await h.refresh(detail());
  assert.equal(option(h, 'provider').disabled, true);
  assert.match(h.content.querySelector('.request-explanation').textContent, /was not recorded/);
  assert.ok(h.content.querySelector('.body-json'));
});

test('a slow changed-data refresh preserves UI choices made while the fetch is pending', async () => {
  const h = harness();
  await h.refresh(detail(), false);
  const oldBody = h.content.querySelector('.body-json');
  const search = h.content.querySelector('#body-search');
  search.value = 'needle';
  h.content.scrollTop = 10;
  oldBody.scrollTop = 5;
  let resolve;
  const pendingResponse = new Promise(done => { resolve = done; });
  const pendingRefresh = h.refresh(pendingResponse);
  // These are user actions after openRequest has started awaiting the API.
  search.value = 'synthetic';
  search.dispatchEvent({ type: 'input' });
  const disclosure = h.content.querySelector('details');
  disclosure.open = true;
  disclosure.dispatchEvent({ type: 'toggle' });
  h.content.scrollTop = 91;
  oldBody.scrollTop = 37;
  const updated = detail();
  updated.native.payload.data.prompt = 'updated needle';
  resolve(updated);
  await pendingRefresh;
  const newBody = h.content.querySelector('.body-json');
  assert.notEqual(newBody, oldBody);
  assert.match(newBody.textContent, /updated needle/);
  assert.equal(h.content.querySelector('#body-search').value, 'synthetic');
  assert.equal(newBody.querySelector('mark').textContent, 'synthetic');
  assert.equal(h.content.querySelector('details').open, true);
  assert.equal(h.content.scrollTop, 91);
  assert.equal(newBody.scrollTop, 37);
});
