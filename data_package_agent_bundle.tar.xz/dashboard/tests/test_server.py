"""Behavior checks for the independent dashboard service."""

from __future__ import annotations

import importlib.util
import json
import sqlite3
import sys
import tempfile
import threading
import unittest
from contextlib import closing
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import urlopen

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import ObservationDB, ThreadingHTTPServer, make_handler  # noqa: E402


def envelope(data: dict) -> str:
    return json.dumps({"schema_version": 1, "data": data, "redactions": []})


def create_current_database(path: Path) -> None:
    """Initialize the current writer schema with only the standard library.

    Loading the storage module directly preserves the standalone dashboard test
    command without importing the agent, provider or their third-party dependencies.
    The writer is closed before fixtures modify its private tables.
    """
    source = (
        Path(__file__).resolve().parents[2]
        / "src/mcp_agent_template/observability/recording/storage.py"
    )
    spec = importlib.util.spec_from_file_location("dashboard_test_storage", source)
    assert spec is not None and spec.loader is not None
    storage = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(storage)
    store = storage.LocalStore(path, 0)
    try:
        store.start()
    finally:
        store.close()


class DashboardTests(unittest.TestCase):
    """Exercise the standalone reader using the current production storage schema."""

    def setUp(self) -> None:
        """Populate a fresh current-schema database for the read-only dashboard."""
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "observability.sqlite3"
        create_current_database(self.path)
        db = sqlite3.connect(self.path)
        self.addCleanup(db.close)

        def add_run(run_id, parent, summary, completion="completed"):
            """Insert one synthetic run and its complete summary into the private table."""
            db.execute(
                "INSERT INTO _runs (run_id,root_run_id,parent_run_id,process_instance_id,"
                "agent_name,trace_id,thread_id,started,ended,completion,payload,summary) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    run_id,
                    "root" if parent else run_id,
                    parent,
                    "process",
                    "agent",
                    "trace",
                    None,
                    100,
                    105,
                    completion,
                    envelope({"agent_name": "agent"}),
                    envelope({"duration": 5, "summary": summary, "telemetry_complete": "complete"}),
                ),
            )

        add_run(
            "root",
            None,
            {"model_calls": 2, "calls_with_usage": 2, "input_tokens": 100, "output_tokens": 40},
        )
        add_run(
            "child",
            "root",
            {"model_calls": 1, "calls_with_usage": 1, "input_tokens": 60, "output_tokens": 20},
        )
        add_run(
            "missing",
            None,
            {"model_calls": 1, "calls_with_usage": 0, "input_tokens": 0, "output_tokens": 0},
            "failed",
        )
        for event_id, root, name, payload in (
            ("e1", "root", "tool.call.started", {"name": "ping"}),
            ("e2", "root", "log", {"message": "Tool done", "logger": "test", "level": "INFO"}),
            ("e3", "root", "capture.output", {"content": "full capture"}),
            (
                "e4",
                "root",
                "tool.wait_started",
                {"tool": {"name": "ping", "args": {"large": "value"}}},
            ),
        ):
            db.execute(
                "INSERT INTO _events(event_id,timestamp,event_name,root_run_id,run_id,payload) "
                "VALUES (?,?,?,?,?,?)",
                (event_id, 101, name, root, root, envelope(payload)),
            )
        db.execute(
            "INSERT INTO processes VALUES (?,?,?,?,?,?,?,?)",
            ("process", "test", 1, 100, 105, 106, "healthy", 0),
        )
        db.execute(
            "INSERT INTO spans VALUES (?,?,?,?,?,?,?,?)",
            (
                "trace",
                "span",
                None,
                "process",
                "agent.invoke agent",
                100,
                105,
                envelope({"kind": "SpanKind.INTERNAL", "status": "OK"}),
            ),
        )
        db.commit()
        db.close()
        self.observations = ObservationDB(self.path)

    def test_overview_uses_only_root_summaries_and_reports_unknown_usage(self) -> None:
        overview = self.observations.overview("all")
        self.assertEqual(overview["root_runs"], 2)
        self.assertEqual(overview["usage"]["model_calls"], 3)
        self.assertEqual(overview["usage"]["input_tokens"], 100)
        self.assertEqual(overview["usage"]["output_tokens"], 40)
        self.assertEqual(overview["usage"]["missing_calls"], 1)
        self.assertEqual(overview["tool_calls"], 1)
        self.assertEqual(overview["outcomes"], {"completed": 1, "failed": 1})
        self.assertEqual(overview["process_health"], {"count": 1, "unrecorded": 0, "unhealthy": 0})

    def test_child_tree_event_filters_and_full_record(self) -> None:
        """Read tree scopes and paged updates while rejecting writes to storage tables."""
        detail = self.observations.run_detail("child")
        self.assertEqual(detail["root_run_id"], "root")
        self.assertEqual({run["run_id"] for run in detail["runs"]}, {"root", "child"})
        self.assertEqual(len(detail["spans"]), 1)
        flow = self.observations.events("root", 0, 10, "flow")
        self.assertEqual(
            [item["event_name"] for item in flow["items"]],
            ["tool.call.started", "tool.wait_started"],
        )
        self.assertEqual(flow["items"][1]["label"], "ping")
        logs = self.observations.events("root", 0, 10, "logs")
        self.assertEqual(logs["items"][0]["preview"], "Tool done")
        first = self.observations.events("root", 0, 1, "all")
        self.assertTrue(first["has_more"])
        next_page = self.observations.events("root", first["next_cursor"], 1, "all")
        self.assertEqual(next_page["items"][0]["event_name"], "log")
        self.assertEqual(self.observations.event(3)["payload"]["data"]["content"], "full capture")
        with closing(sqlite3.connect(self.path)) as db:
            db.execute(
                "INSERT INTO _events(event_id,timestamp,event_name,root_run_id,run_id,payload) "
                "VALUES (?,?,?,?,?,?)",
                (
                    "e5",
                    106,
                    "model.finished",
                    "root",
                    "root",
                    envelope({"completion": "completed"}),
                ),
            )
            db.commit()
        update = self.observations.events("root", flow["next_cursor"], 10, "flow")
        self.assertEqual([item["event_name"] for item in update["items"]], ["model.finished"])
        with closing(self.observations.connect()) as db:
            with self.assertRaises(sqlite3.OperationalError):
                db.execute("DELETE FROM _events")

    def test_http_serves_page_and_read_only_api(self) -> None:
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.observations))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        base = f"http://127.0.0.1:{server.server_port}"
        with urlopen(base + "/") as response:
            self.assertIn(b"Data Package Agent", response.read())
        with urlopen(base + "/api/overview?window=all") as response:
            self.assertEqual(json.load(response)["root_runs"], 2)
        with urlopen(base + "/api/runs/child") as response:
            self.assertEqual(json.load(response)["root_run_id"], "root")
        with self.assertRaises(HTTPError) as missing:
            urlopen(base + "/api/runs/no-such-run")
        self.assertEqual(missing.exception.code, 404)

    def test_closed_wal_database_without_sidecars_is_readable(self) -> None:
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.commit()
        self.assertFalse(Path(str(self.path) + "-wal").exists())
        self.assertFalse(Path(str(self.path) + "-shm").exists())
        self.assertEqual(self.observations.overview("all")["root_runs"], 2)
        self.assertFalse(Path(str(self.path) + "-wal").exists())

    def test_request_pagination_full_payload_and_run_scoping(self) -> None:
        """Serve complete selected requests while keeping pagination and run scope exact."""
        full = "complete evidence " * 500 + "LAST_BYTE"
        with closing(sqlite3.connect(self.path)) as db:
            for index in range(510):
                owner = "child" if index == 509 else "root"
                payload = json.loads(
                    envelope(
                        {
                            "messages": [[{"type": "system", "content": full}]],
                            "model": "test-model",
                            "native_run_id": f"native-{index}",
                        }
                    )
                )
                payload["context"] = {
                    "round_id": f"round-{index}",
                    "request_id": f"request-{index}",
                    "run_id": owner,
                    "purpose": "agent",
                }
                db.execute(
                    "INSERT INTO _events(event_id,timestamp,event_name,root_run_id,run_id,payload) "
                    "VALUES (?,?,?,?,?,?)",
                    (f"model-{index}", 102, "model.started", "root", owner, json.dumps(payload)),
                )
            db.commit()
        first = self.observations.requests("root", 0, 25)
        self.assertTrue(first["has_more"])
        self.assertNotIn(full, json.dumps(first))
        cursor = first["items"][0]["cursor"]
        total, after = 0, 0
        while True:
            page = self.observations.requests("root", after, 25)
            total += len(page["items"])
            if not page["has_more"]:
                break
            after = page["next_cursor"]
        self.assertEqual(total, 510)
        detail = self.observations.request("root", cursor)
        self.assertEqual(detail["native"]["payload"]["data"]["messages"][0][0]["content"], full)
        self.assertEqual(detail["coverage"]["definition"], "unavailable")
        self.assertIsNone(self.observations.request("missing", cursor))
        self.assertIsNone(self.observations.request("child", cursor))
        self.assertEqual(len(self.observations.requests("child", 0, 25)["items"]), 1)

        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.observations))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        base = f"http://127.0.0.1:{server.server_port}"
        with urlopen(base + "/api/runs/root/requests?limit=1") as response:
            self.assertEqual(len(json.load(response)["items"]), 1)
        with urlopen(base + f"/api/runs/root/requests/{cursor}") as response:
            self.assertEqual(
                json.load(response)["native"]["payload"]["data"]["messages"][0][0]["content"], full
            )
        with self.assertRaises(HTTPError) as missing:
            urlopen(base + f"/api/runs/missing/requests/{cursor}")
        self.assertEqual(missing.exception.code, 404)


if __name__ == "__main__":
    unittest.main()
