const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

function harness() {
  const elements = new Map();
  const scrolls = [];
  function element() {
    const classes = new Set();
    return {
      children: [], dataset: {}, value: '', textContent: '', open: false,
      classList: {
        add: name => classes.add(name), remove: name => classes.delete(name),
        contains: name => classes.has(name),
      },
      append(...children) { for (const child of children) child.parent = this; this.children.push(...children); },
      replaceChildren(...children) { this.children = []; this.append(...children); },
      addEventListener() {},
      querySelectorAll() { return []; },
      insertBefore(child, before) {
        child.remove();
        child.parent = this;
        const index = this.children.indexOf(before);
        this.children.splice(index < 0 ? this.children.length : index, 0, child);
      },
      remove() {
        if (this.parent) this.parent.children = this.parent.children.filter(child => child !== this);
        this.parent = null;
      },
      get lastChild() { return this.children.at(-1); },
      get lastElementChild() { return this.children.at(-1); },
      get isConnected() { return this.root || this.parent?.isConnected || false; },
      scrollIntoView() { scrolls.push({ element: this, connected: this.isConnected }); },
    };
  }
  function get(id) {
    if (!elements.has(id)) { const el = element(); el.root = true; elements.set(id, el); }
    return elements.get(id);
  }
  const context = vm.createContext({
    Intl, URLSearchParams, location: { search: '' },
    document: { getElementById: get, createElement: element },
  });
  const source = readFileSync(path.join(__dirname, '../static/app.js'), 'utf8');
  const boot = source.indexOf("\n$('window').value=state.window;");
  assert.ok(boot > 0);
  // Execute the production refresh and loadView functions without registering
  // browser event handlers or starting the polling timer.
  vm.runInContext(source.slice(0, boot), context);
  vm.runInContext(readFileSync(path.join(__dirname, '../static/request.js'), 'utf8'), context);
  vm.runInContext(`
    state.database={identity:'fixture',watermark:'old'};
    state.initialized=true;state.initialLoadComplete=true;
    state.selected='root';state.agent='child';state.tab='activity';
    state.selection='event:17';state.offset=50;state.eventPage={after:100};
    state.inspector='record';
    viewChrome=()=>{};urlState=()=>{};
    loadRuns=()=>api('/fixture/runs');
    loadRunHeader=()=>api('/fixture/header');
    renderEvents=()=>{};
  `, context);
  const state = vm.runInContext('state', context);
  const counts = new Map();
  const failures = new Map();
  context.api = async url => {
    const key = url === '/api/database' ? 'database'
      : url === '/fixture/runs' ? 'runs'
      : url === '/fixture/header' ? 'header'
      : url.includes('/activity?') ? 'activity'
      : url.includes('/usage?') ? 'usage' : url;
    counts.set(key, (counts.get(key) || 0) + 1);
    if (failures.get(key)) {
      failures.set(key, failures.get(key) - 1);
      throw new Error(`Synthetic ${key} failure`);
    }
    if (key === 'database') return {
      identity: 'fixture', watermark: 'new', path: 'synthetic.sqlite3',
      schema_version: 2, counts: {},
    };
    if (key === 'usage') return { total: { total_tokens: 3 } };
    return {};
  };
  return { context, state, counts, failures, get, scrolls };
}

function navigation(state) {
  return JSON.stringify({
    selected: state.selected, agent: state.agent, tab: state.tab,
    selection: state.selection, offset: state.offset, eventPage: state.eventPage,
  });
}

test('failed refresh retries unchanged watermarks and keeps failure visible until recovery', async () => {
  const h = harness();
  const selected = navigation(h.state);
  h.failures.set('runs', 2);
  await h.context.refresh();
  assert.equal(h.state.refreshPending, true);
  assert.equal(h.get('connection').textContent, 'Refresh failed');
  await h.context.refresh();
  assert.equal(h.counts.get('runs'), 2);
  assert.equal(h.state.refreshPending, true);
  assert.equal(h.get('connection').textContent, 'Refresh failed');
  assert.equal(h.get('error-banner').classList.contains('hidden'), false);
  await h.context.refresh();
  assert.equal(h.counts.get('runs'), 3);
  assert.equal(h.counts.get('activity'), 1);
  assert.equal(h.state.refreshPending, false);
  assert.match(h.get('connection').textContent, /^Updated /);
  assert.equal(h.get('error-banner').classList.contains('hidden'), true);
  assert.equal(navigation(h.state), selected);
  await h.context.refresh();
  assert.equal(h.counts.get('runs'), 3);
});

test('view fetch failures reach the refresh retry path without losing selection', async () => {
  const h = harness();
  const selected = navigation(h.state);
  h.state.follow = true;
  h.failures.set('activity', 1);
  await h.context.refresh();
  assert.equal(h.state.refreshPending, true);
  assert.equal(h.get('connection').textContent, 'Refresh failed');
  await h.context.refresh();
  assert.equal(h.counts.get('activity'), 2);
  assert.equal(h.state.refreshPending, false);
  assert.equal(navigation(h.state), selected);
});

test('a failed initial load completes on a later poll without a new database write', async () => {
  const h = harness();
  h.state.database = null;
  h.state.initialLoadComplete = false;
  h.state.selection = '';
  const selected = navigation(h.state);
  h.failures.set('runs', 1);
  await h.context.refresh();
  assert.equal(h.state.initialLoadComplete, false);
  assert.equal(h.state.refreshPending, true);
  await h.context.refresh();
  assert.equal(h.counts.get('runs'), 2);
  assert.equal(h.counts.get('activity'), 1);
  assert.equal(h.state.initialLoadComplete, true);
  assert.equal(h.state.refreshPending, false);
  assert.equal(navigation(h.state), selected);
});

test('failure fetching the latest transcript page remains pending for retry', async () => {
  const h = harness();
  h.state.tab = 'conversation';
  h.state.follow = true;
  h.state.offset = 0;
  h.context.renderConversation = () => {};
  const api = h.context.api;
  let pages = 0;
  h.context.api = async url => {
    if (!url.includes('/conversation?')) return api(url);
    pages++;
    if (pages === 2) throw new Error('Synthetic latest-page failure');
    return { has_more: pages === 1, total_items: 100 };
  };
  await h.context.refresh();
  assert.equal(h.state.refreshPending, true);
  assert.equal(h.get('connection').textContent, 'Refresh failed');
  assert.equal(h.state.offset, 50);
  await h.context.refresh();
  assert.equal(pages, 3);
  assert.equal(h.state.refreshPending, false);
  assert.equal(h.state.offset, 50);
});

test('follow-request failures retry the same selected call with an unchanged watermark', async () => {
  const h = harness();
  const selected = navigation(h.state);
  h.get('request-dialog').open = true;
  h.state.requestDetail = { selected_cursor: 23 };
  h.state.requestCursor = 23;
  h.state.requestOwner = 'child';
  h.state.requestFollow = true;
  const requests = [];
  h.context.openRequest = async (...args) => {
    requests.push(args);
    return requests.length > 1;
  };
  await h.context.refresh();
  assert.equal(h.state.refreshPending, true);
  assert.equal(h.get('connection').textContent, 'Refresh failed');
  h.state.paused = true;
  await h.context.refresh();
  assert.equal(requests.length, 1);
  assert.equal(h.state.refreshPending, true);
  h.state.paused = false;
  await h.context.refresh();
  assert.deepEqual(requests, [[23, 'child', true], [23, 'child', true]]);
  assert.equal(h.state.refreshPending, false);
  assert.equal(navigation(h.state), selected);
  assert.equal(h.state.requestOwner, 'child');
  assert.equal(h.state.requestDetail.selected_cursor, 23);
});

test('Follow latest scrolls the mounted transcript node after unchanged reconciliation', () => {
  const h = harness();
  const page = {
    items: [{ calls: [], role: 'user', key: 'message', turn_id: 'turn',
      preview: 'Synthetic question', content_complete: true }],
    calls: [], rounds: [], turns: [{ id: 'turn', number: 1, usage: null }],
    has_more: false, total_turns: 1, total_rounds: 0,
  };
  h.context.renderConversation(page);
  const mounted = h.get('content').lastElementChild;
  h.state.follow = true;
  h.context.renderConversation(page);
  assert.equal(h.get('content').lastElementChild, mounted);
  assert.equal(h.scrolls.length, 1);
  assert.equal(h.scrolls[0].element, mounted);
  assert.equal(h.scrolls[0].connected, true);
  page.items[0].preview = 'Synthetic question with more text';
  h.context.renderConversation(page);
  assert.equal(h.get('content').lastElementChild, mounted);
  assert.equal(h.scrolls[1].element, mounted);
  assert.equal(h.scrolls[1].connected, true);
});
