"""Shared, read-only evidence helpers for the dashboard."""

from __future__ import annotations

import json
from typing import Any

CATEGORIES = {
    "llm": "LLM",
    "middleware": "Middleware",
    "tool": "Tool",
    "mcp": "MCP",
    "delegation": "Delegation",
    "log": "System log",
    "system": "Run / system",
    "recorder": "Recorder",
    "feedback": "Feedback",
    "other": "Other",
}


def envelope(value: str | None) -> dict:
    """Keep malformed evidence accessible rather than dropping the record."""
    if not value:
        return {}
    try:
        result = json.loads(value)
    except (ValueError, TypeError):
        return {"record_error": "Invalid JSON payload", "raw_payload": value}
    return result if isinstance(result, dict) else {"data": result}


def data(record: dict) -> dict:
    value = record.get("payload", {}).get("data", {})
    return value if isinstance(value, dict) else {}


def document(row: Any) -> dict:
    result = dict(row)
    for field in ("payload", "summary"):
        if field in result:
            result[field] = envelope(result[field])
    return result


def category(name: str) -> str:
    name = name or ""
    if name == "log":
        return "log"
    if name.startswith(("telemetry.", "mcp_agent_template.telemetry.")):
        return "recorder"
    if name.startswith(("feedback.", "evaluation.")):
        return "feedback"
    if name.startswith(("child.", "delegation.", "capture.child.", "capture.delegation.")):
        return "delegation"
    if name.startswith(("mcp.", "capture.mcp.")):
        return "mcp"
    if name.startswith(
        (
            "policy.",
            "context.",
            "plan.",
            "project.instructions",
            "model.round.",
            "model.dispatch.",
            "tool.wait",
            "tool.exposure.",
            "tool.catalog.",
        )
    ) or name in {
        "model.reserved",
        "model.denied",
        "tool.reserved",
        "tool.denied",
        "tool.suppressed",
        "capture.planning_directive",
        "capture.project_instructions",
        "capture.tool.original",
        "capture.tool.transformed",
        "capture.tool.effective",
        "result.truncated",
        "artifact.omitted",
    }:
        return "middleware"
    if name.startswith(("model.", "capture.model")):
        return "llm"
    if name.startswith(("tool.", "capture.tool.", "operation.")):
        return "tool"
    if name.startswith(("run.", "build.", "process.", "catalog.", "capture.graph.")) or name in {
        "capture.output",
        "capture.stream",
        "capture.agent_definition",
        "capture.run_definition",
    }:
        return "system"
    return "other"


def outcome(name: str, value: dict) -> str:
    level = str(value.get("level") or "").upper()
    if level in ("ERROR", "CRITICAL", "FATAL") or value.get("error") or value.get("error_results"):
        return "error"
    if level in ("WARN", "WARNING"):
        return "warning"
    if name.endswith((".denied", ".suppressed", ".round_limit")):
        return "denied"
    status = value.get("completion") or value.get("status")
    if isinstance(status, str):
        return status
    if name.endswith((".failed", ".error", "_failed")):
        return "error"
    if level:
        return level.lower()
    if name.endswith((".started", "_started")):
        return "started"
    return "recorded"


def preview(value: Any, limit: int = 240) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    return text[:limit]


def event_summary(record: dict) -> dict:
    value, name = data(record), record["event_name"]
    call = value.get("call") if isinstance(value.get("call"), dict) else {}
    tool = value.get("tool")
    if isinstance(tool, dict):
        tool = tool.get("name")
    model = value.get("model")
    if isinstance(model, dict):
        model = model.get("name")
    label = (
        value.get("logger")
        if name == "log"
        else call.get("name") or tool or model or value.get("name")
    )
    message = (
        value.get("message")
        if name == "log"
        else (
            value.get("reason")
            or value.get("completion")
            or value.get("decision")
            or value.get("args")
            or ""
        )
    )
    return {
        **{k: v for k, v in record.items() if k != "payload"},
        "category": category(name),
        "outcome": outcome(name, value),
        "label": preview(label or name, 120),
        "preview": preview(message),
        "level": value.get("level"),
        "logger": value.get("logger"),
        "duration": value.get("duration"),
        "record_error": record.get("payload", {}).get("record_error"),
    }


def json_sql(field: str = "payload") -> str:
    """Only call with a source-code column name, never a request parameter."""
    return f"CASE WHEN json_valid({field}) THEN {field} ELSE '{{}}' END"


def scope(db: Any, run_id: str) -> dict | None:
    row = db.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
    return document(row) if row else None


def usage_total(calls: list[dict]) -> dict:
    total = {
        "model_calls": len(calls),
        "calls_with_usage": 0,
        "partial_calls": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "reported_input_tokens": 0,
        "reported_output_tokens": 0,
    }
    for call in calls:
        coverage = call.get("usage_coverage")
        total["calls_with_usage"] += coverage == "reported"
        total["partial_calls"] += coverage == "partial"
        for name in ("input_tokens", "output_tokens"):
            amount = (call.get("usage") or {}).get(name)
            if isinstance(amount, (int, float)) and not isinstance(amount, bool) and amount >= 0:
                total[name] += amount
                if coverage == "reported":
                    total["reported_" + name] += amount
    total["missing_calls"] = len(calls) - total["calls_with_usage"] - total["partial_calls"]
    total["total_tokens"] = total["input_tokens"] + total["output_tokens"]
    return total
