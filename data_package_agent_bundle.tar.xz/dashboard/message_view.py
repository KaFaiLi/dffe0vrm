"""Text and exposed thinking-summary projections of recorded messages (stdlib only)."""

from __future__ import annotations

from typing import Any


def text_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict) and isinstance(value.get("value"), str):
        return value["value"]
    return ""


def summary_text(value: Any) -> str:
    """Read exposed text only; encrypted/signature fields are never a summary."""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n\n".join(part for item in value if (part := summary_text(item)))
    if isinstance(value, dict):
        if "summary" in value:
            return summary_text(value["summary"])
        for key in ("reasoning", "thinking", "text"):
            if part := text_value(value.get(key)):
                return part
    return ""


def present_message(message: dict) -> dict:
    """Separate provider-exposed summaries from answer text without rewriting evidence."""
    content = message.get("content", "")
    answer, summaries = [], []
    structured = False
    if isinstance(content, str):
        answer.append(content)
    elif isinstance(content, list):
        for block in content:
            if isinstance(block, str):
                answer.append(block)
            elif isinstance(block, dict):
                kind = block.get("type")
                if kind in ("reasoning", "thinking", "reasoning_summary", "summary_text"):
                    if part := summary_text(block):
                        summaries.append(part)
                elif kind in ("text", "output_text"):
                    answer.append(text_value(block.get("text")))
                else:
                    structured = True
            else:
                structured = True
    else:
        structured = True
    thinking = "\n\n".join(summaries)
    return {"text": "".join(answer), "thinking_summary": thinking, "structured_content": structured}


def stream_parts(values: dict) -> dict:
    """Project the recorded callback chunk without inferring text from token metadata."""
    chunk = values.get("chunk")
    message = chunk.get("message", chunk) if isinstance(chunk, dict) else None
    return present_message(message) if isinstance(message, dict) else present_message({})
