"""Paginated read-only navigation and complete selected-record inspection."""

from __future__ import annotations

import base64
import hashlib
import json
import math
import time
from pathlib import Path
from typing import Any

try:
    from .records import (
        CATEGORIES,
        category,
        data,
        document,
        envelope,
        event_summary,
        json_sql,
        outcome,
        scope,
    )
except ImportError:
    from records import (
        CATEGORIES,
        category,
        data,
        document,
        envelope,
        event_summary,
        json_sql,
        outcome,
        scope,
    )


def tables(db: Any) -> set[str]:
    return {
        r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")
    }


def database_info(db: Any, path: Path) -> dict:
    names = tables(db)
    counts = {
        name: db.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
        for name in ("runs", "events", "spans", "processes", "metric_points", "feedback")
        if name in names
    }
    dates = dict(
        db.execute("SELECT MIN(started) first_run,MAX(started) last_run FROM runs").fetchone()
    )
    event = dict(
        db.execute("SELECT MAX(cursor) cursor,MAX(timestamp) timestamp FROM events").fetchone()
    )
    marks = {"events": event, "counts": counts}
    for name, fields in (
        ("spans", "MAX(ended)"),
        ("processes", "MAX(heartbeat)"),
        ("metric_points", "MAX(timestamp)"),
    ):
        if name in names:
            marks[name] = db.execute(f"SELECT {fields} FROM {name}").fetchone()[0]
    files = {}
    for suffix in ("", "-wal"):
        try:
            stat = Path(str(path) + suffix).stat()
            files[suffix or "database"] = {"bytes": stat.st_size, "modified_ns": stat.st_mtime_ns}
        except FileNotFoundError:
            pass
    marks["files"] = files
    fingerprint = hashlib.sha256(f"{path}:{path.stat().st_ino}".encode()).hexdigest()[:16]
    return {
        "path": str(path),
        "filename": path.name,
        "identity": fingerprint,
        "schema_version": db.execute("PRAGMA user_version").fetchone()[0],
        "read_only": True,
        **dates,
        "counts": counts,
        "latest_event": event,
        "watermark": hashlib.sha256(json.dumps(marks, sort_keys=True).encode()).hexdigest(),
        "files": files,
        "categories": CATEGORIES,
        "server_time": time.time(),
    }


def anchor(values: list) -> str:
    return base64.urlsafe_b64encode(json.dumps(values).encode()).decode().rstrip("=")


def unanchor(value: str) -> list:
    try:
        result = json.loads(base64.urlsafe_b64decode(value + "=" * (-len(value) % 4)))
        if not isinstance(result, list) or len(result) != 2 or not isinstance(result[1], str):
            raise ValueError()
        if not isinstance(result[0], (int, float)) or not math.isfinite(result[0]):
            raise ValueError()
        return result
    except (ValueError, TypeError, UnicodeError) as exc:
        raise ValueError("Invalid page anchor") from exc


def run_list(
    db: Any,
    *,
    since: float = 0,
    after: str = "",
    limit: int = 30,
    q: str = "",
    status: str = "",
    thread_id: str = "",
) -> dict:
    clauses, params = ["parent_run_id IS NULL", "started>=?"], [since]
    if thread_id:
        clauses.append("thread_id=?")
        params.append(thread_id)
    if status:
        clauses.append("completion=?")
        params.append(status)
    if q:
        clauses.append("(instr(lower(run_id),lower(?))>0 OR instr(lower(agent_name),lower(?))>0)")
        params.extend((q, q))
    if after:
        started, identity = unanchor(after)
        clauses.append("(started<? OR (started=? AND run_id<?))")
        params.extend((started, started, identity))
    p = json_sql()
    rows = db.execute(
        f"""SELECT run_id,root_run_id,parent_run_id,agent_name,started,ended,completion,
        thread_id,summary,
        (SELECT substr(json_extract(m.value,'$.content'),1,150)
          FROM json_each({p},'$.data.input.messages') m
          WHERE json_valid(m.value)
            AND coalesce(json_extract(m.value,'$.type'),json_extract(m.value,'$.role'))
            IN ('human','user') ORDER BY CAST(m.key AS INTEGER) DESC LIMIT 1) title
        FROM runs WHERE {" AND ".join(clauses)} ORDER BY started DESC,run_id DESC LIMIT ?""",
        (*params, limit + 1),
    ).fetchall()
    items = []
    for row in rows[:limit]:
        r = dict(row)
        r["summary"] = envelope(r["summary"]).get("data", {}).get("summary", {})
        r["title"] = r["title"] or r["agent_name"] or r["run_id"]
        items.append(r)
    return {
        "items": items,
        "has_more": len(rows) > limit,
        "next_anchor": anchor([items[-1]["started"], items[-1]["run_id"]]) if items else None,
    }


def event_projection() -> str:
    p = json_sql("e.payload")

    def extract(path: str) -> str:
        return f"json_extract({p},'$.data.{path}')"

    entries = {
        "name": extract("name"),
        "logger": extract("logger"),
        "level": extract("level"),
        "message": f"substr({extract('message')},1,240)",
        "completion": extract("completion"),
        "status": extract("status"),
        "duration": extract("duration"),
        "reason": f"substr({extract('reason')},1,240)",
        "decision": extract("decision"),
        "model": f"coalesce({extract('model.name')},{extract('model')})",
        "tool": f"coalesce({extract('call.name')},{extract('tool.name')},{extract('tool')})",
        "args": f"substr({extract('args')},1,240)",
        "error": f"CASE WHEN {extract('error')} IS NOT NULL THEN 1 ELSE 0 END",
        "error_results": f"coalesce(json_array_length({p},'$.data.error_results'),0)",
    }
    return "json_object(" + ",".join(f"'{k}',{v}" for k, v in entries.items()) + ")"


def event_list(
    db: Any,
    *,
    after: int = 0,
    before: int = 0,
    limit: int = 100,
    latest: bool = False,
    root_id: str = "",
    run_id: str = "",
    process: str = "",
    category_filter: str = "",
    severity: str = "",
    logger: str = "",
    q: str = "",
    since: float = 0,
    until: float | None = None,
    unscoped: bool = False,
    round_id: str = "",
    native_id: str = "",
) -> dict:
    if after and before:
        raise ValueError("Use after or before, not both")
    if category_filter and category_filter not in CATEGORIES:
        raise ValueError("Unknown category")
    projection = event_projection()
    clauses, params = ["e.timestamp>=?"], [since]
    for field, value in (
        ("root_run_id", root_id),
        ("run_id", run_id),
        ("process_instance_id", process),
    ):
        if value:
            clauses.append(f"e.{field}=?")
            params.append(value)
    if unscoped:
        clauses.append("e.run_id IS NULL")
    for field, value in (("context.round_id", round_id), ("data.native_run_id", native_id)):
        if value:
            clauses.append(f"json_extract({json_sql('e.payload')},'$.{field}')=?")
            params.append(value)
    if until is not None:
        clauses.append("e.timestamp<=?")
        params.append(until)
    if category_filter:
        clauses.append("obs_category(e.event_name)=?")
        params.append(category_filter)
    if severity:
        clauses.append(f"obs_outcome(e.event_name,{projection})=?")
        params.append(severity)
    if logger:
        clauses.append(f"json_extract({json_sql('e.payload')},'$.data.logger')=?")
        params.append(logger)
    if q:
        clauses.append(
            f"(instr(lower(e.event_name),lower(?))>0 OR instr(lower({projection}),lower(?))>0 "
            "OR (e.event_name='log' AND instr(lower("
            f"json_extract({json_sql('e.payload')},'$.data.message')),lower(?))>0))"
        )
        params.extend((q, q, q))
    base_clauses, base_params = clauses[:], params[:]
    if after:
        clauses.append("e.cursor>?")
        params.append(after)
    if before:
        clauses.append("e.cursor<?")
        params.append(before)
    descending = bool(before or latest)
    rows = db.execute(
        f"""SELECT e.cursor,e.event_id,e.timestamp,e.event_name,e.root_run_id,e.run_id,
        e.process_instance_id,e.trace_id,e.span_id,{projection} projected,
        CASE WHEN json_valid(e.payload) THEN NULL ELSE 'Invalid JSON payload' END record_error
        FROM events e WHERE {" AND ".join(clauses)}
        ORDER BY e.cursor {"DESC" if descending else "ASC"} LIMIT ?""",
        (*params, limit + 1),
    ).fetchall()
    selected = list(rows[:limit])
    if descending:
        selected.reverse()
    items = []
    for row in selected:
        r = dict(row)
        r["payload"] = {"data": json.loads(r.pop("projected")), "record_error": r["record_error"]}
        items.append(event_summary(r))

    def exists(comparison: str, value: int) -> bool:
        return (
            db.execute(
                f"SELECT 1 FROM events e WHERE {' AND '.join(base_clauses)} "
                f"AND cursor{comparison}? LIMIT 1",
                (*base_params, value),
            ).fetchone()
            is not None
        )

    return {
        "items": items,
        "has_before": bool(items) and exists("<", items[0]["cursor"]),
        "has_after": bool(items) and exists(">", items[-1]["cursor"]),
        "first_cursor": items[0]["cursor"] if items else None,
        "last_cursor": items[-1]["cursor"] if items else None,
    }


def event_detail(db: Any, cursor: int) -> dict | None:
    row = db.execute("SELECT * FROM events WHERE cursor=?", (cursor,)).fetchone()
    if row is None:
        return None
    record = document(row)
    return {
        **record,
        "category": category(record["event_name"]),
        "outcome": outcome(record["event_name"], data(record)),
    }


def run_records(db: Any, run_id: str) -> dict | None:
    run = scope(db, run_id)
    if run is None:
        return None
    records = [
        document(row)
        for row in db.execute(
            """SELECT * FROM events WHERE run_id=? AND
        event_name IN ('run.started','run.finished','capture.output','capture.run_definition')
        ORDER BY cursor""",
            (run_id,),
        )
    ]
    siblings = (
        [
            dict(r)
            for r in db.execute(
                """SELECT run_id,started,ended,completion,thread_id FROM runs
        WHERE thread_id=? AND parent_run_id IS NULL ORDER BY started,run_id""",
                (run.get("thread_id"),),
            )
        ]
        if run.get("thread_id")
        else []
    )
    return {
        "run": run,
        "records": records,
        "thread_segments": siblings,
        "continuity": "Separate recorded invocations; no branch or linear continuity inferred.",
    }


def tool_groups(db: Any, run_id: str, *, selected: str | None = None) -> list[dict]:
    p = json_sql()
    rows = db.execute(
        f"""SELECT cursor,event_name,trace_id,span_id,
        coalesce(json_extract({p},'$.data.call.id'),json_extract({p},'$.data.tool_call_id'),
          CASE WHEN event_name='tool.call.started' THEN json_extract({p},'$.data.id') END) call_id,
        coalesce(json_extract({p},'$.data.call.name'),json_extract({p},'$.data.name'),
          json_extract({p},'$.data.tool')) name,
        json_extract({p},'$.data.completion') completion,
        json_extract({p},'$.data.duration') duration,
        json_extract({p},'$.data.attempt') attempt,
        json_extract({p},'$.data.execution_id') execution_id,
        json_array_length({p},'$.data.error_results') errors,
        json_extract({p},'$.data.result.status') result_status,
        substr(coalesce(json_extract({p},'$.data.call.args'),
          json_extract({p},'$.data.args')),1,240) args
        FROM events WHERE run_id=? AND (event_name LIKE 'tool.%' OR event_name LIKE 'capture.tool.%'
          OR event_name LIKE 'policy.%' OR event_name LIKE 'operation.%') ORDER BY cursor""",
        (run_id,),
    ).fetchall()
    groups, spans = {}, {}
    for row in rows:
        if row["call_id"]:
            key = str(row["call_id"])
            spans.setdefault((row["trace_id"], row["span_id"]), set()).add(key)
            groups.setdefault(
                key,
                {
                    "id": key,
                    "run_id": run_id,
                    "cursor": row["cursor"],
                    "name": row["name"] or "Tool",
                    "status": "incomplete",
                    "args_preview": row["args"],
                    "duration": None,
                    "attempts": [],
                    "sources": [],
                    "started": False,
                },
            )
    for row in rows:
        key = str(row["call_id"]) if row["call_id"] else None
        candidates = (
            spans.get((row["trace_id"], row["span_id"]), set()) if row["span_id"] else set()
        )
        if key is None and len(candidates) == 1:
            key = next(iter(candidates))
        if key not in groups:
            continue
        g = groups[key]
        g["sources"].append(row["cursor"])
        if row["event_name"] == "tool.call.started":
            g["started"] = True
            g["cursor"] = row["cursor"]
        if row["event_name"] == "tool.finished":
            g["status"] = (
                "error" if row["errors"] or row["result_status"] == "error" else "completed"
            )
        elif row["event_name"] in ("tool.denied", "policy.denied"):
            g["status"] = "denied"
        elif row["event_name"] == "tool.call.finished":
            g["duration"] = row["duration"]
            if g["status"] != "error":
                g["status"] = row["completion"] or g["status"]
        if row["event_name"] == "tool.attempt.started":
            g["attempts"].append(
                {
                    "attempt": row["attempt"],
                    "execution_id": row["execution_id"],
                    "cursor": row["cursor"],
                }
            )
    values = sorted(groups.values(), key=lambda g: g["cursor"])
    if selected is not None:
        values = [g for g in values if g["id"] == selected]
        for g in values:
            g["records"] = [
                document(db.execute("SELECT * FROM events WHERE cursor=?", (c,)).fetchone())
                for c in g["sources"]
            ]
            g["coverage"] = (
                "Explicit tool-call IDs and uniquely shared spans; "
                "unlinked transport records remain in Activity."
            )
    return values


def span_list(db: Any, run_id: str, offset: int, limit: int) -> dict | None:
    run = scope(db, run_id)
    if run is None:
        return None
    p = json_sql("s.payload")
    rows = db.execute(
        f"""SELECT s.trace_id,s.span_id,s.parent_span_id,s.process_instance_id,
          s.name,s.started,s.ended,
        json_extract({p},'$.data.kind') kind,json_extract({p},'$.data.status') status,
        json_extract({p},'$.data.attributes."mcp_agent_template.run_id"') run_id
        FROM spans s WHERE s.trace_id IN (SELECT trace_id FROM runs WHERE root_run_id=?)
        ORDER BY s.started,s.trace_id,s.span_id LIMIT ? OFFSET ?""",
        (run["root_run_id"], limit + 1, offset),
    ).fetchall()
    return {
        "items": [dict(r) for r in rows[:limit]],
        "has_more": len(rows) > limit,
        "offset": offset,
        "next_offset": offset + limit,
    }


def span_detail(db: Any, trace_id: str, span_id: str) -> dict | None:
    row = db.execute(
        "SELECT * FROM spans WHERE trace_id=? AND span_id=?", (trace_id, span_id)
    ).fetchone()
    if row is None:
        return None
    result = document(row)
    result["event_cursors"] = [
        r[0]
        for r in db.execute(
            "SELECT cursor FROM events WHERE trace_id=? AND span_id=? ORDER BY cursor",
            (trace_id, span_id),
        )
    ]
    return result


def processes(db: Any, offset: int, limit: int, selected: str = "") -> dict | None:
    if selected:
        row = db.execute(
            "SELECT * FROM processes WHERE process_instance_id=?", (selected,)
        ).fetchone()
        if row is None:
            return None
        sessions = [
            document(r)
            for r in db.execute(
                "SELECT * FROM events WHERE process_instance_id=? "
                "AND event_name='telemetry.session_finished' ORDER BY cursor",
                (selected,),
            )
        ]
        return {
            "process": dict(row),
            "sessions": sessions,
            "freshness": "Recorded heartbeat; not OS liveness.",
        }
    rows = db.execute(
        "SELECT * FROM processes ORDER BY started DESC,process_instance_id LIMIT ? OFFSET ?",
        (limit + 1, offset),
    ).fetchall()
    return {
        "items": [dict(r) for r in rows[:limit]],
        "has_more": len(rows) > limit,
        "offset": offset,
    }


def metrics(
    db: Any, offset: int, limit: int, process: str = "", collection: str = ""
) -> dict | None:
    if "metric_points" not in tables(db):
        return {"items": [], "has_more": False, "coverage": "Metric table unavailable"}
    where, params = ("WHERE process_instance_id=?", [process]) if process else ("", [])
    if collection:
        rows = db.execute(
            "SELECT * FROM metric_points WHERE collection_id=? ORDER BY point_index", (collection,)
        ).fetchall()
        return {"records": [document(r) for r in rows]} if rows else None
    rows = db.execute(
        "SELECT collection_id,point_index,process_instance_id,timestamp "
        f"FROM metric_points {where} "
        "ORDER BY timestamp DESC,collection_id,point_index LIMIT ? OFFSET ?",
        (*params, limit + 1, offset),
    ).fetchall()
    return {
        "items": [dict(r) for r in rows[:limit]],
        "has_more": len(rows) > limit,
        "offset": offset,
        "coverage": "Recorded snapshots; cumulative values are not summed across collections.",
    }


def metric_series(records: list[dict]) -> list[dict]:
    result = []
    for record in records:
        for resource in data(record).get("resource_metrics", []):
            for scope_value in resource.get("scope_metrics", []):
                for metric in scope_value.get("metrics", []):
                    for point in metric.get("data", {}).get("data_points", []):
                        result.append(
                            {
                                "name": metric.get("name"),
                                "unit": metric.get("unit"),
                                "temporality": metric.get("data", {}).get(
                                    "aggregation_temporality"
                                ),
                                "resource": resource.get("resource"),
                                "scope": scope_value.get("scope"),
                                "point": point,
                            }
                        )
    return result


def metric_history(db: Any, name: str, process: str, offset: int, limit: int) -> dict:
    """Keep points as independent observations, including cumulative and histogram fields."""
    if "metric_points" not in tables(db):
        return {"items": [], "has_more": False, "coverage": "Metric table unavailable"}
    clauses, params = [], []
    if process:
        clauses.append("process_instance_id=?")
        params.append(process)
    p = json_sql()
    clauses.append(f"""EXISTS (SELECT 1 FROM json_each({p},'$.data.resource_metrics') r,
        json_each(r.value,'$.scope_metrics') s,json_each(s.value,'$.metrics') m
        WHERE json_extract(m.value,'$.name')=?)""")
    params.append(name)
    rows = db.execute(
        f"""SELECT * FROM metric_points WHERE {" AND ".join(clauses)}
        ORDER BY timestamp DESC,collection_id,point_index LIMIT ? OFFSET ?""",
        (*params, limit + 1, offset),
    ).fetchall()
    result = []
    for row in rows[:limit]:
        record = document(row)
        for metric in metric_series([record]):
            if metric["name"] == name:
                result.append(
                    {
                        "collection_id": record["collection_id"],
                        "timestamp": record["timestamp"],
                        "process_instance_id": record["process_instance_id"],
                        **metric,
                    }
                )
    return {
        "items": result,
        "has_more": len(rows) > limit,
        "next_offset": offset + limit,
        "coverage": "Independent recorded points. Cumulative samples are not added together.",
    }
