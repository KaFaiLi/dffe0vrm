"""Todo behavior through real compiled graphs, without provider requests."""

import asyncio
import json
from contextlib import aclosing

import pytest
from langchain.agents import create_agent
from langchain.agents.middleware import TodoListMiddleware
from langchain.agents.middleware.todo import WRITE_TODOS_SYSTEM_PROMPT
from langchain.tools import ToolRuntime
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import tool
from langgraph.errors import GraphRecursionError

from mcp_agent_template.agent import AgentSpec, RunContext, build_agent, build_agent_tree
from mcp_agent_template.agent.runtime.context import ModelBudgetExceeded
from mcp_agent_template.agent.runtime.todos import AgentTodoMiddleware
from mcp_agent_template.config import Settings
from mcp_agent_template.observability import ObservabilityRuntime
from tests.support.models import RequestModel, ScriptedModel
from tests.support.observations import events, settings_at


def todo(content, status="in_progress"):
    return {"content": content, "status": status}


def write_call(call_id, todos):
    return {"name": "write_todos", "args": {"todos": todos}, "id": call_id}


def write_message(call_id, todos):
    return AIMessage(content="", tool_calls=[write_call(call_id, todos)])


@pytest.fixture
def settings(tmp_path):
    return Settings(_env_file=None, app_root=tmp_path, obs={"mode": "off"})


@pytest.mark.parametrize("sync", [False, True])
async def test_replacement_completion_and_clear_use_native_state(settings, sync):
    first = [todo("inspect"), todo("obsolete", "pending")]
    second = [todo("inspect", "completed"), todo("report"), todo("verify")]
    model = ScriptedModel(
        responses=[
            write_message("create", first),
            write_message("replace", second),
            write_message("clear", []),
            AIMessage(content="The result."),
        ]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    if sync:
        # Bundle observation is async-only; verify the todo adapter's sync hook
        # on a native graph without expanding the bundle's existing API.
        graph = create_agent(
            model, system_prompt=bundle.system_prompt, middleware=[AgentTodoMiddleware()]
        )
        result = graph.invoke({"messages": [HumanMessage(content="work")]})
    else:
        result = await bundle.ainvoke("work")
    assert result["todos"] == []
    results = [m for m in result["messages"] if isinstance(m, ToolMessage)]
    assert [m.tool_call_id for m in results] == ["create", "replace", "clear"]
    assert all(m.status == "success" for m in results)
    assert "obsolete" not in results[1].text
    assert "completed" in results[1].text
    assert result["messages"][-1].text == "The result."


async def test_stream_exposes_progress_and_unfinished_work_can_return(settings):
    initial = [todo("inspect"), todo("report", "pending")]
    final = [todo("inspect", "completed"), todo("report")]
    model = ScriptedModel(
        responses=[
            write_message("start", initial),
            write_message("progress", final),
            AIMessage(content="Report blocked by missing input."),
        ]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    async with aclosing(bundle.astream("work", stream_mode="values")) as stream:
        states = [state async for state in stream]
    assert any(state.get("todos") == initial for state in states)
    assert states[-1]["todos"] == final
    assert states[-1]["messages"][-1].text == "Report blocked by missing input."


async def test_fresh_call_does_not_recover_todos_and_ask_stays_text(settings):
    model = ScriptedModel(
        responses=[write_message("start", [todo("old work")]), AIMessage(content="done")]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    first = await bundle.ainvoke("work")
    assert first["todos"] == [todo("old work")]
    model.responses = [AIMessage(content="Direct answer.")]
    second = await bundle.ainvoke("simple")
    assert second.get("todos", []) == []
    assert not any(isinstance(m, ToolMessage) for m in second["messages"])
    assert await bundle.ask("simple") == "Direct answer."


@pytest.mark.parametrize("bad_todos", [[todo("bad", "blocked")], [{"status": "pending"}]])
async def test_invalid_update_preserves_previous_state(settings, bad_todos):
    original = [todo("valid")]
    model = ScriptedModel(
        responses=[
            write_message("valid", original),
            write_message("invalid", bad_todos),
            AIMessage(content="Could not update."),
        ]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    result = await bundle.ainvoke("work")
    assert result["todos"] == original
    errors = [m for m in result["messages"] if isinstance(m, ToolMessage) and m.status == "error"]
    assert [m.tool_call_id for m in errors] == ["invalid"]


async def test_duplicate_writes_are_rejected_but_unrelated_tool_runs(settings):
    called = []

    @tool
    def lookup() -> str:
        """Return a synthetic lookup result."""
        called.append("lookup")
        return "found"

    original = [todo("original")]
    model = ScriptedModel(
        responses=[
            write_message("original", original),
            AIMessage(
                content="",
                tool_calls=[
                    write_call("one", [todo("first")]),
                    write_call("two", []),
                    {"name": "lookup", "args": {}, "id": "lookup"},
                ],
            ),
            AIMessage(content="done"),
        ]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[], extra_tools=[lookup])
    result = await bundle.ainvoke("work")
    assert result["todos"] == original
    assert called == ["lookup"]
    statuses = {m.tool_call_id: m.status for m in result["messages"] if isinstance(m, ToolMessage)}
    assert statuses == {"original": "success", "one": "error", "two": "error", "lookup": "success"}


@pytest.mark.parametrize("source", ["mcp", "extra", "middleware", "child"])
async def test_todo_name_collisions_fail_at_build_time(settings, source):
    @tool
    def write_todos() -> str:
        """Conflicting application tool."""
        return "conflict"

    model = ScriptedModel(responses=[AIMessage(content="unused")])
    with pytest.raises(ValueError, match="[Cc]olliding.*write_todos"):
        if source == "child":
            await build_agent_tree(
                AgentSpec(
                    name="root",
                    description="Root",
                    model=model,
                    sub_agents=[
                        AgentSpec(
                            name="worker",
                            description="Worker",
                            model=model,
                            extra_tools=[write_todos],
                        )
                    ],
                ),
                settings,
                mcp_tools=[],
            )
        else:
            await build_agent(
                settings,
                model=model,
                mcp_tools=[write_todos] if source == "mcp" else [],
                extra_tools=[write_todos] if source == "extra" else [],
                middleware=(TodoListMiddleware(),) if source == "middleware" else (),
            )


class TodoByRequestModel(RequestModel):
    """Advance from invocation messages rather than a shared response counter."""

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        start = max(i for i, message in enumerate(messages) if isinstance(message, HumanMessage))
        label = messages[start].text
        results = {m.tool_call_id for m in messages[start:] if isinstance(m, ToolMessage)}
        self.observed.append(list(messages))
        if not results:
            calls = [write_call(f"start-{label}", [todo(label)])]
        elif f"inspect-{label}" not in results:
            calls = [{"name": "inspect_state", "args": {"label": label}, "id": f"inspect-{label}"}]
        elif f"finish-{label}" not in results:
            calls = [write_call(f"finish-{label}", [todo(label, "completed")])]
        else:
            calls = []
        return ChatResult(
            generations=[
                ChatGeneration(message=AIMessage(content="" if calls else label, tool_calls=calls))
            ]
        )


@pytest.mark.parametrize("tree", [False, True])
async def test_concurrent_invocations_and_worker_artifacts_are_isolated(settings, tree):
    reached = set()
    both_running = asyncio.Event()

    @tool
    async def inspect_state(label: str, runtime: ToolRuntime[RunContext]) -> str:
        """Inspect the synthetic invocation's checklist, then wait for its peer."""
        assert runtime.state["todos"] == [todo(label)]
        reached.add(label)
        if {"alpha", "beta"} <= reached:
            both_running.set()
        await both_running.wait()
        return label

    model = TodoByRequestModel(names=[])
    if tree:
        parent_todos = [todo("parent work")]
        parent = ScriptedModel(
            responses=[
                AIMessage(
                    content="",
                    tool_calls=[
                        write_call("parent", parent_todos),
                        *[
                            {"name": "ask_worker", "args": {"task": label}, "id": label}
                            for label in ("alpha", "beta")
                        ],
                    ],
                ),
                AIMessage(content="Parent answer."),
            ]
        )
        bundle = await build_agent_tree(
            AgentSpec(
                name="root",
                description="Root",
                model=parent,
                sub_agents=[
                    AgentSpec(
                        name="worker",
                        description="Worker",
                        model=model,
                        extra_tools=[inspect_state],
                    )
                ],
            ),
            settings,
            mcp_tools=[],
        )
        result = await asyncio.wait_for(bundle.ainvoke("parent"), timeout=10)
        assert result["todos"] == parent_todos
        workers = [
            m for m in result["messages"] if isinstance(m, ToolMessage) and m.name == "ask_worker"
        ]
        assert len(workers) == 2
        for message in workers:
            assert message.text == message.tool_call_id
            assert message.artifact["todos"] == [todo(message.tool_call_id, "completed")]
            assert message.artifact["agent"] == "worker"
        again = await bundle.sub_agent_tools[0].ainvoke(
            {"name": "ask_worker", "args": {"task": "again"}, "id": "again", "type": "tool_call"}
        )
        assert again.artifact["todos"] == [todo("again", "completed")]
    else:
        bundle = await build_agent(settings, model=model, mcp_tools=[], extra_tools=[inspect_state])
        results = await asyncio.wait_for(
            asyncio.gather(bundle.ainvoke("alpha"), bundle.ainvoke("beta")), timeout=10
        )
        assert [result["todos"] for result in results] == [
            [todo(label, "completed")] for label in ("alpha", "beta")
        ]
    assert {"alpha", "beta"} <= reached
    assert all(
        next(m.text for m in request if isinstance(m, SystemMessage)).count(
            WRITE_TODOS_SYSTEM_PROMPT
        )
        == 1
        for request in model.observed
    )


async def test_todos_share_tool_budget(settings):
    settings.agent_max_tool_calls = 1
    model = ScriptedModel(
        responses=[
            write_message("allowed", [todo("work")]),
            write_message("denied", [todo("work", "completed")]),
            AIMessage(content="Stopped at limit."),
        ]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    context = bundle.new_context()
    result = await bundle.ainvoke("work", context=context)
    assert context.budget.calls == 1
    assert result["todos"] == [todo("work")]
    assert any(
        isinstance(m, ToolMessage) and m.tool_call_id == "denied" and m.status == "error"
        for m in result["messages"]
    )


@pytest.mark.parametrize("limit", ["rounds", "models"])
async def test_todos_respect_round_and_model_limits(settings, limit):
    if limit == "rounds":
        settings.agent_max_iterations = 1
    else:
        settings.agent_max_model_calls = 1
    model = ScriptedModel(responses=[write_message("repeat", [todo("unfinished")])])
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    context = bundle.new_context()
    error = GraphRecursionError if limit == "rounds" else ModelBudgetExceeded
    with pytest.raises(error):
        await bundle.ainvoke("work", context=context)
    assert context.budget.calls == 1


async def test_existing_recording_captures_todos_and_complete_prompt(tmp_path):
    settings = settings_at(tmp_path)
    final_todos = [todo("recorded", "completed")]
    model = ScriptedModel(
        responses=[write_message("record", final_todos), AIMessage(content="Recorded answer.")]
    )
    async with ObservabilityRuntime.local(settings) as obs:
        bundle = await build_agent(settings, model=model, mcp_tools=[], observability=obs)
        result = await bundle.ainvoke("work")
        assert result["todos"] == final_todos
        assert await obs.aflush()
        definition = json.loads(bundle.definition_json)["data"]
        assert definition["middleware"].count("AgentTodoMiddleware") == 1
        assert [t["name"] for t in definition["tools"]] == [t.name for t in bundle.all_tools]
        assert definition["system_prompt"] == bundle.system_prompt
        requests = events(obs, "capture.model_request")
        assert len(requests) == 2
        for request in requests:
            assert request["data"]["system_message"]["content"] == bundle.system_prompt
        assert events(obs, "capture.output")[0]["data"]["todos"] == final_todos
        assert events(obs, "tool.finished")[0]["data"]["call"]["name"] == "write_todos"
        assert obs.errors == 0
