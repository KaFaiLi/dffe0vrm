"""Application-root observation configuration and subprocess propagation."""

from pathlib import Path

import pytest
from pydantic import ValidationError

from mcp_agent_template.config import Settings


def test_application_root_dotenv_observation_paths_and_child_settings(tmp_path):
    (tmp_path / ".env").write_text(
        "OBS_MODE=off\nOBS_DIR=records\nOBS_FLUSH_INTERVAL_MS=17\n"
        "GENAI_PROVIDER=socgenai_llm\nGENAI_MODEL=example-model\n",
        encoding="utf-8",
    )
    settings = Settings(app_root=tmp_path)
    assert settings.obs.mode == "off"
    assert settings.obs.flush_interval_ms == 17
    assert settings.resolve_path(settings.obs.dir) == tmp_path / "records"
    assert settings.skills_path == tmp_path / "skills"
    child = settings.mcp_server_env("stdio")
    assert child["OBS_MODE"] == "off"
    assert child["OBS_DIR"] == str(tmp_path / "records")
    assert child["APP_ROOT"] == str(tmp_path)
    assert child["GENAI_PROVIDER"] == "socgenai_llm"
    assert child["GENAI_MODEL"] == "example-model"
    assert child["ANALYSIS_RESULTS_DIR"] == str(tmp_path / ".mcp_agent_template" / "analysis")


def test_analysis_output_override_reaches_server_subprocess(tmp_path):
    settings = Settings(_env_file=None, app_root=tmp_path, analysis_results_dir="audit-output")
    assert settings.mcp_server_env("stdio")["ANALYSIS_RESULTS_DIR"] == str(
        tmp_path / "audit-output"
    )


def test_reasoning_effort_environment_is_propagated_and_can_be_cleared(tmp_path, monkeypatch):
    monkeypatch.setenv("GENAI_REASONING_EFFORT", "low")
    settings = Settings(_env_file=None, app_root=tmp_path, genai_reasoning_effort="max")
    assert settings.mcp_server_env("stdio")["GENAI_REASONING_EFFORT"] == "max"
    cleared = Settings(_env_file=None, app_root=tmp_path, genai_reasoning_effort=None)
    assert not any(
        key.lower() == "genai_reasoning_effort" for key in cleared.mcp_server_env("stdio")
    )


def test_root_environment_is_case_insensitive_and_constructor_wins(tmp_path, monkeypatch):
    monkeypatch.delenv("APP_ROOT", raising=False)
    monkeypatch.setenv("app_root", str(tmp_path))
    assert Settings(_env_file=None).app_root == tmp_path
    assert Settings(_env_file=None, app_root=tmp_path / "explicit").app_root == (
        tmp_path / "explicit"
    )


@pytest.mark.parametrize(
    "values",
    [
        {"agent_max_iterations": 0},
        {"agent_max_tool_calls": 0},
        {"agent_max_model_calls": 0},
        {"agent_max_concurrent_tools": 0},
        {"agent_run_timeout": float("inf")},
    ],
)
def test_invalid_limits_are_rejected_before_construction(values):
    with pytest.raises(ValidationError):
        Settings(_env_file=None, **values)


def test_python_baseline_is_312():
    import tomllib

    root = Path(__file__).resolve().parents[1]
    project = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
    assert project["project"]["requires-python"] == ">=3.12"
    assert project["tool"]["ruff"]["target-version"] == "py312"
    assert (root / ".python-version").read_text().strip() == "3.12"
