from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from mcp_agent_template.notebook import _extract_reasoning, _trace_message_markup


def test_tool_catalog_displays_escaped_tool_metadata(monkeypatch):
    from types import SimpleNamespace

    from mcp_agent_template import notebook

    monkeypatch.setattr(notebook, "_html_obj", lambda markup: markup)
    tool = SimpleNamespace(
        name="search_items",
        description="Search <catalog> & return results.\nAdditional details.",
        args={"query": {"type": "string"}},
    )

    markup = notebook.tool_catalog([tool])

    assert markup.count("<th ") == 3
    assert "search_items" in markup
    assert "Search &lt;catalog&gt; &amp; return results." in markup
    assert "query" in markup
    assert "Additional details." not in markup


def test_notebook_stream_owns_recording_for_bundle_and_raw_graph(tmp_path, monkeypatch):
    import asyncio
    import sys
    import types

    from mcp_agent_template.agent import build_agent
    from mcp_agent_template.notebook import stream_trace
    from mcp_agent_template.observability.recording.storage import read_rows
    from tests.support.models import RequestModel
    from tests.support.observations import settings_at

    display = types.ModuleType("IPython.display")
    display.HTML = lambda value: value
    display.Markdown = lambda value: value
    display.display = lambda *args, **kwargs: None
    display.update_display = lambda *args, **kwargs: None
    monkeypatch.setitem(sys.modules, "IPython.display", display)

    async def run():
        for raw in [False, True]:
            settings = settings_at(tmp_path / str(raw))
            bundle = await build_agent(settings, model=RequestModel(names=[]), mcp_tools=[])
            answer = await stream_trace(bundle.agent if raw else bundle, "hello", settings=settings)
            assert answer == "done:hello"
            path = settings.resolve_path(settings.obs.dir) / "observability.sqlite3"
            assert read_rows(path, "SELECT completion FROM runs") == [{"completion": "completed"}]

    asyncio.run(run())


def test_extract_reasoning_prefers_normalized_responses_blocks():
    """Read exposed summaries from current Responses content blocks."""
    message = AIMessage(
        content=[
            {
                "type": "reasoning",
                "summary": [{"type": "summary_text", "text": "Responses summary."}],
            },
            {"type": "text", "text": "Final answer."},
        ],
    )

    assert _extract_reasoning(message) == "Responses summary."


def test_nested_subagent_trace_renders_its_reasoning():
    assistant = AIMessage(
        content=[
            {"type": "reasoning", "reasoning": "Sub-agent reasoning summary."},
            {"type": "text", "text": "Sub-agent answer."},
        ],
        response_metadata={"output_version": "v1"},
    )
    trace = ToolMessage(
        content="Parent received a summarized result.",
        tool_call_id="call-1",
        name="ask_researcher",
        status="error",
        artifact={
            "agent": "researcher",
            "messages": [HumanMessage(content="Search for lamps."), assistant],
        },
    )

    markup = _trace_message_markup(trace)

    assert "Sub-agent reasoning summary." in markup
    assert "🧠 Reasoning" in markup
    assert "Sub-agent answer." in markup
    assert "Tool error" in markup
    assert "Parent received a summarized result." in markup
    assert "ask_researcher" in markup
    assert "researcher" in markup
