"""Real shared-provider Responses tool history stays usable with compaction."""

import json
from types import SimpleNamespace

import httpx2
import pytest
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool

from mcp_agent_template.agent import build_agent
from mcp_agent_template.agent.runtime.context_policy import _payload
from tests.support.observations import settings_at


@pytest.mark.parametrize("compact", [False, True])
async def test_shared_responses_tool_round_preserves_or_compacts_native_blocks(
    tmp_path, monkeypatch, compact
):
    OpenAI = pytest.importorskip("openai").OpenAI
    provider = pytest.importorskip("socgenai_llm.chat_model")
    requests = []
    tool_invocations = []
    result_text = "RESULT_START:42" + ("x" * 8000 if compact else "") + ":RESULT_END"
    reasoning = {
        "type": "reasoning",
        "id": "rs_synthetic",
        "summary": [{"type": "summary_text", "text": "Use the addition tool."}],
        "encrypted_content": "synthetic-opaque-reasoning",
    }
    function_call = {
        "type": "function_call",
        "id": "fc_synthetic",
        "call_id": "call_synthetic",
        "name": "add",
        # Preserve original whitespace rather than reserializing parsed arguments.
        "arguments": '{ "a": 19, "b": 23 }',
        "status": "completed",
    }

    @tool
    def add(a: int, b: int) -> str:
        """Add two integers and return a synthetic textual report."""
        tool_invocations.append((a, b))
        return result_text

    def handle(request):
        payload = json.loads(request.content)
        requests.append(payload)
        assert request.url.path == "/openai/v1/responses"
        assert payload["reasoning"] == {"effort": "max", "summary": "detailed"}
        assert "temperature" not in payload
        summary = payload.get("tool_choice") == "none"
        if summary:
            assert not payload.get("tools")
            assert not {"max_tokens", "max_completion_tokens", "max_output_tokens"} & payload.keys()
        if len(requests) == 1:
            output = [reasoning, function_call]
        else:
            output = [
                {
                    "type": "message",
                    "id": f"msg_synthetic_{len(requests)}",
                    "role": "assistant",
                    "status": "completed",
                    "content": [
                        {
                            "type": "output_text",
                            "text": "Completed add(19,23)=42." if summary else "42",
                            "annotations": [],
                        }
                    ],
                }
            ]
        return httpx2.Response(
            200,
            json={
                "id": f"resp_synthetic_{len(requests)}",
                "object": "response",
                "created_at": 1,
                "model": "synthetic-deployment",
                "status": "completed",
                "output": output,
                "usage": {"input_tokens": 4, "output_tokens": 2, "total_tokens": 6},
            },
        )

    with OpenAI(
        base_url="https://synthetic.invalid/openai/v1/",
        api_key="synthetic-key",
        max_retries=0,
        http_client=httpx2.Client(transport=httpx2.MockTransport(handle)),
    ) as client:
        # Only corporate client construction is replaced; the actual shared wrapper
        # and SDK perform request/result conversion through the mocked HTTP transport.
        monkeypatch.setattr(
            provider,
            "GenAiApiClient",
            lambda **kwargs: SimpleNamespace(
                get_genai_response=lambda *, request: client.responses.create(**request)
            ),
        )
        model = provider.GenAIChatModel(
            model="synthetic-deployment",
            use_responses_api=True,
            reasoning={"effort": "max", "summary": "detailed"},
            max_retries=0,
            disable_streaming=True,
        )
        settings = settings_at(
            tmp_path,
            skills_dir="compaction-test-skills",
            context_compaction={"input_token_budget": 12000 if compact else 32000},
        )
        bundle = await build_agent(settings, model=model, mcp_tools=[add])
        result = await bundle.ainvoke({"messages": [HumanMessage(content="Add 19 and 23.")]})

    assert tool_invocations == [(19, 23)]
    assert result["messages"][-1].text == "42"
    native_call = next(m for m in result["messages"] if isinstance(m, AIMessage) and m.tool_calls)
    assert next(b for b in native_call.content if b["type"] == "function_call") == function_call
    assert next(b for b in native_call.content if b["type"] == "reasoning") == reasoning
    assert next(m for m in result["messages"] if isinstance(m, ToolMessage)).content == result_text
    projected_call = _payload(native_call)
    assert not projected_call["tool_calls"]
    assert projected_call["content"] == native_call.content
    summaries = [p for p in requests if p.get("tool_choice") == "none"]
    final_input = requests[-1]["input"]
    if compact:
        assert summaries
        portions = "".join(
            message["content"].split("\nNext portion:\n", 1)[1]
            for payload in summaries
            for message in payload["input"]
        )
        assert result_text in portions
        assert "Use the addition tool." in portions
        assert json.dumps(function_call["arguments"])[1:-1] in portions
        assert not any(m["type"] == "function_call" for m in final_input)
    else:
        assert len(requests) == 2
        assert not summaries
        assert next(m for m in final_input if m["type"] == "function_call") == function_call
        assert next(m for m in final_input if m["type"] == "reasoning") == reasoning
        assert next(m for m in final_input if m["type"] == "function_call_output")["output"] == (
            result_text
        )
