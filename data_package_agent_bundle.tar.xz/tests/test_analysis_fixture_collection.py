"""Exercise real fixture setup across every ordering of nested and parent test files."""

import os
import subprocess
import sys
from itertools import permutations
from pathlib import Path

import pytest

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
FILES = (
    "tests/analysis/test_risk_metrics.py",
    "tests/test_risk_metrics_mcp.py",
    "tests/analysis/test_charts.py",
)


@pytest.mark.parametrize("files", tuple(permutations(FILES)))
def test_analysis_fixtures_survive_file_order(files, tmp_path):
    """Interleaved parent and analysis arguments retain both explicitly requested fixtures."""
    env = os.environ.copy()
    # Keep the child deterministic without importing unrelated installed plugins.
    env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    env.pop("PYTEST_ADDOPTS", None)
    env.pop("PYTEST_PLUGINS", None)
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-c",
            "pyproject.toml",
            "-p",
            "pytest_asyncio.plugin",
            *files,
            "-k",
            "test_complete_reports_preserve_sources_and_return_saved_markdown "
            "or test_risk_values_and_limit_history_without_consumption_overlays",
            "--basetemp",
            str(tmp_path / "pytest"),
            "--color=no",
            "--tb=short",
            "-q",
        ],
        cwd=PACKAGE_ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    output = result.stdout + result.stderr
    assert result.returncode == 0, output
    assert "2 passed" in result.stdout, output
