"""Evidence-bound single findings without provider calls or development data."""

import hashlib
import json
from copy import deepcopy
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage, ToolMessage

from notebooks.review_reporting import (
    CHECK_TOPICS,
    COMPARISONS,
    TOPIC_TOOLS,
    AuditReport,
    Criterion,
    MappingBasis,
    RunEvidence,
    Source,
    build_evidence_catalog,
    capture_run_evidence,
    render_audit_report,
    report_instructions,
    validate_audit_report,
)
from tests.support.paths import redirect_path_resolution


def call(name, args, key):
    return AIMessage(content="", tool_calls=[{"name": name, "args": args, "id": key}])


def source_fixture(tmp_path):
    return [
        Source(
            id=key,
            topic=topic,
            kind=kind,
            path=str(tmp_path / f"{key}.csv"),
            scope="Synthetic book A; 2026-01-01 to 2026-01-31",
        )
        for key, topic, kind in (
            ("PNL", "pnl", "pnl"),
            ("SGMR", "risk_metrics", "risk_consumption"),
            ("PTC", "post_trade", "post_trade_cases"),
        )
    ]


def tool_body(source, output_dir):
    folder = output_dir / source.topic
    folder.mkdir(parents=True, exist_ok=True)
    artifacts = [folder / "analysis.md", folder / "analysis.xlsx"]
    body = (
        f"Source dataset: {Path(source.path).name}\n"
        f"## Population {source.id}\n"
        f"| {Path(source.path).name} [row=1] | "
        f"Source {source.id} row 1: value 12 EUR; denominator 10. |\n"
        f"Workbook: {artifacts[1]}\nMarkdown: {artifacts[0]}"
    )
    for artifact in artifacts:
        artifact.write_text(body, encoding="utf-8")
    return body


def evidence_fixture(tmp_path):
    sources = source_fixture(tmp_path)
    output_dir = tmp_path / "output"
    messages = [
        call("load_skill", {"name": "market-activity-review"}, "load"),
        ToolMessage(content="Review skill loaded.", tool_call_id="load"),
    ]
    for source in sources:
        args = (
            {"folder_path": str(Path(source.path).parent)}
            if source.topic == "post_trade"
            else {"pnl_path" if source.topic == "pnl" else "sgmr_path": source.path}
        )
        child = [
            call(TOPIC_TOOLS[source.topic], args, source.id),
            ToolMessage(content=tool_body(source, output_dir), tool_call_id=source.id),
        ]
        messages.extend(
            [
                call(f"ask_{source.topic}", {"task": "Review synthetic evidence."}, source.topic),
                ToolMessage(
                    content="Topic review complete.",
                    tool_call_id=source.topic,
                    artifact={"agent": source.topic, "messages": child},
                ),
            ]
        )
    return sources, output_dir, messages


def report_fixture(sources, captured):
    return {
        "schema_version": "1.0",
        "run_id": "synthetic-review",
        "scope": "Synthetic book A",
        "sources": [s.model_dump() for s in sources],
        "mappings": [],
        "criteria": [],
        "execution_status": "completed",
        "topic_coverage": [
            {"topic": topic, "status": "completed", "explanation": "Tool result available."}
            for topic in TOPIC_TOOLS
        ],
        "checks": [
            {
                "check_id": key,
                "status": "insufficient_evidence",
                "basis": "Additional source or policy evidence is required.",
                "evidence_ids": [],
            }
            for key in CHECK_TOPICS
        ],
        "evidence": [
            {
                "id": f"E-{s.id}",
                "source_id": s.id,
                "locator": f"{Path(s.path).name} [row=1]",
                "excerpt": f"Source {s.id} row 1: value 12 EUR; denominator 10.",
                "level": "tool_report",
            }
            for s in sources
            if captured.statuses[s.topic] == "completed"
        ],
        "observations": [],
        "cross_source_matrix": [
            {
                "comparison": kind,
                "relationship": "unlinked",
                "assessment": "No supplied link.",
                "mapping_id": None,
                "compatibility_limits": ["No established entity mapping."],
                "evidence_ids": [],
                "follow_up": "Obtain effective-dated source mapping.",
            }
            for kind in COMPARISONS
        ],
        "final_finding": {
            "disposition": "further_evidence_required",
            "title": "Common issue not established",
            "conclusion": "Do not infer one common control failure from unrelated observations.",
            "criterion_ids": [],
            "condition": "The extracted populations are not linked.",
            "cross_source_comparisons": ["pnl_risk"],
            "cause": "Unknown",
            "demonstrated_effect": "No loss established.",
            "potential_exposure": "Cannot quantify from these extracts.",
            "recommendation": "Obtain source lineage and applicable policy.",
            "limitations": ["Independent populations and missing criteria."],
            "evidence_ids": [],
        },
        "evidence_requests": ["Effective-dated book mapping and applicable approval policy."],
        "artifacts": [{"path": path, "topic": topic} for path, topic in captured.artifacts.items()],
    }


def catalog_report_fixture(sources, captured):
    data = report_fixture(sources, captured)
    catalog = build_evidence_catalog(captured, sources)
    data["evidence"] = [
        {
            "id": item["id"],
            "catalog_id": next(
                key
                for key, ref in catalog.items()
                if ref.source_id == item["source_id"]
                and item["locator"] in ref.excerpt
                and item["excerpt"] in ref.excerpt
            ),
        }
        for item in data["evidence"]
    ]
    return data


@pytest.fixture
def review(tmp_path):
    sources, output_dir, messages = evidence_fixture(tmp_path)
    captured = capture_run_evidence(messages, sources, output_dir)
    return report_fixture(sources, captured), sources, captured


def validate(data, sources, captured, **kwargs):
    return validate_audit_report(
        json.dumps(data), run_id="synthetic-review", sources=sources, captured=captured, **kwargs
    )


def test_catalog_is_deterministic_and_does_not_read_sources_or_workbooks(review, monkeypatch):
    _, sources, captured = review

    def forbidden(*args, **kwargs):
        pytest.fail("Evidence catalogs must use only captured report text.")

    original_resolve = Path.resolve
    resolutions = []

    def resolve(path, *args, **kwargs):
        resolutions.append(path)
        return original_resolve(path, *args, **kwargs)

    monkeypatch.setattr(Path, "read_text", forbidden)
    monkeypatch.setattr(Path, "read_bytes", forbidden)
    monkeypatch.setattr(Path, "resolve", resolve)
    first = build_evidence_catalog(captured, sources)
    assert len(resolutions) == len(sources)
    assert first == build_evidence_catalog(captured, sources)
    reordered = RunEvidence(reports=list(reversed(captured.reports)))
    assert first == build_evidence_catalog(reordered, list(reversed(sources)))
    assert all(ref.id == key and ref.level == "tool_report" for key, ref in first.items())
    assert all(len(key) == len("catalog-") + 20 for key in first)


@pytest.mark.parametrize("duplicate", [True, False])
def test_short_catalog_ids_deduplicate_identical_records_and_fail_closed_on_collision(
    tmp_path, monkeypatch, duplicate
):
    original_sha256 = hashlib.sha256

    class Digest:
        def __init__(self, data):
            self.value = original_sha256(data).hexdigest()

        def hexdigest(self):
            return "a" * 20 + self.value[20:]

    monkeypatch.setattr("notebooks.review_reporting.hashlib.sha256", Digest)
    first = "Exact report line: amount 12 EUR."
    second = first if duplicate else "Different report line: amount 99 EUR."
    captured = RunEvidence(reports=[("pnl", {"PNL"}, first), ("pnl", {"PNL"}, second)])
    sources = source_fixture(tmp_path)
    if duplicate:
        assert len(build_evidence_catalog(captured, sources)) == 1
    else:
        with pytest.raises(ValueError, match="catalog ID collision"):
            build_evidence_catalog(captured, sources)


def test_multi_source_catalog_requires_unambiguous_bound_source_markers(tmp_path):
    sources = source_fixture(tmp_path)
    sources.append(
        Source(id="ADJ", topic="pnl", kind="adjustments", path=str(tmp_path / "ADJ.csv"), scope="A")
    )
    body = "\n".join(
        [
            "| PNL.csv [row=1] | PnL amount 12 EUR. |",
            "| ADJ.csv [row=2] | Adjustment amount 9 EUR. |",
            "Unscoped summary does not establish a source.",
            "| PNL.csv [row=1] | ADJ.csv [row=2] | Ambiguous combined row. |",
            "| SGMR.csv [row=1] | A source outside the bound report. |",
            "| OTHER_PNL.csv [row=1] | Filename prefix is not a source marker. |",
        ]
    )
    captured = RunEvidence(reports=[("pnl", {"PNL", "ADJ"}, body)])
    catalog = build_evidence_catalog(captured, sources)
    assert len(catalog) == 2
    assert {ref.source_id for ref in catalog.values()} == {"PNL", "ADJ"}
    assert (
        next(ref for ref in catalog.values() if ref.source_id == "PNL").excerpt
        == body.splitlines()[0]
    )
    assert (
        next(ref for ref in catalog.values() if ref.source_id == "ADJ").excerpt
        == body.splitlines()[1]
    )


def test_catalog_ambiguous_basenames_need_genuine_full_paths(tmp_path):
    sources = [
        Source(
            id=key, topic="pnl", kind=kind, path=str(tmp_path / key / "same_name.csv"), scope="A"
        )
        for key, kind in (("PNL", "pnl"), ("ADJ", "adjustments"))
    ]
    full = sources[0].path.replace("_", r"\_")
    body = f"| same_name.csv [row=1] | Ambiguous basename. |\n| {full} | Amount 12 EUR. |"
    catalog = build_evidence_catalog(RunEvidence(reports=[("pnl", {"PNL", "ADJ"}, body)]), sources)
    assert len(catalog) == 1
    assert next(iter(catalog.values())).source_id == "PNL"


def test_catalog_binds_complete_literal_risk_commentary_without_interpreting_it(tmp_path):
    """Literal commentary retains its own provenance despite embedded filenames and fences."""
    sources = [
        Source(
            id="SGMR",
            topic="risk_metrics",
            kind="risk_consumption",
            path=str(tmp_path / "SGMR.parquet"),
            scope="A",
        ),
        Source(
            id="NOTE",
            topic="risk_metrics",
            kind="risk_commentary",
            path=str(tmp_path / "notes.md"),
            scope="A",
        ),
    ]
    lines = [
        '| SGMR.parquet [id="observation-1"] | Utilization 1.05 |',
        "Source: " + sources[1].path,
        "",
        "````text",
        "# Free-form source",
        "Claim about SGMR.parquet is still a commentary claim.",
        "```text",
        "Source: " + sources[0].path,
        "Embedded source marker must not reassign evidence.",
        "```",
        "````",
        "An unscoped summary outside the literal source.",
    ]
    captured = RunEvidence(reports=[("risk_metrics", {"SGMR", "NOTE"}, "\n".join(lines))])
    catalog = build_evidence_catalog(captured, sources)
    by_excerpt = {ref.excerpt: ref for ref in catalog.values()}
    assert by_excerpt[lines[0]].source_id == "SGMR"
    for index in (4, 5, 7, 8):
        assert by_excerpt[lines[index]].source_id == "NOTE"
    assert lines[-1] not in by_excerpt
    assert all("sha256" not in ref.locator for ref in catalog.values())


@pytest.mark.usefixtures("without_png_rendering")
@pytest.mark.parametrize("ambiguous", [False, True])
def test_excess_id_rows_retain_source_binding_without_file_locator(tmp_path, ambiguous):
    """Real excess rows are citable by ID while ambiguous sources and commentary stay separate."""
    from mcp_agent_template.analysis.risk_metrics import run_risk_metrics_analysis
    from tests.analysis.risk_support import write_comment, write_excesses, write_sgmr

    sgmr = write_sgmr(tmp_path / "risk.parquet")
    events = write_excesses(tmp_path / "events.csv")
    fake = "| FAKE-EVENT | commentary claim |"
    note = write_comment(tmp_path / "note.md", f"## Excess governance\n{fake}\n")
    report = run_risk_metrics_analysis(sgmr, events, note, output_dir=tmp_path / "reports")
    sources = [
        Source(id=key, topic="risk_metrics", kind=kind, path=str(path), scope="All dates")
        for key, kind, path in (
            ("SGMR", "risk_consumption", sgmr),
            ("COL", "excess_events", events),
            ("NOTE", "risk_commentary", note),
        )
    ]
    if ambiguous:
        sources.append(
            Source(
                id="COL2",
                topic="risk_metrics",
                kind="excess_events",
                path=str(tmp_path / "other.csv"),
                scope="All dates",
            )
        )
    captured = RunEvidence(reports=[("risk_metrics", {s.id for s in sources}, report)])
    catalog = build_evidence_catalog(captured, sources)
    row = next(line for line in report.splitlines() if line.startswith("| EVENT-A |"))
    matches = [ref for ref in catalog.values() if ref.excerpt == row]
    if ambiguous:
        assert not matches
    else:
        assert len(matches) == 1 and matches[0].source_id == "COL"
    assert any(ref.excerpt == fake and ref.source_id == "NOTE" for ref in catalog.values())


@pytest.mark.usefixtures("without_png_rendering")
def test_catalog_combines_current_pnl_sections_and_literal_risk_commentary(tmp_path):
    """Real PnL and risk reports preserve both renderer contracts in one evidence catalog."""
    from mcp_agent_template.analysis.pnl import run_pnl_analysis
    from mcp_agent_template.analysis.risk_metrics import run_risk_metrics_analysis
    from tests.analysis.pnl_support import dataset, write_csv
    from tests.analysis.risk_support import sgmr_series, write_sgmr

    paths, _, attribution, *_ = dataset(tmp_path / "pnl-input", n=20)
    attribution[-1]["Unexplained"] = 100
    write_csv(Path(paths["income_attribution_path"]), attribution)
    pnl_report = run_pnl_analysis(**paths, output_dir=tmp_path / "pnl-output")
    inputs = {
        "pnl": "pnl_path",
        "attribution": "income_attribution_path",
        "adjustments": "adjustments_path",
        "validation": "validation_history_path",
        "ia_commentary": "income_attribution_commentary_path",
        "pnl_commentary": "pnl_commentary_path",
    }
    sources = [
        Source(id=kind, kind=kind, path=paths[arg], topic="pnl", scope="All dates")
        for kind, arg in inputs.items()
    ]
    risk_path = write_sgmr(tmp_path / "SGMR.parquet", sgmr_series([10, 11, 12]))
    note_path = tmp_path / "risk-notes.md"
    claim = "A claim mentioning pnl.xlsx and SGMR.parquet remains commentary."
    fake = "| Fake PC | 999 |"
    note_path.write_text(
        f"# Source note\n{claim}\n```text\n## PC PnL summary\n{fake}\n```\n", encoding="utf-8"
    )
    risk_report = run_risk_metrics_analysis(
        risk_path, risk_metrics_commentary_path=note_path, output_dir=tmp_path / "risk-output"
    )
    sources += [
        Source(
            id="SGMR",
            kind="risk_consumption",
            path=str(risk_path),
            topic="risk_metrics",
            scope="All dates",
        ),
        Source(
            id="NOTE",
            kind="risk_commentary",
            path=str(note_path),
            topic="risk_metrics",
            scope="All dates",
        ),
    ]
    reports = [("pnl", set(inputs), pnl_report), ("risk_metrics", {"SGMR", "NOTE"}, risk_report)]

    catalog = build_evidence_catalog(RunEvidence(reports=reports), sources)

    assert catalog == build_evidence_catalog(RunEvidence(reports=list(reversed(reports))), sources)
    assert any(ref.source_id == "pnl" and "| PC1 |" in ref.excerpt for ref in catalog.values())
    assert any(
        ref.source_id == "attribution" and "Unexplained" in ref.excerpt for ref in catalog.values()
    )
    for line in (claim, fake):
        references = [ref for ref in catalog.values() if ref.excerpt == line]
        assert len(references) == 1
        assert references[0].source_id == "NOTE"
        assert references[0].locator.startswith("tool_report:risk_metrics:")


def test_single_source_catalog_uses_actual_tool_report_lines_and_preserves_whitespace(tmp_path):
    sources = source_fixture(tmp_path)
    line = "  | case 41 | Pending closure evidence. |  "
    body = f"## Case review\n\nshort\n{line}\n"
    captured = RunEvidence(reports=[("post_trade", {"PTC"}, body)])
    catalog = build_evidence_catalog(captured, sources)
    assert len(catalog) == 2
    ref = next(ref for ref in catalog.values() if ref.excerpt == line)
    assert ref.source_id == "PTC"
    assert ref.locator == "tool_report:post_trade:1:line:4"
    assert ref.level == "tool_report"
    assert not build_evidence_catalog(RunEvidence(reports=[("pnl", {"PTC"}, line)]), sources)


def test_catalog_selection_resolves_exact_server_owned_records_and_renders(review):
    _, sources, captured = review
    data = catalog_report_fixture(sources, captured)
    catalog = build_evidence_catalog(captured, sources)
    report = validate(data, sources, captured, evidence_mode="catalog")
    for selection, ref in zip(data["evidence"], report.evidence, strict=True):
        expected = catalog[selection["catalog_id"]].model_copy(update={"id": selection["id"]})
        assert ref == expected
        assert "catalog_id" not in ref.model_dump()
    assert "Source PNL row 1" in render_audit_report(report)
    assert "sha256:" not in render_audit_report(report)
    assert r"tool\_report:" in render_audit_report(report)


def test_catalog_resolution_keeps_whitespace_in_exact_lines(review):
    _, sources, captured = review
    topic, ids, body = captured.reports[-1]
    line = "  | case 41 | Pending closure evidence. |  "
    captured.reports[-1] = (topic, ids, body + "\n" + line)
    data = catalog_report_fixture(sources, captured)
    catalog = build_evidence_catalog(captured, sources)
    key = next(key for key, ref in catalog.items() if ref.excerpt == line)
    data["evidence"][-1]["catalog_id"] = key
    report = validate(data, sources, captured, evidence_mode="catalog")
    assert report.evidence[-1].excerpt == line
    assert json.loads(report.model_dump_json())["evidence"][-1]["excerpt"] == line


@pytest.mark.parametrize("field", ["source_id", "locator", "excerpt"])
def test_catalog_mode_rejects_manually_supplied_evidence_fields(review, field):
    _, sources, captured = review
    data = catalog_report_fixture(sources, captured)
    data["evidence"][0][field] = "Forged model-owned evidence."
    with pytest.raises(ValueError):
        validate(data, sources, captured, evidence_mode="catalog")


@pytest.mark.parametrize(
    "change", ["unknown_id", "stale_report", "wrong_topic", "missing_artifact"]
)
def test_catalog_selection_keeps_catalog_scope_and_existing_report_gates(review, change):
    _, sources, captured = review
    data = catalog_report_fixture(sources, captured)
    if change == "unknown_id":
        data["evidence"][0]["catalog_id"] = "catalog-forged"
    elif change == "stale_report":
        topic, ids, body = captured.reports[0]
        captured.reports[0] = (topic, ids, body + "\nReport changed after lookup.")
    elif change == "wrong_topic":
        data["evidence"][0]["catalog_id"] = data["evidence"][1]["catalog_id"]
        data["checks"][4].update(status="exception_identified", evidence_ids=["E-PNL"])
    else:
        data["artifacts"].pop()
    with pytest.raises(ValueError):
        validate(data, sources, captured, evidence_mode="catalog")


def test_catalog_model_schema_requests_only_evidence_selections():
    instructions = report_instructions(evidence_mode="catalog")
    schema = json.loads(instructions.split("\n", 1)[1])
    assert schema["properties"]["evidence"]["items"]["$ref"].endswith("/EvidenceSelection")
    assert set(schema["$defs"]["EvidenceSelection"]["properties"]) == {"id", "catalog_id"}
    assert "EvidenceReference" not in schema["$defs"]
    assert "lookup_review_evidence" in instructions
    assert report_instructions() == report_instructions(evidence_mode="verbatim")
    with pytest.raises(ValueError):
        report_instructions(evidence_mode="unsupported")


def test_roundtrip_has_one_finding_and_complete_workpapers(review):
    data, sources, captured = review
    report = validate(data, sources, captured)
    assert report.model_dump(mode="json") == data
    markdown = render_audit_report(report)
    assert markdown.count("## Final finding\n") == 1
    assert "Common issue not established" in markdown
    assert all(key in markdown for key in CHECK_TOPICS)
    assert len(report.checks) == 36
    assert len(report.artifacts) == 6


def test_final_and_matrix_comparison_schema_expose_the_same_allowed_identifiers(review):
    definitions = AuditReport.model_json_schema()["$defs"]
    matrix_values = definitions["CrossSourceComparison"]["properties"]["comparison"]["enum"]
    finding_values = definitions["FinalFinding"]["properties"]["cross_source_comparisons"]["items"][
        "enum"
    ]
    assert set(matrix_values) == set(finding_values) == set(COMPARISONS)
    data, sources, captured = review
    data["final_finding"]["cross_source_comparisons"] = ["P&L and risk human-readable label"]
    with pytest.raises(ValueError):
        validate(data, sources, captured)


@pytest.fixture
def chart_inputs(tmp_path):
    sources, output_dir, messages = evidence_fixture(tmp_path)
    charts = output_dir / "pnl" / "charts"
    charts.mkdir()
    for name in ("index.md", "manifest.json", "chart-0001.png"):
        (charts / name).write_text("Synthetic chart artifact.", encoding="utf-8")
    report = charts.parent / "analysis.md"
    report.write_text(
        report.read_text(encoding="utf-8")
        + "\n[Index](charts/index.md) [Manifest](charts/manifest.json) "
        + "![Preview](charts/chart-0001.png)\n",
        encoding="utf-8",
    )
    return sources, output_dir, messages


def test_explicitly_linked_chart_artifacts_are_optional_and_validated(chart_inputs):
    sources, output_dir, messages = chart_inputs
    captured = capture_run_evidence(messages, sources, output_dir)
    assert len(captured.artifacts) == 6
    assert len(captured.supporting_artifacts) == 3
    data = report_fixture(sources, captured)
    assert len(validate(data, sources, captured).artifacts) == 6
    data["artifacts"].extend(
        {"path": path, "topic": topic} for path, topic in captured.supporting_artifacts.items()
    )
    assert len(validate(data, sources, captured).artifacts) == 9


@pytest.mark.parametrize("change", ["missing_primary", "duplicate_optional", "unlinked_chart"])
def test_optional_charts_do_not_allow_missing_duplicate_or_unobserved_files(chart_inputs, change):
    sources, output_dir, messages = chart_inputs
    captured = capture_run_evidence(messages, sources, output_dir)
    data = report_fixture(sources, captured)
    if change == "missing_primary":
        data["artifacts"].pop()
    elif change == "duplicate_optional":
        path, topic = next(iter(captured.supporting_artifacts.items()))
        data["artifacts"].extend([{"path": path, "topic": topic}] * 2)
    else:
        path = output_dir / "pnl" / "charts" / "unlinked.png"
        path.write_bytes(b"Synthetic image.")
        data["artifacts"].append({"path": str(path), "topic": "pnl"})
    with pytest.raises(ValueError, match="Artifact inventory"):
        validate(data, sources, captured)


def test_chart_links_cannot_escape_the_report_directory_or_use_traversal(chart_inputs):
    sources, output_dir, messages = chart_inputs
    folder = output_dir / "pnl"
    (folder / "outside.md").write_text("Synthetic outside file.", encoding="utf-8")
    (folder / "charts" / "hidden.md").write_text("Synthetic hidden file.", encoding="utf-8")
    report = folder / "analysis.md"
    report.write_text(
        report.read_text(encoding="utf-8")
        + "\n[Outside](charts/../outside.md) [Outside](outside.md) "
        + "[Traversal](charts/inner/../hidden.md) "
        + f"[Absolute](<{folder / 'outside.md'}>)\n",
        encoding="utf-8",
    )
    captured = capture_run_evidence(messages, sources, output_dir)
    assert len(captured.supporting_artifacts) == 3


def test_resolved_chart_target_cannot_escape_the_chart_directory(chart_inputs, monkeypatch):
    sources, output_dir, messages = chart_inputs
    # Staying inside output_dir must not permit escape from the chart directory.
    outside = output_dir / "outside"
    outside.mkdir()
    (outside / "secret.md").write_text("Synthetic outside file.", encoding="utf-8")
    link = output_dir / "pnl" / "charts" / "linked"
    link.mkdir()
    (link / "secret.md").write_text("Directory placeholder.", encoding="utf-8")
    redirect_path_resolution(monkeypatch, {link: outside})
    report = output_dir / "pnl" / "analysis.md"
    report.write_text(
        report.read_text(encoding="utf-8") + "\n[Outside](charts/linked/secret.md)\n",
        encoding="utf-8",
    )
    captured = capture_run_evidence(messages, sources, output_dir)
    assert len(captured.supporting_artifacts) == 3


def test_resolved_chart_directory_cannot_broaden_the_allowed_directory(chart_inputs, monkeypatch):
    sources, output_dir, messages = chart_inputs
    charts = output_dir / "pnl" / "charts"
    target = output_dir / "other_charts"
    charts.rename(target)
    charts.mkdir()
    for path in target.iterdir():
        (charts / path.name).write_bytes(path.read_bytes())
    redirect_path_resolution(monkeypatch, {charts: target})
    captured = capture_run_evidence(messages, sources, output_dir)
    assert not captured.supporting_artifacts


def test_failed_child_chart_files_do_not_establish_artifact_provenance(chart_inputs):
    sources, output_dir, messages = chart_inputs
    messages[3].status = "error"
    captured = capture_run_evidence(messages, sources, output_dir)
    assert not captured.supporting_artifacts
    data = report_fixture(sources, captured)
    data["execution_status"] = "partial"
    data["topic_coverage"][0]["status"] = "failed"
    data["artifacts"].append(
        {"path": str(output_dir / "pnl" / "charts" / "index.md"), "topic": "pnl"}
    )
    with pytest.raises(ValueError, match="Artifact inventory"):
        validate(data, sources, captured)


@pytest.mark.parametrize(
    "change",
    [
        "missing_check",
        "duplicate_check",
        "second_finding",
        "missing_topic",
        "missing_comparison",
        "invented_evidence",
        "wrong_source",
        "invented_artifact",
        "invented_completion",
        "wrong_run",
        "unknown_criterion",
        "clean_with_gaps",
        "performed_without_evidence",
        "invented_mapping",
    ],
)
def test_reject_unsupported_report_claims(review, change):
    data, sources, captured = review
    if change == "missing_check":
        data["checks"].pop()
    elif change == "duplicate_check":
        data["checks"][-1] = deepcopy(data["checks"][0])
    elif change == "second_finding":
        data["findings"] = [data["final_finding"]]
    elif change == "missing_topic":
        data["topic_coverage"].pop()
    elif change == "missing_comparison":
        data["cross_source_matrix"].pop()
    elif change == "invented_evidence":
        data["evidence"][0]["excerpt"] = "Invented loss amount 9999."
    elif change == "wrong_source":
        data["evidence"][0]["source_id"] = "SGMR"
    elif change == "invented_artifact":
        data["artifacts"][0]["path"] += ".invented"
    elif change == "invented_completion":
        captured.statuses["pnl"] = "failed"
    elif change == "wrong_run":
        data["run_id"] = "other-run"
    elif change == "unknown_criterion":
        data["final_finding"]["criterion_ids"] = ["fictional-policy"]
    elif change == "clean_with_gaps":
        data["final_finding"]["disposition"] = "no_finding_identified"
    elif change == "performed_without_evidence":
        data["checks"][4]["status"] = "no_exception_identified"
    elif change == "invented_mapping":
        data["cross_source_matrix"][2]["mapping_id"] = "inferred-book-name"
    with pytest.raises(ValueError):
        validate(data, sources, captured)


def establish_link(data):
    basis = MappingBasis(
        id="book-map",
        source_ids=["PNL", "SGMR"],
        scope="Book A only",
        period="January 2026",
        measurement_basis="EUR, source identities checked",
        reference="Synthetic approved mapping record 1",
    )
    criterion = Criterion(
        id="control-1",
        requirement="Synthetic control obligation",
        reference="Synthetic policy section 1",
    )
    data["mappings"] = [basis.model_dump()]
    data["criteria"] = [criterion.model_dump()]
    data["cross_source_matrix"][2].update(
        {
            "relationship": "contradictory",
            "mapping_id": basis.id,
            "compatibility_limits": [],
            "evidence_ids": ["E-PNL", "E-SGMR"],
            "assessment": "Synthetic linked records disagree about the control outcome.",
        }
    )
    data["final_finding"].update(
        {
            "disposition": "supported_finding",
            "criterion_ids": [criterion.id],
            "evidence_ids": ["E-PNL", "E-SGMR"],
        }
    )
    return basis, criterion


def test_supported_contradiction_keeps_unrelated_post_trade_separate(review):
    data, sources, captured = review
    basis, criterion = establish_link(data)
    report = validate(data, sources, captured, mappings=[basis], criteria=[criterion])
    assert report.final_finding.disposition == "supported_finding"
    assert report.cross_source_matrix[-1].relationship == "unlinked"
    assert "Synthetic control obligation" in render_audit_report(report)


@pytest.mark.parametrize("gap", ["currency incompatible", "separate snapshots", "no case linkage"])
def test_compatibility_gaps_prevent_confirmed_links(review, gap):
    data, sources, captured = review
    basis, criterion = establish_link(data)
    data["cross_source_matrix"][2]["compatibility_limits"] = [gap]
    with pytest.raises(ValueError, match="compatible supplied mapping"):
        validate(data, sources, captured, mappings=[basis], criteria=[criterion])


def test_wrong_source_kinds_do_not_prove_post_trade_link(review):
    data, sources, captured = review
    basis, criterion = establish_link(data)
    data["cross_source_matrix"][-1].update(
        {
            "relationship": "confirmed",
            "mapping_id": basis.id,
            "compatibility_limits": [],
            "evidence_ids": ["E-PNL", "E-SGMR"],
        }
    )
    with pytest.raises(ValueError, match="source kinds"):
        validate(data, sources, captured, mappings=[basis], criteria=[criterion])


def test_clean_result_requires_performed_checks_or_justified_nonapplicability(review):
    data, sources, captured = review
    for check in data["checks"]:
        check.update(status="not_applicable", basis="Synthetic out-of-scope procedure.")
    data["checks"][4].update(
        status="no_exception_identified",
        basis="Synthetic P&L population test.",
        evidence_ids=["E-PNL"],
    )
    data["final_finding"]["disposition"] = "no_finding_identified"
    assert validate(data, sources, captured).final_finding.disposition == "no_finding_identified"


@pytest.mark.parametrize(
    "status, message",
    [
        ("failed", "Sub-agent 'risk_metrics' failed."),
        ("timed_out", "Sub-agent 'risk_metrics' timed out after 120s."),
    ],
)
def test_failed_child_retains_successful_sibling_evidence(tmp_path, status, message):
    sources, output_dir, messages = evidence_fixture(tmp_path)
    messages[5] = ToolMessage(content=message, tool_call_id="risk_metrics", status="error")
    captured = capture_run_evidence(messages, sources, output_dir)
    assert captured.statuses == {
        "pnl": "completed",
        "risk_metrics": status,
        "post_trade": "completed",
    }
    assert len(captured.artifacts) == 4
    data = report_fixture(sources, captured)
    data["execution_status"] = "partial"
    data["topic_coverage"][1]["status"] = status
    assert validate(data, sources, captured).execution_status == "partial"


def test_wrong_analysis_source_and_failed_tool_are_not_success(tmp_path):
    sources, output_dir, messages = evidence_fixture(tmp_path)
    messages[3].artifact["messages"][0].tool_calls[0]["args"]["pnl_path"] = "other.csv"
    messages[5].artifact["messages"][1].status = "error"
    captured = capture_run_evidence(messages, sources, output_dir)
    assert captured.statuses["pnl"] == captured.statuses["risk_metrics"] == "failed"


def test_malformed_json_and_duplicate_final_object_rejected(review):
    data, sources, captured = review
    for text in ("not JSON", '{"final_finding": {}, "final_finding": {}}'):
        with pytest.raises(ValueError):
            validate_audit_report(
                text, run_id="synthetic-review", sources=sources, captured=captured
            )


def test_source_content_cannot_create_active_html_or_links(review):
    data, sources, captured = review
    data["final_finding"]["condition"] = "<script>alert(1)</script> [click](https://invalid.test)"
    markdown = render_audit_report(validate(data, sources, captured))
    assert "<script>" not in markdown
    assert "[click](" not in markdown


@pytest.mark.parametrize(
    "check_id,evidence_id,accepted",
    [
        ("D01", "E-PNL", True),
        ("C01", "E-PNL", True),
        ("UNKNOWN", "E-PNL", False),
        ("R01", "E-PNL", False),
        ("D01", "E-SGMR", False),
    ],
)
def test_observation_shared_checks_keep_known_ids_and_topic_bound_evidence(
    review, check_id, evidence_id, accepted
):
    data, sources, captured = review
    data["observations"] = [
        {
            "id": "O1",
            "topic": "pnl",
            "check_ids": [check_id],
            "statement": "Synthetic observation.",
            "measures_and_basis": "12 EUR; denominator 10.",
            "contrary_evidence": "None supplied.",
            "uncertainty": "Source completeness unverified.",
            "follow_up": "Obtain source lineage.",
            "evidence_ids": [evidence_id],
        }
    ]
    if accepted:
        assert validate(data, sources, captured).observations[0].check_ids == [check_id]
    else:
        with pytest.raises(ValueError, match="observation|Observation"):
            validate(data, sources, captured)


@pytest.mark.parametrize(
    "check_ids,evidence_ids,accepted",
    [
        (["P10", "R10"], ["E-PNL", "E-SGMR"], True),
        (["P10", "R10", "C01"], ["E-PNL", "E-SGMR"], True),
        (["D01", "C01"], ["E-PNL", "E-SGMR"], True),
        (["P10"], ["E-PNL"], True),
        (["P10", "R10"], ["E-PNL"], False),
        (["P10", "R10"], ["E-SGMR"], False),
        (["R10", "C01"], ["E-PNL", "E-SGMR"], False),
        (["P10", "C01"], ["E-PNL", "E-SGMR"], False),
        (["P10", "R10"], ["E-PNL", "E-SGMR", "E-PTC"], False),
        (["D01", "C01"], ["E-SGMR", "E-PTC"], False),
        (["P10", "UNKNOWN", "C01"], ["E-PNL", "E-SGMR"], False),
    ],
)
def test_primary_theme_observations_require_evidence_for_exactly_the_cited_specific_topics(
    review, check_ids, evidence_ids, accepted
):
    _, sources, captured = review
    data = catalog_report_fixture(sources, captured)
    data["observations"] = [
        {
            "id": "CROSS-SOURCE",
            "topic": "pnl",
            "check_ids": check_ids,
            "statement": "Synthetic cross-source supporting observation.",
            "measures_and_basis": "Reported values and source-bound commentary.",
            "contrary_evidence": "No causal relationship established.",
            "uncertainty": "Entity mapping and source completeness need confirmation.",
            "follow_up": "Obtain authoritative mapping and definitions.",
            "evidence_ids": evidence_ids,
        }
    ]
    if accepted:
        report = validate(data, sources, captured, evidence_mode="catalog")
        assert report.observations[0].topic == "pnl"
        assert report.observations[0].check_ids == check_ids
    else:
        with pytest.raises(ValueError, match="observation|Observation"):
            validate(data, sources, captured, evidence_mode="catalog")


def test_cannot_relabel_a_quote_from_another_source_in_the_same_topic(review, tmp_path):
    data, sources, captured = review
    adjustment = Source(
        id="ADJ", topic="pnl", kind="adjustments", path=str(tmp_path / "ADJ.csv"), scope="Book A"
    )
    sources.append(adjustment)
    data["sources"] = [source.model_dump() for source in sources]
    topic, ids, body = captured.reports[0]
    captured.reports[0] = (
        topic,
        ids | {adjustment.id},
        body + "\n| ADJ.csv [row=2] | Adjustment amount 900 EUR. |",
    )
    data["evidence"][0].update(locator="ADJ.csv [row=2]", excerpt="Adjustment amount 900 EUR.")
    with pytest.raises(ValueError, match="bound successful tool report"):
        validate(data, sources, captured)


@pytest.mark.parametrize("locator", ["Population PNL", "PNL.csv [row=1]"])
def test_locator_and_excerpt_cannot_be_taken_from_unrelated_report_lines(review, locator):
    data, sources, captured = review
    data["evidence"][0].update(locator=locator, excerpt="Unrelated adjustment amount 900 EUR.")
    topic, ids, body = captured.reports[0]
    captured.reports[0] = (topic, ids, body + "\nUnrelated adjustment amount 900 EUR.")
    with pytest.raises(ValueError, match="bound successful tool report"):
        validate(data, sources, captured)


def test_escaped_filename_and_exact_quote_on_one_report_row_are_accepted(review, tmp_path):
    data, sources, captured = review
    sources[0] = sources[0].model_copy(update={"path": str(tmp_path / "pnl_a&b.csv")})
    data["sources"] = [source.model_dump() for source in sources]
    locator = r"pnl\_a&amp;b.csv \[sheet=Table\] \[row=2\]"
    excerpt = r"Reported amount &gt; 12 EUR \| explanatory text."
    data["evidence"][0].update(locator=locator, excerpt=excerpt)
    captured.reports[0] = ("pnl", {"PNL"}, f"| {locator} | {excerpt} |")
    assert validate(data, sources, captured).evidence[0].locator == locator


def test_filename_prefix_is_not_a_source_marker(review):
    data, sources, captured = review
    locator, excerpt = "OTHER_PNL.csv [row=1]", "Unrelated amount 900 EUR."
    data["evidence"][0].update(locator=locator, excerpt=excerpt)
    captured.reports[0] = ("pnl", {"PNL"}, f"| {locator} | {excerpt} |")
    with pytest.raises(ValueError, match="bound successful tool report"):
        validate(data, sources, captured)


def test_ambiguous_basename_requires_full_source_path(review, tmp_path):
    data, sources, captured = review
    adjustment = Source(
        id="ADJ",
        topic="pnl",
        kind="adjustments",
        path=str(tmp_path / "different" / "PNL.csv"),
        scope="Book A",
    )
    sources.append(adjustment)
    data["sources"] = [source.model_dump() for source in sources]
    captured.reports[0] = (
        "pnl",
        {"PNL", "ADJ"},
        captured.reports[0][2]
        + f"\n| {sources[0].path} [row=1] | {data['evidence'][0]['excerpt']} |",
    )
    with pytest.raises(ValueError, match="bound successful tool report"):
        validate(data, sources, captured)
    data["evidence"][0]["locator"] = f"{sources[0].path} [row=1]"
    assert validate(data, sources, captured).evidence[0].source_id == "PNL"


def test_pnl_trusted_path_compaction_preserves_verbatim_report_and_row_suffix(review):
    data, sources, captured = review
    row = f"| PNL.csv [sheet=Data] [row=17] | {data['evidence'][0]['excerpt']} |"
    captured.reports[0] = ("pnl", {"PNL"}, row)
    locator = f"{sources[0].path} [sheet=Data] [row=17]"
    data["evidence"][0].update(locator=locator, excerpt=row)
    report = validate(data, sources, captured)
    assert report.evidence[0].locator == locator
    assert report.evidence[0].excerpt == row


@pytest.mark.parametrize("change", ["wrong_row", "wrong_source", "ambiguous", "other_line"])
def test_pnl_path_compaction_does_not_relax_source_row_or_quote_binding(review, tmp_path, change):
    data, sources, captured = review
    excerpt = data["evidence"][0]["excerpt"]
    data["evidence"][0]["locator"] = f"{sources[0].path} [row=1]"
    if change == "wrong_row":
        data["evidence"][0]["locator"] = f"{sources[0].path} [row=2]"
    elif change == "wrong_source":
        data["evidence"][0]["locator"] = f"{sources[1].path} [row=1]"
    elif change == "ambiguous":
        sources.append(
            Source(
                id="ADJ",
                topic="pnl",
                kind="adjustments",
                path=str(tmp_path / "other" / "PNL.csv"),
                scope="Book A",
            )
        )
        data["sources"] = [source.model_dump() for source in sources]
    else:
        captured.reports[0] = ("pnl", {"PNL"}, f"PNL.csv [row=1]\n{excerpt}")
    with pytest.raises(ValueError, match="bound successful tool report"):
        validate(data, sources, captured)


def test_capture_binds_commentary_paths_to_their_parameter_roles(tmp_path):
    sources, output_dir, messages = evidence_fixture(tmp_path)
    args = messages[3].artifact["messages"][0].tool_calls[0]["args"]
    for key, kind, argument in (
        ("IA-C", "ia_commentary", "income_attribution_commentary_path"),
        ("PNL-C", "pnl_commentary", "pnl_commentary_path"),
    ):
        source = Source(
            id=key, topic="pnl", kind=kind, path=str(tmp_path / f"{key}.md"), scope="Book A"
        )
        sources.append(source)
        args[argument] = source.path
    assert capture_run_evidence(messages, sources, output_dir).statuses["pnl"] == "completed"
    left, right = "income_attribution_commentary_path", "pnl_commentary_path"
    args[left], args[right] = args[right], args[left]
    captured = capture_run_evidence(messages, sources, output_dir)
    assert captured.statuses["pnl"] == "failed"
    assert not any(topic == "pnl" for topic, _, _ in captured.reports)


def test_source_path_outside_manifest_cannot_supply_followup_evidence(tmp_path):
    sources, output_dir, messages = evidence_fixture(tmp_path)
    args = messages[3].artifact["messages"][0].tool_calls[0]["args"]
    expected = {"pnl": dict(args)}
    args["pnl_path"] = str(tmp_path / "different.csv")
    captured = capture_run_evidence(messages, sources, output_dir, expected_arguments=expected)
    assert captured.statuses["pnl"] == "failed"
    assert not any(analysis["topic"] == "pnl" for analysis in captured.analyses)
    assert not any(topic == "pnl" for topic, _, _ in captured.reports)


@pytest.mark.parametrize("argument", ["review_start", "review_end", "output_dir", "unsupported"])
def test_capture_rejects_arguments_outside_current_mcp_contract(tmp_path, argument):
    """Unsupported tool arguments cannot turn old or malformed traces into current evidence."""
    sources, output_dir, messages = evidence_fixture(tmp_path)
    args = messages[3].artifact["messages"][0].tool_calls[0]["args"]
    args[argument] = "synthetic"
    captured = capture_run_evidence(messages, sources, output_dir)
    assert captured.statuses["pnl"] == "failed"
    assert not any(topic == "pnl" for topic, _, _ in captured.reports)
    assert not any(topic == "pnl" for topic in captured.artifacts.values())
