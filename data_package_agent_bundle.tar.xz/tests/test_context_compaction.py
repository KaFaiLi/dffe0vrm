"""History-only compaction through native model hooks and real agent graphs."""

from __future__ import annotations

import asyncio
import json
import sys
import time
from types import SimpleNamespace
from typing import Any

import pytest
from langchain.agents.middleware import AgentMiddleware, ModelRequest
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, ChatMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import Field, ValidationError

from mcp_agent_template.agent import (
    AgentSpec,
    ContextCompactionSettings,
    build_agent,
    build_agent_tree,
)
from mcp_agent_template.agent.runtime.context import ModelBudgetExceeded, RunContext
from mcp_agent_template.agent.runtime.context_policy import (
    ContextCompactionMiddleware,
    _TokenCounter,
)
from mcp_agent_template.config import Settings
from mcp_agent_template.observability.recording.runtime import ObservabilityRuntime
from mcp_agent_template.observability.semantics import ContextLimitExceeded
from tests.support.observations import events
from tests.support.observations import settings_at as _settings_at

_COUNTER_INIT = _TokenCounter.__init__


def settings_at(path, **kwargs):
    # Keep these fixed-budget fixtures independent of the application skill catalog size.
    return _settings_at(path, skills_dir="compaction-test-skills", **kwargs)


class SummaryModel(BaseChatModel):
    observed: list[Any] = Field(default_factory=list)
    summary: str = "Completed work: result=42; next: answer the user."
    failure: Any = None
    summary_tool: bool = False

    @property
    def _llm_type(self):
        return "synthetic-summary-model"

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        summary = kwargs.get("tool_choice") == "none"
        self.observed.append({"summary": summary, "messages": list(messages), "kwargs": kwargs})
        if summary and self.failure:
            raise self.failure
        calls = [{"id": "bad", "name": "add", "args": {}}] if summary and self.summary_tool else []
        response = AIMessage(
            content=self.summary if summary else "done",
            tool_calls=calls,
            usage_metadata={"input_tokens": 4, "output_tokens": 2, "total_tokens": 6},
        )
        return ChatResult(generations=[ChatGeneration(message=response)])


@pytest.fixture(autouse=True)
def deterministic_counter(monkeypatch):
    def initialize(self, model):
        self.encoding = None
        self.method = "conservative:utf8-bytes"

    monkeypatch.setattr(_TokenCounter, "__init__", initialize)


def _history():
    return [
        HumanMessage(content="Earlier goal " + "a" * 4000, id="old-user"),
        AIMessage(content="Earlier decision " + "b" * 4000, id="old-ai"),
        HumanMessage(content="Current request", id="current"),
    ]


def _request(messages=None, *, model=None, context=None, **kwargs):
    return ModelRequest(
        model=model or SummaryModel(),
        messages=_history() if messages is None else messages,
        runtime=SimpleNamespace(context=context or RunContext()),
        **kwargs,
    )


def _middleware(**kwargs):
    return ContextCompactionMiddleware(ContextCompactionSettings(input_token_budget=3000, **kwargs))


async def _return(request):
    return request


def _summaries(model):
    return [call for call in model.observed if call["summary"]]


@pytest.mark.parametrize(
    "values",
    [
        {"input_token_budget": 0},
        {"summary_max_tokens": 0},
        {"keep_recent_groups": -1},
        {"trigger_fraction": 1},
        {"target_fraction": 0},
        {"target_fraction": 0.9},
        {"trigger_fraction": float("nan")},
        {"unknown": True},
    ],
)
def test_invalid_policy_is_rejected(values):
    with pytest.raises(ValidationError):
        ContextCompactionSettings(**values)


def test_environment_policy_is_opt_in_and_nested(tmp_path, monkeypatch):
    monkeypatch.setenv("CONTEXT_COMPACTION_INPUT_TOKEN_BUDGET", "6000")
    assert Settings(_env_file=None, app_root=tmp_path).context_compaction.input_token_budget == 6000
    assert ContextCompactionSettings().input_token_budget is None


@pytest.mark.asyncio
async def test_disabled_policy_preserves_request_even_with_media():
    request = _request([HumanMessage(content=[{"type": "image", "url": "synthetic"}])])
    middleware = ContextCompactionMiddleware(ContextCompactionSettings())
    assert await middleware.awrap_model_call(request, _return) is request
    assert not request.model.observed


@pytest.mark.asyncio
async def test_system_and_developer_anchors_are_unchanged_and_absent_from_summaries():
    system = SystemMessage(content="ORIGINAL_SYSTEM_SENTINEL")
    anchor = SystemMessage(content="APPLICATION_ANCHOR_SENTINEL")
    developer = ChatMessage(role="developer", content="DEVELOPER_SENTINEL")
    messages = [*_history()[:2], anchor, AIMessage(content="c" * 4000), developer, _history()[-1]]
    request = _request(messages, system_message=system)
    snapshots = [message.model_dump() for message in messages]
    result = await _middleware().awrap_model_call(request, _return)
    assert result.system_message is system
    assert result.messages[-1] is messages[-1]
    assert [m for m in result.messages if m in (anchor, developer)] == [anchor, developer]
    assert result.messages.index(anchor) < result.messages.index(developer)
    assert [message.model_dump() for message in messages] == snapshots
    material = "".join(m.text for call in _summaries(request.model) for m in call["messages"])
    for marker in (system.text, anchor.text, developer.text, messages[-1].text):
        assert marker not in material
    assert any("Conversation history summary" in m.text for m in result.messages)


def _tool_group(size=8000, *, complete=True, anchor=None):
    call = AIMessage(
        content="",
        id="calls",
        tool_calls=[
            {"name": "first", "id": "a", "args": {"x": 1}},
            {"name": "second", "id": "b", "args": {"x": 2}},
        ],
    )
    result = [
        call,
        ToolMessage(
            content="BEGIN_RESULT" + "x" * size + "END_RESULT",
            tool_call_id="b",
            artifact={"secret_artifact": "ARTIFACT_SENTINEL"},
            status="error",
        ),
    ]
    if anchor:
        result.append(anchor)
    if complete:
        result.append(ToolMessage(content="42", tool_call_id="a"))
    return result


@pytest.mark.asyncio
async def test_large_latest_parallel_group_is_summarized_in_full_without_artifacts():
    messages = [HumanMessage(content="Current request"), *_tool_group()]
    request = _request(messages)
    result = await _middleware().awrap_model_call(request, _return)
    calls = _summaries(request.model)
    assert len(calls) > 1
    portions = "".join(call["messages"][0].text.split("\nNext portion:\n", 1)[1] for call in calls)
    assert "BEGIN_RESULT" + "x" * 8000 + "END_RESULT" in portions
    assert '"tool_call_id":"a"' in portions and '"tool_call_id":"b"' in portions
    assert '"status":"error"' in portions
    assert "ARTIFACT_SENTINEL" not in portions
    assert result.messages[0] is messages[0]
    assert not any(isinstance(m, ToolMessage) for m in result.messages)
    for call in calls:
        assert _TokenCounter(request.model).messages(call["messages"]) <= 3000
        assert call["kwargs"]["tools"] == []
        assert (
            not {"max_tokens", "max_completion_tokens", "max_output_tokens"} & call["kwargs"].keys()
        )


@pytest.mark.asyncio
@pytest.mark.parametrize("anchor", [None, SystemMessage(content="protected anchor")])
async def test_partial_or_instruction_crossing_tool_group_is_never_compacted(anchor):
    request = _request(
        [HumanMessage(content="Current"), *_tool_group(complete=False, anchor=anchor)]
    )
    with pytest.raises(ContextLimitExceeded):
        await _middleware().awrap_model_call(request, _return)
    assert not request.model.observed


@pytest.mark.asyncio
async def test_complete_tool_group_crossing_an_instruction_is_protected():
    request = _request(
        [
            HumanMessage(content="Current"),
            *_tool_group(
                anchor=SystemMessage(content="protected anchor"),
            ),
        ]
    )
    with pytest.raises(ContextLimitExceeded):
        await _middleware().awrap_model_call(request, _return)
    assert not request.model.observed


@pytest.mark.asyncio
async def test_unchanged_summaries_are_reused_and_changed_history_invalidates_cache():
    request = _request()
    middleware = _middleware()
    await middleware.awrap_model_call(request, _return)
    count = len(_summaries(request.model))
    await middleware.awrap_model_call(request, _return)
    assert len(_summaries(request.model)) == count
    request.messages[0].content = "CHANGED_HISTORY" + "z" * 4000
    await middleware.awrap_model_call(request, _return)
    assert len(_summaries(request.model)) > count
    assert any(
        "CHANGED_HISTORY" in m.text
        for c in _summaries(request.model)[count:]
        for m in c["messages"]
    )


@pytest.mark.asyncio
async def test_new_history_merges_existing_summary_without_resending_old_content():
    request = _request()
    middleware = _middleware()
    await middleware.awrap_model_call(request, _return)
    count = len(_summaries(request.model))
    request.messages[-1:-1] = [AIMessage(content="NEW_HISTORY" + "z" * 4000)]
    await middleware.awrap_model_call(request, _return)
    material = "".join(
        m.text for call in _summaries(request.model)[count:] for m in call["messages"]
    )
    assert "Completed work: result=42" in material
    assert "NEW_HISTORY" in material
    assert "Earlier goal" not in material


@pytest.mark.asyncio
async def test_model_budget_exhaustion_keeps_cache_uncommitted():
    request = _request(context=RunContext(max_model_calls=1))
    with pytest.raises(ModelBudgetExceeded):
        await _middleware().awrap_model_call(request, _return)
    assert len(request.model.observed) == 1
    assert request.runtime.context.context_summaries == []


@pytest.mark.asyncio
@pytest.mark.parametrize("model", [SummaryModel(summary=""), SummaryModel(summary_tool=True)])
async def test_invalid_summary_never_commits_cache(model):
    request = _request(model=model)
    with pytest.raises(ValueError):
        await _middleware().awrap_model_call(request, _return)
    assert len(model.observed) == 1
    assert request.runtime.context.context_summaries == []


@pytest.mark.asyncio
async def test_provider_error_is_original_and_not_retried():
    failure = RuntimeError("synthetic provider error")
    request = _request(model=SummaryModel(failure=failure))
    with pytest.raises(RuntimeError) as caught:
        await _middleware().awrap_model_call(request, _return)
    assert caught.value is failure
    assert len(request.model.observed) == 1
    assert not request.runtime.context.context_summaries


@pytest.mark.asyncio
@pytest.mark.parametrize("protected", ["system", "user", "schema", "media"])
async def test_impossible_protected_input_fails_before_summary_or_main_dispatch(protected):
    kwargs = {}
    messages = _history()
    if protected == "system":
        kwargs["system_message"] = SystemMessage(content="s" * 4000)
    elif protected == "user":
        messages[-1].content = "u" * 4000
    elif protected == "schema":
        kwargs["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": "large",
                    "description": "s" * 4000,
                    "parameters": {"type": "object"},
                },
            }
        ]
    else:
        messages[0].content = [{"type": "image_url", "image_url": {"url": "synthetic"}}]
    request = _request(messages, **kwargs)
    with pytest.raises(ContextLimitExceeded):
        await _middleware().awrap_model_call(request, _return)
    assert not request.model.observed
    assert request.runtime.context.budget.model_calls == 0


def test_sync_hook_and_conservative_unicode_estimation():
    request = _request()
    result = _middleware().wrap_model_call(request, lambda projected: projected)
    assert result.messages[-1] is request.messages[-1]
    assert _summaries(request.model)
    assert _TokenCounter(request.model).text("中文") == 6


@pytest.mark.parametrize("known", [False, True])
def test_optional_tokenizer_and_unknown_deployment_fallback(monkeypatch, known):
    encoder = SimpleNamespace(name="synthetic-encoding", encode=lambda value, **kwargs: [1, 2])

    def encoding_for_model(name):
        if not known:
            raise KeyError(name)
        return encoder

    monkeypatch.setitem(
        sys.modules, "tiktoken", SimpleNamespace(encoding_for_model=encoding_for_model)
    )
    monkeypatch.setattr(_TokenCounter, "__init__", _COUNTER_INIT)
    counter = _TokenCounter(SummaryModel())
    assert counter.text("中文") == (2 if known else 6)
    assert counter.method == ("tiktoken:synthetic-encoding" if known else "conservative:utf8-bytes")


@pytest.mark.asyncio
async def test_child_and_concurrent_invocations_keep_separate_summary_caches():
    parent = RunContext()
    child = parent.child()
    first = _request(context=parent)
    second = _request(context=child)
    middleware = _middleware()
    await asyncio.gather(
        middleware.awrap_model_call(first, _return),
        middleware.awrap_model_call(second, _return),
    )
    assert parent.budget is child.budget
    assert parent.context_summaries is not child.context_summaries
    assert parent.context_summaries[0] is not child.context_summaries[0]
    assert parent.budget.model_calls == len(first.model.observed) + len(second.model.observed)


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True])
async def test_real_graph_preserves_history_records_summary_usage_and_effective_projection(
    tmp_path, tree
):
    settings = settings_at(tmp_path, context_compaction={"input_token_budget": 12000})
    model = SummaryModel()
    messages = _history()
    async with ObservabilityRuntime.local(settings) as obs:
        if tree:
            bundle = await build_agent_tree(
                AgentSpec("leaf", "test", model=model), settings, mcp_tools=[], observability=obs
            )
        else:
            bundle = await build_agent(settings, model=model, mcp_tools=[], observability=obs)
        context = bundle.new_context()
        result = await bundle.ainvoke({"messages": messages}, context=context)
        assert result["messages"][:3] == messages
        assert result["messages"][-1].text == "done"
        assert await obs.aflush()
        captured = events(obs, "capture.model_request")
        identities = [json.loads(event["payload"])["context"] for event in captured]
        assert all(identity["purpose"] == "summary" for identity in identities[:-1])
        assert identities[-1]["purpose"] == "agent"
        assert len({identity["request_id"] for identity in identities}) == len(identities)
        main = captured[-1]["data"]
        assert main["system_message"]["content"] == bundle.system_prompt
        assert "Conversation history summary" in main["messages"][0]["content"]
        started = events(obs, "model.started")
        summary_calls = len(_summaries(model))
        assert len(started) == summary_calls + 1
        assert context.budget.model_calls == summary_calls + 1
        finished = events(obs, "run.finished")[-1]["data"]["summary"]
        assert finished["model_calls"] == summary_calls + 1
        assert finished["input_tokens"] == 4 * (summary_calls + 1)
        assert finished["output_tokens"] == 2 * (summary_calls + 1)
        assert len(events(obs, "context.compaction")) == 1


@pytest.mark.asyncio
async def test_summary_messages_do_not_leak_into_native_stream(tmp_path):
    settings = settings_at(tmp_path, context_compaction={"input_token_budget": 12000})
    bundle = await build_agent(
        settings, model=SummaryModel(summary="PRIVATE_SUMMARY"), mcp_tools=[]
    )
    received = [
        item async for item in bundle.astream({"messages": _history()}, stream_mode="messages")
    ]
    assert received
    assert all("PRIVATE_SUMMARY" not in message.text for message, metadata in received)


@pytest.mark.asyncio
async def test_application_instruction_is_protected_after_request_transformation(tmp_path):
    class Directive(AgentMiddleware):
        async def awrap_model_call(self, request, handler):
            return await handler(
                request.override(
                    messages=[
                        SystemMessage(content="APPLICATION_SENTINEL"),
                        *request.messages,
                    ]
                )
            )

    model = SummaryModel()
    settings = settings_at(tmp_path, context_compaction={"input_token_budget": 12000})
    bundle = await build_agent(settings, model=model, mcp_tools=[], middleware=(Directive(),))
    await bundle.ainvoke({"messages": _history()})
    assert model.observed[-1]["messages"][1].text == "APPLICATION_SENTINEL"
    assert all(
        "APPLICATION_SENTINEL" not in m.text for c in _summaries(model) for m in c["messages"]
    )


@pytest.mark.asyncio
async def test_tree_installs_policy_on_every_node_with_explicit_overrides(tmp_path, monkeypatch):
    from mcp_agent_template.agent import factory

    built = {}
    native = factory.create_agent

    def capture(*args, **kwargs):
        built[kwargs["name"]] = kwargs["middleware"]
        return native(*args, **kwargs)

    monkeypatch.setattr(factory, "create_agent", capture)
    settings = settings_at(tmp_path, context_compaction={"input_token_budget": 12000})
    root = AgentSpec(
        "root",
        "test",
        model=SummaryModel(),
        sub_agents=[
            AgentSpec("inherited", "test", model=SummaryModel()),
            AgentSpec(
                "custom",
                "test",
                model=SummaryModel(),
                context_compaction=ContextCompactionSettings(input_token_budget=9000),
            ),
            AgentSpec(
                "disabled",
                "test",
                model=SummaryModel(),
                context_compaction=ContextCompactionSettings(),
            ),
        ],
    )
    bundle = await build_agent_tree(root, settings, mcp_tools=[])
    policies = {
        name: [
            m.policy.input_token_budget for m in stack if isinstance(m, ContextCompactionMiddleware)
        ]
        for name, stack in built.items()
    }
    assert policies == {"root": [12000], "inherited": [12000], "custom": [9000], "disabled": []}
    assert (
        json.loads(bundle.definition_json)["data"]["context_compaction"]["input_token_budget"]
        == 12000
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("deadline", [False, True])
async def test_cancellation_and_child_deadline_leave_no_partial_cache(deadline):
    class WaitingModel(SummaryModel):
        entered: Any = Field(default_factory=asyncio.Event)
        release: Any = Field(default_factory=asyncio.Event)
        closed: Any = Field(default_factory=asyncio.Event)

        async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
            self.entered.set()
            try:
                await self.release.wait()
                return self._generate(messages, stop, run_manager, **kwargs)
            finally:
                self.closed.set()

    model = WaitingModel()
    context = RunContext(timeout=10)
    if deadline:
        context._call_deadline = time.monotonic() + 0.1
    request = _request(model=model, context=context)
    pending = asyncio.create_task(_middleware().awrap_model_call(request, _return))
    await asyncio.wait_for(model.entered.wait(), 5)
    if not deadline:
        pending.cancel()
    with pytest.raises(TimeoutError if deadline else asyncio.CancelledError):
        await asyncio.wait_for(pending, 5)
    assert model.closed.is_set()
    assert context.context_summaries == []
    assert context.budget.model_calls == 1


@pytest.mark.asyncio
async def test_recent_complete_tool_groups_are_retained_when_they_fit():
    first = [
        AIMessage(content="", tool_calls=[{"name": "first", "id": "a", "args": {}}]),
        ToolMessage(content="42", tool_call_id="a"),
    ]
    second = [
        AIMessage(content="", tool_calls=[{"name": "second", "id": "b", "args": {}}]),
        ToolMessage(content="18", tool_call_id="b"),
    ]
    messages = [*_history(), *first, *second]
    result = await _middleware().awrap_model_call(_request(messages), _return)
    assert all(
        actual is original
        for actual, original in zip(result.messages[-4:], [*first, *second], strict=True)
    )


@pytest.mark.asyncio
async def test_below_trigger_dispatches_without_summary_and_preserves_schema_objects():
    from pydantic import BaseModel

    class Output(BaseModel):
        answer: str

    tool = {
        "type": "function",
        "function": {
            "name": "small",
            "parameters": {"type": "object"},
        },
    }
    request = _request([HumanMessage(content="short")], tools=[tool], response_format=Output)
    result = await _middleware().awrap_model_call(request, _return)
    assert result.tools is request.tools
    assert result.response_format is Output
    assert result.messages[0] is request.messages[0]
    assert not request.model.observed


@pytest.mark.asyncio
async def test_round_limit_counts_complete_history_after_compaction(tmp_path):
    from langchain_core.tools import tool
    from langgraph.errors import GraphRecursionError

    class RepeatingModel(SummaryModel):
        def _generate(self, messages, stop=None, run_manager=None, **kwargs):
            if kwargs.get("tool_choice") == "none":
                return super()._generate(messages, stop, run_manager, **kwargs)
            return ChatResult(
                generations=[
                    ChatGeneration(
                        message=AIMessage(
                            content="",
                            tool_calls=[
                                {"name": "large_result", "id": str(len(messages)), "args": {}}
                            ],
                        )
                    )
                ]
            )

    effects = []

    @tool
    async def large_result() -> str:
        """Return a large synthetic result."""
        effects.append(1)
        return "r" * 8000

    settings = settings_at(
        tmp_path, agent_max_iterations=1, context_compaction={"input_token_budget": 12000}
    )
    model = RepeatingModel()
    bundle = await build_agent(settings, model=model, mcp_tools=[], extra_tools=[large_result])
    with pytest.raises(GraphRecursionError):
        await bundle.ainvoke("Work on the task")
    assert effects == [1]
    assert _summaries(model)
