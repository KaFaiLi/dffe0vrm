"""FOX regression checks through real Parquet ingestion and report exports."""

from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace

import openpyxl
import pandas as pd
import polars as pl
import pytest

from mcp_agent_template.analysis.fox.preprocessing import load_cases, prepare_cases
from mcp_agent_template.analysis.fox.risk_analysis import score_and_select_reviews
from mcp_agent_template.analysis.fox.runners import run_fox_analysis
from mcp_agent_template.analysis.fox.summary_analysis import build_summaries
from mcp_agent_template.config import Settings
from tests.analysis.support import case_row, workbook_table, write_cases


@pytest.fixture
def fixed_snapshot(monkeypatch):
    snapshot = pd.Timestamp("2026-10-19 12:34:56")
    monkeypatch.setattr(
        "mcp_agent_template.analysis.fox.preprocessing.datetime",
        SimpleNamespace(now=lambda: snapshot.to_pydatetime()),
    )
    return snapshot


def test_required_schema_produces_both_reports_and_real_workbook(tmp_path):
    source = write_cases(tmp_path / "input" / "any-name.parquet")
    original = source.read_bytes()
    report = run_fox_analysis(source, output_dir=tmp_path / "reports")
    (workbook,) = (tmp_path / "reports").glob("*/FOX_audit_analysis.xlsx")
    markdown = workbook.with_suffix(".md")
    assert markdown.read_text(encoding="utf-8") == report
    assert str(workbook) in report
    assert str(markdown) in report
    assert "2025-01-01" in report
    assert source.read_bytes() == original
    saved = openpyxl.load_workbook(workbook)
    try:
        population = workbook_table(saved, "Overview", "FoxPopulation")
        summary = {row["Metric"]: row["Value"] for row in population}
        review = workbook_table(saved, "Overview", "FoxReview")
        metrics = {row["Metric"]: row["Value"] for row in review}
        assert summary["Analyzed rows"] == 1
        assert metrics["Completed without comments"] == 1
        assert metrics["Critical-priority cases"] == 1
        assert saved.sheetnames == [
            "Overview",
            "Control Analysis",
            "Monthly Trends",
            "Hit Search Analysis",
            "Processed Data",
        ]
    finally:
        saved.close()


@pytest.mark.parametrize("column", ["historic_comments_count", "hit_search_items"])
def test_missing_analysis_field_is_rejected_before_creating_reports(tmp_path, column):
    row = case_row()
    del row[column]
    source = write_cases(tmp_path / "input.parquet", [row])
    with pytest.raises(ValueError, match=f"Missing required columns: {column}"):
        run_fox_analysis(source, output_dir=tmp_path / "reports")
    assert not (tmp_path / "reports").exists()


@pytest.mark.parametrize("count", [-1, 1.5, "invalid", float("inf")])
def test_invalid_comment_counts_have_actionable_errors(count):
    with pytest.raises(ValueError, match="nonnegative whole numbers or null"):
        prepare_cases(pd.DataFrame([case_row(historic_comments_count=count)]))


def test_sparse_inputs_keep_analysis_fields_and_unknown_counts_are_not_zero(tmp_path):
    rows = [
        case_row(
            Case_Id=f"case-{index}",
            historic_comments_count=0 if index == 0 else None,
            isautoclosed=True if index == 0 else None,
            closure_date="2025-01-03" if index == 0 else None,
            hit_search_items="Synthetic item" if index == 0 else None,
        )
        for index in range(4)
    ]
    loaded = load_cases(write_cases(tmp_path / "input.parquet", rows))
    assert {"historic_comments_count", "closure_date", "isautoclosed", "hit_search_items"} <= set(
        loaded
    )
    prepared, _ = prepare_cases(loaded)
    assert prepared["historic_comments_count_numeric"].isna().sum() == 3
    assert prepared["completed_without_comments_derived"].tolist() == [True, False, False, False]
    assert prepared["auto_close_category"].tolist() == ["Auto", "Unknown", "Unknown", "Unknown"]
    assert prepared.loc[0, "days_to_close"] == 2


@pytest.mark.parametrize("values", [[True, False, None], ["TRUE", "false", "unrecognized"]])
def test_auto_closed_counts_are_preserved_in_all_summaries(values):
    frame = pd.DataFrame([case_row(Case_Id=str(i), isautoclosed=v) for i, v in enumerate(values)])
    prepared, snapshot = prepare_cases(frame)
    scored, _, _ = score_and_select_reviews(prepared)
    summary = build_summaries(scored, snapshot)
    assert scored["auto_close_category"].tolist() == ["Auto", "Manual", "Unknown"]
    assert summary["control_scorecard"]["auto_closed_cases"].sum() == 1
    assert summary["monthly_trends"]["auto_closed_cases"].sum() == 1
    auto = summary["auto_closure_summary"].set_index("auto_close_category")
    assert auto.loc["Auto", "cases"] == 1


def test_current_datetime_drives_aging_risk_and_both_reports(tmp_path, fixed_snapshot):
    rows = [
        case_row(status="Processing", final_decision=None, historic_comments_count=1),
        case_row(Case_Id="case-2", control_execution_date="2025-01-11"),
    ]
    source = write_cases(tmp_path / "input.parquet", rows)
    prepared, snapshot = prepare_cases(load_cases(source))
    assert snapshot == fixed_snapshot
    expected_age = (fixed_snapshot - pd.Timestamp("2025-01-01")).total_seconds() / 86400
    assert prepared.loc[0, "case_age_days"] == pytest.approx(expected_age)
    scored, _, _ = score_and_select_reviews(prepared)
    assert scored.loc[0, "audit_risk_score"] == 4
    report = run_fox_analysis(source, output_dir=tmp_path / "reports")
    assert f"Snapshot datetime (current server local time) | {fixed_snapshot}" in report
    assert "Over 90 days | 1 | 100.0%" in report
    (workbook,) = (tmp_path / "reports").glob("*/*.xlsx")
    saved = openpyxl.load_workbook(workbook)
    try:
        population = workbook_table(saved, "Overview", "FoxPopulation")
        summary = {row["Metric"]: row["Value"] for row in population}
        assert summary["Snapshot datetime (server local)"] == fixed_snapshot.to_pydatetime()
        rows = workbook_table(saved, "Processed Data", "FoxProcessedData")
        case = next(row for row in rows if row["Case_Id"] == "case-1")
        assert case["case_age_days"] == pytest.approx(expected_age)
    finally:
        saved.close()


def test_all_missing_dates_and_counts_keep_current_snapshot(tmp_path, fixed_snapshot):
    source = write_cases(
        tmp_path / "input.parquet",
        [
            case_row(
                control_execution_date=None,
                historic_comments_count=None,
                status="Processing",
                final_decision=None,
            )
        ],
    )
    report = run_fox_analysis(source, output_dir=tmp_path / "reports")
    assert f"Snapshot datetime (current server local time) | {fixed_snapshot}" in report
    assert "Unknown | 1 | 100.0%" in report
    assert "Rows with unknown comment count | 1" in report


def test_current_datetime_preserves_closed_durations_and_fractional_age_thresholds(fixed_snapshot):
    rows = [
        case_row(
            Case_Id=str(age),
            control_execution_date=fixed_snapshot - pd.Timedelta(days=age),
            status="Processing",
            final_decision=None,
        )
        for age in [30, 30.5, 90, 90.5]
    ]
    rows.append(
        case_row(
            Case_Id="closed",
            control_execution_date=pd.Timestamp("2025-01-01"),
            closure_date=pd.Timestamp("2025-01-03 12:00:00"),
            final_decision="Justified",
        )
    )
    prepared, _ = prepare_cases(pd.DataFrame(rows))
    scored, _, _ = score_and_select_reviews(prepared)
    assert scored["case_age_days"].tolist() == [30, 30.5, 90, 90.5, 2.5]
    assert scored["audit_risk_score"].tolist() == [0, 3, 3, 4, 0]


def test_empty_dataset_is_rejected(tmp_path):
    source = tmp_path / "empty.parquet"
    pl.DataFrame([case_row()]).head(0).write_parquet(source)
    with pytest.raises(ValueError, match="contains no rows"):
        run_fox_analysis(source, output_dir=tmp_path / "reports")


def test_default_destination_respects_application_settings_and_isolates_concurrent_runs(
    tmp_path,
    monkeypatch,
):
    settings = Settings(_env_file=None, app_root=tmp_path, analysis_results_dir="review-reports")
    monkeypatch.setattr("mcp_agent_template.analysis.fox.runners.get_settings", lambda: settings)
    source = write_cases(tmp_path / "input.parquet")
    with ThreadPoolExecutor(max_workers=2) as pool:
        reports = list(pool.map(run_fox_analysis, [source, source]))
    saved = list((tmp_path / "review-reports" / "fox").glob("*/*.md"))
    assert len(saved) == 2
    assert {path.read_text(encoding="utf-8") for path in saved} == set(reports)
    assert all(path.with_suffix(".xlsx").is_file() for path in saved)


def test_exact_duplicates_removed_but_conflicting_ids_are_disclosed(tmp_path):
    first = case_row(historic_comments_count=1)
    source = write_cases(
        tmp_path / "input.parquet",
        [
            first,
            first,
            {**first, "historic_comments_count": 2},
        ],
    )
    report = run_fox_analysis(source, output_dir=tmp_path / "reports")
    assert "Rows analyzed | 2" in report
    assert "Distinct non-null Case_Id values | 1" in report
    assert "Non-identical duplicate Case_Id records" in report


def test_explicit_output_files_remain_supported(tmp_path):
    source = write_cases(tmp_path / "input.parquet")
    workbook = tmp_path / "custom" / "review.xlsx"
    markdown = tmp_path / "text" / "review.md"
    report = run_fox_analysis(source, workbook, markdown)
    assert workbook.is_file()
    assert markdown.read_text(encoding="utf-8") == report


def test_markdown_monthly_totals_reconcile_with_excel_and_use_case_level_medians(tmp_path):
    first = case_row(closure_date="2025-01-02", isautoclosed=True)
    rows = [
        first,
        first,
        case_row(
            Case_Id="case-2",
            control_execution_date="2025-01-05",
            closure_date="2025-01-14",
            final_decision="Justified",
            historic_comments_count=2,
            isautoclosed=False,
        ),
        case_row(
            Case_Id="case-3",
            control_logical_code="CTRL-2",
            control_execution_date="2025-01-10",
            status="Processing",
            final_decision=None,
            historic_comments_count=None,
        ),
        case_row(
            Case_Id="case-4",
            control_execution_date="2025-02-01",
            closure_date="2025-02-05",
            final_decision="False anomaly",
            isautoclosed=True,
        ),
        case_row(
            Case_Id="case-5",
            control_logical_code=None,
            control_execution_date=None,
            status="Processing",
            final_decision=None,
        ),
        case_row(
            Case_Id="case-6",
            control_logical_code="CTRL-2",
            control_execution_date="2025-01-01",
            closure_date="2025-04-11",
            final_decision="Justified",
            historic_comments_count=1,
        ),
    ]
    source = write_cases(tmp_path / "input.parquet", rows)
    report = run_fox_analysis(source, output_dir=tmp_path / "reports")
    monthly = report.split("## Monthly analysis\n\n", 1)[1].split("\n\n## ", 1)[0]
    assert "One row per execution month across all controls" in monthly
    assert "not historical month-end backlog" in monthly
    assert "| 2025-01 | 4 | 2 | 0 | 1 | 1 | 1 | 1 | 1 | 9.00 |" in monthly
    assert "| 2025-02 | 1 | 0 | 1 | 0 | 0 | 0 | 1 | 1 | 4.00 |" in monthly
    assert "| Unknown | 1 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | — |" in monthly
    assert "CTRL-1" not in monthly and "CTRL-2" not in monthly
    (path,) = (tmp_path / "reports").glob("*/*.xlsx")
    saved = openpyxl.load_workbook(path)
    try:
        excel_rows = workbook_table(saved, "Monthly Trends", "FoxMonthly")
        markdown_rows = [line for line in monthly.splitlines() if line.startswith("| ")][2:]
        assert len(markdown_rows) == 3
        assert len(excel_rows) == 4
        for markdown in markdown_rows:
            cells = [value.strip() for value in markdown.strip("|").split("|")]
            group = [row for row in excel_rows if (row["execution_month"] or "Unknown") == cells[0]]
            assert [int(value) for value in cells[1:9]] == [
                sum(row[field] for row in group)
                for field in [
                    "cases",
                    "justified_cases",
                    "false_anomaly_cases",
                    "breach_cases",
                    "no_decision_cases",
                    "open_cases",
                    "auto_closed_cases",
                    "completed_without_comments",
                ]
            ]
        jan = [row for row in excel_rows if row["execution_month"] == "2025-01"]
        assert {row["control_logical_code"] for row in jan} == {"CTRL-1", "CTRL-2"}
        assert [row["median_days_to_close"] for row in jan] == [5, 100]
        assert sum(row["cases"] for row in excel_rows) == 6
        assert path.with_suffix(".md").read_text(encoding="utf-8") == report
    finally:
        saved.close()


def test_five_tabs_reconcile_and_filters_preserve_distinct_records(tmp_path, fixed_snapshot):
    first = case_row(
        closure_date="2025-01-03",
        historic_comments_count=1,
        isautoclosed=False,
        historic_comments_markdown="=1+1",
        unused_source_field="omit me",
        product="unused product",
        uuid="unused identifier",
    )
    rows = [
        first,
        first,
        {
            **first,
            "status": "Processing",
            "final_decision": None,
            "closure_date": None,
            "control_execution_date": "2026-10-10",
        },
        case_row(
            Case_Id="old-open", status="Processing", final_decision=None, control_logical_code=None
        ),
        case_row(
            Case_Id="unknown-age",
            status="Processing",
            final_decision=None,
            control_execution_date=None,
        ),
        case_row(
            Case_Id="no-comments",
            final_decision="Justified",
            control_execution_date="2026-10-10",
            closure_date="2026-10-12",
        ),
        case_row(Case_Id="workflow", final_decision="Justified", historic_comments_count=None),
    ]
    source = write_cases(tmp_path / "input.parquet", rows)
    run_fox_analysis(source, output_dir=tmp_path / "reports")
    (path,) = (tmp_path / "reports").glob("*/*.xlsx")
    saved = openpyxl.load_workbook(path)
    try:
        cases = workbook_table(saved, "Processed Data", "FoxProcessedData")
        assert len(cases) == 6
        assert {row["Analysis_Row_ID"] for row in cases} == set(range(1, 7))
        same_id = [row for row in cases if row["Case_Id"] == "case-1"]
        assert len(same_id) == 2
        assert sorted(row["in_manual_review"] for row in same_id) == [False, True]
        assert not {"unused_source_field", "product", "uuid"} & cases[0].keys()
        assert {
            "Case_Id",
            "control_logical_code",
            "control_description",
            "control_execution_date",
            "closure_date",
            "status",
            "final_decision",
            "isautoclosed",
            "historic_comments_count",
            "historic_comments_markdown",
            "hit_search_items",
        } <= cases[0].keys()
        assert all(row["historic_comments_markdown"] == "=1+1" for row in same_id)
        assert not any(cell.data_type == "f" for row in saved["Processed Data"] for cell in row)
        population = {
            r["Metric"]: r["Value"] for r in workbook_table(saved, "Overview", "FoxPopulation")
        }
        assert population["Source rows"] == 7
        assert population["Exact duplicates removed"] == 1
        assert population["Analyzed rows"] == len(cases)
        assert population["Distinct non-null Case_Id"] == 5
        metrics = {r["Metric"]: r["Value"] for r in workbook_table(saved, "Overview", "FoxReview")}
        assert metrics["Priority queue rows"] == sum(row["in_priority_queue"] for row in cases) == 3
        assert metrics["Manual-review rows"] == sum(row["in_manual_review"] for row in cases) == 3
        assert metrics["Workflow exceptions"] == sum(row["has_workflow_exception"] for row in cases)
        assert metrics["Completed without comments"] == sum(
            row["completed_without_comments_derived"] for row in cases
        )
        controls = workbook_table(saved, "Control Analysis", "FoxControls")
        assert sum(row["cases"] for row in controls) == len(cases)
        for control in controls:
            assert (
                sum(
                    control[col]
                    for col in control
                    if col.startswith("open_") and col not in {"open_cases", "open_rate"}
                )
                == control["open_cases"]
            )
        assert sum(row["open_unknown_age"] for row in controls) == 1
        assert (
            next(row for row in controls if row["control_logical_code"] is None)["open_cases"] == 1
        )
        assert sum(r["cases"] for r in workbook_table(saved, "Monthly Trends", "FoxMonthly")) == 6
        aging = workbook_table(saved, "Overview", "FoxAging")
        assert sum(sum(v for k, v in row.items() if k != "status_normalized") for row in aging) == 6
        assert saved["Processed Data"].freeze_panes == "D7"
        assert len(saved["Processed Data"].conditional_formatting) == 1
        unknown = next(row for row in cases if row["Case_Id"] == "unknown-age")
        assert unknown["case_age_days"] is None
    finally:
        saved.close()
