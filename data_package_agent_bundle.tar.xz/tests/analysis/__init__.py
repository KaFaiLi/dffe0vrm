"""Synthetic analysis regressions migrated from the source skills."""
