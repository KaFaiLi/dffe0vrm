"""Adjustment dataset checks use reported EUR amounts without hierarchy mappings."""

from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal

import pytest

from mcp_agent_template.analysis.pnl.controls import adjustment_analysis
from mcp_agent_template.analysis.pnl.models import Review


def adjustment(identifier, amount, **fields):
    return {
        "ADJUSTMENTID": identifier,
        "GOP": "G1",
        "PC": "PC1",
        "PTF": "P1",
        "CCY": "EUR",
        "AMOUNTINEUR": amount,
        "VALDATEBEGIN": "2026-01-01",
        "VALDATEEND": "2026-01-01",
        "CREATIONDATE": "2026-01-02",
        "SOURCE": "MANUAL",
        "COMMENTS": "Accrual",
        "_ref": f"adjustments.csv [ID={identifier}]",
        **fields,
    }


def analyze(rows, *, dates=()):
    review = Review(source_dates={"pnl": set(dates)})
    adjustment_analysis(rows, review)
    return review


def test_eur_amounts_form_one_population_without_mappings():
    """Retain EUR totals without amount screens or hierarchy mappings."""
    rows = [
        adjustment(
            f"A{index}",
            -1000 if index == 19 else 1,
            CCY="EUR",
            GOP=f"G{index}",
            AMOUNT="unused",
        )
        for index in range(20)
    ]
    original = deepcopy(rows)
    review = analyze(rows)

    assert rows == original
    assert review.tables["Adjustment summary"] == [
        {
            "source": "MANUAL",
            "nature": "",
            "currency": "EUR",
            "count": 20,
            "net amount": Decimal(-981),
        }
    ]
    assert "Adjustment magnitude screen" not in review.tables
    assert "Very large adjustments" not in review.tables
    assert all("amount magnitude z score" not in row for row in review.tables["All adjustments"])
    assert review.tables["All adjustments"][-1]["AMOUNTINEUR"] == -1000
    assert "Adjustment desk concentration" not in review.tables
    assert "Adjustment ID duplicates" not in review.tables
    assert all(
        not {"desk", "desk mapping", "mapping"}.intersection(row)
        for row in review.tables["All adjustments"]
    )
    assert review.issues == []


def test_summary_counts_every_row_by_source_and_nature():
    """Keep classifications distinct without excluding zero, repeated or outside rows."""
    rows = [
        adjustment("A", 10, NATURE="ACCRUAL", CCY="EUR"),
        adjustment("B", 10, NATURE="ACCRUAL", CCY="EUR"),
        adjustment("C", -5, NATURE="ACCRUAL", CCY="EUR"),
        adjustment("D", 0, NATURE="RESERVE", VALDATEBEGIN="", CREATIONDATE=""),
        adjustment(
            "E",
            100,
            SOURCE="AUTO",
            NATURE="ACCRUAL",
            VALDATEBEGIN="2027-01-01",
            VALDATEEND="2027-01-01",
        ),
        adjustment("F", 20, SOURCE=" MANUAL ", NATURE=" ACCRUAL "),
        adjustment("G", 30, SOURCE=None, NATURE=None),
        adjustment("H", 40, SOURCE=" "),
        adjustment("I", 50, SOURCE="manual", NATURE="ACCRUAL"),
    ]
    del rows[7]["SOURCE"]
    original = deepcopy(rows)

    review = analyze(rows)

    assert rows == original
    summary = review.tables["Adjustment summary"]
    assert [(row["source"], row["nature"], row["count"], row["net amount"]) for row in summary] == [
        ("", "", 2, Decimal(70)),
        ("AUTO", "ACCRUAL", 1, Decimal(100)),
        ("MANUAL", "ACCRUAL", 4, Decimal(35)),
        ("MANUAL", "RESERVE", 1, Decimal(0)),
        ("manual", "ACCRUAL", 1, Decimal(50)),
    ]
    assert {row["currency"] for row in summary} == {"EUR"}
    assert sum(row["count"] for row in summary) == len(rows)
    assert review.tables["Adjustment repeated entries"][0]["ADJUSTMENTIDs"] == "A; B"
    assert sum(row["net amount"] for row in review.tables["Adjustment daily activity"]) == 255
    assert sum(row["gross amount"] for row in review.tables["Adjustment daily activity"]) == 265


def test_matching_rows_under_different_ids_are_repeated_entries():
    rows = [
        adjustment("A", "10", AMOUNT="unused A"),
        adjustment("B", "10", AMOUNT="unused B"),
        adjustment("C", "20", AMOUNT="unused A"),
        adjustment("D", "10", COMMENTS="Different rationale"),
        adjustment("E", "10.00"),
    ]
    review = analyze(rows)

    (repeated,) = review.tables["Adjustment repeated entries"]
    assert repeated["ADJUSTMENTIDs"] == "A; B"
    assert repeated["duplicate rows"] == 2
    assert not {"ADJUSTMENTID", "AMOUNT", "_ref"}.intersection(repeated["matching fields"])
    assert repeated["matching fields"]["AMOUNTINEUR"] == "10"
    assert len(review.tables["All adjustments"]) == 5
    assert review.tables["Adjustment summary"][0]["net amount"] == 60
    assert [issue["check"] for issue in review.issues] == ["adjustment_repeated_entry"]


@pytest.mark.parametrize("n,amount", [(1, 10), (19, 10), (20, 0)])
def test_constant_eur_populations_have_unavailable_z_scores(n, amount):
    """A single creation date has no count z-score, regardless of amount values."""
    review = analyze([adjustment(f"A{index}", amount) for index in range(n)])

    assert len(review.tables["All adjustments"]) == n
    assert review.tables["Adjustment summary"][0]["count"] == n
    assert review.tables["Adjustment daily activity"][0]["record count z score"] is None
    assert review.tables["Adjustment daily activity"][0]["record count screen"] == (
        "unavailable (constant values)"
    )
    assert not any(issue["check"] == "adjustment_large" for issue in review.issues)


@pytest.mark.parametrize("n,flagged", [(9, False), (10, False), (11, True)])
def test_creation_count_threshold_is_strictly_greater_than_three(n, flagged):
    """One active day among ten has z=3 exactly and must remain unflagged."""
    dates = {date(2026, 1, 1) + timedelta(days=index) for index in range(n)}
    review = analyze([adjustment("A", 10)], dates=dates)
    active = next(
        row for row in review.tables["Adjustment daily activity"] if row["adjustment count"]
    )

    assert float(active["record count z score"]) == pytest.approx((n - 1) ** 0.5)
    if n == 10:
        assert active["record count z score"] == 3
    assert bool(active["review candidate"]) is flagged
    assert bool(review.issues) is flagged
    if flagged:
        assert review.issues[0]["observations"] == n


def test_extreme_amount_with_constant_daily_counts_does_not_trigger_a_flag():
    """Changing EUR magnitudes alone cannot flag a creation date."""
    rows = [
        adjustment(
            f"A{index}",
            10**12 if index == 19 else 1,
            CREATIONDATE=(date(2026, 1, 1) + timedelta(days=index)).isoformat(),
        )
        for index in range(20)
    ]
    review = analyze(rows)

    assert review.issues == []
    assert all(
        row["record count z score"] is None for row in review.tables["Adjustment daily activity"]
    )
    assert all(
        "gross amount z score" not in row for row in review.tables["Adjustment daily activity"]
    )


def test_small_full_daily_populations_are_screened_on_creation_date_only():
    dates = {date(2026, 1, 1) + timedelta(days=index) for index in range(11)}
    review = analyze([adjustment("A", 10)], dates=dates)

    activity = review.tables["Adjustment daily activity"]
    assert len(activity) == 11
    assert all(row["record count screen"] == "checked" for row in activity)
    assert {row["date"] for row in activity if row["review candidate"]} == {date(2026, 1, 2)}
    assert all("date basis" not in row for row in activity)
    assert [issue["check"] for issue in review.issues] == [
        "adjustment_daily_concentration",
    ]


def test_empty_adjustment_population_has_no_statistics():
    """An empty population produces empty evidence and no statistical issues."""
    review = analyze([])

    assert review.tables["All adjustments"] == []
    assert review.tables["Adjustment summary"] == []
    assert "Very large adjustments" not in review.tables
    assert review.tables["Adjustment daily activity"] == []
    assert review.issues == []


def test_creation_date_screens_count_each_eur_adjustment_once():
    """Each EUR adjustment contributes once to the complete creation-date calendar."""
    dates = {date(2026, 1, 1) + timedelta(days=index) for index in range(20)}
    review = analyze([adjustment("A", 10, CCY="EUR"), adjustment("B", -20, CCY="EUR")], dates=dates)

    activity = review.tables["Adjustment daily activity"]
    assert len(activity) == 20
    assert {row["currency"] for row in activity} == {"EUR"}
    assert sum(row["adjustment count"] for row in activity) == 2
    assert sum(row["net amount"] for row in activity) == -10
    assert sum(row["gross amount"] for row in activity) == 30
    selected = [row for row in activity if row["review candidate"]]
    assert len(selected) == 1
    assert selected[0]["date"] == date(2026, 1, 2)
    assert selected[0]["review candidate"] == "record count"
    assert len(review.issues) == 1
    assert all(issue["check"] == "adjustment_daily_concentration" for issue in review.issues)
    assert all("date_basis" not in issue for issue in review.issues)


def test_valuation_dates_cannot_change_daily_groups_or_screen_statistics():
    dates = {date(2026, 1, 1) + timedelta(days=index) for index in range(20)}
    rows = [adjustment("A", 10), adjustment("B", -20)]
    original = analyze(rows, dates=dates)
    shifted = [{**row, "VALDATEBEGIN": "2030-06-30", "VALDATEEND": "2030-06-30"} for row in rows]

    review = analyze(shifted, dates=dates)

    assert (
        review.tables["Adjustment daily activity"] == original.tables["Adjustment daily activity"]
    )
    assert len(review.tables["Adjustment daily activity"]) == 20
    assert not any(row["date"].year == 2030 for row in review.tables["Adjustment daily activity"])


def test_creation_dates_outside_pnl_calendar_are_included_without_valuation_fallback():
    dates = {date(2026, 1, 1) + timedelta(days=index) for index in range(20)}
    rows = [
        adjustment("A", 10, CREATIONDATE="2026-02-07"),
        adjustment("B", 20, CREATIONDATE=""),
        adjustment("C", 30, CREATIONDATE="invalid"),
    ]

    review = analyze(rows, dates=dates)

    activity = review.tables["Adjustment daily activity"]
    assert len(activity) == 21
    assert sum(row["adjustment count"] for row in activity) == 1
    assert sum(row["gross amount"] for row in activity) == 10
    assert {row["date"] for row in activity if row["review candidate"]} == {date(2026, 2, 7)}
    assert len(review.tables["All adjustments"]) == 3


def test_opposite_eur_amounts_are_retained_without_reversal_classification():
    """Linked opposite amounts still count separately and retain their gross EUR activity."""
    rows = [
        adjustment("A", 100, AMOUNT=1, ADJUSTMENTLINKID="LINK"),
        adjustment(
            "B",
            -100,
            AMOUNT=1,
            ADJUSTMENTLINKID="LINK",
            VALDATEBEGIN="2026-01-06",
            VALDATEEND="2026-01-06",
        ),
    ]
    review = analyze(rows)

    assert "Adjustment reversals" not in review.tables
    assert [row["ADJUSTMENTID"] for row in review.tables["All adjustments"]] == ["A", "B"]
    assert review.tables["Adjustment summary"][0]["count"] == 2
    assert review.tables["Adjustment summary"][0]["net amount"] == 0
    assert review.tables["Adjustment daily activity"][0]["gross amount"] == 200
    assert review.issues == []


def test_all_dates_retain_full_eur_amounts_without_period_labels():
    """Review dates impose no labels; malformed source intervals still generate findings."""
    rows = [
        adjustment("A", 10, VALDATEBEGIN="2025-12-01", VALDATEEND="2026-01-02"),
        adjustment("B", 20, VALDATEBEGIN="2026-02-01", VALDATEEND="2026-02-01"),
        adjustment("C", 30, VALDATEBEGIN=""),
    ]
    review = analyze(rows)

    assert len(review.tables["All adjustments"]) == 3
    assert all(
        not {"review period status", "period overlap"}.intersection(row)
        for row in review.tables["All adjustments"]
    )
    assert review.tables["Adjustment summary"][0]["net amount"] == 60
    assert [issue["check"] for issue in review.issues] == ["adjustment_scope"]
