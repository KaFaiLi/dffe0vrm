"""Daily attribution drivers retain independent outlier screens without series or trends."""

from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

import pytest

from mcp_agent_template.analysis.pnl.calculations import attribution_analysis
from mcp_agent_template.analysis.pnl.loading import load_table, prepare
from mcp_agent_template.analysis.pnl.models import Review
from tests.analysis.pnl_support import dataset, write_csv
from tests.analysis.test_pnl_analysis import run


def source(day, gop="G1", *, pc="PC1", market=0, fees=0):
    """Supply a daily-only attribution record without any final PnL dependency."""
    return {
        "pc": pc,
        "gop": gop,
        "asofdate": (date(2026, 1, 1) + timedelta(days=day)).isoformat(),
        "Market": market,
        "Fees": fees,
        "_ref": f"attribution.csv [row={day}-{gop}-{pc}]",
    }


def analyse(rows):
    """Use production preparation and analysis, retaining desk-data exclusions."""
    review = Review()
    daily = attribution_analysis(prepare(rows, "attribution", review), review)
    return daily, review


def test_gop_netting_precedes_independent_driver_and_pc_outlier_screens():
    """Same-day offsets stay constant while independent drivers flag both tails at equality."""
    rows = []
    for day in range(10):
        last = day == 9
        rows.extend(
            [
                source(day, market=1000 if last else 10, fees=100 if last else 0),
                source(day, "G2", market=-970 if last else 20),
                source(day, pc="PC2", market=-100 if last else 0),
            ]
        )
    original = deepcopy(rows)
    daily, review = analyse(rows)
    assert rows == original
    assert len(daily) == 20
    assert all(row["Market"] == 30 for row in daily if row["pc"] == "PC1")
    assert len(daily[0]["_refs"]) == 2
    assert {
        (row["pc"], row["driver"], row["z score"]) for row in review.tables["Attribution outliers"]
    } == {("PC1", "Fees", Decimal(3)), ("PC2", "Market", Decimal(-3))}
    fees = next(row for row in review.tables["Attribution outliers"] if row["driver"] == "Fees")
    assert (fees["n"], fees["mean"], fees["standard deviation"]) == (10, 10, 30)
    assert len(review.issues) == 2
    assert len(review.tables["Attribution daily"]) == 40
    assert set(review.tables) == {"Attribution daily", "Attribution outliers"}


def test_missing_constituent_is_unknown_only_for_that_driver_and_date():
    """A partial sum cannot enter its baseline or change another driver's known amount."""
    _, review = analyse(
        [
            source(0, market=10),
            source(0, "G2", market=None),
            source(1, market=5),
            source(11, market=25),
        ]
    )
    market = [row for row in review.tables["Attribution daily"] if row["driver"] == "Market"]
    fees = [row for row in review.tables["Attribution daily"] if row["driver"] == "Fees"]
    assert [row["amount"] for row in market] == [None, 5, 25]
    assert [row["z score"] for row in market] == [None, -1, 1]
    assert all(row["amount"] == 0 and row["z score"] is None for row in fees)


@pytest.mark.parametrize("value", [None, 0, 7])
def test_unknown_and_constant_driver_values_keep_screen_availability(value):
    """Unknown never becomes zero and unavailable screening cannot imply a clean result."""
    _, review = analyse([source(day, market=value) for day in range(10)])
    rows = [row for row in review.tables["Attribution daily"] if row["driver"] == "Market"]
    assert len(rows) == 10
    assert all(row["amount"] == value and row["z score"] is None for row in rows)
    status = "no known values" if value is None else "constant values"
    assert all(row["outlier screen"] == f"unavailable ({status})" for row in rows)
    assert not review.tables["Attribution outliers"]


@pytest.mark.parametrize("final", [None, "invalid", "999999999999999"])
def test_final_pnl_and_cumulative_values_cannot_gate_or_enter_driver_screens(final):
    """Only daily contributions influence their own histories, regardless of final totals."""
    rows = [source(day, market=day) for day in range(10)]
    for row in rows:
        row.update({"Final Result Acc DTD": final, "Market Cumulative": "invalid"})
    _, review = analyse(rows)
    assert {row["driver"] for row in review.tables["Attribution daily"]} == {"Market", "Fees"}
    assert not review.issues


@pytest.mark.parametrize("rejection", ["invalid", "duplicate"])
def test_rejected_constituent_excludes_whole_pc_date(rejection):
    """Ambiguous or invalid constituents prevent partial PC totals."""
    rows = [source(0), source(0, "G2"), source(1)]
    if rejection == "invalid":
        rows[1]["gop"] = ""
    else:
        rows.append(dict(rows[1]))
    daily, review = analyse(rows)
    assert [row["_date"] for row in daily] == [date(2026, 1, 2)]
    assert review.incomplete_attribution_dates == {(date(2026, 1, 1), "PC1")}
    assert len(review.tables["Attribution daily"]) == 2
    assert review.issues


@pytest.mark.usefixtures("without_png_rendering")
def test_file_runner_omits_series_and_trend_sheets_but_retains_daily_outliers(tmp_path):
    """The public runner exports outliers and daily source evidence with no trend artifacts."""
    paths, _, attribution, *_ = dataset(tmp_path / "input", n=10)
    for index, row in enumerate(attribution):
        for field in list(row):
            if field.endswith(" Cumulative") or field == "Final Result Acc DTD":
                del row[field]
        row.update(Market=100 if index == 9 else 0, isbatchvalidated=1, status=2, validated=3)
    write_csv(Path(paths["income_attribution_path"]), attribution)
    report, tables = run(paths, tmp_path)
    assert {row["driver"] for row in tables["Attribution daily"]} == {"Unexplained", "Market"}
    assert len(tables["Attribution outliers"]) == 1
    assert tables["Attribution outliers"][0]["driver"] == "Market"
    assert "## Attribution outliers" in report
    for removed in ("Attribution series", "Attribution trends", "Attribution trend history"):
        assert removed not in tables
        assert f"## {removed}" not in report
    assert tables["PnL series"][0]["observations"] == 10


def test_final_pnl_column_alone_does_not_satisfy_daily_driver_contract(tmp_path):
    """A source without a daily contribution is an input error, not a clean screen."""
    paths, _, rows, *_ = dataset(tmp_path / "input", n=2)
    for row in rows:
        del row["Unexplained"]
    path = Path(paths["income_attribution_path"])
    write_csv(path, rows)
    with pytest.raises(ValueError, match="at least one daily monetary driver column"):
        load_table(path, "attribution")


@pytest.mark.usefixtures("without_png_rendering")
def test_wholly_rejected_attribution_remains_visible_in_desk_data_and_exceptions(tmp_path):
    """Duplicate-only inputs retain exclusions without creating daily amounts or clean assurance."""
    paths, _, attribution, *_ = dataset(tmp_path / "input", n=2)
    source_path = Path(paths["income_attribution_path"])
    write_csv(source_path, attribution + deepcopy(attribution))
    before = source_path.read_bytes()
    report, tables = run(paths, tmp_path)
    assert source_path.read_bytes() == before
    assert tables["Attribution daily"] == tables["Attribution outliers"] == []
    data = next(row for row in tables["Desk data"] if row["dataset"] == "attribution")
    assert data["supplied rows"] == 4 and data["valid unique rows"] == 0
    assert data["incomplete PC dates"] == 2
    assert sum(row["check"] == "duplicate_key" for row in tables["Exceptions"]) == 4
    assert "check screen availability in the workbook" in report


def test_outliers_use_all_known_dates_without_a_rolling_window():
    """A late spike uses the entire driver history after removing trend analysis."""
    _, review = analyse([source(day, market=100 if day == 59 else 0) for day in range(60)])
    (flag,) = review.tables["Attribution outliers"]
    assert flag["n"] == 60
    assert flag["z score"] == pytest.approx(Decimal(59).sqrt())
