"""Risk runtime ownership and complete evidence under bounded intermediate storage."""

import gc
import weakref
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

import openpyxl
import polars as pl
import pytest
from openpyxl.worksheet import _writer

from mcp_agent_template.analysis import charts
from mcp_agent_template.analysis.risk_metrics import export, sources
from mcp_agent_template.analysis.risk_metrics.charts import risk_charts
from mcp_agent_template.analysis.risk_metrics.models import Review
from mcp_agent_template.analysis.risk_metrics.runners import analyze_tables
from mcp_agent_template.analysis.risk_metrics.sources import load_table
from tests.analysis.risk_support import excess_row, sgmr_series, write_excesses, write_sgmr


@pytest.mark.parametrize("path_kind", ["filename", "directory"])
def test_parquet_source_paths_are_literal_not_glob_patterns(tmp_path, path_kind):
    """Read the selected source when brackets could match a neighboring file or folder."""
    if path_kind == "filename":
        requested = tmp_path / "risk[1].parquet"
        neighbor = tmp_path / "risk1.parquet"
    else:
        requested = tmp_path / "source[1]" / "risk.parquet"
        neighbor = tmp_path / "source1" / "risk.parquet"
    write_sgmr(requested, sgmr_series([11]))
    write_sgmr(neighbor, sgmr_series([99]))

    source = load_table(requested, "sgmr", Review())

    assert source.path == str(requested.resolve())
    assert [record.raw["consoValue"] for record in source.records] == [11]


def test_file_sources_avoid_whole_file_and_row_list_materialization(tmp_path, monkeypatch):
    """Both file readers preserve records without allocating whole-file Python buffers."""
    sgmr = write_sgmr(tmp_path / "risk.parquet", sgmr_series([1, 2, 3]))
    events = write_excesses(tmp_path / "events.csv", [excess_row(), excess_row()])
    expected = Review()
    load_table(sgmr, "sgmr", expected)
    load_table(events, "colibris", expected)

    def forbidden(*args, **kwargs):
        """Reject the full materializations whose overlap inflated loading memory."""
        pytest.fail("A source was materialized as whole-file bytes or a complete row list")

    monkeypatch.setattr(Path, "read_bytes", forbidden)
    monkeypatch.setattr(pl.DataFrame, "to_dicts", forbidden)
    actual = Review()
    load_table(sgmr, "sgmr", actual)
    load_table(events, "colibris", actual)
    assert asdict(actual) == asdict(expected)


def test_digest_collisions_keep_distinct_raw_types_and_original_duplicate_locations(monkeypatch):
    """Fingerprint matches require canonical equality, including numeric/text distinctions."""
    frame = pl.DataFrame([sgmr_series([5])[0]] * 6).with_columns(
        pl.Series("metadata", [1, 1.0, "1", 1, None, None], dtype=pl.Object)
    )
    expected = Review()
    sources.prepare_table(frame, "sgmr", expected, name="source.parquet")
    monkeypatch.setattr(
        sources, "sha256", lambda data: SimpleNamespace(digest=lambda: b"collision")
    )
    actual = Review()
    source = sources.prepare_table(frame, "sgmr", actual, name="source.parquet")
    assert asdict(actual) == asdict(expected)
    assert source.input_rows == 6 and source.duplicate_rows == 2
    assert [record.ordinal for record in source.records] == [1, 2, 3, 5]
    assert "record=4" in source.records[0].duplicate_locators[0]
    assert "record=6" in source.records[3].duplicate_locators[0]


@pytest.mark.parametrize("failure_stage", ["row", "save"])
def test_failed_workbook_export_cleans_owned_xml_and_preserves_error(
    tmp_path, monkeypatch, failure_stage
):
    """Write-only XML files are removed on failed rows and failed archive publication."""
    from openpyxl.worksheet._write_only import WriteOnlyWorksheet

    created = []
    original_temp = _writer.create_temporary_file
    original_append = WriteOnlyWorksheet.append
    failure = OSError("synthetic workbook failure")

    def tracked_temp(*args, **kwargs):
        """Track only temporaries created by this workbook operation."""
        path = original_temp(*args, **kwargs)
        created.append(Path(path))
        return path

    def append(sheet, row):
        """Fail after an earlier sheet already opened its XML stream."""
        if sheet.title == "Series Review":
            raise failure
        return original_append(sheet, row)

    def save(*args, **kwargs):
        """Reject final publication after all evidence rows have been streamed."""
        raise failure

    monkeypatch.setattr(_writer, "create_temporary_file", tracked_temp)
    if failure_stage == "row":
        monkeypatch.setattr(WriteOnlyWorksheet, "append", append)
    else:
        monkeypatch.setattr(openpyxl.Workbook, "save", save)
    with pytest.raises(OSError) as caught:
        export.export_workbook(
            Review(summary=[{"measure": "count", "value": 1}]), tmp_path / "r.xlsx"
        )
    assert caught.value is failure
    assert created
    assert all(not path.exists() for path in created)
    assert not {str(path) for path in created}.intersection(_writer.ALL_TEMP_FILES)


@pytest.mark.parametrize("fail_save", [False, True])
def test_risk_renderers_are_released_without_cyclic_collection(tmp_path, monkeypatch, fail_save):
    """Successful and failed PNG exports release pixel owners even with exceptions retained."""
    rows = sgmr_series([1, 2, 3]) + sgmr_series([3, 2, 1], limId="SECOND")
    review = analyze_tables(pl.DataFrame(rows))
    renderers = []
    original = charts.FigureCanvasAgg.print_png

    def capture(canvas, filename):
        """Render normally and retain only a weak reference to the pixel owner."""
        # Every earlier image must be released before the next PNG is rendered.
        assert all(ref() is None for ref in renderers)
        try:
            original(canvas, Path(filename).parent if fail_save else filename)
        finally:
            renderers.append(weakref.ref(canvas.renderer))

    monkeypatch.setattr(charts.FigureCanvasAgg, "print_png", capture)
    enabled = gc.isenabled()
    gc.collect()
    gc.disable()
    try:
        if fail_save:
            with pytest.raises(OSError) as failure:
                charts.export_charts(risk_charts(review.observations, review), tmp_path / "png")
            assert failure.value.__traceback__ is not None
        else:
            charts.export_charts(risk_charts(review.observations, review), tmp_path / "png")
        assert renderers
        assert all(ref() is None for ref in renderers)
    finally:
        if enabled:
            gc.enable()
        gc.collect()
