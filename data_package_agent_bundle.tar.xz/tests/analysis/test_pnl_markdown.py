"""Reader-facing summaries preserve complete underlying workbook calculations."""

from copy import deepcopy
from datetime import date, timedelta
from pathlib import Path

import pytest

from mcp_agent_template.analysis.pnl.models import Review
from mcp_agent_template.analysis.pnl.reporting import markdown
from notebooks.review_reporting import RunEvidence, Source, build_evidence_catalog
from tests.analysis.pnl_support import dataset, write_csv
from tests.analysis.test_adjustments import adjustment, analyze
from tests.analysis.test_pnl_analysis import run

pytestmark = pytest.mark.usefixtures("without_png_rendering")


def render(review):
    review.tables.setdefault("Sources", [{"role": "pnl", "path": "pnl.xlsx", "sha256": "hidden"}])
    return markdown(review, Path("review.xlsx"), Path("review.md"))


def test_adjustment_summary_groups_source_nature_and_keeps_amounts_in_workbook(tmp_path):
    """The public runner saves a count-only Markdown pivot and full EUR evidence."""
    paths, _, _, adjustments, _ = dataset(tmp_path / "input")
    template = adjustments[0]
    adjustments[:] = [
        {
            **template,
            "ADJUSTMENTID": "A",
            "SOURCE": "MANUAL",
            "NATURE": "ACCRUAL",
            "AMOUNTINEUR": 10,
            "CCY": "EUR",
        },
        {
            **template,
            "ADJUSTMENTID": "B",
            "SOURCE": "MANUAL",
            "NATURE": "ACCRUAL",
            "AMOUNTINEUR": -5,
            "CCY": "EUR",
        },
        {
            **template,
            "ADJUSTMENTID": "C",
            "SOURCE": "MANUAL",
            "NATURE": "RESERVE",
            "AMOUNTINEUR": 0,
        },
        {**template, "ADJUSTMENTID": "D", "SOURCE": "AUTO", "NATURE": "ACCRUAL", "AMOUNTINEUR": 20},
        {**template, "ADJUSTMENTID": "E", "SOURCE": "", "NATURE": "", "AMOUNTINEUR": 30},
    ]
    write_csv(Path(paths["adjustments_path"]), adjustments)

    report, tables = run(paths, tmp_path)

    summary = report.split("## Adjustment summary", 1)[1].split("## ", 1)[0]
    assert [line for line in summary.splitlines() if line.startswith("|")] == [
        "| source | nature | count |",
        "| --- | --- | --- |",
        "|  |  | 1 |",
        "| AUTO | ACCRUAL | 1 |",
        "| MANUAL | ACCRUAL | 2 |",
        "| MANUAL | RESERVE | 1 |",
    ]
    assert "AMOUNTINEUR in EUR" in summary
    assert "net amount" not in summary
    assert [row["net amount"] for row in tables["Adjustment summary"]] == ["30", "20", "5", "0"]
    assert {row["currency"] for row in tables["Adjustment summary"]} == {"EUR"}
    assert sum(row["count"] for row in tables["Adjustment summary"]) == len(adjustments)
    assert len(tables["All adjustments"]) == len(adjustments)
    (saved_report,) = (tmp_path / "reports").glob("*/*.md")
    assert saved_report.read_text(encoding="utf-8") == report


def test_adjustment_records_remain_in_workbook_and_validation_shows_percentages(tmp_path):
    """Markdown shows count candidates while retaining complete source records in Excel."""
    paths, _, _, adjustments, history = dataset(tmp_path / "input", n=20)
    template = adjustments[0]
    long_text = "Outlier rationale " + "A" * 650
    adjustments[:] = [
        {
            **template,
            "ADJUSTMENTID": f"ROUTINE_{index}" if index < 19 else "OUTLIER_ID",
            "AMOUNTINEUR": 10 if index < 19 else 10000,
            "COMMENTS": f"Routine item {index}" if index < 19 else long_text,
            "EXTRA_SOURCE_COLUMN": "Retained source value",
        }
        for index in range(20)
    ]
    for row in history:
        if row["team"] == "MPC":
            row["state"] = "Official PNL"
    write_csv(Path(paths["adjustments_path"]), adjustments)
    write_csv(Path(paths["validation_history_path"]), history)
    original = "# Original\n\n| reference | source rows |\n| literal | preserved |\n"
    Path(paths["pnl_commentary_path"]).write_text(original, encoding="utf-8")

    report, tables = run(paths, tmp_path)

    generated = report.split("## Original attribution commentary", 1)[0]
    assert "sha256" not in generated
    assert "| population |" not in generated
    assert "population" not in generated.lower()
    assert "all supplied desk data" in generated
    assert "## Attribution series" not in generated
    assert "## Attribution trends" not in generated
    assert "| reference |" not in generated
    assert "source rows" not in generated
    assert "[row=" not in generated
    assert "## PnL daily" not in generated
    assert "## Attribution daily" not in generated
    assert "## All adjustments" not in generated
    assert "Evidence for" not in generated
    assert "ROUTINE_" not in generated
    assert "## Outlier adjustments" not in generated
    assert "OUTLIER_ID" not in generated
    assert "not labelled Validated" not in generated
    assert "## Validation state counts" not in generated
    summary = generated.split("## Validation summary", 1)[1].split("## ", 1)[0]
    assert "| Other | Other % |" in summary
    assert (
        "| MPC | FLASH | 20 | 0 | 0.00% | 0 | 0.00% | 0 | 0.00% | 0 | 0.00% | 20 | 100.00% |"
        in summary
    )
    assert "No DEValidated records found." in generated
    assert "## Validation exceptions" not in generated
    assert original in report
    assert len(tables["All adjustments"]) == 20
    assert len(tables["PnL daily"]) == 20
    assert len(tables["Attribution daily"]) == 20
    assert tables["All adjustments"][-1]["COMMENTS"] == long_text
    assert tables["All adjustments"][-1]["EXTRA_SOURCE_COLUMN"] == "Retained source value"
    assert tables["Sources"][0]["sha256"]


def test_more_than_twelve_flagged_creation_dates_are_all_displayed_by_count_score():
    """Every date above the count threshold is displayed without mutating evidence."""
    dates = [date(2026, 1, 1) + timedelta(days=index) for index in range(400)]
    review = analyze(
        [
            adjustment(f"ID_{index}", 10, CREATIONDATE=event_date.isoformat())
            for index, event_date in enumerate(dates[:14])
        ],
        dates=dates,
    )
    original = deepcopy(review.tables)

    report = render(review)

    section = report.split("## Unusual adjustment dates", 1)[1].split("## ", 1)[0]
    assert "| date | adjustment count | record count z score |" in section
    for index in range(14):
        assert f"| {dates[index]} |" in section
    assert str(dates[14]) not in section
    assert "net amount" not in section
    assert "gross amount" not in section
    assert "omitted" not in section
    assert {k: v for k, v in review.tables.items() if k != "Sources"} == original


def test_creation_dates_at_or_below_threshold_are_not_displayed():
    """Markdown filters unrounded scores strictly above 3, then ranks them descending."""
    review = Review(
        tables={
            "Adjustment daily activity": [
                {
                    "date": date(2026, 1, index),
                    "adjustment count": index,
                    "record count z score": score,
                    "record count screen": "checked",
                }
                for index, score in enumerate((3, 2.9, None, 3.001, 4), 1)
            ]
        }
    )

    section = render(review).split("## Unusual adjustment dates", 1)[1].split("## ", 1)[0]

    assert "2026-01-01" not in section
    assert "2026-01-02" not in section
    assert "2026-01-03" not in section
    assert section.index("2026-01-05") < section.index("2026-01-04")


def test_adjustment_date_excerpt_shows_candidates_instead_of_zero_activity():
    review = analyze([adjustment("A", 10)], dates={date(2026, 1, day) for day in range(1, 21)})

    report = render(review)

    section = report.split("## Unusual adjustment dates", 1)[1].split("## ", 1)[0]
    assert "2026-01-02" in section
    assert "2026-01-01" not in section
    assert "2026-01-03" not in section
    assert "CREATIONDATE" in section
    assert "date basis" not in section and "valuation start" not in section
    assert "| 2.000" not in section  # Scores come from the full creation-date calendar.
    assert len(review.tables["Adjustment daily activity"]) == 20


def test_metadata_free_numerical_rows_remain_bound_in_the_evidence_catalog(tmp_path):
    """Bind actual numerical outliers to their source without trusting commentary headings."""
    paths, pnl, attribution, *_ = dataset(tmp_path / "input", n=20)
    attribution[-1]["Unexplained"] = 100
    write_csv(Path(paths["income_attribution_path"]), attribution)
    # Inject a source heading which must never acquire numerical provenance.
    fake = "| Fake PC | 999 |"
    Path(paths["pnl_commentary_path"]).write_text(
        "# Original\n\n## PC PnL summary\n" + fake, encoding="utf-8"
    )
    report, _ = run(paths, tmp_path)
    inputs = {
        "pnl": "pnl_path",
        "attribution": "income_attribution_path",
        "adjustments": "adjustments_path",
        "validation": "validation_history_path",
        "ia_commentary": "income_attribution_commentary_path",
        "pnl_commentary": "pnl_commentary_path",
    }
    sources = [
        Source(id=kind, kind=kind, path=paths[arg], topic="pnl", scope="All supplied desk data")
        for kind, arg in inputs.items()
    ]

    catalog = build_evidence_catalog(RunEvidence(reports=[("pnl", set(inputs), report)]), sources)

    assert any(ref.source_id == "pnl" and "| PC1 |" in ref.excerpt for ref in catalog.values())
    assert any(
        ref.source_id == "attribution" and "Unexplained" in ref.excerpt for ref in catalog.values()
    )
    assert any(
        ref.source_id == "validation" and "| FO | FLASH | 20 |" in ref.excerpt
        for ref in catalog.values()
    )
    assert not any(fake in ref.excerpt for ref in catalog.values())
