"""PnL checks operate on PC daily totals rather than individual GOP/PTF rows."""

from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal

import pytest

from mcp_agent_template.analysis.pnl.calculations import pnl_analysis
from mcp_agent_template.analysis.pnl.loading import prepare
from mcp_agent_template.analysis.pnl.models import Review


def source(day, amount, *, pc="PC1", gop="G1", ptf="P1", **fields):
    return {
        "Value Date": day.isoformat(),
        "DTD": str(amount),
        "Version": "FLASH",
        "Notion": "Final",
        "Currency": "EUR",
        "PC": pc,
        "GOP": gop,
        "PTF": ptf,
        "_ref": f"pnl.csv [date={day}; PC={pc}; GOP={gop}; PTF={ptf}]",
        **fields,
    }


def analyze(rows):
    review = Review()
    prepared = prepare(rows, "pnl", review)
    daily = pnl_analysis(prepared, review)
    return daily, review


def test_gop_ptf_contributions_are_summed_before_pc_outlier_calculation():
    rows = []
    for index in range(11):
        day = date(2026, 1, 1) + timedelta(days=index)
        rows += [
            source(day, 1000 if index == 10 else 10),
            source(day, -970 if index == 10 else 20, gop="G2", ptf="P2"),
            source(day, 1000 if index == 10 else 10, pc="PC2"),
        ]
    original = deepcopy(rows)

    daily, review = analyze(rows)

    assert rows == original
    assert len(daily) == 22
    first_pc = [row for row in daily if row["PC"] == "PC1"]
    assert all(row["DTD"] == 30 and row["source rows"] == 2 for row in first_pc)
    assert all(len(row["_refs"]) == 2 for row in first_pc)
    summaries = {row["PC"]: row for row in review.tables["PnL series"]}
    assert summaries["PC1"]["observations"] == 11
    assert summaries["PC1"]["source rows"] == 22
    assert summaries["PC1"]["DTD sum"] == 330
    assert summaries["PC1"]["outlier screen"] == "unavailable (constant values)"
    (outlier,) = review.tables["PnL outliers"]
    assert outlier["PC"] == "PC2"
    assert outlier["DTD"] == 1000
    assert outlier["n"] == 11
    assert outlier["z score"] == pytest.approx(10**0.5)
    assert [issue["pc"] for issue in review.issues] == ["PC2"]
    assert "PnL monthly" not in review.tables
    assert "pnl cumulative checks" not in review.tables


def test_reversals_compare_aggregated_pc_amounts_once_per_date():
    rows = []
    for index in range(11):
        day = date(2026, 1, 1) + timedelta(days=index)
        sign = 1 if index == 9 else -1 if index == 10 else 0
        rows += [source(day, 60 * sign), source(day, 40 * sign, gop="G2", ptf="P2")]

    _, review = analyze(rows)

    (reversal,) = review.tables["PnL reversal candidates"]
    assert reversal["PC"] == "PC1"
    assert reversal["first DTD"] == 100
    assert reversal["second DTD"] == -100
    assert len(review.tables["PnL daily"]) == 11
    assert len(review.tables["PnL series"]) == 1


def test_pc_scope_rejects_mixed_notion():
    """Notion remains single-valued even when the differing row is numerically invalid."""
    day = date(2026, 1, 1)
    rows = [
        source(day, 10),
        source(day, "invalid", gop="G2", ptf="P2", Notion="Other"),
    ]

    with pytest.raises(ValueError, match="Notion must have exactly one nonblank value"):
        analyze(rows)


def test_version_changes_do_not_split_pc_dates_or_hide_duplicate_keys():
    """Versions may change across dates and constituents but never disambiguate source keys."""
    first, second = date(2026, 1, 1), date(2026, 1, 2)
    rows = [
        source(first, 10),
        source(first, 20, gop="G2", ptf="P2", Version="STAB"),
        source(second, 100, Version=""),
        source(second, 200, gop="G2", ptf="P2", Version="FINAL"),
    ]

    daily, review = analyze(rows)

    assert sorted(row["DTD"] for row in daily) == [Decimal(30), Decimal(300)]
    assert len(review.tables["PnL series"]) == 1
    assert review.tables["PnL series"][0]["observations"] == 2
    assert review.pnl_scope == {"Notion": "Final", "Currency": "EUR"}
    assert all("Version" not in row for row in daily)

    daily, review = analyze([*rows, {**rows[0], "Version": "OTHER"}])
    assert [row["_date"] for row in daily] == [second]
    assert review.incomplete_pnl_dates == {(first, "PC1")}
    assert [issue["check"] for issue in review.issues] == ["duplicate_key", "duplicate_key"]


def test_reported_pc_ytd_is_display_only_and_requires_all_contributions():
    day = date(2026, 1, 1)
    daily, review = analyze(
        [source(day, 10, YTD="1000"), source(day, 20, gop="G2", ptf="P2", YTD="2000")]
    )
    assert daily[0]["YTD"] == 3000
    assert review.issues == []

    daily, review = analyze([source(day, 10, YTD="1000"), source(day, 20, gop="G2", ptf="P2")])
    assert daily[0]["YTD"] is None
    assert review.issues == []


@pytest.mark.parametrize("rejection", ["invalid", "duplicate"])
def test_rejected_constituents_make_the_entire_pc_date_unknown(rejection):
    first, second = date(2026, 1, 1), date(2026, 1, 2)
    rows = [
        source(first, 10),
        source(first, 20, gop="G2", ptf="P2"),
        source(second, 10),
        source(second, 20, gop="G2", ptf="P2"),
    ]
    if rejection == "invalid":
        rows[0]["DTD"] = "invalid"
    else:
        rows.append(dict(rows[0]))

    daily, review = analyze(rows)

    assert len(daily) == 1
    assert daily[0]["_date"] == second
    assert daily[0]["DTD"] == 30
    assert review.tables["PnL series"][0]["observations"] == 1
    assert len(review.incomplete_pnl_dates) == 1
