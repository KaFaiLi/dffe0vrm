"""Full-population hierarchy context through the PnL runner and report artifacts."""

from copy import deepcopy
from pathlib import Path

import pytest
from openpyxl import load_workbook

from mcp_agent_template.analysis.pnl import runners
from mcp_agent_template.analysis.pnl.tree import generate_tree, hierarchy_paths
from tests.analysis.pnl_support import dataset, save_pnl, write_csv
from tests.analysis.test_pnl_analysis import run

pytestmark = pytest.mark.usefixtures("without_png_rendering")


def test_hierarchy_preserves_distinct_parent_paths_and_collapses_daily_repetitions():
    """Displayed parent changes remain distinct while omitted hierarchy levels collapse."""
    rows = [
        {
            "BU": "Business",
            "SBU": "Unit",
            "GPC1": "Group1",
            "GPC2": "Group2",
            "GPC3": "Group3",
            "TD": "Desk A",
            "PC": "PC1",
            "GGOP": "GG1",
            "GOP": "G1",
            "PTF": "P1",
            "DTD": 10,
            "_ref": "pnl.csv [row=2]",
        }
    ]
    rows.extend(
        [
            {**rows[0], "DTD": None, "_ref": "pnl.csv [row=3]"},
            {**rows[0], "PTF": "P2", "_ref": "pnl.csv [row=4]"},
            {**rows[0], "GPC3": "Group4", "TD": "Desk B", "_ref": "pnl.csv [row=5]"},
        ]
    )
    original = deepcopy(rows)

    paths = hierarchy_paths(rows)
    tree = generate_tree(paths)

    assert len(paths) == 2
    assert [path["source rows"] for path in paths] == [3, 1]
    assert all(not {"TD", "GGOP", "PTF"}.intersection(path) for path in paths)
    assert paths[0]["reference"] == "pnl.csv [row=2]"
    assert tree == (
        "Business [BU]\n"
        "└── Unit [SBU]\n"
        "    └── Group1 [GPC1]\n"
        "        └── Group2 [GPC2]\n"
        "            ├── Group3 [GPC3]\n"
        "            │   └── PC1 [PC]\n"
        "            │       └── G1 [GOP]\n"
        "            └── Group4 [GPC3]\n"
        "                └── PC1 [PC]\n"
        "                    └── G1 [GOP]"
    )
    assert rows == original


def test_hierarchy_uses_available_headers_and_keeps_blank_and_literal_labels_distinct():
    """Available PC/GOP labels retain case, blanks and escaped source control characters."""
    rows = [
        {"pc": " PC1 ", "gop": None, "ptf": "P1", "_ref": "source [row=2]"},
        {"pc": "PC1", "gop": "(blank)", "ptf": "P2", "_ref": "source [row=3]"},
        {"pc": "pc1", "gop": "G1\n```\t", "ptf": "P3", "_ref": "source [row=4]"},
    ]

    paths = hierarchy_paths(rows)
    tree = generate_tree(paths)

    assert len(paths) == 3
    assert paths[0]["PC"] == "PC1"
    assert paths[0]["GOP"] == ""
    assert paths[1]["GOP"] == "(blank)"
    assert "BU" not in paths[0]
    assert tree.startswith("├── PC1 [PC]\n")
    assert "└── pc1 [PC]" in tree
    assert "G1\\u000a``` [GOP]" in tree
    assert tree.count("(blank) [GOP]") == 2
    assert "[PTF]" not in tree
    assert hierarchy_paths([]) == []
    assert generate_tree([]) == "No hierarchy paths."


@pytest.mark.parametrize("suffix", [".xlsx", ".csv"])
def test_runner_exports_full_loaded_population_before_numerical_exclusions(
    tmp_path, monkeypatch, suffix
):
    """The reduced hierarchy still retains rejected and duplicate source populations."""
    paths, pnl, *_ = dataset(tmp_path / "input", n=6)
    for row in pnl:
        row.update(BU="Business", SBU="Unit", GPC1="Group", TD="Desk")
    pnl[0].update(PC="OTHER_PC", GOP="OLD_GOP", PTF="OLD_PTF", DTD=None)
    pnl[2].update(PC="REJECTED_PC", GOP="BAD_GOP", PTF="BAD_PTF", DTD=None)
    pnl[3].update(PC="UNDATED_PC", PTF="", **{"Value Date": "invalid"})
    pnl[4].update(PC="DUPLICATE_PC")
    pnl[5].update(PC="OTHER_PC", GOP="OLD_GOP", PTF="OLD_PTF")
    pnl.append(dict(pnl[4]))
    source = Path(paths["pnl_path"]).with_suffix(suffix)
    paths["pnl_path"] = str(source)
    if suffix == ".csv":
        write_csv(source, pnl)
    else:
        save_pnl(source, pnl)
        book = load_workbook(source)
        book.active.title = "PnL data"
        book.create_sheet("Read me", 0).append(["Not the PnL sheet"])
        book.save(source)
        book.close()
    calls = []
    load = runners.load_table

    def record_load(path, role):
        """Record source reads while retaining real loading and validation."""
        calls.append(role)
        return load(path, role)

    monkeypatch.setattr(runners, "load_table", record_load)

    report, tables = run(paths, tmp_path)

    assert calls.count("pnl") == 1
    hierarchy = tables["Desk hierarchy"]
    assert len(hierarchy) == 5
    assert sum(row["source rows"] for row in hierarchy) == 7
    assert {row["PC"] for row in hierarchy} == {
        "PC1",
        "OTHER_PC",
        "REJECTED_PC",
        "UNDATED_PC",
        "DUPLICATE_PC",
    }
    assert next(row for row in hierarchy if row["PC"] == "OTHER_PC")["source rows"] == 2
    assert {row["PC"] for row in tables["PnL daily"]} == {"PC1", "OTHER_PC"}
    assert all(row["observations"] == 1 for row in tables["PnL series"])
    assert all(str(source.resolve()) in row["reference"] for row in hierarchy)
    if suffix == ".xlsx":
        assert all("[sheet=PnL data]" in row["reference"] for row in hierarchy)
    section = report.split("## Desk analytical structure\n\n", 1)[1].split("## ", 1)[0]
    assert "all supplied PnL desk data" in section
    assert "```text\nBusiness [BU]" in section
    for pc in {row["PC"] for row in hierarchy}:
        assert f"{pc} [PC]" in section
    assert "[PTF]" not in section
    assert "[TD]" not in section
    assert all(not {"TD", "GGOP", "PTF"}.intersection(row) for row in hierarchy)
    assert " [GPC2]" not in section
    assert " [GGOP]" not in section
    assert report.index("## Scope and sources") < report.index("## Desk analytical structure")
    assert report.index("## Desk analytical structure") < report.index("## Checks requiring review")
    saved = next((tmp_path / "reports").glob("*/pnl_review.md"))
    assert saved.read_text(encoding="utf-8") == report


def test_complete_hierarchy_bypasses_markdown_row_and_cell_limits_and_excel_formulas(tmp_path):
    """Every displayed GOP and full source label survives rendering and literal Excel export."""
    paths, pnl, *_ = dataset(tmp_path / "input", n=16)
    label = "=SOURCE_TEXT" + "x" * 400
    for i, row in enumerate(pnl):
        row.update(BU=label, GOP=f"GOP_{i:02}", PTF=f"PTF_{i:02}")
    paths["pnl_path"] = str(Path(paths["pnl_path"]).with_suffix(".csv"))
    write_csv(Path(paths["pnl_path"]), pnl)

    report, tables = run(paths, tmp_path)

    section = report.split("## Desk analytical structure\n\n", 1)[1].split("## ", 1)[0]
    assert label + " [BU]" in section
    assert "omitted" not in section
    assert len(tables["Desk hierarchy"]) == 16
    for i in range(16):
        assert f"GOP_{i:02} [GOP]" in section
        assert f"PTF_{i:02} [PTF]" not in section
    book = load_workbook(next((tmp_path / "reports").glob("*/*.xlsx")), data_only=False)
    try:
        sheet = book["Desk hierarchy"]
        assert sheet["A2"].value == label
        assert sheet["A2"].data_type == "s"
        assert sheet.max_row == 17
    finally:
        book.close()
