"""Behavioural checks through the public runner and its saved evidence tables."""

import hashlib
from decimal import Decimal
from pathlib import Path

import pytest
from openpyxl import load_workbook

from mcp_agent_template.analysis.pnl import run_pnl_analysis
from tests.analysis.pnl_support import dataset, save_pnl, write_csv

pytestmark = pytest.mark.usefixtures("without_png_rendering")


def run(paths, tmp_path, **options):
    result = run_pnl_analysis(**paths, output_dir=tmp_path / "reports", **options)
    books = list((tmp_path / "reports").glob("*/*.xlsx"))
    book = load_workbook(books[-1], data_only=False)
    tables = {}
    for sheet in book:
        iterator = sheet.iter_rows(values_only=True)
        columns = next(iterator)
        tables[sheet.title] = [
            dict(zip(columns, row, strict=True)) for row in iterator if row[0] != "No records"
        ]
    book.close()
    return result, tables


def test_baseline_scope_and_evidence(tmp_path):
    paths, *_ = dataset(tmp_path / "input")
    before = {k: hashlib.sha256(Path(v).read_bytes()).digest() for k, v in paths.items()}
    report, tables = run(paths, tmp_path)
    assert not [r for r in tables["Exceptions"] if r["check"] != "adjustment_daily_concentration"]
    assert len(tables["All adjustments"]) == 1
    assert tables["All adjustments"][0]["CREATIONDATE"] == "2026-02-01"
    assert {row["family"] for row in tables["Commentary sources"]} == {"pnl", "attribution"}
    for key in ("income_attribution_commentary_path", "pnl_commentary_path"):
        assert Path(paths[key]).read_text(encoding="utf-8") in report
    assert "Commentary associations" not in tables
    assert all(hashlib.sha256(Path(v).read_bytes()).digest() == before[k] for k, v in paths.items())
    assert {r["team"]: r["Validated"] for r in tables["Validation summary"]} == {
        "FO": 50,
        "MPC": 50,
    }
    assert tables["Validation exceptions"] == []
    assert tables["Devalidated records"] == []
    assert "Attribution validation" not in tables


@pytest.mark.parametrize("suffix", [".xlsx", ".csv"])
def test_all_dates_are_used_independently_for_each_dataset(tmp_path, suffix):
    """Attribution before and after the PnL calendar contributes to totals and drivers."""
    paths, pnl, attribution, adjustments, _ = dataset(tmp_path / "input", n=3)
    pnl[0]["Value Date"], pnl[-1]["Value Date"] = "2020-01-01", "2030-12-31"
    source = Path(paths["pnl_path"]).with_suffix(suffix)
    paths["pnl_path"] = str(source)
    if suffix == ".csv":
        write_csv(source, pnl)
    else:
        save_pnl(source, pnl)
    for row, event_date, amount in zip(
        attribution, ("2019-12-31", "2031-01-01", "2040-01-01"), (10, 20, 30), strict=True
    ):
        row.update(asofdate=event_date, Unexplained=amount, **{"Final Result Acc DTD": amount})
    write_csv(Path(paths["income_attribution_path"]), attribution)
    adjustments[0].update(
        VALDATEBEGIN="2041-01-01", VALDATEEND="2041-01-01", CREATIONDATE="2041-01-02"
    )
    write_csv(Path(paths["adjustments_path"]), adjustments)

    report, tables = run(paths, tmp_path)

    assert {str(row["date"])[:10] for row in tables["PnL daily"]} == {
        row["Value Date"] for row in pnl
    }
    assert {str(row["date"])[:10] for row in tables["Attribution daily"]} == {
        row["asofdate"] for row in attribution
    }
    assert tables["PnL series"][0]["observations"] == 3
    assert Decimal(tables["PnL series"][0]["DTD sum"]) == sum(
        Decimal(str(row["DTD"])) for row in pnl
    )
    assert len(tables["Attribution daily"]) == 3
    assert [Decimal(row["amount"]) for row in tables["Attribution daily"]] == [10, 20, 30]
    assert tables["Adjustment summary"][0]["net amount"] == "10"
    assert "2041-01-02" in {str(row["date"])[:10] for row in tables["Adjustment daily activity"]}
    assert "all supplied dates" in report
    assert "Review period:" not in report
    assert all("in review period" not in row for row in tables["Desk data"])
    assert not {"review period status", "period overlap"}.intersection(tables["All adjustments"][0])


def test_outlier_ignores_attribution_cumulative_and_uses_reported_adjustment_eur(tmp_path):
    paths, pnl, ia, adj, _ = dataset(tmp_path / "input")
    pnl[10]["DTD"] = 100
    save_pnl(paths["pnl_path"], pnl)
    january = next(r for r in ia if r["asofdate"] == "2026-01-01")
    january["Final Result Acc DTD Cumulative"] += 30
    write_csv(Path(paths["income_attribution_path"]), ia)
    adj[0]["AMOUNTINEUR"] = 50
    write_csv(Path(paths["adjustments_path"]), adj)
    _, tables = run(paths, tmp_path)
    flags = tables["Exceptions"]
    assert any(r["check"] == "pnl_outlier" and r["date"] == "2025-12-11" for r in flags)
    assert not any(r["check"] == "attribution_cumulative" for r in flags)
    assert "attribution cumulative checks" not in tables
    assert not any(r["check"] == "adjustment_conversion" for r in flags)
    assert tables["Adjustment summary"][0]["net amount"] == "50"
    assert len(tables["All adjustments"]) == 1


@pytest.mark.parametrize(
    "state,summary_label",
    [
        ("Validated", "Validated"),
        ("Not Validated", "Not Validated"),
        ("Waiting Official PNL", "Waiting Official PNL"),
        ("DEValidated", "DEValidated"),
        ("Custom workflow", "Other"),
    ],
)
def test_validation_summary_keeps_teams_and_states_distinct(tmp_path, state, summary_label):
    """Save state counts and percentages for each team without reinterpreting labels."""
    paths, _, _, _, history = dataset(tmp_path / "input")
    history[0]["state"] = state
    write_csv(Path(paths["validation_history_path"]), history)
    _, tables = run(paths, tmp_path)
    by_team = {row["team"]: row for row in tables["Validation summary"]}
    assert by_team["FO"][summary_label] == (50 if state == "Validated" else 1)
    assert tables["Validation records"][0]["state"] == state
    assert Decimal(by_team["FO"][f"{summary_label} %"]) == (100 if state == "Validated" else 2)
    assert all(row["pnlType"] == "FLASH" for row in by_team.values())
    assert by_team["MPC"]["Validated"] == 50
    assert Decimal(by_team["MPC"]["Validated %"]) == 100
    assert len(tables["Validation exceptions"]) == (state != "Validated")
    assert len(tables["Devalidated records"]) == (state == "DEValidated")
    assert sum(r["check"] == "validation_devalidated" for r in tables["Exceptions"]) == (
        state == "DEValidated"
    )


def test_validation_dataset_ignores_active_and_pnl_dates(tmp_path):
    """Every supplied history row contributes regardless of active flag and date."""
    paths, _, _, _, history = dataset(tmp_path / "input")
    history[0].update(state="Not Validated", active="FALSE", api_request_date="2020-01-01")
    history[1].update(state="DEValidated", active="FALSE", api_request_date="2020-01-01")
    write_csv(Path(paths["validation_history_path"]), history)
    _, tables = run(paths, tmp_path)
    assert len(tables["Validation records"]) == 100
    assert len(tables["Validation exceptions"]) == 2
    assert len(tables["Devalidated records"]) == 1
    assert sum(row["records"] for row in tables["Validation summary"]) == 100
    assert (
        sum(row["Not Validated"] + row["DEValidated"] for row in tables["Validation summary"]) == 2
    )


def test_pnl_attribution_and_validation_are_reviewed_independently(tmp_path):
    """Attribution driver evidence and validation remain independent of PnL amounts."""
    paths, _, ia, _, history = dataset(tmp_path / "input")
    history[1]["state"] = "Not Validated"
    write_csv(Path(paths["validation_history_path"]), history)
    ia[1]["Final Result Acc DTD"] += 5
    for row in ia:
        row["gop"] = "ATTRIBUTION_ONLY"
        row["pc"] = "ATTRIBUTION_PC"
        del row["air_fo_validation status"]
        del row["air_mpc_validation_status"]
    write_csv(Path(paths["income_attribution_path"]), ia)
    report, tables = run(paths, tmp_path)
    assert len(tables["Validation exceptions"]) == 1
    assert tables["Validation exceptions"][0]["team"] == "MPC"
    assert tables["PnL series"][0]["observations"] == 50
    assert len(tables["Attribution daily"]) == 50
    assert {row["pc"] for row in tables["Attribution daily"]} == {"ATTRIBUTION_PC"}
    assert not any(r["check"] == "attribution_cumulative" for r in tables["Exceptions"])
    assert not any(
        r["check"] in {"monetary_scope", "pnl_attribution_difference"} for r in tables["Exceptions"]
    )
    assert "Monetary comparison" not in tables
    assert "monetary reconciliation unavailable" not in report
    assert "Attribution validation" not in tables
    assert not any(r["check"].startswith("attribution_mpc") for r in tables["Exceptions"])


def test_adjustments_retain_all_dates_and_flag_invalid_source_intervals(tmp_path):
    paths, _, _, adj, _ = dataset(tmp_path / "input")
    base = adj[0]
    adj.extend(
        [
            {
                **base,
                "ADJUSTMENTID": "ADJ2",
                "VALDATEBEGIN": "2025-11-01",
                "VALDATEEND": "2025-12-02",
                "AMOUNT": -10,
                "AMOUNTINEUR": -10,
                "SOURCE": "MANUAL",
            },
            {
                **base,
                "ADJUSTMENTID": "ADJ3",
                "VALDATEBEGIN": "2026-05-01",
                "VALDATEEND": "2026-05-01",
            },
            {**base, "ADJUSTMENTID": "ADJ4", "VALDATEBEGIN": ""},
        ]
    )
    write_csv(Path(paths["adjustments_path"]), adj)
    _, tables = run(paths, tmp_path)
    assert {r["ADJUSTMENTID"] for r in tables["All adjustments"]} == {
        "ADJ1",
        "ADJ2",
        "ADJ3",
        "ADJ4",
    }
    assert any(r["check"] == "adjustment_scope" for r in tables["Exceptions"])


def test_adjustments_accept_eur_without_original_amount(tmp_path):
    paths, _, _, adjustments, _ = dataset(tmp_path / "input")
    del adjustments[0]["AMOUNT"]
    adjustments[0].update(AMOUNTINEUR=25, CCY="EUR", GOP="UNMATCHED", PTF="UNMATCHED")
    write_csv(Path(paths["adjustments_path"]), adjustments)

    report, tables = run(paths, tmp_path)

    assert tables["Adjustment summary"][0]["net amount"] == "25"
    assert tables["Adjustment summary"][0]["currency"] == "EUR"
    assert not any(
        row["check"] in {"adjustment_mapping", "adjustment_desk_mapping", "adjustment_conversion"}
        for row in tables["Exceptions"]
    )
    assert not {"desk", "desk mapping", "mapping", "AMOUNT"}.intersection(
        tables["All adjustments"][0]
    )
    assert "## All adjustments" not in report
    assert "## Outlier adjustments" not in report
    summary = report.split("## Adjustment summary")[1].split("## ")[0]
    assert "| source | nature | count |" in summary
    assert "| FREEZE |  | 1 |" in summary
    assert "net amount" not in summary
    assert "25" not in summary


def test_duplicate_source_keys_exclude_the_incomplete_pc_date(tmp_path):
    """Reject both copies of a source key instead of reporting a partial PC total."""
    paths, pnl, *_ = dataset(tmp_path / "input")
    pnl.append(dict(pnl[0]))
    save_pnl(paths["pnl_path"], pnl)
    _, tables = run(paths, tmp_path)
    assert len(tables["PnL series"]) == 1
    assert tables["PnL series"][0]["observations"] == 49
    assert all(str(row["date"])[:10] != "2025-12-01" for row in tables["PnL daily"])
    assert sum(r["check"] == "duplicate_key" for r in tables["Exceptions"]) == 2


@pytest.mark.parametrize(
    "field,value",
    [("Notion", "Other"), ("Notion", "")],
)
def test_pnl_rejects_mixed_or_blank_run_scope_before_numerical_exclusions(tmp_path, field, value):
    """A rejected amount on any supplied date cannot hide conflicting run metadata."""
    paths, pnl, *_ = dataset(tmp_path / "input")
    pnl[0].update({field: value, "DTD": None})
    save_pnl(paths["pnl_path"], pnl)

    with pytest.raises(ValueError, match=f"pnl: {field} must have exactly one nonblank value"):
        run(paths, tmp_path)

    assert not list((tmp_path / "reports").rglob("*.xlsx"))


def test_pnl_rejects_non_eur_inputs_instead_of_relabelling_amounts(tmp_path):
    """The fixed EUR contract fails before export even when every row uses another unit."""
    paths, pnl, *_ = dataset(tmp_path / "input", n=3)
    for row in pnl:
        row["Currency"] = "unsupported-unit"
    save_pnl(paths["pnl_path"], pnl)

    with pytest.raises(ValueError, match="Currency must be EUR"):
        run(paths, tmp_path)

    assert not list((tmp_path / "reports").rglob("*.xlsx"))


@pytest.mark.parametrize("n", [1, 10, 50])
def test_constant_populations_have_unavailable_z_scores(tmp_path, n):
    """Constant known daily values retain zero deviation and unavailable z-scores."""
    paths, pnl, *_ = dataset(tmp_path / "input", n=n)
    for row in pnl:
        row["DTD"] = 0
    save_pnl(paths["pnl_path"], pnl)
    _, tables = run(paths, tmp_path)
    assert tables["PnL outliers"] == []
    assert tables["PnL series"][0]["standard deviation"] == 0
    assert tables["PnL series"][0]["outlier screen"] == "unavailable (constant values)"


def test_small_full_pnl_population_is_screened_for_outliers(tmp_path):
    paths, pnl, *_ = dataset(tmp_path / "input", n=11)
    pnl[-1]["DTD"] = 1000
    save_pnl(paths["pnl_path"], pnl)

    report, tables = run(paths, tmp_path)

    assert tables["PnL series"][0]["observations"] == 11
    assert tables["PnL series"][0]["outlier screen"] == "checked"
    assert len(tables["PnL outliers"]) == 1
    assert tables["PnL outliers"][0]["DTD"] == "1000"
    assert tables["PnL outliers"][0]["n"] == 11
    assert "no minimum observation count" in report


def test_small_full_pnl_population_is_screened_for_reversals(tmp_path):
    paths, pnl, *_ = dataset(tmp_path / "input", n=11)
    for index, row in enumerate(pnl):
        row["DTD"] = 100 if index == 9 else -100 if index == 10 else 0
        for field in ("WTD", "MTD", "QTD", "YTD"):
            row[field] = 100 if index == 9 else 0
    save_pnl(paths["pnl_path"], pnl)

    _, tables = run(paths, tmp_path)

    assert tables["PnL series"][0]["outlier screen"] == "checked"
    assert len(tables["PnL reversal candidates"]) == 1
    assert tables["PnL reversal candidates"][0]["first DTD"] == "100"
    assert tables["PnL reversal candidates"][0]["second DTD"] == "-100"


def test_reported_attribution_cumulative_is_unchecked_and_text_is_not_formula(tmp_path):
    paths, _, ia, adj, _ = dataset(tmp_path / "input", n=20)
    for row in ia:
        row["Final Result Acc DTD Cumulative"] += 200
    adj[0]["COMMENTS"] = "=HYPERLINK(1)"
    write_csv(Path(paths["income_attribution_path"]), ia)
    write_csv(Path(paths["adjustments_path"]), adj)
    _, tables = run(paths, tmp_path)
    assert not [r for r in tables["Exceptions"] if "cumulative" in r["check"]]
    book = load_workbook(next((tmp_path / "reports").glob("*/*.xlsx")), data_only=False)
    assert not any(c.data_type == "f" for sheet in book for row in sheet for c in row)
    book.close()


def test_markdown_summarizes_validation_states_instead_of_backlog_rows(tmp_path):
    """The report replaces the state-count section with grouped counts and percentages."""
    paths, _, _, _, history = dataset(tmp_path / "input")
    for row in history:
        if row["team"] == "MPC":
            row["state"] = "Not Validated"
            row["active"] = "FALSE"
    history[-2]["state"] = "DEValidated"
    write_csv(Path(paths["validation_history_path"]), history)
    report, tables = run(paths, tmp_path)
    section = report.split("## Validation summary")[1].split("## ")[0]
    assert "| FO | FLASH | 50 | 0 | 0.00% | 0 | 0.00% | 49 | 98.00% | 1 | 2.00% |" in section
    assert "| MPC | FLASH | 50 | 50 | 100.00% | 0 | 0.00% | 0 | 0.00% | 0 | 0.00% |" in section
    assert "## Validation state counts" not in report
    assert "Validation state counts" not in tables
    assert "not labelled Validated" not in report
    assert len(tables["Validation exceptions"]) == 51
    assert len(tables["Devalidated records"]) == 1
    assert "## Devalidated summary" in report
    assert "## Validation exceptions" not in report
    assert "## Devalidated records" not in report
    assert "## Validation records" not in report


def test_validation_percentages_split_stab_and_flash_in_markdown_and_workbook(tmp_path):
    """The public runner saves and displays independent team/type denominators."""
    paths, _, _, _, history = dataset(tmp_path / "input", n=3)
    for index, row in enumerate(history):
        row["pnlType"] = "STAB" if index < 4 else "FLASH"
    history[0]["state"] = "Not Validated"
    history[4]["state"] = "DEValidated"
    write_csv(Path(paths["validation_history_path"]), history)

    report, tables = run(paths, tmp_path)

    summary = {(row["team"], row["pnlType"]): row for row in tables["Validation summary"]}
    assert len(summary) == 4
    assert summary[("FO", "STAB")]["records"] == 2
    assert Decimal(summary[("FO", "STAB")]["Not Validated %"]) == 50
    assert summary[("FO", "FLASH")]["records"] == 1
    assert Decimal(summary[("FO", "FLASH")]["DEValidated %"]) == 100
    assert Decimal(summary[("MPC", "STAB")]["Validated %"]) == 100
    section = report.split("## Validation summary")[1].split("## ")[0]
    assert "| FO | STAB | 2 | 1 | 50.00% | 0 | 0.00% | 1 | 50.00% | 0 | 0.00% |" in section
    assert "| FO | FLASH | 1 | 0 | 0.00% | 0 | 0.00% | 0 | 0.00% | 1 | 100.00% |" in section
    assert "records without validation" not in section


def test_attribution_hierarchies_are_aggregated_to_the_same_pc_date(tmp_path):
    """Distinct hierarchy contributions sum once into their shared daily PC amount."""
    paths, _, ia, _, _ = dataset(tmp_path / "input")
    ia.append({**ia[0], "td": "ANOTHER_DESK"})
    write_csv(Path(paths["income_attribution_path"]), ia)
    _, tables = run(paths, tmp_path)
    assert len(tables["Attribution daily"]) == 50
    assert tables["Attribution daily"][0]["source rows"] == 2
    assert sum(row["source rows"] for row in tables["Attribution daily"]) == 51
    assert tables["PnL series"][0]["observations"] == 50
    assert "Monetary comparison" not in tables
    assert not any(row["check"] == "monetary_scope" for row in tables["Exceptions"])


@pytest.mark.parametrize("change", ["missing-file", "bad-schema", "bad-dates"])
def test_actionable_input_errors(tmp_path, change):
    """Invalid source dates remain input errors without a review-period parameter."""
    paths, pnl, *_ = dataset(tmp_path / "input")
    if change == "missing-file":
        Path(paths["pnl_path"]).unlink()
    elif change == "bad-schema":
        Path(paths["adjustments_path"]).write_text("wrong\n1\n")
    else:
        for row in pnl:
            row["Value Date"] = "invalid"
        save_pnl(paths["pnl_path"], pnl)
    with pytest.raises(ValueError):
        run_pnl_analysis(**paths, output_dir=tmp_path / "reports")


@pytest.mark.parametrize("rejection", ["invalid", "duplicate"])
@pytest.mark.parametrize("index", [1, 31])
def test_rejected_attribution_dates_remain_gaps_in_pc_evidence(tmp_path, rejection, index):
    """Rejected constituents remain unknown even outside the PnL date coverage."""
    paths, _, rows, *_ = dataset(tmp_path / "input", n=34)
    rows[index]["asofdate"] = "2040-01-01"
    rejected_date = rows[index]["asofdate"]
    if rejection == "invalid":
        rows[index]["gop"] = ""
    else:
        rows.append(dict(rows[index]))
    write_csv(Path(paths["income_attribution_path"]), rows)
    _, tables = run(paths, tmp_path)
    assert any(r["check"] in {"invalid_row", "duplicate_key"} for r in tables["Exceptions"])
    assert not any(r["check"] == "attribution_cumulative" for r in tables["Exceptions"])
    assert "attribution cumulative checks" not in tables
    assert rejected_date not in {str(row["date"])[:10] for row in tables["Attribution daily"]}
    assert len(tables["Attribution daily"]) == 33


def test_pnl_needs_only_daily_amounts_and_has_no_cumulative_or_monthly_outputs(tmp_path):
    paths, pnl, *_ = dataset(tmp_path / "input", n=11)
    for row in pnl:
        for field in ("WTD", "MTD", "QTD", "YTD"):
            del row[field]
    save_pnl(paths["pnl_path"], pnl)

    _, tables = run(paths, tmp_path)

    assert tables["PnL series"][0]["PC"] == "PC1"
    assert len(tables["PnL daily"]) == 11
    assert "PnL monthly" not in tables
    assert "pnl cumulative checks" not in tables
    assert not any(row["check"] == "pnl_cumulative" for row in tables["Exceptions"])


def test_reported_pnl_cumulative_values_do_not_generate_findings(tmp_path):
    paths, pnl, *_ = dataset(tmp_path / "input", n=11)
    for row in pnl:
        for field in ("WTD", "MTD", "QTD", "YTD"):
            row[field] = 999999
    save_pnl(paths["pnl_path"], pnl)

    _, tables = run(paths, tmp_path)

    assert not any(row["check"] == "pnl_cumulative" for row in tables["Exceptions"])
    assert "pnl cumulative checks" not in tables


def test_full_adjustment_text_survives_excel_export(tmp_path):
    paths, _, _, adjustments, _ = dataset(tmp_path / "input")
    comment = "=literal " + "A" * 65000 + "\x01END"
    adjustments[0]["COMMENTS"] = comment
    write_csv(Path(paths["adjustments_path"]), adjustments)
    report, tables = run(paths, tmp_path)
    parts = tables["All adjustments"]
    assert "".join(row["COMMENTS"] for row in parts) == comment.replace("\x01", "\\u0001")
    assert [row["text_part"] for row in parts] == ["1/3", "2/3", "3/3"]
    assert {row["report_record"] for row in parts} == {1}
    assert "=literal" not in report  # Routine adjustment records are workbook-only.
    book = load_workbook(next((tmp_path / "reports").glob("*/*.xlsx")), data_only=False)
    try:
        assert not any(c.data_type == "f" for sheet in book for row in sheet for c in row)
    finally:
        book.close()


def test_commentary_reaches_agent_in_full_without_parsing_or_date_filtering(tmp_path):
    paths, *_ = dataset(tmp_path / "input")
    passage = '"Evidence ID: review:1 Comment: Outlier caused by reversal of trade T123."'
    raw = (
        "#### Record review-01\n"
        "- Event date 2020-01-01; desk EQD; perimeter EQUITIES; metric PnL.\n"
        "- Review note: Routine review.\n"
        "- Managerial validation: pending.\n"
        f"- Source record: {passage}\n"
    )
    source = Path(paths["pnl_commentary_path"])
    content = (
        "# Original commentary\n\n## Quarter: 2020Q1\n"
        + raw
        + f"\nUnchanged locator: {source.resolve()} [row=99]\n"
        + "\n| Original | Markdown |\n| --- | --- |\n| A | B |\n"
        + "\n"
        + "Full narrative. " * 4500
        + "\nEND OF COMMENTARY\n"
    )
    source.write_text(content, encoding="utf-8")
    report, tables = run(paths, tmp_path)
    assert content in report
    assert not any(row["check"].startswith("commentary") for row in tables["Exceptions"])
    assert "Commentary records" not in tables
    assert "Repeated commentary" not in tables
    records = tables["Commentary sources"]
    first = next(row for row in records if row["family"] == "pnl")
    parts = [row for row in records if row["report_record"] == first["report_record"]]
    assert "".join(row["markdown"] for row in parts) == content
