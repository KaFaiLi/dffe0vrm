"""Standalone validation summaries use only the supplied validation dataset."""

from copy import deepcopy
from datetime import date
from decimal import Decimal

from mcp_agent_template.analysis.pnl.controls import validation_analysis
from mcp_agent_template.analysis.pnl.models import Review


def record(state, *, team="FO", requested="2026-01-01", **fields):
    return {
        "gop": "G1",
        "team": team,
        "state": state,
        "api_request_date": requested,
        "pnlType": "FLASH",
        "_ref": "validation.csv [row=2]",
        **fields,
    }


def test_summary_counts_all_four_states_and_flags_only_devalidated_rows():
    """State percentages accompany counts while only DEValidated produces flags."""
    rows = [
        record("Validated"),
        record("Not Validated", team="fo"),
        record("Waiting Official PNL"),
        record("DEValidated", team="MPC", requested="01/02/2026"),
        record("Validated", team="mpc"),
    ]
    original = deepcopy(rows)
    review = Review()

    validation_analysis(rows, review)

    assert rows == original
    assert review.tables["Validation summary"] == [
        {
            "team": "FO",
            "pnlType": "FLASH",
            "records": 3,
            "Not Validated": 1,
            "Not Validated %": Decimal(100) / 3,
            "Waiting Official PNL": 1,
            "Waiting Official PNL %": Decimal(100) / 3,
            "Validated": 1,
            "Validated %": Decimal(100) / 3,
            "DEValidated": 0,
            "DEValidated %": 0,
        },
        {
            "team": "MPC",
            "pnlType": "FLASH",
            "records": 2,
            "Not Validated": 0,
            "Not Validated %": 0,
            "Waiting Official PNL": 0,
            "Waiting Official PNL %": 0,
            "Validated": 1,
            "Validated %": 50,
            "DEValidated": 1,
            "DEValidated %": 50,
        },
    ]
    assert len(review.tables["Validation records"]) == 5
    assert [r["state"] for r in review.tables["Validation exceptions"]] == [
        "Not Validated",
        "Waiting Official PNL",
        "DEValidated",
    ]
    (devalidated,) = review.tables["Devalidated records"]
    assert devalidated["review date"] == date(2026, 1, 2)
    assert devalidated["reference"] == "validation.csv [row=2]"
    assert [issue["check"] for issue in review.issues] == ["validation_devalidated"]
    assert "Attribution validation" not in review.tables


def test_all_validated_records_have_one_hundred_percent_and_no_flags():
    """An all-validated group keeps its denominator and produces no review flags."""
    review = Review()
    validation_analysis([record("Validated", team="MPC")], review)

    assert review.tables["Validation summary"][0]["Validated %"] == 100
    assert "records without validation" not in review.tables["Validation summary"][0]
    assert review.tables["Validation exceptions"] == []
    assert review.tables["Devalidated records"] == []
    assert review.issues == []


def test_no_active_filter_pnl_mapping_or_latest_state_selection():
    """Repeated and inactive rows remain in the percentage denominator."""
    first = record("Not Validated", requested="2020-01-01", active="FALSE", gop="UNMATCHED")
    rows = [first, dict(first), record("Validated", requested="2026-01-02", gop="UNMATCHED")]
    review = Review()

    validation_analysis(rows, review)

    assert review.tables["Validation summary"][0]["records"] == 3
    assert review.tables["Validation summary"][0]["Not Validated"] == 2
    assert review.tables["Validation summary"][0]["Not Validated %"] == Decimal(200) / 3
    assert len(review.tables["Validation exceptions"]) == 2
    assert review.tables["Devalidated records"] == []
    assert review.issues == []


def test_additional_states_are_counted_as_other_and_retained_in_details():
    """Additional labels retain their source text and contribute to Other percentages."""
    rows = [
        record("Validated"),
        record("Custom workflow"),
        record("DEValidated", team="MPC"),
        record("validated", team="MPC"),
    ]
    review = Review()

    validation_analysis(rows, review)

    summary = {row["team"]: row for row in review.tables["Validation summary"]}
    assert summary["FO"]["Other"] == 1
    assert summary["FO"]["Validated"] == 1
    assert summary["FO"]["Other %"] == 50
    assert summary["MPC"]["Other"] == 1
    assert summary["MPC"]["DEValidated"] == 1
    assert summary["MPC"]["DEValidated %"] == 50
    assert summary["MPC"]["Other %"] == 50
    assert [row["state"] for row in review.tables["Validation records"]] == [
        "Validated",
        "Custom workflow",
        "DEValidated",
        "validated",
    ]
    assert [row["state"] for row in review.tables["Validation exceptions"]] == [
        "Custom workflow",
        "DEValidated",
        "validated",
    ]
    assert [issue["check"] for issue in review.issues] == ["validation_devalidated"]


def test_original_states_and_devalidated_rows_are_summarized_without_filtering():
    """Grouped validation replaces the redundant original-state table."""
    rows = [record("Official PNL", team="MPC") for _ in range(4)] + [
        record("DEValidated"),
        record("DEValidated", team="fo"),
        record("Validated"),
    ]
    review = Review()

    validation_analysis(rows, review)

    assert "Validation state counts" not in review.tables
    summary = {row["team"]: row for row in review.tables["Validation summary"]}
    assert summary["FO"]["DEValidated"] == 2
    assert summary["MPC"]["Other"] == 4
    assert summary["MPC"]["Other %"] == 100
    assert review.tables["Devalidated summary"] == [
        {"team": "FO", "gop": "G1", "pnlType": "FLASH", "records": 2}
    ]
    assert len(review.tables["Validation records"]) == 7


def test_percentages_use_independent_team_and_pnl_type_denominators():
    """STAB and FLASH percentages use their own totals and retain other/blank types."""
    rows = [
        record("Validated", pnlType=" stab ", team=" fo "),
        record("Validated", pnlType="STAB"),
        record("DEValidated", pnlType=" stab "),
        record("Validated", pnlType="FLASH"),
        record("Official PNL", pnlType="flash"),
        record("Not Validated", pnlType="STAB", team="MPC"),
        record("Waiting Official PNL", pnlType="", team="MPC"),
        record("Validated", pnlType="CUSTOM", team="MPC"),
    ]
    original = deepcopy(rows)
    review = Review()

    validation_analysis(rows, review)

    summary = {(row["team"], row["pnlType"]): row for row in review.tables["Validation summary"]}
    assert summary[("FO", "STAB")]["records"] == 3
    assert summary[("FO", "STAB")]["Validated %"] == Decimal(200) / 3
    assert summary[("FO", "FLASH")]["records"] == 2
    assert summary[("FO", "FLASH")]["Validated %"] == 50
    assert summary[("FO", "FLASH")]["Other %"] == 50
    assert summary[("MPC", "STAB")]["Not Validated %"] == 100
    assert summary[("MPC", "")]["Waiting Official PNL %"] == 100
    assert summary[("MPC", "CUSTOM")]["Validated %"] == 100
    assert sum(row["records"] for row in summary.values()) == len(rows)
    assert review.tables["Devalidated summary"] == [
        {"team": "FO", "gop": "G1", "pnlType": "STAB", "records": 1}
    ]
    assert rows == original


def test_empty_validation_has_no_percentages_or_division_by_zero():
    """No supplied history produces no groups, records or flags."""
    review = Review()

    validation_analysis([], review)

    assert review.tables["Validation summary"] == []
    assert review.tables["Validation records"] == []
    assert review.issues == []
