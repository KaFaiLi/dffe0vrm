"""Exercise the in-memory review and read-only renderers through their interfaces."""

from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

import pytest
from openpyxl import load_workbook

from mcp_agent_template.analysis.pnl import excel, reporting
from mcp_agent_template.analysis.pnl.charts import pnl_charts
from mcp_agent_template.analysis.pnl.runners import analyze_pnl


def records() -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    """Supply canonical scalar records with independent dates and repeated locators."""
    pnl = [
        {
            "Value Date": date(2026, 1, 1) + timedelta(days=index),
            "Notion": "Final",
            "Currency": "EUR",
            "PC": "PC1",
            "GOP": "G1",
            "DTD": "10.125" if index == 9 else "0.125",
            "_ref": "same supplied locator",
        }
        for index in range(10)
    ]
    attribution = [
        {
            "asofdate": "2030-01-01",
            "pc": "IA_PC",
            "gop": "IA_GOP",
            "Final Result Acc DTD": "0",
            "First driver": "1.125",
            "Second driver": "-1.125",
            "Unknown driver": "",
            "_ref": "attribution record",
        }
    ]
    adjustments = [
        {
            "ADJUSTMENTID": "A1",
            "AMOUNTINEUR": "1.125",
            "VALDATEBEGIN": "invalid",
            "VALDATEEND": "2026-01-01",
            "CREATIONDATE": "2031-01-01",
            "COMMENTS": "=literal",
            "_ref": "adjustment record",
        }
    ]
    validation = [
        {"team": "fo", "state": state, "api_request_date": "bad date", "_ref": "history"}
        for state in ("Validated", "Validated ", "DEValidated")
    ]
    return pnl, attribution, adjustments, validation


def test_analysis_needs_no_files_or_settings_and_keeps_input_records(monkeypatch):
    """One result retains independent populations, exact values and chart evidence."""
    supplied = records()
    original = deepcopy(supplied)

    def unexpected(*args, **kwargs):
        """Fail if pure analysis attempts to read paths or application settings."""
        pytest.fail("In-memory analysis attempted I/O or settings access")

    monkeypatch.setattr(Path, "open", unexpected)
    monkeypatch.setattr("mcp_agent_template.config.get_settings", unexpected)
    review = analyze_pnl(*supplied)

    assert supplied == original
    assert [row["supplied rows"] for row in review.tables["Desk data"]] == [10, 1, 1, 3]
    assert review.tables["PnL series"][0]["DTD sum"] == Decimal("11.250")
    assert review.tables["PnL outliers"][0]["z score"] == 3  # Equality is included.
    assert len(review.pnl_daily) == 10  # Source locators are not business identity.
    assert all(row["_refs"] == ["same supplied locator"] for row in review.pnl_daily)
    assert [row["driver"] for row in review.tables["Attribution daily"]] == [
        "First driver",
        "Second driver",
        "Unknown driver",
    ]
    assert review.tables["Attribution daily"][2]["amount"] is None
    assert "Attribution trends" not in review.tables
    assert review.tables["Adjustment summary"][0]["net amount"] == Decimal("1.125")
    assert len(review.tables["Adjustment daily activity"]) == 11
    assert review.tables["Validation summary"][0]["Other"] == 1
    assert review.tables["Validation summary"][0]["DEValidated"] == 1
    assert review.tables["Validation summary"][0]["pnlType"] == ""
    assert len(review.tables["Devalidated records"]) == 1
    assert "Sources" not in review.tables and "Commentary sources" not in review.tables


def test_preparation_keeps_full_hierarchy_and_rejects_entire_incomplete_pc_dates():
    """Duplicate keys and invalid constituents leave calendar gaps without losing hierarchy."""
    supplied = records()
    pnl, attribution, *_ = supplied
    pnl.append({**pnl[0], "Version": "different version"})
    pnl.append({**pnl[1], "GOP": "rejected GOP", "DTD": "invalid"})
    attribution.append(dict(attribution[0]))
    original = deepcopy(supplied)

    review = analyze_pnl(*supplied)

    assert supplied == original
    assert len(review.source_dates["pnl"]) == 10
    assert review.incomplete_pnl_dates == {(date(2026, 1, 1), "PC1"), (date(2026, 1, 2), "PC1")}
    assert [row["_date"] for row in review.pnl_daily] == [
        date(2026, 1, 1) + timedelta(days=index) for index in range(2, 10)
    ]
    assert {row["GOP"] for row in review.tables["Desk hierarchy"]} == {"G1", "rejected GOP"}
    assert review.tables["Attribution daily"] == []
    assert review.tables["Desk data"][0]["valid unique rows"] == 9
    assert review.tables["Desk data"][0]["PC daily totals"] == 8
    assert len([issue for issue in review.issues if issue["check"] == "duplicate_key"]) == 4


@pytest.mark.parametrize("failure", ["scope", "pnl", "adjustment"])
def test_analysis_errors_leave_inputs_unchanged(failure):
    """Failing scope, source-population and EUR validation preserve caller data."""
    supplied = records()
    if failure == "scope":
        supplied[0][0]["Notion"] = "Other"
        message = "Notion must have exactly one nonblank value"
    elif failure == "pnl":
        for row in supplied[0]:
            row["DTD"] = "invalid"
        message = "No valid PnL observations"
    else:
        supplied[2][0]["AMOUNTINEUR"] = "invalid"
        message = "AMOUNTINEUR must be present and numeric"
    original = deepcopy(supplied)

    with pytest.raises(ValueError, match=message):
        analyze_pnl(*supplied)
    assert supplied == original


def test_repeated_analysis_and_all_renderers_preserve_results(tmp_path):
    """Markdown, workbook and chart consumption cannot alter shared calculated evidence."""
    supplied = records()
    review = analyze_pnl(*supplied)
    assert analyze_pnl(*supplied) == review
    review.tables["Commentary sources"] = [
        {"family": "pnl", "path": "synthetic.md", "markdown": "=literal\x01" + "text|" * 7000}
    ]
    original = deepcopy(review)
    workbook = tmp_path / "review.xlsx"
    report = reporting.markdown(review, workbook, tmp_path / "review.md")
    excel.export_workbook(review, workbook)
    for chart in pnl_charts(review.pnl_daily, review):
        assert chart.unit == "EUR"
        assert chart.findings[0]["z score"] == 3
        chart.figure.clear()
    assert review == original
    assert "## Scope and sources\n\nNotion: Final; Currency: EUR.\n\nNo records." in report
    assert "No valid PnL observations" not in report
    assert review.tables["Commentary sources"][0]["markdown"] in report
    book = load_workbook(workbook)
    try:
        text_cells = [row[2] for row in list(book["Commentary sources"])[1:]]
        assert len(text_cells) == 2
        assert all(cell.data_type == "s" for cell in text_cells)
        assert "".join(cell.value for cell in text_cells) == "=literal\\u0001" + "text|" * 7000
        assert book["PnL daily"]["C11"].value == "10.125"
        assert book["PnL daily"]["C11"].data_type == "s"
    finally:
        book.close()
