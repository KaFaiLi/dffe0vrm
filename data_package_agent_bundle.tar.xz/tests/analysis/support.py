"""Synthetic post-trade datasets shared by unit and real MCP tests."""

from pathlib import Path

import polars as pl


def workbook_table(workbook, sheet_name: str, table_name: str) -> list[dict]:
    """Read a named evidence table without depending on its presentation position."""
    sheet = workbook[sheet_name]
    rows = iter(sheet[sheet.tables[table_name].ref])
    header = [cell.value for cell in next(rows)]
    return [dict(zip(header, [cell.value for cell in row], strict=True)) for row in rows]


def write_cases(path: Path, rows: list[dict] | None = None) -> Path:
    if rows is None:
        rows = [case_row()]
    path.parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(rows).write_parquet(path)
    return path


def case_row(**changes) -> dict:
    return {
        "Case_Id": "case-1",
        "control_logical_code": "CTRL-1",
        "control_description": "Synthetic trade review",
        "control_execution_date": "2025-01-01",
        "status": "Completed",
        "final_decision": "Breach",
        "historic_comments_count": 0,
        "hit_search_items": "Synthetic item",
        **changes,
    }
