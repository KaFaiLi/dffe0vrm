"""Chart evidence and headless PNG rendering through the production runners."""

import gc
import hashlib
import json
import struct
import weakref
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from pathlib import Path

import numpy as np
import pytest
from matplotlib import dates as mdates
from matplotlib.figure import Figure
from matplotlib.text import Text

from mcp_agent_template.analysis import charts
from mcp_agent_template.analysis.pnl import run_pnl_analysis
from mcp_agent_template.analysis.risk_metrics import run_risk_metrics_analysis
from tests.analysis.pnl_support import dataset, save_pnl, write_csv
from tests.analysis.risk_support import sgmr_row, sgmr_series, write_sgmr


def sample_chart():
    figure = Figure()
    axis = figure.subplots()
    axis.plot([1, 2], [2, 1])
    charts.style(figure, r"<script>literal</script> $\not_a_math_command$", "Synthetic export")
    return charts.Chart(figure, "test", "Synthetic export", {}, "units", [], [])


def family(items, name):
    return [item for item in items if item.family == name]


def trace(chart, name):
    return next(
        item for axis in chart.figure.axes for item in axis.lines if item.get_label() == name
    )


def test_pnl_exports_only_daily_pc_charts_without_llm_previews(tmp_path, captured_charts):
    """Daily PnL uses a line with source values and standalone calendar-year charts."""
    paths, pnl, attribution, *_ = dataset(tmp_path / "inputs")
    for row in attribution:
        row["pc"] = "ATTRIBUTION_ONLY"
        row["Market Effect"] = 4
        row["Market Effect Cumulative"] = 100
    write_csv(Path(paths["income_attribution_path"]), attribution)
    pnl[0]["DTD"] = -3
    save_pnl(paths["pnl_path"], pnl)

    result = run_pnl_analysis(**paths, output_dir=tmp_path / "reports")

    assert len(captured_charts) == 2
    assert {chart.family for chart in captured_charts} == {"pnl_daily"}
    assert all(chart.scope["PC"] == "PC1" for chart in captured_charts)
    daily = captured_charts[0]
    assert trace(daily, "Daily PnL").get_ydata()[0] == -3
    assert trace(daily, "Daily PnL").get_color() == charts.COLORS[0]
    assert daily.unit == "EUR"
    assert {d.year for d in daily.dates} == {2025}
    assert {d.year for d in captured_charts[1].dates} == {2026}
    assert "![" not in result
    assert "## Visualizations" not in result
    assert "charts/" not in result
    report = next((tmp_path / "reports").glob("*/*.md"))
    assert result == report.read_text(encoding="utf-8")
    assert (report.parent / "charts/index.md").exists()


def test_pnl_gaps_conflicts_and_separate_series(tmp_path, captured_charts):
    """Rejected PC1 contributions leave line gaps without excluding complete PC2 dates."""
    paths, pnl, *_ = dataset(tmp_path / "inputs", n=5)
    pnl.extend({**row, "PC": "PC2"} for row in list(pnl))
    pnl[1]["DTD"] = ""
    pnl.append(dict(pnl[2]))
    save_pnl(paths["pnl_path"], pnl)

    run_pnl_analysis(**paths, output_dir=tmp_path / "reports")

    daily = family(captured_charts, "pnl_daily")
    assert {item.unit for item in daily} == {"EUR"}
    assert {item.scope["PC"] for item in daily} == {"PC1", "PC2"}
    first = next(item for item in daily if item.scope["PC"] == "PC1")
    assert np.isnan(trace(first, "Daily PnL").get_ydata()[1:3]).all()
    second = next(item for item in daily if item.scope["PC"] == "PC2")
    assert not np.isnan(trace(second, "Daily PnL").get_ydata()).any()
    assert all(not chart.findings for chart in daily)


def test_pnl_charts_use_pc_totals_from_the_desk_tree_source(tmp_path, captured_charts):
    """The plotted line sums complete GOP/PTF contributions before chart generation."""
    paths, pnl, *_ = dataset(tmp_path / "inputs", n=3)
    expected_dtd = [row["DTD"] + 10 for row in pnl]
    additions = [{**row, "GOP": "G2", "PTF": "P2", "DTD": 10, "YTD": 100} for row in pnl]
    additions[1]["YTD"] = None
    save_pnl(paths["pnl_path"], pnl + additions)

    result = run_pnl_analysis(**paths, output_dir=tmp_path / "reports")

    (daily,) = captured_charts
    assert daily.family == "pnl_daily"
    assert list(trace(daily, "Daily PnL").get_ydata()) == pytest.approx(expected_dtd)
    assert daily.scope["PC"] == "PC1"
    assert not {"GOP", "PTF"}.intersection(daily.scope)
    assert len(daily.references) == 6
    assert all(paths["pnl_path"] in ref for ref in daily.references)
    assert all(label in result for label in ("PC1 [PC]", "G1 [GOP]", "G2 [GOP]"))


def test_daily_only_pnl_does_not_require_cumulative_columns(tmp_path, captured_charts):
    """Daily-only inputs generate the same PC line without cumulative metadata."""
    paths, pnl, *_ = dataset(tmp_path / "inputs", n=3)
    for row in pnl:
        for field in ("WTD", "MTD", "QTD", "YTD"):
            del row[field]
    save_pnl(paths["pnl_path"], pnl)

    run_pnl_analysis(**paths, output_dir=tmp_path / "reports")

    (daily,) = captured_charts
    assert daily.family == "pnl_daily"
    assert list(trace(daily, "Daily PnL").get_ydata()) == pytest.approx([row["DTD"] for row in pnl])


def test_pnl_outliers_keep_all_dates_scores_and_exact_pc_series(tmp_path, captured_charts):
    """Annual lines retain full-population scores and never borrow another PC's outliers."""
    paths, pnl, *_ = dataset(tmp_path / "inputs", n=33)
    for row in pnl:
        row["DTD"] = 0
    pnl[-2]["DTD"], pnl[-1]["DTD"] = 400, -400
    # Only two observations are in January: an annual re-screen would miss both.
    additions = [{**row, "GOP": "G2", "PTF": "P2", "DTD": row["DTD"] * 1.5} for row in pnl]
    other = [{**row, "PC": "PC2", "DTD": 1} for row in pnl]
    save_pnl(paths["pnl_path"], pnl + additions + other)

    run_pnl_analysis(**paths, output_dir=tmp_path / "reports")

    marked = [chart for chart in captured_charts if chart.findings]
    assert len(marked) == 1
    (chart,) = marked
    assert chart.scope == {"PC": "PC1"}
    assert chart.dates == [date(2026, 1, 1), date(2026, 1, 2)]
    assert list(trace(chart, "Daily PnL").get_ydata()) == pytest.approx([1000, -1000])
    assert [item["DTD"] for item in chart.findings] == [1000, -1000]
    assert [item["z score"] for item in chart.findings] == pytest.approx(
        [(33 / 2) ** 0.5, -((33 / 2) ** 0.5)]
    )
    assert all(item["check"] == "pnl_outlier" and item["n"] == 33 for item in chart.findings)
    axis = chart.figure.axes[0]
    np.testing.assert_allclose(
        axis.collections[0].get_offsets(),
        list(zip(mdates.date2num(chart.dates), [1000, -1000], strict=True)),
    )
    assert {text.get_text() for text in axis.texts} == {
        "2026-01-01\nz=4.06",
        "2026-01-02\nz=-4.06",
    }
    assert any("all supplied dates" in text.get_text() for text in axis.get_legend().get_texts())
    assert all(not other.figure.axes[0].collections for other in captured_charts if other != chart)


def test_pnl_chart_labels_render_source_markup_literally(tmp_path, captured_charts):
    paths, pnl, *_ = dataset(tmp_path / "inputs", n=2)
    for row in pnl:
        row["PC"] = "<script>PC</script> $not_math$"
    save_pnl(paths["pnl_path"], pnl)

    run_pnl_analysis(**paths, output_dir=tmp_path / "reports")

    (chart,) = captured_charts
    assert "<script>PC</script>" in chart.title
    assert all(
        not text.get_parse_math() and not text.get_usetex() for text in chart.figure.findobj(Text)
    )
    index = next((tmp_path / "reports").glob("*/charts/index.md")).read_text(encoding="utf-8")
    assert "<script>" not in index


def test_risk_values_and_limit_history_without_consumption_overlays(tmp_path, captured_charts):
    """Risk charts retain values and independent history markers on one axis only."""
    rows = sgmr_series([10, 11, -12, 10])
    rows[2]["limMinValue"] = -11
    rows[3]["limMaxValue"] = 20
    for item in rows:
        item["limTempMaxValue"] = 100
    source = write_sgmr(tmp_path / "risk.parquet", rows)
    run_risk_metrics_analysis(source, output_dir=tmp_path / "reports")
    chart = captured_charts[0]
    assert list(trace(chart, "Observed risk").get_ydata()) == [10, 11, -12, 10]
    assert len(chart.figure.axes) == 1
    labels = {line.get_label() for line in chart.figure.axes[0].lines}
    assert labels == {"Observed risk", "Limit change"}
    assert "observed_limit_change" in {item["check"] for item in chart.findings}
    assert all(item["source_locator"].startswith(f"{source.name} [id=") for item in chart.findings)


def test_risk_gaps_scenarios_relative_limits_and_other_metrics(tmp_path, captured_charts):
    rows = sgmr_series([8, None, 12])
    rows.append({**rows[2], "consoValue": 14})
    rows.extend(sgmr_series([1, 2, 3], consoSttScenario="separate"))
    rows.append(
        sgmr_row(value=20, rmRiskIndicator="EXPOSURE", limId="E", flatStrana='{"PC":"OTHER"}')
    )
    rows.append(
        sgmr_row(value=20, rmRiskIndicator="STRESS TEST", limId="S", limType="RELATIVE_THRESHOLD")
    )
    source = write_sgmr(tmp_path / "risk.parquet", rows)
    run_risk_metrics_analysis(source, output_dir=tmp_path / "reports")
    assert len(captured_charts) == 4
    main = next(
        item
        for item in captured_charts
        if item.scope["limId"] == "LIMIT-A" and not item.scope["consoSttScenario"]
    )
    np.testing.assert_equal(trace(main, "Observed risk").get_ydata(), [8, np.nan, np.nan])
    other = family(captured_charts, "highlighted_risk")[0]
    assert other.scope["rmRiskIndicator"] == "EXPOSURE"
    stress = family(captured_charts, "stress")[0]
    assert all(item.get_label() != "Breach" for axis in stress.figure.axes for item in axis.lines)
    assert len(stress.figure.axes) == 1
    assert all("bound" not in item.get_label().lower() for item in stress.figure.axes[0].lines)


def test_risk_charts_keep_all_supplied_dates_for_shorter_series(tmp_path, captured_charts):
    """Every series uses the full SGMR calendar, retaining leading and trailing gaps."""
    dates = [date(2025, 1, day) for day in (1, 3, 5)]
    rows = [sgmr_row(day, value) for day, value in zip(dates, (1, 2, 3), strict=True)]
    rows.append(sgmr_row(dates[1], 12, limId="SHORT", id="short-row"))
    source = write_sgmr(tmp_path / "risk.parquet", rows)

    run_risk_metrics_analysis(source, output_dir=tmp_path / "reports")

    try:
        assert len(captured_charts) == 2
        assert all(chart.dates == dates for chart in captured_charts)
        short = next(chart for chart in captured_charts if chart.scope["limId"] == "SHORT")
        np.testing.assert_equal(trace(short, "Observed risk").get_xdata(), dates)
        np.testing.assert_equal(trace(short, "Observed risk").get_ydata(), [np.nan, 12, np.nan])
        manifest = json.loads(
            next((tmp_path / "reports").glob("*/charts/manifest.json")).read_text(encoding="utf-8")
        )
        assert all(item["date_start"] == "2025-01-01" for item in manifest)
        assert all(item["date_end"] == "2025-01-05" for item in manifest)
    finally:
        for chart in captured_charts:
            chart.figure.clear()
            chart.figure.set_canvas(None)


def test_risk_movement_markers_retain_exact_series_identity(tmp_path, captured_charts):
    """Flag the movement endpoint only in its exact series, with no removed trend shading."""
    rows = sgmr_series([5.0] * 39 + [9.0], limMaxValue=1000)
    rows.extend(sgmr_series([1] * 40, limMaxValue=1000, consoSttScenario="other"))
    source = write_sgmr(tmp_path / "risk.parquet", rows)
    run_risk_metrics_analysis(source, output_dir=tmp_path / "reports")
    main = next(item for item in captured_charts if not item.scope["consoSttScenario"])
    finding = next(item for item in main.findings if item["check"] == "movement_outlier")
    assert 'id="ROW-2025-02-09"' in finding["source_locator"]
    assert list(trace(main, "Movement").get_xdata()) == [date(2025, 2, 9)]
    assert not main.figure.axes[0].patches
    other = next(item for item in captured_charts if item.scope["consoSttScenario"])
    assert all(item["check"] != "movement_outlier" for item in other.findings)


@pytest.mark.parametrize("kind", ["pnl", "risk"])
def test_render_failure_does_not_publish_partial_reports(tmp_path, monkeypatch, kind):
    def fail(figures, directory):
        directory.mkdir()
        (directory / "partial.png").write_bytes(b"partial")
        raise RuntimeError("synthetic render failure")

    monkeypatch.setattr(charts, "export_charts", fail)
    with pytest.raises(RuntimeError, match="synthetic render failure"):
        if kind == "pnl":
            paths, *_ = dataset(tmp_path / "input", n=2)
            run_pnl_analysis(**paths, output_dir=tmp_path / "reports")
        else:
            source = write_sgmr(tmp_path / "risk.parquet")
            run_risk_metrics_analysis(source, output_dir=tmp_path / "reports")
    assert list((tmp_path / "reports").iterdir()) == []


def test_real_headless_png_reports_and_source_integrity(tmp_path):
    """Both runners save real chart artifacts separately from their Markdown reports."""
    paths, *_ = dataset(tmp_path / "input", n=2)
    source = write_sgmr(tmp_path / "risk.parquet", sgmr_series([9, 12, -12]))
    inputs = [Path(path) for path in paths.values()] + [source]
    before = {path: hashlib.sha256(path.read_bytes()).digest() for path in inputs}
    run_pnl_analysis(**paths, output_dir=tmp_path / "pnl")
    run_risk_metrics_analysis(source, output_dir=tmp_path / "risk")
    for name in ("pnl", "risk"):
        report = next((tmp_path / name).glob("*/*.md"))
        manifest = json.loads((report.parent / "charts/manifest.json").read_text(encoding="utf-8"))
        assert manifest
        for record in manifest:
            png = (report.parent / "charts" / record["file"]).read_bytes()
            assert png[:8] == b"\x89PNG\r\n\x1a\n"
            width, height = struct.unpack(">II", png[16:24])
            assert width == 2800 and height >= 1200
            assert record["source_locators"]
        report_text = report.read_text(encoding="utf-8")
        assert "## Visualizations" not in report_text
        assert "charts/" not in report_text and "![" not in report_text
        assert (report.parent / "charts/index.md").is_file()
        if name == "pnl":
            assert {record["family"] for record in manifest} == {"pnl_daily"}
        assert report.with_suffix(".xlsx").is_file()
    assert all(hashlib.sha256(path.read_bytes()).digest() == before[path] for path in inputs)


@pytest.mark.asyncio
async def test_export_from_active_loop_is_lazy_and_clears_figures(tmp_path):
    first, second = sample_chart(), sample_chart()

    def figures():
        yield first
        assert not first.figure.axes
        yield second

    records = charts.export_charts(figures(), tmp_path / "charts")
    assert len(records) == 2
    assert not second.figure.axes
    assert first.figure.canvas is second.figure.canvas is None
    assert (tmp_path / "charts" / records[0]["file"]).read_bytes().startswith(b"\x89PNG")


def test_export_failure_clears_figure_and_does_not_advance(tmp_path, monkeypatch):
    first = sample_chart()

    def figures():
        yield first
        pytest.fail("Rendering must stop at the first failure")

    def fail(*args, **kwargs):
        raise RuntimeError("synthetic Agg failure")

    monkeypatch.setattr(charts.FigureCanvasAgg, "print_png", fail)
    with pytest.raises(RuntimeError, match="synthetic Agg failure"):
        charts.export_charts(figures(), tmp_path / "charts")
    assert not first.figure.axes
    assert first.figure.canvas is None
    assert not (tmp_path / "charts/index.md").exists()


def test_concurrent_exports_have_independent_artifacts(tmp_path):
    def export(index):
        def figures():
            yield sample_chart()

        directory = tmp_path / str(index)
        records = charts.export_charts(figures(), directory)
        assert records[0]["file"] == "chart-0001.png"
        return (directory / records[0]["file"]).read_bytes()

    with ThreadPoolExecutor(max_workers=2) as pool:
        images = list(pool.map(export, range(2)))
    assert all(image.startswith(b"\x89PNG") for image in images)


def test_save_failure_releases_rendered_buffer_with_retained_exception(tmp_path, monkeypatch):
    chart = sample_chart()
    tracked = {}
    print_png = charts.FigureCanvasAgg.print_png

    def invalid_destination(canvas, filename):
        tracked["canvas"] = weakref.ref(canvas)
        try:
            # Draw normally, then fail when Pillow tries to save into a directory.
            print_png(canvas, Path(filename).parent)
        finally:
            tracked["renderer"] = weakref.ref(canvas.renderer)

    monkeypatch.setattr(charts.FigureCanvasAgg, "print_png", invalid_destination)
    with pytest.raises(OSError) as failure:
        charts.export_charts(iter([chart]), tmp_path / "charts")
    assert failure.value.__traceback__ is not None
    assert not chart.figure.axes
    assert chart.figure.canvas is None
    gc.collect()
    assert tracked["canvas"]() is None
    assert tracked["renderer"]() is None


@pytest.mark.parametrize("days", [[date(2026, 1, 1)], [date(2026, 1, 1), date(2026, 1, 2)]])
def test_short_date_windows_do_not_repeat_labels_or_invent_subdaily_ticks(days):
    figure = Figure()
    axis = figure.subplots()
    axis.plot(days, charts.numeric_values([None] * len(days)))
    charts.date_axes(figure, days)
    ticks = axis.get_xticks()
    labels = [axis.xaxis.get_major_formatter()(value) for value in ticks]
    assert len(labels) == len(set(labels)) == len(days)
    assert all(value == int(value) for value in ticks)
    figure.clear()


@pytest.mark.parametrize("failures", [1, 4])
def test_windows_publication_retry_is_bounded(tmp_path, monkeypatch, failures):
    original = Path.rename
    attempts, waits = [], []

    def rename(source, destination):
        attempts.append(source)
        if len(attempts) <= failures:
            error = PermissionError("synthetic Windows lock")
            error.winerror = 32
            raise error
        return original(source, destination)

    monkeypatch.setattr(Path, "rename", rename)
    monkeypatch.setattr(charts.time, "sleep", waits.append)

    def publish():
        with charts.staged_run(tmp_path) as (stage, destination):
            (stage / "report.md").write_text("complete")
        return destination

    if failures == 4:
        with pytest.raises(PermissionError, match="synthetic Windows lock"):
            publish()
        assert list(tmp_path.iterdir()) == []
        assert len(attempts) == 4
    else:
        assert (publish() / "report.md").read_text() == "complete"
        assert len(attempts) == 2
    assert len(waits) == min(failures, 3)
