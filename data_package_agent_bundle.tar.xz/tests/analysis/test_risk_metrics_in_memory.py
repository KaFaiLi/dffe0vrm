"""Exercise owned numerical reviews and their file/report interfaces."""

import csv
import re
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from pathlib import Path
from zipfile import ZipFile

import openpyxl
import polars as pl
import pytest
from polars.testing import assert_frame_equal

from mcp_agent_template.analysis.risk_metrics import (
    analyze_tables,
    run_risk_metrics_analysis,
    runners,
)
from mcp_agent_template.analysis.risk_metrics.charts import risk_charts
from mcp_agent_template.analysis.risk_metrics.export import export_workbook
from mcp_agent_template.analysis.risk_metrics.models import Review
from mcp_agent_template.analysis.risk_metrics.report import markdown_report
from tests.analysis.risk_support import (
    excess_row,
    sgmr_row,
    sgmr_series,
    write_excesses,
    write_sgmr,
)

pytestmark = pytest.mark.usefixtures("without_png_rendering")


def test_in_memory_matches_file_evidence_and_saved_reports(tmp_path, monkeypatch):
    """Both entry points retain raw CSV values, ordered disclosures and complete tables."""
    rows = sgmr_series([10, 10.25, -10, -10.25, None, 0, 9, 9, 9])
    rows += [rows[0].copy(), {**rows[2], "consoValue": -13}]
    rows += [
        sgmr_row(id="REPEATED", consoValueDate="bad", limRelativeThreshold=None),
        sgmr_row(id="REPEATED", consoVersion=2),
    ]
    sgmr = write_sgmr(tmp_path / "risk.parquet", rows)
    first = excess_row(excessId="A", sgmrId="ROW-2025-01-02")
    csv_path = write_excesses(
        tmp_path / "events.csv",
        [first, first.copy(), excess_row(excessId="B"), excess_row(excessId="B", usage="bad")],
    )
    # CSV supplies literal strings, including empty fields; preserve that source representation.
    with csv_path.open(newline="", encoding="utf-8") as stream:
        events = pl.DataFrame(list(csv.DictReader(stream)))
    result = analyze_tables(
        pl.read_parquet(sgmr), events, sgmr_name=str(sgmr), colibris_name=str(csv_path)
    )
    captured = []

    def capture(review, path):
        """Retain the actual runner result while writing its real workbook."""
        captured.append(review)
        export_workbook(review, path)

    monkeypatch.setattr(runners, "export_workbook", capture)
    saved_text = run_risk_metrics_analysis(sgmr, csv_path, output_dir=tmp_path / "reports")
    assert asdict(result) == asdict(captured[0])
    file_workbook = next((tmp_path / "reports").glob("*/*.xlsx"))
    memory_workbook = tmp_path / "memory.xlsx"
    export_workbook(result, memory_workbook)
    with ZipFile(file_workbook) as file_zip, ZipFile(memory_workbook) as memory_zip:
        assert file_zip.namelist() == memory_zip.namelist()
        # Only workbook creation/modified timestamps are outside the report contract.
        for name in file_zip.namelist():
            contents = [archive.read(name) for archive in (file_zip, memory_zip)]
            if name == "docProps/core.xml":
                timestamps = rb"(<dcterms:(created|modified)\b[^>]*>).*?(</dcterms:\2>)"
                contents = [re.sub(timestamps, rb"\1TIMESTAMP\3", value) for value in contents]
            assert contents[0] == contents[1], name
    assert markdown_report(result, file_workbook, file_workbook.with_suffix(".md")) == (
        markdown_report(captured[0], file_workbook, file_workbook.with_suffix(".md"))
    )
    assert saved_text == file_workbook.with_suffix(".md").read_text(encoding="utf-8")


@pytest.mark.parametrize("object_metadata", [False, True])
def test_analysis_is_owned_repeatable_and_needs_no_io(tmp_path, monkeypatch, object_metadata):
    """Nested source values and observations belong to each result, never the input frame."""
    frame = pl.DataFrame([sgmr_row(metadata={"tags": ["original"]})])
    if object_metadata:
        frame = frame.with_columns(pl.Series("metadata", [{"tags": ["original"]}], dtype=pl.Object))
    events = pl.DataFrame([excess_row()])
    original, original_events = frame.clone(), events.clone()

    def unexpected(*args, **kwargs):
        """Fail if numerical analysis attempts settings, source reads or report writes."""
        pytest.fail("In-memory analysis must not access settings or files")

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(runners, "get_settings", unexpected)
    monkeypatch.setattr(Path, "read_bytes", unexpected)
    monkeypatch.setattr(Path, "write_text", unexpected)
    monkeypatch.setattr(runners, "export_workbook", unexpected)
    result = analyze_tables(frame, events)
    repeated = analyze_tables(frame, events)
    assert isinstance(result, Review)
    assert asdict(result) == asdict(repeated)
    assert result.reference_date == date(2025, 1, 1)
    assert result.observations[0].record is result.sources[0].records[0]
    result.observations[0].record.raw["metadata"]["tags"].append("changed")
    result.candidates.clear()
    result.sources[1].records[0].raw["excessId"] = "changed"
    assert repeated.sources[0].records[0].raw["metadata"]["tags"] == ["original"]
    assert repeated.sources[1].records[0].raw["excessId"] == "EVENT-A"
    assert frame["metadata"].to_list() == [{"tags": ["original"]}]
    assert frame.schema == original.schema
    assert_frame_equal(frame.drop("metadata"), original.drop("metadata"))
    assert_frame_equal(events, original_events)
    assert list(tmp_path.iterdir()) == []


def test_renderers_preserve_result_and_complete_workbook_evidence(tmp_path):
    """Current writers preserve the result, literal formulas and long source evidence."""
    result = analyze_tables(pl.DataFrame([sgmr_row(consoComment="=SUM(A1:A2)" + "x" * 65000)]))
    before = deepcopy(result)
    direct = tmp_path / "direct.xlsx"
    assert export_workbook(result, direct) is None
    report = markdown_report(result, direct, tmp_path / "review.md")
    assert report.startswith("# Risk Metrics")
    assert "## Executive observations" not in report
    assert "## Scope and availability" not in report
    for chart in risk_charts(result.observations, result):
        chart.figure.clear()
    assert asdict(result) == asdict(before)
    workbook = openpyxl.load_workbook(direct)
    try:
        assert workbook.sheetnames == [
            "Summary",
            "Series Review",
            "Value Outliers",
            "Movement and Value Outliers",
            "Excess Review",
            "Review Candidates",
            "Data Quality",
            "SGMR Detail",
            "Sources and Methods",
        ]
        sheet = workbook["SGMR Detail"]
        columns = [cell.value for cell in sheet[1]]
        text_column = columns.index("raw:consoComment") + 1
        cells = [sheet.cell(row, text_column) for row in range(2, sheet.max_row + 1)]
        assert all(cell.data_type == "s" for cell in cells)
        assert "".join(cell.value for cell in cells) == "=SUM(A1:A2)" + "x" * 65000
        assert sheet.freeze_panes == "A2"
    finally:
        workbook.close()


def test_source_identity_duplicates_and_candidate_order():
    """Repeated IDs retain original ordinals; ties use row order rather than ID text."""
    rows = [
        sgmr_row(day=date(2025, 1, i), value=10.125, id="REPEATED", flatStrana='{"PC":"OTHER"}')
        for i in range(1, 12)
    ]
    rows.insert(1, rows[0].copy())
    result = analyze_tables(pl.DataFrame(rows), sgmr_name="supplied.parquet")
    assert result.sources[0].duplicate_rows == 1
    records = result.sources[0].records
    assert [r.ordinal for r in records] == [1, *range(3, 13)]
    assert records[0].duplicate_locators == ['supplied.parquet [id="REPEATED"; record=2]']
    conflicts = [r for r in result.candidates if r["check"] == "hierarchy_conflict"]
    assert [r["source_locator"] for r in conflicts] == [r.locator for r in records]
    assert result.observations[0].value == 10.125
    assert not hasattr(result.observations[0], "utilization")
    assert not hasattr(result.observations[0], "breach")


@pytest.mark.parametrize("missing", [False, True])
def test_report_identifiers_preserve_source_labels_and_missing_values(missing):
    """Metric/perimeter columns replace combined labels without inferring absent PC names."""
    metric, perimeter = (None, None) if missing else ("VaR source label", "Pc Source Label")
    result = analyze_tables(
        pl.DataFrame(
            [
                sgmr_row(
                    rmRiskMetricName=metric,
                    stranaPc=perimeter,
                    stranaNodeName="Different portfolio label",
                    stranaBu="CONFLICT",
                )
            ]
        ),
        pl.DataFrame(
            [
                excess_row(
                    riskMetricName=metric,
                    perimeterMnemonic=perimeter,
                    excessStillOpen=False,
                )
            ]
        ),
    )
    for rows in (result.series, result.detail, result.excesses, result.candidates):
        assert rows
        assert all("scope" not in row for row in rows)
        assert all(row["riskMetricName"] == metric for row in rows)
        assert all(row["perimeterMnemonic"] == perimeter for row in rows)
    report = markdown_report(result, Path("risk.xlsx"), Path("risk.md"))
    assert "| scope |" not in report
    assert "| riskMetricName | perimeterMnemonic |" in report
    assert "Different portfolio label" not in report


def test_shared_report_labels_do_not_merge_distinct_movement_populations():
    """Identical metric/perimeter display names keep separate limit-based z-score baselines."""
    rows = sgmr_series([5.0] * 11 + [10.0], limId="LIMIT-A")
    rows += sgmr_series([5.0] * 11 + [20.0], limId="LIMIT-B")
    result = analyze_tables(pl.DataFrame(rows))
    segments = [row for row in result.series if row["period"] == "movement segment"]
    assert len(segments) == 2
    assert {row["limId"] for row in segments} == {"LIMIT-A", "LIMIT-B"}
    assert all(row["movement_observations"] == 11 for row in segments)
    assert all(row["movement_outliers"] == 1 for row in segments)
    assert all(row["riskMetricName"] == "VAR-1D" for row in segments)
    assert all(row["perimeterMnemonic"] == "PC-A" for row in segments)


def test_reference_date_uses_all_valid_sgmr_dates_without_inventing_a_snapshot():
    """Conflicts still contribute dates; invalid dates do not create an artificial clock."""
    rows = [
        sgmr_row(day=date(2025, 1, 10), value=11),
        sgmr_row(day=date(2025, 1, 10), value=12),
        sgmr_row(consoValueDate="invalid"),
    ]
    result = analyze_tables(pl.DataFrame(rows), pl.DataFrame([excess_row()]))
    assert result.reference_date == date(2025, 1, 10)
    assert result.excesses[0]["calendar_age_days"] == 9
    assert all(item.conflict for item in result.observations[:2])
    assert result.observations[-1].day is None


@pytest.mark.parametrize("supplied", [False, True])
def test_omitted_and_supplied_empty_event_populations_stay_distinct(supplied):
    """An omitted event source stays unknown; a supplied header-only table has zero inputs."""
    events = pl.DataFrame(schema={"excessId": pl.String}) if supplied else None
    result = analyze_tables(pl.DataFrame(sgmr_series([5.0] * 20)), events)
    summary = {row["measure"]: row["value"] for row in result.summary}
    assert summary["Colibris input events"] == (0 if supplied else None)
    assert summary["Colibris recorded open events"] is None
    assert "Confirmed Colibris observation links" not in summary
    assert not hasattr(result, "reconciliation")
    assert result.excesses == []
    assert result.candidates == []


@pytest.mark.parametrize("condition", ["missing", "empty", "columns", "ambiguous", "name"])
def test_in_memory_input_validation(condition):
    """Required tables and column ambiguity use the existing preparation rules."""
    frame = pl.DataFrame([sgmr_row()])
    kwargs = {}
    if condition == "missing":
        frame = None
    elif condition == "empty":
        frame = frame.head(0)
    elif condition == "columns":
        frame = frame.drop("limId")
    elif condition == "ambiguous":
        frame = frame.with_columns(pl.lit("other").alias(" LIMID "))
    else:
        kwargs["sgmr_name"] = " "
    with pytest.raises(ValueError):
        analyze_tables(frame, **kwargs)
