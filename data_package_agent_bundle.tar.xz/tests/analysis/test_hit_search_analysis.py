"""Check source attribution arithmetic independently from report rendering."""

import openpyxl
import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

from mcp_agent_template.analysis.fox.hit_search_analysis import build_hit_search_summaries
from mcp_agent_template.analysis.fox.runners import run_fox_analysis
from tests.analysis.support import case_row, workbook_table, write_cases


def test_items_count_once_per_row_with_overlapping_items_and_repeated_case_ids(tmp_path):
    rows = [
        case_row(hit_search_items="Alpha, Alpha, Beta"),
        case_row(hit_search_items="Alpha,  Gamma   delta "),
        case_row(Case_Id="case-2", hit_search_items=None),
        case_row(
            Case_Id="case-3", final_decision="Justified", hit_search_items="Alpha, Only clean"
        ),
    ]
    source = write_cases(tmp_path / "input.parquet", rows)
    report = run_fox_analysis(source, output_dir=tmp_path / "reports")
    assert "Breach rows with hit-search items | 2 (66.7%)" in report
    assert "| Alpha | 3 | 2 | 66.7% | 66.7% |" in report
    assert "| Gamma delta | 1 | 1 | 33.3% | 100.0% |" in report
    (workbook,) = (tmp_path / "reports").glob("*/*.xlsx")
    saved = openpyxl.load_workbook(workbook)
    try:
        records = workbook_table(saved, "Hit Search Analysis", "FoxHitItems")
        items = {row["hit_search_item"]: row for row in records}
        assert set(items) == {"Alpha", "Beta", "Gamma delta"}
        assert items["Alpha"]["rows"] == 3
        assert items["Alpha"]["breach_rows"] == 2
        assert items["Alpha"]["share_of_breach_rows"] == pytest.approx(2 / 3)
        assert items["Alpha"]["breach_rate"] == pytest.approx(2 / 3)
        assert "hit_search_items" in workbook_table(saved, "Processed Data", "FoxProcessedData")[0]
        (summary,) = workbook_table(saved, "Hit Search Analysis", "FoxHitCoverage")
        assert summary["breach_rows"] == 3
        assert summary["breach_rows_with_items"] == 2
        assert summary["distinct_breach_items"] == 3
    finally:
        saved.close()


@pytest.mark.parametrize("decision", ["breach", "justified"])
def test_blank_items_and_zero_breaches_have_explicit_coverage(decision):
    frame = pd.DataFrame(
        {"decision_normalized": [decision] * 3, "hit_search_items": [None, "", " , "]}
    )
    summaries = build_hit_search_summaries(frame)
    summary = summaries["hit_search_summary"].iloc[0]
    assert summaries["hit_search_items"].empty
    assert summary["breach_rows_with_items"] == 0
    assert summary["distinct_breach_items"] == 0
    if decision == "breach":
        assert summary["breach_rows"] == 3
        assert summary["breach_item_coverage"] == 0
    else:
        assert summary["breach_rows"] == 0
        assert pd.isna(summary["breach_item_coverage"])


def test_duplicate_source_ids_do_not_merge_distinct_item_rows():
    """Attribution counts retained rows independently of any supplied identifier."""
    frame = pd.DataFrame(
        {
            "decision_normalized": ["breach", "breach"],
            "hit_search_items": ["Alpha, Alpha", "Alpha"],
            "Analysis_Row_ID": [99, 99],
        },
        index=[7, 7],
    )
    before = frame.copy(deep=True)
    summaries = build_hit_search_summaries(frame)
    coverage = summaries["hit_search_summary"].iloc[0]
    item = summaries["hit_search_items"].iloc[0]
    assert coverage["breach_rows_with_items"] == 2
    assert coverage["breach_item_coverage"] == 1.0
    assert item["rows"] == item["breach_rows"] == 2
    assert_frame_equal(frame, before)
