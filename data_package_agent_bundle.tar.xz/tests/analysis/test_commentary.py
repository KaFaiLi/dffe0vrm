"""Commentary handoff preserves complete source Markdown without interpreting it."""

from pathlib import Path

import pytest

from mcp_agent_template.analysis.pnl.commentary import commentary_analysis


def test_commentary_loader_is_standalone_and_preserves_both_documents(tmp_path):
    documents = {
        "pnl": (
            "# PnL commentary\n\n## Earlier quarter\n\n"
            "Unparsed narrative with € and **formatting**.\n"
        ),
        "attribution": (
            "# Attribution commentary\n\n"
            + "| Factor | Note |\n| --- | --- |\n| A | Original text |\n"
        ),
    }
    paths = {family: tmp_path / f"{family}.md" for family in documents}
    for family, path in paths.items():
        path.write_text(documents[family], encoding="utf-8")

    sources = commentary_analysis(paths)

    assert sources == [
        {"family": family, "path": str(path.resolve()), "markdown": documents[family]}
        for family, path in paths.items()
    ]
    assert all(
        Path(source["path"]).read_text(encoding="utf-8") == source["markdown"] for source in sources
    )


@pytest.mark.parametrize("filename", ["missing.md", "commentary.txt"])
def test_commentary_requires_an_existing_markdown_file(tmp_path, filename):
    path = tmp_path / filename
    if path.suffix == ".txt":
        path.write_text("Original text", encoding="utf-8")

    with pytest.raises(ValueError, match="existing Markdown file"):
        commentary_analysis({"pnl": path})
