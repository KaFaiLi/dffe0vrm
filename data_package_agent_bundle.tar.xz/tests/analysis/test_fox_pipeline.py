"""Verify in-memory reviews and current report interfaces."""

from copy import deepcopy

import openpyxl
import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

from mcp_agent_template.analysis.fox.export import write_workbook
from mcp_agent_template.analysis.fox.markdown_report import (
    render_markdown,
)
from mcp_agent_template.analysis.fox.runners import analyze_cases
from tests.analysis.support import case_row, workbook_table

SNAPSHOT = pd.Timestamp("2026-10-19 12:34:56")


@pytest.mark.parametrize(
    "comment", ["=literal " + "Long comment. " * 4000, "before\x01after"], ids=["long", "control"]
)
def test_workbook_preserves_comment_text_and_one_row_per_case(tmp_path, comment):
    """Long text has complete linked evidence; XML controls are visibly escaped."""
    result = analyze_cases(
        pd.DataFrame(
            [
                case_row(Case_Id="long", historic_comments_markdown=comment),
                case_row(Case_Id="short", historic_comments_markdown="=literal short comment"),
            ]
        ),
        snapshot_at=SNAPSHOT,
    )
    before = result.cases.copy(deep=True)
    path = tmp_path / "comments.xlsx"
    write_workbook(result, path, input_file="synthetic.parquet")
    book = openpyxl.load_workbook(path)
    try:
        cases = workbook_table(book, "Processed Data", "FoxProcessedData")
        assert len(cases) == 2
        by_id = {row["Case_Id"]: row for row in cases}
        expected = comment.replace("\x01", "\\u0001")
        if len(expected) > 32767:
            assert "Text Evidence" in book.sheetnames
            assert "Text Evidence" in by_id["long"]["historic_comments_markdown"]
            parts = workbook_table(book, "Text Evidence", "FoxTextEvidence")
            parts = [
                row
                for row in parts
                if row["source_table"] == "FoxProcessedData"
                and row["source_column"] == "historic_comments_markdown"
            ]
            assert len(parts) > 1
            assert "".join(row["text"] for row in parts) == expected
            assert {row["Analysis_Row_ID"] for row in parts} == {by_id["long"]["Analysis_Row_ID"]}
            assert len({row["source_row"] for row in parts}) == 1
        else:
            assert by_id["long"]["historic_comments_markdown"] == expected
            assert "Text Evidence" not in book.sheetnames
        assert by_id["short"]["historic_comments_markdown"] == "=literal short comment"
        assert all(cell.data_type != "f" for sheet in book for row in sheet for cell in row)
    finally:
        book.close()
    assert_frame_equal(result.cases, before)


def test_analysis_preserves_input_and_preparation_order_with_duplicate_ids():
    """Pruning precedes deduplication, while IDs distinguish conflicting records."""
    first = case_row(historic_comments_count=1, unused_sparse="only difference")
    rows = [first, {**first, "unused_sparse": None}]
    rows += [case_row(Case_Id=f"case-{i}") for i in range(2, 5)]
    rows += [case_row(Case_Id="case-1", final_decision="Justified", closure_date="2025-01-02")]
    frame = pd.DataFrame(rows, index=[9, 9, 4, 8, 1, 2])
    original = frame.copy(deep=True)
    result = analyze_cases(frame, snapshot_at=SNAPSHOT)
    assert_frame_equal(frame, original)
    assert result.source_row_count == 6
    assert len(result.cases) == 5
    assert result.cases["Analysis_Row_ID"].tolist() == list(range(1, 6))
    assert result.cases["Case_Id"].tolist().count("case-1") == 2
    assert set(result.duplicate_details["Column"]) == {
        "historic_comments_count",
        "final_decision",
        "closure_date",
    }
    assert "unused_sparse" not in result.cases
    assert result.snapshot_at == SNAPSHOT


def test_fixed_snapshot_preserves_additive_rules_and_overlapping_queues():
    """Multiple workflow messages score once; negative age still scores separately."""
    rows = [
        case_row(Case_Id="workflow", final_decision=None, closure_date=None),
        case_row(
            Case_Id="negative",
            control_execution_date="2025-01-02",
            closure_date="2025-01-01",
            historic_comments_count=0,
        ),
        case_row(
            Case_Id="unknown",
            status="Processing",
            final_decision=None,
            control_execution_date=None,
            historic_comments_count=None,
        ),
    ]
    rows += [
        case_row(
            Case_Id=f"age-{age}",
            status="Processing",
            final_decision=None,
            control_execution_date=SNAPSHOT - pd.Timedelta(days=age),
        )
        for age in [30, 30.5, 90, 90.5]
    ]
    # Consistent datetime values avoid changing pandas' existing mixed-string parser.
    frame = pd.DataFrame(rows)
    frame["control_execution_date"] = pd.to_datetime(frame["control_execution_date"])
    result = analyze_cases(frame, snapshot_at=SNAPSHOT)
    scores = result.cases.set_index("Case_Id")["audit_risk_score"].to_dict()
    assert scores == {
        "workflow": 3,
        "negative": 14,
        "unknown": 0,
        "age-30": 0,
        "age-30.5": 3,
        "age-90": 3,
        "age-90.5": 4,
    }
    assert set(result.manual_review["Case_Id"]) == {"workflow", "negative", "age-90.5"}
    assert set(result.priority_cases["Case_Id"]) == {
        "workflow",
        "negative",
        "age-30.5",
        "age-90",
        "age-90.5",
    }
    unknown = result.cases.set_index("Case_Id").loc["unknown"]
    assert pd.isna(unknown["case_age_days"])
    assert not unknown["completed_without_comments_derived"]


def test_reports_and_queue_order_survive_reindexing_without_mutation(tmp_path):
    """Stored queue snapshots retain both orders and renderers leave results intact."""
    result = analyze_cases(
        pd.DataFrame(
            [
                case_row(control_logical_code="Z"),
                case_row(control_logical_code="A"),
                case_row(
                    status="Processing", final_decision=None, control_execution_date="2026-10-18"
                ),
            ]
        ),
        snapshot_at=SNAPSHOT,
    )
    workbook = tmp_path / "report.xlsx"
    markdown = tmp_path / "report.md"
    expected = render_markdown(result, "input.parquet", workbook, markdown)
    priority_ids = result.priority_cases["Analysis_Row_ID"].tolist()
    manual_ids = result.manual_review["Analysis_Row_ID"].tolist()
    result.cases = result.cases.iloc[::-1].reset_index(drop=True)
    before = deepcopy(result)
    assert result.priority_cases["Analysis_Row_ID"].tolist() == priority_ids
    assert result.manual_review["Analysis_Row_ID"].tolist() == manual_ids
    assert render_markdown(result, "input.parquet", workbook, markdown) == expected
    write_workbook(result, workbook, input_file="input.parquet")
    assert_frame_equal(result.cases, before.cases)
    assert_frame_equal(result.duplicate_details, before.duplicate_details)
    assert_frame_equal(result.priority_cases, before.priority_cases)
    assert_frame_equal(result.manual_review, before.manual_review)
    for key in result.summaries:
        assert_frame_equal(result.summaries[key], before.summaries[key])
    saved = openpyxl.load_workbook(workbook)
    try:
        cases = workbook_table(saved, "Processed Data", "FoxProcessedData")
        assert {row["Analysis_Row_ID"] for row in cases if row["in_priority_queue"]} == set(
            priority_ids
        )
        assert {row["Analysis_Row_ID"] for row in cases if row["in_manual_review"]} == set(
            manual_ids
        )
        population = workbook_table(saved, "Overview", "FoxPopulation")
        assert {row["Metric"]: row["Value"] for row in population}["Analyzed rows"] == 3
    finally:
        saved.close()


@pytest.mark.parametrize("snapshot", [None, pd.NaT])
def test_in_memory_analysis_requires_a_known_snapshot(snapshot):
    """Unknown explicit snapshots cannot silently read the clock or hide missing ages."""
    with pytest.raises(ValueError, match="snapshot_at must be a valid"):
        analyze_cases(pd.DataFrame([case_row()]), snapshot_at=snapshot)
