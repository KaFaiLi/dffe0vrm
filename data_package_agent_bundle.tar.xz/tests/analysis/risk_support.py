"""Small synthetic risk files; independent of development helpers and credentials."""

import csv
from datetime import date, timedelta

import polars as pl


def sgmr_row(day=date(2025, 1, 1), value=5.0, **overrides):
    result = {
        "limId": "LIMIT-A",
        "stranaNodeName": "PORTFOLIO-A",
        "stranaPc": "PC-A",
        "stranaBu": "DESK-A",
        "rmRiskIndicator": "VAR",
        "rmRiskMetricName": "VAR-1D",
        "limUnit": "MEUR",
        "limType": "ABSOLUTE_THRESHOLD",
        "limMinValue": -10.0,
        "limMaxValue": 10.0,
        "limInitialMinValue": -10.0,
        "limInitialMaxValue": 10.0,
        "limStartDate": "2025-01-01",
        "limEndDate": "2025-12-31",
        "limFrequency": "Daily",
        "limRelativeThreshold": 0.9,
        "consoValue": value,
        "consoValueDate": str(day),
        "consoVersion": 1,
        "consoId": f"CONSO-{day}",
        "id": f"ROW-{day}",
        "consoOfficialStampIndic": "N",
        "flatStrana": '{"BU":"DESK-A","PC":"PC-A"}',
    }
    result.update(overrides)
    return result


def sgmr_series(values, **overrides):
    return [
        sgmr_row(date(2025, 1, 1) + timedelta(days=i), value, **overrides)
        for i, value in enumerate(values)
    ]


def excess_row(**overrides):
    result = {
        "excessId": "EVENT-A",
        "sgmrId": "NO-MATCH",
        "perimeterMnemonic": "PC-A",
        "riskIndicator": "VAR",
        "riskMetricName": "VAR-1D",
        "unit": "MEUR",
        "limitType": "ABSOLUTE_THRESHOLD",
        "limitValue": 10.0,
        "excessLastConsoValue": 11.0,
        "excessLastConsoValueDate": "2025-01-01",
        "usage": "110%",
        "excessMaxUsage": 110,
        "excessStillOpen": True,
        "excessWorkflowStatus": "OPEN",
        "excessCreationDate": "2025-01-01",
        "excessCloseDate": None,
        "lastExcessExplanationCreationDate": "2025-01-02",
        "lastExcessExplanationCause": "Market prices",
        "lastExcessExplanationActionPlan": "Review hedges",
        "lastExcessExplanationDeadline": "2025-01-03",
        "lastExcessValidationCreationDate": "2025-01-03",
        "lastExcessValidationIsSatisfactory": True,
    }
    result.update(overrides)
    return result


def write_sgmr(path, rows=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(
        rows if rows is not None else [sgmr_row()], infer_schema_length=None
    ).write_parquet(path)
    return path


def write_excesses(path, rows=None):
    rows = rows if rows is not None else [excess_row()]
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
    return path


def comment_record(
    evidence_id="review:1",
    validation="pending",
    note="Movement explained.",
    metric="VAR",
    desk="DESK-A",
    perimeter="PC-A",
):
    return (
        f"#### Record {evidence_id}\n"
        f"- Event date 2025-01-01; desk {desk}; perimeter {perimeter}; metric {metric}.\n"
        f"- Review note: {note}\n"
        f"- Managerial validation: {validation}.\n"
        f'- Source record: "Evidence ID: {evidence_id} Source: var_svar Desk: {desk} '
        f"Perimeter: {perimeter} Metric: {metric} Error Message: movement threshold exceeded "
        f"Comment: {note} Managerial Validation Comment: {validation} "
        'Related Scenario: rates +100bp"\n'
    )


def write_comment(path, text=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        text if text is not None else "# Commentary\n\n## Quarter: 2025Q1\n" + comment_record(),
        encoding="utf-8",
    )
    return path
