"""Keep run units, missing-driver coverage and original columns in saved evidence."""

from pathlib import Path

import pytest

from mcp_agent_template.analysis.pnl.loading import load_table
from tests.analysis.pnl_support import dataset, save_pnl, write_csv
from tests.analysis.test_pnl_analysis import run

pytestmark = pytest.mark.usefixtures("without_png_rendering")


def test_workbook_retains_run_currency_and_notion_once(tmp_path):
    """The workbook identifies PnL amounts without depending on its sibling Markdown."""
    paths, pnl, *_ = dataset(tmp_path / "input", n=3)
    for row in pnl:
        row.update(Notion="Synthetic notion")
    save_pnl(paths["pnl_path"], pnl)

    report, tables = run(paths, tmp_path)

    assert tables["PnL scope"] == [{"Notion": "Synthetic notion", "Currency": "EUR"}]
    assert "Currency: EUR" in report
    assert "Notion: Synthetic notion" in report
    assert all("Currency" not in row and "Notion" not in row for row in tables["PnL daily"])


def test_entirely_missing_driver_retains_unknown_coverage(tmp_path):
    """An all-blank driver remains unknown for every supplied PC date, never absent."""
    paths, _, attribution, *_ = dataset(tmp_path / "input", n=3)
    for row in attribution:
        row["Missing daily driver"] = ""
    write_csv(Path(paths["income_attribution_path"]), attribution)

    report, tables = run(paths, tmp_path)

    evidence = [
        row for row in tables["Attribution daily"] if row["driver"] == "Missing daily driver"
    ]
    assert len(evidence) == 3
    assert all(row["outlier screen"] == "unavailable (no known values)" for row in evidence)
    assert all(
        row["amount"] is None
        for row in tables["Attribution daily"]
        if row["driver"] == "Missing daily driver"
    )
    assert "Missing daily driver" not in report
    assert "check screen availability in the workbook" in report


def test_blank_adjustment_and_validation_columns_remain_in_evidence(tmp_path):
    """Complete source records distinguish supplied blank columns from omitted columns."""
    paths, _, _, adjustments, history = dataset(tmp_path / "input", n=3)
    for row in adjustments:
        row["Review comment"] = ""
    for row in history:
        row["Approval reference"] = ""
    write_csv(Path(paths["adjustments_path"]), adjustments)
    write_csv(Path(paths["validation_history_path"]), history)

    _, tables = run(paths, tmp_path)

    assert all(row["Review comment"] is None for row in tables["All adjustments"])
    assert all(row["Approval reference"] is None for row in tables["Validation records"])


@pytest.mark.parametrize("suffix", [".csv", ".xlsx"])
@pytest.mark.parametrize("version", ["absent", "blank", "varying"])
def test_pnl_aliases_and_optional_metadata_preserve_all_dates(tmp_path, suffix, version):
    """Both formats accept date/version aliases and absent PTF without splitting PC series."""
    paths, pnl, *_ = dataset(tmp_path / "input", n=3)
    for index, row in enumerate(pnl):
        row["ValuationDate"] = row.pop("Value Date")
        del row["Version"]
        del row["PTF"]
        row["Blank source metadata"] = ""
        if version != "absent":
            row["versiontype"] = "" if version == "blank" else ("FLASH", "", "STAB")[index]
    source = Path(paths["pnl_path"]).with_suffix(suffix)
    paths["pnl_path"] = str(source)
    if suffix == ".csv":
        write_csv(source, pnl)
    else:
        save_pnl(source, pnl)

    loaded = load_table(source, "pnl")
    _, tables = run(paths, tmp_path)

    assert len(loaded) == 3
    assert all("Value Date" in row and "ValuationDate" not in row for row in loaded)
    assert all("Blank source metadata" in row for row in loaded)
    assert all(("Version" in row) == (version == "varying") for row in loaded)
    assert len(tables["PnL daily"]) == 3
    assert tables["PnL series"][0]["observations"] == 3
    assert not tables["Exceptions"]
