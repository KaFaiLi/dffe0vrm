"""Behavioral regressions through the public file-to-report runner."""

from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from statistics import fmean, pstdev

import openpyxl
import polars as pl
import pytest

from mcp_agent_template.analysis.risk_metrics import run_risk_metrics_analysis
from tests.analysis.risk_support import (
    comment_record,
    excess_row,
    sgmr_row,
    sgmr_series,
    write_comment,
    write_excesses,
    write_sgmr,
)

pytestmark = pytest.mark.usefixtures("without_png_rendering")


def read_tables(path):
    workbook = openpyxl.load_workbook(path, read_only=True, data_only=False)
    try:
        tables = {}
        for sheet in workbook:
            iterator = sheet.iter_rows(values_only=True)
            headers = next(iterator)
            tables[sheet.title] = [dict(zip(headers, values, strict=True)) for values in iterator]
        return tables
    finally:
        workbook.close()


def run(tmp_path, rows=None, excesses=None, comments=None):
    sgmr = write_sgmr(tmp_path / "input.parquet", rows)
    csv = write_excesses(tmp_path / "events.csv", excesses) if excesses is not None else None
    markdown = write_comment(tmp_path / "notes.md", comments) if comments is not None else None
    report = run_risk_metrics_analysis(sgmr, csv, markdown, output_dir=tmp_path / "reports")
    workbook = next((tmp_path / "reports").glob("*/*.xlsx"))
    return report, read_tables(workbook)


def candidates(tables):
    return {row.get("check") for row in tables["Review Candidates"]}


def summary(tables):
    return {row["measure"]: row["value"] for row in tables["Summary"]}


def test_complete_reports_preserve_sources_and_return_saved_markdown(tmp_path):
    """Keep full evidence in Excel while saved/returned Markdown omits inventories and charts."""
    sgmr = write_sgmr(tmp_path / "input.parquet", [sgmr_row(value=11)])
    csv = write_excesses(tmp_path / "events.csv")
    notes = [
        write_comment(
            tmp_path / f"notes-{i}.md", "## Quarter: 2025Q1\n" + comment_record(f"review:{i}")
        )
        for i in range(3)
    ]
    before = {path: path.read_bytes() for path in [sgmr, csv, *notes]}
    report = run_risk_metrics_analysis(sgmr, csv, *notes, output_dir=tmp_path / "reports")
    workbook = next((tmp_path / "reports").glob("*/*.xlsx"))
    assert workbook.with_suffix(".md").read_text(encoding="utf-8") == report
    assert all(path.read_bytes() == original for path, original in before.items())
    tables = read_tables(workbook)
    assert len(tables) == 9
    assert summary(tables)["SGMR analyzed observations"] == 1
    assert all(path.read_text(encoding="utf-8") in report for path in notes)
    assert not any("Commentary" in key for key in summary(tables))
    assert "Commentary Review" not in tables
    assert summary(tables)["Colibris recorded open events"] == 1
    assert "Reconciliation" not in tables
    assert "Confirmed Colibris observation links" not in summary(tables)
    assert "## Cross-source reconciliation" not in report
    assert "sha256" not in report and "hash" not in report.lower()
    assert all("sha256" not in row for rows in tables.values() for row in rows)
    assert tables["SGMR Detail"][0]["source_locator"] == 'input.parquet [id="ROW-2025-01-01"]'
    assert tables["Excess Review"][0]["source_locator"] == 'events.csv [excessId="EVENT-A"]'
    assert all("scope" not in row for rows in tables.values() for row in rows)
    for title in ("Series Review", "Excess Review", "SGMR Detail"):
        assert tables[title][0]["riskMetricName"] == "VAR-1D"
        assert tables[title][0]["perimeterMnemonic"] == "PC-A"
    assert "| scope |" not in report
    assert "| excessId | riskMetricName | perimeterMnemonic |" in report
    assert "## Scope and availability" not in report
    assert "| role | path | input_records | duplicates_removed |" not in report
    assert "usable_records_for_all_listed_fields" not in report
    assert "## Visualizations" not in report and "![" not in report
    assert "charts/" not in report
    assert report.startswith("# Risk Metrics Analysis\n\n## Metric movements\n")
    assert "## Limit consumption" not in report
    assert "## Executive observations" not in report
    assert "## Prioritized follow-up" not in report
    assert "## Metric value outliers" in report
    assert "## Days with movement and value outliers" in report
    assert "Review coverage:" not in report
    assert "| SGMR input observations |" not in report
    excess_section = report.split("## Excess governance\n", 1)[1].split("\n## ", 1)[0]
    assert "excessId" in excess_section and "EVENT-A" in excess_section
    assert "source_locator" not in excess_section and "reperformed_usage" not in excess_section
    assert tables["Excess Review"][0]["reperformed_usage"] == pytest.approx(1.1)
    assert "## Methods and limitations" not in report
    assert "**Movements.**" not in report
    assert any(row.get("name") == "Movements" for row in tables["Sources and Methods"])
    methods = tables["Sources and Methods"]
    assert {row["name"] for row in methods if row["kind"] == "source"} == {
        "sgmr",
        "colibris",
        "risk_metrics_commentary",
        "stress_test_commentary",
        "var_svar_commentary",
    }
    assert any(row["kind"] == "availability" for row in methods)


@pytest.mark.parametrize(
    "value,lower,upper",
    [
        (12, -10, 10),
        (-12, -10, 10),
        (5, -10, 0),
        (None, -10, 10),
    ],
)
def test_consumption_fields_checks_and_counts_are_removed(tmp_path, value, lower, upper):
    """Source bounds remain raw evidence without generating utilization or consumption flags."""
    report, tables = run(tmp_path, [sgmr_row(value=value, limMinValue=lower, limMaxValue=upper)])
    detail = tables["SGMR Detail"][0]
    assert detail["raw:limMinValue"] == lower and detail["raw:limMaxValue"] == upper
    removed_fields = {
        "utilization",
        "absolute_bound_exceedance",
        "warning_threshold",
        "warning_default",
        "absolute_limit_denominator",
        "bound_exceedances",
        "warning_observations",
        "max_utilization",
        "mean_utilization",
        "valid_utilizations",
        "warning_default_rows",
    }
    assert all(
        not removed_fields & row.keys() for row in tables["SGMR Detail"] + tables["Series Review"]
    )
    assert not candidates(tables) & {
        "absolute_bound_exceedance",
        "breach_episode",
        "repeated_warning_proximity",
    }
    assert (
        not {"Absolute-limit eligible observations", "Absolute-bound exceedances"}
        & summary(tables).keys()
    )
    assert not any(
        row.get("check") in {"Limit consumption", "unavailable_utilization", "warning_default"}
        for row in tables["Sources and Methods"] + tables["Data Quality"]
    )
    assert "## Limit consumption" not in report


def test_raw_warning_fields_do_not_trigger_consumption_analysis(tmp_path):
    """Unused warning ratios stay literal while independent limit-history disclosures remain."""
    _, tables = run(
        tmp_path,
        [
            sgmr_row(
                value=12,
                limType="RELATIVE_THRESHOLD",
                limTempMaxValue=20,
                limRelativeThreshold="not-a-warning-ratio",
            )
        ],
    )
    detail = tables["SGMR Detail"][0]
    assert detail["raw:limRelativeThreshold"] == "not-a-warning-ratio"
    assert detail["raw:limTempMaxValue"] == 20
    assert "temporary_bounds_not_applied" in {r["check"] for r in tables["Data Quality"]}
    assert not any(
        row["check"] in {"warning_default", "unavailable_utilization"}
        or "limrelativethreshold" in row["detail"]
        for row in tables["Data Quality"]
    )


def test_movements_run_without_any_limit_consumption_fields(tmp_path):
    """Removing source bounds/type/warnings does not gate the retained movement analysis."""
    removed = {
        "limMinValue",
        "limMaxValue",
        "limInitialMinValue",
        "limInitialMaxValue",
        "limTempMinValue",
        "limTempMaxValue",
        "limRelativeThreshold",
        "limType",
    }
    rows = [
        {key: value for key, value in row.items() if key not in removed}
        for row in sgmr_series([5.0] * 11 + [10.0])
    ]
    _, tables = run(tmp_path, rows)
    assert summary(tables)["Risk movements calculated"] == 11
    assert "movement_outlier" in candidates(tables)
    assert tables["SGMR Detail"][-1]["movement_z_score"] == pytest.approx(10**0.5)


def test_duplicate_grains_versions_and_missing_dates(tmp_path):
    first = sgmr_row()
    rows = [
        first,
        first.copy(),
        {**first, "consoValue": 8},
        {**first, "consoVersion": 2},
        sgmr_row(date(2025, 1, 2), consoValueDate="bad-date"),
    ]
    _, tables = run(tmp_path, rows)
    assert summary(tables)["SGMR exact duplicates removed"] == 1
    assert len(tables["SGMR Detail"]) == 4
    assert sum(row["conflicting_grain"] for row in tables["SGMR Detail"]) == 2
    assert summary(tables)["SGMR series"] == 2
    assert "conflicting_observation_grain" in candidates(tables)


def test_case_insensitive_core_and_optional_gating(tmp_path):
    row = {
        "LIMID": "L",
        "STRANANODENAME": "P",
        "RMRISKINDICATOR": "VAR",
        "CONSOVALUEDATE": "2025-01-01",
        "CONSOVALUE": 3.0,
    }
    report, tables = run(tmp_path, [row])
    assert summary(tables)["Colibris input events"] is None
    assert not any("Commentary" in key for key in summary(tables))
    assert tables["SGMR Detail"][0]["value"] == 3
    assert "Metric movements" in report
    availability = next(
        row
        for row in tables["Sources and Methods"]
        if row.get("kind") == "availability" and row.get("check") == "Metric movements"
    )
    assert availability["status"] == "unavailable"


@pytest.mark.parametrize(
    "condition",
    ["missing-column", "ambiguous-columns", "empty", "corrupt", "wrong-format", "missing"],
)
def test_invalid_sgmr_rejected_before_outputs(tmp_path, condition):
    row = sgmr_row()
    if condition == "missing-column":
        del row["limId"]
    if condition == "ambiguous-columns":
        row["LIMID"] = "other"
    source = write_sgmr(tmp_path / "input.parquet", [row])
    if condition == "empty":
        pl.DataFrame([row]).head(0).write_parquet(source)
    if condition == "corrupt":
        source.write_bytes(b"not parquet")
    if condition == "wrong-format":
        source = source.rename(source.with_suffix(".csv"))
    if condition == "missing":
        source.unlink()
    with pytest.raises(ValueError):
        run_risk_metrics_analysis(source, output_dir=tmp_path / "reports")
    assert not (tmp_path / "reports").exists()


@pytest.mark.parametrize(
    "values,expected",
    [
        ([5.0] * 19, set()),
        ([5.0] * 40, set()),
        ([5.0] * 39 + [9.0], {"metric_outlier", "movement_outlier"}),
        (
            [5.0] * 20 + [8.0] * 20,
            {"sustained_level_shift", "movement_outlier"},
        ),
    ],
)
def test_statistical_screens_through_runner(tmp_path, values, expected):
    _, tables = run(tmp_path, sgmr_series(values))
    statistical = {
        row["check"] for row in tables["Review Candidates"] if row.get("review_order") == 3
    }
    assert expected <= statistical
    if not expected:
        assert statistical == set()
    if values == [5.0] * 20 + [8.0] * 20:
        assert any(row.get("shift_zero_dispersion") for row in tables["Series Review"])


def test_gaps_break_movement_and_statistical_segments(tmp_path):
    """A missing supplied date splits both movement pairs and level-statistics segments."""
    rows = sgmr_series([9.0] * 39)
    # Another portfolio supplies the omitted date in the observed-date calendar.
    del rows[19]
    rows.append(sgmr_row(date(2025, 1, 20), limId="OTHER", stranaNodeName="OTHER", value=2))
    _, tables = run(tmp_path, rows)
    assert summary(tables)["Comparable statistical segments analyzed"] == 0
    assert summary(tables)["Risk movements calculated"] == 36
    after_gap = next(
        row
        for row in tables["SGMR Detail"]
        if row["source_locator"] == 'input.parquet [id="ROW-2025-01-21"]'
    )
    assert after_gap["relative_movement"] is None
    assert after_gap["previous_source_locator"] is None
    assert after_gap["movement_status"] == "no_previous_comparable_observation"


def test_unknown_zero_baseline_and_hierarchy_change(tmp_path):
    rows = sgmr_series([0.0] * 20 + [2.0] * 20)
    rows[0]["flatStrana"] = '{"PC":"OTHER"}'
    _, tables = run(tmp_path, rows)
    assert "hierarchy_conflict" in candidates(tables)
    stats = next(row for row in tables["Series Review"] if row["period"] == "statistics segment")
    assert stats["zero_baseline_changes_unavailable"] == 20
    assert "movement_outlier" not in candidates(tables)
    details = tables["SGMR Detail"]
    assert all(row["relative_movement"] is None for row in details[:21])
    assert all(row["movement_z_score"] is None for row in details)
    assert all(row["movement_status"] == "zero_previous_value" for row in details[1:21])
    assert all(row.get("observed") != float("inf") for row in tables["Review Candidates"])


def test_workflow_timing_unknowns_and_usage(tmp_path):
    rows = [sgmr_row(date(2025, 1, 10))]
    event = excess_row(
        excessCloseDate="2025-01-02",
        lastExcessValidationCreationDate="2024-12-31",
        usage="90%",
        excessMaxUsage=100,
        increaseWorkflowStatus="APPROVED",
        increaseId=0,
    )
    report, tables = run(tmp_path, rows, [event])
    assert candidates(tables) >= {
        "open_event_with_closure",
        "validation_before_explanation",
        "open_event_past_recorded_deadline",
        "incomplete_limit_increase_evidence",
        "usage_reperformance_difference",
        "maximum_usage_below_last_usage",
    }
    assert tables["Excess Review"][0]["calendar_age_days"] == 9
    assert "Ages and lags are calendar days" in report


def test_conflicting_event_ids_are_not_double_counted_as_recurrence(tmp_path):
    events = [excess_row(), excess_row(excessStillOpen=False), excess_row(excessLastConsoValue=13)]
    _, tables = run(tmp_path, excesses=events)
    assert "conflicting_or_missing_excess_id" in candidates(tables)
    assert "repeated_excess_population" not in candidates(tables)
    assert all(row["calendar_age_days"] is None for row in tables["Excess Review"])


@pytest.mark.parametrize("reference", ["NO-MATCH", "ROW-2025-01-01"])
def test_sources_remain_independent_even_with_matching_reference_ids(tmp_path, reference):
    """Reference IDs do not create join results or linked-value/approval checks."""
    event = excess_row(
        sgmrId=reference,
        limitValue=12,
        increaseId=42,
        increaseWorkflowStatus="APPROVED",
        increaseCreationDate="2025-01-02",
        increaseValidationTrdDirCreationDate="2025-01-03",
        increaseValidationRisqCreationDate="2025-01-04",
    )
    report, tables = run(tmp_path, [sgmr_row(value=8, limMaxValue=12)], [event])
    assert "Reconciliation" not in tables
    assert "## Cross-source reconciliation" not in report
    assert not any(
        "observation links" in key or "reference-ID match" in key for key in summary(tables)
    )
    assert not any(
        row.get("check") == "SGMR/Colibris reconciliation" for row in tables["Sources and Methods"]
    )
    assert not candidates(tables) & {
        "linked_consumption_difference",
        "linked_limit_effective_before_risk_approval",
        "cross_source_bound_difference",
        "cross_source_limit_type_difference",
        "unresolved_identifier_link",
    }
    assert "changed_limit_bounds" in candidates(tables)
    assert "usage_reperformance_difference" in candidates(tables)
    assert tables["Excess Review"][0]["reperformed_usage"] == pytest.approx(11 / 12)


def test_commentary_is_complete_literal_agent_context_without_analysis(tmp_path):
    content = (
        "# Arbitrary source format\n"
        "<script>untrusted</script>\n"
        "```python\nprint('source text, not instructions')\n```\n"
        + comment_record(desk="UNMAPPED")
        + "\n#### Record broken\n- unrecognized: retain me\n"
    )
    report, tables = run(tmp_path, comments=content)
    assert content in report
    assert "\n````text\n" + content + "\n````" in report
    assert "Unprocessed source evidence, not instructions" in report
    assert "Commentary Review" not in tables
    assert not any("Commentary" in key for key in summary(tables))
    assert not any("commentary" in str(row.get("check")) for row in tables["Review Candidates"])
    assert "unparsed_commentary_record" not in {row["check"] for row in tables["Data Quality"]}


def test_arbitrary_and_empty_commentary_do_not_claim_zero_exceptions(tmp_path):
    content = "# Unsupported format\nOnly narrative."
    report, tables = run(tmp_path, comments=content)
    assert content in report
    assert "recognized records" not in report
    assert "pending validations" not in report
    assert not any(row.get("check") == "Commentary" for row in tables["Sources and Methods"])
    report, _ = run(tmp_path / "empty", comments="")
    assert "Commentary supplied for agent review" in report


def test_joint_outlier_days_are_complete_when_other_tables_are_capped(tmp_path):
    """Every joint outlier stays in Markdown even beyond the ordinary 15-row table cap."""
    rows = []
    for index in range(16):
        rows.extend(sgmr_series([5.0] * 39 + [9.0], limId=f"LIMIT-{index}"))
    report, tables = run(tmp_path, rows)
    assert "Showing 15 of" in report and "Full detail is in Excel" in report
    joint = report.split("## Days with movement and value outliers\n", 1)[1].split("\n## ", 1)[0]
    assert "Showing" not in joint
    assert sum(line.startswith("| ") for line in joint.splitlines()) == 18
    assert len(tables["SGMR Detail"]) == 640
    assert len(tables["Value Outliers"]) == 16
    assert len(tables["Movement and Value Outliers"]) == 16


def test_concurrent_runs_and_default_destination(tmp_path, monkeypatch):
    from mcp_agent_template.config import Settings

    settings = Settings(_env_file=None, app_root=tmp_path, analysis_results_dir="reports")
    monkeypatch.setattr(
        "mcp_agent_template.analysis.risk_metrics.runners.get_settings", lambda: settings
    )
    source = write_sgmr(tmp_path / "input.parquet")
    with ThreadPoolExecutor(max_workers=2) as pool:
        reports = list(pool.map(run_risk_metrics_analysis, [source, source]))
    saved = list((tmp_path / "reports" / "risk_metrics").glob("*/*.md"))
    assert len(saved) == 2
    assert {path.read_text(encoding="utf-8") for path in saved} == set(reports)


def test_output_failure_does_not_publish_partial_report(tmp_path, monkeypatch):
    source = write_sgmr(tmp_path / "input.parquet")

    def fail(*args):
        raise OSError("synthetic output failure")

    monkeypatch.setattr("mcp_agent_template.analysis.risk_metrics.runners.export_workbook", fail)
    with pytest.raises(OSError, match="synthetic output"):
        run_risk_metrics_analysis(source, output_dir=tmp_path / "reports")
    assert not list((tmp_path / "reports").iterdir())


@pytest.mark.parametrize(
    "zeros,final,flagged", [(9, 10, False), (10, 10, True), (9, 0, False), (10, 0, True)]
)
def test_movement_z_score_strict_boundary_and_both_tails(tmp_path, zeros, final, flagged):
    """Ten changes give exactly +/-3; eleven exceed either boundary without a 20-row gate."""
    report, tables = run(tmp_path, sgmr_series([5.0] * (zeros + 1) + [final]))
    detail = tables["SGMR Detail"][-1]
    expected_z = zeros**0.5 * (1 if final > 5 else -1)
    assert detail["movement_z_score"] == pytest.approx(expected_z)
    assert detail["movement_outlier"] is flagged
    assert ("movement_outlier" in candidates(tables)) is flagged
    assert "large_metric_change" not in candidates(tables)
    assert summary(tables)["Comparable statistical segments analyzed"] == 0
    assert summary(tables)["Risk movements calculated"] == zeros + 1
    assert "mean_relative_movement" in report


def test_every_movement_retains_signed_values_population_and_predecessor(tmp_path):
    """Independently reconcile complete movement evidence, including negative and zero bases."""
    _, tables = run(tmp_path, sgmr_series([-10.0, -12.0, -9.0, 0.0, 2.0, 4.0]))
    details = tables["SGMR Detail"]
    known = [-0.2, 0.25, 1.0, 1.0]
    average, deviation = fmean(known), pstdev(known)
    assert details[0]["movement_status"] == "no_previous_comparable_observation"
    assert details[0]["movement_outlier"] is None
    assert details[4]["movement_status"] == "zero_previous_value"
    assert details[4]["relative_movement"] is None
    for position, change in zip((1, 2, 3, 5), known, strict=True):
        detail = details[position]
        assert detail["relative_movement"] == pytest.approx(change)
        assert detail["movement_z_score"] == pytest.approx((change - average) / deviation)
        assert detail["mean_relative_movement"] == pytest.approx(average)
        assert detail["movement_population_stddev"] == pytest.approx(deviation)
        assert detail["movement_population_count"] == 4
        assert detail["previous_source_locator"] == details[position - 1]["source_locator"]
    movement = next(row for row in tables["Series Review"] if row["period"] == "movement segment")
    assert movement["movement_observations"] == 4
    assert movement["zero_baseline_changes_unavailable"] == 1


@pytest.mark.parametrize("values", [[5.0], [5.0] * 12, [5.0, 10.0, 20.0]])
def test_first_and_constant_movements_keep_unknown_scores(tmp_path, values):
    """Constant percentage changes remain known while zero dispersion never becomes z=0."""
    _, tables = run(tmp_path, sgmr_series(values))
    details = tables["SGMR Detail"]
    assert details[0]["relative_movement"] is None
    for row in details[1:]:
        assert row["relative_movement"] == (1 if values == [5.0, 10.0, 20.0] else 0)
        assert row["movement_z_score"] is None
        assert row["movement_outlier"] is None
        assert row["movement_status"] == "zero_movement_dispersion"
    assert "movement_outlier" not in candidates(tables)


def test_movements_cover_every_metric_without_pooling_series(tmp_path):
    """All metric definitions get independent movement baselines, including custom indicators."""
    metrics = ("VAR", "SVAR", "STRESS TEST", "EXPOSURE", "CUSTOM")
    rows = []
    for index, metric in enumerate(metrics):
        rows.extend(
            sgmr_series(
                [5.0] * 11 + [10.0],
                limId=f"L-{index}",
                rmRiskIndicator=metric,
                rmRiskMetricName=f"M-{index}",
            )
        )
    _, tables = run(tmp_path, rows)
    flags = [row for row in tables["Review Candidates"] if row["check"] == "movement_outlier"]
    assert len(flags) == len(metrics)
    assert {
        row["raw:rmRiskIndicator"] for row in tables["SGMR Detail"] if row["movement_outlier"]
    } == set(metrics)
    assert summary(tables)["Risk movements calculated"] == len(metrics) * 11
    assert all(
        row["movement_population_count"] == 11
        for row in tables["SGMR Detail"]
        if row["movement_z_score"] is not None
    )


def test_invalid_and_conflicting_values_break_movement_pairs(tmp_path):
    """No return is invented across missing values or a disputed source grain."""
    rows = sgmr_series([5.0, 6.0, None, 8.0, 9.0, 10.0, 11.0])
    rows.append({**rows[4], "consoValue": 20.0})
    _, tables = run(tmp_path, rows)
    details = tables["SGMR Detail"]
    assert details[1]["relative_movement"] == pytest.approx(0.2)
    for position in (2, 4, 7):
        assert details[position]["movement_status"] == "invalid_or_conflicting_observation"
        assert details[position]["relative_movement"] is None
    for position in (3, 5):
        assert details[position]["previous_source_locator"] is None
        assert details[position]["relative_movement"] is None
    assert details[6]["relative_movement"] == pytest.approx(0.1)


def test_nonfinite_derived_movement_remains_unknown(tmp_path):
    """Finite source values that overflow the relative-change calculation are disclosed."""
    _, tables = run(tmp_path, sgmr_series([1e308, -1e308]))
    row = tables["SGMR Detail"][-1]
    assert row["movement_status"] == "nonfinite_movement"
    assert row["relative_movement"] is None and row["movement_z_score"] is None
    assert any(item["check"] == "nonfinite_movement" for item in tables["Data Quality"])


def test_outlier_equality_and_zero_dispersion_are_not_outliers(tmp_path):
    _, tables = run(tmp_path, sgmr_series([1.0, -1.0, 1 / 3, -1 / 3] + [0.0] * 16))
    assert "metric_outlier" not in candidates(tables)
    assert tables["SGMR Detail"][0]["value_z_score"] == pytest.approx(3.0)
    assert tables["SGMR Detail"][1]["value_z_score"] == pytest.approx(-3.0)
    assert tables["SGMR Detail"][0]["value_outlier"] is False
    assert tables["SGMR Detail"][1]["value_outlier"] is False


@pytest.mark.parametrize("final", [9.0, -9.0])
def test_value_and_joint_outliers_retain_independent_population_scores(tmp_path, final):
    """The same signed observation qualifies independently under both population z-scores."""
    values = [5.0] * 39 + [final]
    report, tables = run(tmp_path, sgmr_series(values))
    average, deviation = fmean(values), pstdev(values)
    detail = tables["SGMR Detail"][-1]
    assert detail["value_z_score"] == pytest.approx((final - average) / deviation)
    assert detail["value_z_score"] > 3 if final > 5 else detail["value_z_score"] < -3
    assert detail["value_outlier"] is True
    assert detail["movement_outlier"] is True
    assert detail["movement_and_value_outlier"] is True
    assert detail["value_population_count"] == 40
    assert detail["mean_value"] == pytest.approx(average)
    assert detail["value_population_stddev"] == pytest.approx(deviation)
    assert detail["value_status"] == "available"
    assert summary(tables)["Metric value outlier observations"] == 1
    assert summary(tables)["Movement and value outlier observations"] == 1
    for title in ("Value Outliers", "Movement and Value Outliers"):
        assert len(tables[title]) == 1
        assert tables[title][0]["source_locator"] == detail["source_locator"]
        assert tables[title][0]["observation_date"] == detail["observation_date"]
        assert tables[title][0]["value_z_score"] == pytest.approx(detail["value_z_score"])
    joint = report.split("## Days with movement and value outliers\n", 1)[1].split("\n## ", 1)[0]
    assert "2025-02-09" in joint and "ROW-2025-02-09" in joint
    assert "## Prioritized follow-up" not in report


@pytest.mark.parametrize(
    "values,status",
    [([5.0] * 19, "insufficient_comparable_observations"), ([5.0] * 20, "zero_value_dispersion")],
)
def test_unavailable_value_scores_remain_unknown_in_joint_checks(tmp_path, values, status):
    """Short and constant populations do not manufacture value scores or joint-outlier days."""
    _, tables = run(tmp_path, sgmr_series(values))
    details = tables["SGMR Detail"]
    assert all(row["value_z_score"] is None and row["value_outlier"] is None for row in details)
    assert all(row["value_status"] == status for row in details)
    assert all(row["value_population_count"] == len(values) for row in details)
    assert all(row["movement_and_value_outlier"] is None for row in details)
    assert summary(tables)["Risk values with known z-score"] == 0
    assert tables["Value Outliers"][0]["status"].startswith("No rows")
    assert tables["Movement and Value Outliers"][0]["status"].startswith("No rows")


def test_joint_days_do_not_match_flags_from_different_series(tmp_path):
    """Matching date/metric/perimeter labels cannot combine flags from distinct source rows."""
    rows = sgmr_series([9.0] + [5.0] * 39, limId="VALUE-ONLY")
    rows += [
        sgmr_row(date(2024, 12, 21) + timedelta(days=index), value, limId="MOVEMENT-ONLY")
        for index, value in enumerate([5.0] * 11 + [10.0])
    ]
    _, tables = run(tmp_path, rows)
    same_day = [
        row for row in tables["SGMR Detail"] if row["observation_date"].date() == date(2025, 1, 1)
    ]
    assert len(same_day) == 2
    assert same_day[0]["value_outlier"] is True and same_day[0]["movement_outlier"] is None
    assert same_day[1]["movement_outlier"] is True and same_day[1]["value_outlier"] is None
    assert all(row["movement_and_value_outlier"] is not True for row in same_day)
    assert summary(tables)["Movement and value outlier observations"] == 0
    assert tables["Movement and Value Outliers"][0]["status"].startswith("No rows")


@pytest.mark.parametrize("retained,flagged", [(19, False), (18, True)])
def test_coverage_screen_uses_observed_dates_and_strict_threshold(tmp_path, retained, flagged):
    rows = sgmr_series([5.0] * retained)
    rows += sgmr_series([2.0] * 20, limId="OTHER", stranaNodeName="OTHER")
    _, tables = run(tmp_path, rows)
    assert ("series_coverage_below_95_percent" in candidates(tables)) is flagged


def test_limit_history_changes_without_initial_bounds(tmp_path):
    rows = sgmr_series([5.0, 6.0], limInitialMinValue=None, limInitialMaxValue=None)
    rows[1]["limMaxValue"] = 12
    _, tables = run(tmp_path, rows)
    assert summary(tables)["Changed-limit series"] == 1
    assert "observed_limit_change" in candidates(tables)


def test_units_conflict_at_same_grain_and_scenario_axes_stay_separate(tmp_path):
    rows = [sgmr_row(), sgmr_row(limUnit="EUR"), sgmr_row(consoSttScenario="different")]
    _, tables = run(tmp_path, rows)
    assert sum(row["conflicting_grain"] for row in tables["SGMR Detail"]) == 2
    assert sum(row["comparable_for_statistics"] for row in tables["SGMR Detail"]) == 1


def test_nonfinite_and_malformed_fields_remain_visible(tmp_path):
    rows = [
        sgmr_row(value=float("nan")),
        sgmr_row(date(2025, 1, 2), value=float("inf")),
        sgmr_row(date(2025, 1, 3), limMaxValue=None, consoVersion=-1),
    ]
    _, tables = run(tmp_path, rows)
    assert all(row["value"] is None for row in tables["SGMR Detail"][:2])
    assert [row["raw:consoValue"] for row in tables["SGMR Detail"][:2]] == ["NaN", "Infinity"]
    assert sum(row["check"] == "invalid_field" for row in tables["Data Quality"]) == 3


def test_multiple_excesses_and_validation_unknowns(tmp_path):
    events = [excess_row(excessId=f"E-{i}", excessStillOpen="unrecognized") for i in range(3)]
    _, tables = run(tmp_path, excesses=events)
    assert summary(tables)["Colibris recorded open events"] is None
    assert "repeated_excess_population" in candidates(tables)
    assert all(row["calendar_age_days"] is None for row in tables["Excess Review"])


@pytest.mark.parametrize("condition", ["invalid-utf8", "broken-csv", "missing-id"])
def test_invalid_optional_input_is_an_error_not_a_silent_omission(tmp_path, condition):
    sgmr = write_sgmr(tmp_path / "input.parquet")
    csv = tmp_path / "events.csv"
    if condition == "invalid-utf8":
        csv.write_bytes(b"excessId\n\xff")
    elif condition == "broken-csv":
        csv.write_text('excessId\n"unterminated', encoding="utf-8")
    else:
        csv.write_text("other\n1", encoding="utf-8")
    with pytest.raises(ValueError):
        run_risk_metrics_analysis(sgmr, csv, output_dir=tmp_path / "reports")
    assert not (tmp_path / "reports").exists()


def test_commentary_duplicates_and_conflicts_are_left_for_the_agent(tmp_path):
    first = comment_record()
    second = comment_record("review:2").replace("Desk: DESK-A", "Desk: DIFFERENT")
    content = "## Quarter: 2025Q1\n" + first + first + second
    report, tables = run(tmp_path, comments=content)
    assert content in report
    assert report.count(first) == 2
    assert not any("commentary" in str(row.get("check")) for row in tables["Review Candidates"])
    assert not any("commentary" in str(row.get("check")) for row in tables["Data Quality"])


def test_excel_long_text_continuations_preserve_evidence(tmp_path):
    text = "A" * 65000
    _, tables = run(tmp_path, [sgmr_row(consoComment=text)])
    chunks = tables["SGMR Detail"]
    assert "".join(row["raw:consoComment"] for row in chunks) == text
    assert [row["text_part"] for row in chunks] == ["1/3", "2/3", "3/3"]
    assert [row["value"] for row in chunks] == [5, None, None]


def test_relative_paths_and_workbook_layout(tmp_path, monkeypatch):
    write_sgmr(tmp_path / "source.parquet")
    monkeypatch.chdir(tmp_path)
    run_risk_metrics_analysis("source.parquet", output_dir="reports")
    path = next((tmp_path / "reports").glob("*/*.xlsx"))
    workbook = openpyxl.load_workbook(path)
    try:
        for sheet in workbook:
            assert sheet.freeze_panes == "A2"
            assert sheet.auto_filter.ref == sheet.dimensions
            assert sheet["A1"].font.bold
            assert 12 <= sheet.column_dimensions["A"].width <= 60
    finally:
        workbook.close()


@pytest.mark.parametrize(
    "after,spread,flagged",
    [
        (6.0, 0.25, True),
        (5.999, 0.25, False),
        (6.25, 0.5, True),
        (6.25, 0.501, False),
    ],
)
def test_level_shift_percentage_and_effect_boundaries(tmp_path, after, spread, flagged):
    values = [5 - spread, 5 + spread] * 10 + [after - spread, after + spread] * 10
    _, tables = run(tmp_path, sgmr_series(values))
    assert ("sustained_level_shift" in candidates(tables)) is flagged


@pytest.mark.parametrize(
    "values",
    [
        [2 + index * 0.1 for index in range(60)],
        [5 + (-1) ** index * (0.1 if index < 40 else 1.5) for index in range(80)],
    ],
)
def test_removed_volatility_and_trend_have_no_calculations_or_outputs(tmp_path, values):
    """Previously qualifying series no longer produce removed screens or workbook columns."""
    report, tables = run(tmp_path, sgmr_series(values))
    assert not {"persistent_metric_trend", "volatility_regime_change"} & candidates(tables)
    removed = {
        "rolling_volatility_change",
        "trend_slope_per_observation",
        "trend_r_squared",
        "projected_period_change",
    }
    assert all(not removed & row.keys() for row in tables["Series Review"])
    assert "Volatility and trend" not in report
    assert "R-squared" not in report and "OLS" not in report


def test_negative_lag_fields_and_unsatisfactory_validation(tmp_path):
    _, tables = run(
        tmp_path,
        excesses=[
            excess_row(
                daysWithoutValidationTotal=-2,
                lastExcessValidationIsSatisfactory=False,
            )
        ],
    )
    assert "unsatisfactory_validation_recorded" in candidates(tables)
    assert any(
        row["check"] == "invalid_field" and "dayswithoutvalidationtotal" in row["detail"]
        for row in tables["Data Quality"]
    )


def test_sgmr_cannot_be_omitted_by_python_callers(tmp_path):
    with pytest.raises(ValueError, match="SGMR path is required"):
        run_risk_metrics_analysis(None, output_dir=tmp_path / "reports")
    assert not (tmp_path / "reports").exists()


@pytest.mark.parametrize("missing", [True, False])
def test_source_references_distinguish_missing_and_duplicate_ids(tmp_path, missing):
    source_id = None if missing else "REUSED"
    rows = [
        sgmr_row(id=source_id, value=11),
        sgmr_row(date(2025, 1, 2), id=source_id, value=12),
    ]
    _, tables = run(tmp_path, rows)
    references = [row["source_locator"] for row in tables["SGMR Detail"]]
    assert len(set(references)) == 2
    assert "record=1" in references[0] and "record=2" in references[1]
    if not missing:
        assert all('id="REUSED"' in item for item in references)


def test_source_ids_preserve_literal_special_characters_and_numeric_ids(tmp_path):
    _, tables = run(
        tmp_path,
        [sgmr_row(id='row | "quoted"\nnext', value=11)],
        [excess_row(excessId=42)],
    )
    reference = tables["SGMR Detail"][0]["source_locator"]
    assert "\n" not in reference
    assert r"\n" in reference
    assert tables["SGMR Detail"][0]["id"] == 'row | "quoted"\nnext'
    assert tables["Excess Review"][0]["source_locator"] == 'events.csv [excessId="42"]'


@pytest.mark.parametrize("invalid", ["missing", "encoding", "extension"])
def test_commentary_file_errors_are_explicit(tmp_path, invalid):
    sgmr = write_sgmr(tmp_path / "input.parquet")
    commentary = tmp_path / ("notes.txt" if invalid == "extension" else "notes.md")
    if invalid != "missing":
        commentary.write_bytes(b"\xff" if invalid == "encoding" else b"source")
    with pytest.raises(ValueError):
        run_risk_metrics_analysis(
            sgmr, risk_metrics_commentary_path=commentary, output_dir=tmp_path / "reports"
        )
    assert not (tmp_path / "reports").exists()


def test_commentary_bom_crlf_and_long_content_reach_agent_without_truncation(tmp_path):
    source = write_sgmr(tmp_path / "input.parquet")
    content = "# Custom\r\n" + "Narrative. " * 7000 + "\r\nTAIL-MARKER"
    notes = tmp_path / "notes.md"
    notes.write_bytes(b"\xef\xbb\xbf" + content.encode("utf-8"))
    report = run_risk_metrics_analysis(
        source, risk_metrics_commentary_path=notes, output_dir=tmp_path / "reports"
    )
    assert content.replace("\r\n", "\n") in report
    assert notes.read_bytes() == b"\xef\xbb\xbf" + content.encode("utf-8")
    assert "TAIL-MARKER" in report
