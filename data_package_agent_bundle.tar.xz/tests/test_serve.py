from __future__ import annotations

import asyncio
import socket
import subprocess
from pathlib import Path

import pytest
from fastmcp import Client

from mcp_agent_template import serve
from mcp_agent_template.config import Settings
from tests.analysis.support import write_cases


class Process:
    pid = 12345

    def __init__(self, *, terminate_times_out=False, exited=False):
        self.terminate_times_out = terminate_times_out
        self.exited = exited
        self.calls = []

    def poll(self):
        return 0 if self.exited else None

    def terminate(self):
        self.calls.append("terminate")

    def kill(self):
        self.calls.append("kill")

    def wait(self, timeout=None):
        self.calls.append("wait")
        if self.terminate_times_out and "kill" not in self.calls:
            raise subprocess.TimeoutExpired("server", timeout)
        self.exited = True
        return 0


@pytest.fixture
def settings(tmp_path):
    return Settings(_env_file=None, app_root=tmp_path, log_level="ERROR")


def test_launch_resolves_log_and_passes_settings_then_closes_parent_handle(settings, monkeypatch):
    process = Process()
    captured = {}

    def launch(*args, **kwargs):
        captured.update(kwargs)
        assert not kwargs["stdout"].closed
        return process

    monkeypatch.setattr(serve, "_port_open", lambda *args: False)
    monkeypatch.setattr(serve, "wait_for_port", lambda *args: True)
    monkeypatch.setattr(serve.subprocess, "Popen", launch)

    assert serve.spawn_http_server(settings, log_path="server.log") is process
    assert Path(captured["stdout"].name) == settings.app_root / "server.log"
    assert captured["stdout"] is captured["stderr"]
    assert captured["stdout"].closed
    assert captured["env"] == settings.mcp_server_env("http")


def test_failed_spawn_closes_log(settings, monkeypatch):
    handles = []

    def fail(*args, **kwargs):
        handles.append(kwargs["stdout"])
        raise OSError("launch failed")

    monkeypatch.setattr(serve, "_port_open", lambda *args: False)
    monkeypatch.setattr(serve.subprocess, "Popen", fail)

    with pytest.raises(OSError, match="launch failed"):
        serve.spawn_http_server(settings)
    assert handles[0].closed


@pytest.mark.parametrize("terminate_times_out", [False, True])
def test_readiness_failure_reaps_process_and_closes_log(settings, monkeypatch, terminate_times_out):
    process = Process(terminate_times_out=terminate_times_out)
    handles = []

    def launch(*args, **kwargs):
        handles.append(kwargs["stdout"])
        return process

    monkeypatch.setattr(serve, "_port_open", lambda *args: False)
    monkeypatch.setattr(serve, "wait_for_port", lambda *args: False)
    monkeypatch.setattr(serve.subprocess, "Popen", launch)

    with pytest.raises(RuntimeError, match="failed to start"):
        serve.spawn_http_server(settings)
    expected = (
        ["terminate", "wait", "kill", "wait"] if terminate_times_out else ["terminate", "wait"]
    )
    assert process.calls == expected
    assert process.exited
    assert handles[0].closed


def test_readiness_exception_also_reaps_child(settings, monkeypatch):
    process = Process()

    def fail(*args):
        raise KeyboardInterrupt

    monkeypatch.setattr(serve, "_port_open", lambda *args: False)
    monkeypatch.setattr(serve.subprocess, "Popen", lambda *args, **kwargs: process)
    monkeypatch.setattr(serve, "wait_for_port", fail)

    with pytest.raises(KeyboardInterrupt):
        serve.spawn_http_server(settings)
    assert process.calls == ["terminate", "wait"]


def test_shutdown_escalates_and_reaps_before_checking_port(settings, monkeypatch):
    process = Process(terminate_times_out=True)

    def released(*args):
        assert process.exited
        return True

    monkeypatch.setattr(serve, "wait_for_port_free", released)
    serve.stop_http_server(process, settings)
    assert process.calls == ["terminate", "wait", "kill", "wait"]


def test_shutdown_reports_port_still_in_use(settings, monkeypatch):
    monkeypatch.setattr(serve, "wait_for_port_free", lambda *args: False)

    with pytest.raises(RuntimeError, match="still in use"):
        serve.stop_http_server(Process(), settings)


def test_shutdown_reaps_already_exited_process(settings, monkeypatch):
    process = Process(exited=True)
    monkeypatch.setattr(serve, "wait_for_port_free", lambda *args: True)
    serve.stop_http_server(process, settings)
    assert process.calls == ["wait"]


def test_context_manager_uses_shared_cleanup_on_body_error(settings, monkeypatch):
    process = Process(terminate_times_out=True)
    monkeypatch.setattr(serve, "spawn_http_server", lambda *args, **kwargs: process)
    monkeypatch.setattr(serve, "wait_for_port_free", lambda *args: True)
    manager = serve.http_server(settings)

    with pytest.raises(ValueError, match="body failed"):
        with manager:
            raise ValueError("body failed")
    assert process.calls == ["terminate", "wait", "kill", "wait"]
    assert manager.proc is None


def test_none_shutdown_is_noop(monkeypatch):
    def unexpected(*args):
        raise AssertionError("No owned process means no port wait")

    monkeypatch.setattr(serve, "wait_for_port_free", unexpected)
    serve.stop_http_server(None)


def test_real_http_helper_passes_settings_and_reaps_child(tmp_path):
    source = write_cases(tmp_path / "input" / "cases.parquet")
    with socket.socket() as socket_probe:
        socket_probe.bind(("127.0.0.1", 0))
        port = socket_probe.getsockname()[1]
    settings = Settings(
        _env_file=None,
        app_root=tmp_path,
        mcp_host="127.0.0.1",
        mcp_port=port,
        genai_model="helper-specific-model",
        mcp_server_name="helper-specific-server",
        mcp_server_module="mcp_agent_template.mcp_server",
        log_level="ERROR",
    )

    async def verify():
        """Validate the HTTP catalog, configured server identity and actual review call."""
        async with Client(settings.mcp_http_url) as client:
            definitions = await client.list_tools()
            assert {tool.name for tool in definitions} == {
                "list_files",
                "run_post_trade_review",
                "run_risk_metrics_analysis",
                "run_pnl_analysis",
            }
            assert client.server_info.name == settings.mcp_server_name
            result = await client.call_tool(
                "run_post_trade_review", {"folder_path": str(source.parent)}
            )
            assert "Post-Trade Control Analysis" in result.data

    with serve.http_server(settings) as process:
        asyncio.run(asyncio.wait_for(verify(), timeout=15))
    assert process.poll() is not None
    assert (tmp_path / "mcp_server.log").is_file()
    assert "Traceback" not in (tmp_path / "mcp_server.log").read_text(encoding="utf-8")
    assert process.stdin.closed
    from mcp_agent_template.observability.recording.storage import read_rows

    records = read_rows(
        settings.resolve_path(settings.obs.dir) / "observability.sqlite3", "SELECT * FROM processes"
    )
    assert records and all(
        record["stopped"] and record["health"] == "healthy" for record in records
    )
