"""Application-folder skills, with no installed-package fallback."""

import json
from pathlib import Path
from shutil import copytree

import pytest
from langchain_core.messages import AIMessage, ToolMessage

from mcp_agent_template.agent.multi_agent import AgentSpec, build_agent_tree
from mcp_agent_template.agent.react_agent import build_agent
from mcp_agent_template.config import Settings
from mcp_agent_template.skills.loader import agent_skills_path, discover_skills
from tests.support.models import ScriptedModel

SKILL_SOURCE = Path(__file__).resolve().parents[1] / "skills" / "post-trade-control"


async def test_risk_skill_and_references_load_through_agent(tmp_path):
    source = SKILL_SOURCE.parent / "risk-metrics"
    copytree(source, tmp_path / "skills" / source.name)
    settings = Settings(_env_file=None, app_root=tmp_path, obs={"mode": "off"})
    calls = [
        ("load_skill", {"name": "risk-metrics"}),
        ("read_skill_file", {"name": "risk-metrics", "path": "references/dataset.md"}),
        ("read_skill_file", {"name": "risk-metrics", "path": "references/methodology.md"}),
    ]
    model = ScriptedModel(
        responses=[
            AIMessage(content="", tool_calls=[{"name": name, "args": args, "id": str(i)}])
            for i, (name, args) in enumerate(calls)
        ]
        + [AIMessage(content="Risk review contract loaded.")]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    result = await bundle.ainvoke("Load the risk review skill and its references.")
    messages = [message for message in result["messages"] if isinstance(message, ToolMessage)]
    assert len(messages) == 3
    assert all(message.status == "success" for message in messages)
    assert "run_risk_metrics_analysis" in str(messages[0].content)
    assert "limId" in str(messages[1].content)
    assert "1.5 percentage points" in str(messages[2].content)


@pytest.mark.parametrize("exists", [False, True], ids=["missing", "empty"])
def test_default_folder_has_no_fallback(tmp_path, monkeypatch, exists):
    settings = Settings(_env_file=None, app_root=tmp_path, skills_dir="skills")
    monkeypatch.setattr("mcp_agent_template.skills.loader.get_settings", lambda: settings)
    if exists:
        settings.skills_path.mkdir()
    assert agent_skills_path(settings) == tmp_path / "skills"
    assert discover_skills() == []
    assert discover_skills(agent_skills_path(settings)) == []


@pytest.mark.parametrize("exists", [False, True], ids=["missing", "empty"])
def test_custom_directory_does_not_merge_default_skills(tmp_path, exists):
    copytree(SKILL_SOURCE, tmp_path / "skills" / SKILL_SOURCE.name)
    custom = tmp_path / "custom"
    if exists:
        custom.mkdir()
    settings = Settings(_env_file=None, app_root=tmp_path, skills_dir="custom")
    assert agent_skills_path(settings) == custom
    assert discover_skills(agent_skills_path(settings)) == []
    defaults = Settings(_env_file=None, app_root=tmp_path, skills_dir="skills")
    assert agent_skills_path(defaults, "custom") == custom
    assert discover_skills(agent_skills_path(defaults, "custom")) == []


@pytest.mark.parametrize("tree", [False, True], ids=["single-agent", "tree-node"])
async def test_agent_loads_default_skill_and_dataset_reference(tmp_path, tree):
    destination = tmp_path / "skills" / SKILL_SOURCE.name
    copytree(SKILL_SOURCE, destination)
    settings = Settings(_env_file=None, app_root=tmp_path, obs={"mode": "off"})
    calls = [
        ("load_skill", {"name": "post-trade-control"}),
        ("read_skill_file", {"name": "post-trade-control", "path": "references/dataset.md"}),
    ]
    model = ScriptedModel(
        responses=[
            AIMessage(content="", tool_calls=[{"name": tool, "args": args, "id": str(i)}])
            for i, (tool, args) in enumerate(calls)
        ]
        + [AIMessage(content="Skill and dataset contract loaded.")]
    )
    if tree:
        bundle = await build_agent_tree(
            AgentSpec(
                name="auditor",
                description="Review controls",
                model=model,
                skill_names=["post-trade-control"],
            ),
            settings,
            mcp_tools=[],
        )
    else:
        bundle = await build_agent(settings, model=model, mcp_tools=[])
    assert [skill.name for skill in bundle.skills] == ["post-trade-control"]
    assert bundle.skills[0].path == destination / "SKILL.md"
    result = await bundle.ainvoke("Load the post-trade review skill and its dataset contract.")
    messages = [m for m in result["messages"] if isinstance(m, ToolMessage)]
    assert len(messages) == 2
    assert all(message.status == "success" for message in messages)
    assert bundle.skills[0].instructions in messages[0].content
    payload = json.loads(messages[1].content)
    assert payload["relative_path"] == "references/dataset.md"
    assert payload["content"] == (destination / "references/dataset.md").read_text(encoding="utf-8")


async def test_tree_keeps_explicit_empty_folder_and_skill_exclusion(tmp_path):
    copytree(SKILL_SOURCE, tmp_path / "skills" / SKILL_SOURCE.name)
    (tmp_path / "empty").mkdir()
    settings = Settings(_env_file=None, app_root=tmp_path, obs={"mode": "off"})
    model = ScriptedModel(responses=[AIMessage(content="done")])
    for options in ({"skills_dir": "empty"}, {"skill_names": []}):
        bundle = await build_agent_tree(
            AgentSpec(name="auditor", description="No selected skill", model=model, **options),
            settings,
            mcp_tools=[],
        )
        assert bundle.skills == []
    with pytest.raises(ValueError, match="unknown skill_names"):
        await build_agent_tree(
            AgentSpec(
                name="auditor",
                description="Missing skill",
                model=model,
                skills_dir="empty",
                skill_names=["post-trade-control"],
            ),
            settings,
            mcp_tools=[],
        )
