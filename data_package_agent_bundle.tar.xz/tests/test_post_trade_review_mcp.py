"""Exercise the post-trade review tool and its errors over real MCP stdio."""

import asyncio

import pytest
from langchain_core.messages import ToolMessage

from mcp_agent_template.agent.react_agent import build_mcp_client
from mcp_agent_template.config import Settings
from tests.analysis.support import case_row, write_cases

TOOL_NAME = "run_post_trade_review"


async def review_tool(tmp_path):
    settings = Settings(
        _env_file=None,
        app_root=tmp_path / "application",
        analysis_results_dir=str(tmp_path / "reports"),
        obs={"mode": "off"},
    )
    tools = await build_mcp_client(settings).list_tools()
    return next(tool for tool in tools if tool.name == TOOL_NAME)


async def call(tool, folder):
    message = await tool.ainvoke(
        {
            "type": "tool_call",
            "name": TOOL_NAME,
            "args": {"folder_path": str(folder)},
            "id": "analysis-test",
        }
    )
    assert isinstance(message, ToolMessage)
    return message


async def test_post_trade_review_runs_over_stdio_and_retains_separate_reports(tmp_path):
    source = write_cases(tmp_path / "input" / "arbitrary.parquet")
    tool = await review_tool(tmp_path)
    results = await asyncio.gather(call(tool, source.parent), call(tool, source.parent))
    for result in results:
        assert result.status == "success", result.content
        assert "Post-Trade Control Analysis" in str(result.content)
    reports = list((tmp_path / "reports" / "fox").glob("*/*.md"))
    assert len(reports) == 2
    assert all(report.with_suffix(".xlsx").is_file() for report in reports)
    assert "historic_comments_count" in str(tool.args_schema)


@pytest.mark.parametrize(
    "condition,expected",
    [
        ("missing-folder", "existing directory"),
        ("missing-column", "historic_comments_count"),
        ("missing-hit-search-items", "hit_search_items"),
        ("multiple-files", "Multiple post-trade control Parquet"),
        ("corrupt-file", "Cannot read Parquet schema"),
        ("invalid-count", "nonnegative whole numbers"),
        ("blocked-output", "ANALYSIS_RESULTS_DIR"),
    ],
)
async def test_post_trade_review_errors_are_actionable_over_stdio(tmp_path, condition, expected):
    folder = tmp_path / "input"
    if condition != "missing-folder":
        row = case_row()
        if condition == "missing-column":
            del row["historic_comments_count"]
        if condition == "missing-hit-search-items":
            del row["hit_search_items"]
        if condition == "invalid-count":
            row["historic_comments_count"] = -1
        source = write_cases(folder / "input.parquet", [row])
        if condition == "multiple-files":
            write_cases(folder / "second.parquet")
        if condition == "corrupt-file":
            source.write_bytes(b"synthetic invalid parquet")
        if condition == "blocked-output":
            (tmp_path / "reports").write_text("not a directory", encoding="utf-8")
    result = await call(await review_tool(tmp_path), folder)
    assert result.status == "error", result.content
    assert expected in str(result.content)
