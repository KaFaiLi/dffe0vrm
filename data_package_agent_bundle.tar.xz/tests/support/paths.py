"""Portable path-resolution redirects for filesystem containment tests."""

from collections.abc import Mapping
from pathlib import Path

from pytest import MonkeyPatch


def redirect_path_resolution(monkeypatch: MonkeyPatch, redirects: Mapping[Path, Path]) -> None:
    """Model resolved file/directory targets without requiring OS symlink privileges.

    Redirect descendants too, so replacing a directory affects every file below
    it. Other paths and all file reads still use the real temporary filesystem.
    """
    original_resolve = Path.resolve

    def resolve(path: Path, *args, **kwargs) -> Path:
        for source, target in redirects.items():
            try:
                relative = path.relative_to(source)
            except ValueError:
                continue
            return original_resolve(target / relative, *args, **kwargs)
        return original_resolve(path, *args, **kwargs)

    monkeypatch.setattr(Path, "resolve", resolve)
