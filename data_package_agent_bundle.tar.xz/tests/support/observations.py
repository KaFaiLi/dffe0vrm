"""SQLite evidence helpers for agent recordings."""

import json

from mcp_agent_template.config import Settings
from mcp_agent_template.observability.recording.storage import read_rows


def settings_at(path, **kwargs):
    return Settings(_env_file=None, app_root=path, obs={"flush_interval_ms": 0}, **kwargs)


def events(obs, name=None):
    rows = read_rows(
        obs.path,
        "SELECT * FROM events" + (" WHERE event_name=?" if name else "") + " ORDER BY cursor",
        (name,) if name else (),
    )
    for row in rows:
        row["data"] = json.loads(row["payload"])["data"]
    return rows
