"""Shared scripted models and recorder evidence helpers."""
