"""Opt-in analysis fixtures registered as a plugin by tests/conftest.py."""

import pytest

from mcp_agent_template.analysis import charts


@pytest.fixture
def without_png_rendering(monkeypatch):
    """Replace only PNG export when numerical tests explicitly request this fixture."""

    def export(_figures, directory):
        """Write an empty chart index without consuming or rendering the figures."""
        directory.mkdir()
        charts.write_index([], directory)
        return []

    monkeypatch.setattr(charts, "export_charts", export)


@pytest.fixture
def captured_charts(monkeypatch):
    """Capture production figures and evidence while leaving PNG rendering to dedicated tests."""
    captured = []

    def export(figures, directory):
        """Materialize chart data and write its real index without serializing image pixels."""
        directory.mkdir()
        items = list(figures)
        captured.extend(items)
        records = [item.metadata(f"chart-{i:04d}.png") for i, item in enumerate(items, 1)]
        charts.write_index(records, directory)
        return records

    monkeypatch.setattr(charts, "export_charts", export)
    return captured
