"""Invocation-keyed scripted test models."""

from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import Field


class ScriptedModel(FakeMessagesListChatModel):
    def bind_tools(self, tools, **kwargs):
        return self


class RequestModel(BaseChatModel):
    names: list[str]
    observed: list[Any] = Field(default_factory=list)
    repeat: bool = False

    @property
    def _llm_type(self):
        return "request-keyed-test-model"

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        latest = max(i for i, m in enumerate(messages) if isinstance(m, HumanMessage))
        label = messages[latest].text
        completed = any(isinstance(m, ToolMessage) for m in messages[latest + 1 :])
        self.observed.append(list(messages))
        calls = (
            []
            if completed and not self.repeat
            else [
                {"name": name, "args": {"label": label}, "id": f"{name}-{len(messages)}"}
                for name in self.names
            ]
        )
        message = AIMessage(
            content="" if calls else f"done:{label}",
            tool_calls=calls,
            usage_metadata={"input_tokens": 4, "output_tokens": 2, "total_tokens": 6},
        )
        return ChatResult(generations=[ChatGeneration(message=message)])
