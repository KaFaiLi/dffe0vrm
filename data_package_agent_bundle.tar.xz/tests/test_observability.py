"""Real native graph recording, redaction, isolation and cleanup."""

import asyncio
import json
import logging

import pytest
from langchain_core.messages import AIMessage
from langchain_core.tools import tool
from langgraph.errors import GraphRecursionError

from mcp_agent_template.agent import AgentSpec, build_agent, build_agent_tree
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.cli import archive
from mcp_agent_template.observability.context import ACTIVE_SCOPE
from mcp_agent_template.observability.recording.storage import read_rows
from tests.analysis.support import write_cases
from tests.support.models import RequestModel, ScriptedModel
from tests.support.observations import events, settings_at


def test_server_middleware_records_real_mcp_arguments_results_and_failures(tmp_path):
    from fastmcp import Client

    from mcp_agent_template.mcp_server.server import build_server

    source = write_cases(tmp_path / "input" / "cases.parquet")

    async def run():
        async with ObservabilityRuntime.local(settings_at(tmp_path)) as obs:
            with obs.activate():
                async with Client(build_server(obs.settings)) as client:
                    result = await client.call_tool(
                        "run_post_trade_review", {"folder_path": str(source.parent)}
                    )
                    assert "Post-Trade Control Analysis" in result.data
                    failed = await client.call_tool(
                        "run_post_trade_review",
                        {"folder_path": str(tmp_path / "missing")},
                        raise_on_error=False,
                    )
                    assert failed.is_error
            assert await obs.aflush()
            assert events(obs, "capture.mcp.server.request")
            assert events(obs, "capture.mcp.server.result")
            completions = events(obs, "mcp.server.tool.finished")
            assert {row["data"]["completion"] for row in completions} == {"completed", "failed"}
            assert obs.errors == 0

    asyncio.run(run())


def test_python_312_handler_replacement_redacts_real_output_without_mutating_record(monkeypatch):
    import io

    from rich.console import Console
    from rich.logging import RichHandler

    from mcp_agent_template.logging_utils import CredentialFilter

    monkeypatch.setenv("TEST_API_KEY", "example-credential")
    output = io.StringIO()
    handler = RichHandler(console=Console(file=output, width=120), show_path=False)
    handler.addFilter(CredentialFilter())
    try:
        raise RuntimeError("password=example-credential")
    except RuntimeError:
        import sys

        record = logging.LogRecord(
            "example",
            logging.ERROR,
            __file__,
            1,
            "Bearer %s",
            ("example-credential",),
            sys.exc_info(),
        )
    handler.handle(record)
    assert "example-credential" not in output.getvalue()
    assert "[REDACTED]" in output.getvalue()
    assert record.getMessage() == "Bearer example-credential"
    assert record.exc_info is not None


def test_complete_recording_usage_redaction_and_export(tmp_path, monkeypatch):
    monkeypatch.setenv("TEST_API_KEY", "synthetic-secret")

    @tool
    async def lookup(label: str) -> str:
        """Return a matching result and record its diagnostic details."""
        logging.getLogger(__name__).warning("Bearer synthetic-secret")
        return "x" * 70000 + label + " synthetic-secret"

    async def run():
        settings = settings_at(tmp_path)
        obs = ObservabilityRuntime.local(settings)
        async with obs:
            bundle = await build_agent(
                settings,
                model=RequestModel(names=["lookup"]),
                mcp_tools=[],
                extra_tools=[lookup],
                observability=obs,
            )
            assert await bundle.ask("query") == "done:query"
            assert await obs.aflush()
            run_id = read_rows(obs.path, "SELECT run_id FROM runs")[0]["run_id"]
            exported = archive(obs.path, run_id)
            assert exported["runs"]
            assert obs.errors == 0
        assert obs.closed and not obs.store.thread.is_alive()
        payloads = "\n".join(
            r["payload"] for r in read_rows(obs.path, "SELECT payload FROM events")
        )
        assert "synthetic-secret" not in payloads
        assert "[REDACTED]" in payloads
        tool_result = events(obs, "tool.finished")[0]["data"]["result"]
        assert len(tool_result["content"]) > 70000
        assert read_rows(obs.path, "SELECT * FROM logs")
        assert read_rows(obs.path, "SELECT * FROM captures")
        assert read_rows(obs.path, "SELECT * FROM spans")
        assert read_rows(obs.path, "SELECT * FROM metric_points")
        summary = json.loads(read_rows(obs.path, "SELECT summary FROM runs")[0]["summary"])["data"]
        assert summary["summary"]["model_calls"] == 2
        assert summary["summary"]["input_tokens"] == 8
        assert summary["summary"]["output_tokens"] == 4
        assert summary["telemetry_complete"] == "complete"

    asyncio.run(run())


def test_auto_owned_recording_and_off_mode(tmp_path):
    async def run():
        bundle = await build_agent(
            settings_at(tmp_path),
            mcp_tools=[],
            model=ScriptedModel(responses=[AIMessage(content="ready")]),
        )
        assert await bundle.ask("hello") == "ready"
        db = tmp_path / ".mcp_agent_template/observability/observability.sqlite3"
        assert read_rows(db, "SELECT completion FROM runs") == [{"completion": "completed"}]
        off = settings_at(tmp_path / "off")
        off = off.model_copy(update={"obs": off.obs.model_copy(update={"mode": "off"})})
        bundle = await build_agent(
            off, mcp_tools=[], model=ScriptedModel(responses=[AIMessage(content="ready")])
        )
        assert await bundle.ask("hello") == "ready"
        assert not (off.app_root / ".mcp_agent_template").exists()

    asyncio.run(run())


def test_stream_consumer_is_detached_and_early_close_is_recorded(tmp_path):
    async def run():
        async with ObservabilityRuntime.local(settings_at(tmp_path)) as obs:
            bundle = await build_agent(
                settings_at(tmp_path),
                mcp_tools=[],
                observability=obs,
                model=ScriptedModel(responses=[AIMessage(content="ready")]),
            )
            stream = bundle.astream("hello", stream_mode="values")
            await anext(stream)
            assert ACTIVE_SCOPE.get() is None
            await stream.aclose()
            assert not obs.active_scopes
            assert await obs.aflush()
            assert (
                read_rows(obs.path, "SELECT completion FROM runs")[0]["completion"]
                == "closed_early"
            )
        assert not obs.store.thread.is_alive()

    asyncio.run(run())


def test_failed_run_keeps_complete_failure_and_next_run_works(tmp_path):
    @tool
    async def lookup(label: str) -> str:
        """Return the requested label."""
        return label

    async def run():
        settings = settings_at(tmp_path, agent_max_iterations=1)
        async with ObservabilityRuntime.local(settings) as obs:
            bundle = await build_agent(
                settings,
                model=RequestModel(names=["lookup"], repeat=True),
                mcp_tools=[],
                extra_tools=[lookup],
                observability=obs,
            )
            with pytest.raises(GraphRecursionError):
                await bundle.ask("limit")
            assert not obs.active_scopes
            next_bundle = await build_agent(
                settings,
                model=ScriptedModel(responses=[AIMessage(content="ok")]),
                mcp_tools=[],
                observability=obs,
            )
            assert await next_bundle.ask("next") == "ok"
            assert await obs.aflush()
            assert {
                r["completion"] for r in read_rows(obs.path, "SELECT completion FROM runs")
            } == {"failed", "completed"}

    asyncio.run(run())


def test_child_runs_share_root_usage_and_preserve_parent_callbacks(tmp_path):
    from langchain_core.callbacks import AsyncCallbackHandler

    class Callback(AsyncCallbackHandler):
        started: int = 0

        async def on_chat_model_start(self, *args, **kwargs):
            self.started += 1

    async def run():
        settings = settings_at(tmp_path, agent_max_concurrent_tools=1)
        child = AgentSpec(
            name="child",
            description="Answer a delegated question.",
            model=ScriptedModel(
                responses=[
                    AIMessage(
                        content="child answer",
                        usage_metadata={"input_tokens": 3, "output_tokens": 1, "total_tokens": 4},
                    )
                ]
            ),
        )
        root = AgentSpec(
            name="root",
            description="Delegate then answer.",
            sub_agents=[child],
            model=ScriptedModel(
                responses=[
                    AIMessage(
                        content="",
                        tool_calls=[
                            {"name": "ask_child", "args": {"task": "subtask"}, "id": "child-call"}
                        ],
                    ),
                    AIMessage(content="root answer"),
                ]
            ),
        )
        callback = Callback()
        async with ObservabilityRuntime.local(settings) as obs:
            bundle = await build_agent_tree(root, settings, mcp_tools=[], observability=obs)
            assert await bundle.ask("question", config={"callbacks": [callback]}) == "root answer"
            assert await obs.aflush()
            runs = read_rows(obs.path, "SELECT * FROM runs")
            assert len(runs) == 2 and len({r["root_run_id"] for r in runs}) == 1
            child_run = next(r for r in runs if r["parent_run_id"])
            root_run = next(r for r in runs if not r["parent_run_id"])
            assert child_run["parent_run_id"] == root_run["run_id"]
            assert json.loads(root_run["summary"])["data"]["summary"]["model_calls"] == 3
            assert json.loads(root_run["summary"])["data"]["summary"]["input_tokens"] == 3
            assert callback.started == 3
            assert obs.errors == 0

    asyncio.run(run())
