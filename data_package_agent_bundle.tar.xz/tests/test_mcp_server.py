"""End-to-end-ish test: spawn the real MCP server over stdio and list tools.

No LLM/credentials needed -- this validates the server + adapter wiring.
"""

import pytest

from mcp_agent_template.agent.react_agent import build_mcp_client
from mcp_agent_template.config import Settings
from tests.analysis.support import write_cases


@pytest.mark.asyncio
async def test_stdio_discovery_and_call_flush_and_stop_their_recorders(tmp_path):
    from mcp_agent_template.observability.recording.storage import read_rows

    settings = Settings(_env_file=None, app_root=tmp_path)
    client = build_mcp_client(settings)
    tools = await client.list_tools()
    db = settings.resolve_path(settings.obs.dir) / "observability.sqlite3"
    discovered = read_rows(db, "SELECT stopped,health FROM processes")
    assert discovered and all(row["stopped"] and row["health"] == "healthy" for row in discovered)
    source = write_cases(tmp_path / "input" / "cases.parquet")
    review = next(t for t in tools if t.name == "run_post_trade_review")
    result = await review.ainvoke({"folder_path": str(source.parent)})
    assert "Post-Trade Control Analysis" in str(result)
    called = read_rows(db, "SELECT stopped,health FROM processes")
    assert len(called) == len(discovered) + 1
    assert all(row["stopped"] and row["health"] == "healthy" for row in called)
    assert read_rows(db, "SELECT * FROM events WHERE event_name='capture.mcp.server.result'")


@pytest.mark.asyncio
async def test_stdio_server_exposes_tools():
    """Real stdio discovery exposes the review tools and project file discovery."""
    settings = Settings(mcp_transport="stdio")
    client = build_mcp_client(settings)
    tools = await client.list_tools()
    names = {t.name for t in tools}

    assert names == {
        "list_files",
        "run_post_trade_review",
        "run_risk_metrics_analysis",
        "run_pnl_analysis",
    }


@pytest.mark.asyncio
async def test_post_trade_review_tool_returns_report(tmp_path):
    source = write_cases(tmp_path / "input" / "cases.parquet")
    settings = Settings(_env_file=None, app_root=tmp_path, mcp_transport="stdio")
    client = build_mcp_client(settings)
    tools = await client.list_tools()
    review = next(t for t in tools if t.name == "run_post_trade_review")
    result = await review.ainvoke({"folder_path": str(source.parent)})
    assert "Post-Trade Control Analysis" in str(result)
