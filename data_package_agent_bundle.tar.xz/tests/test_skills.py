import base64
import json
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.tools import ToolException

from mcp_agent_template.agent.multi_agent import AgentSpec, build_agent_tree
from mcp_agent_template.agent.react_agent import build_agent
from mcp_agent_template.config import Settings
from mcp_agent_template.skills.loader import MAX_SKILL_FILE_BYTES, discover_skills
from mcp_agent_template.skills.tools import build_skill_tools, render_skills_overview
from tests.support.models import ScriptedModel
from tests.support.paths import redirect_path_resolution


@pytest.fixture
def skills_root(tmp_path):
    for name, body in [
        ("catalog_search", "Search the catalog."),
        ("tool_authoring", "Follow this checklist when authoring tools."),
    ]:
        directory = tmp_path / name
        directory.mkdir()
        (directory / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: Demo skill.\n---\n{body}\n",
            encoding="utf-8",
        )
    return tmp_path


def test_discovers_fixture_skills(skills_root):
    skills = discover_skills(skills_root)
    names = {s.name for s in skills}
    assert "catalog_search" in names
    assert "tool_authoring" in names
    for s in skills:
        assert s.description
        assert s.instructions


def test_frontmatter_parsing(tmp_path: Path):
    skill_dir = tmp_path / "demo"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(
        "---\nname: demo\ndescription: A demo skill.\n---\n# Body\nDo the thing.\n",
        encoding="utf-8",
    )
    skills = discover_skills(tmp_path)
    assert len(skills) == 1
    assert skills[0].name == "demo"
    assert skills[0].description == "A demo skill."
    assert "Do the thing." in skills[0].instructions


def test_skill_tools_roundtrip(skills_root):
    skills = discover_skills(skills_root)
    tools = build_skill_tools(skills)
    names = {t.name for t in tools}
    assert names == {"list_skills", "load_skill", "read_skill_file"}

    load_skill = next(t for t in tools if t.name == "load_skill")
    out = load_skill.invoke({"name": "tool_authoring"})
    assert "checklist" in out.lower()

    assert "Unknown skill 'nope'" in load_skill.invoke({"name": "nope"})

    assert "catalog_search" in render_skills_overview(skills)


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True], ids=["single-agent", "tree-node"])
async def test_agent_builders_recover_from_unknown_skill(skills_root, tree):
    model = ScriptedModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[{"name": "load_skill", "args": {"name": "absent"}, "id": "failed"}],
            ),
            AIMessage(
                content="",
                tool_calls=[
                    {"name": "load_skill", "args": {"name": "catalog_search"}, "id": "recovered"}
                ],
            ),
            AIMessage(content="Recovered using the available skill."),
        ]
    )
    settings = Settings(_env_file=None, app_root=skills_root, skills_dir=".", obs={"mode": "off"})
    if tree:
        bundle = await build_agent_tree(
            AgentSpec(name="reader", description="Read a skill", model=model),
            settings,
            mcp_tools=[],
        )
    else:
        bundle = await build_agent(settings, model=model, mcp_tools=[])
    result = await bundle.ainvoke("Load the skill, trying another name if unavailable.")
    messages = [message for message in result["messages"] if isinstance(message, ToolMessage)]
    assert [message.tool_call_id for message in messages] == ["failed", "recovered"]
    assert [message.status for message in messages] == ["error", "success"]
    assert "Unknown skill 'absent'" in messages[0].content
    assert "catalog_search" in messages[0].content
    assert "Search the catalog." in messages[1].content
    assert result["messages"][-1].text == "Recovered using the available skill."


@pytest.fixture
def full_skill(tmp_path):
    directory = tmp_path / "my-skill"
    directory.mkdir()
    (directory / "SKILL.md").write_text(
        "---\nname: my-skill\ndescription: A complete skill.\n---\n"
        "Read references/api-guide.md, then use the template and assets.\n",
        encoding="utf-8",
    )
    contents = {
        "references/api-guide.md": "# API guide\nUse the documented endpoint.\n",
        "references/examples.md": "Example: café.\n",
        "references/troubleshooting.md": "Check the input.\n",
        "references/nested/detail.md": "Nested reference.\n",
        "scripts/generate.py": "from pathlib import Path\nPath('executed').touch()\n",
        "scripts/validate.sh": "#!/bin/sh\nprintf 'validated'\n",
        "templates/component.tsx.template": "export const Component = () => <div />;\n",
        "templates/test.spec.ts.template": "test('component', () => {});\n",
        "assets/config.json": '{"enabled": true}\n',
        "assets/logo.png": base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/"
            "l9sAAAAASUVORK5CYII="
        ),
    }
    for relative, content in contents.items():
        path = directory / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content.encode("utf-8") if isinstance(content, str) else content)
    return directory, contents


def _tools_for(directory):
    return {t.name: t for t in build_skill_tools(discover_skills(directory))}


def test_discovers_full_folder_without_eagerly_reading_supporting_files(full_skill, monkeypatch):
    directory, contents = full_skill
    opened = []
    original = Path.open

    def open_file(path, *args, **kwargs):
        opened.append(path)
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", open_file)
    skills = discover_skills(directory.parent)
    assert len(skills) == 1
    skill = skills[0]
    assert skill.root == directory.resolve()
    assert skill.files == tuple(sorted(contents))
    tools = {t.name: t for t in build_skill_tools(skills)}
    loaded = tools["load_skill"].invoke({"name": "my-skill"})
    assert skill.instructions in loaded
    assert str(skill.root) in loaded
    assert all(f"- {relative}" in loaded for relative in contents)
    assert "read_skill_file" in loaded
    assert "Use the documented endpoint." not in loaded
    assert opened == [directory / "SKILL.md"]
    assert not (directory / "executed").exists()


def test_markdown_only_skill_returns_instructions(skills_root):
    """Return instructions directly when the selected skill has no supporting files."""
    tools = _tools_for(skills_root)
    assert tools["load_skill"].invoke({"name": "catalog_search"}) == "Search the catalog."


@pytest.mark.parametrize(
    "path",
    [
        "references/api-guide.md",
        "references/nested/detail.md",
        "references/examples.md",
        "scripts/generate.py",
        "scripts/validate.sh",
        "templates/component.tsx.template",
        "templates/test.spec.ts.template",
        "assets/config.json",
    ],
)
def test_reads_reference_script_template_and_text_asset(full_skill, path):
    directory, contents = full_skill
    result = _tools_for(directory)["read_skill_file"].invoke({"name": "my-skill", "path": path})
    assert result["content"] == contents[path]
    assert result["encoding"] == "utf-8"
    assert result["relative_path"] == path
    assert Path(result["path"]) == directory / path
    assert result["size_bytes"] == len(contents[path].encode("utf-8"))
    assert not (directory / "executed").exists()


def test_reads_binary_asset_losslessly_and_explicit_encoding(full_skill):
    directory, contents = full_skill
    read = _tools_for(directory)["read_skill_file"]
    result = read.invoke({"name": "my-skill", "path": "assets/logo.png"})
    assert result["encoding"] == "base64"
    assert result["mime_type"] == "image/png"
    assert base64.b64decode(result["content"]) == contents["assets/logo.png"]
    assert result["size_bytes"] == len(contents["assets/logo.png"])
    assert "not UTF-8" in read.invoke(
        {"name": "my-skill", "path": "assets/logo.png", "encoding": "utf-8"}
    )
    result = read.invoke(
        {"name": "my-skill", "path": "references/examples.md", "encoding": "base64"}
    )
    assert result["encoding"] == "base64"
    assert base64.b64decode(result["content"]) == contents["references/examples.md"].encode("utf-8")


def test_binary_with_valid_utf8_is_base64_and_windows_separators_work(full_skill):
    directory, _ = full_skill
    (directory / "assets/data.bin").write_bytes(b"\x00\x01\x02")
    read = _tools_for(directory)["read_skill_file"]
    result = read.invoke({"name": "my-skill", "path": "assets\\data.bin"})
    assert result["relative_path"] == "assets/data.bin"
    assert result["encoding"] == "base64"
    assert base64.b64decode(result["content"]) == b"\x00\x01\x02"


@pytest.mark.parametrize(
    "path",
    [
        "../secret.txt",
        "..\\secret.txt",
        "references/../../secret.txt",
        "references/../assets/config.json",
        "/etc/passwd",
        "\\secret.txt",
        "C:\\secret.txt",
        "C:secret.txt",
        "\\\\server\\share\\secret.txt",
        "assets/config.json:secret",
        "assets/config.json\x00",
        "",
    ],
)
def test_read_rejects_absolute_paths_and_traversal(full_skill, path):
    directory, _ = full_skill
    assert "relative file path" in _tools_for(directory)["read_skill_file"].invoke(
        {"name": "my-skill", "path": path}
    )


def test_missing_directory_removed_and_unselected_files_are_actionable_errors(full_skill):
    directory, _ = full_skill
    read = _tools_for(directory)["read_skill_file"]
    assert "Unknown skill 'other'" in read.invoke({"name": "other", "path": "assets/config.json"})
    for path in ("assets/missing.json", "assets", "SKILL.md"):
        assert "inventory from load_skill" in read.invoke({"name": "my-skill", "path": path})
    (directory / "assets/config.json").unlink()
    assert "no longer a regular file" in read.invoke(
        {"name": "my-skill", "path": "assets/config.json"}
    )


def test_read_reports_io_failure_with_original_cause(full_skill, monkeypatch):
    directory, _ = full_skill
    read = _tools_for(directory)["read_skill_file"]
    original = Path.open
    error = PermissionError("File is not readable.")

    def open_file(path, *args, **kwargs):
        if path.name == "api-guide.md":
            raise error
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", open_file)
    assert "not readable" in read.invoke({"name": "my-skill", "path": "references/api-guide.md"})
    # The tool handles expected failures; its callback still retains the original cause.
    with pytest.raises(ToolException, match="not readable") as caught:
        read.func(name="my-skill", path="references/api-guide.md")
    assert caught.value.__cause__ is error


def test_file_size_limit_is_explicit_and_does_not_truncate(full_skill):
    directory, _ = full_skill
    path = directory / "assets/large.bin"
    path.write_bytes(b"a" * MAX_SKILL_FILE_BYTES)
    read = _tools_for(directory)["read_skill_file"]
    result = read.invoke({"name": "my-skill", "path": "assets/large.bin", "encoding": "base64"})
    assert base64.b64decode(result["content"]) == path.read_bytes()
    with path.open("ab") as handle:
        handle.write(b"a")
    assert "exceeds the 1048576-byte limit" in read.invoke(
        {"name": "my-skill", "path": "assets/large.bin"}
    )


def test_nested_skill_files_belong_only_to_their_own_skill(full_skill):
    directory, _ = full_skill
    nested = directory / "references/child"
    nested.mkdir()
    (nested / "SKILL.md").write_text("# Child skill\n", encoding="utf-8")
    (nested / "private.md").write_bytes(b"Child reference.\n")
    skills = {skill.name: skill for skill in discover_skills(directory)}
    assert set(skills) == {"my-skill", "child"}
    assert "references/child/private.md" not in skills["my-skill"].files
    assert skills["child"].read_file("private.md") == b"Child reference.\n"
    read = build_skill_tools([skills["my-skill"]])[-1]
    assert "Unknown skill 'child'" in read.invoke({"name": "child", "path": "private.md"})
    assert "Unknown skill file" in read.invoke(
        {"name": "my-skill", "path": "references/child/private.md"}
    )


def test_inventory_excludes_files_and_directories_resolving_outside_skill(
    full_skill, tmp_path, monkeypatch
):
    directory, contents = full_skill
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.txt").write_text("Outside file.\n", encoding="utf-8")
    (directory / "assets/external.txt").write_text("File placeholder.\n", encoding="utf-8")
    external_dir = directory / "assets/external-dir"
    external_dir.mkdir()
    (external_dir / "secret.txt").write_text("Directory placeholder.\n", encoding="utf-8")
    # An external SKILL.md must not leak into discovery either.
    external_skill = directory / "external-skill"
    external_skill.mkdir()
    (external_skill / "SKILL.md").write_text("# External skill\n", encoding="utf-8")
    redirect_path_resolution(
        monkeypatch,
        {
            directory / "assets/external.txt": outside / "secret.txt",
            external_dir: outside,
            external_skill / "SKILL.md": outside / "secret.txt",
        },
    )
    skills = discover_skills(directory)
    assert [skill.name for skill in skills] == ["my-skill"]
    assert skills[0].files == tuple(sorted(contents))


@pytest.mark.parametrize("redirect", ["file", "directory"])
@pytest.mark.parametrize("scope", ["internal", "external"])
def test_read_rechecks_resolved_targets_after_discovery(
    full_skill, tmp_path, monkeypatch, redirect, scope
):
    directory, _ = full_skill
    read = _tools_for(directory)["read_skill_file"]
    target = (tmp_path if scope == "external" else directory) / "redirected"
    target.mkdir()
    (target / "config.json").write_bytes(b"Redirected file.\n")
    redirects = (
        {directory / "assets/config.json": target / "config.json"}
        if redirect == "file"
        else {directory / "assets": target}
    )
    redirect_path_resolution(monkeypatch, redirects)
    result = read.invoke({"name": "my-skill", "path": "assets/config.json"})
    if scope == "external":
        assert "outside the selected skill folder" in result
    else:
        assert result["content"] == "Redirected file.\n"


def test_read_keeps_original_boundary_when_skill_folder_is_replaced(
    full_skill, tmp_path, monkeypatch
):
    directory, _ = full_skill
    read = _tools_for(directory)["read_skill_file"]
    outside = tmp_path / "outside"
    (outside / "assets").mkdir(parents=True)
    (outside / "assets/config.json").write_text("Outside file.", encoding="utf-8")
    directory.rename(tmp_path / "moved-skill")
    redirect_path_resolution(monkeypatch, {directory: outside})
    assert "outside the selected skill folder" in read.invoke(
        {"name": "my-skill", "path": "assets/config.json"}
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True])
async def test_agent_builders_expose_and_invoke_supporting_file_tools(full_skill, tmp_path, tree):
    directory, contents = full_skill
    model = ScriptedModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[{"name": "load_skill", "args": {"name": "my-skill"}, "id": "load"}],
            ),
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "read_skill_file",
                        "args": {"name": "my-skill", "path": "references/api-guide.md"},
                        "id": "read",
                    }
                ],
            ),
            AIMessage(content="Followed the reference."),
        ]
    )
    settings = Settings(
        _env_file=None, app_root=tmp_path, skills_dir=directory.name, obs={"mode": "off"}
    )
    if tree:
        bundle = await build_agent_tree(
            AgentSpec(
                name="reader", description="Read a skill", model=model, skill_names=["my-skill"]
            ),
            settings,
            mcp_tools=[],
        )
    else:
        bundle = await build_agent(settings, model=model, mcp_tools=[])
    result = await bundle.ainvoke("Use the skill and its API guide.")
    messages = {m.name: m.content for m in result["messages"] if isinstance(m, ToolMessage)}
    assert "references/api-guide.md" in messages["load_skill"]
    assert json.loads(messages["read_skill_file"])["content"] == contents["references/api-guide.md"]
    assert result["messages"][-1].text == "Followed the reference."


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True], ids=["single-agent", "tree-node"])
@pytest.mark.parametrize(
    ("failure", "expected_error"),
    [
        ("unknown_file", "Unknown skill file"),
        ("removed_file", "no longer a regular file"),
        ("unreadable_file", "File is not readable"),
        ("oversized_file", "exceeds the 1048576-byte limit"),
        ("invalid_utf8", "not UTF-8 text"),
        ("traversal", "relative file path"),
        ("unknown_skill", "Unknown skill 'unselected'"),
    ],
)
async def test_agent_builders_recover_from_skill_file_errors(
    full_skill, tmp_path, monkeypatch, tree, failure, expected_error
):
    directory, contents = full_skill
    failing_args = {"name": "my-skill", "path": "references/api-guide.md"}
    if failure == "unknown_file":
        failing_args["path"] = "assets/missing.txt"
    elif failure == "oversized_file":
        failing_args["path"] = "assets/large.bin"
        (directory / failing_args["path"]).write_bytes(b"a" * (MAX_SKILL_FILE_BYTES + 1))
    elif failure == "invalid_utf8":
        failing_args.update(path="assets/logo.png", encoding="utf-8")
    elif failure == "traversal":
        failing_args["path"] = "../secret.txt"
    elif failure == "unknown_skill":
        failing_args["name"] = "unselected"
    model = ScriptedModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[{"name": "read_skill_file", "args": failing_args, "id": "failed"}],
            ),
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "read_skill_file",
                        "args": {"name": "my-skill", "path": "references/examples.md"},
                        "id": "recovered",
                    }
                ],
            ),
            AIMessage(content="Recovered using the available reference."),
        ]
    )
    settings = Settings(
        _env_file=None, app_root=tmp_path, skills_dir=directory.name, obs={"mode": "off"}
    )
    if tree:
        bundle = await build_agent_tree(
            AgentSpec(
                name="reader", description="Read a skill", model=model, skill_names=["my-skill"]
            ),
            settings,
            mcp_tools=[],
        )
    else:
        bundle = await build_agent(settings, model=model, mcp_tools=[])
    if failure == "removed_file":
        (directory / failing_args["path"]).unlink()
    elif failure == "unreadable_file":
        original = Path.open

        def open_file(path, *args, **kwargs):
            if path == directory / failing_args["path"]:
                raise PermissionError("File is not readable.")
            return original(path, *args, **kwargs)

        monkeypatch.setattr(Path, "open", open_file)

    result = await bundle.ainvoke("Read a skill file, using another reference if unavailable.")
    messages = [message for message in result["messages"] if isinstance(message, ToolMessage)]
    assert [message.tool_call_id for message in messages] == ["failed", "recovered"]
    assert [message.name for message in messages] == ["read_skill_file", "read_skill_file"]
    assert [message.status for message in messages] == ["error", "success"]
    assert expected_error in messages[0].content
    assert json.loads(messages[1].content)["content"] == contents["references/examples.md"]
    assert result["messages"][-1].text == "Recovered using the available reference."
