"""Real MCP transport exercises the five-path risk interface without an LLM."""

import asyncio

import pytest

from mcp_agent_template.agent.react_agent import build_mcp_client
from mcp_agent_template.config import Settings
from tests.analysis.risk_support import sgmr_series, write_comment, write_excesses, write_sgmr


async def tool_for(tmp_path):
    settings = Settings(
        _env_file=None,
        app_root=tmp_path / "app",
        analysis_results_dir=str(tmp_path / "reports"),
        obs={"mode": "off"},
    )
    tools = await build_mcp_client(settings).list_tools()
    tool = next(item for item in tools if item.name == "run_risk_metrics_analysis")
    return tool


async def call(tool, args):
    return await tool.ainvoke(
        {"type": "tool_call", "name": tool.name, "args": args, "id": "risk-test"}
    )


async def test_five_path_tool_over_stdio_and_concurrent_artifacts(tmp_path):
    """MCP returns text-only reports with preserved commentary and independent run artifacts."""
    # A joint outlier verifies row-level provenance in the new numerical sections.
    sgmr = write_sgmr(tmp_path / "input.parquet", sgmr_series([5.0] * 39 + [9.0]))
    csv = write_excesses(tmp_path / "events.csv")
    comments = [
        write_comment(tmp_path / f"comment-{i}.md", f"# Free-form source {i}\nRAW-COMMENT-{i}")
        for i in range(3)
    ]
    tool = await tool_for(tmp_path)
    schema = tool.args_schema
    if not isinstance(schema, dict):
        schema = schema.model_json_schema()
    assert schema["required"] == ["sgmr_path"]
    assert set(schema["properties"]) == {
        "sgmr_path",
        "colibris_path",
        "risk_metrics_commentary_path",
        "stress_test_commentary_path",
        "var_svar_commentary_path",
    }
    # Schema field order is not used to bind semantic roles.
    args = {
        "sgmr_path": str(sgmr),
        "colibris_path": str(csv),
        "risk_metrics_commentary_path": str(comments[0]),
        "stress_test_commentary_path": str(comments[1]),
        "var_svar_commentary_path": str(comments[2]),
    }
    results = await asyncio.gather(call(tool, args), call(tool, {"sgmr_path": str(sgmr)}))
    assert all(result.status == "success" for result in results), results
    assert all("Risk Metrics Analysis" in str(result.content) for result in results)
    assert all("## Limit consumption" not in result.text for result in results)
    assert all("## Prioritized follow-up" not in result.text for result in results)
    assert all("## Metric value outliers" in result.text for result in results)
    assert all("## Days with movement and value outliers" in result.text for result in results)
    assert all("| scope |" not in result.text for result in results)
    assert "| excessId | riskMetricName | perimeterMnemonic |" in results[0].text
    assert all("## Executive observations" not in result.text for result in results)
    assert all("## Cross-source reconciliation" not in result.text for result in results)
    for result in results:
        excess_section = result.text.split("## Excess governance\n", 1)[1].split("\n## ", 1)[0]
        assert "source_locator" not in excess_section and "reperformed_usage" not in excess_section
    assert all("## Scope and availability" not in result.text for result in results)
    assert all("## Visualizations" not in result.text for result in results)
    assert all("charts/" not in result.text and "![" not in result.text for result in results)
    assert all(f"RAW-COMMENT-{i}" in results[0].text for i in range(3))
    assert "RAW-COMMENT-" not in results[1].text
    assert "Commentary recognized records" not in results[0].text
    assert "sha256" not in results[0].text
    assert "ROW-2025-02-09" in results[0].text
    reports = list((tmp_path / "reports" / "risk_metrics").glob("*/*.md"))
    assert len(reports) == 2
    assert all(path.with_suffix(".xlsx").is_file() for path in reports)


@pytest.mark.parametrize(
    "condition,expected",
    [
        ("missing", "existing file"),
        ("optional-missing", "existing file"),
        ("corrupt", "Cannot parse sgmr"),
        ("output", "ANALYSIS_RESULTS_DIR"),
    ],
)
async def test_risk_errors_are_actionable_over_stdio(tmp_path, condition, expected):
    source = write_sgmr(tmp_path / "input.parquet")
    args = {"sgmr_path": str(source)}
    if condition == "missing":
        source.unlink()
    if condition == "optional-missing":
        args["colibris_path"] = str(tmp_path / "missing.csv")
    if condition == "corrupt":
        source.write_bytes(b"invalid")
    if condition == "output":
        (tmp_path / "reports").write_text("blocked", encoding="utf-8")
    result = await call(await tool_for(tmp_path), args)
    assert result.status == "error"
    assert expected in str(result.content)
