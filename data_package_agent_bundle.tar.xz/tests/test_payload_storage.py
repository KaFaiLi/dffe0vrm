"""Current-schema concurrency and canonical content through real SQLite readers."""

import asyncio
import json
import sqlite3
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing

import pytest
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import SystemMessage
from langchain_core.tools import tool

from dashboard.server import ObservationDB
from mcp_agent_template.agent import build_agent
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.cli import archive
from mcp_agent_template.observability.privacy import Redactor
from mcp_agent_template.observability.recording import storage
from mcp_agent_template.observability.recording.storage import LocalStore, read_rows
from tests.support.models import RequestModel
from tests.support.observations import events, settings_at


@pytest.mark.parametrize(
    "text",
    ["api_key=synthetic-secret", '{"password": "synthetic-secret"}', "cookie=synthetic-secret;"],
)
def test_repeated_redaction_preserves_credential_markers(text):
    """Re-encoding a safe build receipt cannot change its marker or reveal the source."""
    redactor = Redactor()
    once = redactor.text(text)
    assert "synthetic-secret" not in once
    assert redactor.text(once) == once


def _event(event_id, seq, name, payload, run_id=None):
    return {
        "event_id": event_id,
        "source_seq": seq,
        "event_name": name,
        "payload": payload,
        "process_instance_id": "p",
        "timestamp": seq,
        "run_id": run_id,
        "root_run_id": run_id,
        "trace_id": None,
        "span_id": None,
    }


def test_concurrent_writer_startup_serializes_schema_creation(tmp_path, monkeypatch):
    """Initialize one current schema while two writers start on the same empty database."""
    path = tmp_path / "concurrent.db"
    # Establish WAL before racing schema initialization, not journal-mode changes.
    with closing(sqlite3.connect(path)) as db:
        db.execute("PRAGMA journal_mode=WAL")
    barrier = threading.Barrier(2)
    connect = sqlite3.connect

    class SynchronizedConnection(sqlite3.Connection):
        def execute(self, sql, *args, **kwargs):
            if sql == "BEGIN IMMEDIATE":
                barrier.wait(timeout=5)
            return super().execute(sql, *args, **kwargs)

    def synchronized_connect(*args, **kwargs):
        return connect(*args, **kwargs, factory=SynchronizedConnection)

    monkeypatch.setattr(storage.sqlite3, "connect", synchronized_connect)
    stores = [LocalStore(path, 0), LocalStore(path, 0)]
    try:
        with ThreadPoolExecutor(max_workers=2) as executor:
            starts = [executor.submit(store.start) for store in stores]
            for started in starts:
                started.result(timeout=10)
        payloads = [Redactor().encode({"content": f"writer {i} " * 300}) for i in range(2)]
        for i, store in enumerate(stores):
            assert store.enqueue("event", _event(f"new-{i}", i + 3, "capture.output", payloads[i]))
            assert store.flush()
        assert [
            row["payload"]
            for row in read_rows(
                path, "SELECT payload FROM events WHERE event_id LIKE 'new-%' ORDER BY event_id"
            )
        ] == payloads
        assert read_rows(path, "PRAGMA user_version") == [{"user_version": 2}]
    finally:
        for store in stores:
            store.close()


def test_duplicate_identity_cannot_leave_later_accepted_content_unresolved(tmp_path):
    store = LocalStore(tmp_path / "duplicate.db", 0)
    store.start()
    try:
        first = Redactor().encode({"content": "old " * 1000})
        second = Redactor().encode({"content": "new " * 1000})
        store.enqueue("event", _event("one", 1, "capture.output", first))
        store.enqueue("event", _event("one", 1, "capture.output", second))
        store.enqueue("event", _event("two", 2, "capture.output", second))
        assert store.flush()
        assert [
            r["payload"]
            for r in read_rows(store.path, "SELECT payload FROM events ORDER BY cursor")
        ] == [first, second]
    finally:
        store.close()


def test_current_store_reopens_and_appends_without_rewriting_content(tmp_path):
    """Retain interned payloads across writer restart and expose all records to readers."""
    path = tmp_path / "reopen.db"
    payloads = [Redactor().encode({"content": f"result {i} " * 500}) for i in range(2)]
    for index, payload in enumerate(payloads):
        store = LocalStore(path, 0)
        try:
            store.start()
            assert store.enqueue("event", _event(str(index), index, "capture.output", payload))
            assert store.flush()
        finally:
            store.close()
        assert [
            row["payload"] for row in read_rows(path, "SELECT payload FROM events ORDER BY cursor")
        ] == payloads[: index + 1]
        with closing(ObservationDB(path).connect()) as db:
            assert db.execute("SELECT count(*) FROM captures").fetchone()[0] == index + 1


def test_schema_creation_failure_rolls_back_and_allows_a_fresh_start(tmp_path, monkeypatch):
    """A DDL failure leaves no partial current schema or version marker behind."""
    path = tmp_path / "initialization.db"
    connect = sqlite3.connect

    class FailingConnection(sqlite3.Connection):
        """Fail after initial table creation while retaining real SQLite transactions."""

        def execute(self, sql, *args, **kwargs):
            """Simulate a schema creation error before payload storage is initialized."""
            if "CREATE TABLE payload_parts" in sql:
                raise sqlite3.OperationalError("synthetic schema creation failure")
            return super().execute(sql, *args, **kwargs)

    with monkeypatch.context() as patch:
        patch.setattr(
            storage.sqlite3,
            "connect",
            lambda *args, **kw: connect(*args, **kw, factory=FailingConnection),
        )
        failed = LocalStore(path, 0)
        with pytest.raises(RuntimeError, match="initialize"):
            failed.start()
        assert not failed.thread.is_alive()
    with closing(connect(path)) as db:
        assert db.execute("PRAGMA user_version").fetchone()[0] == 0
        assert db.execute("SELECT name FROM sqlite_master").fetchall() == []
    store = LocalStore(path, 0)
    try:
        store.start()
        assert read_rows(path, "SELECT count(*) AS n FROM events") == [{"n": 0}]
    finally:
        store.close()


def test_content_is_stored_once_and_plain_sql_reconstructs_exact_envelopes(tmp_path):
    store = LocalStore(tmp_path / "content.db", 0)
    store.start()
    content = 'Unicode 世界; escaped "quotes", \\ and\nnewlines. ' * 300
    payloads = [
        Redactor().encode({"request": i, "content": content, "artifact": [content]})
        for i in range(4)
    ]
    try:
        for i, payload in enumerate(payloads):
            store.enqueue("event", _event(str(i), i, "capture.stream", payload))
        assert store.flush()
        # Query while the writer owns a live WAL connection; no Python resolver.
        with closing(ObservationDB(store.path).connect()) as db:
            assert [
                r[0] for r in db.execute("SELECT payload FROM events ORDER BY cursor")
            ] == payloads
            assert db.execute("SELECT count(*) FROM captures").fetchone()[0] == 4
            assert db.execute("SELECT count(*) FROM payload_parts").fetchone()[0] == 1
            actual = db.execute(
                "SELECT (SELECT sum(length(CAST(payload AS BLOB))) FROM _events) + "
                "(SELECT sum(length(CAST(payload AS BLOB))) FROM payload_parts)"
            ).fetchone()[0]
            assert actual < sum(len(p.encode()) for p in payloads) // 2
        assert store.health()["unrecorded"] == 0
    finally:
        store.close()


def test_redacted_content_and_pre_policy_differences_survive_real_recording_and_export(
    tmp_path, monkeypatch
):
    """Preserve redacted content and distinct input stages in current recordings and exports."""
    monkeypatch.setenv("SYNTHETIC_API_KEY", "not-a-real-secret")
    content = "synthetic result not-a-real-secret " * 2500

    class ApplicationDirective(AgentMiddleware):
        async def awrap_model_call(self, request, handler):
            return await handler(
                request.override(
                    messages=[SystemMessage(content="application " * 1000), *request.messages]
                )
            )

    @tool
    def lookup(label: str) -> str:
        """Return a synthetic large result."""
        return content

    async def run():
        settings = settings_at(tmp_path)
        async with ObservabilityRuntime.local(settings) as obs:
            bundle = await build_agent(
                settings,
                model=RequestModel(names=["lookup"]),
                mcp_tools=[],
                extra_tools=[lookup],
                observability=obs,
                middleware=(ApplicationDirective(),),
            )
            result = await bundle.ainvoke("hello")
            assert result["messages"][-1].text == "done:hello"
            assert await obs.aflush()
            run_id = events(obs, "run.started")[0]["run_id"]
            exported = archive(obs.path, run_id)
            outputs = [e for e in exported["events"] if e["event_name"] == "capture.output"]
            assert outputs[0]["payload"]["data"]["messages"][-2]["content"] == obs.redactor.text(
                content
            )
            original = events(obs, "model.round.started")[0]["data"]
            effective = events(obs, "capture.model_request")[0]["data"]
            assert original["stage"] == "round_input"
            assert effective["stage"] == "effective_request"
            assert not any("application " in m["content"] for m in original["messages"])
            assert effective["messages"][0]["content"] == "application " * 1000
            assert "not-a-real-secret" not in json.dumps(exported)
            with closing(ObservationDB(obs.path).connect()) as db:
                assert db.execute(
                    "SELECT payload FROM captures WHERE event_id=?", (outputs[0]["event_id"],)
                ).fetchone()[0] == json.dumps(outputs[0]["payload"], ensure_ascii=False)
                assert db.execute("SELECT count(*) FROM payload_parts").fetchone()[0] >= 1

    asyncio.run(run())


def test_redaction_cache_is_bounded_and_tracks_each_path(tmp_path):
    redactor = Redactor(("synthetic-secret",))
    text = "synthetic-secret " * 300
    projected, paths = redactor.project({"left": text, "right": text})
    assert "synthetic-secret" not in projected["left"]
    assert paths == ["$/left", "$/right"]
    for i in range(100):
        redactor.text(f"{i}:" + "x" * 20000)
    assert redactor._text_cache_bytes <= redactor._text_cache_limit
