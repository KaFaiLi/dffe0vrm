"""Project file discovery, public MCP defaults and deterministic containment checks."""

import stat
from pathlib import Path
from unittest.mock import Mock

import pytest
from fastmcp import Client
from fastmcp.exceptions import ToolError

from mcp_agent_template.config import Settings
from mcp_agent_template.mcp_server.server import build_server
from mcp_agent_template.mcp_server.tools.filesystem_tools import _list_files


def settings_at(root: Path) -> Settings:
    """Build isolated server settings with recording disabled and no environment file."""
    return Settings(_env_file=None, app_root=root, obs={"mode": "off"})


async def test_file_discovery_mcp_defaults_and_recursive_project_relative_paths(tmp_path):
    """MCP returns sorted files, includes hidden names and resolves folders against APP_ROOT."""
    (tmp_path / "inputs" / "nested").mkdir(parents=True)
    (tmp_path / "empty").mkdir()
    for relative in ("z.csv", ".hidden", "inputs/a.csv", "inputs/nested/b.csv"):
        (tmp_path / relative).write_text("Synthetic content", encoding="utf-8")
    async with Client(build_server(settings_at(tmp_path))) as client:
        default = await client.call_tool("list_files", {})
        assert default.data == {
            "folder_path": ".",
            "recursive": False,
            "files": [".hidden", "z.csv"],
        }
        recursive = await client.call_tool(
            "list_files", {"folder_path": "inputs", "recursive": True}
        )
        assert recursive.data == {
            "folder_path": "inputs",
            "recursive": True,
            "files": ["inputs/a.csv", "inputs/nested/b.csv"],
        }
        absolute = await client.call_tool("list_files", {"folder_path": str(tmp_path / "inputs")})
        assert absolute.data["files"] == ["inputs/a.csv"]
        empty = await client.call_tool("list_files", {"folder_path": "empty"})
        assert empty.data["files"] == []


@pytest.mark.parametrize(
    "path", ["", " ", "bad\x00path", "..", "../outside", "missing", "data.csv"]
)
def test_file_discovery_rejects_invalid_or_outside_directories(tmp_path, path):
    """Invalid paths never return files from outside the root or from a partial traversal."""
    (tmp_path / "data.csv").write_text("Synthetic", encoding="utf-8")
    with pytest.raises(ToolError):
        _list_files(settings_at(tmp_path), path, True)


def test_file_discovery_skips_simulated_links_and_junctions(tmp_path, monkeypatch):
    """Simulate link metadata without requiring Windows symlink privileges."""
    for name in ("link", "junction"):
        (tmp_path / name).mkdir()
        (tmp_path / name / "hidden.csv").write_text("Synthetic", encoding="utf-8")
    (tmp_path / "visible.csv").write_text("Synthetic", encoding="utf-8")
    real_lstat = Path.lstat
    real_junction = Path.is_junction

    def lstat(path, *args, **kwargs):
        """Mark one real directory as a symlink for the traversal exclusion check."""
        if path == tmp_path / "link":
            return Mock(st_mode=stat.S_IFLNK)
        return real_lstat(path, *args, **kwargs)

    def junction(path):
        """Mark one real directory as a junction without changing other path resolution."""
        return path == tmp_path / "junction" or real_junction(path)

    monkeypatch.setattr(Path, "lstat", lstat)
    monkeypatch.setattr(Path, "is_junction", junction)
    result = _list_files(settings_at(tmp_path), ".", True)
    assert result["files"] == ["visible.csv"]


def test_file_discovery_rejects_resolved_entry_escape(tmp_path, monkeypatch):
    """A simulated resolved path outside APP_ROOT aborts enumeration."""
    entry = tmp_path / "escape.csv"
    entry.write_text("Synthetic", encoding="utf-8")
    resolve = Path.resolve

    def redirected(path, *args, **kwargs):
        """Resolve only the synthetic entry outside the project."""
        return tmp_path.parent / "outside.csv" if path == entry else resolve(path, *args, **kwargs)

    monkeypatch.setattr(Path, "resolve", redirected)
    with pytest.raises(ToolError, match="outside the project"):
        _list_files(settings_at(tmp_path), ".", True)


def test_file_discovery_never_returns_partial_listing(tmp_path, monkeypatch):
    """An enumeration failure after a regular entry raises instead of returning that entry."""
    entry = tmp_path / "first.csv"
    entry.write_text("Synthetic", encoding="utf-8")

    def incomplete(path):
        """Yield one existing file before a deterministic storage failure."""
        yield entry
        raise PermissionError("Synthetic enumeration failure")

    monkeypatch.setattr(Path, "iterdir", incomplete)
    with pytest.raises(ToolError, match="No partial result"):
        _list_files(settings_at(tmp_path), ".", True)
