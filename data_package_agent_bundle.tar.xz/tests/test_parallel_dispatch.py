"""Active parallel policy through the shared Responses wrapper and request capture."""

import json
from types import SimpleNamespace

import pytest
from langchain.agents.middleware import AgentMiddleware, ModelRequest
from langchain_core.messages import HumanMessage

from mcp_agent_template.agent import AgentSpec, RunContext, build_agent, build_agent_tree
from mcp_agent_template.agent.runtime.middleware import RuntimePolicyMiddleware
from mcp_agent_template.llm import get_chat_model
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.capture.middleware import EffectiveRequestMiddleware
from tests.support.models import RequestModel
from tests.support.observations import events, settings_at


class ApplicationModelSettings(AgentMiddleware):
    """Supply application options before the runtime enforces parallel dispatch."""

    async def awrap_model_call(self, request, handler):
        """Keep the caller's explicit output limit while overriding parallelism."""
        return await handler(
            request.override(model_settings={"parallel_tool_calls": False, "max_output_tokens": 32})
        )


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True])
async def test_parallel_dispatch_reaches_shared_responses_and_recording(
    tmp_path, monkeypatch, tree
):
    """Both builders enforce parallelism through the current wrapper without mutating options."""
    provider = pytest.importorskip("socgenai_llm.chat_model")
    Response = pytest.importorskip("openai.types.responses").Response
    requests = []

    def respond(*, request):
        """Capture the real wrapper payload and return one synthetic SDK response."""
        requests.append(request)
        return Response.model_validate(
            {
                "id": "resp-synthetic",
                "object": "response",
                "created_at": 1,
                "model": "synthetic",
                "status": "completed",
                "parallel_tool_calls": True,
                "tool_choice": "auto",
                "tools": [],
                "output": [
                    {
                        "type": "message",
                        "id": "msg-synthetic",
                        "status": "completed",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": "complete", "annotations": []}],
                    }
                ],
            }
        )

    # Replace corporate construction; the actual shared wrapper converts requests and results.
    monkeypatch.setattr(
        provider,
        "GenAiApiClient",
        lambda **kwargs: SimpleNamespace(get_genai_response=respond, close=lambda: None),
    )
    settings = settings_at(tmp_path)
    with get_chat_model(
        settings=settings,
        max_retries=0,
        disable_streaming=True,
        model_kwargs={"parallel_tool_calls": False},
    ) as model:
        async with ObservabilityRuntime.local(settings) as obs:
            if tree:
                bundle = await build_agent_tree(
                    AgentSpec(name="root", description="Answer", model=model),
                    settings,
                    mcp_tools=[],
                    middleware=(ApplicationModelSettings(),),
                    observability=obs,
                )
            else:
                bundle = await build_agent(
                    settings,
                    model=model,
                    mcp_tools=[],
                    middleware=(ApplicationModelSettings(),),
                    observability=obs,
                )
            assert await bundle.ask("Complete the task") == "complete"
            assert len(requests) == 1
            assert requests[0]["parallel_tool_calls"] is True
            assert requests[0]["max_output_tokens"] == 32
            assert requests[0]["reasoning"]["summary"] == "detailed"
            assert model.model_kwargs["parallel_tool_calls"] is False
            assert await obs.aflush()
            captured = events(obs, "capture.model_request")[0]["data"]["model_settings"]
            assert captured == {"parallel_tool_calls": True, "max_output_tokens": 32}
            assert json.loads(bundle.definition_json)["data"]["parallel_tools"] is True


def test_sync_model_dispatch_enables_parallelism_without_mutating_request():
    """Preserve settings and one model reservation through the active policy."""
    request = ModelRequest(
        model=RequestModel(names=[]),
        messages=[HumanMessage(content="Complete the task")],
        runtime=SimpleNamespace(context=RunContext()),
        model_settings={"parallel_tool_calls": False, "max_output_tokens": 32},
    )
    effective = RuntimePolicyMiddleware().wrap_model_call(
        request,
        lambda prepared: EffectiveRequestMiddleware().wrap_model_call(
            prepared, lambda dispatched: dispatched
        ),
    )
    assert effective.model_settings == {"parallel_tool_calls": True, "max_output_tokens": 32}
    assert request.model_settings["parallel_tool_calls"] is False
    assert request.runtime.context.budget.model_calls == 1
