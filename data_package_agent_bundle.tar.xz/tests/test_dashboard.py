"""Dashboard behavior with actual agent recordings and the package layout."""

import hashlib
import json
import logging
import sqlite3
import sys
from contextlib import aclosing, closing
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from langchain_core.messages import AIMessage
from langchain_core.tools import tool

from dashboard import server
from dashboard.records import category
from dashboard.server import DEFAULT_DB, ObservationDB
from mcp_agent_template.agent import AgentSpec, build_agent, build_agent_tree
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.recording.storage import LocalStore, read_rows
from tests.support.models import RequestModel, ScriptedModel
from tests.support.observations import settings_at
from tests.test_context_compaction import SummaryModel, _history, _TokenCounter


@pytest.mark.parametrize("tree", [False, True])
async def test_dashboard_reads_definition_and_skills_from_fresh_recording(tmp_path, tree):
    """Both builders retain one definition envelope and distinguish loaded skills."""
    settings = settings_at(tmp_path)
    for name in ("selected", "unused"):
        directory = settings.skills_path / name
        directory.mkdir(parents=True)
        (directory / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: Synthetic {name} skill.\n---\n"
            f"Instructions for {name}.\n",
            encoding="utf-8",
        )
        (directory / "reference.md").write_text("Synthetic reference.", encoding="utf-8")
    model = ScriptedModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {"id": "load-selected", "name": "load_skill", "args": {"name": "selected"}},
                ],
            ),
            AIMessage(content="Recorded answer."),
        ]
    )
    # Build outside recording: the invocation must carry its complete definition.
    if tree:
        bundle = await build_agent_tree(
            AgentSpec("agent", "Synthetic agent", model=model), settings, mcp_tools=[]
        )
    else:
        bundle = await build_agent(settings, model=model, mcp_tools=[])
    await bundle.ask("Use the selected skill.")
    path = settings.resolve_path(settings.obs.dir) / "observability.sqlite3"
    run_id = read_rows(path, "SELECT run_id FROM runs")[0]["run_id"]
    observations = ObservationDB(path)
    requests = observations.requests(run_id, after=0, limit=50)["items"]
    detail = observations.request(run_id, requests[-1]["cursor"])
    definition = detail["definition"]["payload"]["data"]
    assert definition["system_prompt"] == bundle.system_prompt
    assert "data" not in definition
    assert definition["skills"] == json.loads(bundle.definition_json)["data"]["skills"]
    assert {skill["name"] for skill in definition["skills"]} == {"selected", "unused"}
    skills = {skill["name"]: skill for skill in detail["skills"]}
    assert skills["selected"]["loaded"] is True
    assert skills["selected"]["presence"] == "present"
    assert skills["unused"]["loaded"] is False
    assert skills["unused"]["presence"] == "not_loaded"
    assert skills["selected"]["files"] == ["reference.md"]


async def test_recorded_definition_preserves_build_redaction_paths(tmp_path):
    """Reusing a safe build receipt retains its redaction provenance in one envelope."""
    bundle = await build_agent_tree(
        AgentSpec(
            "agent",
            "Synthetic agent",
            model=ScriptedModel(responses=[AIMessage(content="done")]),
            system_prompt_extra="Synthetic credential: api_key=synthetic-test-secret",
        ),
        settings_at(tmp_path),
        mcp_tools=[],
    )
    receipt = json.loads(bundle.definition_json)
    assert "$/system_prompt" in receipt["redactions"]
    await bundle.ask("Synthetic task")
    path = bundle.settings.resolve_path(bundle.settings.obs.dir) / "observability.sqlite3"
    encoded = read_rows(
        path, "SELECT payload FROM events WHERE event_name='capture.run_definition'"
    )[0]["payload"]
    assert "synthetic-test-secret" not in encoded
    recorded = json.loads(encoded)
    assert recorded["data"]["system_prompt"] == receipt["data"]["system_prompt"]
    assert set(receipt["redactions"]) <= set(recorded["redactions"])


def test_dashboard_default_database_belongs_to_agent_package():
    root = Path(__file__).resolve().parents[1]
    assert DEFAULT_DB == root / ".mcp_agent_template/observability/observability.sqlite3"


@pytest.mark.parametrize("explicit_db", [False, True])
def test_dashboard_database_environment_and_command_line_precedence(
    tmp_path, monkeypatch, explicit_db
):
    """Select the configured path using fresh current-schema recordings."""
    environment_db = tmp_path / "environment.sqlite3"
    command_line_db = tmp_path / "command-line.sqlite3"
    for path in (environment_db, command_line_db):
        store = LocalStore(path, 0)
        try:
            store.start()
        finally:
            store.close()
    monkeypatch.setenv("MCP_AGENT_TEMPLATE_OBS_DB", str(environment_db))
    arguments = ["dashboard/server.py", "--port", "0"]
    if explicit_db:
        arguments.extend(["--db", str(command_line_db)])
    monkeypatch.setattr(sys, "argv", arguments)
    handler_factory = MagicMock()
    http_server = MagicMock(server_port=0)
    server_factory = MagicMock(return_value=http_server)
    monkeypatch.setattr(server, "make_handler", handler_factory)
    monkeypatch.setattr(server, "ThreadingHTTPServer", server_factory)

    server.main()

    selected = handler_factory.call_args.args[0]
    assert selected.path == (command_line_db if explicit_db else environment_db)
    server_factory.assert_called_once_with(("127.0.0.1", 0), handler_factory.return_value)
    http_server.serve_forever.assert_called_once()
    http_server.server_close.assert_called_once()


@pytest.mark.asyncio
async def test_dashboard_reads_actual_agent_recording_without_changes(tmp_path):
    @tool
    async def lookup(label: str) -> str:
        """Return the supplied label and record a diagnostic message."""
        logging.getLogger(__name__).warning("Recorded lookup for %s", label)
        return label

    async with ObservabilityRuntime.local(settings_at(tmp_path)) as recording:
        bundle = await build_agent(
            recording.settings,
            model=RequestModel(names=["lookup"]),
            mcp_tools=[],
            extra_tools=[lookup],
            observability=recording,
        )
        assert await bundle.ask("dashboard query") == "done:dashboard query"
        assert await recording.aflush()
        run_id = read_rows(recording.path, "SELECT run_id FROM runs")[0]["run_id"]
        observations = ObservationDB(recording.path)
        handled, live = observations.inspect("/api/database")
        assert handled and live["read_only"]
        assert live["counts"]["runs"] == 1

    before = hashlib.sha256(recording.path.read_bytes()).hexdigest()
    handled, conversation = observations.inspect(f"/api/runs/{run_id}/conversation")
    assert handled
    assert any(item["preview"] == "done:dashboard query" for item in conversation["items"])
    handled, usage = observations.inspect(f"/api/runs/{run_id}/usage")
    assert handled and usage["reconciliation"] == "agrees"
    assert usage["total"]["model_calls"] == 2
    assert usage["total"]["input_tokens"] == 8
    assert usage["total"]["output_tokens"] == 4
    handled, tools = observations.inspect(f"/api/runs/{run_id}/tools")
    assert handled and tools["items"][0]["name"] == "lookup"
    assert tools["items"][0]["status"] == "completed"
    requests = observations.requests(run_id, 0, 100)
    assert len(requests["items"]) == 2
    assert all(observations.request(run_id, item["cursor"]) for item in requests["items"])
    assert observations.global_logs(0, 100)["items"]
    assert observations.inspect("/api/processes")[1]["items"]
    metrics = observations.inspect("/api/metrics")[1]["items"]
    metric_names = {
        metric["name"]
        for item in metrics
        for metric in observations.inspect(f"/api/metrics/{item['collection_id']}")[1]["series"]
    }
    assert {
        "mcp_agent_template.model.calls",
        "mcp_agent_template.model.tokens",
        "mcp_agent_template.tool.calls",
        "mcp_agent_template.run.count",
        "mcp_agent_template.telemetry.written_records",
    } <= metric_names
    assert all(name.startswith("mcp_agent_template.") for name in metric_names)
    assert category("mcp_agent_template.telemetry.written_records") == "recorder"
    spans = observations.inspect(f"/api/runs/{run_id}/spans")[1]["items"]
    assert spans
    assert any(item["run_id"] == run_id for item in spans)
    attributes = [
        observations.inspect(f"/api/traces/{item['trace_id']}/spans/{item['span_id']}")[1][
            "payload"
        ]["data"]["attributes"]
        for item in spans
    ]
    model_spans = [item for item in attributes if "gen_ai.operation.name" in item]
    assert len(model_spans) == 2
    assert all(item["mcp_agent_template.run_id"] == run_id for item in model_spans)
    assert all(
        item["mcp_agent_template.mapping_version"] == "mcp_agent_template-v1"
        for item in model_spans
    )
    with closing(observations.connect()) as database:
        with pytest.raises(sqlite3.OperationalError, match="readonly"):
            database.execute("DELETE FROM processes")
    assert hashlib.sha256(recording.path.read_bytes()).hexdigest() == before
    assert not Path(str(recording.path) + "-wal").exists()
    assert not Path(str(recording.path) + "-shm").exists()


@pytest.mark.asyncio
async def test_dashboard_projects_thinking_and_request_from_actual_recording(tmp_path):
    message = AIMessage(
        content=[
            {"type": "reasoning", "reasoning": "Compare the recorded facts."},
            {"type": "text", "text": "Recorded answer."},
        ],
        usage_metadata={"input_tokens": 7, "output_tokens": 3, "total_tokens": 10},
    )
    async with ObservabilityRuntime.local(settings_at(tmp_path)) as recording:
        bundle = await build_agent(
            recording.settings,
            model=ScriptedModel(responses=[message]),
            mcp_tools=[],
            observability=recording,
        )
        await bundle.ask("synthetic dashboard check")
        assert await recording.aflush()
        run_id = read_rows(recording.path, "SELECT run_id FROM runs")[0]["run_id"]
    observations = ObservationDB(recording.path)
    before = hashlib.sha256(recording.path.read_bytes()).hexdigest()
    conversation = observations.inspect(f"/api/runs/{run_id}/conversation")[1]
    assistant = next(item for item in conversation["items"] if item["role"] == "assistant")
    assert assistant["preview"] == "Recorded answer."
    assert assistant["thinking_preview"] == "Compare the recorded facts."
    timeline = observations.inspect(f"/api/runs/{run_id}/thinking")[1]
    assert timeline["summary_calls"] == 1
    detail = observations.request(run_id, timeline["items"][0]["request_cursor"])
    assert detail["native"]["payload"]["data"]["messages"]
    assert detail["coverage"]["provider_http_body"] == "not_observed"
    assert (
        detail["response_messages"][0]["presentation"]["thinking_summary"]
        == assistant["thinking_preview"]
    )
    assert hashlib.sha256(recording.path.read_bytes()).hexdigest() == before


@pytest.mark.parametrize("streaming", [False, True])
async def test_dashboard_compaction_keeps_summary_calls_out_of_graph_transcript(
    tmp_path, monkeypatch, streaming
):
    def counter(self, model):
        self.encoding = None
        self.method = "conservative:utf8-bytes"

    monkeypatch.setattr(_TokenCounter, "__init__", counter)
    settings = settings_at(
        tmp_path,
        skills_dir="compaction-test-skills",
        context_compaction={"input_token_budget": 12000},
    )
    async with ObservabilityRuntime.local(settings) as recording:
        bundle = await build_agent(
            settings, model=SummaryModel(), mcp_tools=[], observability=recording
        )
        inputs = {"messages": _history()}
        if streaming:
            async with aclosing(bundle.astream(inputs, stream_mode="values")) as stream:
                states = [state async for state in stream]
            result = states[-1]
        else:
            result = await bundle.ainvoke(inputs)
        assert await recording.aflush()
        run_id = read_rows(recording.path, "SELECT run_id FROM runs")[0]["run_id"]

    observations = ObservationDB(recording.path)
    conversation = observations.inspect(f"/api/runs/{run_id}/conversation")[1]
    assert [item["message_id"] for item in conversation["items"]] == [
        message.id for message in result["messages"]
    ]
    timeline = observations.inspect(f"/api/runs/{run_id}/thinking")[1]
    summaries = [call for call in timeline["items"] if call["purpose"] == "summary"]
    assert summaries
    for call in summaries:
        detail = observations.request(run_id, call["request_cursor"])
        assert detail["response_messages"][0]["presentation"]["text"].startswith("Completed work:")
    usage = observations.inspect(f"/api/runs/{run_id}/usage")[1]
    assert usage["reconciliation"] == "agrees"
    assert conversation["usage"]["model_calls"] == len(timeline["items"])
    assert sum(len(group["calls"]) for group in conversation["rounds"]) == len(timeline["items"])


@pytest.mark.parametrize("mode", ["invoke", "stream", "delegated"])
async def test_dashboard_recovers_native_todo_tool_messages(tmp_path, mode):
    todos = [{"content": "Inspect synthetic input", "status": "completed"}]
    model = ScriptedModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[{"id": "todo-call", "name": "write_todos", "args": {"todos": todos}}],
            ),
            AIMessage(content="Recorded answer."),
        ]
    )
    async with ObservabilityRuntime.local(settings_at(tmp_path)) as recording:
        if mode == "delegated":
            parent = ScriptedModel(
                responses=[
                    AIMessage(
                        content="",
                        tool_calls=[
                            {"id": "delegate", "name": "ask_worker", "args": {"task": "work"}}
                        ],
                    ),
                    AIMessage(content="Parent answer."),
                ]
            )
            bundle = await build_agent_tree(
                AgentSpec(
                    "root",
                    "Root",
                    model=parent,
                    sub_agents=[AgentSpec("worker", "Worker", model=model)],
                ),
                recording.settings,
                mcp_tools=[],
                observability=recording,
            )
            parent_result = await bundle.ainvoke("work")
            artifact = next(
                message.artifact for message in parent_result["messages"] if message.type == "tool"
            )
            assert artifact["todos"] == todos
            result = {"messages": artifact["messages"]}
        else:
            bundle = await build_agent(
                recording.settings, model=model, mcp_tools=[], observability=recording
            )
            if mode == "stream":
                async with aclosing(bundle.astream("work", stream_mode="values")) as stream:
                    states = [state async for state in stream]
                result = states[-1]
            else:
                result = await bundle.ainvoke("work")
        assert await recording.aflush()
        runs = read_rows(recording.path, "SELECT run_id,parent_run_id FROM runs")
        run_id = next(
            row["run_id"] for row in runs if bool(row["parent_run_id"]) == (mode == "delegated")
        )

    observations = ObservationDB(recording.path)
    conversation = observations.inspect(f"/api/runs/{run_id}/conversation")[1]
    assert [(item["role"], item["preview"]) for item in conversation["items"]] == [
        ({"human": "user", "ai": "assistant"}.get(message.type, message.type), message.text)
        for message in result["messages"]
    ]
    tool_messages = [item for item in conversation["items"] if item["role"] == "tool"]
    assert len(tool_messages) == 1
    assert tool_messages[0]["tool_call_id"] == "todo-call"
    selected = observations.inspect(
        f"/api/runs/{run_id}/conversation", {"item": [tool_messages[0]["key"]]}
    )[1]
    assert selected["message"]["status"] == "success"
    assert "Inspect synthetic input" in selected["message"]["content"]
    assert selected["sources"][0]["field"] == (
        "data.messages" if mode == "invoke" else "data.result.update.messages"
    )
