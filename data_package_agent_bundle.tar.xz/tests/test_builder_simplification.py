"""Shared preparation and active policy contracts, without provider dispatch."""

import asyncio
import json

import pytest
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool

from mcp_agent_template.agent import AgentSpec, build_agent, build_agent_tree, multi_agent
from mcp_agent_template.agent.runtime.context import RunContext
from mcp_agent_template.observability import ObservabilityRuntime
from tests.support.models import RequestModel, ScriptedModel
from tests.support.observations import events, settings_at


def _skill(path, name, body="Follow the instructions."):
    directory = path / name
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "SKILL.md").write_text(
        f"---\nname: {name}\ndescription: Demo skill.\n---\n{body}\n", encoding="utf-8"
    )


def test_single_agent_and_tree_leaf_share_preparation(tmp_path):
    _skill(tmp_path / "skills", "demo")

    async def run():
        settings = settings_at(tmp_path, skills_dir="skills")
        model = RequestModel(names=[])
        single = await build_agent(settings, model=model, mcp_tools=[])
        leaf = await build_agent_tree(
            AgentSpec(name="agent", description="A leaf", model=model), settings, mcp_tools=[]
        )
        assert single.system_prompt == leaf.system_prompt
        assert single.definition_json == leaf.definition_json
        assert single.build_fingerprint == leaf.build_fingerprint
        assert single.recursion_limit == leaf.recursion_limit
        assert [t.name for t in single.all_tools] == [t.name for t in leaf.all_tools]

    asyncio.run(run())


@pytest.mark.parametrize("concurrency", ["sequential", 1, 2, "parallel", "custom"])
def test_active_tree_child_capacity_and_caller_wrapper(tmp_path, concurrency):
    """Preserve explicit child scheduling under the always-parallel model policy."""

    async def run():
        """Release gated child calls after verifying the requested scheduling mode."""
        first_entered = asyncio.Event()
        second_entered = asyncio.Event()
        second_scheduled = asyncio.Event()
        release = asyncio.Event()
        custom_calls = []
        started = []
        scheduled = []

        @tool
        async def work(label: str) -> str:
            """Hold the first child until the test permits completion."""
            started.append(label)
            first_entered.set()
            if len(started) == 2:
                second_entered.set()
            await release.wait()
            return label

        class Scheduling(AgentMiddleware):
            async def awrap_tool_call(self, request, handler):
                scheduled.append(request.tool_call["name"])
                if len(scheduled) == 2:
                    second_scheduled.set()
                return await handler(request)

        async def custom(request, execute):
            custom_calls.append(request.tool_call["name"])
            return await execute(request)

        mode = custom if concurrency == "custom" else concurrency
        root = AgentSpec(
            name="root",
            description="Root",
            concurrency=mode,
            model=ScriptedModel(
                responses=[
                    AIMessage(
                        content="",
                        tool_calls=[
                            {"name": "ask_a", "args": {"task": "a"}, "id": "a"},
                            {"name": "ask_b", "args": {"task": "b"}, "id": "b"},
                        ],
                    ),
                    AIMessage(content="done"),
                ]
            ),
            sub_agents=[
                AgentSpec(
                    name=name,
                    description=name,
                    model=RequestModel(names=["work"]),
                    extra_tools=[work],
                )
                for name in ("a", "b")
            ],
        )
        settings = settings_at(tmp_path)
        bundle = await build_agent_tree(root, settings, mcp_tools=[], middleware=(Scheduling(),))
        invocation = asyncio.create_task(bundle.ask("delegate"))
        try:
            await asyncio.wait_for(first_entered.wait(), 5)
            await asyncio.wait_for(second_scheduled.wait(), 5)
            if concurrency in ("sequential", 1):
                assert not second_entered.is_set()
            else:
                await asyncio.wait_for(second_entered.wait(), 5)
            release.set()
            assert await asyncio.wait_for(invocation, 5) == "done"
            assert second_entered.is_set()
            if concurrency == "custom":
                assert sorted(custom_calls) == ["ask_a", "ask_b"]
        finally:
            release.set()
            if not invocation.done():
                invocation.cancel()
            await asyncio.gather(invocation, return_exceptions=True)

    asyncio.run(run())


def test_tree_catalog_cache_is_resolved_build_local_and_selections_are_independent(
    tmp_path, monkeypatch
):
    _skill(tmp_path / "skills", "alpha")
    _skill(tmp_path / "skills", "beta")
    discovered = []
    original = multi_agent.discover_skills

    def discover(path):
        discovered.append(path)
        return original(path)

    monkeypatch.setattr(multi_agent, "discover_skills", discover)
    built = {}
    original_tool = multi_agent.make_agent_tool

    def agent_tool(spec, bundle, **kwargs):
        built[spec.name] = bundle
        return original_tool(spec, bundle, **kwargs)

    monkeypatch.setattr(multi_agent, "make_agent_tool", agent_tool)
    model = RequestModel(names=[])
    children = [
        AgentSpec(name="a", description="A", model=model, skill_names=["alpha"]),
        AgentSpec(
            name="b",
            description="B",
            model=model,
            skill_names=["beta"],
            skills_dir="skills/../skills",
        ),
    ]
    root = AgentSpec(name="root", description="Root", model=model, sub_agents=children)

    async def run():
        settings = settings_at(tmp_path, skills_dir="skills")
        first = await build_agent_tree(root, settings, mcp_tools=[])
        assert discovered == [(tmp_path / "skills").resolve()]
        definition = json.loads(first.definition_json)["data"]
        assert {s.name for s in first.skills} == {"alpha", "beta"}
        assert "ask_a" in {t["name"] for t in definition["tools"]}
        assert [s.name for s in built["a"].skills] == ["alpha"]
        assert [s.name for s in built["b"].skills] == ["beta"]
        assert built["a"] is not built["b"]
        _skill(tmp_path / "skills", "gamma")
        second = await build_agent_tree(root, settings, mcp_tools=[])
        assert len(discovered) == 2
        assert {s.name for s in second.skills} == {"alpha", "beta", "gamma"}

    asyncio.run(run())


def test_application_middleware_stays_on_root_and_raw_context_has_no_recording_state(tmp_path):
    calls = []

    class Application(AgentMiddleware):
        async def awrap_model_call(self, request, handler):
            calls.append(request)
            return await handler(request)

    async def run():
        settings = settings_at(tmp_path)
        model = RequestModel(names=[])
        root = await build_agent_tree(
            AgentSpec(
                name="root",
                description="Root",
                model=model,
                sub_agents=[AgentSpec(name="child", description="Child", model=model)],
            ),
            settings,
            mcp_tools=[],
            middleware=(Application(),),
        )
        assert await root.sub_agent_tools[0].ainvoke({"task": "child"}) == "done:child"
        assert not calls
        assert await root.ask("root") == "done:root"
        assert len(calls) == 1
        context = root.new_context()
        assert not hasattr(context, "_observation")
        assert not hasattr(context.child(), "_parent_observation")
        result = await root.agent.ainvoke(
            {"messages": [HumanMessage(content="raw")]}, context=context
        )
        assert result["messages"][-1].text == "done:raw"
        with pytest.raises(ValueError, match="already been used"):
            root.observe_invocation(context=context)
        context = RunContext()
        root.observe_invocation(context=context)
        with pytest.raises(ValueError, match="already been used"):
            root.observe_invocation(context=context)

    asyncio.run(run())


def test_active_builder_preserves_parallel_tool_decisions_and_message_identity(tmp_path):
    executed = []

    @tool
    def first(label: str) -> str:
        """Record the first decision."""
        executed.append("first")
        return label

    @tool
    def second(label: str) -> str:
        """Record the second decision."""
        executed.append("second")
        return label

    async def run():
        settings = settings_at(tmp_path)
        async with ObservabilityRuntime.local(settings) as obs:
            bundle = await build_agent(
                settings,
                model=RequestModel(names=["first", "second"]),
                mcp_tools=[],
                extra_tools=[first, second],
                observability=obs,
            )
            result = await bundle.ainvoke("label")
            assert sorted(executed) == ["first", "second"]
            assert len([m for m in result["messages"] if isinstance(m, ToolMessage)]) == 2
            chosen = next(
                m for m in result["messages"] if isinstance(m, AIMessage) and m.tool_calls
            )
            assert await obs.aflush()
            assert chosen.id == events(obs, "tool.proposed")[0]["data"]["id"]
            assert [call["name"] for call in chosen.tool_calls] == ["first", "second"]

    asyncio.run(run())
