"""Real stdio discovery, errors, report isolation and application-skill loading."""

import asyncio
import json
from pathlib import Path
from shutil import copytree

import pytest
from fastmcp import Client
from fastmcp.exceptions import ToolError
from langchain_core.messages import AIMessage, ToolMessage

from mcp_agent_template.agent.react_agent import build_agent, build_mcp_client
from mcp_agent_template.analysis.pnl import run_pnl_analysis
from mcp_agent_template.config import Settings
from mcp_agent_template.mcp_server.server import build_server
from tests.analysis.pnl_support import dataset
from tests.support.models import ScriptedModel


async def test_pnl_stdio_and_concurrent_reports(tmp_path):
    """Real MCP calls retain the PC/GOP tree and complete isolated report artifacts."""
    paths, *_ = dataset(tmp_path / "input")
    originals = {}
    for key, title in (
        ("pnl_commentary_path", "PnL original"),
        ("income_attribution_commentary_path", "Attribution original"),
    ):
        originals[key] = f"# {title}\n\n## Quarter outside numerical window: 2020Q1\n\n" + (
            "Original **Markdown**, unchanged for agent review.\n\n" * 15
        )
        Path(paths[key]).write_text(originals[key], encoding="utf-8")
    settings = Settings(_env_file=None, app_root=tmp_path, obs={"mode": "off"})
    tools = await build_mcp_client(settings).list_tools()
    tool = next(t for t in tools if t.name == "run_pnl_analysis")
    assert set(tool.args) == set(paths)

    async def call(args):
        """Invoke the discovered tool through the real stdio adapter."""
        return await tool.ainvoke(
            {"type": "tool_call", "name": tool.name, "args": args, "id": "pnl-test"}
        )

    outputs = await asyncio.gather(call(paths), call(paths))
    assert all(isinstance(r, ToolMessage) and r.status == "success" for r in outputs)
    assert all("PnL and Income Attribution Review" in str(r.content) for r in outputs)
    assert all("Currency: EUR" in str(r.content) for r in outputs)
    assert all("Attribution outliers" in str(r.content) for r in outputs)
    assert all("## Attribution series" not in str(r.content) for r in outputs)
    assert all("## Attribution trends" not in str(r.content) for r in outputs)
    assert all("Desk analytical structure" in str(r.content) for r in outputs)
    assert all("PC1 [PC]" in str(r.content) and "G1 [GOP]" in str(r.content) for r in outputs)
    assert all("[PTF]" not in str(r.content) for r in outputs)
    assert all("attribution cumulative checks" not in str(r.content) for r in outputs)
    for response in outputs:
        body = (
            response.content
            if isinstance(response.content, str)
            else "\n".join(item["text"] for item in response.content if item.get("type") == "text")
        )
        assert all(original in body for original in originals.values())
        assert "## Visualizations" not in body and "charts/" not in body and "![" not in body
    reports = list((tmp_path / ".mcp_agent_template/analysis/pnl").glob("*/*.md"))
    assert len(reports) == 2
    assert all(p.with_suffix(".xlsx").is_file() for p in reports)
    assert all(list((p.parent / "charts").glob("*.png")) for p in reports)
    result = await call({**paths, "pnl_path": str(tmp_path / "missing.xlsx")})
    assert result.status == "error"
    assert "existing file" in str(result.content)


@pytest.mark.parametrize("removed", ["review_start", "review_end"])
async def test_removed_review_dates_fail_before_source_loading(tmp_path, removed):
    """Python and MCP reject legacy date filters instead of silently broadening the request."""
    paths = {
        name: str(tmp_path / "missing.csv")
        for name in (
            "income_attribution_path",
            "pnl_path",
            "adjustments_path",
            "validation_history_path",
            "income_attribution_commentary_path",
            "pnl_commentary_path",
        )
    }
    with pytest.raises(TypeError, match=removed):
        run_pnl_analysis(**paths, **{removed: "2026-01-01"})
    settings = Settings(_env_file=None, app_root=tmp_path, obs={"mode": "off"})
    async with Client(build_server(settings)) as client:
        with pytest.raises(ToolError, match="unexpected_keyword_argument"):
            await client.call_tool("run_pnl_analysis", {**paths, removed: "2026-01-01"})
    assert not settings.resolve_path(settings.analysis_results_dir).exists()


async def test_pnl_skill_and_reference_loaded_through_agent(tmp_path):
    """The agent reads the deployed EUR-only contract and both complete references."""
    source = Path(__file__).resolve().parents[1] / "skills/pnl"
    copytree(source, tmp_path / "skills/pnl")
    settings = Settings(_env_file=None, app_root=tmp_path, obs={"mode": "off"})
    calls = [
        ("load_skill", {"name": "pnl"}),
        ("read_skill_file", {"name": "pnl", "path": "references/dataset.md"}),
        ("read_skill_file", {"name": "pnl", "path": "references/interpretation.md"}),
    ]
    model = ScriptedModel(
        responses=[
            AIMessage(content="", tool_calls=[{"name": name, "args": args, "id": str(i)}])
            for i, (name, args) in enumerate(calls)
        ]
        + [AIMessage(content="References loaded.")]
    )
    bundle = await build_agent(settings, model=model, mcp_tools=[])
    assert [s.name for s in bundle.skills] == ["pnl"]
    result = await bundle.ainvoke("Prepare the PnL review.")
    responses = [m for m in result["messages"] if isinstance(m, ToolMessage)]
    assert len(responses) == 3
    assert all(m.status == "success" for m in responses)
    for response, (_, arguments) in zip(responses[1:], calls[1:], strict=True):
        reference = json.loads(response.content)
        assert reference["relative_path"] == arguments["path"]
        assert reference["content"] == (source / arguments["path"]).read_text(encoding="utf-8")
    dataset_contract = json.loads(responses[1].content)["content"]
    assert "Every PnL row must have Currency EUR" in dataset_contract
    assert "all known daily amounts" in dataset_contract
    assert "There are no Attribution series, Attribution trends or Attribution trend history" in (
        dataset_contract
    )
