"""Execute the demo's cells and real four-agent tree with synthetic inputs."""

import ast
import asyncio
import inspect
import json
import sys
import types
from collections import Counter
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.tools import StructuredTool, ToolException
from pydantic import Field, create_model

from mcp_agent_template.agent.multi_agent import build_agent_tree
from mcp_agent_template.analysis.pnl import run_pnl_analysis
from mcp_agent_template.config import Settings
from notebooks.review_reporting import (
    TOPIC_TOOLS,
    RunEvidence,
    build_evidence_catalog,
    capture_run_evidence,
    validate_audit_report,
)
from tests.support.models import ScriptedModel
from tests.test_review_reporting import call, evidence_fixture, report_fixture

PACKAGE = Path(__file__).resolve().parents[1]
NOTEBOOK = PACKAGE / "notebooks" / "market_activity_review.ipynb"


async def execute_cell(source, namespace):
    compiled = compile(source, str(NOTEBOOK), "exec", flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
    result = eval(compiled, namespace)
    if inspect.isawaitable(result):
        await result


def catalog_draft(report, sources, captured):
    """Script a model selection from actual synthetic report rows, without retyping them."""
    catalog = build_evidence_catalog(captured, sources)
    selections = []
    for reference in report["evidence"]:
        key = next(
            key
            for key, record in catalog.items()
            if record.source_id == reference["source_id"] and reference["excerpt"] in record.excerpt
        )
        selections.append({"id": reference["id"], "catalog_id": key})
    return {**report, "evidence": selections}


@pytest.fixture
async def notebook(tmp_path, monkeypatch):
    display = types.ModuleType("IPython.display")
    display.HTML = display.Markdown = lambda value: value
    display.display = display.update_display = lambda *args, **kwargs: None
    monkeypatch.setitem(sys.modules, "IPython.display", display)
    monkeypatch.chdir(PACKAGE)
    content = json.loads(NOTEBOOK.read_text(encoding="utf-8"))
    code = ["".join(c["source"]) for c in content["cells"] if c["cell_type"] == "code"]
    assert all(
        c["outputs"] == [] and c["execution_count"] is None
        for c in content["cells"]
        if c["cell_type"] == "code"
    )
    namespace = {}
    await execute_cell(code[0], namespace)
    # The notebook's editable DATA_ROOT is replaced with self-contained synthetic
    # files before preflight. No repository development dataset is read in tests.
    namespace["DATA_ROOT"] = tmp_path / "input"
    manifest = next(
        node.value
        for node in ast.parse(code[1]).body
        if isinstance(node, ast.Assign)
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "SOURCE_FILES"
    )
    for _, _, _, relative in ast.literal_eval(manifest):
        file = namespace["DATA_ROOT"] / relative
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text("Synthetic preflight fixture only.", encoding="utf-8")
    for cell in code[1:3]:
        await execute_cell(cell, namespace)
    return namespace, code


async def test_preflight_and_disabled_execution_never_construct_provider(notebook):
    """Preflight supplies only source paths for PnL and never requests a date window."""
    namespace, code = notebook

    def forbidden(*args, **kwargs):
        pytest.fail("Provider or graph construction must remain behind RUN_REVIEW.")

    namespace["get_chat_model"] = namespace["build_agent_tree"] = forbidden
    for cell in code[3:]:
        await execute_cell(cell, namespace)
    assert namespace["preflight_ok"]
    assert (
        namespace["topic_arguments"]["pnl"].keys()
        <= inspect.signature(run_pnl_analysis).parameters.keys()
    )
    assert len(namespace["topic_arguments"]["pnl"]) == 6
    assert all(name.endswith("_path") for name in namespace["topic_arguments"]["pnl"])
    assert {source.scope for source in namespace["sources"] if source.topic == "pnl"} == {
        "All supplied dates"
    }
    assert len(namespace["source_hashes"]) == 12
    assert namespace["run_dir"] is None
    assert namespace["report"] is None


async def test_missing_input_prevents_execution(notebook):
    namespace, code = notebook
    Path(namespace["sources"][0].path).unlink()
    await execute_cell(code[1], namespace)
    await execute_cell(code[3], namespace)
    assert not namespace["preflight_ok"]
    with pytest.raises(ValueError, match="preflight"):
        await namespace["execute_review"]()


async def test_catalog_tool_pages_real_report_rows_without_reading_source_files(
    notebook, tmp_path, monkeypatch
):
    namespace, _ = notebook
    sources, output, messages = evidence_fixture(tmp_path)
    namespace.update(sources=sources, run_dir=output, last_state={"messages": messages})
    namespace["topic_arguments"] = {
        message.artifact["agent"]: message.artifact["messages"][0].tool_calls[0]["args"]
        for message in messages
        if isinstance(message, ToolMessage) and message.artifact
    }
    read_text = Path.read_text

    def reports_only(path, *args, **kwargs):
        assert path.resolve().is_relative_to(output.resolve())
        return read_text(path, *args, **kwargs)

    monkeypatch.setattr(Path, "read_text", reports_only)
    lookup = namespace["review_spec"].extra_tools[0]
    result = json.loads(await lookup.ainvoke({"source_id": "PNL", "query": "Source PNL row 1"}))
    assert result["total"] == 1 and result["next_offset"] is None
    assert result["candidates"][0]["source_id"] == "PNL"
    assert "Source PNL row 1" in result["candidates"][0]["excerpt"]
    assert len(result["required_artifacts"]) == 2
    first = json.loads(await lookup.ainvoke({"source_id": "PTC", "page_size": 1}))
    second = json.loads(
        await lookup.ainvoke({"source_id": "PTC", "page_size": 1, "offset": first["next_offset"]})
    )
    assert first["candidates"][0]["catalog_id"] != second["candidates"][0]["catalog_id"]
    assert "manifest" in await lookup.ainvoke({"source_id": "invented"})
    assert "page_size" in await lookup.ainvoke({"source_id": "PNL", "page_size": 51})


@pytest.mark.parametrize("scenario", ["valid", "invalid_json", "cleanup_error"])
async def test_notebook_execution_exports_only_validated_reports(notebook, tmp_path, scenario):
    namespace, code = notebook
    models = []

    class Model:
        closed = False

        def close(self):
            self.closed = True
            if scenario == "cleanup_error" and self is models[0]:
                raise RuntimeError("Synthetic cleanup failure.")

    def model_factory(**kwargs):
        assert kwargs["max_retries"] == 0
        settings = kwargs["settings"]
        assert settings.genai_provider == "socgenai_llm"
        assert settings.genai_use_responses_api
        assert settings.genai_temperature is None
        models.append(Model())
        return models[-1]

    async def build(spec, settings):
        output = Path(settings.analysis_results_dir)
        messages = [
            call("load_skill", {"name": "market-activity-review"}, "load"),
            ToolMessage(content="Review skill loaded.", tool_call_id="load"),
        ]
        for topic, tool in TOPIC_TOOLS.items():
            folder = output / topic
            folder.mkdir()
            body = "\n".join(
                f"Source dataset: {Path(s.path).name}\n"
                f"| {Path(s.path).name} [row=1] | "
                f"Source {s.id} row 1: value 12 EUR; denominator 10. |"
                for s in namespace["sources"]
                if s.topic == topic
            )
            body += f"\nWorkbook: {folder / 'analysis.xlsx'}\nMarkdown: {folder / 'analysis.md'}"
            for suffix in ("xlsx", "md"):
                (folder / f"analysis.{suffix}").write_text(body, encoding="utf-8")
            children = [
                call(tool, namespace["topic_arguments"][topic], f"analysis-{topic}"),
                ToolMessage(content=body, tool_call_id=f"analysis-{topic}"),
            ]
            messages.extend(
                [
                    call(f"ask_{topic}", {"task": "Synthetic topic review"}, topic),
                    ToolMessage(
                        content=body,
                        tool_call_id=topic,
                        artifact={"agent": topic, "messages": children},
                    ),
                ]
            )
        captured = capture_run_evidence(messages, namespace["sources"], output)
        report = report_fixture(namespace["sources"], captured)
        report["run_id"] = namespace["run_id"]
        report = catalog_draft(report, namespace["sources"], captured)
        final = "invalid JSON" if scenario == "invalid_json" else json.dumps(report)
        messages.append(AIMessage(content=final))

        class Bundle:
            all_tools = []

            async def astream(self, *args, **kwargs):
                yield {"messages": messages}

        return Bundle()

    namespace["Settings"] = lambda **kwargs: Settings(
        _env_file=None,
        app_root=tmp_path,
        analysis_results_dir=str(tmp_path / "results"),
        obs={"mode": "off"},
    )
    namespace["get_chat_model"] = model_factory
    namespace["build_agent_tree"] = build
    namespace["RUN_REVIEW"] = True
    namespace["SHOW_TRACE"] = False
    for cell in code[3:]:
        await execute_cell(cell, namespace)
    output = namespace["run_dir"]
    assert len(models) == 4 and all(model.closed for model in models)
    assert (output / "manifest.json").is_file()
    assert (output / "execution.json").is_file()
    execution = json.loads((output / "execution.json").read_text(encoding="utf-8"))
    assert len(execution["analyses"]) == 3
    assert all(analysis["canonical_scope"] for analysis in execution["analyses"])
    assert execution["supporting_artifacts"] == {}
    if scenario == "invalid_json":
        assert (output / "validation_errors.json").is_file()
        assert not (output / "review.json").exists()
        assert namespace["report"] is None
    else:
        stored = json.loads((output / "review.json").read_text(encoding="utf-8"))
        assert stored == namespace["report"].model_dump(mode="json")
        assert (output / "review.md").read_text(encoding="utf-8") == namespace["markdown"]
    assert (output / "cleanup_errors.json").exists() == (scenario == "cleanup_error")


class CapabilityModel(ScriptedModel):
    exposed_tools: list[str] = Field(default_factory=list)

    def bind_tools(self, tools, **kwargs):
        self.exposed_tools = [tool.name for tool in tools]
        return self


@pytest.mark.parametrize("failure", [None, "failed", "timed_out"])
async def test_real_tree_cross_source_followup_and_partial_results(notebook, tmp_path, failure):
    namespace, _ = notebook
    sources = namespace["sources"]
    root = namespace["review_spec"]
    output = tmp_path / "output"
    bodies = {}
    artifact_paths = {}
    for topic in TOPIC_TOOLS:
        folder = output / topic
        topic_paths = [folder / "analysis.md", folder / "analysis.xlsx"]
        body = (
            "\n".join(
                f"Source dataset: {Path(s.path).name}\n"
                f"| {Path(s.path).name} [row=1] | "
                f"Source {s.id} row 1: value 12 EUR; denominator 10. |"
                for s in sources
                if s.topic == topic
            )
            + f"\nMarkdown: {topic_paths[0]}\nWorkbook: {topic_paths[1]}"
        )
        bodies[topic] = body
        if topic != "risk_metrics" or failure is None:
            artifact_paths.update({str(path): topic for path in topic_paths})
    statuses = dict.fromkeys(TOPIC_TOOLS, "completed")
    if failure:
        statuses["risk_metrics"] = failure
    expected_capture = RunEvidence(
        statuses=statuses,
        artifacts=artifact_paths,
        reports=[
            (topic, {source.id for source in sources if source.topic == topic}, body)
            for topic, body in bodies.items()
            if statuses[topic] == "completed"
        ],
    )
    report = report_fixture(sources, expected_capture)
    if failure:
        report["execution_status"] = "partial"
        report["topic_coverage"][1]["status"] = failure
    report = catalog_draft(report, sources, expected_capture)

    started = set()
    barrier = asyncio.Event()
    invocations = Counter()
    tools = []

    def analysis_tool(topic):
        async def analyze(**kwargs):
            invocations[topic] += 1
            started.add(topic)
            if len(started) == 3:
                barrier.set()
            # This fails if child analysis calls do not actually overlap.
            await asyncio.wait_for(barrier.wait(), timeout=5)
            if topic == "risk_metrics" and failure == "failed":
                raise ToolException("Synthetic unavailable source.")
            if topic == "risk_metrics" and failure == "timed_out":
                await asyncio.Event().wait()
            folder = output / topic
            folder.mkdir(parents=True, exist_ok=True)
            for suffix in ("md", "xlsx"):
                (folder / f"analysis.{suffix}").write_text(bodies[topic], encoding="utf-8")
            return bodies[topic]

        schema = create_model(
            f"{topic}Input",
            **{key: (str | None, None) for key in namespace["topic_arguments"][topic]},
        )
        return StructuredTool.from_function(
            coroutine=analyze,
            name=TOPIC_TOOLS[topic],
            description="Synthetic analysis contract.",
            args_schema=schema,
            handle_tool_error=True,
        )

    for spec in root.sub_agents:
        tools.append(analysis_tool(spec.name))
        skill = spec.skill_names[0]
        spec.model = CapabilityModel(
            responses=[
                call("load_skill", {"name": skill}, f"{spec.name}-load"),
                call(
                    "read_skill_file",
                    {"name": skill, "path": "references/dataset.md"},
                    f"{spec.name}-dataset",
                ),
                call(
                    TOPIC_TOOLS[spec.name],
                    namespace["topic_arguments"][spec.name],
                    f"{spec.name}-analysis",
                ),
                AIMessage(content=bodies[spec.name]),
            ]
            + (
                [
                    call("load_skill", {"name": skill}, "risk-followup-load"),
                    AIMessage(
                        content="No case linkage is supplied. Do not rerun unchanged analysis."
                    ),
                ]
                if spec.name == "risk_metrics" and failure is None
                else []
            )
        )
        if failure == "timed_out" and spec.name == "risk_metrics":
            spec.call_timeout = 1.0
    initial = AIMessage(
        content="",
        tool_calls=[
            {
                "name": f"ask_{spec.name}",
                "id": f"delegate-{spec.name}",
                "args": {
                    "task": json.dumps(
                        {
                            "source_manifest": [
                                s.model_dump() for s in sources if s.topic == spec.name
                            ],
                            "tool_arguments": namespace["topic_arguments"][spec.name],
                        }
                    )
                },
            }
            for spec in root.sub_agents
        ],
    )
    root.model = CapabilityModel(
        responses=[
            call("load_skill", {"name": "market-activity-review"}, "main-load"),
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "read_skill_file",
                        "id": f"ref-{name}",
                        "args": {
                            "name": "market-activity-review",
                            "path": f"references/{name}.md",
                        },
                    }
                    for name in ("workflow", "tools-and-data", "checklist")
                ],
            ),
            initial,
        ]
        + (
            [
                call(
                    "ask_risk_metrics",
                    {
                        "task": "Prior evidence: "
                        + bodies["risk_metrics"]
                        + "\nAssess whether this establishes a case-to-trade link; "
                        "do not rerun analysis."
                    },
                    "risk-followup",
                ),
            ]
            if failure is None
            else []
        )
        + [AIMessage(content=json.dumps(report))]
    )
    settings = Settings(
        _env_file=None,
        app_root=PACKAGE,
        analysis_results_dir=str(output),
        obs={"mode": "off"},
    )
    bundle = await build_agent_tree(root, settings, mcp_tools=tools)
    result = await bundle.ainvoke(
        "Review three topics and consolidate the cross-source assessment."
    )
    captured = capture_run_evidence(result["messages"], sources, output)
    validated = validate_audit_report(
        result["messages"][-1].text,
        run_id="synthetic-review",
        sources=sources,
        captured=captured,
        evidence_mode="catalog",
    )
    assert validated.execution_status == ("partial" if failure else "completed")
    assert started == set(TOPIC_TOOLS)
    assert invocations == dict.fromkeys(TOPIC_TOOLS, 1)
    assert not set(TOPIC_TOOLS.values()).intersection(root.model.exposed_tools)
    assert "lookup_review_evidence" in root.model.exposed_tools
    for spec in root.sub_agents:
        assert set(TOPIC_TOOLS.values()).intersection(spec.model.exposed_tools) == {
            TOPIC_TOOLS[spec.name]
        }
        assert not any(name.startswith("ask_") for name in spec.model.exposed_tools)
    skill_outputs = [
        m for m in result["messages"] if isinstance(m, ToolMessage) and m.name == "read_skill_file"
    ]
    assert len(skill_outputs) == 3 and all(m.status == "success" for m in skill_outputs)
