"""Native middleware policy through real compiled agent invocations."""

import asyncio
import json

import pytest
from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool

from mcp_agent_template.agent import AgentSpec, build_agent, build_agent_tree
from mcp_agent_template.agent.runtime.context import RunContext
from mcp_agent_template.agent.runtime.middleware import (
    RuntimePolicyMiddleware,
)
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.capture.middleware import EffectiveRequestMiddleware
from tests.support.models import RequestModel, ScriptedModel
from tests.support.observations import events, settings_at


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True])
@pytest.mark.parametrize("with_skills", [False, True])
async def test_builders_keep_skills_and_child_tools_with_static_todo_guidance(
    tmp_path, tree, with_skills
):
    """Keep tools, prompts, and one runtime policy on every constructed graph."""
    settings = settings_at(tmp_path)
    if with_skills:
        skill_dir = settings.skills_path / "demo"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\nname: demo\ndescription: Demo skill.\n---\nUse the demo tool.\n",
            encoding="utf-8",
        )

    @tool
    async def lookup(label: str) -> str:
        """Return the label for this turn."""
        return label

    model = RequestModel(names=["lookup"])
    async with ObservabilityRuntime.local(settings) as obs:
        if tree:
            bundle = await build_agent_tree(
                AgentSpec(
                    name="root",
                    description="Demo",
                    model=model,
                    extra_tools=[lookup],
                    sub_agents=[
                        AgentSpec(name="child", description="Answer", model=RequestModel(names=[]))
                    ],
                ),
                settings,
                mcp_tools=[],
                observability=obs,
            )
        else:
            bundle = await build_agent(
                settings, model=model, extra_tools=[lookup], mcp_tools=[], observability=obs
            )
        definition = json.loads(bundle.definition_json)["data"]
        assert definition["middleware"] == [
            "ObservationMiddleware",
            "ToolRoundPolicyMiddleware",
            "AgentTodoMiddleware",
            "RuntimePolicyMiddleware",
            "EffectiveRequestMiddleware",
        ]
        assert "PlanningMiddleware" not in definition["middleware"]
        assert definition["middleware"].count("AgentTodoMiddleware") == 1
        assert "planning_directive" not in definition
        assert ("demo: Demo skill." in bundle.system_prompt) is with_skills
        assert "AVAILABLE SKILLS\n" in bundle.system_prompt
        assert "TOOL-CALL POLICY (strict)" not in bundle.system_prompt
        assert "Use the demo tool." not in bundle.system_prompt
        assert definition["parallel_tools"] is True
        tool_names = {tool.name for tool in bundle.all_tools}
        assert {"list_skills", "load_skill", "lookup", "write_todos"} <= tool_names
        assert ("ask_child" in tool_names) is tree
        first = await bundle.ainvoke("first")
        second = await bundle.ainvoke(
            {"messages": [*first["messages"], HumanMessage(content="second")]}
        )
        assert second["messages"][-1].text == "done:second"
        assert len(model.observed) == 4
        for request in model.observed:
            assert [m.text for m in request if isinstance(m, SystemMessage)] == [
                bundle.system_prompt
            ]
        assert not any(isinstance(m, SystemMessage) for m in second["messages"])
        assert await obs.aflush()
        assert not events(obs, "capture.planning_directive")
        definitions = events(obs, "capture.agent_definition")
        assert len(definitions) == (2 if tree else 1)
        assert all(row["data"]["middleware"] == definition["middleware"] for row in definitions)


@pytest.mark.asyncio
@pytest.mark.parametrize("sync", [False, True], ids=["async", "sync"])
async def test_raw_graph_runtime_policy_preserves_single_use_context_and_exact_budgets(sync):
    """Exercise sync and async graphs with exactly enough call budget."""
    effects = []

    @tool
    def lookup(label: str) -> str:
        """Record the one tool operation permitted by the shared budget."""
        effects.append(label)
        return label

    graph = create_agent(
        RequestModel(names=["lookup"]),
        [lookup],
        middleware=[RuntimePolicyMiddleware(), EffectiveRequestMiddleware()],
        context_schema=RunContext,
    )
    context = RunContext(max_tool_calls=1, max_model_calls=2, max_concurrent_tools=1)
    inputs = {"messages": [HumanMessage(content="one operation")]}
    result = (
        graph.invoke(inputs, context=context)
        if sync
        else await graph.ainvoke(inputs, context=context)
    )
    assert result["messages"][-1].text == "done:one operation"
    assert effects == ["one operation"]
    assert context.budget.calls == 1
    assert context.budget.model_calls == 2
    with pytest.raises(ValueError, match="already been used"):
        if sync:
            graph.invoke(inputs, context=context)
        else:
            await graph.ainvoke(inputs, context=context)
    assert effects == ["one operation"]


@pytest.mark.asyncio
async def test_child_delegation_leaves_single_external_slot_available(tmp_path):
    """Complete delegation with one external permit and exactly one shared budget tree."""

    @tool
    async def lookup(label: str) -> str:
        """Return the child's result while it holds the only external permit."""
        return label

    root = AgentSpec(
        name="root",
        description="Delegate one operation.",
        model=ScriptedModel(
            responses=[
                AIMessage(
                    content="",
                    tool_calls=[{"name": "ask_child", "args": {"task": "child"}, "id": "1"}],
                ),
                AIMessage(content="complete"),
            ]
        ),
        sub_agents=[
            AgentSpec(
                name="child",
                description="Perform the lookup.",
                model=RequestModel(names=["lookup"]),
                extra_tools=[lookup],
            )
        ],
    )
    bundle = await build_agent_tree(
        root,
        settings_at(
            tmp_path,
            agent_max_concurrent_tools=1,
            agent_max_tool_calls=2,
            agent_max_model_calls=4,
        ),
        mcp_tools=[],
    )
    context = bundle.new_context()
    assert await asyncio.wait_for(bundle.ask("delegate", context=context), 5) == "complete"
    assert context.budget.calls == 2
    assert context.budget.model_calls == 4


@pytest.mark.asyncio
@pytest.mark.parametrize("mode,limit", [(None, 3), ("sequential", 1), ("parallel", 3), (2, 2)])
async def test_tree_builder_limits_child_execution_without_blocking_regular_tools(
    tmp_path, mode, limit
):
    """Bound child execution while leaving regular tools eligible for their own permits."""
    settings = settings_at(tmp_path)
    started = []
    active = 0
    peak = 0
    capacity_reached = asyncio.Event()
    regular_entered = asyncio.Event()
    release = asyncio.Event()

    @tool
    async def child_work(label: str) -> str:
        """Wait until the parent has filled its configured child capacity."""
        nonlocal active, peak
        active += 1
        peak = max(peak, active)
        started.append(label)
        if active == limit:
            capacity_reached.set()
        try:
            await release.wait()
            return label
        finally:
            active -= 1

    @tool
    async def regular() -> str:
        """Run even while child capacity is occupied."""
        await capacity_reached.wait()
        regular_entered.set()
        return "regular"

    children = [
        AgentSpec(
            name=name,
            description=f"Run child {name}.",
            model=RequestModel(names=["child_work"]),
            extra_tools=[child_work],
        )
        for name in ("a", "b", "c")
    ]
    root = AgentSpec(
        name="root",
        description="Delegate work.",
        **({"concurrency": mode} if mode is not None else {}),
        sub_agents=children,
        extra_tools=[regular],
        model=ScriptedModel(
            responses=[
                AIMessage(
                    content="",
                    tool_calls=[
                        {"name": f"ask_{c.name}", "args": {"task": c.name}, "id": c.name}
                        for c in children
                    ]
                    + [{"name": "regular", "args": {}, "id": "regular"}],
                ),
                AIMessage(content="complete"),
            ]
        ),
    )
    bundle = await build_agent_tree(root, settings, mcp_tools=[])
    pending = asyncio.create_task(bundle.ask("delegate"))
    try:
        await asyncio.wait_for(capacity_reached.wait(), 5)
        await asyncio.wait_for(regular_entered.wait(), 5)
        assert len(started) == limit
    finally:
        release.set()
        answer = await asyncio.wait_for(pending, 5)
    assert answer == "complete"
    assert peak == limit and sorted(started) == ["a", "b", "c"]


@pytest.mark.asyncio
async def test_tree_builder_preserves_custom_concurrency_wrapper(tmp_path):
    """Apply an explicit caller wrapper to child execution without a global policy switch."""
    calls = []

    async def wrapper(request, handler):
        calls.append(request.tool_call["name"])
        return await handler(request)

    root = AgentSpec(
        name="root",
        description="Delegate a question.",
        concurrency=wrapper,
        sub_agents=[AgentSpec(name="child", description="Answer", model=RequestModel(names=[]))],
        model=ScriptedModel(
            responses=[
                AIMessage(
                    content="",
                    tool_calls=[{"name": "ask_child", "args": {"task": "demo"}, "id": "1"}],
                ),
                AIMessage(content="complete"),
            ]
        ),
    )
    bundle = await build_agent_tree(root, settings_at(tmp_path), mcp_tools=[])
    assert await bundle.ask("delegate") == "complete"
    assert calls == ["ask_child"]


@pytest.mark.asyncio
@pytest.mark.parametrize("mode", [0, -1, "bogus"])
async def test_tree_builder_rejects_invalid_child_concurrency(tmp_path, mode):
    """Reject invalid child capacities independently of parallel model decisions."""
    root = AgentSpec(
        name="root",
        description="Delegate a question.",
        concurrency=mode,
        sub_agents=[AgentSpec(name="child", description="Answer", model=RequestModel(names=[]))],
        model=RequestModel(names=[]),
    )
    with pytest.raises(ValueError, match="Child concurrency"):
        await build_agent_tree(root, settings_at(tmp_path), mcp_tools=[])


def test_independent_root_requests_do_not_share_ordering_or_recording(tmp_path):
    started = []
    ready = asyncio.Event()

    @tool
    async def lookup(label: str) -> str:
        """Wait until two independent requests have both started."""
        started.append(label)
        if len(started) == 2:
            ready.set()
        await asyncio.wait_for(ready.wait(), 5)
        return label

    async def run():
        settings = settings_at(tmp_path)
        async with ObservabilityRuntime.local(settings) as obs:
            bundle = await build_agent(
                settings,
                model=RequestModel(names=["lookup"]),
                mcp_tools=[],
                extra_tools=[lookup],
                observability=obs,
            )
            answers = await asyncio.gather(bundle.ask("alpha"), bundle.ask("beta"))
            assert answers == ["done:alpha", "done:beta"]
            assert await obs.aflush()
            starts = events(obs, "run.started")
            labels = {
                row["run_id"]: row["data"]["input"]["messages"][0]["content"] for row in starts
            }
            assert len(labels) == 2
            for row in events(obs, "tool.finished"):
                assert row["data"]["result"]["content"] == labels[row["run_id"]]
            assert not obs.active_scopes and obs.errors == 0

    asyncio.run(run())


def test_tool_budget_is_reserved_before_parallel_side_effects(tmp_path):
    """Reserve the shared tool budget before parallel tools can mutate state."""
    effects = []

    @tool
    async def first(label: str) -> str:
        """Record the first operation."""
        effects.append("first")
        await asyncio.sleep(0)
        return label

    @tool
    async def second(label: str) -> str:
        """Record the second operation."""
        effects.append("second")
        return label

    async def run():
        """Run both proposed tools against one shared reservation and inspect their effects."""
        settings = settings_at(tmp_path, agent_max_tool_calls=1)
        # The runtime reserves the single shared call before either tool runs.
        bundle = await build_agent(
            settings,
            model=RequestModel(names=["first", "second"]),
            mcp_tools=[],
            extra_tools=[first, second],
        )
        state = await bundle.ainvoke("limited")
        assert len(effects) == 1
        assert any(getattr(m, "status", None) == "error" for m in state["messages"])

    asyncio.run(run())


def test_application_middleware_mutation_is_captured_at_effective_dispatch(tmp_path):
    class AddDirective(AgentMiddleware):
        async def awrap_model_call(self, request, handler):
            return await handler(
                request.override(
                    messages=[SystemMessage(content="application directive"), *request.messages]
                )
            )

    async def run():
        settings = settings_at(tmp_path)
        model = RequestModel(names=[])
        async with ObservabilityRuntime.local(settings) as obs:
            bundle = await build_agent(
                settings,
                model=model,
                mcp_tools=[],
                observability=obs,
                middleware=(AddDirective(),),
            )
            assert await bundle.ask("hello") == "done:hello"
            assert await obs.aflush()
            effective = events(obs, "capture.model_request")[0]["data"]
            assert effective["messages"][0]["content"] == "application directive"
            assert effective["stage"] == "effective_request"
            assert model.observed[0][1].text == "application directive"

    asyncio.run(run())


@pytest.mark.parametrize("tree", [False, True])
@pytest.mark.parametrize(
    "reserved_name",
    [
        "ObservationMiddleware",
        "RuntimePolicyMiddleware",
    ],
)
def test_duplicate_names_and_reserved_middleware_fail_before_execution(
    tmp_path, tree, reserved_name
):
    """Reject collisions with active middleware before graph execution."""

    @tool
    def list_skills() -> str:
        """A conflicting application tool."""
        return "conflict"

    async def run():
        settings = settings_at(tmp_path)
        if tree:
            spec = AgentSpec(
                name="root",
                description="Demo",
                model=RequestModel(names=[]),
                extra_tools=[list_skills],
            )
            with pytest.raises(ValueError, match="colliding"):
                await build_agent_tree(spec, settings, mcp_tools=[])
        else:
            with pytest.raises(ValueError, match="Colliding"):
                await build_agent(
                    settings, model=RequestModel(names=[]), mcp_tools=[], extra_tools=[list_skills]
                )

        class Invalid(AgentMiddleware):
            @property
            def name(self):
                """Use the reserved policy name under test."""
                return reserved_name

        with pytest.raises(ValueError, match="reserved"):
            await build_agent(
                settings, model=RequestModel(names=[]), mcp_tools=[], middleware=(Invalid(),)
            )

    asyncio.run(run())


def test_cancellation_releases_gates_and_next_request_succeeds(tmp_path):
    entered = asyncio.Event()
    never = asyncio.Event()

    @tool
    async def lookup(label: str) -> str:
        """Wait only for the request that the test cancels."""
        if label == "cancel":
            entered.set()
            await never.wait()
        return label

    async def run():
        settings = settings_at(tmp_path)
        async with ObservabilityRuntime.local(settings) as obs:
            bundle = await build_agent(
                settings,
                model=RequestModel(names=["lookup"]),
                mcp_tools=[],
                extra_tools=[lookup],
                observability=obs,
            )
            pending = asyncio.create_task(bundle.ask("cancel"))
            await asyncio.wait_for(entered.wait(), 5)
            pending.cancel()
            with pytest.raises(asyncio.CancelledError):
                await pending
            assert not obs.active_scopes
            assert await asyncio.wait_for(bundle.ask("next"), 5) == "done:next"
            assert await obs.aflush()
            assert {row["data"]["completion"] for row in events(obs, "run.finished")} == {
                "cancelled",
                "completed",
            }

    asyncio.run(run())


def test_context_cannot_be_reused(tmp_path):
    async def run():
        settings = settings_at(tmp_path)
        bundle = await build_agent(settings, model=RequestModel(names=[]), mcp_tools=[])
        context = bundle.new_context()
        assert await bundle.ask("first", context=context) == "done:first"
        with pytest.raises(ValueError, match="already been used"):
            await bundle.ask("second", context=context)

    asyncio.run(run())


def test_model_budget_denies_an_extra_dispatch(tmp_path):
    from mcp_agent_template.agent.runtime.context import ModelBudgetExceeded

    @tool
    async def lookup(label: str) -> str:
        """Return the label once."""
        return label

    async def run():
        settings = settings_at(tmp_path, agent_max_model_calls=1)
        model = RequestModel(names=["lookup"])
        bundle = await build_agent(settings, model=model, mcp_tools=[], extra_tools=[lookup])
        with pytest.raises(ModelBudgetExceeded):
            await bundle.ask("limited")
        assert len(model.observed) == 1

    asyncio.run(run())


def test_middleware_tools_are_registered_inspectable_and_executable(tmp_path):
    @tool
    async def application_lookup(label: str) -> str:
        """Look up a label through the application extension."""
        return label

    class ApplicationTools(AgentMiddleware):
        tools = [application_lookup]

    async def run():
        bundle = await build_agent(
            settings_at(tmp_path),
            model=RequestModel(names=["application_lookup"]),
            mcp_tools=[],
            middleware=(ApplicationTools(),),
        )
        assert "application_lookup" in {tool.name for tool in bundle.all_tools}
        assert await bundle.ask("extension") == "done:extension"

    asyncio.run(run())
