"""Provider-native input and summary bounds through the shared Responses wrapper."""

import json
from types import SimpleNamespace

import httpx2
import pytest
from langchain.agents.middleware import ModelRequest
from langchain_core.messages import AIMessage, HumanMessage

from mcp_agent_template.agent.runtime.context import RunContext
from mcp_agent_template.agent.runtime.context_policy import (
    ContextCompactionMiddleware,
    _TokenCounter,
)
from mcp_agent_template.config import ContextCompactionSettings
from mcp_agent_template.observability.semantics import ContextLimitExceeded


@pytest.fixture
def responses_model(monkeypatch):
    OpenAI = pytest.importorskip("openai").OpenAI
    GenAIChatModel = pytest.importorskip("socgenai_llm").GenAIChatModel
    resolve_request = pytest.importorskip("genai_api_manager.api.requests").resolve_request
    bodies = []

    def handle(request):
        bodies.append(json.loads(request.content))
        return httpx2.Response(
            200,
            json={
                "id": "resp-synthetic",
                "object": "response",
                "created_at": 1,
                "model": "synthetic",
                "status": "completed",
                "output": [
                    {
                        "type": "message",
                        "id": "msg-synthetic",
                        "status": "completed",
                        "role": "assistant",
                        "content": [
                            {"type": "output_text", "text": "Completed work.", "annotations": []}
                        ],
                    }
                ],
                "usage": {"input_tokens": 4, "output_tokens": 2, "total_tokens": 6},
            },
        )

    def counter_init(self, model):
        self.encoding = None
        self.method = "conservative:utf8-bytes"

    monkeypatch.setattr(_TokenCounter, "__init__", counter_init)
    with OpenAI(
        api_key="synthetic",
        base_url="https://synthetic.invalid/openai/v1/",
        max_retries=0,
        http_client=httpx2.Client(transport=httpx2.MockTransport(handle)),
    ) as sdk:

        class Manager:
            def get_genai_response(self, request):
                return sdk.responses.create(**resolve_request(request))

        # Replace corporate construction only; use the real shared wrapper,
        # manager request reconciliation and SDK HTTP serialization.
        monkeypatch.setattr("socgenai_llm.chat_model.GenAiApiClient", lambda **kwargs: Manager())

        class NativeOptionsModel(GenAIChatModel):
            instructions: str | None = None
            text: dict | None = None
            extra_body: dict | None = None

            def _params(self, stop=None, **kwargs):
                defaults = {
                    key: getattr(self, key)
                    for key in ("instructions", "text", "extra_body")
                    if getattr(self, key) is not None
                }
                return {**defaults, **super()._params(stop=stop, **kwargs)}

        yield bodies, NativeOptionsModel


def request_with_options(model_type, options, location, messages):
    model = model_type(
        model="synthetic",
        use_responses_api=True,
        reasoning={"summary": "detailed"},
        model_kwargs=options if location == "model" else {},
        **(options if location == "attributes" else {}),
    )
    return ModelRequest(
        model=model,
        messages=messages,
        model_settings=options if location == "request" else {},
        runtime=SimpleNamespace(context=RunContext()),
    )


def dispatch(request):
    return request.model.invoke(request.messages, **request.model_settings)


@pytest.mark.parametrize("location", ["model", "request", "attributes"])
@pytest.mark.parametrize("nested", [False, True])
@pytest.mark.parametrize("kind", ["instructions", "schema"])
def test_provider_native_protected_input_rejected_before_dispatch(
    responses_model, location, nested, kind
):
    bodies, model_type = responses_model
    options = (
        {"instructions": "protected " * 1000}
        if kind == "instructions"
        else {"text": {"format": {"type": "json_schema", "schema": {"description": "x" * 10000}}}}
    )
    if nested:
        options = {"extra_body": options}
    request = request_with_options(model_type, options, location, [HumanMessage(content="current")])
    middleware = ContextCompactionMiddleware(ContextCompactionSettings(input_token_budget=3000))
    with pytest.raises(ContextLimitExceeded):
        middleware.wrap_model_call(request, dispatch)
    assert not bodies
    assert request.runtime.context.budget.model_calls == 0


@pytest.mark.parametrize("location", ["model", "request", "attributes"])
@pytest.mark.parametrize("summary_limit", [None, 100])
def test_nested_options_cannot_override_summary_bounds_or_leak_main_contract(
    responses_model, location, summary_limit
):
    bodies, model_type = responses_model
    options = {
        "instructions": "ORIGINAL_INSTRUCTIONS",
        "extra_body": {
            "max_output_tokens": 9999,
            "tools": [
                {"type": "function", "name": "original_tool", "parameters": {"type": "object"}}
            ],
            "tool_choice": "auto",
            "text": {"format": {"type": "json_object"}},
        },
    }
    request = request_with_options(
        model_type,
        options,
        location,
        [
            HumanMessage(content="old " + "x" * 5000),
            AIMessage(content="y" * 5000),
            HumanMessage(content="current"),
        ],
    )
    middleware = ContextCompactionMiddleware(
        ContextCompactionSettings(input_token_budget=3000, summary_max_tokens=summary_limit)
    )
    middleware.wrap_model_call(request, dispatch)
    assert len(bodies) > 1
    for body in bodies[:-1]:
        if summary_limit is None:
            assert not {"max_tokens", "max_output_tokens", "max_completion_tokens"} & body.keys()
        else:
            assert body["max_output_tokens"] == summary_limit
        assert body.get("tools", []) == []
        assert body["tool_choice"] == "none"
        assert "instructions" not in body
        assert "text" not in body
        assert "ORIGINAL_INSTRUCTIONS" not in json.dumps(body["input"])
        assert body["reasoning"] == {"summary": "detailed"}
    assert bodies[-1]["instructions"] == options["instructions"]
    for key, value in options["extra_body"].items():
        assert bodies[-1][key] == value


@pytest.mark.parametrize("location", ["model", "request", "attributes"])
@pytest.mark.parametrize(
    "key", ["input", "messages", "previous_response_id", "conversation", "prompt"]
)
def test_unbounded_provider_history_is_rejected(responses_model, location, key):
    bodies, model_type = responses_model
    request = request_with_options(
        model_type, {"extra_body": {key: "synthetic"}}, location, [HumanMessage(content="current")]
    )
    middleware = ContextCompactionMiddleware(ContextCompactionSettings(input_token_budget=3000))
    with pytest.raises(ContextLimitExceeded, match="cannot be bounded"):
        middleware.wrap_model_call(request, dispatch)
    assert not bodies
