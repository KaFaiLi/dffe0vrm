"""Tests for the parent/sub-agent tree builder (`agent.multi_agent`)."""

from __future__ import annotations

import asyncio

import pytest
from langchain_core.messages import AIMessage, HumanMessage

from mcp_agent_template.agent.multi_agent import (
    AgentSpec,
    _validate_tree,
    make_agent_tool,
)


# ---------------------------------------------------------------------------
# _validate_tree
# ---------------------------------------------------------------------------
def test_validate_tree_accepts_a_simple_tree():
    root = AgentSpec(
        name="root",
        description="root",
        sub_agents=[AgentSpec(name="a", description="a"), AgentSpec(name="b", description="b")],
    )
    _validate_tree(root)  # must not raise


def test_validate_tree_detects_cycle():
    child = AgentSpec(name="child", description="child")
    root = AgentSpec(name="root", description="root", sub_agents=[child])
    child.sub_agents.append(root)  # manually create a cycle
    with pytest.raises(ValueError, match="Cycle detected"):
        _validate_tree(root)


def test_validate_tree_detects_duplicate_names():
    root = AgentSpec(
        name="root",
        description="root",
        sub_agents=[
            AgentSpec(name="dup", description="one"),
            AgentSpec(
                name="x", description="x", sub_agents=[AgentSpec(name="dup", description="two")]
            ),
        ],
    )
    with pytest.raises(ValueError, match="Duplicate agent name"):
        _validate_tree(root)


def test_validate_tree_detects_sibling_tool_name_collision():
    root = AgentSpec(
        name="root",
        description="root",
        sub_agents=[
            AgentSpec(name="same", description="one"),
            AgentSpec(name="same", description="two"),
        ],
    )
    with pytest.raises(ValueError, match="duplicate tool"):
        _validate_tree(root)


# ---------------------------------------------------------------------------
# make_agent_tool
# ---------------------------------------------------------------------------
class _FakeAgent:
    """Minimal stand-in for a compiled LangGraph agent's ``.astream``."""

    def __init__(
        self,
        answer: str | None = None,
        error: Exception | None = None,
        delay: float = 0.0,
    ):
        self._answer = answer
        self._error = error
        self._delay = delay

    async def astream(self, input, *, config, stream_mode):
        task = input["messages"][0]["content"]
        human = HumanMessage(content=task)
        human.id = "h-1"
        yield {"messages": [human]}
        if self._delay:
            await asyncio.sleep(self._delay)
        if self._error:
            raise self._error
        ai = AIMessage(content=f"{self._answer}:{task}")
        ai.id = "a-1"
        yield {"messages": [human, ai]}


class _FakeBundle:
    """Minimal stand-in for AgentBundle, for tool-wiring tests."""

    def __init__(
        self, answer: str | None = None, error: Exception | None = None, delay: float = 0.0
    ):
        self.agent = _FakeAgent(answer=answer, error=error, delay=delay)

    def _run_config(self) -> dict:
        return {}


@pytest.mark.asyncio
async def test_make_agent_tool_wires_name_and_description():
    spec = AgentSpec(name="researcher", description="Searches things.")
    bundle = _FakeBundle(answer="ok")
    t = make_agent_tool(spec, bundle, default_timeout=5)
    assert t.name == "ask_researcher"
    assert t.description == "Searches things."
    # Direct ainvoke (no tool_call_id) returns just the content, same as any
    # other tool -- the artifact only shows up when invoked via a ToolNode.
    result = await t.ainvoke({"task": "find lamps"})
    assert result == "ok:find lamps"


@pytest.mark.asyncio
async def test_make_agent_tool_captures_nested_trace_as_artifact():
    spec = AgentSpec(name="researcher", description="Searches things.")
    bundle = _FakeBundle(answer="ok")
    t = make_agent_tool(spec, bundle, default_timeout=5)

    content, artifact = await t.coroutine(task="find lamps")
    assert content == "ok:find lamps"
    assert artifact["agent"] == "researcher"
    # Both the injected human turn and the final AI answer were captured.
    assert len(artifact["messages"]) == 2
    assert isinstance(artifact["messages"][0], HumanMessage)
    assert isinstance(artifact["messages"][1], AIMessage)


class _FakeReasoningV1Agent:
    async def astream(self, input, *, config, stream_mode):
        human = HumanMessage(content=input["messages"][0]["content"])
        human.id = "h-v1"
        assistant = AIMessage(
            content=[
                {"type": "reasoning", "reasoning": "I found matching items."},
                {"type": "text", "text": "Found two lamp items."},
            ],
            response_metadata={"output_version": "v1"},
        )
        assistant.id = "a-v1"
        yield {"messages": [human]}
        yield {"messages": [human, assistant]}


class _FakeReasoningV1Bundle:
    agent = _FakeReasoningV1Agent()

    def _run_config(self) -> dict:
        return {}


class _FakeUpdatingAgent:
    async def astream(self, input, *, config, stream_mode):
        human = HumanMessage(content=input["messages"][0]["content"], id="h-update")
        draft = AIMessage(
            content="",
            tool_calls=[{"name": "lookup", "args": {}, "id": "call-update"}],
            id="a-update",
        )
        final = AIMessage(content="Updated final answer.", id="a-update")
        yield {"messages": [human]}
        yield {"messages": [human, draft]}
        yield {"messages": [human, final]}


class _FakeUpdatingBundle:
    agent = _FakeUpdatingAgent()

    def _run_config(self) -> dict:
        return {}


@pytest.mark.asyncio
async def test_make_agent_tool_returns_v1_text_and_keeps_reasoning_in_artifact():
    spec = AgentSpec(name="researcher", description="Searches things.")
    t = make_agent_tool(spec, _FakeReasoningV1Bundle(), default_timeout=5)

    content, artifact = await t.coroutine(task="find lamps")

    assert content == "Found two lamp items."
    assert artifact["messages"][-1].content_blocks[0] == {
        "type": "reasoning",
        "reasoning": "I found matching items.",
    }


@pytest.mark.asyncio
async def test_make_agent_tool_replaces_updated_messages_with_same_id():
    spec = AgentSpec(name="researcher", description="Searches things.")
    t = make_agent_tool(spec, _FakeUpdatingBundle(), default_timeout=5)

    content, artifact = await t.coroutine(task="find lamps")

    assert content == "Updated final answer."
    assert len(artifact["messages"]) == 2
    assert artifact["messages"][-1].text == "Updated final answer."


@pytest.mark.asyncio
async def test_make_agent_tool_surfaces_errors_as_tool_exception():
    spec = AgentSpec(name="flaky", description="Sometimes fails.")
    bundle = _FakeBundle(error=RuntimeError("boom"))
    t = make_agent_tool(spec, bundle, default_timeout=5)
    # handle_tool_errors=True -> ainvoke returns a ToolMessage-like error string,
    # it does not raise.
    result = await t.ainvoke({"task": "x"})
    assert "flaky" in str(result) or "boom" in str(result)


@pytest.mark.asyncio
async def test_make_agent_tool_times_out():
    spec = AgentSpec(name="slow", description="Too slow.", call_timeout=0.01)
    bundle = _FakeBundle(answer="ok", delay=1.0)
    t = make_agent_tool(spec, bundle, default_timeout=5)
    result = await t.ainvoke({"task": "x"})
    assert "timed out" in str(result).lower()
