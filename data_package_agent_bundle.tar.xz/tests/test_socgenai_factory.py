"""Exercise agent options through the real shared wrapper request converter."""

from copy import deepcopy
from types import SimpleNamespace

import pytest
from langchain_core.messages import HumanMessage

from mcp_agent_template.config import Settings
from mcp_agent_template.llm import get_chat_model


def test_agent_defaults_select_shared_responses_and_omit_sampling():
    settings = Settings(_env_file=None)
    assert settings.genai_provider == "socgenai_llm"
    assert settings.genai_use_responses_api is True
    assert settings.genai_temperature is None


@pytest.mark.parametrize(
    "options,expected",
    [
        ({}, "max"),
        ({"reasoning_effort": "low"}, "low"),
        ({"reasoning": {"effort": "low"}}, "low"),
        ({"model_kwargs": {"reasoning_effort": "low"}}, "low"),
        ({"model_kwargs": {"reasoning": {"effort": "low"}}}, "low"),
    ],
)
def test_configured_effort_respects_explicit_request_options(monkeypatch, options, expected):
    pytest.importorskip("socgenai_llm")
    from socgenai_llm._responses_compat import request_payload

    monkeypatch.setattr(
        "socgenai_llm.chat_model.GenAiApiClient",
        lambda **kw: SimpleNamespace(close=lambda: None),
    )
    original = deepcopy(options)
    settings = Settings(_env_file=None, genai_reasoning_effort="max")
    with get_chat_model(settings=settings, **options) as model:
        payload = request_payload(
            [HumanMessage("Synthetic input")], model._params(), streaming=False
        )
    assert payload["reasoning"] == {"effort": expected, "summary": "detailed"}
    assert options == original


def test_factory_keeps_request_options_in_actual_socgenai_payload(monkeypatch):
    wrapper = pytest.importorskip("socgenai_llm")
    from socgenai_llm._responses_compat import request_payload

    manager = SimpleNamespace(close=lambda: None)
    monkeypatch.setattr("socgenai_llm.chat_model.GenAiApiClient", lambda **kw: manager)
    options = {"reasoning_effort": "max", "timeout": 45}
    original = deepcopy(options)
    model = get_chat_model(
        settings=Settings(
            _env_file=None,
            genai_provider="socgenai_llm",
            genai_use_responses_api=True,
            genai_temperature=0.0,
        ),
        max_output_tokens=4096,
        model_kwargs=options,
        max_retries=0,
        cache=False,
    )
    assert isinstance(model, wrapper.GenAIChatModel)
    try:
        payload = request_payload(
            [HumanMessage("Synthetic input")], model._params(), streaming=False
        )
        assert payload["max_output_tokens"] == 4096
        assert payload["reasoning"] == {"effort": "max", "summary": "detailed"}
        assert payload["timeout"] == 45
        assert "max_retries" not in payload
        assert model.max_retries == 0
        assert model.cache is False
        assert options == original
    finally:
        model.close()
