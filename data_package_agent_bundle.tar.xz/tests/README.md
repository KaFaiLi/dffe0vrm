# Agent tests

The maintained suite covers current agent, analysis, recording and dashboard
behavior. Dedicated backward-compatibility and obsolete development tests were
removed at the user's request. See the
[2026-10-26 review](../docs/review/legacy-test-review-2026-10-26.md) for the complete
test-file disposition. The subsequent [compatibility removal guide](../docs/legacy-removal.md)
records the removed interfaces and the explicitly preserved old LLM adapter.

Run the unit, MCP integration and dashboard tests from the package directory
using the corporate development environment:

```text
uv run pytest tests dashboard/tests -q
```

The skill and chart path-containment regressions do not create OS symlinks or
require administrator privileges or Windows Developer Mode. They redirect
`Path.resolve()` for selected paths and their descendants, using real temporary
files for discovery and reads. These checks run even when corporate policy
denies symlink creation, including rejection of external resource targets and
directories replaced after skill discovery.

This verifies the application's containment checks with simulated resolved
targets; it does not establish OS symlink or junction behavior on a corporate
filesystem. See [AGENTS.md](../AGENTS.md) for the isolated local uv environment
and its dependency boundary.
