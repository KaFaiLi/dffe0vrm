"""Tool decisions and execution through the active middleware policy."""

from __future__ import annotations

import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor

import pytest
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.config import CONFIG_KEY_RUNTIME
from langgraph.prebuilt import ToolNode
from langgraph.runtime import Runtime

from mcp_agent_template.agent import AgentSpec, build_agent, build_agent_tree
from mcp_agent_template.agent.runtime.context import RunContext
from mcp_agent_template.agent.runtime.middleware import (
    RuntimePolicyMiddleware,
    ToolRoundPolicyMiddleware,
)
from tests.support.models import RequestModel
from tests.support.observations import settings_at


def test_round_policy_preserves_all_tool_calls():
    """Preserve every model-selected tool under the active parallel policy."""
    ai = AIMessage(
        content="",
        id="msg-1",
        tool_calls=[
            {"name": "a", "args": {}, "id": "1"},
            {"name": "b", "args": {}, "id": "2"},
        ],
    )
    policy = ToolRoundPolicyMiddleware(10)
    result = policy.after_model({"messages": [HumanMessage(content="hi"), ai]}, None)
    assert result == {}
    assert ai.id == "msg-1"
    assert [call["id"] for call in ai.tool_calls] == ["1", "2"]


@pytest.mark.parametrize(
    "messages",
    [
        [AIMessage(content="", tool_calls=[{"name": "a", "args": {}, "id": "1"}])],
        [AIMessage(content="done")],
        [HumanMessage(content="hi")],
        [],
    ],
)
def test_round_policy_leaves_single_or_absent_tool_calls_unchanged(messages):
    """Leave single-call and non-tool messages unchanged."""
    policy = ToolRoundPolicyMiddleware(10)
    assert policy.after_model({"messages": messages}, None) == {}


@pytest.mark.asyncio
async def test_active_execution_policy_allows_parallel_dispatch():
    """Keep the active runtime policy parallel on the native async tool node."""
    order = []
    first_entered = asyncio.Event()
    second_entered = asyncio.Event()
    release = asyncio.Event()

    @tool
    async def slow_a() -> str:
        """Wait while the second tool attempts dispatch."""
        order.append("start:a")
        first_entered.set()
        await release.wait()
        order.append("end:a")
        return "a"

    @tool
    async def slow_b() -> str:
        """Wait alongside the first tool."""
        order.append("start:b")
        second_entered.set()
        await release.wait()
        order.append("end:b")
        return "b"

    policy = RuntimePolicyMiddleware()

    node = ToolNode([slow_a, slow_b], awrap_tool_call=policy.awrap_tool_call)
    pending = asyncio.create_task(
        node.ainvoke(
            [
                {"name": "slow_a", "args": {}, "id": "1", "type": "tool_call"},
                {"name": "slow_b", "args": {}, "id": "2", "type": "tool_call"},
            ],
            config={"configurable": {CONFIG_KEY_RUNTIME: Runtime(context=RunContext())}},
        )
    )
    try:
        await asyncio.wait_for(first_entered.wait(), 5)
        await asyncio.wait_for(second_entered.wait(), 5)
        assert sorted(order) == ["start:a", "start:b"]
    finally:
        release.set()
        await asyncio.wait_for(pending, 5)
    assert sorted(order[2:]) == ["end:a", "end:b"]


def test_sync_execution_policy_allows_parallel_native_dispatch():
    """Keep the active runtime policy parallel on the native sync tool node."""
    entered = [threading.Event(), threading.Event()]
    release = threading.Event()

    @tool
    def wait_for_peer(index: int) -> str:
        """Wait until both synchronous calls have entered."""
        entered[index].set()
        if not release.wait(5):
            raise TimeoutError("Peer did not enter before the test deadline.")
        return str(index)

    policy = RuntimePolicyMiddleware()
    node = ToolNode([wait_for_peer], wrap_tool_call=policy.wrap_tool_call)
    with ThreadPoolExecutor(max_workers=1) as executor:
        pending = executor.submit(
            node.invoke,
            [
                {"name": "wait_for_peer", "args": {"index": i}, "id": str(i), "type": "tool_call"}
                for i in range(2)
            ],
            config={"configurable": {CONFIG_KEY_RUNTIME: Runtime(context=RunContext())}},
        )
        try:
            assert all(event.wait(5) for event in entered)
        finally:
            release.set()
        assert [message.content for message in pending.result(5)["messages"]] == ["0", "1"]


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True])
async def test_builders_execute_all_independent_tool_calls(tmp_path, tree):
    """Execute both independent calls through either public builder."""
    effects = []
    entered = asyncio.Event()
    release = asyncio.Event()

    async def record(name, label):
        effects.append(name)
        if len(effects) == 2:
            entered.set()
        await release.wait()
        return label

    @tool
    async def first(label: str) -> str:
        """Record the first selected operation."""
        return await record("first", label)

    @tool
    async def second(label: str) -> str:
        """Record the second selected operation."""
        return await record("second", label)

    settings = settings_at(tmp_path)
    model = RequestModel(names=["first", "second"])
    if tree:
        bundle = await build_agent_tree(
            AgentSpec(
                name="root", description="Execute tools", model=model, extra_tools=[first, second]
            ),
            settings,
            mcp_tools=[],
        )
    else:
        bundle = await build_agent(settings, model=model, mcp_tools=[], extra_tools=[first, second])
    pending = asyncio.create_task(bundle.ainvoke("policy"))
    try:
        await asyncio.wait_for(entered.wait(), 5)
    finally:
        release.set()
        state = await asyncio.wait_for(pending, 5)
    assert sorted(effects) == ["first", "second"]
    messages = [m for m in state["messages"] if isinstance(m, ToolMessage)]
    assert [message.name for message in messages] == ["first", "second"]
    assert state["messages"][-1].text == "done:policy"
