"""Cancellation must settle recorder ownership on a continuing event loop."""

import asyncio
import logging
import threading

import pytest

from mcp_agent_template.observability import ObservabilityRuntime
from tests.support.observations import settings_at


async def wait_entered(event):
    async with asyncio.timeout(5):
        while not event.is_set():
            await asyncio.sleep(0.001)


@pytest.mark.parametrize("phase", ["before", "after"])
def test_cancelled_startup_joins_worker_and_closes_acquired_resources(tmp_path, monkeypatch, phase):
    async def run():
        obs = ObservabilityRuntime.local(settings_at(tmp_path / phase))
        entered, release = threading.Event(), threading.Event()
        original = obs.start

        def delayed_start():
            if phase == "after":
                original()
            entered.set()
            assert release.wait(5)
            return original() if phase == "before" else obs

        monkeypatch.setattr(obs, "start", delayed_start)
        pending = asyncio.create_task(obs.__aenter__())
        try:
            await wait_entered(entered)
            pending.cancel()
            await asyncio.sleep(0)
            pending.cancel()
            await asyncio.sleep(0)
            assert not pending.done()
        finally:
            release.set()
        with pytest.raises(asyncio.CancelledError):
            await pending
        assert obs.closed and not obs.store.thread.is_alive()
        assert obs.log_handler not in logging.getLogger().handlers
        assert not obs.active_scopes and obs.errors == 0
        await obs.aclose()
        async with ObservabilityRuntime.local(settings_at(tmp_path / "next")) as next_obs:
            next_obs.emit("test.continuing_loop", {"complete": True})
        assert next_obs.closed and not next_obs.store.thread.is_alive()

    asyncio.run(run())


def test_repeated_cancellation_during_close_does_not_orphan_writer(tmp_path, monkeypatch):
    async def run():
        obs = await ObservabilityRuntime.local(settings_at(tmp_path)).__aenter__()
        entered, release = threading.Event(), threading.Event()
        original = obs.close

        def delayed_close():
            entered.set()
            assert release.wait(5)
            original()

        monkeypatch.setattr(obs, "close", delayed_close)
        pending = asyncio.create_task(obs.aclose())
        try:
            await wait_entered(entered)
            pending.cancel()
            await asyncio.sleep(0)
            pending.cancel()
            await asyncio.sleep(0)
            assert not pending.done()
        finally:
            release.set()
        with pytest.raises(asyncio.CancelledError):
            await pending
        assert obs.closed and not obs.store.thread.is_alive()
        assert obs.log_handler not in logging.getLogger().handlers
        await obs.aclose()

    asyncio.run(run())


def test_failed_partial_startup_releases_registered_resources(tmp_path, monkeypatch):
    async def run():
        obs = ObservabilityRuntime.local(settings_at(tmp_path))
        original = obs.heartbeat

        def fail_start(stopped=False):
            if not stopped:
                raise RuntimeError("synthetic startup failure")
            return original(stopped=stopped)

        monkeypatch.setattr(obs, "heartbeat", fail_start)
        with pytest.raises(RuntimeError, match="synthetic startup failure"):
            await obs.__aenter__()
        assert obs.closed and not obs.store.thread.is_alive()
        assert obs.errors > 0
        assert obs.log_handler not in logging.getLogger().handlers

    asyncio.run(run())


def test_metric_flush_failure_still_closes_writer_and_unregisters(tmp_path, monkeypatch):
    async def run():
        obs = await ObservabilityRuntime.local(settings_at(tmp_path)).__aenter__()

        def failed_flush():
            raise RuntimeError("synthetic metric flush failure")

        monkeypatch.setattr(obs.meter_provider, "force_flush", failed_flush)
        with pytest.raises(RuntimeError, match="synthetic metric flush failure"):
            await obs.aclose()
        assert obs.closed and not obs.store.thread.is_alive() and obs.errors > 0
        assert obs.log_handler not in logging.getLogger().handlers

    asyncio.run(run())


def test_failed_stop_heartbeat_still_closes_writer_and_unregisters(tmp_path, monkeypatch):
    async def run():
        obs = await ObservabilityRuntime.local(settings_at(tmp_path)).__aenter__()
        original = obs.heartbeat

        def failed_stop(stopped=False):
            if stopped:
                raise RuntimeError("synthetic stopped heartbeat failure")
            return original(stopped=stopped)

        monkeypatch.setattr(obs, "heartbeat", failed_stop)
        with pytest.raises(RuntimeError, match="stopped heartbeat failure"):
            await obs.aclose()
        assert obs.closed and not obs.store.thread.is_alive() and obs.errors > 0
        assert obs.log_handler not in logging.getLogger().handlers
        # A new recorder on this event loop remains usable after failed cleanup diagnostics.
        async with ObservabilityRuntime.local(settings_at(tmp_path / "next")) as next_obs:
            next_obs.emit("test.next", {"ok": True})
        assert next_obs.closed

    asyncio.run(run())
