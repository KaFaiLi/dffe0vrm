"""Attempt identity and reservations through real compiled model dispatch."""

import asyncio
import json
from types import SimpleNamespace

import pytest
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.outputs import ChatGeneration, ChatResult

from mcp_agent_template.agent import AgentSpec, build_agent, build_agent_tree
from mcp_agent_template.agent.runtime.context import ModelBudgetExceeded, RunBudget, RunContext
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.capture.middleware import EffectiveRequestMiddleware
from mcp_agent_template.observability.context import model_context
from tests.support.models import ScriptedModel
from tests.support.observations import events, settings_at


class RetryModel(AgentMiddleware):
    async def awrap_model_call(self, request, handler):
        try:
            return await handler(
                request.override(
                    messages=[SystemMessage(content="first attempt"), *request.messages]
                )
            )
        except RuntimeError:
            return await handler(
                request.override(
                    messages=[SystemMessage(content="retry attempt"), *request.messages]
                )
            )


def correlation(event):
    return json.loads(event["payload"])["context"]


async def build_recorded(settings, obs, model, tree, middleware=()):
    if tree:
        return await build_agent_tree(
            AgentSpec(name="root", description="Answer", model=model),
            settings,
            mcp_tools=[],
            observability=obs,
            middleware=middleware,
        )
    return await build_agent(
        settings,
        model=model,
        mcp_tools=[],
        observability=obs,
        middleware=middleware,
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("tree", [False, True], ids=["single-agent", "tree-node"])
async def test_retried_concurrent_roots_keep_distinct_attempts(tmp_path, tree):
    started = asyncio.Event()
    release = asyncio.Event()
    calls = {}

    class RetryingModel(ScriptedModel):
        async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
            label = next(m.text for m in messages if isinstance(m, HumanMessage))
            seen = calls.setdefault(label, [])
            seen.append(model_context())
            if len(seen) == 1:
                if len(calls) == 2:
                    started.set()
                await release.wait()
                raise RuntimeError("Synthetic provider failure.")
            return ChatResult(generations=[ChatGeneration(message=AIMessage(content=label))])

    settings = settings_at(tmp_path, agent_max_model_calls=2)
    async with ObservabilityRuntime.local(settings) as obs:
        bundle = await build_recorded(
            settings, obs, RetryingModel(responses=[]), tree, middleware=(RetryModel(),)
        )
        pending = [asyncio.create_task(bundle.ask(label)) for label in ("left", "right")]
        try:
            await asyncio.wait_for(started.wait(), 5)
        finally:
            release.set()
            answers = await asyncio.wait_for(asyncio.gather(*pending), 5)
        assert answers == ["left", "right"]
        assert model_context() is None
        assert await obs.aflush()
        requests = events(obs, "capture.model_request")
        finished = events(obs, "model.finished")
        assert len(requests) == len(finished) == 4
        identities = {correlation(e)["request_id"] for e in requests}
        assert len(identities) == 4
        assert {correlation(e)["request_id"] for e in finished} == identities
        for attempts in calls.values():
            assert len(attempts) == 2
            assert attempts[0]["run_id"] == attempts[1]["run_id"]
            assert attempts[0]["round_id"] == attempts[1]["round_id"]
            assert attempts[0]["request_id"] != attempts[1]["request_id"]
            assert [
                e["data"]["messages"][0]["content"]
                for e in requests
                if e["run_id"] == attempts[0]["run_id"]
            ] == ["first attempt", "retry attempt"]
        assert calls["left"][0]["run_id"] != calls["right"][0]["run_id"]
        assert [e["data"]["completion"] for e in finished].count("failed") == 2
        dispatches = events(obs, "model.dispatch.finished")
        assert len(dispatches) == 4
        assert [e["data"]["completion"] for e in dispatches].count("failed") == 2
        assert {correlation(e)["request_id"] for e in dispatches} == identities
        definitions = events(obs, "capture.run_definition")
        assert len(definitions) == 2
        assert all("source_build_event_id" not in e["data"] for e in definitions)


@pytest.mark.asyncio
async def test_concurrent_handler_attempts_share_round_but_keep_request_identity(tmp_path):
    calls = []
    entered = asyncio.Event()

    class ParallelModel(ScriptedModel):
        async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
            calls.append(model_context())
            if len(calls) == 2:
                entered.set()
            await asyncio.wait_for(entered.wait(), 5)
            return ChatResult(generations=[ChatGeneration(message=AIMessage(content="complete"))])

    class ParallelAttempts(AgentMiddleware):
        async def awrap_model_call(self, request, handler):
            results = await asyncio.gather(handler(request), handler(request))
            return results[-1]

    settings = settings_at(tmp_path, agent_max_model_calls=2)
    async with ObservabilityRuntime.local(settings) as obs:
        bundle = await build_recorded(
            settings, obs, ParallelModel(responses=[]), False, middleware=(ParallelAttempts(),)
        )
        assert await bundle.ask("parallel attempts") == "complete"
        assert model_context() is None
        assert await obs.aflush()
        assert len(calls) == 2
        assert calls[0]["run_id"] == calls[1]["run_id"]
        assert calls[0]["round_id"] == calls[1]["round_id"]
        assert calls[0]["request_id"] != calls[1]["request_id"]
        identities = {c["request_id"] for c in calls}
        for name in ("capture.model_request", "model.started", "model.finished"):
            assert {correlation(e)["request_id"] for e in events(obs, name)} == identities


@pytest.mark.asyncio
async def test_rejected_retry_has_identity_without_provider_dispatch(tmp_path, monkeypatch):
    attempts = []
    reserve = RunBudget.reserve_model

    def observe_reservation(budget):
        attempts.append(model_context())
        reserve(budget)

    monkeypatch.setattr(RunBudget, "reserve_model", observe_reservation)

    class FailingModel(ScriptedModel):
        async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
            raise RuntimeError("Synthetic provider failure.")

    settings = settings_at(tmp_path, agent_max_model_calls=1)
    async with ObservabilityRuntime.local(settings) as obs:
        bundle = await build_recorded(
            settings, obs, FailingModel(responses=[]), False, middleware=(RetryModel(),)
        )
        context = bundle.new_context()
        with pytest.raises(ModelBudgetExceeded):
            await bundle.ask("retry", context=context)
        assert context.budget.model_calls == 1
        assert len(attempts) == 2
        assert all(a["request_id"] for a in attempts)
        assert attempts[0]["request_id"] != attempts[1]["request_id"]
        assert model_context() is None
        assert await obs.aflush()
        assert len(events(obs, "capture.model_request")) == 1
        assert len(events(obs, "model.started")) == 1
        assert (
            correlation(events(obs, "model.finished")[0])["request_id"] == attempts[0]["request_id"]
        )


@pytest.mark.asyncio
async def test_model_cancellation_cleans_identity_before_next_root(tmp_path):
    entered = asyncio.Event()
    never = asyncio.Event()
    calls = []

    class BlockingModel(ScriptedModel):
        async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
            calls.append(model_context())
            if next(m.text for m in messages if isinstance(m, HumanMessage)) == "cancel":
                entered.set()
                await never.wait()
            return ChatResult(generations=[ChatGeneration(message=AIMessage(content="complete"))])

    settings = settings_at(tmp_path)
    async with ObservabilityRuntime.local(settings) as obs:
        bundle = await build_recorded(settings, obs, BlockingModel(responses=[]), False)
        pending = asyncio.create_task(bundle.ask("cancel"))
        try:
            await asyncio.wait_for(entered.wait(), 5)
        finally:
            pending.cancel()
            with pytest.raises(asyncio.CancelledError):
                await pending
        assert model_context() is None
        assert await bundle.ask("next") == "complete"
        assert calls[0]["run_id"] != calls[1]["run_id"]
        assert calls[0]["request_id"] != calls[1]["request_id"]
        assert await obs.aflush()
        finished = events(obs, "model.finished")
        # Native cancellation can omit its callback; scope cleanup retains unknown outcome.
        assert finished[0]["data"]["completion"] in ("unknown", "cancelled")
        assert finished[1]["data"]["completion"] == "completed"
        assert [correlation(e)["request_id"] for e in finished] == [c["request_id"] for c in calls]
        assert [e["data"]["completion"] for e in events(obs, "model.dispatch.finished")] == [
            "cancelled",
            "completed",
        ]
        assert [e["data"]["completion"] for e in events(obs, "run.finished")] == [
            "cancelled",
            "completed",
        ]


@pytest.mark.parametrize("model_limit", [1, 2])
def test_sync_model_hook_reserves_before_dispatch(model_limit):
    context = RunContext(max_model_calls=model_limit)
    request = SimpleNamespace(runtime=SimpleNamespace(context=context))
    dispatched = []

    def dispatch(request):
        dispatched.append(request)
        return "complete"

    middleware = EffectiveRequestMiddleware()
    assert middleware.wrap_model_call(request, dispatch) == "complete"
    if model_limit == 1:
        with pytest.raises(ModelBudgetExceeded):
            middleware.wrap_model_call(request, dispatch)
    else:
        assert middleware.wrap_model_call(request, dispatch) == "complete"
    assert context.budget.model_calls == model_limit
    assert len(dispatched) == model_limit
