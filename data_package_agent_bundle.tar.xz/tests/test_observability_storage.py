from __future__ import annotations

import asyncio
import json
import sqlite3
import threading

import pytest

from mcp_agent_template.agent.react_agent import build_agent
from mcp_agent_template.observability import ObservabilityRuntime
from mcp_agent_template.observability.recording.storage import LocalStore, read_rows
from tests.support.models import RequestModel
from tests.support.observations import settings_at


def test_flush_admission_cannot_follow_writer_shutdown(tmp_path, monkeypatch):
    """A concurrent close cannot strand an admitted flush behind the stop command."""
    store = LocalStore(tmp_path / "shutdown.sqlite3", 0)
    store.start()
    entering = threading.Event()
    release = threading.Event()
    closed = threading.Event()
    barriers = []
    results = []
    locked_at_admission = []
    original_put = store.queue.put

    def paused_put(item):
        """Pause flush admission so shutdown attempts the competing lifecycle path."""
        if item[0] == "flush":
            barriers.append(item[1])
            locked_at_admission.append(store._lock.locked())
            entering.set()
            assert release.wait(5)
        original_put(item)

    def close_store():
        """Expose completed writer shutdown without relying on scheduling sleeps."""
        store.close()
        closed.set()

    monkeypatch.setattr(store.queue, "put", paused_put)
    flusher = threading.Thread(target=lambda: results.append(store.flush()))
    closer = threading.Thread(target=close_store)
    try:
        flusher.start()
        assert entering.wait(5)
        closer.start()
        # Before the fix, close can finish while the flush is paused. Once flush
        # holds the lifecycle lock, release it so both operations can complete.
        if not locked_at_admission[0]:
            assert closed.wait(5)
        release.set()
        closer.join(5)
        flusher.join(1)
        assert not flusher.is_alive(), "Flush barrier was queued after the writer stopped."
        assert not closer.is_alive()
        assert results == [True]
        assert store.queue.empty()
        assert not store.thread.is_alive()
    finally:
        release.set()
        for barrier in barriers:
            barrier.set()  # Also release the stranded waiter when testing the old bug.
        if closer.ident is not None:
            closer.join(5)
        flusher.join(5)
        store.close()


def test_writer_failure_does_not_change_agent_answer(tmp_path, monkeypatch):
    async def run():
        async with ObservabilityRuntime.local(settings_at(tmp_path)) as obs:
            monkeypatch.setattr(
                obs.store, "_write", lambda *args: (_ for _ in ()).throw(OSError("disk full"))
            )
            bundle = await build_agent(
                obs.settings,
                model=RequestModel(names=[]),
                mcp_tools=[],
                observability=obs,
            )
            assert await bundle.ask("healthy") == "done:healthy"
            assert not await obs.aflush()
        assert obs.store.failed and obs.store.unrecorded > 0
        assert not obs.store.thread.is_alive()

    asyncio.run(run())


def test_duplicate_records_are_idempotent_and_no_automatic_retention(tmp_path):
    store = LocalStore(tmp_path / "observations.db", 0)
    store.start()
    r = {
        "event_id": "one",
        "process_instance_id": "p",
        "source_seq": 1,
        "timestamp": 1.0,
        "event_name": "capture.old",
        "root_run_id": None,
        "run_id": None,
        "trace_id": None,
        "span_id": None,
        "payload": json.dumps({"data": "x" * 2000000, "redactions": []}),
    }
    store.enqueue("event", r)
    store.enqueue("event", r)
    assert store.flush()
    store.close()
    assert read_rows(store.path, "SELECT count(*) n FROM events")[0]["n"] == 1
    assert (
        len(json.loads(read_rows(store.path, "SELECT payload FROM events")[0]["payload"])["data"])
        == 2000000
    )


def test_lossless_slow_writer_and_concurrent_reader(tmp_path, monkeypatch):
    import time
    from concurrent.futures import ThreadPoolExecutor

    store = LocalStore(tmp_path / "events.sqlite3", 0.01)
    store.start()
    original = store._write

    def slow(db, kind, record):
        time.sleep(0.001)
        original(db, kind, record)

    monkeypatch.setattr(store, "_write", slow)
    try:
        for i in range(100):
            store.enqueue(
                "event",
                {
                    "event_id": str(i),
                    "process_instance_id": "p",
                    "source_seq": i,
                    "timestamp": i,
                    "event_name": "sample",
                    "payload": json.dumps({"data": "x" * 1000, "redactions": []}),
                },
            )
        assert store.health()["pending_records"] > 0
        with ThreadPoolExecutor() as pool:
            waiting = pool.submit(store.flush)
            counts = [
                read_rows(store.path, "SELECT count(*) n FROM events")[0]["n"] for _ in range(10)
            ]
            assert counts == sorted(counts)
            assert waiting.result(timeout=5)
        assert store.health()["unrecorded"] == 0
        assert read_rows(store.path, "SELECT count(*) n FROM events")[0]["n"] == 100
    finally:
        store.close()


@pytest.mark.parametrize("version", [0, 1, 999])
def test_schema_conflict_is_non_destructive(tmp_path, version):
    """Reject unsupported populated stores without changing their schema or records."""
    path = tmp_path / "future.sqlite3"
    with sqlite3.connect(path) as db:
        db.execute(f"PRAGMA user_version={version}")
        db.execute("CREATE TABLE future (value TEXT)")
        db.execute("INSERT INTO future VALUES ('kept')")
    store = LocalStore(path)
    with pytest.raises(RuntimeError, match="initialize"):
        store.start()
    assert not store.thread.is_alive()
    with sqlite3.connect(path) as db:
        assert db.execute("PRAGMA user_version").fetchone()[0] == version
        assert db.execute("SELECT value FROM future").fetchone()[0] == "kept"
        assert db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() == [
            ("future",)
        ]
    with pytest.raises(ValueError, match="Unsupported"):
        read_rows(path, "SELECT * FROM future")
