"""Todo state survives real history compaction without rewriting native records."""

import json
from typing import Any

from langchain.tools import ToolRuntime
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import tool
from langchain_core.utils.function_calling import convert_to_openai_tool
from pydantic import Field

from mcp_agent_template.agent import RunContext, build_agent
from mcp_agent_template.agent.runtime.context_policy import _TokenCounter
from mcp_agent_template.config import ContextCompactionSettings, Settings


class TodoCompactionModel(BaseChatModel):
    responses: list[AIMessage] = Field(default_factory=list)
    main_requests: list[Any] = Field(default_factory=list)
    summary_requests: list[Any] = Field(default_factory=list)

    @property
    def _llm_type(self):
        return "synthetic-todo-compaction"

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        if kwargs.get("tool_choice") == "none":
            assert kwargs["tools"] == []
            self.summary_requests.append(list(messages))
            response = AIMessage(content="Earlier work is complete. Current task: publish report.")
        else:
            self.main_requests.append(list(messages))
            response = self.responses[len(self.main_requests) - 1]
        return ChatResult(generations=[ChatGeneration(message=response)])


def write_todos(call_id, todos):
    return AIMessage(
        content="",
        tool_calls=[{"name": "write_todos", "args": {"todos": todos}, "id": call_id}],
    )


async def test_compaction_preserves_current_todos_and_complete_native_tool_history(
    tmp_path, monkeypatch
):
    def initialize_counter(self, model):
        self.encoding = None
        self.method = "conservative:utf8-bytes"

    monkeypatch.setattr(_TokenCounter, "__init__", initialize_counter)
    current = {"content": "publish report", "status": "in_progress"}
    completed = {**current, "status": "completed"}
    inspected = []
    model = TodoCompactionModel()

    @tool
    def inspect_current_todos(runtime: ToolRuntime[RunContext]) -> str:
        """Check the synthetic task's native checklist without modifying it."""
        assert model.summary_requests
        assert runtime.state["todos"] == [current]
        inspected.append(list(runtime.state["todos"]))
        return "Current checklist verified."

    settings = Settings(
        _env_file=None,
        app_root=tmp_path,
        skills_dir="no-test-skills",
        obs={"mode": "off"},
    )
    # Measure the actual assembled prompt and tool schemas before selecting the
    # fixture budget: both features add fixed input that history cannot shrink.
    baseline = await build_agent(
        settings, model=model, mcp_tools=[], extra_tools=[inspect_current_todos]
    )
    counter = _TokenCounter(model)
    schemas = {
        "tools": [convert_to_openai_tool(t) for t in baseline.all_tools],
        "response_format": None,
    }
    fixed = counter.text(json.dumps(schemas, ensure_ascii=False, separators=(",", ":")))
    fixed += counter.messages([SystemMessage(content=baseline.system_prompt)])
    budget = 2 * fixed + 5000
    settings.context_compaction = ContextCompactionSettings(
        input_token_budget=budget, keep_recent_groups=0
    )
    old_content = "OLD_COMPLETED_BEGIN" + "x" * (3 * budget) + "OLD_COMPLETED_END"
    original = [{"content": old_content, "status": "completed"}, current]
    model.responses = [
        write_todos("initial", original),
        write_todos("replace", [current]),
        AIMessage(
            content="",
            tool_calls=[{"name": "inspect_current_todos", "args": {}, "id": "inspect"}],
        ),
        write_todos("finish", [completed]),
        AIMessage(content="Published report."),
    ]
    bundle = await build_agent(
        settings, model=model, mcp_tools=[], extra_tools=[inspect_current_todos]
    )
    context = bundle.new_context()
    result = await bundle.ainvoke(
        "Publish the report after checking the checklist.", context=context
    )

    assert inspected == [[current]]
    assert result["todos"] == [completed]
    assert result["messages"][-1].text == "Published report."
    assert context.budget.calls == 4
    assert context.budget.model_calls == 5 + len(model.summary_requests)
    assert context.context_summaries

    results = {m.tool_call_id: m for m in result["messages"] if isinstance(m, ToolMessage)}
    assert set(results) == {"initial", "replace", "inspect", "finish"}
    assert all(message.status == "success" for message in results.values())
    assert old_content in results["initial"].text
    initial_call = next(m for m in result["messages"] if isinstance(m, AIMessage) and m.tool_calls)
    assert initial_call.tool_calls[0]["args"]["todos"] == original
    assert "in_progress" in results["replace"].text
    assert "completed" in results["finish"].text
    assert not any("Conversation history summary" in m.text for m in result["messages"])

    projected = model.main_requests[1]
    assert any("Conversation history summary" in m.text for m in projected)
    assert not any("OLD_COMPLETED_BEGIN" in m.text for m in projected)
    assert not any(isinstance(m, ToolMessage) and m.tool_call_id == "initial" for m in projected)
    assert not any(
        call["id"] == "initial"
        for message in projected
        if isinstance(message, AIMessage)
        for call in message.tool_calls
    )
    # Every byte of the original tool result reached the summary model, even
    # when bounded requests split it into multiple portions.
    portions = "".join(
        message.text.split("\nNext portion:\n", 1)[1]
        for request in model.summary_requests
        for message in request
    )
    assert old_content in portions
    assert all(counter.messages(request) <= budget for request in model.summary_requests)
