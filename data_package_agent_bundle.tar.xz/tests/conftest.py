"""Register shared opt-in fixtures independently of directory collector identity."""

# Pytest 9.1.1 can recreate directory collectors for interleaved file arguments.
# A plugin keeps fixture visibility stable without changing test collection order.
pytest_plugins = ("tests.support.analysis_fixtures",)
