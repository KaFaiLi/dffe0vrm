# socgenai_llm/_client_delegates.py
from __future__ import annotations

from typing import Any, Dict, Optional, Protocol, runtime_checkable


@runtime_checkable
class _HasClient(Protocol):
    """Protocol for wrapper classes that contain an underlying GenAiApiClient."""

    _client: Any


class ClientDelegatesMixin:
    """Expose selected GenAiApiClient helper methods on wrapper classes.

    This keeps LangChain wrappers ergonomic: users can call
    `model.print_today_usage_report()` or `model.get_models()`
    without touching `_client`.
    """

    # ---- usage reporting ----

    def print_today_usage_report(self: _HasClient) -> None:
        """Print today's usage report to stdout (delegates to GenAiApiClient)."""
        if not hasattr(self._client, "print_today_usage_report"):
            raise AttributeError(
                "Underlying GenAiApiClient does not implement print_today_usage_report(). "
                "Please upgrade genai_api_manager."
            )
        self._client.print_today_usage_report()

    # ---- models / pricing ----

    def get_models(
        self: _HasClient,
        *,
        print_models: bool = True,
        include_substring: Optional[str] = None,
        exclude_substring: Optional[str] = None,
        title: str = "Available Models (pricing per 1K tokens)",
    ) -> Dict[str, Dict[str, float]]:
        """Return model pricing dict and optionally print it (delegates to GenAiApiClient)."""
        if not hasattr(self._client, "get_models"):
            raise AttributeError(
                "Underlying GenAiApiClient does not implement get_models(). "
                "Please upgrade genai_api_manager."
            )
        return self._client.get_models(
            print_models=print_models,
            include_substring=include_substring,
            exclude_substring=exclude_substring,
            title=title,
        )

    def get_available_models(self: _HasClient) -> list[str]:
        """Backward compatible convenience: non-embedding models (delegates)."""
        if not hasattr(self._client, "get_available_models"):
            # fallback using get_models if only the unified API exists
            models = self.get_models(
                print_models=True,
                exclude_substring="embedding",
                title="Available Models (non-embedding) — pricing per 1K tokens",
            )
            return sorted(models.keys())

        return self._client.get_available_models()

    def get_available_embedding_models(self: _HasClient) -> list[str]:
        """Backward compatible convenience: embedding models (delegates)."""
        if not hasattr(self._client, "get_available_embedding_models"):
            # fallback using get_models if only the unified API exists
            models = self.get_models(
                print_models=True,
                include_substring="embedding",
                title="Available Models (embedding) — pricing per 1K tokens",
            )
            return sorted(models.keys())

        return self._client.get_available_embedding_models()

    # ---- optional: convenience access to the raw client ----

    @property
    def client(self: _HasClient) -> Any:
        """Expose the underlying GenAiApiClient (read-only convenience)."""
        return self._client
