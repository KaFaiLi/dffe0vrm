"""GenAIChatModel — LangChain BaseChatModel backed by GenAiApiClient.

This module provides ``GenAIChatModel``, a thin wrapper that delegates
chat completions to :class:`genai_api_client.GenAiApiClient` while
exposing the full LangChain ``BaseChatModel`` interface.
"""

from __future__ import annotations

import asyncio
import warnings
from copy import deepcopy
from functools import partial
from typing import Any, Callable, Literal, Optional, Sequence

from langchain_core.callbacks import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models import BaseChatModel, LangSmithParams
from langchain_core.messages import BaseMessage
from langchain_core.outputs import ChatResult
from langchain_core.runnables import (
    Runnable,
)
from langchain_core.runnables.config import run_in_executor
from langchain_core.tools import BaseTool
from langchain_core.utils.function_calling import (
    convert_to_openai_function,
    convert_to_openai_tool,
)
from langchain_core.utils.pydantic import is_basemodel_subclass
from pydantic import BaseModel as PydanticV2BaseModel
from pydantic import ConfigDict, Field, field_validator

from genai_api_manager.genai_api_client import GenAiApiClient
from genai_api_manager import UnexpectedStreamEndError

from socgenai_llm._client_delegates import ClientDelegatesMixin
from socgenai_llm._chat_compat import ChatChunks, chat_params
from socgenai_llm._responses_compat import (
    GenAIResponseError,
    ResponseChunks,
    check_budget,
    request_payload,
    response_result,
)
from socgenai_llm._streaming import ExecutorStream, StreamOwner, close_in_executor
from socgenai_llm._structured_output import FinalStructuredOutput, parse_final
from socgenai_llm._usage import combine_usage, restore_message_usage, result_with_usage
from socgenai_llm._utils import (
    convert_messages_to_dicts,
    convert_response_to_chat_result,
)


class GenAIRefusalError(Exception):
    """Raised when the model refuses to produce the requested structured output.

    Mirrors ``langchain_openai.chat_models.base.OpenAIRefusalError``: raised by
    the ``json_schema`` structured-output parser when the response carries a
    ``refusal`` instead of content.
    """


class GenAIChatModel(ClientDelegatesMixin, BaseChatModel):
    """LangChain chat model backed by :class:`GenAiApiClient`.

    All network calls are synchronous and delegate to
    the manager's Chat Completions or Responses methods. Async support uses
    an executor, not a native async Azure client.

    Args:
        model: Azure OpenAI deployment / model name (required).
        temperature: Sampling temperature; ``None`` omits from request.
        max_tokens: Maximum completion tokens; ``None`` omits from request.
        max_retries: SDK retries after the initial attempt. ``None`` preserves
            the SDK default; ``0`` disables retries. Constructor-only; consumed
            streams are never replayed.
        config_path: Legacy field; only ``None`` is accepted. The manager owns
            trusted configuration paths.
        use_responses_api: ``True`` selects Responses; ``None`` selects it when
            ``reasoning`` is supplied, otherwise Chat Completions.
        reasoning: Provider reasoning options, e.g. ``{"summary": "auto"}``.
        model_kwargs: Extra keyword arguments forwarded to every
            completion call (e.g. ``top_p``, ``frequency_penalty``).
        executor: Optional executor (e.g. a ``ThreadPoolExecutor``) used
            by ``_agenerate`` to off-load the synchronous call.  ``None``
            (the default) uses the event loop's default executor.
    Example:
        .. code-block:: python

            from socgenai_llm import GenAIChatModel
            from langchain_core.messages import HumanMessage

            model = GenAIChatModel(model="gpt-4.1-nano")
            response = model.invoke([HumanMessage(content="Hello!")])
            print(response.content)
    """

    model: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    max_retries: int | None = Field(default=None, ge=0, strict=True)
    config_path: Optional[str] = None
    use_responses_api: bool | None = None
    reasoning: dict[str, Any] | None = None
    model_kwargs: dict[str, Any] = {}
    # ``Any`` (rather than ``Optional[Executor]``) avoids Pydantic schema
    # generation for the executor object; arbitrary types are already allowed.
    # ``exclude=True`` prevents PydanticSerializationError on model_dump_json()
    # when a live ThreadPoolExecutor is assigned.
    executor: Optional[Any] = Field(default=None, exclude=True)

    # --- internal state (excluded from Pydantic serialization) ---
    _client: GenAiApiClient = None  # type: ignore[assignment]

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_validator("model_kwargs")
    @classmethod
    def _validate_request_retry_options(cls, options):
        extra = options.get("extra_body")
        if "max_retries" in options or (
            isinstance(extra, dict) and "max_retries" in extra
        ):
            raise ValueError(
                "Set max_retries on the GenAIChatModel constructor, not the request."
            )
        return options

    def model_post_init(self, __context: Any) -> None:
        """Instantiate the underlying GenAiApiClient."""
        super().model_post_init(__context)
        if self.config_path is not None:
            raise ValueError(
                "config_path overrides are not supported; use trusted configuration."
            )
        self._client = GenAiApiClient(
            **(
                {"max_retries": self.max_retries}
                if self.max_retries is not None
                else {}
            )
        )

    # ------------------------------------------------------------------
    # BaseChatModel interface
    # ------------------------------------------------------------------

    @property
    def _llm_type(self) -> str:
        return "genai-chat"

    @property
    def _identifying_params(self) -> dict[str, Any]:
        return {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "use_responses_api": self.use_responses_api,
            "reasoning": self.reasoning,
            "model_kwargs": self.model_kwargs,
            "output_version": self.output_version,
        }

    def _params(self, stop=None, **kwargs):
        self._validate_request_retry_options(self.model_kwargs)
        self._validate_request_retry_options(kwargs)
        configured = {
            key: value
            for key, value in {
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "use_responses_api": self.use_responses_api,
                "reasoning": self.reasoning,
            }.items()
            if value is not None
        }
        if stop is not None:
            configured["stop"] = stop
        params = {**self.model_kwargs, **configured, **kwargs}
        params.pop("_genai_stream_owner", None)
        return params

    @staticmethod
    def _responses_selected(params):
        selection = params.get("use_responses_api")
        if selection is not None and type(selection) is not bool:
            raise ValueError("use_responses_api must be True, False, or None.")
        reasoning = params.get("reasoning")
        if reasoning is not None and not isinstance(reasoning, dict):
            raise ValueError("reasoning must be a dictionary or None.")
        if selection is False and reasoning is not None:
            raise ValueError("reasoning requires the Responses API.")
        return selection is True or (selection is None and reasoning is not None)

    def _should_stream(self, *, async_api, run_manager=None, **kwargs):
        params = self._params(**kwargs)
        if not self._responses_selected(params):
            params = chat_params(params)
        return super()._should_stream(
            async_api=async_api, run_manager=run_manager, **params
        )

    def _get_invocation_params(self, stop=None, **kwargs):
        kwargs.pop("_genai_stream_owner", None)
        return super()._get_invocation_params(stop=stop, **kwargs)

    def _get_llm_string(self, stop=None, **kwargs):
        # Core merges the original kwargs back after _get_invocation_params.
        # Ownership is per invocation, never part of the request's cache identity.
        kwargs.pop("_genai_stream_owner", None)
        return super()._get_llm_string(stop=stop, **kwargs)

    def _generate_with_cache(self, messages, stop=None, run_manager=None, **kwargs):
        owner = kwargs.setdefault("_genai_stream_owner", StreamOwner())
        try:
            return result_with_usage(
                super()._generate_with_cache(
                    messages, stop=stop, run_manager=run_manager, **kwargs
                )
            )
        finally:
            owner.close()

    async def _agenerate_with_cache(
        self, messages, stop=None, run_manager=None, **kwargs
    ):
        owner = kwargs.setdefault("_genai_stream_owner", StreamOwner())
        try:
            return result_with_usage(
                await super()._agenerate_with_cache(
                    messages, stop=stop, run_manager=run_manager, **kwargs
                )
            )
        finally:
            await close_in_executor(self.executor, owner)

    def _convert_cached_generations(self, cache_val):
        # Core mutates cached generations and adds total_cost even when usage
        # was unknown. Copy first and restore valid usage before event replay.
        generations = super()._convert_cached_generations(deepcopy(cache_val))
        for generation in generations:
            restore_message_usage(generation.message)
        return generations

    def _combine_llm_outputs(self, llm_outputs):
        return combine_usage(llm_outputs)

    def stream(self, input, config=None, *, stop=None, **kwargs):
        owner = StreamOwner()
        iterator = super().stream(
            input, config, stop=stop, _genai_stream_owner=owner, **kwargs
        )
        try:
            yield from iterator
        finally:
            try:
                iterator.close()
            finally:
                owner.close()

    async def astream(self, input, config=None, *, stop=None, **kwargs):
        owner = StreamOwner()
        iterator = super().astream(
            input, config, stop=stop, _genai_stream_owner=owner, **kwargs
        )
        try:
            async for chunk in iterator:
                yield chunk
        finally:
            try:
                await iterator.aclose()
            finally:
                await close_in_executor(self.executor, owner)

    def _stream(self, messages, stop=None, run_manager=None, **kwargs):
        owner = kwargs.pop("_genai_stream_owner", None)
        params = self._params(stop=stop, **kwargs)
        if not self._responses_selected(params):
            yield from self._stream_chat(messages, params, owner, run_manager)
            return
        params.pop("use_responses_api", None)
        params.setdefault("model", self.model)
        payload = request_payload(messages, params, streaming=True)
        stream = check_budget(self._client.get_genai_response(request=payload))
        if owner is not None:
            owner.resource = stream
        converter = ResponseChunks()
        try:
            for event in stream:
                chunk = converter.convert(event)
                if chunk is not None:
                    # Public BaseChatModel.stream/astream owns callbacks. The
                    # private hook receives a manager only in direct hook use.
                    if run_manager is not None:
                        run_manager.on_llm_new_token(chunk.text, chunk=chunk)
                    yield chunk
                if converter.terminal:
                    return
            error = UnexpectedStreamEndError(
                "Responses stream ended without a terminal result.",
                event=converter.last_event,
            )
            error.response_id = converter.response_id
            error.events_observed = converter.events_observed
            error.request_id = getattr(stream, "_http_request_id", None)
            raise error
        except GenAIResponseError as error:
            error.request_id = getattr(stream, "_http_request_id", None)
            raise
        finally:
            stream.close()

    def _stream_chat(self, messages, params, owner, run_manager):
        params.pop("use_responses_api", None)
        params.pop("reasoning", None)
        params.setdefault("model", self.model)
        params = chat_params(params, streaming=True)
        stream = check_budget(
            self._client.get_genai_completion(
                messages=convert_messages_to_dicts(messages), **params
            )
        )
        if owner is not None:
            owner.resource = stream
        converter = ChatChunks()
        try:
            for event in stream:
                try:
                    chunk = converter.convert(event)
                except Exception as error:
                    raise converter.conversion_error(error, stream) from error
                if chunk is not None:
                    if run_manager is not None:
                        run_manager.on_llm_new_token(chunk.text, chunk=chunk)
                    yield chunk
            chunk = converter.finish(stream)
            if run_manager is not None:
                run_manager.on_llm_new_token(chunk.text, chunk=chunk)
            yield chunk
        finally:
            stream.close()

    def _iter_v2_events(self, messages, **kwargs):
        # Core's v3 bridge bypasses public stream(), and its generator wrappers
        # do not guarantee child close propagation on callback errors.
        owner = kwargs.setdefault("_genai_stream_owner", StreamOwner())
        iterator = super()._iter_v2_events(messages, **kwargs)
        try:
            yield from iterator
        finally:
            try:
                iterator.close()
            finally:
                owner.close()

    async def _aiter_v2_events(self, messages, **kwargs):
        owner = kwargs.setdefault("_genai_stream_owner", StreamOwner())
        iterator = super()._aiter_v2_events(messages, **kwargs)
        try:
            async for event in iterator:
                yield event
        finally:
            try:
                await iterator.aclose()
            finally:
                await close_in_executor(self.executor, owner)

    async def _astream(self, messages, stop=None, run_manager=None, **kwargs):
        owner = kwargs.pop("_genai_stream_owner", None)
        stream = ExecutorStream(self._stream(messages, stop=stop, **kwargs))
        if owner is not None:
            owner.resource = stream
        pending = None
        try:
            while True:
                pending = asyncio.create_task(
                    run_in_executor(self.executor, stream.next)
                )
                chunk = await asyncio.shield(pending)
                pending = None
                if chunk is stream.done:
                    return
                if run_manager is not None:
                    await run_manager.on_llm_new_token(chunk.text, chunk=chunk)
                yield chunk
        finally:
            try:
                await close_in_executor(self.executor, stream)
            finally:
                if pending is not None:
                    # Cancellation can win while the worker later raises. Read
                    # its result so asyncio cannot print a raw provider error as
                    # an unhandled task exception. The original caller failure
                    # or cancellation remains authoritative.
                    try:
                        await asyncio.shield(pending)
                    except (Exception, asyncio.CancelledError):
                        pass

    def close(self):
        """Close the owned manager; in-flight synchronous reads retain timeouts."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Call GenAiApiClient.get_genai_completion and return a ChatResult.

        Args:
            messages: The prompt messages.
            stop: Optional stop sequences.
            run_manager: Callback manager (unused by wrapper).
            **kwargs: Extra params merged with ``model_kwargs``.

        Returns:
            A ``ChatResult`` with one ``ChatGeneration`` containing an
            ``AIMessage``.
        """
        merged = self._params(stop=stop, **kwargs)
        responses = self._responses_selected(merged)
        merged.pop("use_responses_api", None)
        if responses:
            merged.setdefault("model", self.model)
            payload = request_payload(messages, merged, streaming=False)
            return response_result(
                check_budget(self._client.get_genai_response(request=payload))
            )
        merged.pop("reasoning", None)
        merged = chat_params(merged, streaming=False)
        merged.setdefault("model", self.model)
        msg_dicts = convert_messages_to_dicts(messages)
        response = check_budget(
            self._client.get_genai_completion(
                messages=msg_dicts,
                **merged,
            )
        )
        return convert_response_to_chat_result(response)

    async def _agenerate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: AsyncCallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Async version of ``_generate`` using ``run_in_executor``.

        Delegates to the synchronous ``_generate`` in a thread-pool
        executor so that the event loop is not blocked.  ``self.executor``
        (default ``None``) lets callers supply a custom executor.
        """
        return await run_in_executor(
            self.executor,
            self._generate,
            messages,
            stop,
            run_manager.get_sync() if run_manager else None,
            **kwargs,
        )

    def _get_ls_params(
        self,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LangSmithParams:
        """Return LangSmith tracing metadata for this model invocation."""
        params = LangSmithParams(
            ls_provider="genai",
            ls_model_name=self.model,
            ls_model_type="chat",
            ls_temperature=self.temperature,
        )
        if self.max_tokens is not None:
            params["ls_max_tokens"] = self.max_tokens
        if stop:
            params["ls_stop"] = stop
        return params

    # ------------------------------------------------------------------
    # Token counting
    # ------------------------------------------------------------------

    def get_token_ids(self, text: str) -> list[int]:
        """Return the token ids for *text* using ``tiktoken``.

        Falls back to the ``BaseChatModel`` default implementation if
        ``tiktoken`` is not installed.
        """
        try:
            encoding = self._get_encoding()
        except ImportError:
            return super().get_token_ids(text)
        return encoding.encode(text)

    def get_num_tokens_from_messages(
        self,
        messages: list[BaseMessage],
        tools: Optional[Sequence[dict[str, Any] | type | Callable | BaseTool]] = None,
        **kwargs: Any,
    ) -> int:
        """Count the tokens used by a list of *messages* with ``tiktoken``.

        Mirrors ``langchain_openai`` per-message overhead (3 tokens per
        message, 1 per ``name`` field, and 3 priming tokens for the
        reply).  Falls back to the ``BaseChatModel`` default when
        ``tiktoken`` is unavailable so token counting never crashes.

        Args:
            messages: The message inputs to tokenize.
            tools: Ignored; tool-schema token counting is not supported.
            **kwargs: Ignored extra keyword arguments.
        """
        if tools is not None:
            warnings.warn(
                "Counting tokens in tool schemas is not yet supported. Ignoring tools."
            )
        try:
            encoding = self._get_encoding()
        except ImportError:
            return super().get_num_tokens_from_messages(messages)

        # Per-message / per-name overhead (gpt-3.5-turbo / gpt-4 family).
        tokens_per_message = 3
        tokens_per_name = 1

        num_tokens = 0
        messages_dict = convert_messages_to_dicts(messages)
        for message in messages_dict:
            num_tokens += tokens_per_message
            for key, value in message.items():
                if key == "tool_call_id":
                    # Approximation; OpenAI does not document this.
                    num_tokens += 3
                    continue
                if isinstance(value, list):
                    # content blocks or tool calls
                    for val in value:
                        if isinstance(val, str):
                            num_tokens += len(encoding.encode(val))
                        elif val.get("type") == "text":
                            num_tokens += len(encoding.encode(val["text"]))
                        elif val.get("type") == "function":
                            num_tokens += len(
                                encoding.encode(val["function"]["arguments"])
                            )
                            num_tokens += len(encoding.encode(val["function"]["name"]))
                        # image_url / file blocks are not counted here.
                elif value:
                    # Cast in case the value is not already a string.
                    num_tokens += len(encoding.encode(str(value)))
                if key == "name":
                    num_tokens += tokens_per_name
        # Every reply is primed with <im_start>assistant.
        num_tokens += 3
        return num_tokens

    def _get_encoding(self) -> Any:
        """Return a ``tiktoken`` encoding for ``self.model``.

        Tries ``encoding_for_model`` first, then falls back to
        ``o200k_base`` and finally ``cl100k_base``.  Raises
        ``ImportError`` if ``tiktoken`` is not installed so callers can
        fall back to the base implementation.
        """
        import tiktoken  # noqa: PLC0415 — optional dependency, imported lazily

        try:
            return tiktoken.encoding_for_model(self.model)
        except KeyError:
            try:
                return tiktoken.get_encoding("o200k_base")
            except (KeyError, ValueError):
                return tiktoken.get_encoding("cl100k_base")

    # ------------------------------------------------------------------
    # Tool calling
    # ------------------------------------------------------------------

    def bind_tools(
        self,
        tools: Sequence[dict[str, Any] | type | Callable | BaseTool],
        *,
        tool_choice: str | dict | bool | None = None,
        strict: bool | None = None,
        parallel_tool_calls: bool | None = None,
        **kwargs: Any,
    ) -> Runnable:
        """Bind tool definitions to this model.

        Args:
            tools: Tool definitions (dicts, Pydantic classes, callables,
                or ``BaseTool`` instances).
            tool_choice: Which tool to require.  Accepts a tool name
                string, ``True`` / ``"any"`` / ``"required"`` to force a
                call, ``"auto"`` / ``"none"`` for default behaviour, or
                a raw dict.
            strict: If ``True``, model output is guaranteed to match the
                tool JSON schema exactly (set on each tool definition).
                If ``False``, strict mode is explicitly disabled.
                If ``None``, the ``strict`` key is omitted.
            parallel_tool_calls: If ``False``, disables parallel tool
                calling.  Passed directly to the API.
            **kwargs: Additional keyword arguments passed to ``bind``.

        Returns:
            A ``Runnable`` with the tools bound as kwargs.
        """
        formatted_tools = [
            convert_to_openai_tool(tool, strict=strict) for tool in tools
        ]

        if parallel_tool_calls is not None:
            kwargs["parallel_tool_calls"] = parallel_tool_calls

        # Collect tool names for choice normalisation.
        tool_names: list[str] = []
        for t in formatted_tools:
            if "function" in t:
                tool_names.append(t["function"]["name"])
            elif "name" in t:
                tool_names.append(t["name"])

        if tool_choice is not None:
            if isinstance(tool_choice, str):
                if tool_choice in tool_names:
                    tool_choice = {
                        "type": "function",
                        "function": {"name": tool_choice},
                    }
                elif tool_choice == "any":
                    tool_choice = "required"
                # "auto", "none", "required" pass through as-is.
            elif isinstance(tool_choice, bool):
                tool_choice = "required" if tool_choice else "none"
            elif isinstance(tool_choice, dict):
                pass
            else:
                raise ValueError(
                    f"Unrecognized tool_choice type. Expected str, bool or "
                    f"dict. Received: {tool_choice}"
                )
            kwargs["tool_choice"] = tool_choice

        return super().bind(tools=formatted_tools, **kwargs)

    # ------------------------------------------------------------------
    # Structured output
    # ------------------------------------------------------------------

    def with_structured_output(
        self,
        schema: Optional[type | dict[str, Any]] = None,
        *,
        include_raw: bool = False,
        method: Literal["function_calling", "json_schema", "json_mode"] = "json_schema",
        strict: Optional[bool] = None,
        **kwargs: Any,
    ) -> Runnable:
        """Return a Runnable that parses model output into *schema*.

        Supports three methods for structured output:
        - ``json_schema`` (default, matching ``AzureChatOpenAI``): Uses an
          OpenAI ``response_format`` of type ``json_schema`` to constrain
          the model's JSON output
        - ``function_calling``: Uses tool calling (most compatible)
        - ``json_mode``: Returns JSON without enforcing schema

        All methods validate successful completion and complete final JSON.
        Streaming emits one validated parsed value; ``include_raw=True`` also
        forwards raw chunks incrementally. Accumulate those chunks with ``+``.
        Parser failures raise ``OutputParserException`` or populate
        ``parsing_error`` when raw output is requested. Provider errors retain
        their existing exception types.

        Args:
            schema: A Pydantic class or JSON-schema dict describing the
                desired output structure. Required for ``function_calling``
                and ``json_schema`` methods. Optional for ``json_mode``.
            include_raw: If ``True``, return a dict with ``raw``,
                ``parsed``, and ``parsing_error`` keys. Default: ``False``.
            method: The method to use for structured output:
                - ``"json_schema"`` (default): Binds a ``response_format`` of
                  type ``json_schema`` and parses the JSON content
                - ``"function_calling"``: Binds schema as a tool
                - ``"json_mode"``: Returns valid JSON (schema not enforced)
            strict: Enable strict schema validation. ``None`` defaults to
                ``True`` for Pydantic schemas under ``method="json_schema"``
                (mirroring ``AzureChatOpenAI``'s SDK ``.parse()`` path) and
                ``False`` otherwise. Default: ``None``.
            **kwargs: Additional keyword args passed through to the model
                (bound onto the returned runnable), matching
                ``AzureChatOpenAI``/langchain-openai >= 0.3.21 behavior.

        Returns:
            A ``Runnable`` producing instances of *schema* (or a dict
            when *include_raw* is ``True``).

        Raises:
            ValueError: If schema is required but not provided, or if
                method/strict combination is invalid.

        Examples:
            Basic Pydantic schema:

            .. code-block:: python

                from pydantic import BaseModel

                class Person(BaseModel):
                    name: str
                    age: int

                structured = model.with_structured_output(Person)
                result = structured.invoke("John is 30 years old")
                # result is a Person instance

            With include_raw for error handling:

            .. code-block:: python

                structured = model.with_structured_output(
                    Person,
                    include_raw=True
                )
                result = structured.invoke("...")
                if result["parsing_error"]:
                    print(f"Error: {result['parsing_error']}")
                else:
                    person = result["parsed"]

            Using json_mode for flexible JSON:

            .. code-block:: python

                structured = model.with_structured_output(
                    method="json_mode"
                )
                result = structured.invoke(
                    "Return JSON with name and age fields"
                )
                # result is a dict (schema not enforced)
        """
        # Validate method parameter
        if method not in ("function_calling", "json_schema", "json_mode"):
            raise ValueError(
                f"Invalid method '{method}'. Must be one of: "
                f"'function_calling', 'json_schema', 'json_mode'"
            )

        # Mirror upstream langchain-openai: json_schema does not support
        # pydantic v1 schemas or pre-Structured-Output models — warn and
        # fall back to function_calling in both cases.
        if method == "json_schema":
            if _is_pydantic_class(schema) and not (
                isinstance(schema, type) and issubclass(schema, PydanticV2BaseModel)
            ):
                warnings.warn(
                    "Received a Pydantic BaseModel V1 schema. This is not supported "
                    'by method="json_schema". Please use method="function_calling" '
                    "or specify schema via JSON Schema or Pydantic V2 BaseModel. "
                    'Overriding to method="function_calling".'
                )
                method = "function_calling"
            if self.model and (
                self.model.startswith("gpt-3")
                or self.model.startswith("gpt-4-")
                or self.model == "gpt-4"
            ):
                warnings.warn(
                    f"Cannot use method='json_schema' with model {self.model} "
                    "since it doesn't support OpenAI's Structured Output API. "
                    "Overriding to method='function_calling'."
                )
                method = "function_calling"

        # Validate schema requirement
        if method in ("function_calling", "json_schema") and schema is None:
            raise ValueError(
                f"schema is required when method='{method}'. "
                f"Either provide a schema or use method='json_mode'."
            )

        # Validate strict parameter compatibility (rejects any
        # non-None strict with json_mode, not just True).
        if strict is not None and method == "json_mode":
            raise ValueError(
                "Argument `strict` is not supported with `method`='json_mode'. "
                "Use 'function_calling' or 'json_schema' for strict validation."
            )

        # Route to appropriate implementation
        if method == "json_mode":
            return self._with_structured_output_json_mode(
                schema=schema,
                include_raw=include_raw,
                **kwargs,
            )
        elif method == "json_schema":
            return self._with_structured_output_json_schema(
                schema=schema,  # type: ignore[arg-type]
                include_raw=include_raw,
                strict=strict,
                **kwargs,
            )
        else:
            return self._with_structured_output_function_calling(
                schema=schema,  # type: ignore[arg-type]
                include_raw=include_raw,
                strict=strict,
                **kwargs,
            )

    def _with_structured_output_function_calling(
        self,
        schema: type | dict[str, Any],
        *,
        include_raw: bool,
        strict: Optional[bool],
        **kwargs: Any,
    ) -> Runnable:
        """Implementation of the function_calling method."""
        # Convert once with strict applied; bind_tools receives the
        # already-formatted tool (mirrors upstream langchain-openai).
        formatted_tool = convert_to_openai_tool(schema, strict=strict)
        tool_name = formatted_tool["function"]["name"]

        # tool_choice defaults to the structured-output tool; **kwargs last
        # so callers can override, matching upstream langchain-openai.
        # parallel_tool_calls is NOT sent: AzureChatOpenAI filters it out by
        # default (disabled_params) because many Azure models reject it.
        llm = self.bind_tools(
            [formatted_tool],
            **{
                "tool_choice": tool_name,
                "ls_structured_output_format": {
                    "kwargs": {"method": "function_calling", "strict": strict},
                    "schema": schema,
                },
                **kwargs,
            },
        )

        return self._structured_result(
            llm,
            schema=schema,
            method="function_calling",
            include_raw=include_raw,
            tool_name=tool_name,
        )

    def _with_structured_output_json_schema(
        self,
        schema: type | dict[str, Any],
        *,
        include_raw: bool,
        strict: Optional[bool],
        **kwargs: Any,
    ) -> Runnable:
        """Implementation of the ``json_schema`` method.

        Binds an OpenAI ``response_format`` of type ``json_schema`` (which
        the backend forwards untouched to the chat completions API) and
        parses the JSON *content* of the response.  Unlike
        ``function_calling`` this binds no tools.
        """
        is_pydantic = isinstance(schema, type) and _is_pydantic_class(schema)

        # Mirror AzureChatOpenAI: its Pydantic path goes through the SDK's
        # .parse(), which requests strict structured outputs by default.
        if strict is None and is_pydantic:
            strict = True

        response_format = _convert_to_openai_response_format(schema, strict=strict)

        # Upstream reports the converted tool in LangSmith metadata; fall back
        # to the raw schema for pre-formed response_format dicts it can't parse.
        try:
            ls_schema: Any = convert_to_openai_tool(schema)
        except Exception:
            ls_schema = schema
        bind_kwargs = {
            "response_format": response_format,
            "ls_structured_output_format": {
                "kwargs": {"method": "json_schema", "strict": strict},
                "schema": ls_schema,
            },
            **kwargs,
        }
        llm = self.bind(**bind_kwargs)

        return self._structured_result(
            llm,
            schema=schema,
            method="json_schema",
            include_raw=include_raw,
        )

    def _with_structured_output_json_mode(
        self,
        schema: Optional[type | dict[str, Any]],
        *,
        include_raw: bool,
        **kwargs: Any,
    ) -> Runnable:
        """Implementation of json_mode method.

        Returns valid JSON but does NOT enforce the schema — include schema
        instructions in the prompt.  No warning is emitted (AzureChatOpenAI
        is silent here; a warning breaks warnings-as-errors setups).
        The schema (if provided) is used only for parsing hints.
        """
        # JSON mode: add response_format to model kwargs
        # Note: This requires your GenAI backend to support json_object response format
        bind_kwargs = {
            "response_format": {"type": "json_object"},
            "ls_structured_output_format": {
                "kwargs": {"method": "json_mode"},
                "schema": schema,
            },
            **kwargs,
        }
        llm = self.bind(**bind_kwargs)

        return self._structured_result(
            llm,
            schema=schema,
            method="json_mode",
            include_raw=include_raw,
        )

    @staticmethod
    def _structured_result(llm, *, schema, method, include_raw, tool_name=None):
        parse = partial(
            parse_final,
            schema=schema,
            method=method,
            tool_name=tool_name,
            refusal_error=GenAIRefusalError,
        )
        result = FinalStructuredOutput(
            llm, parse, include_raw=include_raw, refusal_error=GenAIRefusalError
        )
        if not include_raw and isinstance(schema, type) and _is_pydantic_class(schema):
            return result.with_types(output_type=schema)
        return result


def _convert_to_openai_response_format(
    schema: type | dict[str, Any],
    *,
    strict: Optional[bool] = None,
) -> dict[str, Any]:
    """Build an OpenAI ``response_format`` dict for the ``json_schema`` method.

    Mirrors ``langchain_openai._convert_to_openai_response_format`` but always
    returns a plain dict (the GenAi/Azure backend cannot consume a raw Pydantic
    class), shaped as::

        {"type": "json_schema",
         "json_schema": {"name": <name>, "schema": <json schema>,
                         "strict": <bool>}}

    Args:
        schema: A Pydantic class, TypedDict, or JSON-schema/function dict.
        strict: Whether to request strict schema adherence.  ``None`` is
            treated as ``False``.

    Returns:
        A ``response_format`` dict ready to forward to the backend.
    """
    # Pre-formed response_format dicts pass through, but an explicit strict
    # must agree with the schema's own strict — upstream raises on mismatch
    # instead of silently dropping the caller's request.
    response_format: Optional[dict[str, Any]] = None
    if (
        isinstance(schema, dict)
        and "json_schema" in schema
        and schema.get("type") == "json_schema"
    ):
        response_format = schema
    elif isinstance(schema, dict) and "name" in schema and "schema" in schema:
        response_format = {"type": "json_schema", "json_schema": schema}
    if response_format is not None:
        if strict is not None and strict is not response_format["json_schema"].get(
            "strict"
        ):
            raise ValueError(
                "Output schema already has 'strict' value set to "
                f"{response_format['json_schema'].get('strict')} but 'strict' "
                f"also passed in to with_structured_output as {strict}. "
                "Please make sure that 'strict' is only specified in one place."
            )
        return response_format

    if strict is None:
        if isinstance(schema, dict) and isinstance(schema.get("strict"), bool):
            strict = schema["strict"]
        else:
            strict = False

    # Derive name + JSON schema from a function/Pydantic/dict schema.
    function = convert_to_openai_function(schema, strict=strict)
    if strict and isinstance(schema, type) and issubclass(schema, PydanticV2BaseModel):
        # convert_to_openai_function only completes 'required' at the top
        # level; strict mode needs every nesting level transformed. Use the
        # same OpenAI-SDK helper AzureChatOpenAI's .parse() path relies on.
        from openai.lib._pydantic import to_strict_json_schema

        function["parameters"] = to_strict_json_schema(schema)
    function["schema"] = function.pop("parameters")
    # description is valid in the json_schema body and used by the model for steering.
    function["strict"] = bool(strict)
    return {"type": "json_schema", "json_schema": function}


def _is_pydantic_class(obj: Any) -> bool:
    """Return ``True`` if *obj* is a Pydantic model class (v1 or v2).

    Uses ``is_basemodel_subclass`` like upstream langchain-openai so
    ``pydantic.v1.BaseModel`` schemas get Pydantic parsers too.
    """
    return isinstance(obj, type) and is_basemodel_subclass(obj)
