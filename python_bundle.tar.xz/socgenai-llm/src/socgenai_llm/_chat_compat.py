"""Chat chunk conversion for the pinned LangChain version; no SDK dispatch."""

from copy import deepcopy

from langchain_core.messages import AIMessageChunk
from langchain_core.outputs import ChatGenerationChunk
from langchain_openai.chat_models.base import _convert_delta_to_message_chunk

from genai_api_manager import StreamAssemblyError, UnexpectedStreamEndError
from socgenai_llm._usage import project_usage


def chat_params(params, *, streaming=None):
    """Resolve transport controls without changing the caller's dictionaries."""
    params = deepcopy(params)
    extra = params.get("extra_body") or {}
    if not isinstance(extra, dict):
        raise ValueError("extra_body must be a mapping.")
    for key in ("stream", "n"):
        if key in extra:
            if params.get(key) is not None and params[key] != extra[key]:
                raise ValueError(f"Conflicting {key} in extra_body.")
            params[key] = extra.pop(key)
    if params.get("stream") is not None and type(params["stream"]) is not bool:
        raise ValueError("stream must be a boolean.")
    if streaming and params.get("n", 1) != 1:
        raise ValueError("Chat streaming supports only one result (n=1).")
    # Ordinary calls leave omitted stream selection to the manager's default.
    if streaming is True or (streaming is False and params.get("stream") is True):
        params["stream"] = streaming
    if streaming is False:
        params.pop("stream_options", None)
        extra.pop("stream_options", None)
    return params


class ChatChunks:
    """Preserve deltas, then emit authoritative usage once after exhaustion."""

    def __init__(self):
        self.last_event = None
        self.events_observed = 0
        self.response_id = None
        self.finish_reason = None
        self.usage = None
        self.metadata = {}

    def error_context(self, error, stream):
        error.event = self.last_event
        error.response_id = self.response_id
        error.request_id = getattr(stream, "_http_request_id", None)
        error.usage = self.usage
        error.events_observed = self.events_observed
        return error

    def convert(self, event):
        self.last_event = event
        self.events_observed += 1
        self.response_id = getattr(event, "id", None) or self.response_id
        if getattr(event, "usage", None) is not None:
            self.usage = event.usage
        data = event.model_dump(exclude_none=True, warnings=False)
        for source, target in (
            ("model", "model_name"),
            ("system_fingerprint", "system_fingerprint"),
            ("service_tier", "service_tier"),
            ("prompt_filter_results", "prompt_filter_results"),
        ):
            if source in data:
                self.metadata[target] = data[source]
        choices = data.get("choices", [])
        if not choices:
            return None
        if len(choices) != 1 or choices[0].get("index") != 0:
            raise ValueError("Expected only completion choice index 0.")
        choice = choices[0]
        if choice.get("finish_reason") and self.finish_reason != "content_filter":
            self.finish_reason = choice["finish_reason"]
        delta = choice.get("delta") or {}
        for tool in delta.get("tool_calls", []):
            if type(tool.get("index")) is not int or tool["index"] < 0:
                raise ValueError("Tool fragments require a nonnegative index.")
            if not isinstance(tool.get("function"), dict):
                raise ValueError("Tool fragments require function data.")
        message = _convert_delta_to_message_chunk(delta, AIMessageChunk)
        message.id = self.response_id
        # The native delta helper omits these fields. Keep originals for strict
        # final parsing instead of relying on partially repaired tool arguments.
        for key in ("tool_calls", "refusal"):
            if key in delta:
                message.additional_kwargs[key] = delta[key]
        info = {}
        for key in ("logprobs", "content_filter_results"):
            if key in choice:
                info[key] = choice[key]
        if choice.get("finish_reason"):
            info["finish_reason"] = self.finish_reason
        return ChatGenerationChunk(message=message, generation_info=info or None)

    def finish(self, stream):
        if self.finish_reason is None:
            raise self.error_context(
                UnexpectedStreamEndError("Chat stream ended without a finish reason."),
                stream,
            )
        if self.finish_reason == "content_filter":
            raise ValueError(
                "Azure has not provided the response due to a content filter "
                "being triggered"
            )
        try:
            return self._final_chunk()
        except Exception as error:
            raise self.conversion_error(error, stream) from error

    def _final_chunk(self):
        usage_metadata, annotation = project_usage(self.usage)
        self.metadata.update(annotation)
        return ChatGenerationChunk(
            message=AIMessageChunk(
                content="",
                id=self.response_id,
                usage_metadata=usage_metadata,
                response_metadata=self.metadata,
                chunk_position="last",
            )
        )

    def conversion_error(self, error, stream):
        return self.error_context(
            StreamAssemblyError(
                "Cannot convert Chat stream event.", details={"reason": str(error)}
            ),
            stream,
        )
