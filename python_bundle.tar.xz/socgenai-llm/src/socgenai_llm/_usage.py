"""Result usage projections; billing remains exclusively in the manager."""

from copy import deepcopy


INPUT_DETAILS = {
    "audio": "audio_tokens",
    "cache_read": "cached_tokens",
    "cache_creation": "cache_write_tokens",
}
OUTPUT_DETAILS = {
    "audio": "audio_tokens",
    "reasoning": "reasoning_tokens",
    "accepted_prediction": "accepted_prediction_tokens",
    "rejected_prediction": "rejected_prediction_tokens",
}


def _count(value):
    return type(value) is int and value >= 0


def project_usage(usage, *, responses=False):
    """Return (LangChain usage or None, lossless raw usage and safe status)."""
    raw = (
        usage.model_dump(warnings=False)
        if hasattr(usage, "model_dump")
        else deepcopy(usage)
    )
    metadata = {"usage": raw, "usage_status": "unknown"}
    if not responses:
        metadata["token_usage"] = deepcopy(raw)

    def unknown(reason):
        metadata["usage_reason"] = reason
        return None, metadata

    if raw is None:
        return unknown("missing")
    if not isinstance(raw, dict):
        return unknown("invalid")
    input_key, output_key = (
        ("input_tokens", "output_tokens")
        if responses
        else ("prompt_tokens", "completion_tokens")
    )
    counts = [raw.get(k) for k in (input_key, output_key, "total_tokens")]
    if any(v is not None and not _count(v) for v in counts):
        return unknown("invalid")
    if any(v is None for v in counts):
        return unknown("incomplete")
    inputs, outputs, total = counts
    if inputs + outputs != total:
        return unknown("invalid")
    normalized = dict(zip(("input_tokens", "output_tokens", "total_tokens"), counts))
    for field, canonical, mapping, parent in (
        (input_key + "_details", "input_token_details", INPUT_DETAILS, inputs),
        (output_key + "_details", "output_token_details", OUTPUT_DETAILS, outputs),
    ):
        details = raw.get(field)
        if details is None:
            continue
        if not isinstance(details, dict):
            return unknown("invalid")
        translated = {}
        for target, source in mapping.items():
            value = details.get(source)
            if value is None:
                continue
            if not _count(value) or value > parent:
                return unknown("invalid")
            translated[target] = value
        if canonical == "input_token_details" and (
            translated.get("cache_read", 0) + translated.get("cache_creation", 0)
            > inputs
        ):
            return unknown("invalid")
        if translated:
            normalized[canonical] = translated
    metadata["usage_status"] = "known"
    return normalized, metadata


def token_usage(normalized):
    """Translate known normalized counts to the common Chat aggregate schema."""
    if normalized is None:
        return {}
    result = {
        "prompt_tokens": normalized["input_tokens"],
        "completion_tokens": normalized["output_tokens"],
        "total_tokens": normalized["total_tokens"],
    }
    for source, target, mapping in (
        ("input_token_details", "prompt_tokens_details", INPUT_DETAILS),
        ("output_token_details", "completion_tokens_details", OUTPUT_DETAILS),
    ):
        details = normalized.get(source, {})
        if details:
            result[target] = {
                wire: details[key] for key, wire in mapping.items() if key in details
            }
    return result


def restore_message_usage(message):
    """Normalize a copied cached/final message, including legacy cache entries."""
    metadata = message.response_metadata
    if metadata.get("usage_status") == "unknown":
        # Core may have inserted total_cost=0 into an unknown cached message.
        # The adapter already classified the original usage; preserve that fact.
        message.usage_metadata = None
        return message
    raw = metadata.get("usage", metadata.get("token_usage"))
    if (
        "usage" not in metadata
        and "token_usage" not in metadata
        and message.usage_metadata
    ):
        # Older caches may retain only the standardized LangChain counts.
        prior = message.usage_metadata
        required = ("input_tokens", "output_tokens", "total_tokens")
        if all(k in prior for k in required):
            raw = token_usage(prior)
    responses = isinstance(raw, dict) and (
        metadata.get("object") == "response"
        or (
            not any(k in raw for k in ("prompt_tokens", "completion_tokens"))
            and any(k in raw for k in ("input_tokens", "output_tokens"))
        )
    )
    normalized, annotation = project_usage(raw, responses=responses)
    message.usage_metadata = normalized
    message.response_metadata = {**metadata, **annotation}
    message.response_metadata.pop("usage_reason", None)
    if "usage_reason" in annotation:
        message.response_metadata["usage_reason"] = annotation["usage_reason"]
    return message


def result_with_usage(result):
    """Recover request summaries after core cache/stream assembly, without mutation."""
    result = result.model_copy(deep=True)
    if not result.generations:
        return result
    # Usage is request-scoped even if a future converter exposes more choices.
    message = restore_message_usage(result.generations[0].message)
    metadata = message.response_metadata
    output = deepcopy(result.llm_output or {})
    output.update(
        token_usage=token_usage(message.usage_metadata),
        usage_status=metadata["usage_status"],
    )
    output.pop("usage_reason", None)
    if "usage_reason" in metadata:
        output["usage_reason"] = metadata["usage_reason"]
    for key in ("model_name", "system_fingerprint"):
        if key in metadata:
            output[key] = deepcopy(metadata[key])
    result.llm_output = output
    return result


def _sum_usage(usages):
    result = {
        key: sum(usage[key] for usage in usages)
        for key in ("prompt_tokens", "completion_tokens", "total_tokens")
    }
    for field in ("prompt_tokens_details", "completion_tokens_details"):
        keys = set.intersection(*(set(usage.get(field, {})) for usage in usages))
        if keys:
            result[field] = {
                key: sum(usage[field][key] for usage in usages) for key in sorted(keys)
            }
    return result


def combine_usage(outputs):
    """Aggregate once per request, retaining an explicit known-only subtotal."""
    outputs = [output or {} for output in outputs]
    known = [o["token_usage"] for o in outputs if o.get("usage_status") == "known"]
    complete = bool(outputs) and len(known) == len(outputs)
    totals = _sum_usage(known) if known else {}
    result = {
        "token_usage": totals
        if complete
        else {"known_subtotal": totals}
        if known
        else {},
        "usage_status": "known" if complete else "unknown",
        "usage_coverage": {
            "total_requests": len(outputs),
            "known_requests": len(known),
            "unknown_requests": len(outputs) - len(known),
        },
    }
    for key in ("model_name", "system_fingerprint"):
        values = [o.get(key) for o in outputs]
        if values and values[0] and all(v == values[0] for v in values):
            result[key] = values[0]
        elif key == "model_name":
            result["model_names"] = sorted(
                {v for v in values if isinstance(v, str) and v}
            )
    return result
