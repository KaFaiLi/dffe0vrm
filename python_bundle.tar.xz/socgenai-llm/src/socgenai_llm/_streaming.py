"""Synchronous iterator ownership for LangChain's executor-backed async API."""

import asyncio
from threading import Lock

from langchain_core.runnables.config import run_in_executor


class StreamOwner:
    """Close one invocation's resource even when a public callback raises."""

    def __init__(self):
        self.resource = None

    def close(self):
        if self.resource is not None:
            self.resource.close()


class ExecutorStream:
    """Serialize next/close, including cancellation during a synchronous read."""

    def __init__(self, iterator):
        self.iterator = iterator
        self.lock = Lock()
        self.closed = False
        self.done = object()

    def next(self):
        with self.lock:
            if self.closed:
                return self.done
            return next(self.iterator, self.done)

    def close(self):
        with self.lock:
            if not self.closed:
                self.closed = True
                self.iterator.close()


async def close_in_executor(executor, resource):
    """Finish cleanup even if cancellation is requested more than once."""
    task = asyncio.create_task(run_in_executor(executor, resource.close))
    cancelled = False
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            cancelled = True
    task.result()
    if cancelled:
        raise asyncio.CancelledError
