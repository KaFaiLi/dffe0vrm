"""GenAIEmbeddings — LangChain Embeddings backed by GenAiApiClient.

This module provides ``GenAIEmbeddings``, a thin wrapper that delegates
embedding requests to :class:`genai_api_client.GenAiApiClient` while
exposing the standard LangChain ``Embeddings`` interface.
"""

from __future__ import annotations

from typing import Any, Optional

from langchain_core.embeddings import Embeddings
from pydantic import BaseModel, ConfigDict

from genai_api_manager.genai_api_client import GenAiApiClient

from socgenai_llm._client_delegates import ClientDelegatesMixin


class GenAIEmbeddings(ClientDelegatesMixin, BaseModel, Embeddings):
    """LangChain embeddings model backed by :class:`GenAiApiClient`.

    All network calls are synchronous and delegate to
    ``GenAiApiClient.get_genai_embeddings``.  Async support is provided
    by the default ``Embeddings`` base class implementation which uses
    ``run_in_executor``.

    ``embed_documents`` automatically batches large inputs so that no
    single backend request exceeds ``chunk_size`` items (the Azure
    guidance is 2048 items per request).  When ``tiktoken`` is available
    it is also token-length safe: any single text longer than
    ``embedding_ctx_length`` tokens is split into sub-chunks which are
    embedded separately and recombined into a single vector via a
    token-count-weighted average followed by L2 normalisation.  If
    ``tiktoken`` is unavailable or the model is unknown to it, the class
    gracefully falls back to plain ``chunk_size`` batching without token
    splitting.

    Args:
        model: Azure OpenAI embedding model name (required).
        dimensions: Embedding dimensionality; ``None`` uses model default.
        encoding_format: Encoding format (``"float"`` or ``"base64"``);
            ``None`` uses model default.
        chunk_size: Maximum number of texts to embed in a single backend
            request.  Defaults to ``2048`` (the Azure per-request limit).
        embedding_ctx_length: Maximum number of tokens allowed in a single
            input.  Texts longer than this are split and recombined.
            Defaults to ``8191``.
        config_path: Path to ``config.yaml``.  ``None`` uses the client's
            built-in default.

    Example:
        .. code-block:: python

            from socgenai_llm import GenAIEmbeddings

            embeddings = GenAIEmbeddings(model="text-embedding-3-small")
            vectors = embeddings.embed_documents(["Hello", "World"])
    """

    model: str
    dimensions: Optional[int] = None
    encoding_format: Optional[str] = None
    chunk_size: int = 2048
    embedding_ctx_length: int = 8191
    config_path: Optional[str] = None

    # --- internal state ---
    _client: GenAiApiClient = None  # type: ignore[assignment]

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def model_post_init(self, __context: Any) -> None:
        """Instantiate the underlying GenAiApiClient."""
        super().model_post_init(__context)
        self._client = (
            GenAiApiClient(config_path=self.config_path)
            if self.config_path
            else GenAiApiClient()
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _request_params(self) -> dict[str, Any]:
        """Build the optional backend params shared by all requests."""
        params: dict[str, Any] = {}
        if self.dimensions is not None:
            params["dimensions"] = self.dimensions
        if self.encoding_format is not None:
            params["encoding_format"] = self.encoding_format
        return params

    def _embed_batch(
        self, batch: list[str] | list[str | list[int]], params: dict[str, Any]
    ) -> list[list[float]]:
        """Embed a single batch of inputs via one backend call.

        Each batch item is either a raw string or a token sub-array; both
        are accepted by the backend's ``input`` parameter.
        """
        return self._client.get_genai_embeddings(
            input=batch,
            model=self.model,
            embeddings_only=True,
            **params,
        )

    def _embed_plain(
        self, texts: list[str], params: dict[str, Any]
    ) -> list[list[float]]:
        """Embed ``texts`` using plain ``chunk_size`` batching.

        Splits ``texts`` into batches of at most ``chunk_size`` items,
        issues one backend call per batch, and concatenates the resulting
        vectors in order.  This is the fallback used when token-length
        safety is unavailable.
        """
        embeddings: list[list[float]] = []
        for i in range(0, len(texts), self.chunk_size):
            batch = texts[i : i + self.chunk_size]
            embeddings.extend(self._embed_batch(batch, params))
        return embeddings

    def _embed_len_safe(
        self, texts: list[str], params: dict[str, Any]
    ) -> list[list[float]]:
        """Embed ``texts`` with token-length safety.

        Each text is tokenised with ``tiktoken`` to measure its length.
        Texts within ``embedding_ctx_length`` are sent to the backend as
        their original strings (so the common case passes raw text); only
        texts that exceed the limit are split into sub-chunks of at most
        ``embedding_ctx_length`` tokens.  All chunks (across all texts) are
        batched into backend requests of at most ``chunk_size`` items.
        Sub-chunks of a single text are then recombined into one vector via
        a token-count-weighted average followed by L2 normalisation.

        Raises:
            KeyError: If ``tiktoken`` does not recognise ``self.model``.
                The caller is expected to fall back to plain batching.
        """
        import tiktoken

        encoding = tiktoken.encoding_for_model(self.model)

        # Flatten every text into one or more chunks.  Each chunk is the
        # payload to send to the backend: the original string when it fits
        # within ``embedding_ctx_length``, otherwise a token sub-array.
        # ``indices`` maps each chunk back to its originating text;
        # ``token_counts`` records the token length of each chunk (the
        # averaging weight used when recombining split texts).
        chunks: list[str | list[int]] = []
        indices: list[int] = []
        token_counts: list[int] = []
        for i, text in enumerate(texts):
            tokens = encoding.encode_ordinary(text)
            if len(tokens) <= self.embedding_ctx_length:
                # Always use the token array so every item in `chunks` is
                # uniformly list[int]. Mixing raw str with list[int] in the
                # same backend batch causes HTTP 400 from the Azure/OpenAI API.
                chunks.append(tokens)
                indices.append(i)
                token_counts.append(len(tokens))
                continue
            for j in range(0, len(tokens), self.embedding_ctx_length):
                sub = tokens[j : j + self.embedding_ctx_length]
                chunks.append(sub)
                indices.append(i)
                token_counts.append(len(sub))

        # Embed all chunks, batching by ``chunk_size`` items per request.
        chunk_embeddings: list[list[float]] = []
        for i in range(0, len(chunks), self.chunk_size):
            batch = chunks[i : i + self.chunk_size]
            chunk_embeddings.extend(self._embed_batch(batch, params))

        # Recombine chunks belonging to the same text.
        results: list[list[list[float]]] = [[] for _ in texts]
        weights: list[list[int]] = [[] for _ in texts]
        for chunk_idx, text_idx in enumerate(indices):
            results[text_idx].append(chunk_embeddings[chunk_idx])
            weights[text_idx].append(token_counts[chunk_idx])

        embeddings: list[list[float]] = []
        for text_idx in range(len(texts)):
            text_chunks = results[text_idx]
            if len(text_chunks) == 1:
                # The common case: one chunk, one vector — no maths needed.
                embeddings.append(text_chunks[0])
                continue
            embeddings.append(_weighted_average_norm(text_chunks, weights[text_idx]))
        return embeddings

    # ------------------------------------------------------------------
    # Embeddings interface
    # ------------------------------------------------------------------

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of documents.

        The input is automatically batched so that no single backend
        request exceeds ``chunk_size`` items.  When ``tiktoken`` is
        available and recognises the model, oversized texts are split on
        token boundaries and recombined; otherwise plain batching is used.

        Args:
            texts: The texts to embed.

        Returns:
            A list of embedding vectors (one per input text, in order).
            Returns ``[]`` for empty input without making a network call.
        """
        if not texts:
            return []

        params = self._request_params()

        # Prefer token-length-safe embedding, but never crash if tiktoken
        # (or the model) is unavailable: fall back to plain batching.
        try:
            return self._embed_len_safe(texts, params)
        except (ImportError, KeyError):
            return self._embed_plain(texts, params)

    def embed_query(self, text: str) -> list[float]:
        """Embed a single query text.

        Args:
            text: The text to embed.

        Returns:
            A single embedding vector.
        """
        params = self._request_params()

        return self._client.get_genai_embeddings(
            input=text,
            model=self.model,
            embeddings_only=True,
            **params,
        )


def _weighted_average_norm(
    vectors: list[list[float]], weights: list[int]
) -> list[float]:
    """Token-count-weighted average of ``vectors`` with L2 normalisation.

    Mirrors the recombination used by ``OpenAIEmbeddings`` for long inputs
    (see the OpenAI cookbook).  Implemented in pure Python so that it does
    not depend on ``numpy``.

    Args:
        vectors: The per-chunk embedding vectors (all the same length).
        weights: The token count of each chunk, used as the averaging
            weight.  A zero total weight (e.g. all-empty chunks) falls back
            to an unweighted mean to avoid division by zero.

    Returns:
        A single L2-normalised vector.
    """
    total_weight = sum(weights)
    if total_weight == 0:
        # All chunks were empty; weight each equally to avoid /0.
        weights = [1] * len(weights)
        total_weight = len(weights)

    average = [
        sum(val * weight for val, weight in zip(component, weights)) / total_weight
        for component in zip(*vectors)
    ]

    magnitude = sum(val**2 for val in average) ** 0.5
    if magnitude == 0:
        return average
    return [val / magnitude for val in average]
