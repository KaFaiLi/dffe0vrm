"""langchain_genai — LangChain-compatible wrappers for GenAiApiClient."""

from .chat_model import GenAIChatModel, GenAIRefusalError
from .embeddings import GenAIEmbeddings
from ._responses_compat import GenAIBudgetExceededError, GenAIResponseError

__all__ = [
    "GenAIChatModel",
    "GenAIEmbeddings",
    "GenAIRefusalError",
    "GenAIBudgetExceededError",
    "GenAIResponseError",
]

__version__ = "2.5.0"
