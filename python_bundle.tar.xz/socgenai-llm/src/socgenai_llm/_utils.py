"""Message conversion utilities for socgenai_llm.

Provides helpers to convert between LangChain message types and
OpenAI-format dictionaries, and to convert OpenAI ChatCompletion
responses into LangChain ChatResult objects.
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    ChatMessage,
    FunctionMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.output_parsers.openai_tools import (
    make_invalid_tool_call,
    parse_tool_call,
)
from langchain_core.outputs import ChatGeneration, ChatResult

from socgenai_llm._usage import project_usage


_DEFAULT_FILE_NAME = "document.pdf"


def _to_openai_content_block(block: Any) -> Any:
    """Translate a LangChain canonical multimodal block to OpenAI legacy shape.

    Detection is shape-based: blocks that carry top-level ``base64``/``data``/
    ``source_type``/``url``/``file_id`` keys are LangChain canonical; blocks that already
    have a nested ``file`` / ``image_url`` payload are legacy OpenAI and pass
    through unchanged.
    """
    if not isinstance(block, dict):
        return block
    btype = block.get("type")

    if btype == "file" and "file_id" in block:
        return {"type": "file", "file": {"file_id": block["file_id"]}}

    if btype == "file" and "base64" in block:
        mime = block.get("mime_type", "application/pdf")
        filename = (block.get("extras") or {}).get("filename", _DEFAULT_FILE_NAME)
        return {
            "type": "file",
            "file": {
                "filename": filename,
                "file_data": f"data:{mime};base64,{block['base64']}",
            },
        }

    if btype == "image":
        source_type = block.get("source_type")
        if source_type == "url" and "url" in block:
            return {"type": "image_url", "image_url": {"url": block["url"]}}
        if source_type == "base64" and "data" in block:
            mime = block.get("mime_type", "image/jpeg")
            return {
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{block['data']}"},
            }
        if "base64" in block:
            mime = block.get("mime_type", "image/jpeg")
            return {
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{block['base64']}"},
            }
        if "url" in block:
            return {"type": "image_url", "image_url": {"url": block["url"]}}

    return block


def _normalize_content(content: Any) -> Any:
    """Normalize a message's ``content`` field. Strings and non-list values
    pass through; lists are mapped element-wise through
    ``_to_openai_content_block``."""
    if not isinstance(content, list):
        return content
    return [_to_openai_content_block(b) for b in content]


def convert_messages_to_dicts(messages: list[BaseMessage]) -> list[dict[str, Any]]:
    """Convert a list of LangChain messages to OpenAI-format dicts.

    Args:
        messages: LangChain message objects to convert.

    Returns:
        List of dicts with ``role``, ``content``, and optional fields.

    Raises:
        TypeError: If a message type is not supported.
    """
    result: list[dict[str, Any]] = []
    for msg in messages:
        if isinstance(msg, HumanMessage):
            d: dict[str, Any] = {
                "role": "user",
                "content": _normalize_content(msg.content),
            }
        elif isinstance(msg, AIMessage):
            d = {"role": "assistant", "content": _normalize_content(msg.content)}
            tool_calls = _extract_tool_calls(msg)
            if tool_calls:
                d["tool_calls"] = tool_calls
                # OpenAI expects content=null when tool_calls are present.
                d["content"] = d["content"] or None
        elif isinstance(msg, SystemMessage):
            role = msg.additional_kwargs.get("__openai_role__", "system")
            d = {"role": role, "content": _normalize_content(msg.content)}
        elif isinstance(msg, FunctionMessage):
            d = {
                "role": "function",
                "content": _normalize_content(msg.content),
                "name": msg.name,
            }
        elif isinstance(msg, ToolMessage):
            d = {
                "role": "tool",
                "content": _normalize_content(msg.content),
                "tool_call_id": msg.tool_call_id,
            }
        elif isinstance(msg, ChatMessage):
            d = {"role": msg.role, "content": _normalize_content(msg.content)}
        else:
            raise TypeError(f"Unsupported message type: {type(msg).__name__}")

        # Forward the name field when present (applicable to all message types
        # except FunctionMessage which already sets it above).
        if not isinstance(msg, FunctionMessage):
            name = msg.name or msg.additional_kwargs.get("name")
            if name is not None:
                d["name"] = name

        result.append(d)
    return result


def _extract_tool_calls(msg: AIMessage) -> list[dict[str, Any]] | None:
    """Return OpenAI-format tool_calls from an AIMessage, or *None*."""
    result: list[dict[str, Any]] = []

    # Valid tool calls from the canonical .tool_calls attribute.
    if msg.tool_calls:
        for tc in msg.tool_calls:
            result.append(
                {
                    "id": tc["id"],
                    "type": "function",
                    "function": {
                        "name": tc["name"],
                        "arguments": (
                            tc["args"]
                            if isinstance(tc["args"], str)
                            else __import__("json").dumps(tc["args"])
                        ),
                    },
                }
            )

    # Invalid tool calls (malformed args, etc.) — still need to be forwarded
    # so that the API can see the full conversation history.
    if msg.invalid_tool_calls:
        for itc in msg.invalid_tool_calls:
            result.append(
                {
                    "id": itc.get("id", ""),
                    "type": "function",
                    "function": {
                        "name": itc.get("name", ""),
                        "arguments": (
                            itc["args"]
                            if isinstance(itc.get("args"), str)
                            else __import__("json").dumps(itc.get("args", ""))
                        ),
                    },
                }
            )

    if result:
        return result

    # Fall back to additional_kwargs["tool_calls"] (raw OpenAI format).
    raw = msg.additional_kwargs.get("tool_calls")
    if raw:
        return raw  # type: ignore[return-value]
    return None


def convert_response_to_chat_result(response: Any) -> ChatResult:
    """Convert an OpenAI ChatCompletion response to a LangChain ChatResult.

    Args:
        response: The response object returned by
            ``GenAiApiClient.get_genai_completion``.

    Returns:
        A ``ChatResult`` containing one ``ChatGeneration`` with an ``AIMessage``.

    Raises:
        ValueError: If the response was blocked by Azure content filters
            (``finish_reason == "content_filter"``).
    """
    choice = response.choices[0]
    message = choice.message

    # Azure content-filter guard — must check before building the result.
    finish_reason = getattr(choice, "finish_reason", None)
    if finish_reason == "content_filter":
        raise ValueError(
            "Azure has not provided the response due to a content filter "
            "being triggered"
        )

    content: str = message.content or ""

    # Parse tool_calls if present. Malformed calls (e.g. invalid JSON in
    # arguments) go to invalid_tool_calls instead of raising, mirroring
    # langchain_openai, so agent loops can see and correct them.
    tool_calls: list[dict[str, Any]] = []
    invalid_tool_calls: list[dict[str, Any]] = []
    if getattr(message, "tool_calls", None):
        for raw_tc in message.tool_calls:
            tc_dict = raw_tc if isinstance(raw_tc, dict) else raw_tc.model_dump()
            try:
                parsed = parse_tool_call(tc_dict, return_id=True)
            except Exception as e:
                invalid_tool_calls.append(make_invalid_tool_call(tc_dict, str(e)))
            else:
                if parsed is not None:
                    tool_calls.append(parsed)

    usage_metadata, response_metadata = project_usage(getattr(response, "usage", None))
    token_usage_dict = response_metadata["token_usage"]
    model_name = getattr(response, "model", None)
    if model_name is not None:
        response_metadata["model_name"] = model_name
    sys_fp = getattr(response, "system_fingerprint", None)
    if sys_fp is not None:
        response_metadata["system_fingerprint"] = sys_fp
    if finish_reason is not None:
        response_metadata["finish_reason"] = finish_reason

    # Capture content-filter results if present on the choice (Azure-specific).
    content_filter = getattr(choice, "content_filter_results", None)
    if content_filter is not None:
        response_metadata["content_filter_results"] = content_filter

    # Capture logprobs if present.
    logprobs = getattr(choice, "logprobs", None)
    if logprobs is not None:
        response_metadata["logprobs"] = logprobs

    # Capture refusal if present.
    additional_kwargs: dict[str, Any] = {}
    if getattr(message, "tool_calls", None):
        additional_kwargs["tool_calls"] = [
            tc if isinstance(tc, dict) else tc.model_dump() for tc in message.tool_calls
        ]
    refusal = getattr(message, "refusal", None)
    if refusal is not None:
        additional_kwargs["refusal"] = refusal

    ai_message = AIMessage(
        content=content,
        id=getattr(response, "id", None),
        tool_calls=tool_calls,
        invalid_tool_calls=invalid_tool_calls,
        additional_kwargs=additional_kwargs,
        usage_metadata=usage_metadata,  # type: ignore[arg-type]
        response_metadata=response_metadata,
    )

    generation_info: dict[str, Any] = {}
    if finish_reason is not None:
        generation_info["finish_reason"] = finish_reason

    generation = ChatGeneration(
        message=ai_message,
        generation_info=generation_info,
    )

    # Build llm_output.
    llm_output: dict[str, Any] = {}
    if token_usage_dict is not None:
        llm_output["token_usage"] = token_usage_dict
    if model_name is not None:
        llm_output["model_name"] = model_name
    if sys_fp is not None:
        llm_output["system_fingerprint"] = sys_fp
    resp_id = getattr(response, "id", None)
    if resp_id is not None:
        llm_output["id"] = resp_id

    # Capture prompt-filter results if present (Azure-specific).
    prompt_filter = getattr(response, "prompt_filter_results", None)
    if prompt_filter is not None:
        llm_output["prompt_filter_results"] = prompt_filter

    return ChatResult(
        generations=[generation],
        llm_output=llm_output,
    )
