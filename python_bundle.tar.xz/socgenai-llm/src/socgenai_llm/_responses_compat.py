"""Conversion boundary for langchain-openai 1.6.7; never creates SDK clients.

These upstream helpers are private. Upgrade their pinned dependency only with
the wrapper's JSON/SSE contract suite. SDK dispatch belongs to the manager.
"""

from copy import deepcopy
import json

from genai_api_manager import StreamResultError
from socgenai_llm._usage import project_usage
from langchain_openai.chat_models.base import (
    _construct_lc_result_from_responses_api,
    _construct_responses_api_payload,
    _convert_responses_chunk_to_generation_chunk,
)


class GenAIBudgetExceededError(RuntimeError):
    """The manager blocked dispatch under its existing budget policy."""


class _CallbackResponse:
    """HTTP-style JSON for LangChain callbacks, delegating SDK attributes.

    Core 1.6.6 assumes error.response.json() is an HTTP response decoder.
    Pydantic's legacy json() instead warns and returns a JSON string. Keep
    the original SDK object on the error and expose a mapping to callbacks.
    """

    def __init__(self, response):
        self._response = response

    def json(self):
        return self._response.model_dump(mode="json", warnings=False)

    def __getattr__(self, name):
        return getattr(self._response, name)


class GenAIResponseError(StreamResultError):
    """Response conversion/provider failure retaining the full parsed payload.

    ``provider_response`` is the original SDK response or error event.
    ``response`` delegates its attributes with HTTP-style ``json()`` decoding
    for LangChain's error callbacks. ``event`` and ``body`` remain unchanged.
    """

    def __init__(self, message, *, event, details=None):
        super().__init__(message, event=event, details=details)
        self.provider_response = getattr(event, "response", event)
        self.response = _CallbackResponse(self.provider_response)
        self.request_id = getattr(self.provider_response, "_request_id", None)
        self.response_id = getattr(self.provider_response, "id", None)
        self.usage = getattr(self.provider_response, "usage", None)


def check_budget(result):
    if isinstance(result, str) and result == "Daily cost limit exceeded.":
        raise GenAIBudgetExceededError(result)
    return result


def request_payload(messages, params, *, streaming):
    """Reuse upstream history, tool, and structured-format translation."""
    payload = deepcopy(
        {key: value for key, value in params.items() if value is not None}
    )
    for key in ("stop", "stream_options", "logprobs", "top_logprobs"):
        if payload.get(key) is not None:
            raise ValueError(f"{key} is not supported by the Responses adapter.")
        payload.pop(key, None)
    n = payload.pop("n", 1)
    if n != 1:
        raise ValueError("Responses supports only one result (n=1).")
    limits = [
        payload.pop(key)
        for key in ("max_tokens", "max_completion_tokens", "max_output_tokens")
        if payload.get(key) is not None
    ]
    if limits:
        if any(value != limits[0] for value in limits):
            raise ValueError("Conflicting output token limits.")
        payload["max_output_tokens"] = limits[0]
    effort = payload.pop("reasoning_effort", None)
    if effort is not None:
        reasoning = payload.setdefault("reasoning", {})
        if "effort" in reasoning and reasoning["effort"] != effort:
            raise ValueError("Conflicting reasoning effort settings.")
        reasoning["effort"] = effort
    payload.setdefault("store", False)
    # Ordinary calls leave omitted stream selection to the manager's default.
    if streaming or payload.get("stream") is True:
        payload["stream"] = streaming
    # Our structured-output interface supplies JSON schemas, not SDK parse()
    # classes. All requests continue to use the manager's create() lifecycle.
    result = _construct_responses_api_payload(deepcopy(messages), payload)
    if "text_format" in result:
        raise ValueError("Use with_structured_output() for Pydantic schemas.")
    # Upstream removes temperature for some model-name prefixes. Preserve an
    # explicit request option: Azure decides whether this deployment accepts it.
    if params.get("temperature") is not None:
        result["temperature"] = params["temperature"]
    return result


def _conversion_response(response):
    # Our shared projection owns usage; upstream must not default unknowns to
    # zero or fail before the original usage can be retained as metadata.
    return response.model_copy(update={"usage": None})


def _annotate(message, response):
    # Preserve final provider argument strings even when standardized content
    # or core's partial chunk parser has converted the arguments to objects.
    calls = [
        {
            "id": item.call_id,
            "type": "function",
            "function": {"name": item.name, "arguments": item.arguments},
        }
        for item in response.output
        if item.type == "function_call"
    ]
    if calls:
        message.additional_kwargs["tool_calls"] = calls
    normalized, annotation = project_usage(
        getattr(response, "usage", None), responses=True
    )
    message.usage_metadata = normalized
    message.response_metadata.update(annotation)
    request_id = getattr(response, "_request_id", None)
    if request_id:
        message.response_metadata["request_id"] = request_id
    # Retain top-level Azure/provider extensions outside the answer text.
    message.response_metadata["provider_extra"] = deepcopy(
        getattr(response, "model_extra", None) or {}
    )
    return message


def response_result(response):
    try:
        if response.status not in ("completed", "incomplete"):
            raise ValueError(f"Response terminated with status {response.status!r}.")
        result = _construct_lc_result_from_responses_api(
            _conversion_response(response), output_version="responses/v1"
        )
        _annotate(result.generations[0].message, response)
        return result
    except Exception as error:
        raise GenAIResponseError(
            "Cannot convert Responses result.",
            event=response,
            details={"reason": str(error)},
        ) from error


class ResponseChunks:
    """Per-request native chunk indexes; no accounting or network ownership."""

    def __init__(self):
        self.indexes = (-1, -1, -1)
        self.last_event = None
        self.response_id = None
        self.events_observed = 0
        self.terminal = False

    def convert(self, event):
        self.last_event = event
        self.events_observed += 1
        response = getattr(event, "response", None)
        if response is not None:
            self.response_id = getattr(response, "id", None) or self.response_id
        kind = event.type
        self.terminal = kind in (
            "response.completed",
            "response.incomplete",
            "response.failed",
        )
        try:
            if kind == "error" or kind == "response.failed":
                raise ValueError("Provider reported a Responses failure.")
            converted = event
            if self.terminal:
                if response.status not in ("completed", "incomplete"):
                    raise ValueError(f"Unexpected terminal status {response.status!r}.")
                if response.status == "completed":
                    for item in response.output:
                        if item.type == "function_call":
                            # Core's partial JSON parser otherwise turns some
                            # malformed final arguments into an empty object.
                            arguments = json.loads(item.arguments, strict=False)
                            if not isinstance(arguments, dict):
                                raise ValueError(
                                    "Function arguments must be a JSON object."
                                )
                converted = event.model_copy(
                    update={"response": _conversion_response(response)}
                )
            *indexes, chunk = _convert_responses_chunk_to_generation_chunk(
                converted, *self.indexes, output_version="responses/v1"
            )
            self.indexes = tuple(indexes)
            if chunk is not None and self.terminal:
                _annotate(chunk.message, response)
            return chunk
        except Exception as error:
            failure = GenAIResponseError(
                "Cannot convert Responses event.",
                event=event,
                details={"reason": str(error)},
            )
            failure.response_id = self.response_id
            failure.events_observed = self.events_observed
            raise failure from error
