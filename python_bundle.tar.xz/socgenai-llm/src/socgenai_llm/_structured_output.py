"""Validate complete structured results without repairing partial provider JSON."""

import json
from typing import Any

from langchain_core.exceptions import OutputParserException
from langchain_core.runnables import Runnable, RunnableLambda
from langchain_core.runnables.utils import AddableDict
from langchain_core.utils.pydantic import is_basemodel_subclass
from pydantic import BaseModel


class FinalStructuredOutput(Runnable[Any, Any]):
    """Final parsing with explicit ownership of public model stream iterators.

    Delegating streaming through a generic RunnableSequence does not guarantee
    async iterator close propagation. Hold the model iterator here so early
    close/cancellation deterministically reaches the manager's stream owner.
    """

    def __init__(self, llm, parse, *, include_raw, refusal_error):
        self.llm = llm
        self.parse = parse
        self.include_raw = include_raw
        self.refusal_error = refusal_error
        self.parser = RunnableLambda(self._result)
        self.chain = llm | self.parser

    @property
    def InputType(self):
        return self.llm.InputType

    def _result(self, message):
        try:
            parsed = self.parse(message)
        except (OutputParserException, self.refusal_error) as error:
            if not self.include_raw:
                raise
            return {"raw": message, "parsed": None, "parsing_error": error}
        if self.include_raw:
            return {"raw": message, "parsed": parsed, "parsing_error": None}
        return parsed

    def invoke(self, input, config=None, **kwargs):
        return self.chain.invoke(input, config, **kwargs)

    async def ainvoke(self, input, config=None, **kwargs):
        return await self.chain.ainvoke(input, config, **kwargs)

    def _final_chunk(self, message, config):
        result = self.parser.invoke(message, config)
        if self.include_raw:
            # Raw chunks have already been forwarded; do not duplicate them.
            return AddableDict(
                parsed=result["parsed"], parsing_error=result["parsing_error"]
            )
        return result

    def stream(self, input, config=None, **kwargs):
        # These bindings are created by GenAIChatModel.bind/bind_tools. Bypass
        # the pinned RunnableBinding's generator wrapper (which does not close
        # its child), retaining exactly its config and keyword precedence.
        iterator = self.llm.bound.stream(
            input, self.llm._merge_configs(config), **{**self.llm.kwargs, **kwargs}
        )
        full = None
        try:
            for chunk in iterator:
                full = chunk if full is None else full + chunk
                if self.include_raw:
                    yield AddableDict(raw=chunk)
            if full is not None:
                yield self._final_chunk(full, config)
        finally:
            iterator.close()

    async def astream(self, input, config=None, **kwargs):
        iterator = self.llm.bound.astream(
            input, self.llm._merge_configs(config), **{**self.llm.kwargs, **kwargs}
        )
        full = None
        try:
            async for chunk in iterator:
                full = chunk if full is None else full + chunk
                if self.include_raw:
                    yield AddableDict(raw=chunk)
            if full is not None:
                result = await self.parser.ainvoke(full, config)
                if self.include_raw:
                    yield AddableDict(
                        parsed=result["parsed"], parsing_error=result["parsing_error"]
                    )
                else:
                    yield result
        finally:
            await iterator.aclose()


def _reject_constant(value):
    raise ValueError(f"Nonstandard JSON constant: {value}")


def parse_final(message, *, schema, method, refusal_error, tool_name=None):
    """Parse only a fully accumulated message; provider errors stay upstream.

    The structured runnable accumulates chunks before this function runs.
    Raw tool arguments are retained by the adapters, independently of core's
    incremental (and intentionally permissive) tool argument parser.
    """
    refusal = message.additional_kwargs.get("refusal")
    for block in message.content_blocks:
        if block["type"] == "refusal":
            refusal = refusal or block.get("refusal")
        elif block["type"] == "non_standard":
            refusal = refusal or block.get("value", {}).get("refusal")
    if refusal:
        raise refusal_error(refusal)

    source = message.text
    try:
        if method == "function_calling":
            calls = message.additional_kwargs.get("tool_calls", [])
            matching = [
                call["function"]
                for call in calls
                if call.get("type") == "function"
                and call.get("function", {}).get("name") == tool_name
            ]
            if not matching:
                # Preserve malformed provider arguments in the caller's error.
                invalid = next(
                    (
                        c
                        for c in message.invalid_tool_calls
                        if c.get("name") == tool_name
                    ),
                    None,
                )
                if invalid is not None:
                    source = invalid.get("args") or ""
                raise ValueError("No matching raw structured-output function result.")
            source = matching[0]["arguments"]

        metadata = message.response_metadata
        if "status" in metadata:
            if metadata["status"] != "completed":
                raise ValueError(
                    f"Structured output requires completed status; got {metadata['status']!r}."
                )
        else:
            allowed = (
                {"stop", "tool_calls"} if method == "function_calling" else {"stop"}
            )
            if metadata.get("finish_reason") not in allowed:
                raise ValueError(
                    "Structured output requires a successful finish reason; "
                    f"got {metadata.get('finish_reason')!r}."
                )

        value = json.loads(source, parse_constant=_reject_constant)
        if method == "function_calling":
            invalid = next(
                (c for c in message.invalid_tool_calls if c.get("name") == tool_name),
                None,
            )
            if invalid is not None:
                source = invalid.get("args") or ""
                raise ValueError("Invalid matching structured-output function call.")
            if not isinstance(value, dict):
                raise ValueError("Function arguments must be a JSON object.")
        if isinstance(schema, type) and is_basemodel_subclass(schema):
            value = (
                schema.model_validate(value)
                if issubclass(schema, BaseModel)
                else schema.parse_obj(value)
            )
            if method == "json_schema":
                message.additional_kwargs["parsed"] = value
        return value
    except (ValueError, TypeError, KeyError) as error:
        raise OutputParserException(
            f"Cannot validate final {method} output: {error}", llm_output=source
        ) from error
