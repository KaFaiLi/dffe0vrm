"""Pure token normalization, decimal pricing, and process-local daily budgets."""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from threading import Lock


CURRENCY = "EUR"
RATE_UNIT = Decimal(1000)


class UnpricedModelError(ValueError):
    """The requested model/deployment has no configured token prices."""


def field(value, name, default=None):
    return (
        value.get(name, default)
        if isinstance(value, dict)
        else getattr(value, name, default)
    )


@dataclass(frozen=True)
class Usage:
    input_tokens: int | None
    output_tokens: int | None
    cached_input_tokens: int | None = None
    cache_write_tokens: int | None = None

    def __post_init__(self):
        for value in (
            self.input_tokens,
            self.output_tokens,
            self.cached_input_tokens,
            self.cache_write_tokens,
        ):
            if value is not None and (type(value) is not int or value < 0):
                raise ValueError("Token counts must be nonnegative integers or None")
        if self.cached_input_tokens is not None and self.input_tokens is not None:
            if self.cached_input_tokens > self.input_tokens:
                raise ValueError("Cached input exceeds total input")
        if self.input_tokens is not None:
            if (self.cached_input_tokens or 0) + (
                self.cache_write_tokens or 0
            ) > self.input_tokens:
                raise ValueError("Cache reads and writes exceed total input")

    @classmethod
    def from_sdk(cls, usage, operation):
        if usage is None:
            return cls(None, None)
        if operation == "responses":
            return cls(
                field(usage, "input_tokens"),
                field(usage, "output_tokens"),
                field(field(usage, "input_tokens_details"), "cached_tokens"),
                field(field(usage, "input_tokens_details"), "cache_write_tokens"),
            )
        return cls(
            field(usage, "prompt_tokens"),
            0 if operation == "embeddings" else field(usage, "completion_tokens"),
            0
            if operation == "embeddings"
            else field(field(usage, "prompt_tokens_details"), "cached_tokens"),
            0
            if operation == "embeddings"
            else field(field(usage, "prompt_tokens_details"), "cache_write_tokens"),
        )


@dataclass(frozen=True)
class Charge:
    input_cost: Decimal | None
    output_cost: Decimal | None
    status: str

    @property
    def total(self):
        if self.input_cost is None or self.output_cost is None:
            return None
        return self.input_cost + self.output_cost


class PriceBook:
    """Trusted EUR prices per 1,000 tokens, resolved through deployment aliases."""

    def __init__(self, prices, aliases=None):
        self.aliases = dict(aliases or {})
        self.prices = {}
        self._long_context = {}
        for model, entry in prices.items():
            self.prices[model] = self._parse_rates(entry)
            if "long_context" in entry:
                context = entry["long_context"]
                if not isinstance(context, dict):
                    raise ValueError("long_context must be a price entry")
                threshold = context.get("input_tokens_above")
                if type(threshold) is not int or threshold <= 0:
                    raise ValueError("input_tokens_above must be a positive integer")
                if context.keys() - {
                    "input_tokens_above",
                    "input",
                    "cached_input",
                    "cache_write",
                    "output",
                    "currency",
                    "rate_unit",
                    "version",
                }:
                    raise ValueError("Unknown long_context pricing field")
                self._long_context[model] = (threshold, self._parse_rates(context))
        for target in self.aliases.values():
            if target not in self.prices:
                raise ValueError("Pricing alias refers to an unknown price entry")

    @staticmethod
    def _parse_rates(entry):
        if not isinstance(entry, dict):
            raise ValueError("Prices must be configured as a price entry")
        if entry.get("currency", CURRENCY) != CURRENCY:
            raise ValueError("Prices must be in EUR")
        try:
            valid_unit = Decimal(str(entry.get("rate_unit", RATE_UNIT))) == RATE_UNIT
        except InvalidOperation:
            valid_unit = False
        if not valid_unit:
            raise ValueError("Prices must be per 1,000 tokens (rate_unit=1000)")
        try:
            rates = {name: Decimal(str(entry[name])) for name in ("input", "output")}
            for name in ("cached_input", "cache_write"):
                rates[name] = Decimal(str(entry[name])) if name in entry else None
        except (KeyError, InvalidOperation) as error:
            raise ValueError(
                "Prices require valid input/output and optional cache rates"
            ) from error
        if any(x is not None and (not x.is_finite() or x < 0) for x in rates.values()):
            raise ValueError("Rates must be finite and nonnegative")
        return rates

    def require_model(self, model):
        """Resolve a priced model or alias before a billable request is sent."""
        entry = self.prices.get(self.aliases.get(model, model))
        if entry is None:
            raise UnpricedModelError(
                f"No pricing configured for model/deployment {model!r}"
            )
        return entry

    def quote(self, model, usage):
        entry = self.require_model(model)
        if usage.input_tokens is None or usage.output_tokens is None:
            return Charge(None, None, "usage_missing")
        context = self._long_context.get(self.aliases.get(model, model))
        if context is not None and usage.input_tokens > context[0]:
            entry = context[1]
        cached = usage.cached_input_tokens
        writes = usage.cache_write_tokens
        status = "exact"
        rate = entry["cached_input"]
        write_rate = entry["cache_write"]
        if writes and write_rate is None:
            return Charge(None, None, "cache_write_rate_missing")
        if writes is None and write_rate is None:
            # Preserve legacy contracts with no separately priced/reported cache writes.
            writes = 0
        if cached is None:
            known_writes = writes or 0
            input_cost = known_writes * (write_rate or Decimal(0)) + (
                usage.input_tokens - known_writes
            ) * max(
                entry["input"],
                rate or Decimal(0),
                (write_rate or Decimal(0)) if writes is None else Decimal(0),
            )
            status = "estimated_cache_unknown"
        elif writes is None:
            input_cost = cached * (rate if rate is not None else entry["input"]) + (
                usage.input_tokens - cached
            ) * max(entry["input"], write_rate)
            status = "estimated_cache_write_unknown"
        else:
            input_cost = (
                (usage.input_tokens - cached - writes) * entry["input"]
                + cached * (rate if rate is not None else entry["input"])
                + writes * (write_rate or Decimal(0))
            )
            if cached and rate is None:
                status = "estimated_cached_rate_missing"
        return Charge(
            input_cost / RATE_UNIT,
            usage.output_tokens * entry["output"] / RATE_UNIT,
            status,
        )


class DailyBudget:
    """Thread-safe numeric spending recorded by the logger.

    This is a process-local post-response guard, not a reservation or shared cap.
    The caller supplies the day key; already-started requests may overshoot.
    """

    def __init__(self):
        self._lock = Lock()
        self._days = {}

    def seed(self, day, cost):
        with self._lock:
            self._days.setdefault(day, Decimal(str(cost)))

    def record(self, day, cost):
        """Add a known charge after queue acceptance or a synchronous write attempt."""
        with self._lock:
            self._days[day] = self._days.get(day, Decimal(0)) + cost

    def snapshot(self, day):
        with self._lock:
            return self._days.get(day, Decimal(0))

    def exceeded(self, day, limit):
        return self.snapshot(day) > Decimal(str(limit))
