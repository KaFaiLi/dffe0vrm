"""Lazy SDK streams and internal collectors sharing one audited lifecycle."""

import json
import logging
from threading import Lock

from ..telemetry.request import RequestAudit, chat_text, response_text
from .accumulation import ChatCompletionAccumulator, terminal_response
from .errors import (
    StreamAssemblyError,
    StreamEventError,
    StreamInterruptedError,
    StreamResultError,
    UnexpectedStreamEndError,
)


class _Stream:
    def __init__(self, stream, audit, owner=None):
        self._stream = stream
        self._iterator = iter(stream)
        self._audit = audit
        self._owner = owner
        self._lock = Lock()
        self._busy = False
        self._closed = False
        self._close_requested = False
        self._collecting = False
        self._usage = None
        self._request_id = None
        self._last_event = None
        self.events_observed = 0
        self._http_request_id = None
        response = getattr(stream, "response", None)
        if response is not None:
            header = response.headers.get("x-request-id")
            if isinstance(header, str):
                self._http_request_id = header

    def __iter__(self):
        return self

    def _begin(self, collecting=False):
        with self._lock:
            if self._closed or self._close_requested:
                if collecting:
                    raise StreamInterruptedError("Request closed before collection.")
                raise StopIteration
            if self._busy:
                raise RuntimeError("A stream supports one iterator consumer.")
            self._busy = True
            self._collecting = collecting

    def _end(self):
        with self._lock:
            self._busy = False
            close = self._close_requested and not self._closed
        if close:
            self._terminate("partial")

    def _check_collection_open(self):
        with self._lock:
            if self._close_requested or self._closed:
                raise StreamInterruptedError("Request closed during collection.")

    def _read(self):
        event = next(self._iterator)
        if self._collecting:
            self._last_event = event
        self.events_observed += 1
        # Usage is observed before any collector validation can fail.
        try:
            self._observe(event)
        except Exception:
            # Public streams preserve original SDK events when audit projection is
            # unsupported. Collector validation runs separately and must raise.
            pass
        return event

    def _error_context(self, error):
        # SDK and transport exceptions must keep their original identity/fields.
        if isinstance(error, StreamResultError):
            if error.event is None:
                error.event = self._last_event
            error.request_id = self._http_request_id
            error.response_id = self._request_id
            error.usage = self._usage
            error.events_observed = self.events_observed

    def __next__(self):
        self._begin()
        try:
            try:
                return self._read()
            except StopIteration:
                self._terminate(self._exhausted_status())
                raise
            except BaseException as error:
                self._terminate(
                    "stream_error" if isinstance(error, Exception) else "interrupted"
                )
                raise
        finally:
            self._end()

    def _finish(self, status, completion=None):
        request_id = (
            self._http_request_id
            if self._collecting and isinstance(self, _LoggedChatCompletionStream)
            else self._request_id
        )
        self._audit.finish(
            status,
            self._usage,
            completion if completion is not None else self._completion,
            request_id,
        )

    def _terminate(self, status, completion=None, *, require_open=False):
        with self._lock:
            if self._closed:
                return
            if require_open and self._close_requested:
                raise StreamInterruptedError("Request closed during collection.")
            self._closed = True
        try:
            self._finish(status, completion)
        finally:
            try:
                self._stream.close()
            except Exception as error:
                logging.getLogger(__name__).warning(
                    "Stream cleanup failed: %s", type(error).__name__
                )
            finally:
                self._last_event = None
                self._clear()
                if self._owner is not None:
                    self._owner.release()

    def close(self):
        with self._lock:
            self._close_requested = True
            busy = self._busy
        # Do not race a synchronous read or discard the usage it may still return.
        if not busy:
            self._terminate("partial")

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False


class _LoggedChatCompletionStream(_Stream):
    """Pass through original chunks; collect a full object only on explicit request."""

    def __init__(
        self,
        stream,
        log_manager,
        model,
        prompt,
        encrypt_key,
        audit=None,
        *,
        owner=None,
        n=1,
    ):
        audit = audit or RequestAudit(log_manager, model, prompt, encrypt_key)
        super().__init__(stream, audit, owner)
        self._content = []
        self._tool_calls = {}
        self._finished_choices = set()
        self._n = n

    def _observe(self, chunk):
        self._request_id = getattr(chunk, "id", None) or self._request_id
        usage = getattr(chunk, "usage", None)
        if usage is not None:
            self._usage = usage
        for position, choice in enumerate(getattr(chunk, "choices", None) or []):
            index = getattr(choice, "index", position)
            finish = getattr(choice, "finish_reason", None)
            if finish:
                self._finished_choices.add(index)
            delta = getattr(choice, "delta", None)
            if delta is None:
                continue
            text = getattr(delta, "content", None)
            if index == 0 and text:
                self._content.append(text)
            for position, fragment in enumerate(
                getattr(delta, "tool_calls", None) or []
            ):
                function = getattr(fragment, "function", None)
                if index != 0:
                    continue
                tool_index = getattr(fragment, "index", None)
                tool_index = position if tool_index is None else tool_index
                call = self._tool_calls.setdefault(
                    tool_index,
                    {
                        "id": None,
                        "type": None,
                        "function": {"name": [], "arguments": []},
                    },
                )
                for key in ("id", "type"):
                    if call[key] is None:
                        call[key] = getattr(fragment, key, None)
                if function is not None:
                    for key in ("name", "arguments"):
                        value = getattr(function, key, None)
                        if value is not None:
                            call["function"][key].append(value)

    def _completion(self):
        text = "".join(self._content)
        if text or not self._tool_calls:
            return text
        return json.dumps(
            [
                {
                    **call,
                    "function": {
                        key: "".join(parts) for key, parts in call["function"].items()
                    },
                }
                for _, call in sorted(self._tool_calls.items())
            ],
            ensure_ascii=False,
        )

    def _exhausted_status(self):
        if self._finished_choices != set(range(self._n)):
            return "interrupted"
        return "completed" if self._usage is not None else "usage_missing"

    def _clear(self):
        self._content.clear()
        self._tool_calls.clear()

    def collect(self):
        """Drain internally, returning one ordinary ChatCompletion or a clear error."""
        self._begin(collecting=True)
        try:
            accumulator = ChatCompletionAccumulator(self._n)
            while True:
                self._check_collection_open()
                try:
                    event = self._read()
                except StopIteration:
                    break
                accumulator.add(event)
            self._check_collection_open()
            result = accumulator.finish(self._http_request_id)
            self._terminate(
                "completed" if self._usage is not None else "usage_missing",
                lambda: chat_text(result),
                require_open=True,
            )
            return result
        except BaseException as error:
            self._error_context(error)
            status = "stream_error"
            if isinstance(error, UnexpectedStreamEndError):
                status = "interrupted"
            elif isinstance(error, StreamAssemblyError):
                status = "assembly_error"
            elif isinstance(error, StreamInterruptedError) or not isinstance(
                error, Exception
            ):
                status = "interrupted"
            self._terminate(status)
            raise
        finally:
            self._end()


class LoggedResponseStream(_Stream):
    """Keep raw events lazy, or return the exact valid terminal Response."""

    _terminals = {"response.completed", "response.incomplete", "response.failed"}

    def __init__(self, stream, audit, *, owner=None):
        super().__init__(stream, audit, owner)
        self._text = []
        self._first_response_id = None

    def _observe(self, event):
        kind = getattr(event, "type", "")
        response = getattr(event, "response", None)
        if response is not None:
            self._request_id = getattr(response, "id", None) or self._request_id
            self._first_response_id = self._first_response_id or self._request_id
            if kind in self._terminals and getattr(response, "usage", None) is not None:
                self._usage = response.usage
        if kind in (
            "response.output_text.delta",
            "response.function_call_arguments.delta",
        ):
            delta = getattr(event, "delta", "")
            if delta:
                self._text.append(delta)
        if not self._collecting:
            if kind in self._terminals:
                try:
                    result = terminal_response(event, self._first_response_id)
                except StreamAssemblyError:
                    self._finish("stream_error")
                else:
                    self._finish(result.status, lambda: response_text(result))
            elif kind == "error":
                self._finish("stream_error")

    def _completion(self):
        return "".join(self._text)

    def _clear(self):
        self._text.clear()

    def _exhausted_status(self):
        return "usage_missing"

    def collect(self):
        self._begin(collecting=True)
        try:
            while True:
                self._check_collection_open()
                try:
                    event = self._read()
                except StopIteration:
                    raise UnexpectedStreamEndError(
                        "Responses stream ended without a terminal result."
                    ) from None
                self._check_collection_open()
                kind = getattr(event, "type", "")
                if kind in self._terminals:
                    result = terminal_response(event, self._first_response_id)
                    result._request_id = self._http_request_id
                    self._terminate(
                        result.status, lambda: response_text(result), require_open=True
                    )
                    return result
                if kind == "error":
                    raise StreamEventError(
                        getattr(event, "message", None)
                        or "Provider reported a stream error without a message.",
                        event=event,
                    )
        except BaseException as error:
            self._error_context(error)
            status = "stream_error"
            if isinstance(
                error, (UnexpectedStreamEndError, StreamInterruptedError)
            ) or not isinstance(error, Exception):
                status = "interrupted"
            elif isinstance(error, StreamAssemblyError):
                status = "assembly_error"
            self._terminate(status)
            raise
        finally:
            self._end()
