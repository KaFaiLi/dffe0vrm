"""Resolve one effective request before pricing, routing and SDK dispatch."""

from copy import deepcopy


def resolve_request(payload):
    payload = dict(payload)
    extra = deepcopy(payload.get("extra_body") or {})
    if not isinstance(extra, dict):
        raise ValueError("extra_body must be a mapping.")
    if "max_retries" in payload or "max_retries" in extra:
        raise ValueError("Set max_retries on the client constructor, not the request.")
    if "internal_streaming" in payload or "internal_streaming" in extra:
        raise ValueError("internal_streaming is a trusted client configuration option.")
    for key in ("model", "messages", "input", "background", "n", "stream"):
        if key not in extra:
            continue
        if payload.get(key) is not None and payload[key] != extra[key]:
            raise ValueError("Conflicting request fields in extra_body.")
        payload[key] = extra.pop(key)
    if "stream_options" in extra:
        options = dict(payload.get("stream_options") or {})
        for key, value in (extra.pop("stream_options") or {}).items():
            if key in options and options[key] != value:
                raise ValueError("Conflicting stream_options in extra_body.")
            options[key] = value
        payload["stream_options"] = options
    if "extra_body" in payload:
        payload["extra_body"] = extra
    query = payload.get("extra_query")
    if query is not None:
        query = dict(query)
        if "api-version" in query:
            raise ValueError("Azure v1 does not use an api-version query parameter.")
        payload["extra_query"] = query
    if payload.get("stream") is not None and type(payload["stream"]) is not bool:
        raise ValueError("stream must be a boolean.")
    return payload


def transport_mode(payload, *, enabled, operation):
    """Return (public stream, wire stream).

    Unsupported/untested ordinary modes select native transport before dispatch.
    This never retries a request and never strips provider generation options.
    """
    if payload.get("stream") is True:
        return True, True
    if payload.get("stream") is False or not enabled:
        return False, False
    if payload.get("extra_body"):
        return False, False
    if operation == "chat.completions" and (
        payload.get("audio") is not None
        or any(mode != "text" for mode in payload.get("modalities") or [])
        or payload.get("web_search_options") is not None
        or any(tool.get("type") != "function" for tool in payload.get("tools") or [])
    ):
        return False, False
    return False, True


def stream_payload(payload, operation):
    payload = dict(payload)
    payload["stream"] = True
    if operation == "chat.completions":
        payload["stream_options"] = {
            **(payload.get("stream_options") or {}),
            "include_usage": True,
        }
    return payload
