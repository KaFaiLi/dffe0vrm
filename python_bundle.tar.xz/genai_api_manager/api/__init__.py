"""Azure API-specific request and streaming behavior."""
