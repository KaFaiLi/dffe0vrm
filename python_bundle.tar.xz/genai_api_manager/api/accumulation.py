"""SDK result assembly, independent of accounting, transport and persistence.

Only string deltas are appended. Identities and extension values are never
concatenated; ambiguous extension changes fail rather than silently lose data.
"""

from copy import deepcopy

from openai.types.chat import ChatCompletion
from openai.types.responses import Response

from .errors import StreamAssemblyError, UnexpectedStreamEndError


def _invalid(message, **details):
    return StreamAssemblyError(message, details=details)


def _merge(target, values, path=""):
    """Merge stable metadata; preserve supplied nulls without erasing values."""
    for key, value in values.items():
        field = f"{path}.{key}" if path else key
        if key not in target or target[key] is None:
            target[key] = deepcopy(value)
        elif value is None or target[key] == value:
            continue
        elif isinstance(target[key], dict) and isinstance(value, dict):
            _merge(target[key], value, field)
        else:
            raise _invalid(
                "A stable stream field changed between chunks.",
                field=field,
                previous=target[key],
                actual=value,
            )


def _filter_merge(target, values):
    """Keep the strongest Azure filter summary; full annotation history is separate."""
    levels = ["safe", "low", "medium", "high"]
    for key, value in values.items():
        old = target.get(key)
        if isinstance(old, dict) and isinstance(value, dict):
            _filter_merge(old, value)
        elif (
            key in ("filtered", "detected")
            and isinstance(old, bool)
            and isinstance(value, bool)
        ):
            target[key] = old or value
        elif key == "severity" and old in levels and value in levels:
            target[key] = levels[max(levels.index(old), levels.index(value))]
        elif value is not None:
            target[key] = deepcopy(value)


def _index(value, limit=None):
    if type(value) is not int or value < 0 or (limit is not None and value >= limit):
        raise _invalid(
            "Stream index must be a nonnegative integer within the requested range.",
            field="index",
            actual=value,
            exclusive_upper_bound=limit,
        )
    return value


class _Fragments:
    def __init__(self):
        self.values = {}

    def add(self, key, value):
        if value is not None and not isinstance(value, str):
            raise _invalid(
                "A streamed text fragment must be a string or null.",
                field=key,
                actual=value,
            )
        if key not in self.values:
            self.values[key] = None
        if value is not None:
            if self.values[key] is None:
                self.values[key] = []
            self.values[key].append(value)

    def result(self):
        return {
            key: None if parts is None else "".join(parts)
            for key, parts in self.values.items()
        }


class _Message:
    def __init__(self):
        self.data = {}
        self.text = _Fragments()
        self.legacy = _Fragments()
        self.tools = {}

    def add(self, delta):
        for key, value in delta.items():
            if key in ("content", "refusal"):
                self.text.add(key, value)
            elif key == "function_call" and value is not None:
                if not isinstance(value, dict):
                    raise _invalid(
                        "function_call must be an object.",
                        actual=value,
                    )
                for name, fragment in value.items():
                    if name not in ("name", "arguments"):
                        raise _invalid(
                            "Cannot assemble an unknown function_call fragment.",
                            field=name,
                            actual=fragment,
                        )
                    self.legacy.add(name, fragment)
            elif key == "tool_calls" and value is not None:
                for tool in value:
                    index = _index(tool.get("index"))
                    data, function = self.tools.setdefault(index, ({}, _Fragments()))
                    _merge(
                        data,
                        {
                            k: v
                            for k, v in tool.items()
                            if k not in ("index", "function")
                        },
                    )
                    if data.get("type") not in (None, "function"):
                        raise _invalid(
                            "Cannot assemble this streamed tool type.",
                            index=index,
                            actual=data,
                        )
                    for name, fragment in (tool.get("function") or {}).items():
                        if name not in ("name", "arguments"):
                            raise _invalid(
                                "Cannot assemble an unknown tool function fragment.",
                                index=index,
                                field=name,
                                actual=fragment,
                            )
                        function.add(name, fragment)
            else:
                _merge(self.data, {key: value})

    def result(self):
        data = {**self.data, **self.text.result()}
        data.setdefault("role", "assistant")
        if data["role"] != "assistant":
            raise _invalid(
                "An assembled Chat message must have role 'assistant'.",
                field="role",
                actual=data["role"],
            )
        if self.legacy.values:
            data["function_call"] = self.legacy.result()
            if not data["function_call"].get("name") or not isinstance(
                data["function_call"].get("arguments"), str
            ):
                raise _invalid(
                    "An assembled function_call requires a name and string arguments.",
                    actual=data["function_call"],
                )
        if self.tools:
            if sorted(self.tools) != list(range(len(self.tools))):
                raise _invalid(
                    "Assembled tool indices must be contiguous starting at zero.",
                    actual=sorted(self.tools),
                )
            tools = []
            for index in sorted(self.tools):
                tool, function = self.tools[index]
                function = function.result()
                if (
                    not isinstance(tool.get("id"), str)
                    or not tool["id"]
                    or tool.get("type") != "function"
                    or not function.get("name")
                    or not isinstance(function.get("arguments"), str)
                ):
                    raise _invalid(
                        "An assembled tool requires an id, function type, name and string arguments.",
                        index=index,
                        actual={**tool, "function": function},
                    )
                tools.append({**tool, "function": function})
            data["tool_calls"] = tools
        return data


class ChatCompletionAccumulator:
    """Collect one Chat Completion with all choices and ordinary SDK nested types."""

    def __init__(self, n=1):
        if type(n) is not int or n < 1:
            raise ValueError("n must be a positive integer for internal streaming.")
        self.n = n
        self.metadata = {}
        self.choices = {}
        self.usage = None
        self.annotations = []

    def add(self, chunk):
        try:
            self._add(chunk.model_dump(exclude_unset=True, warnings=False))
        except StreamAssemblyError as error:
            error.event = chunk
            raise
        except (AttributeError, KeyError, TypeError, ValueError) as error:
            raise StreamAssemblyError(
                f"Could not assemble Chat chunk: {error}",
                event=chunk,
            ) from error

    def _add(self, chunk):
        if chunk.get("object") not in (None, "", "chat.completion.chunk"):
            raise _invalid(
                "Expected a chat.completion.chunk object or Azure annotation.",
                field="object",
                actual=chunk.get("object"),
            )
        annotation = (
            chunk.get("object") == ""
            or any(
                key in chunk for key in ("prompt_annotations", "prompt_filter_results")
            )
            or any("content_filter_offsets" in c for c in chunk.get("choices", []))
        )
        if annotation:
            self.annotations.append(deepcopy(chunk))
        if chunk.get("usage") is not None:
            self.usage = deepcopy(chunk["usage"])
        for key, value in chunk.items():
            if key in ("choices", "usage", "object", "obfuscation"):
                continue
            if chunk.get("object") == "" and key in ("id", "created", "model"):
                continue
            if key in ("prompt_annotations", "prompt_filter_results"):
                if value is None:
                    self.metadata.setdefault(key, None)
                    continue
                prompts = {
                    entry["prompt_index"]: entry
                    for entry in self.metadata.get(key) or []
                }
                for entry in value:
                    index = _index(entry.get("prompt_index"))
                    target = prompts.setdefault(index, {})
                    for name, detail in entry.items():
                        if name == "content_filter_results" and isinstance(
                            detail, dict
                        ):
                            if target.get(name) is None:
                                target[name] = {}
                            _filter_merge(target[name], detail)
                        else:
                            _merge(target, {name: detail})
                self.metadata[key] = [prompts[index] for index in sorted(prompts)]
            else:
                _merge(self.metadata, {key: value})
        for choice in chunk.get("choices", []):
            index = _index(choice.get("index"), self.n)
            data, message = self.choices.setdefault(
                index, ({"index": index}, _Message())
            )
            if choice.get("delta") is not None:
                message.add(choice["delta"])
            for key, value in choice.items():
                if key in ("index", "delta"):
                    continue
                if key == "finish_reason":
                    if value is not None and value not in (
                        "stop",
                        "tool_calls",
                        "function_call",
                        "length",
                        "content_filter",
                    ):
                        raise _invalid(
                            "Unknown Chat finish_reason.",
                            index=index,
                            actual=value,
                        )
                    previous = data.get(key)
                    if (
                        previous
                        and value
                        and previous != value
                        and "content_filter" not in (previous, value)
                    ):
                        raise _invalid(
                            "A choice changed its finish_reason.",
                            index=index,
                            previous=previous,
                            actual=value,
                        )
                    if previous != "content_filter" and value is not None:
                        data[key] = value
                elif key == "logprobs" and value is not None:
                    if data.get(key) is None:
                        data[key] = {}
                    logs = data[key]
                    for name, entries in value.items():
                        if name not in ("content", "refusal"):
                            _merge(logs, {name: entries})
                        elif entries is not None:
                            if logs.get(name) is None:
                                logs[name] = []
                            logs[name].extend(deepcopy(entries))
                        else:
                            logs.setdefault(name, None)
                elif key == "content_filter_results" and isinstance(value, dict):
                    if data.get(key) is None:
                        data[key] = {}
                    _filter_merge(data[key], value)
                elif key == "content_filter_offsets":
                    data[key] = deepcopy(value)
                else:
                    _merge(data, {key: value})

    def finish(self, request_id=None):
        if (
            not self.metadata.get("id")
            or len(self.choices) != self.n
            or any(not data.get("finish_reason") for data, _ in self.choices.values())
        ):
            raise UnexpectedStreamEndError(
                "Chat stream ended before all choices finished.",
                details={
                    "id": self.metadata.get("id"),
                    "expected_choices": self.n,
                    "finish_reasons": {
                        index: data.get("finish_reason")
                        for index, (data, _) in self.choices.items()
                    },
                },
            )
        data = {
            **self.metadata,
            "object": "chat.completion",
            "choices": [
                {**choice, "message": message.result()}
                for _, (choice, message) in sorted(self.choices.items())
            ],
        }
        if self.usage is not None:
            data["usage"] = self.usage
        if self.annotations:
            data["azure_stream_annotations"] = self.annotations
        try:
            # SDK construct preserves extras/field presence and recursively builds
            # native nested objects, without parsed helper fields or strict schemas.
            result = ChatCompletion.construct(**data)
            if (
                type(result.created) is not int
                or not isinstance(result.model, str)
                or not result.model
                or not isinstance(result.id, str)
            ):
                raise _invalid(
                    "Chat result requires an integer created value and string model/id.",
                    actual=data,
                )
        except (AttributeError, TypeError, ValueError) as error:
            raise _invalid(
                f"Could not construct ChatCompletion: {error}",
                actual=data,
            ) from error
        result._request_id = request_id
        return result


def terminal_response(event, previous_id=None):
    """Return the provider's exact terminal Response; never parse/rebuild output."""
    status = getattr(event, "type", "").removeprefix("response.")
    response = getattr(event, "response", None)
    issues = {}
    if not isinstance(response, Response):
        issues["response"] = {"expected": "SDK Response object", "actual": response}
    else:
        if status not in ("completed", "incomplete", "failed"):
            issues["type"] = {
                "expected": "response.completed, response.incomplete or response.failed",
                "actual": getattr(event, "type", None),
            }
        for field, expected in (("status", status), ("object", "response")):
            actual = getattr(response, field, None)
            if actual != expected:
                issues[f"response.{field}"] = {"expected": expected, "actual": actual}
        identity = getattr(response, "id", None)
        if not isinstance(identity, str) or not identity:
            issues["response.id"] = {"expected": "non-empty string", "actual": identity}
        elif previous_id and identity != previous_id:
            issues["response.id"] = {"expected": previous_id, "actual": identity}
        for field, expected_type in (("output", list), ("model", str)):
            actual = getattr(response, field, None)
            if not isinstance(actual, expected_type):
                issues[f"response.{field}"] = {
                    "expected": expected_type.__name__,
                    "actual": actual,
                }
    if issues:
        raise StreamAssemblyError(
            "Malformed terminal Response: " + ", ".join(issues) + ".",
            event=event,
            details=issues,
        )
    return response
