"""Azure OpenAI GA v1 endpoint and SDK construction."""

from urllib.parse import urlsplit

from openai import OpenAI


def azure_v1_base_url(endpoint):
    """Append the GA API path once, preserving a trusted gateway prefix."""
    try:
        url = urlsplit(endpoint)
        valid = (
            isinstance(endpoint, str)
            and url.scheme == "https"
            and url.hostname
            and not (url.query or url.fragment or url.username or url.password)
        )
    except (TypeError, ValueError, AttributeError):
        valid = False
    if not valid:
        raise ValueError(
            "Azure v1 requires an HTTPS endpoint without credentials or query."
        )
    base = endpoint.rstrip("/")
    if not url.path.rstrip("/").endswith("/openai/v1"):
        base += "/openai/v1"
    return base + "/"


def create_azure_client(endpoint, *, api_key, **options):
    """Construct the SDK for Azure v1 with a key or refreshable token provider."""
    return OpenAI(
        base_url=azure_v1_base_url(endpoint),
        api_key=api_key,
        **options,
    )
