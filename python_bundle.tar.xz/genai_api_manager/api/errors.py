"""Caller-visible failures while collecting an internally streamed result.

Exception payloads may contain provider content. Operational diagnostics must
record safe metadata, not these messages or bodies.
"""


class StreamResultError(RuntimeError):
    """A collection failure with the original SDK event and validation details.

    ``body`` exposes the full parsed event, including provider extensions; it is
    not a capture of raw SSE bytes. For premature EOF, ``event`` is the last event
    received (or None). Request and usage context is attached before cleanup.
    """

    def __init__(self, message, *, event=None, details=None):
        super().__init__(message)
        self.message = message
        self.event = event
        self.details = {} if details is None else details
        self.request_id = None
        self.response_id = None
        self.usage = None
        self.events_observed = None

    @property
    def body(self):
        if self.event is None:
            return None
        try:
            return self.event.model_dump(exclude_unset=True, warnings=False)
        except Exception:
            # A malformed SDK object must remain inspectable even if dumping it
            # fails. Never replace the original error with a formatting failure.
            return self.event

    def __str__(self):
        return (
            f"{self.message} (request_id={self.request_id!r}, "
            f"response_id={self.response_id!r}, "
            f"events_observed={self.events_observed!r}) "
            f"details={self.details!r}; body={self.body!r}"
        )


class UnexpectedStreamEndError(StreamResultError):
    """The provider stream ended without semantic completion."""


class StreamAssemblyError(StreamResultError):
    """Stream fields cannot be assembled without losing or inventing data."""


class StreamEventError(StreamResultError):
    """A typed error event arrived without a terminal result."""

    def __init__(self, message, *, event=None, details=None):
        super().__init__(message, event=event, details=details)
        self.code = getattr(event, "code", None)
        self.param = getattr(event, "param", None)
        self.sequence_number = getattr(event, "sequence_number", None)


class StreamInterruptedError(StreamResultError):
    """The client was closed while collecting an ordinary result."""
