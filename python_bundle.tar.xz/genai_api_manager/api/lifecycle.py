"""Own active SDK requests until audit finalization and source cleanup finish."""

import logging
from threading import Lock


def close_resource(resource, name):
    if resource is None:
        return
    try:
        resource.close()
    except Exception as error:
        logging.getLogger(__name__).warning(
            "%s cleanup failed: %s", name, type(error).__name__
        )


class RequestOwner:
    def __init__(self, lifecycle, sdk):
        self.lifecycle = lifecycle
        self.sdk = sdk
        self._lock = Lock()
        self._lease = None
        self._close_stream = None
        self._cancelled = False
        self._released = False

    def acquire_proxy(self):
        lease = self.lifecycle.client._acquire_proxy_lease()
        with self._lock:
            self._lease = lease

    @property
    def cancelled(self):
        with self._lock:
            return self._cancelled

    def attach(self, stream):
        with self._lock:
            self._close_stream = stream.close
            cancelled = self._cancelled
        if cancelled:
            stream.close()

    def close(self):
        with self._lock:
            self._cancelled = True
            callback = self._close_stream
        if callback:
            callback()

    def release(self):
        with self._lock:
            if self._released:
                return
            self._released = True
            lease, self._lease = self._lease, None
            self._close_stream = None
        if lease:
            lease.release()
        self.lifecycle.release(self)


class ClientLifecycle:
    """Close waits logically, never synchronously, for active calls to finalize.

    An in-progress synchronous read/dispatch retains resources until it returns or
    its configured SDK timeout fires. Idle public streams close immediately.
    """

    def __init__(self, client):
        self.client = client
        self._lock = Lock()
        self._owners = set()
        self._closing = False
        self._invalidated = False
        self._sdk_closed = False
        self._closed = False

    def acquire(self):
        with self._lock:
            sdk = getattr(self.client, "_openai_client", None)
            if self._closing or self._invalidated or sdk is None:
                raise RuntimeError(
                    "Client is closed or its connection was invalidated."
                )
            owner = RequestOwner(self, sdk)
            self._owners.add(owner)
        try:
            owner.acquire_proxy()
            if owner.cancelled:
                raise RuntimeError("Client closed before request dispatch.")
        except BaseException:
            owner.release()
            raise
        return owner

    def release(self, owner):
        with self._lock:
            self._owners.discard(owner)
        self._dispose_if_idle()

    def invalidate(self):
        with self._lock:
            self._invalidated = True
        self._dispose_if_idle()

    def close(self):
        with self._lock:
            self._closing = True
            owners = tuple(self._owners)
        for owner in owners:
            owner.close()
        self._dispose_if_idle()

    def _dispose_if_idle(self):
        resources = []
        with self._lock:
            if self._owners:
                return
            if (self._closing or self._invalidated) and not self._sdk_closed:
                self._sdk_closed = True
                resources.append(
                    (getattr(self.client, "_openai_client", None), "_openai_client")
                )
                if self._invalidated:
                    self.client._openai_client = None
            if self._closing and not self._closed:
                self._closed = True
                for name in ("log_manager", "_credential"):
                    resources.append((getattr(self.client, name, None), name))
        for resource, name in resources:
            close_resource(resource, name)
