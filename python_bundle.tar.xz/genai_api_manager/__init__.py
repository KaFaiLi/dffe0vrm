"""
genai_api_manager

High-level client for interacting with Azure OpenAI / GenAI services
with centralized configuration, pricing, and encrypted cost logging.
"""

# ---- Package metadata ----
__version__ = "0.4.0"
__all__ = [
    "GenAiApiClient",
    "load_config",
    "load_pricing",
    "clear_config_cache",
    "DEFAULT_CONFIG_PATH",
    "GenaiAPILogger",
    "AsyncLoggerConfig",
    "UnpricedModelError",
    "StreamResultError",
    "StreamAssemblyError",
    "StreamEventError",
    "StreamInterruptedError",
    "UnexpectedStreamEndError",
]

# ---- Public API ----
from .genai_api_client import GenAiApiClient
from .config_loader import (
    load_config,
    load_pricing,
    clear_config_cache,
    DEFAULT_CONFIG_PATH,
)
from .genai_api_logger import GenaiAPILogger, AsyncLoggerConfig
from .accounting import UnpricedModelError
from .api.errors import (
    StreamResultError,
    StreamAssemblyError,
    StreamEventError,
    StreamInterruptedError,
    UnexpectedStreamEndError,
)
