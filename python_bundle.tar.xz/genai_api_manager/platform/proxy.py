"""Windows proxy lifecycle owned by the current process."""

from __future__ import annotations

import atexit
import glob
import os
import re
import subprocess
import threading
import time
from typing import Optional

import psutil


class _ProxyLease:
    def __init__(self):
        self._released = False

    def release(self):
        manager = WindowsProxyMixin
        with manager._px_lock:
            if self._released:
                return
            self._released = True
            manager._active_requests -= 1
            if manager._active_requests == 0:
                manager._last_use_ts = time.monotonic()


class WindowsProxyMixin:
    # --- Proxy idle-shutdown (per-process) ---
    _px_lock = threading.RLock()
    _active_requests = 0
    _px_popen: Optional[subprocess.Popen] = None
    _px_started_by_us: bool = False
    _last_use_ts: float = 0.0
    _idle_secs: Optional[int] = (
        900  # 15min currently, idle timeout disabled by setting this attribute to None
    )
    _idle_thread: Optional[threading.Thread] = None
    _atexit_registered: bool = False
    _px_pid: Optional[int] = None

    def _acquire_proxy_lease(self):
        manager = WindowsProxyMixin
        with manager._px_lock:
            manager._active_requests += 1
            lease = _ProxyLease()
            try:
                self._ensure_px_for_use()
            except BaseException:
                lease.release()
                raise
            return lease

    def _px_is_running(self) -> bool:
        """Return True if px.exe is already running."""
        for p in psutil.process_iter(["name"]):
            try:
                if p.info["name"] and "px.exe" in p.info["name"].lower():
                    return True
            except psutil.NoSuchProcess:
                continue
        return False

    def _detect_windows_user(self) -> str:
        """
        Detect Windows user using HOME or HOMEPATH.
        Both contain the pattern .../Users/<ID>.
        Extract <ID> robustly.
        """
        # Prefer HOME when available
        home = os.environ.get("HOME") or os.environ.get("HOMEPATH")

        if not home:
            print(
                "[WARN] Neither HOME nor HOMEPATH is set. Cannot detect Windows user ID. Perhaps you're on a VM, proceeding..."
            )
            return None

        # Normalize slashes
        path = home.replace("\\", "/")

        # Look for /Users/<something>
        match = re.search(r"/Users/([^/]+)", path)
        if match:
            user = match.group(1)
            # Validate that it contains digits (Mxxxxx)
            if re.search(r"\d+", user):
                return user

    def _ensure_px_running(self):
        """Start px.exe if not already running."""

        with WindowsProxyMixin._px_lock:
            self._start_px_nolock()

    def _start_px_nolock(self):
        manager = WindowsProxyMixin

        # Start idle watchdog
        manager._start_idle_thread_if_needed()

        if self._px_is_running():
            return  # px already running

        user = self._detect_windows_user()
        if user:
            # Look for C:\Users\<user>\bin\px*\px.exe (e.g., px-v0.4.0, px-0.5.1, etc.)
            candidates = glob.glob(rf"C:\Users\{user}\bin\px*\px.exe")
            if candidates:
                # Choose the most recently modified binary as a pragmatic default
                candidates.sort(key=os.path.getmtime, reverse=True)
                px_path = candidates[0]

                if not os.path.exists(px_path):
                    print(
                        f"[WARN] px.exe not found at: {px_path}. Perhaps, you're working on a VM, proceeding..."
                    )
                    return
            else:
                print(
                    "[WARN] px.exe not found under C:\\Users\\%s\\bin\\px*\\px.exe. Perhaps you're on a VM, proceeding..."
                    % user
                )
                return

            # Start px silently in background
            try:
                popen = subprocess.Popen(
                    [px_path],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )

                # Mark ownership and register atexit once
                manager._px_popen = popen
                manager._px_pid = popen.pid
                manager._px_started_by_us = True
                if not manager._atexit_registered:
                    atexit.register(manager.shutdown_proxy)
                    manager._atexit_registered = True

                # Touch last use so the idle clock starts now
                manager._touch_last_use()

                print(f"[INFO] Started px.exe (pid={popen.pid}) for user {user}")
            except Exception as e:
                print(f"[WARN] Failed to start px.exe: {e}")
        return

    def _ensure_px_for_use(self):
        """
        Fast path: if we still have a live handle to our px process, do nothing.
        Otherwise, try to (re)start px if needed.
        """
        cls = WindowsProxyMixin
        try:
            if cls._px_popen is not None:
                # Cheap check: validate our pid is alive
                if psutil.pid_exists(cls._px_popen.pid):
                    return
        except Exception:
            # fall through to restart if anything looks off
            pass

        # If we reach here, either we never started px, or it was stopped by idle watcher.
        # Try to (re)start. This is still cheap unless px.exe isn't present.
        self._ensure_px_running()

    @classmethod
    def _touch_last_use(cls):
        """Mark last activity timestamp (very cheap)."""
        with WindowsProxyMixin._px_lock:
            WindowsProxyMixin._last_use_ts = time.monotonic()

    @classmethod
    def shutdown_proxy(cls):
        """Stop px.exe only if this process started it."""
        cls = WindowsProxyMixin
        with cls._px_lock:
            cls._shutdown_nolock()

    @classmethod
    def _shutdown_nolock(cls):
        """Internal: assumes _px_lock is held."""
        cls = WindowsProxyMixin
        if not cls._px_started_by_us:
            return

        pid = None
        if cls._px_popen is not None:
            pid = cls._px_popen.pid
        elif cls._px_pid is not None:
            pid = cls._px_pid

        # Best-effort kill of the entire process tree
        if pid:
            try:
                proc = psutil.Process(pid)
                # Terminate children first
                children = proc.children(recursive=True)
                for c in children:
                    try:
                        c.terminate()
                    except Exception:
                        pass

                try:
                    proc.terminate()
                except Exception:
                    pass

                # Wait briefly
                try:
                    psutil.wait_procs(children, timeout=1.5)
                except Exception:
                    pass

                try:
                    proc.wait(timeout=1.5)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass

                # Fallback on Windows: taskkill the tree forcibly if still alive
                if os.name == "nt" and psutil.pid_exists(pid):
                    try:
                        subprocess.run(
                            ["taskkill", "/PID", str(pid), "/T", "/F"],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            check=False,
                        )
                    except Exception:
                        pass

                # Final sweep: kill any direct children still hanging with same ppid
                try:
                    for p in psutil.process_iter(["pid", "name", "ppid"]):
                        if (
                            p.info.get("name")
                            and "px.exe" in p.info["name"].lower()
                            and p.info.get("ppid") == pid
                        ):
                            try:
                                p.kill()
                            except Exception:
                                pass
                except Exception:
                    pass

            except psutil.NoSuchProcess:
                pass
            except Exception:
                # Do not raise; shutdown should be best-effort
                pass

        print("[INFO] Stopped px.exe (idle timeout or shutdown)")

        # Clear our handles/flags
        cls._px_popen = None
        cls._px_pid = None
        cls._px_started_by_us = False

    @classmethod
    def _start_idle_thread_if_needed(cls):
        """Start idle watchdog"""

        cls = WindowsProxyMixin

        if cls._idle_secs and cls._idle_thread is None:

            def _watch():
                # Daemon thread: no impact on shutdown
                check_every = min(5, cls._idle_secs)
                while True:
                    time.sleep(check_every)
                    with cls._px_lock:
                        cls._shutdown_if_idle()

            t = threading.Thread(target=_watch, name="px-idle-watch", daemon=True)
            t.start()
            cls._idle_thread = t

    @classmethod
    def _shutdown_if_idle(cls):
        cls = WindowsProxyMixin
        with cls._px_lock:
            if (
                cls._px_started_by_us
                and cls._px_popen is not None
                and not cls._active_requests
                and cls._idle_secs is not None
                and time.monotonic() - cls._last_use_ts >= cls._idle_secs
            ):
                cls._shutdown_nolock()
