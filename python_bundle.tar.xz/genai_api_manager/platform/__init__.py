"""Operating-system integration, separate from API and accounting logic."""
