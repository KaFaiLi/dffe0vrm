from __future__ import annotations

import os
import json
import datetime
from threading import Lock

import requests
from requests.auth import HTTPBasicAuth
from azure.identity import ClientSecretCredential, get_bearer_token_provider

from typing import Any, Dict, List, Optional, Union

from .genai_api_logger import GenaiAPILogger
from .api.streams import _LoggedChatCompletionStream, LoggedResponseStream
from .api.lifecycle import ClientLifecycle, close_resource
from .api.requests import resolve_request, stream_payload, transport_mode
from .api.azure import azure_v1_base_url, create_azure_client
from .platform.proxy import WindowsProxyMixin
from .telemetry.request import RequestAudit, payload_text, response_text, chat_text
from .config_loader import load_config, load_pricing, DEFAULT_CONFIG_PATH


EmbeddingInput = Union[
    str,
    List[str],
    List[int],
    List[List[int]],
]

ONEDRIVE_MOUNT_ERROR = (
    "You do not have access to the shared V: drive required by this client "
    "As an alternative, please mount the shared folder by synchronizing :"
    "'IGAD DataLab > Patrimoine > 08 - Token GenAI' to your local OneDrive."
    "The folder is available here: "
    "https://groupsg001.sharepoint.com/sites/IGADDataLabIBIT/"
    "Shared%20Documents/-Patrimoine/08%20-%20Token%20GenAI"
)


def _is_multi_input(inp: EmbeddingInput) -> bool:
    """
    Determine whether 'inp' represents multiple inputs.
    - str -> single
    - List[str] -> multi
    - List[int] -> single (token array)
    - List[List[int]] -> multi
    """
    if isinstance(inp, str):
        return False
    if not inp:
        # Empty inputs are invalid per API; treat as multi for downstream checks.
        return True
    first = inp[0]
    return not isinstance(
        first, int
    )  # int => List[int] (single token array); otherwise multi


def _truncate_input(inp: EmbeddingInput, max_length: int) -> EmbeddingInput:
    """
    Non-standard convenience truncation.
    - str / List[str]: truncates by characters.
    - List[int] / List[List[int]]: truncates by token count.
    """
    if max_length <= 0:
        return inp

    if isinstance(inp, str):
        return inp[:max_length]

    # List[...] cases
    if not inp:
        return inp

    if isinstance(inp[0], int):
        # List[int]
        return inp[:max_length]  # token truncation
    else:
        # List[str] or List[List[int]]
        out = []
        for item in inp:
            if isinstance(item, str):
                out.append(item[:max_length])
            else:
                out.append(item[:max_length])
        return out


def _compact_none(d: Dict[str, Any]) -> Dict[str, Any]:
    """
    Remove keys from the input dictionary where the value is None.

    This function helps in cleaning the payload before sending it to the OpenAI API,
    because the API treats keys with None values differently from omitted keys.

    Parameters:
        d (Dict[str, Any]): The input dictionary to be compacted.

    Returns:
        Dict[str, Any]: A new dictionary with all keys having None values removed.
    """
    return {k: v for k, v in d.items() if v is not None}


class GenAiApiClient(WindowsProxyMixin):
    """
    A client for interacting with Azure Open AI API.

    This class manages authentication and access various AI capabilities offered by the Open AI platform, including:
    - Text generation (completions)
    - Embedding generation
    - Model listing
    - Function calling
    - Reranking
    - Multimodal input (text + image)
    - Vision-enabled model interactions
    """

    client_id: str = None
    api_version = "v1"
    client_secret: str = None
    azure_tenant_id: str = None
    azure_client_id: str = None
    azure_client_secret: str = None
    azure_token: str = None
    sg_connect_access_token: Optional[str] = None
    sg_connect_access_token_expires_in: Optional[datetime.datetime] = (
        datetime.datetime.now()
    )
    _lifecycle_init_lock = Lock()

    def _resolve_path_with_onedrive_fallback(
        self,
        *,
        primary_path: str,
        access: str,
        onedrive_subfolder: str,
    ) -> str:
        """
        Resolve a path with a fallback to a OneDrive-synchronized directory.
        """

        # Try primary path (V:)
        try:
            self._check_directory_access(primary_path, access)
            return primary_path
        except (FileNotFoundError, PermissionError):
            pass

        # Fallback to OneDrive
        home_dir = os.path.expanduser("~")  # Get the user's home directory
        fallback_path = os.path.join(
            home_dir,
            "OneDrive - GROUP DIGITAL WORKPLACE",
            onedrive_subfolder,
        )

        try:
            self._check_directory_access(fallback_path, access)
            return fallback_path
        except (FileNotFoundError, PermissionError):
            pass

        raise ValueError(ONEDRIVE_MOUNT_ERROR)

    def __init__(
        self, daily_cost_limit: float = 5.0, *, max_retries: int | None = None
    ):
        """
        Initialize the GenAiApiClient.

        Args:
            daily_cost_limit: Daily spending threshold in EUR (default 5.0).
                New calls are blocked strictly above the recorded cost threshold.
                Unknown costs do not block. The local-day ledger is not a shared
                hard cap; in-flight calls can overshoot.
            max_retries: SDK retries after the initial attempt. None preserves
                the SDK default; zero disables retries. Consumed streams are
                never replayed. This is a constructor-only transport option.
        """

        if max_retries is not None and (
            type(max_retries) is not int or max_retries < 0
        ):
            raise ValueError("max_retries must be a nonnegative integer or None.")

        cfg = load_config()
        self.internal_streaming = cfg.get("internal_streaming", True)
        if type(self.internal_streaming) is not bool:
            raise ValueError(
                "internal_streaming must be a boolean in trusted configuration."
            )
        self.endpoint = cfg["azure_openai_endpoint"]
        azure_v1_base_url(self.endpoint)

        # Ensure proxy px.exe is running
        self._ensure_px_running()

        # Store config values on self (directly)
        self.userinfo_url = cfg["userinfo_url"]
        # Validate access to configured paths
        self.llm_token_path = self._resolve_path_with_onedrive_fallback(
            primary_path=cfg["llm_token_path"],
            access="read",
            onedrive_subfolder=os.path.join(
                "IGAD DataLab - 08 - Token GenAI",
                "Credential",
            ),
        )
        self.llm_log_path = self._resolve_path_with_onedrive_fallback(
            primary_path=cfg["llm_log_path"],
            access="write",
            onedrive_subfolder=os.path.join(
                "IGAD DataLab - 08 - Token GenAI",
                "Log_Azure",
            ),
        )
        # self.llm_log_path = self._resolve_llm_log_path(cfg["llm_log_path"])
        pricing_file_name = cfg.get("pricing_file", "MODELS_PRICE1K_AZURE.json")

        # Resolve config directory
        effective_config_path = os.path.abspath(DEFAULT_CONFIG_PATH)
        cfg_dir = os.path.dirname(effective_config_path)

        # Trusted absolute pricing path from config.json
        pricing_file_path = os.path.join(cfg_dir, pricing_file_name)
        genai_api_key = self._load_credentials(self.llm_token_path)
        self.client_id = genai_api_key.get("client_id")
        self.client_secret = genai_api_key.get("client_secret")
        self.azure_tenant_id = genai_api_key.get("azure_tenant_id")
        self.azure_client_id = genai_api_key.get("azure_client_id")
        self.azure_client_secret = genai_api_key.get("azure_client_secret")
        self.encrypt_key = genai_api_key.get("Public_Key")

        credential = ClientSecretCredential(
            self.azure_tenant_id, self.azure_client_id, self.azure_client_secret
        )
        self._credential = credential
        self.azure_token_provider = get_bearer_token_provider(
            credential, "https://ai.azure.com/.default"
        )

        # Set up the client and reuse it
        self._openai_client = create_azure_client(
            self.endpoint,
            api_key=self.azure_token_provider,
            **({"max_retries": max_retries} if max_retries is not None else {}),
        )

        # Load pricing data once (cached in-memory across instances)
        pricing_data = load_pricing(pricing_file_path)

        # Store for get_models()
        self._pricing_data: Dict[str, Any] = pricing_data

        self.log_manager = GenaiAPILogger(
            log_directory=self.llm_log_path,
            pricing_file=pricing_file_path,
            pricing_data=pricing_data,
            pricing_aliases=cfg.get("pricing_aliases"),
            daily_cost_limit=daily_cost_limit,
            username=os.getlogin(),
            public_key=self.encrypt_key,
        )

    def _check_directory_access(self, path: str, access_right: str = "read") -> bool:
        """
        Check if the directory exists and has the specified access rights.

        Args:
            path (str): Directory path.
            access_right (str): Access type ('read' or 'write').

        Returns:
            bool: True if access is granted, raises an exception otherwise.
        """
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"The directory '{path}' does not exist or is not reachable."
            )

        if access_right == "read" and not os.access(path, os.R_OK):
            raise PermissionError(f"No read access to the directory '{path}'.")
        elif access_right == "write" and not os.access(path, os.W_OK):
            raise PermissionError(f"No write access to the directory '{path}'.")
        elif access_right not in ["read", "write"]:
            raise AttributeError("Illegal access right type.")

        return True

    def _load_credentials(self, cred_path: str) -> dict:
        """
        Load credentials from a JSON file.

        Args:
            cred_path (str): Path to the credentials directory.

        Returns:
            dict: Credentials dictionary.
        """
        try:
            with open(os.path.join(cred_path, "privates_azure.json"), "r") as f:
                data = json.load(f)
            return data["CREDENTIAL_AZURE_IGAD_DEV_C2"]
        except Exception as e:
            raise ValueError(f"Encountered error while loading privates.json: {e}")

    def _get_sgc_for_token_for_user_info(self) -> str:
        """
        Retrieve SG Connect access token for user info.

        Returns:
            str: Access token.
        """
        url = (
            "https://sso.sgmarkets.com/sgconnect/oauth2/access_token?"
            "grant_type=client_credentials&scope=openid profile mail"
        )
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        sg_connect_response = requests.post(
            url, headers=headers, auth=HTTPBasicAuth(self.client_id, self.client_secret)
        )

        if sg_connect_response.status_code == 200:
            return sg_connect_response.json().get("access_token")
        raise ValueError("Failed to retrieve SG Connect token.")

    def _get_user_info(self) -> str:
        """
        Get user information from SG Connect.

        Returns:
            str: Username.
        """
        token = self._get_sgc_for_token_for_user_info()
        headers = {"Authorization": f"Bearer {token}"}
        try:
            response = requests.get(self.userinfo_url, headers=headers, timeout=10)
            response.raise_for_status()
            return response.json().get("name", "unknown user")
        except Exception:
            raise ValueError("Failed to get user information from SG Connect.")

    def _invalidate_connection(self):
        """
        Invalidate the connection by clearing access token and related info.
        """
        self.azure_token = None
        self._request_lifecycle().invalidate()
        print("Connection failed due to exceeding daily cost limit.")

    def _request_lifecycle(self):
        with self._lifecycle_init_lock:
            lifecycle = self.__dict__.get("_lifecycle")
            if lifecycle is None:
                lifecycle = self._lifecycle = ClientLifecycle(self)
            return lifecycle

    def _dispatch(self, payload, operation, prompt):
        """Own one logical request/audit; transport retries belong to the SDK."""
        public, streaming = False, False
        if operation != "embeddings":
            public, streaming = transport_mode(
                payload,
                enabled=getattr(self, "internal_streaming", True),
                operation=operation,
            )
        if streaming:
            payload = stream_payload(payload, operation)
        if streaming and not public and operation == "chat.completions":
            n = payload.get("n", 1)
            if type(n) is not int or n < 1:
                raise ValueError("n must be a positive integer for internal streaming.")
        owner = self._request_lifecycle().acquire()
        transferred = False
        response = None
        try:
            audit = RequestAudit(
                self.log_manager,
                payload["model"],
                prompt,
                self.encrypt_key,
                operation,
            )
            if operation == "chat.completions":
                response = owner.sdk.chat.completions.create(**payload)
            elif operation == "responses":
                response = owner.sdk.responses.create(**payload)
            else:
                response = owner.sdk.embeddings.create(**payload)
            if streaming:
                if operation == "chat.completions":
                    stream = _LoggedChatCompletionStream(
                        response,
                        self.log_manager,
                        payload["model"],
                        prompt,
                        self.encrypt_key,
                        audit=audit,
                        owner=owner,
                        n=payload.get("n", 1),
                    )
                else:
                    stream = LoggedResponseStream(response, audit, owner=owner)
                transferred = True
                owner.attach(stream)
                return stream if public else stream.collect()
            usage = getattr(response, "usage", None)
            if operation == "responses":
                audit.finish(
                    getattr(response, "status", "completed"),
                    usage,
                    lambda: response_text(response),
                    getattr(response, "id", None),
                )
            else:
                audit.finish(
                    "completed" if usage is not None else "usage_missing",
                    usage,
                    "<embeddings>"
                    if operation == "embeddings"
                    else lambda: chat_text(response),
                    getattr(response, "_request_id", None),
                )
            return response
        except BaseException:
            if streaming and response is not None and not transferred:
                close_resource(response, "stream")
            raise
        finally:
            if not transferred:
                owner.release()

    def _get_models_pricing_dict(self) -> Dict[str, Dict[str, float]]:
        """
        Build a normalized dict:
            { model_name: {"input": float, "output": float}, ... }
        from the trusted pricing JSON already loaded in __init__.
        """
        pricing = getattr(self, "_pricing_data", None) or {}
        models: Dict[str, Dict[str, float]] = {}

        for model_name, v in pricing.items():
            if not isinstance(v, dict):
                continue
            if "input" not in v or "output" not in v:
                continue
            try:
                models[model_name] = {
                    "input": float(v["input"]),
                    "output": float(v["output"]),
                }
            except Exception:
                # Skip malformed values
                continue

        return models

    def _print_models(self, models: Dict[str, Dict[str, float]], title: str) -> None:
        """
        Print model pricing in a structured aligned format.
        """

        def fmt(x: float) -> str:
            # readable formatting; avoids scientific notation for small numbers
            return "0" if x == 0 else f"{x:.8f}".rstrip("0").rstrip(".")

        if not models:
            print(f"=== {title} ===")
            print("(none)")
            return

        rows = []
        pricing = getattr(self, "_pricing_data", None) or {}
        for name in sorted(models):
            rates = models[name]
            context = pricing.get(name, {}).get("long_context")
            if context is None:
                rows.append((name, rates["input"], rates["output"]))
            else:
                threshold = context["input_tokens_above"]
                rows.extend(
                    [
                        (
                            f"{name} (input <= {threshold:,})",
                            rates["input"],
                            rates["output"],
                        ),
                        (
                            f"{name} (input > {threshold:,})",
                            float(context["input"]),
                            float(context["output"]),
                        ),
                    ]
                )
        name_w = max([len("Model")] + [len(name) for name, _, _ in rows])

        print(f"=== {title} ===")
        print(f"{'Model':{name_w}}  {'Input/1K':>12}  {'Output/1K':>12}")
        print(f"{'-' * name_w}  {'-' * 12}  {'-' * 12}")

        for name, inp, out in rows:
            print(f"{name:{name_w}}  {fmt(inp):>12}  {fmt(out):>12}")

    def get_models(
        self,
        *,
        print_models: bool = True,
        include_substring: Optional[str] = None,
        exclude_substring: Optional[str] = None,
        title: str = "Available Models (pricing per 1K tokens)",
    ) -> Dict[str, Dict[str, float]]:
        """
        Unified model accessor.

        Args:
            print_models: print to stdout if True
            include_substring: only include models whose name contains this substring (case-insensitive)
            exclude_substring: exclude models whose name contains this substring (case-insensitive)
            title: print header title

        Returns:
            Dict[str, Dict[str, float]]: standard rates {model: {"input": x, "output": y}}.
                Printed output also shows configured long-context rates and thresholds.
        """
        models = self._get_models_pricing_dict()

        inc = include_substring.lower() if include_substring else None
        exc = exclude_substring.lower() if exclude_substring else None

        if inc:
            models = {k: v for k, v in models.items() if inc in k.lower()}
        if exc:
            models = {k: v for k, v in models.items() if exc not in k.lower()}

        if print_models:
            self._print_models(models, title)

        return models

    def get_available_models(self) -> List[str]:
        """
        Backward compatible:
        - prints NON-embedding models (name does NOT contain "embedding")
        - returns list of model names
        """
        models = self.get_models(
            print_models=True,
            exclude_substring="embedding",
            title="Available Models (non-embedding) — pricing per 1K tokens",
        )
        return sorted(models.keys())

    def get_available_embedding_models(self) -> List[str]:
        """
        Backward compatible:
        - prints embedding models (name contains "embedding")
        - returns list of model names
        """
        models = self.get_models(
            print_models=True,
            include_substring="embedding",
            title="Available Models (embedding) — pricing per 1K tokens",
        )
        return sorted(models.keys())

    def get_genai_embeddings(
        self,
        request: Optional[Dict[str, Any]] = None,
        *,
        # --- Convenience inputs (OpenAI API fields) ---
        input: Optional[EmbeddingInput] = None,
        model: Optional[str] = None,
        dimensions: Optional[int] = None,
        encoding_format: Optional[str] = None,
        user: Optional[str] = None,
        # --- Backwards-compat alias ---
        text: Optional[str] = None,
        # --- Wrapper behavior ---
        embeddings_only: bool = False,  # default False => return full response object
        max_length: Optional[int] = None,  # NON-STANDARD convenience truncation
        **openai_params: Any,
    ):
        """
        Invoke the Azure OpenAI Embeddings API (OpenAI-compatible).

        Supports all API input shapes:
          - str
          - List[str]
          - List[int]
          - List[List[int]]
        [1](https://platform.openai.com/docs/api-reference/embeddings?langpython)

        Standard request fields:
          - model (required)
          - input (required)
          - dimensions (optional; text-embedding-3+)
          - encoding_format (optional: "float" | "base64")
          - user (optional)
        [1](https://platform.openai.com/docs/api-reference/embeddings?langpython)

        Azure guidance: array-of-inputs max size 2048. [2](https://learn.microsoft.com/en-us/azure/ai-foundry/openai/how-to/embeddings?view=foundry-classic)

        Returns:
          - Full response object (default), including `data` and `usage`. [1](https://platform.openai.com/docs/api-reference/embeddings?langpython)
          - If embeddings_only=True: returns vector(s) extracted from response.data[].embedding.
        """

        # Build payload (OpenAI-style)
        payload: Dict[str, Any] = dict(request or {})
        payload.update(openai_params)
        payload = resolve_request(payload)

        # Resolve input
        if payload.get("input") is None:
            if input is not None:
                payload["input"] = input
            elif text is not None:
                payload["input"] = text

        # Resolve model
        if payload.get("model") is None and model is not None:
            payload["model"] = model

        # Standard optional fields
        if payload.get("dimensions") is None and dimensions is not None:
            payload["dimensions"] = dimensions
        if payload.get("encoding_format") is None and encoding_format is not None:
            payload["encoding_format"] = encoding_format
        if payload.get("user") is None and user is not None:
            payload["user"] = user

        # Validate required fields
        if not payload.get("model"):
            raise ValueError("Missing required field: 'model'.")
        if payload.get("input") is None:
            raise ValueError("Missing required field: 'input'.")

        self.log_manager.require_priced_model(payload["model"])
        if self._budget_exceeded():
            self._invalidate_connection()
            return "Daily cost limit exceeded."

        # Structural validation: API disallows empty input. [1](https://platform.openai.com/docs/api-reference/embeddings?langpython)
        inp = payload["input"]
        if isinstance(inp, str) and not inp.strip():
            raise ValueError("'input' cannot be an empty string.")
        if isinstance(inp, list) and len(inp) == 0:
            raise ValueError("'input' cannot be an empty list.")

        # Azure guidance: max array size 2048 for multi-input requests. [2](https://learn.microsoft.com/en-us/azure/ai-foundry/openai/how-to/embeddings?view=foundry-classic)
        if isinstance(inp, list) and inp and not isinstance(inp[0], int):
            if len(inp) > 2048:
                raise ValueError(
                    "Too many inputs: Azure guidance is max 2048 items per request."
                )

        # Optional NON-STANDARD truncation
        if max_length is not None:
            payload["input"] = _truncate_input(payload["input"], max_length)

        # Cleanup None keys
        payload = _compact_none(payload)

        response = self._dispatch(payload, "embeddings", payload_text(payload["input"]))

        # Return full response by default (API-standard)
        if not embeddings_only:
            return response

        # Optional convenience: extract vectors only
        multi = _is_multi_input(payload["input"])
        if not multi:
            return response.data[0].embedding
        return [item.embedding for item in response.data]

    def get_genai_completion(
        self,
        request: Optional[Dict[str, Any]] = None,
        *,
        # --- Backwards-compat convenience inputs ---
        prompt: Optional[str] = None,
        system_message: Optional[str] = None,
        model: Optional[str] = None,
        messages: Optional[List[Dict[str, Any]]] = None,
        # --- OpenAI Chat Completions parameters (pass-through) ---
        **openai_params: Any,
    ):
        """
        Generate a text completion by invoking the Azure OpenAI Chat Completions API.

        This method supports three distinct invocation modes:

        1. **Pure OpenAI Payload**:
        Pass a complete OpenAI Chat Completions request as a dictionary.
        Example:
            get_genai_completion(request={"model": "...", "messages": [...], ...})

        2. **Direct Parameters**:
        Provide the OpenAI API parameters as keyword arguments.
        Example:
            get_genai_completion(model="...", messages=[...], temperature=0.2, ...)

        3. **Legacy Mode (Prompt/System Message)**:
        Use legacy parameters for a simplified interface.
        Example:
            get_genai_completion(prompt="hi", system_message="...", model="...")

        **Important Notes:**

        - **Streaming:** With `stream=True`, returns a lazy synchronous iterator over the
        original SDK chunks. `stream_options.include_usage` is forced to `True` for logging.
        Close the stream explicitly or use it as a context manager when stopping early.
        Supported ordinary modes collect internally by default and return a plain
        ChatCompletion. Explicit `stream=False` uses native non-streaming transport;
        trusted `internal_streaming=False` also disables internal collection.
        Errors are never replayed.
        - **Cost Guard:** Checks the daily cost limit before proceeding.
        - **Payload Cleanup:** Keys with None values are removed to ensure proper handling by
        the OpenAI SDK.
        - **Logging:** If enabled, attempts to log the prompt/messages and usage metrics.

        **Parameters:**

        - `request` (Optional[Dict[str, Any]]):
            A complete dictionary in the OpenAI Chat Completions request format.

        - `prompt` (Optional[str]):
            Legacy parameter representing the user’s prompt message (used if `messages` is not provided).

        - `system_message` (Optional[str]):
            Legacy parameter for a system-level instruction; included in the messages if not "NONE".

        - `model` (Optional[str]):
            Legacy parameter specifying the model to use; used if not included in the `request` dictionary.

        - `messages` (Optional[List[Dict[str, Any]]]):
            Legacy parameter representing the chat messages (OpenAI message format).

        - `openai_params` (Any):
            Additional keyword parameters passed through to `client.chat.completions.create(**payload)`.
            These correspond to the OpenAI Chat Completions request-body fields.

            ----
            OpenAI Chat Completions pass-through parameters (request fields)
            ----

            Required (if not provided via `request` / legacy args):
            - `model` (str):
                Model identifier (or Azure deployment name when using Azure OpenAI).
            - `messages` (list[dict]):
                Conversation history. Each message typically includes:
                - `role`: one of `developer`, `system`, `user`, `assistant`, `tool` (and legacy `function`)
                - `content`: string or array of content parts (text/image/audio/file), depending on model.

            Output & formatting:
            - `response_format` (dict):
                Controls output format:
                - `{"type": "text"}` (default)
                - `{"type": "json_object"}` (legacy JSON mode; ensure you instruct the model to emit JSON)
                - `{"type": "json_schema", "json_schema": {...}}` (Structured Outputs / JSON Schema)
            - `modalities` (list[str]):
                Output types the model should generate; commonly `["text"]`.
                Some models support `["text", "audio"]`.
            - `audio` (dict):
                Required when requesting audio output (`"audio"` included in `modalities`).
                Example keys:
                - `format`: "wav" | "mp3" | "flac" | "opus" | "pcm16"
                - `voice`: built-in voice name or a custom voice reference object

            Token limits & multiplicity:
            - `max_completion_tokens` (int):
                Upper bound for generated tokens, including visible output and reasoning tokens.
                Preferred for newer/reasoning models.
            - `max_tokens` (int, deprecated):
                Legacy cap for generated tokens; deprecated in favor of `max_completion_tokens`
                and not compatible with some reasoning model families.
            - `n` (int):
                Number of choices to generate (default 1). You are billed for total tokens across choices.

            Sampling / generation control:
            - `temperature` (float, 0..2):
                Sampling temperature; higher => more randomness.
            - `top_p` (float, 0..1):
                Nucleus sampling; consider tokens comprising top_p probability mass.
            - `stop` (str | list[str]):
                Up to 4 stop sequences where generation halts (model-dependent support).
            - `presence_penalty` (float, -2..2):
                Penalizes tokens based on whether they appear so far; encourages new topics.
            - `frequency_penalty` (float, -2..2):
                Penalizes tokens based on frequency so far; reduces repetition.
            - `logit_bias` (dict[token_id, bias]):
                Map token IDs to bias values (-100..100) to discourage/encourage specific tokens.

            Log probabilities:
            - `logprobs` (bool):
                Whether to return log probabilities for output tokens.
            - `top_logprobs` (int, 0..20):
                Return top N alternatives per token position (requires `logprobs=True`).

            Tools / function calling:
            - `tools` (list[dict]):
                Tool definitions the model may call. Commonly function tools:
                `{"type": "function", "function": {"name": "...", "description": "...",
                "parameters": <json-schema>, "strict": bool}}`
            - `tool_choice` (str | dict):
                Tool selection policy:
                - "none": do not call tools
                - "auto": model decides
                - "required": must call at least one tool
                - or a specific tool target dict to force a particular tool/function.
            - `parallel_tool_calls` (bool):
                Enable/disable parallel tool calls (when supported).
            - `functions` (list[dict], deprecated):
                Legacy function definitions (use `tools` instead).
            - `function_call` (str | dict, deprecated):
                Legacy function call control (use `tool_choice` instead).

            Reasoning & verbosity (model-dependent):
            - `reasoning_effort` (str):
                Constrains reasoning effort for reasoning-capable models.
                Supported values vary by model (e.g., "none", "minimal", "low", "medium", "high", "xhigh").
            - `verbosity` (str):
                Constrains response verbosity, typically: "low" | "medium" | "high".

            Caching / performance (platform/model-dependent):
            - `prompt_cache_key` (str):
                Stable identifier used for prompt caching and cache hit optimization (replaces legacy `user`).
            - `prompt_cache_retention` (str):
                Retention policy for cached prefixes (e.g., "in-memory", "24h"), if supported.
            - `prediction` (dict):
                Predicted output configuration to speed up regeneration when much content is known.
            - `service_tier` (str):
                Processing tier selection (e.g., "auto", "default", and other tier values where available).

            Metadata / storage / safety:
            - `metadata` (dict[str, str]):
                Up to 16 key-value pairs attached to the request/response object for tracking/querying.
            - `store` (bool):
                Whether to store outputs for distillation/evals (platform-dependent).
            - `safety_identifier` (str):
                Stable identifier to help abuse detection (recommend hashing user identifiers).
            - `user` (str, deprecated):
                Legacy user identifier; replaced by `safety_identifier` and `prompt_cache_key`.
            - `seed` (int, deprecated / beta):
                Best-effort deterministic sampling; determinism not guaranteed.

            Web search (if supported by the model/platform):
            - `web_search_options` (dict):
                Options enabling web search (e.g., `search_context_size`, `user_location`).

            Streaming:
            - `stream` (bool):
                If true, returns server-sent events (SSE) chunks instead of one response.
            - `stream_options` (dict):
                Streaming options such as `include_usage`.
                For streaming requests, `include_usage` is always forced to `True`.

            ----
            Notes on compatibility:
            - Parameter support varies by model family and provider (OpenAI vs Azure OpenAI),
            and some fields are deprecated in favor of newer ones (e.g., `max_tokens` -> `max_completion_tokens`,
            `functions/function_call` -> `tools/tool_choice`).

        **Returns:**
        - Without public streaming, the full response object from the Azure OpenAI API call.
        - With `stream=True`, a lazy iterator/context manager yielding the original chunks.
        - If the daily cost limit is exceeded, the string `"Daily cost limit exceeded."`.

        **Raises:**
        - `ValueError`:
            - If required fields (such as "model" or "messages") are missing.
        """

        # Build the API Request Payload
        # Start with a copy of the provided request dictionary (if any) and update it with
        # any additional OpenAI parameters provided via kwargs.
        payload: Dict[str, Any] = dict(request or {})
        payload.update(openai_params)
        payload = resolve_request(payload)

        # Handle Legacy Parameter Compatibility
        # If 'messages' is not provided in the payload, construct it from the legacy parameters.
        if payload.get("messages") is None:
            if messages is not None:
                payload["messages"] = messages
            elif prompt is not None:
                built_messages: List[Dict[str, Any]] = []
                if system_message and system_message != "NONE":
                    # System messages are part of Chat Completions message schema. [1](https://platform.openai.com/docs/api-reference/chat)
                    built_messages.append({"role": "system", "content": system_message})
                built_messages.append({"role": "user", "content": prompt})
                payload["messages"] = built_messages

        # For backwards-compatibility: if 'model' is not set in the payload but provided as a legacy parameter,
        # then add it to the payload.
        if payload.get("model") is None and model is not None:
            payload["model"] = model

        # Validate Required Payload Fields
        # Ensure that both 'model' and 'messages' fields are present in the payload.
        if not payload.get("model"):
            raise ValueError("Missing required field: 'model'.")
        if not payload.get("messages"):
            raise ValueError("Missing required field: 'messages'.")

        self.log_manager.require_priced_model(payload["model"])
        if self._budget_exceeded():
            self._invalidate_connection()
            return "Daily cost limit exceeded."

        # Cleanup the Payload
        # Remove any keys with None values since the OpenAI SDK may treat those differently.
        payload = _compact_none(payload)

        try:
            prompt_to_log = (
                prompt
                if prompt is not None
                else json.dumps(payload["messages"], ensure_ascii=False)
            )
        except Exception:
            prompt_to_log = ""

        return self._dispatch(payload, "chat.completions", prompt_to_log)

    def _budget_exceeded(self):
        check = getattr(self.log_manager, "budget_exceeded", None)
        if callable(check):
            return check()
        return self.log_manager.check_daily_cost() > self.log_manager.daily_cost_limit

    def get_genai_response(
        self, request=None, *, input=None, model=None, **openai_params
    ):
        """Create an Azure Response using the unchanged trusted API version.

        Returns the original SDK Response or a lazy, closable iterator of typed
        events. Supported ordinary calls collect internally by default through the
        first valid completed/incomplete/failed terminal object. Explicit
        stream=False or trusted internal_streaming=False uses native transport.
        Background responses need a separate polling/accounting lifecycle and
        remain unsupported. The server decides version/deployment capability;
        its SDK errors propagate. No stream failure is replayed as another request.
        """
        payload = dict(request or {})
        payload.update(openai_params)
        payload = resolve_request(payload)
        if payload.get("input") is None and input is not None:
            payload["input"] = input
        if payload.get("model") is None and model is not None:
            payload["model"] = model
        if not payload.get("model"):
            raise ValueError("Missing required field: 'model'.")
        if payload.get("input") is None:
            raise ValueError("Missing required field: 'input'.")
        if payload.get("background"):
            raise ValueError(
                "Background Responses are not supported by this usage wrapper."
            )
        self.log_manager.require_priced_model(payload["model"])
        if self._budget_exceeded():
            self._invalidate_connection()
            return "Daily cost limit exceeded."
        payload = _compact_none(payload)
        return self._dispatch(payload, "responses", payload_text(payload["input"]))

    def close(self):
        """Close idle streams now; defer shared resources until active calls finish.

        Synchronous reads/dispatches are not forcibly interrupted. Their configured
        SDK timeouts still apply; call close again after outstanding workers join
        when deterministic process shutdown is required.
        """
        self._request_lifecycle().close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        return False

    def print_today_usage_report(self) -> None:
        """
        Print the current day's usage report to stdout.
        (Delegates to the logger to read today's JSON and aggregate.)
        """
        self.log_manager.print_today_usage_report()


### -> other AI capabilities to add
