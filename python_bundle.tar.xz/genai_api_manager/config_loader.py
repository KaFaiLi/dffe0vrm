from __future__ import annotations

import json
import os
from functools import lru_cache
from typing import Any, Dict, Optional


# ============================================================
# HARD LOCK: Trusted config path (NO OVERRIDES)
# ============================================================
DEFAULT_CONFIG_PATH = r"\\EUR.MSD.WORLD.SOCGEN\groupdir\Tree\DCPE\PAR\DATALAB\05.Partage\05.Token LLM\Credential\config.json"


def _norm_real(p: str) -> str:
    """Normalize and resolve a path to prevent bypass via relative paths/symlinks."""
    return os.path.realpath(os.path.abspath(p))


@lru_cache(maxsize=16)
def _read_json_file(abs_path: str) -> Dict[str, Any]:
    """
    Read and parse a JSON file. Cached in-memory by absolute path.
    """
    with open(abs_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, dict):
        raise ValueError(f"JSON root must be an object/dict: {abs_path}")

    return data


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load config.json from the trusted shared drive path.

    SECURITY:
      - Overriding config_path is ALWAYS forbidden.
      - Environment variables are intentionally NOT used.
    """
    if config_path is not None:
        raise PermissionError(
            "Overriding 'config_path' is not allowed. "
            "This library is locked to the trusted config location."
        )

    path = _norm_real(DEFAULT_CONFIG_PATH)
    if not os.path.exists(path):
        raise FileNotFoundError(f"config.json not found: {path}")

    return _read_json_file(path)


def load_pricing(pricing_path: str) -> Dict[str, Any]:
    """
    Load pricing JSON from a path. Cached in-memory.

    SECURITY:
      - pricing_path MUST match the trusted pricing_file path defined
        in the trusted config.json.
      - This prevents callers from loading arbitrary pricing files.
    """
    requested = _norm_real(pricing_path)

    # Trusted pricing path comes from the trusted config.json
    cfg = load_config()
    trusted_pricing = cfg.get("pricing_file")
    if not trusted_pricing:
        raise KeyError(
            "Missing required config key: 'pricing_file' in trusted config.json"
        )

    trusted = _norm_real(trusted_pricing)

    if requested != trusted:
        raise PermissionError(
            "Overriding pricing file path is not allowed. "
            "Pricing must be loaded from the trusted path in config.json."
        )

    if not os.path.exists(trusted):
        raise FileNotFoundError(f"Pricing file not found: {trusted}")

    data = _read_json_file(trusted)
    if not isinstance(data, dict):
        raise ValueError(f"Pricing JSON must be a dict/object: {trusted}")

    return data


def clear_config_cache() -> None:
    """Clear cached config/pricing data (useful if files change on the shared drive)."""
    _read_json_file.cache_clear()
