"""Request lifecycle measurements and audit helpers."""
