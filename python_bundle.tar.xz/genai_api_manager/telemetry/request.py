"""One audit record per request, including terminal stream failures."""

import json
from threading import Lock

from ..accounting import Usage, field


def payload_text(value):
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=lambda obj: obj.model_dump())


class RequestAudit:
    def __init__(
        self,
        logger,
        model,
        prompt,
        encrypt_key,
        operation="chat.completions",
    ):
        self.logger = logger
        self.model = model
        self.prompt = prompt
        self.encrypt_key = encrypt_key
        self.operation = operation
        self.finalized = False
        self._lock = Lock()

    def finish(self, status, usage=None, completion="", request_id=None):
        with self._lock:
            if self.finalized:
                return
            self.finalized = True
        try:
            normalized = Usage.from_sdk(usage, self.operation)
        except ValueError:
            normalized = Usage(None, None)
            status = "invalid_usage"
        try:
            completion = completion() if callable(completion) else completion
        except Exception:
            # Projection is best-effort; accounting must still see reported usage.
            completion = ""
        try:
            self.logger._save_to_json(
                self.model,
                normalized.input_tokens,
                normalized.output_tokens,
                self.prompt,
                completion,
                self.encrypt_key,
                status=status,
                cached_input_tokens=normalized.cached_input_tokens,
                cache_write_tokens=normalized.cache_write_tokens,
                operation=self.operation,
                request_id=request_id,
            )
        except Exception:
            # An audit sink must not replace an API result or the original exception.
            pass


def response_text(response):
    output = field(response, "output", []) or []
    try:
        return payload_text(
            [
                item.model_dump() if hasattr(item, "model_dump") else item
                for item in output
            ]
        )
    except (TypeError, ValueError, AttributeError):
        return ""


def chat_text(response):
    """Preserve the ordinary first-choice encrypted audit projection."""
    try:
        message = response.choices[0].message
        if message.content:
            return message.content
        if getattr(message, "tool_calls", None):
            return payload_text([tool.model_dump() for tool in message.tool_calls])
    except (AttributeError, IndexError, TypeError, ValueError):
        pass
    return ""
