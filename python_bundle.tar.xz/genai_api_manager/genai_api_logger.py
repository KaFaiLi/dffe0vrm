import os
import json
import time
import base64
import atexit
import queue
import datetime
import threading
from hashlib import sha256
from dataclasses import dataclass
from typing import Any, Dict, Optional, List, Tuple
from collections import defaultdict
from decimal import Decimal, InvalidOperation

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from .config_loader import load_pricing
from .accounting import DailyBudget, PriceBook, Usage


@dataclass(frozen=True)
class AsyncLoggerConfig:
    async_logging_enabled: bool = True

    # Queue / batching
    queue_maxsize: int = 10_000
    flush_interval_seconds: float = 2.0
    batch_size: int = 100

    # BLOCK-only overflow behavior
    # latency spike accepted up to 10s
    # if still cant write, the records will be dropped
    overflow_block_timeout_seconds: float = 10.0

    # Durability
    enable_fsync: bool = False

    # Cross-process lock (optional)
    cross_process_lock_enabled: bool = False
    lock_timeout_seconds: float = 2.0

    # Retries
    writer_retry_count: int = 3
    writer_retry_backoff_base_seconds: float = 0.25
    writer_retry_backoff_max_seconds: float = 10.0

    # Encryption placement
    encrypt_in_writer: bool = True

    def __post_init__(self):
        if (
            self.queue_maxsize <= 0
            or self.batch_size <= 0
            or self.flush_interval_seconds <= 0
        ):
            raise ValueError(
                "Queue size, batch size, and flush interval must be positive"
            )
        if (
            min(
                self.overflow_block_timeout_seconds,
                self.writer_retry_count,
                self.writer_retry_backoff_base_seconds,
                self.writer_retry_backoff_max_seconds,
            )
            < 0
        ):
            raise ValueError("Timeouts and retry settings cannot be negative")


class GenaiAPILogger:
    """
    Async, single-writer, batched JSONL logger with encryption and daily rotation.

    Key invariants:
      - _save_to_json() must be fast and never perform network writes.
      - Only the writer thread writes to the JSONL file.
      - Each entry is one JSON dict per line (JSONL).
    """

    # Process-local lock for safe init/header writes
    _init_lock = threading.Lock()

    def __init__(
        self,
        log_directory: str,
        pricing_file: str,
        daily_cost_limit: float = 5.0,
        username: str = "anonymous",
        public_key: str = "",
        config: Optional[AsyncLoggerConfig] = None,
        *,
        pricing_data: Optional[Dict[str, Any]] = None,
        pricing_aliases: Optional[Dict[str, str]] = None,
    ):
        self.username = username
        self.daily_cost_limit = daily_cost_limit
        self.config = config or AsyncLoggerConfig()
        limit = Decimal(str(daily_cost_limit))
        if not limit.is_finite() or limit < 0:
            raise ValueError("daily_cost_limit must be finite and nonnegative")

        self.pricing_file = pricing_file

        # --- Crypto setup (preserve your approach) ---
        key = serialization.load_pem_public_key(public_key.encode("utf-8"))
        ephemeral_private_key = ec.generate_private_key(ec.SECP256R1())
        shared_key = ephemeral_private_key.exchange(ec.ECDH(), key)
        self.public_key = shared_key  # bytes

        # Cache derived AES key
        self._aes_key = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"ecies encryption",
        ).derive(self.public_key)

        # --- Pricing data ---
        if pricing_data is not None:
            if not isinstance(pricing_data, dict):
                raise ValueError("pricing_data must be a dict.")
            self.prices_data = pricing_data
        else:
            if not self.pricing_file:
                raise ValueError(
                    "pricing_file must be provided if pricing_data is not passed."
                )
            self.prices_data = load_pricing(self.pricing_file)

        self._price_book = PriceBook(self.prices_data, pricing_aliases)
        self._budget = DailyBudget()
        self._submit_lock = threading.Lock()
        self._sync_lock = threading.Lock()
        self._closed = False

        # Root directory passed from client (network share path)
        self._root_log_directory = log_directory

        # --- Persistent counters/state ---
        self._state_lock = threading.Lock()
        self._dropped_events = 0
        self._written_events = 0
        self._write_errors = 0
        self._enqueue_errors = 0
        self._request_status_counts = {}
        self._last_error_message: Optional[str] = None
        self._last_error_time: Optional[str] = None

        # Async spending follows queue acceptance; writer totals describe persisted logs.

        # Determine today's file, ensure header, recover persisted costs.
        self._writer_current_path: Optional[str] = None
        self._writer_file_handle = None
        self._writer_cumulative_total = Decimal(0)
        self._writer_cumulative_input = Decimal(0)
        self._writer_cumulative_output = Decimal(0)

        # Init cost from existing log (if any)
        self._initialize_daily_state()

        # --- Async infrastructure ---
        self._queue: "queue.Queue[Optional[Dict[str, Any]]]" = queue.Queue(
            maxsize=self.config.queue_maxsize
        )
        self._stop_event = threading.Event()
        self._writer_thread: Optional[threading.Thread] = None

        if self.config.async_logging_enabled:
            self._start_writer_thread()
            atexit.register(self.close)

    # -------------------------
    # Public metrics / status
    # -------------------------
    def get_metrics(self) -> Dict[str, Any]:
        with self._state_lock:
            return {
                "dropped_events": self._dropped_events,
                "written_events": self._written_events,
                "write_errors": self._write_errors,
                "enqueue_errors": self._enqueue_errors,
                "request_status_counts": dict(self._request_status_counts),
                "last_error_message": self._last_error_message,
                "last_error_time": self._last_error_time,
                "queue_size": self._queue.qsize(),
                "daily_cost": self.check_daily_cost(),
                "daily_cost_exact": str(self._budget.snapshot(self._accounting_key())),
                "writer_alive": bool(
                    self._writer_thread and self._writer_thread.is_alive()
                ),
            }

    # -------------------------
    # Paths / rotation helpers
    # -------------------------
    def _get_daily_log_dir(self, now: Optional[datetime.datetime] = None) -> str:
        now = now or datetime.datetime.now()
        today_str = now.strftime("%d_%m_%y")
        return os.path.join(self._root_log_directory, f"log_{today_str}")

    def _get_daily_log_path(self, now: Optional[datetime.datetime] = None) -> str:
        now = now or datetime.datetime.now()
        date = (now.date(), self.username, self._root_log_directory)
        cached = getattr(self, "_path_cache", None)
        if cached is not None and cached[0] == date:
            return cached[1]
        today = now.strftime("%Y-%m-%d")
        daily_dir = self._get_daily_log_dir(now)
        path = os.path.join(
            daily_dir, f"api_token_usage_log_{self.username}_{today}.json"
        )
        self._path_cache = (date, path)
        return path

    def _accounting_key(self, now=None):
        """Pure local day identity, independent of audit path resolution/write success."""
        now = now or datetime.datetime.now()
        date = now.date()
        cached = getattr(self, "_accounting_day_cache", None)
        if cached is not None and cached[0] == date:
            return cached[1]
        path = os.path.join(
            self._root_log_directory,
            f"log_{now.strftime('%d_%m_%y')}",
            f"api_token_usage_log_{self.username}_{now.strftime('%Y-%m-%d')}.json",
        )
        self._accounting_day_cache = (date, path)
        return path

    # -------------------------
    # Pricing / loading
    # -------------------------
    @staticmethod
    def _read_log_records(filename):
        """Read unique persisted lines; yield None for damaged/unreadable records.

        Writer retries reuse the identical encrypted, serialized line. Hashes
        avoid retaining whole audit payloads while suppressing those duplicates.
        """
        seen = set()
        try:
            with open(filename, "rb") as source:
                for line in source:
                    line = line.strip()
                    if not line:
                        continue
                    fingerprint = sha256(line).digest()
                    if fingerprint in seen:
                        continue
                    seen.add(fingerprint)
                    try:
                        data = json.loads(line)
                        if not isinstance(data, dict):
                            raise ValueError("Invalid audit record")
                        if "model_name" not in data:
                            if "cumulative_total_cost" in data:
                                continue  # Original cumulative-total header.
                            raise ValueError("Invalid audit record")
                    except (ValueError, UnicodeDecodeError):
                        yield None
                    else:
                        yield data
        except FileNotFoundError:
            pass
        except OSError:
            yield None

    @staticmethod
    def _recorded_cost(event, name):
        value = event.get(f"{name}_cost")
        if value is None:
            return None
        try:
            amount = Decimal(str(value))
        except InvalidOperation:
            return None
        return amount if amount.is_finite() and amount >= 0 else None

    def _load_daily_totals(self, filename):
        """Recover valid known amounts; missing/damaged costs do not affect the guard."""
        totals = {name: Decimal(0) for name in ("total", "input", "output")}
        for event in self._read_log_records(filename):
            if event is None:
                continue
            for name in totals:
                totals[name] += self._recorded_cost(event, name) or Decimal(0)
        return totals

    # -------------------------
    # Safe file initialization
    # -------------------------
    def _safe_init_file_if_needed(self, path: str) -> None:
        """
        Create file if missing, never truncate existing file.
        Write header only if file is new/empty.
        Safe under concurrency within process via _init_lock.
        """
        with GenaiAPILogger._init_lock:
            os.makedirs(os.path.dirname(path), exist_ok=True)

            # Create if not exists; do not truncate.
            if not os.path.exists(path):
                # 'a' creates if missing; no truncation
                with open(path, "a", encoding="utf-8") as f:
                    pass

            # Write header only if empty
            try:
                if os.path.getsize(path) == 0:
                    header = {
                        "cumulative_total_cost": 0.0,
                        "cumulative_input_cost": 0.0,
                        "cumulative_output_cost": 0.0,
                    }
                    with open(path, "a", encoding="utf-8") as f:
                        f.write(json.dumps(header, ensure_ascii=False) + "\n")
            except OSError:
                # If size check fails due to transient network issues, ignore
                pass

    def _initialize_daily_state(self) -> None:
        """
        Initialize daily cost totals from existing request records.
        """
        path = self._get_daily_log_path()
        self._safe_init_file_if_needed(path)
        totals = self._load_daily_totals(path)
        self._budget.seed(path, totals["total"])
        for name, amount in totals.items():
            setattr(self, f"_writer_cumulative_{name}", amount)

    # -------------------------
    # Cost guard API
    # -------------------------
    def init_daily_cost(self) -> float:
        # preserved compatibility
        return self.check_daily_cost()

    def check_daily_cost(self) -> float:
        return float(self._budget.snapshot(self._accounting_key()))

    def budget_exceeded(self) -> bool:
        return self._budget.exceeded(self._accounting_key(), self.daily_cost_limit)

    def require_priced_model(self, model: str) -> None:
        """Raise UnpricedModelError before dispatch for an unknown model or alias."""
        self._price_book.require_model(model)

    # -------------------------
    # Encryption helpers
    # -------------------------
    def _encrypt_aes_gcm(self, plaintext: str) -> bytes:
        iv = os.urandom(12)
        encryptor = Cipher(algorithms.AES(self._aes_key), modes.GCM(iv)).encryptor()
        ct = encryptor.update(plaintext.encode("utf-8")) + encryptor.finalize()
        # iv + tag + ciphertext (same structure as your current)
        return iv + encryptor.tag + ct

    def _encrypt_fields(self, prompt: str, completion: str) -> Tuple[str, str]:
        enc_prompt = self._encrypt_aes_gcm(prompt)
        enc_completion = self._encrypt_aes_gcm(completion)
        return (
            base64.b64encode(enc_prompt).decode("utf-8"),
            base64.b64encode(enc_completion).decode("utf-8"),
        )

    # -------------------------
    # Async writer thread
    # -------------------------
    def _start_writer_thread(self) -> None:
        if self._writer_thread is not None:
            return
        t = threading.Thread(
            target=self._writer_loop, name="GenaiAPILoggerWriter", daemon=True
        )
        self._writer_thread = t
        t.start()

    def close(self, timeout_seconds: float = 5.0) -> None:
        """Drain within a bounded wait; a timed-out writer keeps its own handle."""
        with self._submit_lock:
            already_closed = self._closed
            self._closed = True
            self._stop_event.set()
            if not already_closed:
                try:
                    self._queue.put_nowait(None)
                except queue.Full:
                    pass
        if self.config.async_logging_enabled:
            thread = self._writer_thread
            if thread and thread is not threading.current_thread():
                thread.join(max(0, timeout_seconds))
            if thread and thread.is_alive():
                return
        else:
            with self._sync_lock:
                if self._writer_file_handle:
                    self._writer_file_handle.flush()
                    self._writer_file_handle.close()
                    self._writer_file_handle = None
        atexit.unregister(self.close)

    shutdown = close  # alias

    # -------------------------
    # Overflow handling
    # -------------------------
    def _handle_overflow_block_only(self, event: Dict[str, Any]) -> bool:
        """
        BLOCK-only overflow policy:
        - block up to overflow_block_timeout_seconds trying to enqueue
        - if still full, drop event (and record dropped_events)
        Returns True if enqueued, False if dropped.
        """
        try:
            self._queue.put(event, timeout=self.config.overflow_block_timeout_seconds)
            return True
        except queue.Full:
            with self._state_lock:
                self._dropped_events += 1
            return False

    # -------------------------
    # Error recording
    # -------------------------
    def _record_error(self, msg: str) -> None:
        with self._state_lock:
            self._last_error_message = msg
            self._last_error_time = datetime.datetime.now().isoformat()
            # We count this as a write error when called from writer; enqueue errors elsewhere
            self._write_errors += 1

    def _record_enqueue_error(self, msg: str) -> None:
        with self._state_lock:
            self._last_error_message = msg
            self._last_error_time = datetime.datetime.now().isoformat()
            self._enqueue_errors += 1

    # -------------------------
    # Writer I/O lock (optional cross-process)
    # -------------------------
    def _acquire_cross_process_lock(self, lock_path: str, timeout: float):
        """
        Best-effort cross-process lock:
          - Windows: msvcrt.locking
          - Unix: fcntl.flock
        No external dependencies.
        """
        if not self.config.cross_process_lock_enabled:
            return None

        start = time.monotonic()
        f = open(lock_path, "a+")
        while True:
            try:
                if os.name == "nt":
                    import msvcrt

                    f.seek(0)
                    # lock 1 byte
                    msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                return f
            except Exception:
                if (time.monotonic() - start) >= timeout:
                    try:
                        f.close()
                    except Exception:
                        pass
                    return None
                time.sleep(0.05)

    def _release_cross_process_lock(self, f):
        if not f:
            return
        try:
            if os.name == "nt":
                import msvcrt

                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except Exception:
            pass
        finally:
            try:
                f.close()
            except Exception:
                pass

    # -------------------------
    # Core writer loop
    # -------------------------
    def _writer_loop(self) -> None:
        next_flush_deadline = time.monotonic() + self.config.flush_interval_seconds
        batch: List[Dict[str, Any]] = []

        while not self._stop_event.is_set():
            # Daily rotation check on each loop
            try:
                self._writer_rotate_if_needed()
            except Exception as e:
                self._record_error(f"rotate_failed: {type(e).__name__}")

            # Compute wait time until next flush
            timeout = max(0.0, next_flush_deadline - time.monotonic())

            try:
                item = self._queue.get(timeout=timeout)
            except queue.Empty:
                item = None  # time-based flush trigger

            if item is None:
                # sentinel or timeout -> flush
                if batch:
                    self._flush_batch_with_retries(batch)
                    batch = []
                next_flush_deadline = (
                    time.monotonic() + self.config.flush_interval_seconds
                )
                continue

            batch.append(item)

            # Size-based flush trigger
            if len(batch) >= self.config.batch_size:
                self._flush_batch_with_retries(batch)
                batch = []
                next_flush_deadline = (
                    time.monotonic() + self.config.flush_interval_seconds
                )

        # Shutdown path: drain queue, flush
        try:
            # drain any remaining items quickly
            while True:
                try:
                    item = self._queue.get_nowait()
                except queue.Empty:
                    break
                if item is None:
                    continue
                batch.append(item)
        except Exception:
            pass

        if batch:
            self._flush_batch_with_retries(batch)

        # Close file handle
        try:
            if self._writer_file_handle:
                self._writer_file_handle.flush()
                if self.config.enable_fsync:
                    os.fsync(self._writer_file_handle.fileno())
                self._writer_file_handle.close()
        except Exception:
            pass
        finally:
            self._writer_file_handle = None

    def _writer_rotate_if_needed(self, path=None) -> None:
        """
        Detect when daily path changes and rotate handle.
        """
        path = path or self._get_daily_log_path()

        if path != self._writer_current_path:
            # close old handle
            if self._writer_file_handle:
                try:
                    self._writer_file_handle.flush()
                    if self.config.enable_fsync:
                        os.fsync(self._writer_file_handle.fileno())
                    self._writer_file_handle.close()
                except Exception:
                    pass
                self._writer_file_handle = None

            # ensure new file exists and header
            self._safe_init_file_if_needed(path)

            totals = self._load_daily_totals(path)
            for name, amount in totals.items():
                setattr(self, f"_writer_cumulative_{name}", amount)

            # open new handle in append mode, reuse across flush cycles
            self._writer_file_handle = open(path, "a", encoding="utf-8")
            self._writer_current_path = path

    def _flush_batch_with_retries(self, batch: List[Dict[str, Any]]) -> None:
        """
        Flush batch with retry/backoff.
        If flush fails, we keep the batch in-memory and retry a few times.
        """
        attempts = 0
        delay = self.config.writer_retry_backoff_base_seconds

        while True:
            try:
                self._flush_batch(batch)
                return
            except Exception as e:
                attempts += 1
                self._record_error(
                    f"write_failed(attempt={attempts}): {type(e).__name__}"
                )

                if attempts > self.config.writer_retry_count:
                    # Give up -> drop batch (do not block app). Count as dropped.
                    with self._state_lock:
                        self._dropped_events += len(batch)
                    return

                time.sleep(min(delay, self.config.writer_retry_backoff_max_seconds))
                delay *= 2

    def _flush_batch(self, batch: List[Dict[str, Any]]) -> None:
        """Encrypt then append batches; retries reuse serialized lines and totals.

        Ambiguous I/O failures may duplicate lines. Accepted charges are not undone.
        Only one writer per log is supported
        unless the optional cross-process file lock is enabled.
        """
        # Keep midnight events on the day in which they were accounted.
        groups = []
        for event in batch:
            path = event.get("_log_path") or self._get_daily_log_path()
            if not groups or groups[-1][0] != path:
                groups.append((path, []))
            groups[-1][1].append(event)
        for path, events in groups:
            self._writer_rotate_if_needed(path)
            if not self._writer_file_handle:
                raise RuntimeError("Writer file handle is not available")
            lock_file = None
            try:
                if self.config.cross_process_lock_enabled:
                    lock_file = self._acquire_cross_process_lock(
                        path + ".lock", self.config.lock_timeout_seconds
                    )
                    if lock_file is None:
                        raise TimeoutError("Audit file lock timed out")
                lines = []
                for event in events:
                    if "_serialized" not in event:
                        if not event.get("_encrypted"):
                            event["prompt"], event["completion"] = self._encrypt_fields(
                                event["prompt"], event["completion"]
                            )
                            event["_encrypted"] = True
                        out = {k: v for k, v in event.items() if not k.startswith("_")}
                        for name in ("total", "input", "output"):
                            attr = f"_writer_cumulative_{name}"
                            amount = Decimal(str(event[f"{name}_cost"] or 0))
                            setattr(self, attr, getattr(self, attr) + amount)
                            out[f"cumulative_{name}_cost"] = float(getattr(self, attr))
                        event["_serialized"] = (
                            json.dumps(out, ensure_ascii=False) + "\n"
                        )
                    lines.append(event["_serialized"])
                self._writer_file_handle.write("".join(lines))
                self._writer_file_handle.flush()
                if self.config.enable_fsync:
                    os.fsync(self._writer_file_handle.fileno())
                with self._state_lock:
                    self._written_events += len(events)
            finally:
                if lock_file is not None:
                    self._release_cross_process_lock(lock_file)

    # -------------------------
    # Public enqueue API
    # -------------------------
    def _save_to_json(
        self,
        model_name: str,
        prompt_token: Optional[int],
        output_token: Optional[int],
        prompt: str,
        completion: str,
        encrypt_key: str,
        *,
        status: str = "completed",
        cached_input_tokens: Optional[int] = 0,
        cache_write_tokens: Optional[int] = 0,
        operation: str = "chat.completions",
        request_id: Optional[str] = None,
    ) -> None:
        """Count known cost after queue acceptance or a synchronous write attempt."""
        try:
            usage = Usage(
                prompt_token, output_token, cached_input_tokens, cache_write_tokens
            )
        except ValueError:
            usage = Usage(None, None)
            status = "invalid_usage"
        charge = self._price_book.quote(model_name, usage)
        now = datetime.datetime.now().astimezone()
        day = self._accounting_key(now)

        # Fixed categories keep diagnostics free of provider payloads. Count once
        # before persistence so queue/path failures remain visible to operators.
        category = (
            status
            if status
            in (
                "completed",
                "incomplete",
                "failed",
                "partial",
                "interrupted",
                "usage_missing",
                "invalid_usage",
                "assembly_error",
                "stream_error",
            )
            else "other"
        )
        with self._state_lock:
            self._request_status_counts[category] = (
                self._request_status_counts.get(category, 0) + 1
            )

        try:
            log_path = self._get_daily_log_path(now)
            if log_path is None:
                raise ValueError("Audit destination unavailable")
        except Exception as error:
            self._record_enqueue_error(f"audit_path_failed: {type(error).__name__}")
            with self._state_lock:
                self._dropped_events += 1
            return

        def numeric(value):
            return float(value) if value is not None else None

        known_usage = usage.input_tokens is not None and usage.output_tokens is not None
        event = {
            "request_id": request_id,
            "operation": operation,
            "model_name": model_name,
            "input_token": usage.input_tokens if known_usage else None,
            "output_token": usage.output_tokens if known_usage else None,
            "cached_input_token": usage.cached_input_tokens if known_usage else None,
            "cache_write_token": usage.cache_write_tokens if known_usage else None,
            "input_cost": numeric(charge.input_cost),
            "output_cost": numeric(charge.output_cost),
            "total_cost": numeric(charge.total),
            "cost_status": charge.status,
            "status": status,
            "timestamp": now.isoformat(),
            "prompt": prompt,
            "completion": completion,
            "_encrypted": False,
            "_log_path": log_path,
            "shared_key": base64.b64encode(self.public_key).decode("utf-8"),
        }
        try:
            with self._submit_lock:
                if self._closed:
                    with self._state_lock:
                        self._dropped_events += 1
                    return
                if not self.config.async_logging_enabled:
                    with self._sync_lock:
                        self._flush_batch_with_retries([event])
                    if charge.total is not None:
                        self._budget.record(day, charge.total)
                    return
                if not self.config.encrypt_in_writer:
                    event["prompt"], event["completion"] = self._encrypt_fields(
                        prompt, completion
                    )
                    event["_encrypted"] = True
                try:
                    self._queue.put_nowait(event)
                    accepted = True
                except queue.Full:
                    accepted = self._handle_overflow_block_only(event)
                if accepted and charge.total is not None:
                    self._budget.record(day, charge.total)
        except Exception as error:
            self._record_enqueue_error(f"enqueue_failed: {type(error).__name__}")

    def print_today_usage_report(self) -> None:
        """
        Simple report: read today's JSONL, aggregate, and print a compact report.
        Sections:
        - Header + Time range
        - TOTALS (calls, tokens, costs)
        - LIMITS (limit, current, remaining)
        - PER-MODEL BREAKDOWN (table)
        """

        def fmt_cost(x: float) -> str:
            return f"{x:,.4f} €"

        def fmt_int(x: int) -> str:
            return f"{x:,}"

        try:
            path = self._get_daily_log_path()
            date_str = (
                os.path.basename(path)
                .replace(f"api_token_usage_log_{self.username}_", "")
                .replace(".json", "")
            )

            # Aggregation holders
            per_model = defaultdict(
                lambda: {
                    "calls": 0,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "input_cost": Decimal(0),
                    "output_cost": Decimal(0),
                    "total_cost": Decimal(0),
                }
            )
            totals = {
                "calls": 0,
                "input_tokens": 0,
                "output_tokens": 0,
                "input_cost": Decimal(0),
                "output_cost": Decimal(0),
                "total_cost": Decimal(0),
            }
            unknown_cost = estimated = cached_total = cache_write_total = 0
            first_ts = None
            last_ts = None

            for ev in self._read_log_records(path):
                if ev is None:
                    continue
                known_cost = self._recorded_cost(ev, "total")
                unknown_cost += int(known_cost is None)
                estimated += int(str(ev.get("cost_status", "")).startswith("estimated"))
                cached_total += ev.get("cached_input_token") or 0
                cache_write_total += ev.get("cache_write_token") or 0
                model = ev.get("model_name", "unknown")
                in_tok = int(ev.get("input_token", 0) or 0)
                out_tok = int(ev.get("output_token", 0) or 0)
                in_cost = self._recorded_cost(ev, "input") or Decimal(0)
                out_cost = self._recorded_cost(ev, "output") or Decimal(0)
                tot_cost = known_cost or Decimal(0)
                ts = ev.get("timestamp")

                pm = per_model[model]
                pm["calls"] += 1
                pm["input_tokens"] += in_tok
                pm["output_tokens"] += out_tok
                pm["input_cost"] += in_cost
                pm["output_cost"] += out_cost
                pm["total_cost"] += tot_cost

                totals["calls"] += 1
                totals["input_tokens"] += in_tok
                totals["output_tokens"] += out_tok
                totals["input_cost"] += in_cost
                totals["output_cost"] += out_cost
                totals["total_cost"] += tot_cost

                if ts:
                    try:
                        if first_ts is None or ts < first_ts:
                            first_ts = ts
                        if last_ts is None or ts > last_ts:
                            last_ts = ts
                    except Exception:
                        pass

            # LIMITS
            current = self.check_daily_cost()
            limit = float(self.daily_cost_limit or 0.0)
            remaining = max(0.0, limit - current) if limit > 0 else 0.0

            # Build and print the report
            header = f"=== GenAI Usage Report — {date_str} — user: {self.username} ==="
            print(header)
            print(f"Time range: {first_ts or 'N/A'}  \u2192  {last_ts or 'N/A'}\n")

            print("TOTALS")
            print(f"  Calls         : {fmt_int(totals['calls'])}")
            print(f"  Input tokens  : {fmt_int(totals['input_tokens'])}")
            print(f"  Output tokens : {fmt_int(totals['output_tokens'])}")
            print(f"  Input cost    : {fmt_cost(totals['input_cost'])}")
            print(f"  Output cost   : {fmt_cost(totals['output_cost'])}")
            print(f"  TOTAL cost    : {fmt_cost(totals['total_cost'])}\n")

            print(f"  Cached input  : {cached_total:,}")
            print(f"  Cache writes  : {cache_write_total:,}")
            print(
                f"  Calls with unknown cost: {unknown_cost:,}; estimated calls: {estimated:,}"
            )
            print("LIMITS")
            print(f"  Daily limit   : {fmt_cost(limit)}")
            print(f"  Current usage : {fmt_cost(current)}")
            print(f"  Remaining     : {fmt_cost(remaining)}\n")

            print("PER-MODEL BREAKDOWN")
            hdr = f"{'Model':36} {'Calls':>7} {'InTok':>10} {'OutTok':>10} {'InCost':>12} {'OutCost':>12} {'Total':>12}"
            print(hdr)
            print("-" * len(hdr))
            for model, stats in sorted(
                per_model.items(), key=lambda kv: kv[1]["total_cost"], reverse=True
            ):
                print(
                    f"{model:36} "
                    f"{stats['calls']:7d} "
                    f"{stats['input_tokens']:10,d} "
                    f"{stats['output_tokens']:10,d} "
                    f"{fmt_cost(stats['input_cost']):>12} "
                    f"{fmt_cost(stats['output_cost']):>12} "
                    f"{fmt_cost(stats['total_cost']):>12}"
                )

        except Exception as e:
            # Keep it simple: best-effort print and capture an error internally
            self._record_error(f"print_today_usage_report_failed: {e}")
            print("Failed to print today's usage report.")
