"""Portable corporate defaults, with an explicit network-blocked offline profile."""

from pathlib import Path

from tests.support.client import make_client as make_client
from tests.support.client import retry_delays as retry_delays
from tests.support.acceptance import standard_acceptance as standard_acceptance

import pytest


def pytest_addoption(parser):
    parser.addoption(
        "--offline",
        action="store_true",
        help="Run synthetic regressions; block sockets",
    )
    parser.addoption(
        "--run-azure",
        action="store_true",
        help="Legacy alias for the default corporate profile",
    )


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    offline = config.getoption("--offline")
    if offline and config.getoption("--run-azure"):
        raise pytest.UsageError("--offline and --run-azure cannot be combined")
    if offline:
        if not config.pluginmanager.hasplugin("socket"):
            raise pytest.UsageError("The offline profile requires pytest-socket")
        if config.getoption("--force-enable-socket"):
            raise pytest.UsageError("--offline cannot enable network connections")
        # Set the policy before pytest-socket snapshots it in pytest_configure.
        config.option.disable_socket = True


def pytest_ignore_collect(collection_path, config):
    if config.getoption("--offline"):
        return None
    test_root = Path(__file__).resolve().parent
    if (
        collection_path.is_relative_to(test_root)
        and collection_path.name.startswith("test_")
        and collection_path.suffix == ".py"
        and "azure" not in collection_path.relative_to(test_root).parts
    ):
        return True
    return None


def pytest_collection_modifyitems(config, items):
    offline = config.getoption("--offline")
    if not offline:
        deselected = [item for item in items if "azure" not in item.keywords]
        items[:] = [item for item in items if "azure" in item.keywords]
        if deselected:
            config.hook.pytest_deselected(items=deselected)
    for item in items:
        if offline and "azure" in item.keywords:
            item.add_marker(
                pytest.mark.skip(reason="Corporate live tests excluded by --offline")
            )


@pytest.fixture(autouse=True)
def isolate_local_services(request, monkeypatch):
    if "azure" in request.keywords:
        return
    if not request.config.getoption("--offline"):
        return
    from genai_api_manager import GenAiApiClient

    monkeypatch.setattr(GenAiApiClient, "_ensure_px_running", lambda self: None)
    monkeypatch.setattr(GenAiApiClient, "_ensure_px_for_use", lambda self: None)
