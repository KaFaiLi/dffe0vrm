import json
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest


from genai_api_manager import GenAiApiClient


@pytest.fixture
def wrapper():
    w = GenAiApiClient.__new__(GenAiApiClient)
    w._openai_client = MagicMock()
    w.log_manager = MagicMock()
    w.log_manager.budget_exceeded.return_value = False
    w.encrypt_key = ""
    w._invalidate_connection = MagicMock()
    w.log_manager.daily_cost_limit = 999999
    w.log_manager.check_daily_cost.return_value = 0
    w.log_manager._get_daily_log_path.return_value = "/tmp/daily.json"

    # mock response object
    resp = SimpleNamespace(
        data=[
            SimpleNamespace(embedding=[0.1, 0.2, 0.3]),
            SimpleNamespace(embedding=[0.4, 0.5, 0.6]),
        ],
        usage=SimpleNamespace(prompt_tokens=12, total_tokens=12),
        model="text-embedding-3-small",
        object="list",
    )
    w._openai_client.embeddings.create.return_value = resp
    yield w
    w.close()


# ----------------------------
# Unit tests
# ----------------------------


def test_single_string_returns_full_response(wrapper):
    resp = wrapper.get_genai_embeddings(model="m", input="hello")
    assert resp.object == "list"
    wrapper._openai_client.embeddings.create.assert_called_once()
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["model"] == "m"
    assert kwargs["input"] == "hello"


def test_multi_string_batch(wrapper):
    resp = wrapper.get_genai_embeddings(model="m", input=["doc1", "doc2"])
    assert resp.object == "list"
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["input"] == ["doc1", "doc2"]


def test_token_array_single(wrapper):
    resp = wrapper.get_genai_embeddings(model="m", input=[101, 102, 103])
    assert resp.object == "list"
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["input"] == [101, 102, 103]


def test_token_array_multi(wrapper):
    resp = wrapper.get_genai_embeddings(model="m", input=[[101, 102], [201, 202]])
    assert resp.object == "list"
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["input"] == [[101, 102], [201, 202]]


def test_optional_fields_pass_through(wrapper):
    wrapper.get_genai_embeddings(
        model="m",
        input="hello",
        dimensions=256,
        encoding_format="float",
        user="u1",
    )
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["dimensions"] == 256
    assert kwargs["encoding_format"] == "float"
    assert kwargs["user"] == "u1"


def test_request_dict_used(wrapper):
    wrapper.get_genai_embeddings(request={"model": "m_req", "input": "hi"})
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["model"] == "m_req"
    assert kwargs["input"] == "hi"


def test_missing_model_raises(wrapper):
    with pytest.raises(ValueError):
        wrapper.get_genai_embeddings(input="hello")


def test_missing_input_raises(wrapper):
    with pytest.raises(ValueError):
        wrapper.get_genai_embeddings(model="m")


def test_empty_string_raises(wrapper):
    with pytest.raises(ValueError):
        wrapper.get_genai_embeddings(model="m", input="   ")


def test_empty_list_raises(wrapper):
    with pytest.raises(ValueError):
        wrapper.get_genai_embeddings(model="m", input=[])


def test_too_many_inputs_raises(wrapper):
    with pytest.raises(ValueError):
        wrapper.get_genai_embeddings(model="m", input=["x"] * 2049)


def test_cost_guard(wrapper):
    wrapper.log_manager.budget_exceeded.return_value = True
    wrapper.log_manager.check_daily_cost.return_value = 100
    wrapper.log_manager.daily_cost_limit = 1
    out = wrapper.get_genai_embeddings(model="m", input="hello")
    assert out == "Daily cost limit exceeded."
    wrapper._invalidate_connection.assert_called_once()
    wrapper._openai_client.embeddings.create.assert_not_called()


def test_embeddings_only_single(wrapper):
    vec = wrapper.get_genai_embeddings(model="m", input="hello", embeddings_only=True)
    assert vec == [0.1, 0.2, 0.3]


def test_embeddings_only_multi(wrapper):
    vecs = wrapper.get_genai_embeddings(
        model="m", input=["a", "b"], embeddings_only=True
    )
    assert vecs == [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]


def test_logging_logs_full_string(wrapper):
    long_text = "A" * 20000
    wrapper.get_genai_embeddings(model="m", input=long_text)
    wrapper.log_manager._save_to_json.assert_called_once()
    args, _ = wrapper.log_manager._save_to_json.call_args
    logged_prompt = args[3]
    assert logged_prompt == long_text  # exact match, no truncation


def test_logging_logs_full_list_json(wrapper):
    payload = ["doc1", "doc2"]
    wrapper.get_genai_embeddings(model="m", input=payload)
    args, _ = wrapper.log_manager._save_to_json.call_args
    logged_prompt = args[3]
    assert logged_prompt == json.dumps(payload, ensure_ascii=False)


def test_max_length_truncates_string(wrapper):
    wrapper.get_genai_embeddings(model="m", input="abcdefghij", max_length=4)
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["input"] == "abcd"


def test_max_length_truncates_token_array(wrapper):
    wrapper.get_genai_embeddings(model="m", input=[1, 2, 3, 4, 5], max_length=3)
    _, kwargs = wrapper._openai_client.embeddings.create.call_args
    assert kwargs["input"] == [1, 2, 3]
