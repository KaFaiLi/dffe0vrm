import json
import os
import pytest

from genai_api_manager.config_loader import (
    load_config,
    load_pricing,
    clear_config_cache,
)

from genai_api_manager.genai_api_client import GenAiApiClient


# ---------------------------
# Test doubles / stubs
# ---------------------------


class _DummyOpenAI:
    def __init__(self, *args, **kwargs):
        pass

    class embeddings:
        @staticmethod
        def create(**kwargs):
            raise RuntimeError("Not used in this integration test.")

    class chat:
        class completions:
            @staticmethod
            def create(**kwargs):
                raise RuntimeError("Not used in this integration test.")


class _DummyLogger:
    def __init__(self, **kwargs):
        # capture inputs for assertions
        self.kwargs = kwargs
        self.daily_cost_limit = kwargs.get("daily_cost_limit", 0)

    def check_daily_cost(self):
        return 0.0


@pytest.fixture()
def shared_config_files(tmp_path, monkeypatch):
    """
    Create a temp 'trusted' config.json + pricing.json and patch the library
    to treat tmp config as the hard-locked shared config path.
    """
    # Create pricing file
    pricing_path = tmp_path / "MODELS_PRICE1K_AZURE.json"
    pricing_path.write_text(
        json.dumps(
            {
                "gpt-4o-2024-11-20": {"input": 1.0, "output": 3.0},
                "text-embedding-ada-002": {"input": 0.1, "output": 0.0},
            }
        ),
        encoding="utf-8",
    )

    # Create config file that includes a trusted absolute pricing_file path
    config_path = tmp_path / "config.json"
    config_payload = {
        "userinfo_url": "https://example.invalid/userinfo",
        "azure_openai_endpoint": "https://example.invalid/",
        "llm_token_path": str(tmp_path / "Credential"),
        "llm_log_path": str(tmp_path / "Log_Azure"),
        "pricing_file": str(pricing_path),  # <-- absolute trusted path from config
    }
    config_path.write_text(json.dumps(config_payload), encoding="utf-8")

    # Make directories used by client access checks
    os.makedirs(config_payload["llm_token_path"], exist_ok=True)
    os.makedirs(config_payload["llm_log_path"], exist_ok=True)

    # Patch DEFAULT_CONFIG_PATH to point to our temp config.json (trusted for the test)
    import genai_api_manager.config_loader as config_loader_mod

    monkeypatch.setattr(config_loader_mod, "DEFAULT_CONFIG_PATH", str(config_path))

    # Clear caches so the patched path is used
    clear_config_cache()

    yield {
        "config_path": str(config_path),
        "pricing_path": str(pricing_path),
        "config": config_payload,
    }

    clear_config_cache()


@pytest.fixture()
def stub_external_deps(monkeypatch):
    """
    Stub out external services so the test doesn't touch network/Azure.
    """
    # Patch SDK construction used inside genai_api_client module
    import genai_api_manager.genai_api_client as client_mod

    monkeypatch.setattr(client_mod, "create_azure_client", _DummyOpenAI)

    # Patch azure.identity pieces
    class _DummyCred:
        def __init__(self, *args, **kwargs):
            pass

    def _dummy_token_provider(*args, **kwargs):
        return lambda: "dummy-token"

    monkeypatch.setattr(client_mod, "ClientSecretCredential", _DummyCred)
    monkeypatch.setattr(client_mod, "get_bearer_token_provider", _dummy_token_provider)

    # Patch GenaiAPILogger
    monkeypatch.setattr(client_mod, "GenaiAPILogger", _DummyLogger)

    # Patch os.getlogin to avoid CI failures
    monkeypatch.setattr(client_mod.os, "getlogin", lambda: "test-user")

    # Patch client instance methods that touch filesystem credential JSON
    monkeypatch.setattr(
        GenAiApiClient,
        "_check_directory_access",
        lambda self, path, access_right="read": True,
    )

    monkeypatch.setattr(
        GenAiApiClient,
        "_load_credentials",
        lambda self, cred_path: {
            "client_id": "cid",
            "client_secret": "csecret",
            "azure_tenant_id": "tid",
            "azure_client_id": "aid",
            "azure_client_secret": "asecret",
            "Public_Key": "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A...\n-----END PUBLIC KEY-----",
        },
    )


# ---------------------------
# Tests
# ---------------------------


def test_load_config_is_locked(shared_config_files):
    # load_config() must work with no args
    cfg = load_config()
    assert cfg["pricing_file"] == shared_config_files["pricing_path"]

    # load_config(config_path=...) must be forbidden
    with pytest.raises(PermissionError):
        load_config("C:/temp/evil_config.json")


def test_load_pricing_must_match_trusted_config(shared_config_files):
    # load_pricing() must accept the path that equals config.json["pricing_file"]
    pricing = load_pricing(shared_config_files["pricing_path"])
    assert "gpt-4o-2024-11-20" in pricing

    # Any other pricing path must be rejected
    other_path = os.path.join(
        os.path.dirname(shared_config_files["pricing_path"]), "evil.json"
    )
    with open(other_path, "w", encoding="utf-8") as f:
        json.dump({"x": {"input": 0, "output": 0}}, f)

    with pytest.raises(PermissionError):
        load_pricing(other_path)


def test_client_uses_trusted_config_and_pricing(
    shared_config_files, stub_external_deps
):
    # With stubs in place, we can instantiate without accessing Azure
    client = GenAiApiClient(daily_cost_limit=5.0)

    # Ensure pricing_file passed into logger equals the trusted config pricing_file
    assert (
        client.log_manager.kwargs["pricing_file"] == shared_config_files["pricing_path"]
    )

    # Ensure the config-derived paths were read
    assert client.llm_token_path == shared_config_files["config"]["llm_token_path"]
    assert client.llm_log_path == shared_config_files["config"]["llm_log_path"]


def test_constructor_rejects_override_kwargs(shared_config_files, stub_external_deps):
    # Because __init__ no longer accepts config_path/pricing_path, Python raises TypeError
    with pytest.raises(TypeError):
        GenAiApiClient(config_path="C:/temp/config.json")  # type: ignore

    with pytest.raises(TypeError):
        GenAiApiClient(pricing_path="C:/temp/pricing.json")  # type: ignore
