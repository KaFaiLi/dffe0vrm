"""The copied tests folder selects corporate defaults without local tools."""

import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


@pytest.fixture
def portable_tests(tmp_path):
    source = Path(__file__).resolve().parents[1]
    target = tmp_path / "tests"
    shutil.copytree(
        source, target, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache")
    )
    # Fail even if a development checkout is accidentally present on sys.path.
    guard = """
import importlib.abc
import sys

class RejectDevtools(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "devtools" or fullname.startswith("devtools."):
            raise ImportError("Corporate tests cannot depend on devtools")

sys.meta_path.insert(0, RejectDevtools())
"""
    conftest = target / "conftest.py"
    conftest.write_text(guard + conftest.read_text(encoding="utf-8"), encoding="utf-8")
    return target


def run_copied_tests(target, *arguments):
    environment = os.environ.copy()
    for name in ("PYTHONPATH", "PYTEST_ADDOPTS", "PYTEST_PLUGINS"):
        environment.pop(name, None)
    result = subprocess.run(
        [sys.executable, "-m", "pytest", *arguments],
        cwd=target.parent,
        env=environment,
        text=True,
        capture_output=True,
        timeout=45,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    return result.stdout


def test_copied_folder_collects_only_corporate_cases(portable_tests):
    output = run_copied_tests(portable_tests, "tests", "--collect-only", "-q")
    cases = [line for line in output.splitlines() if "::test_standard_usage[" in line]
    assert len(cases) == 15
    assert sum("api_manager/azure/" in case for case in cases) == 7
    assert sum("langchain/azure/" in case for case in cases) == 8
    assert "15 tests collected" in output
    assert not (portable_tests.parent / "devtools").exists()
    assert not (portable_tests.parent / "pyproject.toml").exists()


def test_copied_hosted_tool_results_match_chatopenai(portable_tests):
    output = run_copied_tests(
        portable_tests,
        "tests/langchain/contracts/test_socgenai_native_tool_results.py",
        "--offline",
        "-q",
    )
    assert "192 passed" in output


def test_copied_wrapper_warnings_are_errors(portable_tests):
    output = run_copied_tests(
        portable_tests,
        "tests/langchain/contracts/test_socgenai_error_callbacks.py",
        "tests/langchain/contracts/test_socgenai_chat_streaming.py::test_full_surface",
        "tests/langchain/contracts/test_socgenai_chat_streaming.py::test_native_tool_conversion_parity",
        "tests/langchain/contracts/test_socgenai_cache_structured.py::test_native_and_custom_reject_truncated_pydantic_output",
        "--offline",
        "-W",
        "error",
        "-q",
    )
    assert "42 passed" in output
    assert "warnings summary" not in output


@pytest.mark.parametrize("offline", [False, True])
def test_copied_profiles_execute_with_correct_network_policy(portable_tests, offline):
    probe = """
import socket
import pytest
import pytest_socket

def check_network_policy(request):
    if request.config.getoption("--offline"):
        with pytest.raises(pytest_socket.SocketBlockedError):
            socket.socket()
    else:
        # Construct and close only; no network connection is made.
        with socket.socket():
            pass

def test_network_policy(request):
    check_network_policy(request)
"""
    (portable_tests / "api_manager/test_profile_probe.py").write_text(
        probe, encoding="utf-8"
    )
    (portable_tests / "api_manager/azure/test_profile_probe.py").write_text(
        probe + "\npytestmark = pytest.mark.azure\n",
        encoding="utf-8",
    )
    # Run the real corporate fixture and public constructors against synthetic
    # configuration and MockTransport, exercising every case without live calls.
    (portable_tests / "conftest.py").write_text(
        (portable_tests / "conftest.py").read_text(encoding="utf-8")
        + """

@pytest.fixture(autouse=True)
def synthetic_corporate_profile(make_client, monkeypatch):
    from genai_api_manager import GenAiApiClient
    from tests.support.standard import PRICES, standard_handler

    monkeypatch.setattr(GenAiApiClient, "_ensure_px_running", lambda self: None)
    monkeypatch.setattr(GenAiApiClient, "_ensure_px_for_use", lambda self: None)
    seed = make_client(standard_handler(), pricing_data=PRICES, internal_streaming=True)
    seed.close()
    monkeypatch.setenv("GENAI_AZURE_CHAT_DEPLOYMENT", "deployment")
    monkeypatch.setenv("GENAI_AZURE_EMBEDDING_DEPLOYMENT", "embedding-deployment")
    monkeypatch.setenv("GENAI_EXPECT_INTERNAL_STREAMING", "true")
    monkeypatch.delenv("GENAI_AZURE_REASONING_EFFORT", raising=False)
""",
        encoding="utf-8",
    )
    if offline:
        arguments = (
            "--offline",
            "tests/api_manager/test_profile_probe.py",
            "tests/api_manager/azure",
            "tests/langchain/azure",
        )
        expected = "1 passed, 16 skipped"
    else:
        arguments = ("tests",)
        expected = "16 passed"
    output = run_copied_tests(portable_tests, *arguments, "-q")
    assert expected in output
