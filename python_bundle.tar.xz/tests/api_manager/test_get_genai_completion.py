import json
from types import SimpleNamespace
from unittest.mock import MagicMock
import pytest

from genai_api_manager.genai_api_client import GenAiApiClient


# ---------------------------
# Helpers / Fakes
# ---------------------------


class FakeLogManager:
    def __init__(self, daily_cost=0.0, daily_limit=999.0, enable_log=False):
        self._daily_cost = daily_cost
        self.daily_cost_limit = daily_limit
        self._enable_log = enable_log
        self._save_to_json = MagicMock()
        self.require_priced_model = MagicMock()

    def check_daily_cost(self):
        return self._daily_cost

    def _get_daily_log_path(self):
        return "/tmp/fake_log.json" if self._enable_log else None


class FakeStream:
    def __init__(self, events, close_error=None):
        self.events = list(events)
        self.close_error = close_error
        self.position = 0
        self.iter_calls = 0
        self.next_calls = 0
        self.close_calls = 0

    def __iter__(self):
        self.iter_calls += 1
        return self

    def __next__(self):
        self.next_calls += 1
        if self.position >= len(self.events):
            raise StopIteration
        event = self.events[self.position]
        self.position += 1
        if isinstance(event, BaseException):
            raise event
        return event

    def close(self):
        self.close_calls += 1
        if self.close_error is not None:
            raise self.close_error


def make_content_chunk(content, *, index=None):
    delta = SimpleNamespace(content=content, tool_calls=None)
    choice = SimpleNamespace(delta=delta)
    if index is not None:
        choice.index = index
    return SimpleNamespace(choices=[choice], usage=None)


def make_tool_chunk(*tool_calls):
    delta = SimpleNamespace(content=None, tool_calls=list(tool_calls))
    return SimpleNamespace(
        choices=[SimpleNamespace(index=0, delta=delta)],
        usage=None,
    )


def make_tool_call(index, *, id=None, type=None, name=None, arguments=None):
    return SimpleNamespace(
        index=index,
        id=id,
        type=type,
        function=SimpleNamespace(name=name, arguments=arguments),
    )


def make_usage_chunk(prompt_tokens=12, completion_tokens=34):
    return SimpleNamespace(
        choices=[],
        usage=SimpleNamespace(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        ),
    )


def make_fake_chat_response(
    content="OK",
    prompt_tokens=12,
    completion_tokens=34,
    tool_calls=None,
):
    """
    Fake shape compatible with:
      res.choices[0].message.content
      res.choices[0].message.tool_calls
      res.usage.prompt_tokens
      res.usage.completion_tokens
    """
    msg = SimpleNamespace(content=content, tool_calls=tool_calls)
    choice = SimpleNamespace(message=msg)
    usage = SimpleNamespace(
        prompt_tokens=prompt_tokens, completion_tokens=completion_tokens
    )
    return SimpleNamespace(choices=[choice], usage=usage)


def make_fake_embedding_response(vector=None):
    if vector is None:
        vector = [0.1, 0.2, 0.3]
    item = SimpleNamespace(embedding=vector)
    return SimpleNamespace(data=[item])


# ---------------------------
# Fixtures
# ---------------------------


@pytest.fixture
def client():
    """
    Create GenAiApiClient instance WITHOUT calling __init__ (to avoid I/O and auth setup),
    and inject a mocked reusable _openai_client.
    """
    c = GenAiApiClient.__new__(GenAiApiClient)
    c.internal_streaming = False

    # minimal fields used by methods
    c.encrypt_key = "fake-public-key"
    c.log_manager = FakeLogManager(daily_cost=0.0, daily_limit=999.0, enable_log=False)

    # inject reusable OpenAI client mock
    c._openai_client = MagicMock()
    c._openai_client.chat.completions.create = MagicMock()
    c._openai_client.embeddings.create = MagicMock()

    # mock invalidate (so we can assert it is called)
    c._invalidate_connection = MagicMock()

    yield c
    c.close()


# ---------------------------
# Tests: Streaming
# ---------------------------


def test_stream_request_forces_usage_options_without_mutating_caller(client):
    source = FakeStream([])
    client._openai_client.chat.completions.create.return_value = source
    options = {"include_usage": False, "future_option": {"keep": True}}
    request = {
        "model": "deployment",
        "messages": [{"role": "user", "content": "hi"}],
        "stream": True,
        "stream_options": options,
    }

    stream = client.get_genai_completion(request=request)

    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["stream"] is True
    assert kwargs["stream_options"] == {
        "include_usage": True,
        "future_option": {"keep": True},
    }
    assert kwargs["stream_options"] is not options
    assert options == {"include_usage": False, "future_option": {"keep": True}}
    assert request["stream_options"] is options
    assert source.next_calls == 0
    stream.close()


def test_stream_kwargs_override_request_and_yield_original_chunks_lazily(client):
    first = make_content_chunk("one")
    second = make_content_chunk("two", index=0)
    usage = make_usage_chunk()
    source = FakeStream([first, second, usage])
    client._openai_client.chat.completions.create.return_value = source

    stream = client.get_genai_completion(
        request={
            "model": "deployment",
            "messages": [{"role": "user", "content": "hi"}],
            "stream": False,
        },
        stream=True,
    )

    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["stream"] is True
    assert source.iter_calls == 1
    assert source.next_calls == 0
    assert next(stream) is first
    assert source.next_calls == 1
    assert next(stream) is second
    assert next(stream) is usage
    assert source.next_calls == 3


def test_stream_options_without_stream_are_forwarded_to_sdk(client):
    response = make_fake_chat_response()
    client._openai_client.chat.completions.create.return_value = response
    options = {"include_usage": False}

    result = client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
        stream_options=options,
    )

    assert result is response
    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["stream_options"] is options


def test_stream_logs_completed_only_at_exhaustion_and_once(client):
    client.log_manager = FakeLogManager(enable_log=True)
    client.log_manager._get_daily_log_path = MagicMock(
        return_value="/tmp/fake_log.json"
    )
    first = make_content_chunk("Hel")
    empty = make_content_chunk("")
    second = make_content_chunk("lo")
    second.choices[0].finish_reason = "stop"
    usage = make_usage_chunk(prompt_tokens=7, completion_tokens=11)
    source = FakeStream([first, empty, second, usage])
    client._openai_client.chat.completions.create.return_value = source

    stream = client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
        stream=True,
    )
    assert next(stream) is first
    assert next(stream) is empty
    assert next(stream) is second
    assert next(stream) is usage

    client.log_manager._save_to_json.assert_not_called()
    with pytest.raises(StopIteration):
        next(stream)

    client.log_manager._save_to_json.assert_called_once_with(
        "deployment",
        7,
        11,
        '[{"role": "user", "content": "hi"}]',
        "Hello",
        client.encrypt_key,
        status="completed",
        cached_input_tokens=None,
        cache_write_tokens=None,
        operation="chat.completions",
        request_id=None,
    )
    client.log_manager._get_daily_log_path.assert_not_called()

    with pytest.raises(StopIteration):
        next(stream)
    stream.close()
    stream.close()
    assert client.log_manager._save_to_json.call_count == 1
    assert source.close_calls == 1


def test_legacy_inputs_support_streaming(client):
    source = FakeStream([])
    client._openai_client.chat.completions.create.return_value = source

    stream = client.get_genai_completion(
        prompt="User prompt",
        system_message="System msg",
        model="deployment",
        stream=True,
    )

    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["messages"] == [
        {"role": "system", "content": "System msg"},
        {"role": "user", "content": "User prompt"},
    ]
    stream.close()


def test_stream_reconstructs_fragmented_tool_calls_in_index_order(client):
    client.log_manager = FakeLogManager(enable_log=True)
    source = FakeStream(
        [
            make_tool_chunk(
                make_tool_call(
                    1,
                    id="call-b",
                    type="function",
                    name="wea",
                    arguments='{"city":"',
                ),
                make_tool_call(0, name="get_", arguments='{"x":'),
            ),
            make_tool_chunk(
                make_tool_call(
                    0,
                    id="call-a",
                    type="function",
                    name="value",
                    arguments="1}",
                ),
                make_tool_call(
                    1,
                    id="ignored",
                    type="ignored",
                    name="ther",
                    arguments='Paris"}',
                ),
            ),
            make_usage_chunk(prompt_tokens=2, completion_tokens=3),
        ]
    )
    source.events[1].choices[0].finish_reason = "tool_calls"
    client._openai_client.chat.completions.create.return_value = source

    list(
        client.get_genai_completion(
            model="deployment",
            messages=[{"role": "user", "content": "tools"}],
            stream=True,
        )
    )

    args, kwargs = client.log_manager._save_to_json.call_args
    assert args[1:3] == (2, 3)
    assert json.loads(args[4]) == [
        {
            "id": "call-a",
            "type": "function",
            "function": {"name": "get_value", "arguments": '{"x":1}'},
        },
        {
            "id": "call-b",
            "type": "function",
            "function": {
                "name": "weather",
                "arguments": '{"city":"Paris"}',
            },
        },
    ]
    assert kwargs["status"] == "completed"


def test_explicit_close_logs_partial_once_without_draining(client):
    client.log_manager = FakeLogManager(enable_log=True)
    first = make_content_chunk("partial")
    source = FakeStream([first, make_content_chunk("unread")])
    client._openai_client.chat.completions.create.return_value = source
    stream = client.get_genai_completion(
        prompt="question",
        model="deployment",
        stream=True,
    )

    assert next(stream) is first
    stream.close()
    stream.close()

    client.log_manager._save_to_json.assert_called_once_with(
        "deployment",
        None,
        None,
        "question",
        "partial",
        client.encrypt_key,
        status="partial",
        cached_input_tokens=None,
        cache_write_tokens=None,
        operation="chat.completions",
        request_id=None,
    )
    assert source.next_calls == 1
    assert source.close_calls == 1
    with pytest.raises(StopIteration):
        next(stream)
    assert source.next_calls == 1


def test_context_exit_logs_partial_and_closes_source(client):
    client.log_manager = FakeLogManager(enable_log=True)
    first = make_content_chunk("observed")
    source = FakeStream([first, make_content_chunk("unread")])
    client._openai_client.chat.completions.create.return_value = source

    with client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
        stream=True,
    ) as stream:
        assert next(stream) is first

    args, kwargs = client.log_manager._save_to_json.call_args
    assert args[1:3] == (None, None)
    assert args[4] == "observed"
    assert kwargs["status"] == "partial"
    assert source.next_calls == 1
    assert source.close_calls == 1


def test_breaking_mid_stream_in_context_logs_partial_without_draining(client):
    client.log_manager = FakeLogManager(enable_log=True)
    first = make_content_chunk("first")
    source = FakeStream([first, make_content_chunk("unread"), make_usage_chunk()])
    client._openai_client.chat.completions.create.return_value = source

    with client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
        stream=True,
    ) as stream:
        for chunk in stream:
            assert chunk is first
            break

    client.log_manager._save_to_json.assert_called_once_with(
        "deployment",
        None,
        None,
        '[{"role": "user", "content": "hi"}]',
        "first",
        client.encrypt_key,
        status="partial",
        cached_input_tokens=None,
        cache_write_tokens=None,
        operation="chat.completions",
        request_id=None,
    )
    assert source.next_calls == 1
    assert source.position == 1
    assert source.close_calls == 1


def test_iteration_error_logs_stream_error_and_reraises_same_exception(client):
    client.log_manager = FakeLogManager(enable_log=True)
    error = RuntimeError("source failed")
    first = make_content_chunk("before error")
    source = FakeStream([first, error])
    client._openai_client.chat.completions.create.return_value = source
    stream = client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
        stream=True,
    )

    assert next(stream) is first
    with pytest.raises(RuntimeError) as exc_info:
        next(stream)
    assert exc_info.value is error

    args, kwargs = client.log_manager._save_to_json.call_args
    assert args[1:3] == (None, None)
    assert args[4] == "before error"
    assert kwargs["status"] == "stream_error"
    assert source.close_calls == 1
    stream.close()
    assert client.log_manager._save_to_json.call_count == 1
    assert source.close_calls == 1


def test_exhaustion_without_usage_logs_usage_missing_once(client):
    client.log_manager = FakeLogManager(enable_log=True)
    chunk = make_content_chunk("no usage")
    chunk.choices[0].finish_reason = "stop"
    source = FakeStream([chunk])
    client._openai_client.chat.completions.create.return_value = source
    stream = client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
        stream=True,
    )

    assert list(stream) == [chunk]
    args, kwargs = client.log_manager._save_to_json.call_args
    assert args[1:3] == (None, None)
    assert args[4] == "no usage"
    assert kwargs["status"] == "usage_missing"
    assert source.close_calls == 1
    stream.close()
    assert client.log_manager._save_to_json.call_count == 1


@pytest.mark.parametrize("enable_log", [False, True])
def test_stream_submits_accounting_with_no_destination_or_failing_logger(
    client, enable_log
):
    client.log_manager = FakeLogManager(enable_log=enable_log)
    if enable_log:
        client.log_manager._save_to_json.side_effect = RuntimeError("logger failed")
    chunk = make_content_chunk("ok")
    usage = make_usage_chunk()
    source = FakeStream([chunk, usage])
    client._openai_client.chat.completions.create.return_value = source

    assert list(
        client.get_genai_completion(
            model="deployment",
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        )
    ) == [chunk, usage]
    assert client.log_manager._save_to_json.call_count == 1


def test_stream_survives_failing_log_enablement_check(client):
    client.log_manager = FakeLogManager(enable_log=True)
    client.log_manager._get_daily_log_path = MagicMock(
        side_effect=RuntimeError("path failed")
    )
    usage = make_usage_chunk()
    client._openai_client.chat.completions.create.return_value = FakeStream([usage])

    assert list(
        client.get_genai_completion(
            model="deployment",
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        )
    ) == [usage]
    client.log_manager._get_daily_log_path.assert_not_called()
    client.log_manager._save_to_json.assert_called_once()


def test_stream_creation_error_propagates_without_accounting(client):
    client.log_manager = FakeLogManager(enable_log=True)
    client.log_manager._get_daily_log_path = MagicMock(
        return_value="/tmp/fake_log.json"
    )
    error = RuntimeError("creation failed")
    client._openai_client.chat.completions.create.side_effect = error

    with pytest.raises(RuntimeError) as exc_info:
        client.get_genai_completion(
            model="deployment",
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        )
    assert exc_info.value is error
    client.log_manager._save_to_json.assert_not_called()


def test_context_preserves_user_error_when_source_close_fails(client):
    error = ValueError("user failed")
    source = FakeStream([], close_error=RuntimeError("close failed"))
    client._openai_client.chat.completions.create.return_value = source

    with pytest.raises(ValueError) as exc_info:
        with client.get_genai_completion(
            model="deployment",
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
        ):
            raise error
    assert exc_info.value is error
    assert source.close_calls == 1


# ---------------------------
# Tests: Required fields validation
# ---------------------------


def test_missing_model_raises(client):
    with pytest.raises(ValueError) as e:
        client.get_genai_completion(messages=[{"role": "user", "content": "hi"}])
    assert "model" in str(e.value).lower()
    client._openai_client.chat.completions.create.assert_not_called()


def test_missing_messages_raises(client):
    with pytest.raises(ValueError) as e:
        client.get_genai_completion(model="deployment")
    assert "messages" in str(e.value).lower()
    client._openai_client.chat.completions.create.assert_not_called()


# ---------------------------
# Tests: Return full response object
# ---------------------------


def test_returns_full_response_object(client):
    fake_res = make_fake_chat_response(content="Hello")
    client._openai_client.chat.completions.create.return_value = fake_res

    res = client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
        temperature=0.2,
    )

    assert res is fake_res
    client._openai_client.chat.completions.create.assert_called_once()


# ---------------------------
# Tests: Backwards compatibility (prompt/system_message)
# ---------------------------


def test_builds_messages_from_prompt_and_system(client):
    client._openai_client.chat.completions.create.return_value = (
        make_fake_chat_response()
    )

    client.get_genai_completion(
        prompt="User prompt",
        system_message="System msg",
        model="deployment",
        temperature=0.5,
    )

    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["model"] == "deployment"
    assert kwargs["messages"] == [
        {"role": "system", "content": "System msg"},
        {"role": "user", "content": "User prompt"},
    ]
    assert kwargs["temperature"] == 0.5


def test_system_message_NONE_is_omitted(client):
    client._openai_client.chat.completions.create.return_value = (
        make_fake_chat_response()
    )

    client.get_genai_completion(
        prompt="User prompt",
        system_message="NONE",
        model="deployment",
    )

    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["messages"] == [
        {"role": "user", "content": "User prompt"},
    ]


# ---------------------------
# Tests: request dict + kwargs override behavior
# ---------------------------


def test_accepts_request_dict_payload(client):
    client._openai_client.chat.completions.create.return_value = (
        make_fake_chat_response()
    )

    payload = {
        "model": "deployment",
        "messages": [{"role": "user", "content": "hi"}],
        "temperature": 0.9,
        "max_completion_tokens": 100,
    }

    client.get_genai_completion(request=payload)

    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["model"] == "deployment"
    assert kwargs["messages"] == [{"role": "user", "content": "hi"}]
    assert kwargs["temperature"] == 0.9
    assert kwargs["max_completion_tokens"] == 100


def test_kwargs_override_request(client):
    client._openai_client.chat.completions.create.return_value = (
        make_fake_chat_response()
    )

    req = {
        "model": "deployment",
        "messages": [{"role": "user", "content": "hi"}],
        "temperature": 0.1,
    }

    client.get_genai_completion(request=req, temperature=0.8)

    _, kwargs = client._openai_client.chat.completions.create.call_args
    assert kwargs["temperature"] == 0.8


# ---------------------------
# Tests: Daily cost guard
# ---------------------------


def test_daily_cost_limit_exceeded_returns_string_and_invalidates(client):
    client.log_manager = FakeLogManager(
        daily_cost=1000.0, daily_limit=1.0, enable_log=False
    )

    out = client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
    )

    assert out == "Daily cost limit exceeded."
    client._invalidate_connection.assert_called_once()

    # must not call OpenAI
    client._openai_client.chat.completions.create.assert_not_called()


# ---------------------------
# Tests: Logging behavior
# ---------------------------


def test_logging_calls_save_to_json_when_enabled(client):
    client.log_manager = FakeLogManager(
        daily_cost=0.0, daily_limit=999.0, enable_log=True
    )

    fake_res = make_fake_chat_response(
        content="Hello", prompt_tokens=3, completion_tokens=4
    )
    client._openai_client.chat.completions.create.return_value = fake_res

    client.get_genai_completion(
        model="deployment",
        messages=[{"role": "user", "content": "hi"}],
    )

    client.log_manager._save_to_json.assert_called_once()
    args, _kwargs = client.log_manager._save_to_json.call_args

    # (model, prompt_tokens, completion_tokens, prompt_to_log, completion_text, encrypt_key)
    assert args[0] == "deployment"
    assert args[1] == 3
    assert args[2] == 4
    assert json.loads(args[3]) == [{"role": "user", "content": "hi"}]
    assert args[4] == "Hello"
    assert args[5] == client.encrypt_key


def test_logging_uses_prompt_when_provided(client):
    client.log_manager = FakeLogManager(
        daily_cost=0.0, daily_limit=999.0, enable_log=True
    )

    fake_res = make_fake_chat_response(
        content="Done", prompt_tokens=1, completion_tokens=2
    )
    client._openai_client.chat.completions.create.return_value = fake_res

    client.get_genai_completion(
        prompt="my prompt",
        system_message="system",
        model="deployment",
    )

    args, _ = client.log_manager._save_to_json.call_args
    assert args[3] == "my prompt"
    assert args[4] == "Done"
