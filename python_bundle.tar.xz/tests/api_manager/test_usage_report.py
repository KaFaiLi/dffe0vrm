# tests/api_manager/test_usage_report.py
import io
import datetime
import contextlib
import re

import pytest
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization

# Adjust imports to your package structure
from genai_api_manager.genai_api_logger import GenaiAPILogger, AsyncLoggerConfig

# If you added the client wrapper method as discussed:
# from genai_api_manager.genai_api_client import GenAiApiClient


# ---------- helpers ----------


def make_public_key_pem() -> str:
    """Generate a valid EC public key PEM for the logger crypto constructor."""
    priv = ec.generate_private_key(ec.SECP256R1())
    pub = priv.public_key()
    pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return pem.decode("utf-8")


def make_logger(
    tmp_path, username="tester", daily_cost_limit=5.0, pricing_data=None
) -> GenaiAPILogger:
    """
    Create a logger configured for synchronous writes (no background thread),
    using a temporary directory and in-memory pricing data.
    """
    if pricing_data is None:
        pricing_data = {
            # prices are per 1k tokens
            "gpt-4o-2024-11-20": {"input": 0.010, "output": 0.020},
            "gpt-4o-mini-2024-07-18": {"input": 0.005, "output": 0.010},
        }

    logger = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=str(
            tmp_path / "prices.json"
        ),  # not read when pricing_data provided
        daily_cost_limit=daily_cost_limit,
        username=username,
        public_key=make_public_key_pem(),
        config=AsyncLoggerConfig(
            async_logging_enabled=False
        ),  # synchronous writes for deterministic tests
        pricing_data=pricing_data,
    )
    return logger


@pytest.fixture
def report_logger(tmp_path):
    loggers = []

    def create(**kwargs):
        logger = make_logger(tmp_path, **kwargs)
        loggers.append(logger)
        return logger

    try:
        yield create
    finally:
        for logger in loggers:
            logger.close()


def capture_stdout(fn, *args, **kwargs) -> str:
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        fn(*args, **kwargs)
    return buf.getvalue()


def today_str() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d")


# ---------- tests ----------


def test_print_report_empty_file(report_logger):
    """
    When no events are present (only header), the report should print zeros and N/A time range.
    """
    logger = report_logger()

    out = capture_stdout(logger.print_today_usage_report)

    # Header line includes today's date and username
    assert f"GenAI Usage Report — {today_str()} — user: tester" in out

    # Time range should be N/A
    assert "Time range: N/A" in out

    # Totals should be zero
    assert re.search(r"Calls\s*:\s*0", out)
    assert re.search(r"Input tokens\s*:\s*0", out)
    assert re.search(r"Output tokens\s*:\s*0", out)
    assert re.search(r"Input cost\s*:\s*0\.0000 €", out)
    assert re.search(r"Output cost\s*:\s*0\.0000 €", out)
    assert re.search(r"TOTAL cost\s*:\s*0\.0000 €", out)

    # Limits section present
    assert "LIMITS" in out
    assert "PER-MODEL BREAKDOWN" in out


def test_print_report_single_model_aggregation(report_logger):
    """
    Two calls on the same model should aggregate tokens and costs correctly.
    """
    logger = report_logger(
        pricing_data={"gpt-4o-2024-11-20": {"input": 0.010, "output": 0.020}}
    )

    # First event: 1000 in, 500 out
    logger._save_to_json("gpt-4o-2024-11-20", 1000, 500, "p1", "c1", encrypt_key="")
    # Second event: 1500 in, 250 out
    logger._save_to_json("gpt-4o-2024-11-20", 1500, 250, "p2", "c2", encrypt_key="")

    # Expected totals:
    # Input tokens: 2500; Output tokens: 750
    # Input cost: (1000*0.010/1000) + (1500*0.010/1000) = 0.010 + 0.015 = 0.025
    # Output cost: (500*0.020/1000) + (250*0.020/1000) = 0.010 + 0.005 = 0.015
    # Total cost: 0.040

    out = capture_stdout(logger.print_today_usage_report)

    assert re.search(r"Calls\s*:\s*2", out)
    assert re.search(r"Input tokens\s*:\s*2,?500", out)
    assert re.search(r"Output tokens\s*:\s*750", out)
    assert "Input cost    : 0.0250 €" in out
    assert "Output cost   : 0.0150 €" in out
    assert "TOTAL cost    : 0.0400 €" in out

    # LIMITS current usage should equal total cost (since writes were synchronous)
    assert "Current usage : 0.0400 €" in out


def test_print_report_per_model_sorting_and_table(report_logger):
    """
    Multi-model: ensure the per-model table exists, and rows are sorted by total cost desc.
    """
    logger = report_logger(
        pricing_data={
            "gpt-4o-2024-11-20": {"input": 0.010, "output": 0.020},
            "gpt-4o-mini-2024-07-18": {"input": 0.005, "output": 0.010},
        },
    )

    # Cost for 4o: 1000 in (0.010), 500 out (0.010) -> 0.020 total
    logger._save_to_json("gpt-4o-2024-11-20", 1000, 500, "p", "c", encrypt_key="")

    # Cost for 4o-mini: 4000 in (0.020), 4000 out (0.040) -> 0.060 total
    logger._save_to_json(
        "gpt-4o-mini-2024-07-18", 4000, 4000, "p2", "c2", encrypt_key=""
    )

    out = capture_stdout(logger.print_today_usage_report)

    # Table header present
    assert "PER-MODEL BREAKDOWN" in out
    assert "Model" in out and "Calls" in out and "InTok" in out and "OutTok" in out

    # Rows should be sorted by total cost descending => gpt-4o-mini first
    first_row_index = out.find("gpt-4o-mini-2024-07-18")
    second_row_index = out.find("gpt-4o-2024-11-20")
    assert first_row_index != -1 and second_row_index != -1
    assert first_row_index < second_row_index

    # Check totals reflect both
    # Total cost = 0.0600 + 0.0200 = 0.0800
    assert "TOTAL cost    : 0.0800 €" in out


def test_print_report_ignores_malformed_lines(report_logger):
    """
    If a malformed/partial JSON line exists (e.g., concurrent write), it should be ignored.
    """
    logger = report_logger(
        pricing_data={"gpt-4o-2024-11-20": {"input": 0.010, "output": 0.020}}
    )

    # Write a valid event
    logger._save_to_json("gpt-4o-2024-11-20", 1000, 1000, "p", "c", encrypt_key="")
    # Manually append a malformed line to today's file
    path = logger._get_daily_log_path()
    with open(path, "a", encoding="utf-8") as f:
        f.write("{ this is not valid json }\n")

    # Another valid event
    logger._save_to_json("gpt-4o-2024-11-20", 1000, 1000, "p2", "c2", encrypt_key="")

    # Each valid event costs: in=0.010, out=0.020 => 0.030 total; 2 events => 0.060 total
    out = capture_stdout(logger.print_today_usage_report)
    assert "TOTAL cost    : 0.0600 €" in out
    # And report should still render without raising


def test_client_wrapper_delegates_to_logger(report_logger, monkeypatch):
    """
    Ensure a client-level print_today_usage_report() delegates to the logger's method.
    We avoid constructing a full GenAiApiClient by crafting an instance without __init__.
    """
    # Create a logger and write a small event so output is non-trivial
    logger = report_logger(
        pricing_data={"gpt-4o-2024-11-20": {"input": 0.010, "output": 0.020}}
    )
    logger._save_to_json("gpt-4o-2024-11-20", 500, 500, "p", "c", encrypt_key="")

    # Minimal stand-in that mirrors your client wrapper behavior:
    class FakeClient:
        def __init__(self, log_manager):
            self.log_manager = log_manager

        def print_today_usage_report(self):
            self.log_manager.print_today_usage_report()

    client = FakeClient(logger)

    out = capture_stdout(client.print_today_usage_report)
    # Basic sanity check: it printed a header and totals > 0
    assert f"GenAI Usage Report — {today_str()} — user: tester" in out
    assert re.search(r"Calls\s*:\s*1", out)
