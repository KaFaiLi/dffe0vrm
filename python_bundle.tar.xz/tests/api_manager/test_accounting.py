from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal

import pytest

from genai_api_manager.accounting import (
    DailyBudget,
    PriceBook,
    Usage,
    UnpricedModelError,
)


@pytest.fixture
def prices():
    return PriceBook(
        {"priced": {"input": "1", "cached_input": "0.2", "output": "3"}},
        aliases={"deployment": "priced"},
    )


def test_cached_tokens_are_not_charged_twice(prices):
    charge = prices.quote("deployment", Usage(1000, 200, 600))
    assert charge.input_cost == Decimal("0.52")
    assert charge.output_cost == Decimal("0.6")
    assert charge.total == Decimal("1.12")
    assert charge.status == "exact"


@pytest.mark.parametrize("cache, expected", [(0, "1"), (1000, "0.2")])
def test_no_cache_and_all_cached(prices, cache, expected):
    assert prices.quote("priced", Usage(1000, 0, cache)).total == Decimal(expected)


@pytest.mark.parametrize(
    "read, write, expected",
    [(0, 1680, "0.21809"), (1680, 0, "0.02153"), (1000, 600, "0.09885")],
)
def test_cache_reads_writes_and_ordinary_input_are_disjoint(read, write, expected):
    prices = PriceBook(
        {
            "m": {
                "input": "0.1",
                "cached_input": "0.011",
                "cache_write": "0.128",
                "output": "0.55",
            }
        }
    )
    quote = prices.quote("m", Usage(1683, 5, read, write))
    assert quote.status == "exact"
    assert quote.total == Decimal(expected)


def test_missing_write_count_uses_conservative_estimate():
    prices = PriceBook(
        {
            "m": {
                "input": "1",
                "cached_input": "0.2",
                "cache_write": "1.25",
                "output": "3",
            }
        }
    )
    quote = prices.quote("m", Usage(1000, 200, 600))
    assert quote.total == Decimal("1.22")
    assert quote.status == "estimated_cache_write_unknown"


def test_reported_writes_without_a_price_are_unresolved(prices):
    quote = prices.quote("priced", Usage(1000, 200, 600, 300))
    assert quote.total is None
    assert quote.status == "cache_write_rate_missing"


@pytest.mark.parametrize("writes", [-1, True, 1.5, 401, 1001])
def test_invalid_or_overlapping_cache_writes_are_rejected(writes):
    with pytest.raises(ValueError):
        Usage(1000, 200, 600, writes)


def test_cache_write_usage_is_read_from_both_apis():
    for operation, payload in (
        (
            "responses",
            {
                "input_tokens": 1000,
                "output_tokens": 200,
                "input_tokens_details": {
                    "cached_tokens": 600,
                    "cache_write_tokens": 300,
                },
            },
        ),
        (
            "chat.completions",
            {
                "prompt_tokens": 1000,
                "completion_tokens": 200,
                "prompt_tokens_details": {
                    "cached_tokens": 600,
                    "cache_write_tokens": 300,
                },
            },
        ),
    ):
        assert Usage.from_sdk(payload, operation) == Usage(1000, 200, 600, 300)


def test_missing_cache_details_are_conservative_estimates(prices):
    charge = prices.quote("priced", Usage(1000, 0))
    assert charge.total == Decimal("1")
    assert charge.status == "estimated_cache_unknown"


def test_missing_cached_rate_is_explicit():
    charge = PriceBook({"m": {"input": 1, "output": 3}}).quote("m", Usage(1000, 0, 600))
    assert charge.total == Decimal("1")
    assert charge.status == "estimated_cached_rate_missing"


def test_missing_usage_and_unknown_model_are_not_free(prices):
    assert prices.quote("priced", Usage(None, None)).total is None
    with pytest.raises(UnpricedModelError, match="unknown"):
        prices.quote("unknown", Usage(1000, 200, 600))


def test_zero_rates_are_priced_but_an_empty_price_book_rejects_models():
    prices = PriceBook({"free": {"input": 0, "output": 0}})
    assert prices.quote("free", Usage(100, 20, 0)).total == 0
    with pytest.raises(UnpricedModelError):
        PriceBook({}).require_model("unknown")


@pytest.mark.parametrize("values", [(-1, 0, 0), (1, 0, 2), (1.5, 0, 0), (True, 0, 0)])
def test_invalid_usage_rejected(values):
    with pytest.raises(ValueError):
        Usage(*values)


@pytest.mark.parametrize(
    "metadata",
    [
        {},
        {"currency": "EUR", "rate_unit": 1000},
        {"currency": "EUR", "rate_unit": "1000"},
        {"rate_unit": "1000.0"},
    ],
)
def test_eur_per_thousand_and_decimal_precision(metadata):
    prices = PriceBook({"m": {"input": "0.1", "output": "0.2", **metadata}})
    charge = prices.quote("m", Usage(3, 7, 0))
    assert charge.total == Decimal("0.0017")


@pytest.mark.parametrize("currency", ["USD", "GBP", None])
def test_non_eur_prices_rejected(currency):
    with pytest.raises(ValueError, match="Prices must be in EUR"):
        PriceBook({"m": {"input": 1, "output": 3, "currency": currency}})


@pytest.mark.parametrize(
    "unit", [1_000_000, 1, 0, -1000, "NaN", "Infinity", None, True]
)
def test_non_thousand_token_units_rejected(unit):
    with pytest.raises(ValueError, match="Prices must be per 1,000 tokens"):
        PriceBook({"m": {"input": 1, "output": 3, "rate_unit": unit}})


@pytest.mark.parametrize("rate", ["NaN", "Infinity", "-1"])
def test_invalid_prices_rejected(rate):
    with pytest.raises(ValueError):
        PriceBook({"m": {"input": rate, "output": 0}})


def test_response_and_chat_usage_normalize_equally():
    response = {
        "input_tokens": 1000,
        "output_tokens": 200,
        "input_tokens_details": {"cached_tokens": 600},
        "output_tokens_details": {"reasoning_tokens": 100},
    }
    chat = {
        "prompt_tokens": 1000,
        "completion_tokens": 200,
        "prompt_tokens_details": {"cached_tokens": 600},
    }
    assert Usage.from_sdk(response, "responses") == Usage.from_sdk(
        chat, "chat.completions"
    )


def test_thread_safe_budget_accumulates_and_resets_by_day():
    budget = DailyBudget()
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(
            pool.map(
                lambda i: budget.record("today", Decimal("0.1")),
                range(1000),
            )
        )
    assert budget.snapshot("today") == Decimal("100.0")
    assert not budget.exceeded("today", 100)
    assert budget.exceeded("today", 99)
    assert not budget.exceeded("tomorrow", 10)
    assert budget.snapshot("tomorrow") == Decimal(0)
    assert not budget.exceeded("tomorrow", 0)
