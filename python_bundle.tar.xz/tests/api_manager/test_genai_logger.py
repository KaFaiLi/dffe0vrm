import os
import json
import time
import base64
import threading
import datetime
from pathlib import Path

import pytest

# ---- Adjust this import to your module path ----
from genai_api_manager.genai_api_logger import GenaiAPILogger, AsyncLoggerConfig
import genai_api_manager.config_loader as config_loader

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization


# ----------------------------
# Helpers / Fixtures
# ----------------------------


def make_public_key_pem() -> str:
    """Generate a valid EC public key PEM for GenaiAPILogger(public_key=...)."""
    priv = ec.generate_private_key(ec.SECP256R1())
    pub = priv.public_key()
    pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return pem.decode("utf-8")


def write_pricing_file(path: Path, data: dict) -> str:
    path.write_text(json.dumps(data), encoding="utf-8")
    return str(path)


def read_all_lines(p: Path):
    if not p.exists():
        return []
    return [ln.rstrip("\n") for ln in p.read_text(encoding="utf-8").splitlines()]


def parse_json_lines(p: Path):
    out = []
    for ln in read_all_lines(p):
        if not ln.strip():
            continue
        out.append(json.loads(ln))
    return out


def wait_until(predicate, timeout=5.0, interval=0.02):
    start = time.time()
    while time.time() - start < timeout:
        if predicate():
            return True
        time.sleep(interval)
    return False


@pytest.fixture
def public_key_pem():
    return make_public_key_pem()


@pytest.fixture
def pricing_valid(tmp_path):
    """Valid pricing file with one known model."""
    data = {
        "known-model": {"input": 1.0, "output": 2.0},  # per 1K tokens
        "other-model": {"input": 0.5, "output": 0.5},
    }
    return write_pricing_file(tmp_path / "pricing.json", data)


@pytest.fixture
def base_config():
    """Fast config for tests (small flush interval, small batch)."""
    return AsyncLoggerConfig(
        async_logging_enabled=True,
        queue_maxsize=2000,
        flush_interval_seconds=0.05,
        batch_size=20,
        overflow_block_timeout_seconds=5.0,
        enable_fsync=False,
        cross_process_lock_enabled=False,
        writer_retry_count=3,
        writer_retry_backoff_base_seconds=0.01,
        writer_retry_backoff_max_seconds=0.05,
        encrypt_in_writer=True,
    )


@pytest.fixture
def trust_pricing(tmp_path, monkeypatch):
    """
    The new config_loader.load_pricing() only accepts a path that matches
    config.json["pricing_file"] from the trusted DEFAULT_CONFIG_PATH.
    This fixture patches DEFAULT_CONFIG_PATH to a temp config.json and sets
    the trusted pricing_file for each test.
    """

    def _set_trusted_pricing(pricing_file: str) -> str:
        cfg_path = tmp_path / "config.json"
        cfg_path.write_text(
            json.dumps({"pricing_file": pricing_file}), encoding="utf-8"
        )

        monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
        config_loader.clear_config_cache()
        return str(cfg_path)

    return _set_trusted_pricing


@pytest.fixture
def logger(tmp_path, pricing_valid, public_key_pem, base_config, trust_pricing):
    # Make the test pricing file "trusted" by writing a temp config.json for it
    trust_pricing(pricing_valid)

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        daily_cost_limit=9999.0,
        username="tester",
        public_key=public_key_pem,
        config=base_config,
    )
    yield lg
    lg.close(timeout_seconds=2.0)


def get_today_log_path(lg: GenaiAPILogger) -> Path:
    return Path(lg._get_daily_log_path())


# ----------------------------
# T01 / T02 Pricing load
# ----------------------------


def test_T01_load_valid_pricing(
    pricing_valid, tmp_path, public_key_pem, base_config, trust_pricing
):
    trust_pricing(pricing_valid)

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=base_config,
    )
    try:
        assert isinstance(lg.prices_data, dict)
        assert "known-model" in lg.prices_data
    finally:
        lg.close(timeout_seconds=2.0)


def test_T02_load_invalid_pricing_missing(
    tmp_path, public_key_pem, base_config, trust_pricing
):
    missing = str(tmp_path / "does_not_exist.json")
    trust_pricing(missing)

    with pytest.raises(FileNotFoundError) as ex:
        GenaiAPILogger(
            log_directory=str(tmp_path),
            pricing_file=missing,
            username="tester",
            public_key=public_key_pem,
            config=base_config,
        )
    assert "pricing file not found" in str(ex.value).lower()


def test_T02_load_invalid_pricing_malformed(
    tmp_path, public_key_pem, base_config, trust_pricing
):
    bad = tmp_path / "bad.json"
    bad.write_text("{not-json", encoding="utf-8")

    trust_pricing(str(bad))

    with pytest.raises(json.JSONDecodeError) as ex:
        GenaiAPILogger(
            log_directory=str(tmp_path),
            pricing_file=str(bad),
            username="tester",
            public_key=public_key_pem,
            config=base_config,
        )
    assert "expecting property name" in str(ex.value).lower()


# ----------------------------
# T03 Unknown model safe
# ----------------------------


def test_T03_unknown_model_raises_without_charging_or_logging(logger):
    from genai_api_manager import UnpricedModelError

    p = get_today_log_path(logger)
    before_metrics = logger.get_metrics().copy()
    before_lines = read_all_lines(p)

    with pytest.raises(UnpricedModelError, match="unknown-model"):
        logger._save_to_json(
            model_name="unknown-model",
            prompt_token=100,
            output_token=200,
            prompt="hello",
            completion="world",
            encrypt_key="",
        )

    assert logger.get_metrics() == before_metrics
    assert read_all_lines(p) == before_lines


# ----------------------------
# T04 Encryption output format
# ----------------------------


def test_T04_encryption_output_format(logger):
    p = get_today_log_path(logger)

    prompt = "SENSITIVE_PROMPT_123"
    completion = "SENSITIVE_COMPLETION_456"

    logger._save_to_json(
        model_name="known-model",
        prompt_token=1000,
        output_token=1000,
        prompt=prompt,
        completion=completion,
        encrypt_key="",
    )

    assert wait_until(lambda: logger.get_metrics()["written_events"] >= 1, timeout=3.0)

    lines = parse_json_lines(p)
    event = lines[-1]  # header is first; our event is last

    assert "prompt" in event and "completion" in event
    assert event["prompt"] != prompt
    assert event["completion"] != completion

    decoded_prompt = base64.b64decode(event["prompt"].encode("utf-8"))
    decoded_completion = base64.b64decode(event["completion"].encode("utf-8"))
    assert isinstance(decoded_prompt, (bytes, bytearray)) and len(decoded_prompt) > 16
    assert (
        isinstance(decoded_completion, (bytes, bytearray))
        and len(decoded_completion) > 16
    )

    raw = Path(p).read_text(encoding="utf-8")
    assert prompt not in raw
    assert completion not in raw


def test_legacy_save_defaults_to_completed_with_unchanged_costs(logger):
    p = get_today_log_path(logger)
    daily_cost_before = logger.init_daily_cost()

    logger._save_to_json(
        "known-model", 1000, 500, "legacy prompt", "legacy completion", ""
    )

    assert wait_until(lambda: logger.get_metrics()["written_events"] >= 1, timeout=3.0)

    event = parse_json_lines(p)[-1]
    assert event["status"] == "completed"
    assert event["input_token"] == 1000
    assert event["output_token"] == 500
    assert event["input_cost"] == pytest.approx(1.0)
    assert event["output_cost"] == pytest.approx(1.0)
    assert event["total_cost"] == pytest.approx(2.0)
    assert logger.init_daily_cost() == pytest.approx(daily_cost_before + 2.0)


@pytest.mark.parametrize(
    ("status", "prompt_token", "output_token"),
    [
        ("partial", None, None),
        ("stream_error", None, 10),
        ("usage_missing", 10, None),
    ],
)
def test_async_audit_events_have_null_usage_and_do_not_change_cost(
    logger, status, prompt_token, output_token
):
    p = get_today_log_path(logger)
    daily_cost_before = logger.init_daily_cost()
    written_before = logger.get_metrics()["written_events"]
    prompt = f"sensitive prompt {status}"
    completion = f"sensitive completion {status}"

    logger._save_to_json(
        "known-model",
        prompt_token,
        output_token,
        prompt,
        completion,
        "",
        status=status,
    )

    assert wait_until(
        lambda: logger.get_metrics()["written_events"] >= written_before + 1,
        timeout=3.0,
    )

    event = parse_json_lines(p)[-1]
    assert event["status"] == status
    for field in (
        "input_token",
        "output_token",
        "input_cost",
        "output_cost",
        "total_cost",
    ):
        assert event[field] is None
    assert event["prompt"] != prompt
    assert event["completion"] != completion
    assert len(base64.b64decode(event["prompt"])) > 16
    assert len(base64.b64decode(event["completion"])) > 16
    assert event["cumulative_input_cost"] == pytest.approx(0.0)
    assert event["cumulative_output_cost"] == pytest.approx(0.0)
    assert event["cumulative_total_cost"] == pytest.approx(0.0)
    assert logger.init_daily_cost() == pytest.approx(daily_cost_before)


def test_sync_mixed_events_keep_cumulative_costs_numeric_and_monotonic(
    tmp_path, public_key_pem
):
    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=str(tmp_path / "unused.json"),
        username="tester",
        public_key=public_key_pem,
        config=AsyncLoggerConfig(async_logging_enabled=False),
        pricing_data={"known-model": {"input": 1.0, "output": 2.0}},
    )
    try:
        lg._save_to_json("known-model", 1000, 500, "p1", "c1", "")
        lg._save_to_json("known-model", None, None, "p2", "c2", "", status="partial")
        lg._save_to_json("known-model", 500, 250, "p3", "c3", "")

        events = parse_json_lines(Path(lg._get_daily_log_path()))[1:]
        assert [event["status"] for event in events] == [
            "completed",
            "partial",
            "completed",
        ]
        assert events[1]["total_cost"] is None

        cumulative_totals = [event["cumulative_total_cost"] for event in events]
        assert cumulative_totals == pytest.approx([2.0, 2.0, 3.0])
        assert all(isinstance(total, (int, float)) for total in cumulative_totals)
        assert cumulative_totals == sorted(cumulative_totals)
        assert lg.init_daily_cost() == pytest.approx(3.0)
    finally:
        lg.close()


# ----------------------------
# T05/T06 Header exactly once
# ----------------------------


def test_T05_new_file_header_once(
    tmp_path, pricing_valid, public_key_pem, base_config, trust_pricing
):
    trust_pricing(pricing_valid)

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=base_config,
    )
    try:
        p = Path(lg._get_daily_log_path())
        lg._save_to_json("known-model", 100, 100, "p", "c", "")

        assert wait_until(lambda: lg.get_metrics()["written_events"] >= 1, timeout=3.0)

        lines = read_all_lines(p)
        assert len(lines) >= 2  # header + at least 1 event
        header = json.loads(lines[0])
        assert header["cumulative_total_cost"] == 0.0
        assert (
            sum(
                1
                for ln in lines
                if '"cumulative_total_cost"' in ln and '"model_name"' not in ln
            )
            == 1
        )
    finally:
        lg.close(timeout_seconds=2.0)


def test_T06_append_does_not_duplicate_header(
    tmp_path, pricing_valid, public_key_pem, base_config, trust_pricing
):
    trust_pricing(pricing_valid)

    lg1 = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=base_config,
    )
    p = Path(lg1._get_daily_log_path())
    try:
        lg1._save_to_json("known-model", 100, 100, "p1", "c1", "")
        assert wait_until(lambda: lg1.get_metrics()["written_events"] >= 1, timeout=3.0)
    finally:
        lg1.close(timeout_seconds=2.0)

    # re-init
    trust_pricing(pricing_valid)
    lg2 = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=base_config,
    )
    try:
        lg2._save_to_json("known-model", 100, 100, "p2", "c2", "")
        assert wait_until(lambda: lg2.get_metrics()["written_events"] >= 1, timeout=3.0)
    finally:
        lg2.close(timeout_seconds=2.0)

    lines = read_all_lines(p)
    assert json.loads(lines[0])["cumulative_total_cost"] == 0.0
    headers = [
        json.loads(ln) for ln in lines if '"model_name"' not in ln and ln.strip()
    ]
    assert len(headers) == 1


# ----------------------------
# T07 Single-thread end-to-end JSONL validity
# ----------------------------


def test_T07_single_thread_end_to_end(logger):
    p = get_today_log_path(logger)

    for i in range(10):
        logger._save_to_json("known-model", 100 + i, 200 + i, f"p{i}", f"c{i}", "")

    assert wait_until(lambda: logger.get_metrics()["written_events"] >= 10, timeout=4.0)

    lines = parse_json_lines(p)
    assert len(lines) == 1 + 10  # header + 10 events
    assert all(isinstance(obj, dict) for obj in lines)
    m = logger.get_metrics()
    assert m["written_events"] == 10
    assert m["dropped_events"] == 0


# ----------------------------
# T08 Multi-thread correctness
# ----------------------------


def test_T08_multi_thread_correctness(logger):
    p = get_today_log_path(logger)

    threads = []
    sent = 20 * 50

    def producer(tid):
        for j in range(50):
            logger._save_to_json(
                "known-model",
                10 + j,
                20 + j,
                f"prompt-{tid}-{j}",
                f"completion-{tid}-{j}",
                "",
            )

    for t in range(20):
        th = threading.Thread(target=producer, args=(t,))
        threads.append(th)
        th.start()

    for th in threads:
        th.join()

    assert wait_until(
        lambda: logger.get_metrics()["written_events"] >= sent, timeout=8.0
    )

    lines = parse_json_lines(p)
    assert len(lines) == 1 + sent
    assert logger.get_metrics()["enqueue_errors"] == 0
    assert (
        logger.get_metrics()["written_events"] + logger.get_metrics()["dropped_events"]
        == sent
    )


# ----------------------------
# T09 Queue saturation behavior
# ----------------------------


def test_T09_queue_saturation_triggers_overflow(
    tmp_path, pricing_valid, public_key_pem, trust_pricing
):
    trust_pricing(pricing_valid)

    cfg = AsyncLoggerConfig(
        async_logging_enabled=True,
        queue_maxsize=10,
        flush_interval_seconds=0.2,
        batch_size=1000,
        overflow_block_timeout_seconds=0.05,
        writer_retry_count=0,
        writer_retry_backoff_base_seconds=0.01,
        writer_retry_backoff_max_seconds=0.01,
        encrypt_in_writer=True,
    )

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=cfg,
    )
    try:
        for i in range(200):
            lg._save_to_json("known-model", 1, 1, f"p{i}", f"c{i}", "")
        time.sleep(0.5)
        m = lg.get_metrics()
        assert m["queue_size"] <= cfg.queue_maxsize
        assert m["written_events"] + m["dropped_events"] <= 200
        assert m["dropped_events"] >= 0
    finally:
        lg.close(timeout_seconds=2.0)


# ----------------------------
# T10 Slow writer -> producer blocks ~timeout
# ----------------------------


def test_T10_slow_writer_blocks_about_timeout(
    tmp_path, pricing_valid, public_key_pem, trust_pricing
):
    trust_pricing(pricing_valid)

    class NoWriterLogger(GenaiAPILogger):
        def _start_writer_thread(self) -> None:
            return

    cfg = AsyncLoggerConfig(
        async_logging_enabled=True,
        queue_maxsize=10,
        flush_interval_seconds=0.05,
        batch_size=5,
        overflow_block_timeout_seconds=0.3,
        writer_retry_count=0,
        writer_retry_backoff_base_seconds=0.01,
        writer_retry_backoff_max_seconds=0.01,
        encrypt_in_writer=True,
    )

    lg = NoWriterLogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=cfg,
    )

    try:
        for i in range(cfg.queue_maxsize):
            lg._save_to_json("known-model", 1, 1, f"p{i}", f"c{i}", "")

        dropped_before = lg.get_metrics()["dropped_events"]

        t0 = time.time()
        lg._save_to_json("known-model", 1, 1, "pX", "cX", "")
        elapsed = time.time() - t0

        assert elapsed >= cfg.overflow_block_timeout_seconds * 0.75
        assert elapsed <= cfg.overflow_block_timeout_seconds + 0.35

        dropped_after = lg.get_metrics()["dropped_events"]
        assert dropped_after == dropped_before + 1

    finally:
        lg.close(timeout_seconds=1.0)


# ----------------------------
# T11 Slow writer recovery drains queue
# ----------------------------


def test_T11_slow_writer_recovery(
    tmp_path, pricing_valid, public_key_pem, trust_pricing
):
    trust_pricing(pricing_valid)

    cfg = AsyncLoggerConfig(
        async_logging_enabled=True,
        queue_maxsize=200,
        flush_interval_seconds=0.05,
        batch_size=20,
        overflow_block_timeout_seconds=0.2,
        writer_retry_count=3,
        writer_retry_backoff_base_seconds=0.01,
        writer_retry_backoff_max_seconds=0.05,
        encrypt_in_writer=True,
    )

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=cfg,
    )

    original_flush = lg._flush_batch
    state = {"first": True}

    def stall_once(batch):
        if state["first"]:
            state["first"] = False
            time.sleep(0.6)
        return original_flush(batch)

    lg._flush_batch = stall_once

    try:
        sent = 150
        for i in range(sent):
            lg._save_to_json("known-model", 2, 2, f"p{i}", f"c{i}", "")

        assert wait_until(
            lambda: lg.get_metrics()["written_events"] >= sent, timeout=8.0
        )
        assert lg.get_metrics()["enqueue_errors"] == 0
    finally:
        lg._flush_batch = original_flush
        lg.close(timeout_seconds=2.0)


# ----------------------------
# T12 close() drains best effort
# ----------------------------


def test_T12_close_drains_best_effort(
    tmp_path, pricing_valid, public_key_pem, base_config, trust_pricing
):
    trust_pricing(pricing_valid)

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=base_config,
    )
    for i in range(200):
        lg._save_to_json("known-model", 3, 3, f"p{i}", f"c{i}", "")

    lg.close(timeout_seconds=2.0)
    assert lg._writer_thread is None or not lg._writer_thread.is_alive()
    assert lg.get_metrics()["queue_size"] == 0


# ----------------------------
# T13 Daily rotation (simulated by subclassing)
# ----------------------------


class RotatingTestLogger(GenaiAPILogger):
    def __init__(self, *args, **kwargs):
        self._fake_now = datetime.datetime(2026, 1, 1, 12, 0, 0)
        super().__init__(*args, **kwargs)

    def set_now(self, dt: datetime.datetime):
        self._fake_now = dt

    def _get_daily_log_dir(self, now=None) -> str:
        now = self._fake_now
        today_str = now.strftime("%d_%m_%y")
        return os.path.join(self._root_log_directory, f"log_{today_str}")

    def _get_daily_log_path(self, now=None) -> str:
        now = self._fake_now
        today = now.strftime("%Y-%m-%d")
        daily_dir = self._get_daily_log_dir(now)
        return os.path.join(
            daily_dir, f"api_token_usage_log_{self.username}_{today}.json"
        )

    def _ensure_daily_dir_exists(self, now=None) -> str:
        daily_dir = self._get_daily_log_dir()
        os.makedirs(daily_dir, exist_ok=True)
        return daily_dir


def test_T13_daily_rotation(tmp_path, pricing_valid, public_key_pem, trust_pricing):
    trust_pricing(pricing_valid)

    cfg = AsyncLoggerConfig(
        async_logging_enabled=True,
        queue_maxsize=1000,
        flush_interval_seconds=0.05,
        batch_size=5,
        overflow_block_timeout_seconds=0.2,
        writer_retry_count=2,
        writer_retry_backoff_base_seconds=0.01,
        writer_retry_backoff_max_seconds=0.05,
        encrypt_in_writer=True,
    )

    lg = RotatingTestLogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=cfg,
    )
    try:
        lg.set_now(datetime.datetime(2026, 1, 1, 12, 0, 0))
        p1 = Path(lg._get_daily_log_path())
        lg._save_to_json("known-model", 10, 10, "p1", "c1", "")
        assert wait_until(lambda: lg.get_metrics()["written_events"] >= 1, timeout=3.0)

        lg.set_now(datetime.datetime(2026, 1, 2, 12, 0, 0))
        p2 = Path(lg._get_daily_log_path())
        lg._save_to_json("known-model", 10, 10, "p2", "c2", "")
        assert wait_until(lambda: lg.get_metrics()["written_events"] >= 2, timeout=3.0)

        assert p1.exists() and p2.exists() and p1 != p2
        assert len(parse_json_lines(p1)) >= 2
        assert len(parse_json_lines(p2)) >= 2
        assert "model_name" not in parse_json_lines(p1)[0]
        assert "model_name" not in parse_json_lines(p2)[0]
    finally:
        lg.close(timeout_seconds=2.0)


# ----------------------------
# T14 JSONL validity sweep
# ----------------------------


def test_T14_jsonl_validity_sweep(logger):
    p = get_today_log_path(logger)
    for i in range(30):
        logger._save_to_json("known-model", 10, 20, f"p{i}", f"c{i}", "")

    assert wait_until(lambda: logger.get_metrics()["written_events"] >= 30, timeout=4.0)

    for ln in read_all_lines(p):
        if not ln.strip():
            continue
        obj = json.loads(ln)
        assert isinstance(obj, dict)


# ----------------------------
# T15 cumulative monotonicity
# ----------------------------


def test_T15_cumulative_monotonicity(logger):
    p = get_today_log_path(logger)
    for i in range(5):
        logger._save_to_json("known-model", 100, 200, f"p{i}", f"c{i}", "")

    assert wait_until(lambda: logger.get_metrics()["written_events"] >= 5, timeout=4.0)

    objs = parse_json_lines(p)
    header = objs[0]
    assert header["cumulative_total_cost"] == 0.0

    prev_total = 0.0
    for ev in objs[1:]:
        assert ev["cumulative_total_cost"] >= prev_total
        expected = prev_total + ev["total_cost"]
        assert abs(ev["cumulative_total_cost"] - expected) < 1e-9
        prev_total = ev["cumulative_total_cost"]


# ----------------------------
# T16 transient write error retry
# ----------------------------


def test_T16_transient_write_error_retry(
    tmp_path, pricing_valid, public_key_pem, trust_pricing
):
    trust_pricing(pricing_valid)

    cfg = AsyncLoggerConfig(
        async_logging_enabled=True,
        queue_maxsize=1000,
        flush_interval_seconds=0.05,
        batch_size=5,
        overflow_block_timeout_seconds=0.2,
        writer_retry_count=3,
        writer_retry_backoff_base_seconds=0.01,
        writer_retry_backoff_max_seconds=0.05,
        encrypt_in_writer=True,
    )

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=cfg,
    )

    original_flush = lg._flush_batch
    state = {"fails_left": 2}

    def fail_then_succeed(batch):
        if state["fails_left"] > 0:
            state["fails_left"] -= 1
            raise OSError("simulated transient failure")
        return original_flush(batch)

    lg._flush_batch = fail_then_succeed

    try:
        for i in range(10):
            lg._save_to_json("known-model", 10, 10, f"p{i}", f"c{i}", "")

        assert wait_until(lambda: lg.get_metrics()["written_events"] >= 10, timeout=6.0)
        m = lg.get_metrics()
        assert m["write_errors"] > 0

        p = Path(lg._get_daily_log_path())
        objs = parse_json_lines(p)
        assert len(objs) == 11  # header + 10 events
    finally:
        lg._flush_batch = original_flush
        lg.close(timeout_seconds=2.0)


# ----------------------------
# T17 permanent write failure -> drop after retries
# ----------------------------


def test_T17_permanent_write_failure_drop(
    tmp_path, pricing_valid, public_key_pem, trust_pricing
):
    trust_pricing(pricing_valid)

    cfg = AsyncLoggerConfig(
        async_logging_enabled=True,
        queue_maxsize=1000,
        flush_interval_seconds=0.05,
        batch_size=5,
        overflow_block_timeout_seconds=0.2,
        writer_retry_count=2,
        writer_retry_backoff_base_seconds=0.01,
        writer_retry_backoff_max_seconds=0.02,
        encrypt_in_writer=True,
    )

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=cfg,
    )

    def always_fail(batch):
        raise OSError("simulated permanent failure")

    lg._flush_batch = always_fail

    try:
        for i in range(10):
            lg._save_to_json("known-model", 10, 10, f"p{i}", f"c{i}", "")

        assert wait_until(lambda: lg.get_metrics()["dropped_events"] >= 10, timeout=4.0)
        m = lg.get_metrics()
        assert m["write_errors"] > 0

        p = Path(lg._get_daily_log_path())
        objs = parse_json_lines(p)
        assert len(objs) == 1  # header only
    finally:
        lg.close(timeout_seconds=2.0)


# ----------------------------
# T18 writer failure should not crash API path (post-init)
# ----------------------------


def test_T18_dir_or_rotation_failure_does_not_crash_save(
    tmp_path, pricing_valid, public_key_pem, base_config, trust_pricing
):
    trust_pricing(pricing_valid)

    lg = GenaiAPILogger(
        log_directory=str(tmp_path),
        pricing_file=pricing_valid,
        username="tester",
        public_key=public_key_pem,
        config=base_config,
    )

    def fail_rotate():
        raise OSError("simulated rotate/dir failure")

    lg._writer_rotate_if_needed = fail_rotate

    try:
        for i in range(5):
            lg._save_to_json("known-model", 10, 10, f"p{i}", f"c{i}", "")

        assert wait_until(lambda: lg.get_metrics()["write_errors"] > 0, timeout=3.0)
        assert lg.get_metrics()["enqueue_errors"] == 0
    finally:
        lg.close(timeout_seconds=2.0)
