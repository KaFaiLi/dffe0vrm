"""Whole-request context tiers with synthetic EUR rates per 1,000 tokens."""

from copy import deepcopy
from decimal import Decimal

import pytest

from genai_api_manager.accounting import PriceBook, Usage


PRICING = {
    "priced": {
        "input": "1",
        "cached_input": "0.2",
        "cache_write": "1.25",
        "output": "3",
        "long_context": {
            "input_tokens_above": 272000,
            "input": "2",
            "cached_input": "0.4",
            "cache_write": "2.5",
            "output": "4.5",
        },
    }
}


@pytest.mark.parametrize("model", ["priced", "deployment"])
@pytest.mark.parametrize(
    "inputs,expected_input,expected_output",
    [
        (271999, "116.999", "3"),
        (272000, "117", "3"),
        (272001, "234.002", "4.5"),
        (300000, "290", "4.5"),
    ],
)
def test_threshold_applies_selected_rates_to_every_token(
    model, inputs, expected_input, expected_output
):
    prices = PriceBook(PRICING, aliases={"deployment": "priced"})
    charge = prices.quote(model, Usage(inputs, 1000, 200000, 20000))
    assert charge.input_cost == Decimal(expected_input)
    assert charge.output_cost == Decimal(expected_output)
    assert charge.total == Decimal(expected_input) + Decimal(expected_output)
    assert charge.status == "exact"


def test_output_does_not_determine_context_tier():
    charge = PriceBook(PRICING).quote("priced", Usage(270000, 100000, 0, 0))
    assert charge.input_cost == Decimal("270")
    assert charge.output_cost == Decimal("300")


@pytest.mark.parametrize("cached,writes", [(300000, 0), (0, 300000)])
def test_entirely_cached_input_still_selects_long_context(cached, writes):
    charge = PriceBook(PRICING).quote("priced", Usage(300000, 1000, cached, writes))
    assert charge.input_cost == Decimal("120" if cached else "750")
    assert charge.output_cost == Decimal("4.5")


@pytest.mark.parametrize(
    "usage,expected,status",
    [
        (Usage(300000, 1000, 200000), "334.5", "estimated_cache_write_unknown"),
        (Usage(300000, 1000, None, 20000), "614.5", "estimated_cache_unknown"),
        (Usage(300000, 1000), "754.5", "estimated_cache_unknown"),
    ],
)
def test_missing_cache_counts_use_selected_tier_estimates(usage, expected, status):
    charge = PriceBook(PRICING).quote("priced", usage)
    assert charge.total == Decimal(expected)
    assert charge.status == status


def test_missing_long_cached_rate_uses_long_input_rate():
    pricing = deepcopy(PRICING)
    del pricing["priced"]["long_context"]["cached_input"]
    charge = PriceBook(pricing).quote("priced", Usage(300000, 1000, 200000, 0))
    assert charge.total == Decimal("604.5")
    assert charge.status == "estimated_cached_rate_missing"


def test_missing_long_write_rate_does_not_inherit_short_write_rate():
    pricing = deepcopy(PRICING)
    del pricing["priced"]["long_context"]["cache_write"]
    prices = PriceBook(pricing)
    charge = prices.quote("priced", Usage(300000, 1000, 200000, 20000))
    assert charge.total is None
    assert charge.status == "cache_write_rate_missing"
    legacy = prices.quote("priced", Usage(300000, 1000, 200000))
    assert legacy.total == Decimal("284.5")
    assert legacy.status == "exact"


def test_zero_long_rates_are_valid():
    pricing = deepcopy(PRICING)
    for name in ("input", "cached_input", "cache_write", "output"):
        pricing["priced"]["long_context"][name] = "0"
    charge = PriceBook(pricing).quote("priced", Usage(300000, 1000, 200000, 20000))
    assert charge.total == 0
    assert charge.status == "exact"


def test_flat_entries_keep_standard_rates_for_large_inputs():
    pricing = deepcopy(PRICING)
    del pricing["priced"]["long_context"]
    charge = PriceBook(pricing).quote("priced", Usage(300000, 1000, 200000, 20000))
    assert charge.total == Decimal("148")


def test_threshold_is_configured_per_model():
    pricing = deepcopy(PRICING)
    pricing["priced"]["long_context"]["input_tokens_above"] = 5000
    assert PriceBook(pricing).quote("priced", Usage(5001, 0, 0, 0)).total == Decimal(
        "10.002"
    )


@pytest.mark.parametrize(
    "usage", [Usage(None, None), Usage(None, 1000), Usage(300000, None)]
)
def test_missing_usage_stays_unknown(usage):
    charge = PriceBook(PRICING).quote("priced", usage)
    assert charge.total is None
    assert charge.status == "usage_missing"


@pytest.mark.parametrize("context", [None, [], "long", {}])
def test_malformed_long_entry_is_rejected_at_load(context):
    pricing = deepcopy(PRICING)
    pricing["priced"]["long_context"] = context
    with pytest.raises(ValueError):
        PriceBook(pricing)


@pytest.mark.parametrize("threshold", [None, True, False, 0, -1, 272000.0, "272000"])
def test_invalid_context_threshold_is_rejected_at_load(threshold):
    pricing = deepcopy(PRICING)
    pricing["priced"]["long_context"]["input_tokens_above"] = threshold
    with pytest.raises(ValueError, match="input_tokens_above"):
        PriceBook(pricing)


@pytest.mark.parametrize("name", ["input", "cached_input", "cache_write", "output"])
@pytest.mark.parametrize("rate", ["NaN", "Infinity", "-1", None, True, "invalid"])
def test_invalid_long_rates_are_rejected_at_load(name, rate):
    pricing = deepcopy(PRICING)
    pricing["priced"]["long_context"][name] = rate
    with pytest.raises(ValueError):
        PriceBook(pricing)


@pytest.mark.parametrize("name", ["input", "output"])
def test_long_entry_requires_its_own_input_and_output_rates(name):
    pricing = deepcopy(PRICING)
    del pricing["priced"]["long_context"][name]
    with pytest.raises(ValueError, match="input/output"):
        PriceBook(pricing)


@pytest.mark.parametrize(
    "metadata,message",
    [
        ({"currency": "USD"}, "Prices must be in EUR"),
        ({"rate_unit": 1000000}, "Prices must be per 1,000 tokens"),
        ({"cache_writes": "2.5"}, "Unknown long_context pricing field"),
        ({"long_context": {}}, "Unknown long_context pricing field"),
    ],
)
def test_long_entry_rejects_wrong_units_and_unknown_fields(metadata, message):
    pricing = deepcopy(PRICING)
    pricing["priced"]["long_context"].update(metadata)
    with pytest.raises(ValueError, match=message):
        PriceBook(pricing)


def test_long_entry_accepts_compatible_currency_and_rate_metadata():
    pricing = deepcopy(PRICING)
    pricing["priced"]["long_context"].update(currency="EUR", rate_unit="1000.0")
    assert PriceBook(pricing).quote("priced", Usage(300000, 0, 0, 0)).total == 600
