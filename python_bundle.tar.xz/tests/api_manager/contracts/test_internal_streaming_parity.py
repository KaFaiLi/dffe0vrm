"""Complete SDK result parity for equivalent synthetic Azure JSON and SSE replies.

Uses one default-configured production client for both omitted stream (internal)
and explicit stream=False (native). This is offline compatibility evidence only.
"""

from copy import deepcopy
import json

import httpx2
import pytest
from openai.types.chat import ChatCompletion
from openai.types.responses import Response
from pydantic import BaseModel

from tests.support.azure import (
    WireStream,
    chat_payload,
    choice,
    chunk,
    response_payload,
    text_events,
    tool,
    wire_response,
)
from tests.support.client import audit_events


PRICES = {
    "deployment": {
        "input": "1",
        "cached_input": "0.2",
        "cache_write": "1.25",
        "output": "3",
    }
}


def assert_same_sdk_object(actual, expected):
    """Compare every serialized field and every nested SDK model's exact type."""
    assert type(actual) is type(expected)
    assert actual.model_dump() == expected.model_dump()
    assert actual.model_dump(mode="json") == expected.model_dump(mode="json")
    assert actual.model_dump(exclude_unset=True) == expected.model_dump(
        exclude_unset=True
    )
    assert actual.to_dict() == expected.to_dict()
    assert json.loads(actual.to_json()) == json.loads(expected.to_json())
    assert actual._request_id == expected._request_id == "request-synthetic"
    assert_same_nested_types(actual, expected)


def assert_same_nested_types(actual, expected):
    assert type(actual) is type(expected)
    if isinstance(expected, BaseModel):
        assert actual.model_fields_set == expected.model_fields_set
        for name in type(expected).model_fields:
            assert_same_nested_types(getattr(actual, name), getattr(expected, name))
        assert_same_nested_types(actual.model_extra, expected.model_extra)
    elif isinstance(expected, dict):
        assert actual.keys() == expected.keys()
        for name in expected:
            assert_same_nested_types(actual[name], expected[name])
    elif isinstance(expected, list):
        assert len(actual) == len(expected)
        for item, native_item in zip(actual, expected, strict=True):
            assert_same_nested_types(item, native_item)
    else:
        assert actual == expected


def chat_case(case):
    native = chat_payload()
    native["system_fingerprint"] = "fp-synthetic"
    native["service_tier"] = "default"
    native["vendor"] = {"flag": True, "nested": {"optional": None}}
    native["usage"]["prompt_tokens_details"]["cache_write_tokens"] = 300
    native["usage"]["completion_tokens_details"] = {"reasoning_tokens": 17}
    metadata = {
        key: native[key] for key in ("system_fingerprint", "service_tier", "vendor")
    }
    if case in ("text", "json", "empty", "missing_usage"):
        text = {
            "text": "Hello 🌍",
            "json": '{"answer":"Hello"}',
            "empty": "",
            "missing_usage": "Hello",
        }[case]
        native["choices"][0]["message"]["content"] = text
        events = [
            chunk([choice({"role": "assistant", "content": text[:3]})], **metadata),
            chunk([choice({"content": text[3:]})]),
            chunk([choice({}, finish="stop")]),
        ]
    elif case == "refusal":
        native["choices"][0]["message"] = {
            "role": "assistant",
            "content": None,
            "refusal": "No thanks",
        }
        events = [
            chunk(
                [choice({"role": "assistant", "content": None, "refusal": "No"})],
                **metadata,
            ),
            chunk([choice({"refusal": " thanks"}, finish="stop")]),
        ]
    elif case == "tools":
        native["choices"][0].update(
            finish_reason="tool_calls",
            message={
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call-lookup",
                        "type": "function",
                        "function": {"name": "lookup", "arguments": '{"id":7}'},
                    },
                    {
                        "id": "call-weather",
                        "type": "function",
                        "function": {
                            "name": "weather",
                            "arguments": '{"city":"Paris"}',
                        },
                    },
                ],
            },
        )
        events = [
            chunk(
                [
                    choice(
                        {
                            "role": "assistant",
                            "content": None,
                            "tool_calls": [
                                tool(
                                    1,
                                    id="call-weather",
                                    name="wea",
                                    arguments='{"city":',
                                ),
                                tool(
                                    0, id="call-lookup", name="loo", arguments='{"id":'
                                ),
                            ],
                        }
                    )
                ],
                **metadata,
            ),
            chunk(
                [
                    choice(
                        {
                            "tool_calls": [
                                tool(0, name="kup", arguments="7}"),
                                tool(1, name="ther", arguments='"Paris"}'),
                            ]
                        },
                        finish="tool_calls",
                    )
                ]
            ),
        ]
    elif case == "legacy_function":
        native["choices"][0].update(
            finish_reason="function_call",
            message={
                "role": "assistant",
                "content": None,
                "function_call": {"name": "lookup", "arguments": '{"id":7}'},
            },
        )
        events = [
            chunk(
                [
                    choice(
                        {
                            "role": "assistant",
                            "content": None,
                            "function_call": {"name": "loo", "arguments": '{"id":'},
                        }
                    )
                ],
                **metadata,
            ),
            chunk(
                [
                    choice(
                        {"function_call": {"name": "kup", "arguments": "7}"}},
                        finish="function_call",
                    )
                ]
            ),
        ]
    elif case == "multiple_choices":
        native["choices"] = [
            {
                "index": 0,
                "finish_reason": "stop",
                "message": {"role": "assistant", "content": "First"},
            },
            {
                "index": 1,
                "finish_reason": "length",
                "message": {"role": "assistant", "content": "Second"},
            },
        ]
        events = [
            chunk(
                [
                    choice({"role": "assistant", "content": "Sec"}, index=1),
                    choice({"role": "assistant", "content": "Fi"}),
                ],
                **metadata,
            ),
            chunk(
                [
                    choice({"content": "rst"}, finish="stop"),
                    choice({"content": "ond"}, index=1, finish="length"),
                ]
            ),
        ]
    elif case == "logprobs":
        logs = [
            {
                "token": "He",
                "bytes": [72, 101],
                "logprob": -0.1,
                "top_logprobs": [{"token": "Hi", "bytes": [72, 105], "logprob": -0.2}],
            },
            {
                "token": "llo",
                "bytes": [108, 108, 111],
                "logprob": -0.3,
                "top_logprobs": [],
            },
        ]
        native["choices"][0]["logprobs"] = {"content": logs, "refusal": None}
        events = [
            chunk(
                [
                    choice(
                        {"role": "assistant", "content": "He"},
                        logprobs={"content": logs[:1], "refusal": None},
                    )
                ],
                **metadata,
            ),
            chunk(
                [
                    choice(
                        {"content": "llo"},
                        finish="stop",
                        logprobs={"content": logs[1:], "refusal": None},
                    )
                ]
            ),
        ]
    else:
        raise AssertionError(f"Unknown fixture case: {case}")
    if case == "missing_usage":
        del native["usage"]
    else:
        events.append(chunk([], usage=deepcopy(native["usage"])))
    return native, events


@pytest.mark.parametrize(
    "case",
    [
        "text",
        "json",
        "empty",
        "refusal",
        "tools",
        "legacy_function",
        "multiple_choices",
        "logprobs",
        "missing_usage",
    ],
)
def test_internal_chat_entire_object_matches_explicit_non_stream(make_client, case):
    native_payload, events = chat_case(case)
    before = deepcopy((native_payload, events))
    source = WireStream(events)
    requests = []

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        assert request.url.path == "/openai/v1/chat/completions"
        if body["stream"]:
            assert body["stream_options"]["include_usage"] is True
            return wire_response(source)
        assert body["stream"] is False
        return httpx2.Response(
            200, json=native_payload, headers={"x-request-id": "request-synthetic"}
        )

    client = make_client(handle, internal_streaming=..., pricing_data=PRICES)
    options = {
        "model": "deployment",
        "prompt": "Synthetic parity check.",
        "n": len(native_payload["choices"]),
    }
    if case == "json":
        options["response_format"] = {"type": "json_object"}
    internal = client.get_genai_completion(**options)
    native = client.get_genai_completion(**options, stream=False)

    assert type(internal) is ChatCompletion
    assert_same_sdk_object(internal, native)
    assert (native_payload, events) == before
    assert [request["stream"] for request in requests] == [True, False]
    assert source.closed and source.reads == len(events)
    audit = audit_events(client)
    assert len(audit) == 2
    assert (
        audit[0]["total_cost"]
        == audit[1]["total_cost"]
        == (None if case == "missing_usage" else 1.195)
    )


@pytest.mark.parametrize("status", ["completed", "incomplete", "failed"])
@pytest.mark.parametrize("usage_present", [True, False], ids=["usage", "null_usage"])
def test_internal_response_entire_object_matches_explicit_non_stream(
    make_client, status, usage_present
):
    payload = response_payload(status)
    payload.update(
        metadata={"synthetic": "parity"},
        service_tier="default",
        vendor={"flag": True, "optional": None},
    )
    if status == "failed":
        payload["error"] = {"code": "server_error", "message": "Synthetic failure."}
    if usage_present:
        payload["usage"]["input_tokens_details"]["cache_write_tokens"] = 300
    else:
        payload["usage"] = None
    payload["output"][0]["content"][0]["annotations"] = [
        {
            "type": "url_citation",
            "start_index": 0,
            "end_index": 5,
            "url": "https://example.invalid/source",
            "title": "Synthetic",
        }
    ]
    payload["output"][0]["content"].append(
        {"type": "refusal", "refusal": "Synthetic refusal"}
    )
    payload["output"].extend(
        [
            {
                "type": "reasoning",
                "id": "rs-synthetic",
                "summary": [
                    {"type": "summary_text", "text": "Synthetic reasoning summary."}
                ],
                "encrypted_content": "synthetic-encrypted-content",
            },
            {
                "type": "function_call",
                "id": "fc-synthetic",
                "call_id": "call-synthetic",
                "name": "lookup",
                "arguments": '{"id":7}',
                "status": "completed",
            },
        ]
    )
    before = deepcopy(payload)
    events = [
        {
            "type": "response.output_text.delta",
            "sequence_number": 0,
            "delta": "Hel",
            "item_id": "msg_synthetic",
            "output_index": 0,
            "content_index": 0,
        },
        {
            "type": "response.output_text.delta",
            "sequence_number": 1,
            "delta": "lo",
            "item_id": "msg_synthetic",
            "output_index": 0,
            "content_index": 0,
        },
        {"type": f"response.{status}", "sequence_number": 2, "response": payload},
    ]
    source = WireStream(
        events, named=True, error=AssertionError("Must close at terminal event")
    )
    requests = []

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        assert request.url.path == "/openai/v1/responses"
        if body["stream"]:
            return wire_response(source)
        assert body["stream"] is False
        return httpx2.Response(
            200, json=payload, headers={"x-request-id": "request-synthetic"}
        )

    client = make_client(handle, internal_streaming=..., pricing_data=PRICES)
    internal = client.get_genai_response(
        model="deployment", input="Synthetic parity check."
    )
    native = client.get_genai_response(
        model="deployment", input="Synthetic parity check.", stream=False
    )

    assert type(internal) is Response
    assert_same_sdk_object(internal, native)
    assert internal.output_text == native.output_text == "Hello"
    assert payload == before
    assert [request["stream"] for request in requests] == [True, False]
    assert source.closed and source.reads == len(events)
    audit = audit_events(client)
    assert len(audit) == 2 and all(event["status"] == status for event in audit)
    assert (
        audit[0]["total_cost"]
        == audit[1]["total_cost"]
        == (1.195 if usage_present else None)
    )


def test_chat_filter_annotations_are_an_explicit_additional_field(make_client):
    filter_results = {"hate": {"filtered": False, "severity": "safe"}}
    native_payload = chat_payload()
    native_payload["prompt_filter_results"] = [
        {"prompt_index": 0, "content_filter_results": filter_results}
    ]
    annotation = {
        "id": "",
        "object": "",
        "created": 0,
        "model": "",
        "choices": [],
        "prompt_filter_results": deepcopy(native_payload["prompt_filter_results"]),
    }
    source = WireStream([annotation, *text_events()])

    def handle(request):
        return (
            wire_response(source)
            if json.loads(request.content)["stream"]
            else httpx2.Response(
                200, json=native_payload, headers={"x-request-id": "request-synthetic"}
            )
        )

    client = make_client(handle, internal_streaming=...)
    internal = client.get_genai_completion(
        model="deployment", prompt="Synthetic parity check."
    )
    native = client.get_genai_completion(
        model="deployment", prompt="Synthetic parity check.", stream=False
    )
    assert type(internal) is type(native) is ChatCompletion
    assert internal.model_dump() != native.model_dump()
    assert internal.azure_stream_annotations == [annotation]
    assert "azure_stream_annotations" not in native.to_dict()
    assert (
        internal.model_dump(exclude={"azure_stream_annotations"}) == native.model_dump()
    )
    internal_fields = internal.to_dict()
    assert internal_fields.pop("azure_stream_annotations") == [annotation]
    assert internal_fields == native.to_dict()
    assert internal._request_id == native._request_id
    assert source.closed
