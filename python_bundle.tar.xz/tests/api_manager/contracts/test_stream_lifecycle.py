"""Deterministic lifecycle races; no proxy processes, network or sleeps."""

from concurrent.futures import ThreadPoolExecutor
from threading import Event
from types import SimpleNamespace
from unittest.mock import Mock

import httpx2
import pytest

from genai_api_manager import GenAiApiClient, StreamInterruptedError
from genai_api_manager.platform.proxy import WindowsProxyMixin

from tests.support.client import audit_events
from tests.support.azure import chat_payload
from tests.support.azure import WireStream, chunk, text_events, wire_response


@pytest.mark.parametrize("internal", [False, True])
def test_close_during_headers_defers_sdk_and_logger_disposal(make_client, internal):
    dispatched, proceed = Event(), Event()
    source = WireStream(text_events())

    def handle(request):
        dispatched.set()
        assert proceed.wait(5)
        return (
            wire_response(source)
            if internal
            else httpx2.Response(200, json=chat_payload())
        )

    client = make_client(handle, internal_streaming=internal)
    sdk = client._openai_client
    with ThreadPoolExecutor(max_workers=1) as pool:
        task = pool.submit(client.get_genai_completion, model="deployment", prompt="hi")
        try:
            assert dispatched.wait(5)
            client.close()
            assert not sdk.is_closed()
            assert not client.log_manager._closed
            assert WindowsProxyMixin._active_requests == 1
        finally:
            proceed.set()
        if internal:
            with pytest.raises(StreamInterruptedError):
                task.result(timeout=5)
            assert source.reads == 0 and source.closed
        else:
            assert task.result(timeout=5).id == "chatcmpl-synthetic"
    assert sdk.is_closed()
    assert client.log_manager._closed
    assert WindowsProxyMixin._active_requests == 0
    assert len(audit_events(client)) == 1


@pytest.mark.parametrize("public", [False, True])
def test_close_during_read_retains_returning_usage_before_release(make_client, public):
    reading, proceed = Event(), Event()

    class DelayedUsage(WireStream):
        def __iter__(self):
            yield from WireStream(text_events(usage=False), done=False)
            reading.set()
            assert proceed.wait(5)
            yield from WireStream([chunk([], usage=chat_payload()["usage"])])

    source = DelayedUsage([])
    client = make_client(lambda _: wire_response(source), internal_streaming=True)

    def consume():
        result = client.get_genai_completion(
            model="deployment", prompt="hi", stream=True if public else None
        )
        if public:
            return list(result)
        return result

    with ThreadPoolExecutor(max_workers=1) as pool:
        task = pool.submit(consume)
        try:
            assert reading.wait(5)
            client.close()
            assert WindowsProxyMixin._active_requests == 1
            assert not client.log_manager._closed
        finally:
            proceed.set()
        if public:
            assert task.result(timeout=5)[-1].usage.prompt_tokens == 1000
        else:
            with pytest.raises(StreamInterruptedError):
                task.result(timeout=5)
    assert source.closed
    assert WindowsProxyMixin._active_requests == 0
    (event,) = audit_events(client)
    assert event["status"] == ("partial" if public else "interrupted")
    assert event["total_cost"] == 1.12
    assert client.log_manager._closed


def test_budget_rejection_does_not_close_other_same_client_stream(make_client):
    sources = []

    def handle(request):
        source = WireStream(text_events())
        sources.append(source)
        return wire_response(source)

    client = make_client(handle)
    sdk = client._openai_client
    first = client.get_genai_completion(model="deployment", prompt="hi", stream=True)
    second = client.get_genai_completion(model="deployment", prompt="hi", stream=True)
    list(first)
    client.log_manager.daily_cost_limit = 1
    assert (
        client.get_genai_completion(model="deployment", prompt="hi")
        == "Daily cost limit exceeded."
    )
    assert not sdk.is_closed()
    assert list(second)[0].choices[0].delta.content == "Hello"
    assert sdk.is_closed()
    assert client._openai_client is None
    assert WindowsProxyMixin._active_requests == 0
    events = audit_events(client)
    assert len(events) == 2
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "2.24"


def test_client_close_closes_idle_stream_without_reading_and_is_idempotent(make_client):
    source = WireStream(text_events())
    client = make_client(lambda _: wire_response(source))
    stream = client.get_genai_completion(model="deployment", prompt="hi", stream=True)
    client.close()
    client.close()
    stream.close()
    assert source.reads == 0 and source.closed
    assert list(stream) == []
    assert WindowsProxyMixin._active_requests == 0
    assert len(audit_events(client)) == 1


@pytest.mark.parametrize("public", [False, True])
def test_keyboard_interrupt_preserved_and_source_closed(make_client, public):
    error = KeyboardInterrupt()
    source = WireStream(text_events(), error=error)
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with pytest.raises(KeyboardInterrupt) as raised:
        result = client.get_genai_completion(
            model="deployment", prompt="hi", stream=True if public else None
        )
        list(result)
    assert raised.value is error
    assert source.closed
    assert WindowsProxyMixin._active_requests == 0
    (event,) = audit_events(client)
    assert event["status"] == "interrupted"
    assert event["total_cost"] == 1.12


def test_proxy_lease_protects_gaps_and_is_shared_across_subclasses(monkeypatch):
    manager = WindowsProxyMixin
    clock = [100.0]
    monkeypatch.setattr(
        "genai_api_manager.platform.proxy.time.monotonic", lambda: clock[0]
    )
    monkeypatch.setattr(manager, "_active_requests", 0)
    monkeypatch.setattr(manager, "_last_use_ts", 0)
    monkeypatch.setattr(manager, "_idle_secs", 10)
    monkeypatch.setattr(manager, "_px_started_by_us", True)
    monkeypatch.setattr(manager, "_px_popen", SimpleNamespace(pid=123))
    stop = Mock()
    monkeypatch.setattr(manager, "_shutdown_nolock", stop)

    class OtherClient(GenAiApiClient):
        pass

    first = GenAiApiClient.__new__(GenAiApiClient)._acquire_proxy_lease()
    second = OtherClient.__new__(OtherClient)._acquire_proxy_lease()
    clock[0] = 10000
    manager._shutdown_if_idle()
    first.release()
    first.release()
    manager._shutdown_if_idle()
    stop.assert_not_called()
    second.release()
    assert manager._active_requests == 0
    manager._shutdown_if_idle()
    stop.assert_not_called()
    clock[0] += 10
    manager._shutdown_if_idle()
    stop.assert_called_once()
    monkeypatch.setattr(manager, "_px_started_by_us", False)
    manager._shutdown_if_idle()
    assert stop.call_count == 1


def test_proxy_acquire_and_idle_shutdown_are_serialized(monkeypatch):
    manager = WindowsProxyMixin
    starting, proceed = Event(), Event()
    monkeypatch.setattr(manager, "_active_requests", 0)
    monkeypatch.setattr(manager, "_px_started_by_us", True)
    monkeypatch.setattr(manager, "_px_popen", SimpleNamespace(pid=123))
    monkeypatch.setattr(manager, "_last_use_ts", 0)
    stop = Mock()
    monkeypatch.setattr(manager, "_shutdown_nolock", stop)

    def startup(self):
        starting.set()
        assert proceed.wait(5)

    monkeypatch.setattr(GenAiApiClient, "_ensure_px_for_use", startup)
    client = GenAiApiClient.__new__(GenAiApiClient)
    with ThreadPoolExecutor(max_workers=2) as pool:
        acquire = pool.submit(client._acquire_proxy_lease)
        try:
            assert starting.wait(5)
            watchdog = pool.submit(manager._shutdown_if_idle)
        finally:
            proceed.set()
        lease = acquire.result(timeout=5)
        try:
            watchdog.result(timeout=5)
            stop.assert_not_called()
        finally:
            lease.release()


def test_failed_proxy_acquisition_does_not_leak_ownership(make_client):
    client = make_client(lambda _: pytest.fail("must not dispatch"))
    error = RuntimeError("synthetic startup failure")
    client._ensure_px_for_use = Mock(side_effect=error)
    with pytest.raises(RuntimeError) as raised:
        client.get_genai_completion(model="deployment", prompt="hi")
    assert raised.value is error
    assert WindowsProxyMixin._active_requests == 0
    assert audit_events(client) == []
