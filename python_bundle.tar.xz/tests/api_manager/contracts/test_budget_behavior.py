"""Original numeric cost guard through production APIs and the actual SDK."""

from decimal import Decimal

import httpx2
import pytest
from openai import APIConnectionError, APITimeoutError

from tests.support.azure import (
    WireStream,
    chat_payload,
    embedding_payload,
    response_payload,
    text_events,
    wire_response,
)
from tests.support.client import audit_events


MODES = [
    (operation, mode)
    for operation in ("chat", "responses")
    for mode in ("native", "internal", "public")
] + [("embeddings", "native")]


def invoke(client, operation, mode, **kwargs):
    if operation == "chat":
        return client.get_genai_completion(
            model="deployment",
            prompt="hi",
            stream=True if mode == "public" else None,
            **kwargs,
        )
    if operation == "responses":
        return client.get_genai_response(
            model="deployment",
            input="hi",
            stream=True if mode == "public" else None,
            **kwargs,
        )
    return client.get_genai_embeddings(model="deployment", input="hi", **kwargs)


@pytest.mark.parametrize("operation,mode", MODES)
@pytest.mark.parametrize("failure", ["connection", "timeout", "argument"])
def test_sdk_failure_does_not_charge_or_disable_next_request(
    make_client, operation, mode, failure
):
    attempts = []
    healthy = False

    def handle(request):
        attempts.append(request)
        if healthy:
            return httpx2.Response(200, json=embedding_payload())
        if failure == "timeout":
            raise httpx2.ReadTimeout("synthetic timeout", request=request)
        raise httpx2.ConnectError("synthetic disconnect", request=request)

    client = make_client(handle, internal_streaming=mode == "internal")
    expected = {
        "connection": APIConnectionError,
        "timeout": APITimeoutError,
        "argument": TypeError,
    }[failure]
    kwargs = {"unsupported_argument": True} if failure == "argument" else {}
    with pytest.raises(expected):
        invoke(client, operation, mode, **kwargs)
    assert len(attempts) == (0 if failure == "argument" else 1)
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "0"
    assert client.log_manager.get_metrics()["request_status_counts"] == {}
    assert not client.log_manager.budget_exceeded()
    healthy = True
    result = client.get_genai_embeddings(
        model="deployment", input="hi", encoding_format="float", embeddings_only=True
    )
    assert result == [0.1, 0.2]
    assert len(audit_events(client)) == 1


@pytest.mark.parametrize(
    "operation,mode,usage_kind",
    [
        (operation, mode, usage_kind)
        for operation, mode in MODES
        for usage_kind in ("missing", "invalid", "write_rate_missing")
        if operation != "embeddings" or usage_kind != "write_rate_missing"
    ],
)
def test_unknown_cost_is_audited_without_blocking_next_request(
    make_client, operation, mode, usage_kind
):
    calls = []

    def handle(request):
        calls.append(request)
        if len(calls) > 1:
            return httpx2.Response(200, json=embedding_payload())
        if operation == "embeddings":
            payload = embedding_payload()
        elif operation == "responses":
            payload = response_payload()
        else:
            payload = chat_payload()
        usage = payload["usage"]
        if usage_kind == "missing":
            payload["usage"] = None
        elif usage_kind == "invalid":
            usage["input_tokens" if operation == "responses" else "prompt_tokens"] = -1
        else:
            usage[
                "input_tokens_details"
                if operation == "responses"
                else "prompt_tokens_details"
            ]["cache_write_tokens"] = 100
        if mode == "native":
            return httpx2.Response(200, json=payload)
        if operation == "chat":
            events = text_events(usage=False)
            events.append(
                {
                    "id": payload["id"],
                    "object": "chat.completion.chunk",
                    "created": 1,
                    "model": "deployment",
                    "choices": [],
                    "usage": payload["usage"],
                }
            )
        else:
            events = [
                {
                    "type": "response.completed",
                    "sequence_number": 0,
                    "response": payload,
                }
            ]
        return wire_response(WireStream(events))

    client = make_client(handle, internal_streaming=mode == "internal")
    result = invoke(client, operation, mode)
    if mode == "public":
        with result:
            list(result)
    assert not client.log_manager.budget_exceeded()
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "0"
    assert client.get_genai_embeddings(
        model="deployment", input="hi", encoding_format="float", embeddings_only=True
    ) == [0.1, 0.2]
    first, second = audit_events(client)
    assert first["total_cost"] is None
    assert first["cost_status"] == (
        "cache_write_rate_missing"
        if usage_kind == "write_rate_missing"
        else "usage_missing"
    )
    assert second["total_cost"] == 0.01
    assert len(calls) == 2


@pytest.mark.parametrize("operation,mode", MODES)
@pytest.mark.parametrize(
    "cost,limit,blocked",
    [
        ("0.99", "1", False),
        ("1", "1", False),
        ("1.01", "1", True),
        ("0", "0", False),
        ("0.01", "0", True),
    ],
)
def test_only_spending_above_limit_blocks(
    make_client, operation, mode, cost, limit, blocked
):
    calls = []

    def handle(request):
        calls.append(request)
        if operation == "embeddings":
            return httpx2.Response(200, json=embedding_payload())
        if mode == "native":
            return httpx2.Response(
                200, json=chat_payload() if operation == "chat" else response_payload()
            )
        events = (
            text_events()
            if operation == "chat"
            else [
                {
                    "type": "response.completed",
                    "sequence_number": 0,
                    "response": response_payload(),
                }
            ]
        )
        return wire_response(WireStream(events))

    client = make_client(handle)
    client.internal_streaming = mode == "internal"
    client.log_manager.daily_cost_limit = Decimal(limit)
    client.log_manager._budget.record(
        client.log_manager._accounting_key(), Decimal(cost)
    )
    result = invoke(client, operation, mode)
    if blocked:
        assert result == "Daily cost limit exceeded."
        assert calls == []
        assert client._openai_client is None
    else:
        if mode == "public":
            with result:
                list(result)
        assert len(calls) == 1
