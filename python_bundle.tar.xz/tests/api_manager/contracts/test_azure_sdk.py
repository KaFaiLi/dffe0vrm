"""Synthetic contracts: no claim of live Azure validation."""

from tests.support.azure import (
    EventBytes,
    WireStream,
    chat_payload,
    response_payload,
    text_events,
    wire_response,
)

import json
from decimal import Decimal

import httpx2
import pytest
from openai import APIConnectionError, APITimeoutError, RateLimitError

from genai_api_manager import UnpricedModelError
from tests.support.client import audit_events


@pytest.mark.parametrize(
    "operation,mode",
    [
        (api, mode)
        for api in ("chat", "responses")
        for mode in ("native", "public", "internal")
    ]
    + [("embeddings", "native")],
)
def test_all_request_routes_write_only_the_nineteen_standard_fields(
    make_client, operation, mode
):
    def handle(request):
        payload = json.loads(request.content)
        assert bool(payload.get("stream")) == (mode != "native")
        if operation == "chat":
            if mode != "native":
                return wire_response(WireStream(text_events()))
            response = chat_payload()
        elif operation == "responses":
            response = response_payload()
            if mode != "native":
                return wire_response(
                    WireStream(
                        [
                            {
                                "type": "response.completed",
                                "sequence_number": 0,
                                "response": response,
                            }
                        ],
                        named=True,
                    )
                )
        else:
            response = {
                "object": "list",
                "model": "deployment",
                "data": [{"object": "embedding", "index": 0, "embedding": [0.1, 0.2]}],
                "usage": {"prompt_tokens": 10, "total_tokens": 10},
            }
        return httpx2.Response(
            200, json=response, headers={"x-request-id": "request-synthetic"}
        )

    client = make_client(handle, internal_streaming=mode == "internal")
    options = {"stream": True} if mode == "public" else {}
    if operation == "chat":
        result = client.get_genai_completion(model="deployment", prompt="hi", **options)
    elif operation == "responses":
        result = client.get_genai_response(model="deployment", input="hi", **options)
    else:
        result = client.get_genai_embeddings(model="deployment", input="hi")
    if mode == "public":
        with result:
            list(result)
    (event,) = audit_events(client)
    assert set(event) == {
        "model_name",
        "input_token",
        "output_token",
        "input_cost",
        "output_cost",
        "total_cost",
        "status",
        "timestamp",
        "prompt",
        "completion",
        "shared_key",
        "cumulative_input_cost",
        "cumulative_output_cost",
        "cumulative_total_cost",
        "operation",
        "request_id",
        "cached_input_token",
        "cache_write_token",
        "cost_status",
    }
    assert event["status"] == "completed"
    assert event["request_id"]
    assert event["total_cost"] == (0.01 if operation == "embeddings" else 1.12)


@pytest.mark.parametrize(
    "operation", ["chat", "chat-stream", "responses", "responses-stream", "embeddings"]
)
@pytest.mark.parametrize("request_style", [False, True])
@pytest.mark.parametrize("budget_blocked", [False, True])
def test_unpriced_model_rejected_before_any_request(
    make_client, operation, request_style, budget_blocked
):
    client = make_client(lambda _: pytest.fail("Unpriced model must not reach Azure"))
    client._ensure_px_for_use = lambda: pytest.fail(
        "Unpriced model must not start proxy"
    )
    if budget_blocked:
        client.log_manager.daily_cost_limit = 0
        client.log_manager._budget.record(
            client.log_manager._accounting_key(), Decimal("0.01")
        )
    before_cost = client.log_manager.get_metrics()["daily_cost_exact"]
    if operation.startswith("chat"):
        call = client.get_genai_completion
        payload = {"messages": [{"role": "user", "content": "hi"}]}
    elif operation.startswith("responses"):
        call = client.get_genai_response
        payload = {"input": "hi"}
    else:
        call = client.get_genai_embeddings
        payload = {"input": "hi"}
    if operation.endswith("-stream"):
        payload["stream"] = True
    payload["model"] = "unpriced-deployment"
    # Validation must use the resolved request model, including request-dict precedence.
    arguments = (
        {"request": payload, "model": "deployment"} if request_style else payload
    )
    with pytest.raises(UnpricedModelError, match="unpriced-deployment"):
        call(**arguments)
    assert audit_events(client) == []
    assert client.log_manager.get_metrics()["daily_cost_exact"] == before_cost
    assert "unpriced_events" not in client.log_manager.get_metrics()


def test_priced_deployment_alias_is_accepted(make_client):
    def handle(request):
        assert request.url.path == "/openai/v1/chat/completions"
        return httpx2.Response(200, json=chat_payload())

    client = make_client(handle, pricing_aliases={"azure-alias": "deployment"})
    client.get_genai_completion(model="azure-alias", prompt="hi")
    (event,) = audit_events(client)
    assert event["model_name"] == "azure-alias"
    assert event["total_cost"] == 1.12


@pytest.mark.parametrize("api", ["chat", "responses"])
def test_cache_write_charge_reaches_production_audit_and_budget(make_client, api):
    payload = chat_payload() if api == "chat" else response_payload()
    details = "prompt_tokens_details" if api == "chat" else "input_tokens_details"
    payload["usage"][details] = {"cached_tokens": 600, "cache_write_tokens": 300}
    client = make_client(
        lambda _: httpx2.Response(200, json=payload),
        pricing_data={
            "deployment": {
                "input": "1",
                "cached_input": "0.2",
                "cache_write": "1.25",
                "output": "3",
            }
        },
    )
    if api == "chat":
        client.get_genai_completion(model="deployment", prompt="hi")
    else:
        client.get_genai_response(model="deployment", input="hi")
    (event,) = audit_events(client)
    assert event["total_cost"] == 1.195
    assert event["cache_write_token"] == 300
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "1.195"


def test_chat_request_contract_and_cached_charge(make_client):
    def handle(request):
        assert request.url.path == "/openai/v1/chat/completions"
        assert "api-version" not in request.url.params
        assert request.headers["authorization"] == "Bearer synthetic-token"
        assert json.loads(request.content)["messages"] == [
            {"role": "user", "content": "hi"}
        ]
        return httpx2.Response(
            200, json=chat_payload(), headers={"x-request-id": "request-synthetic"}
        )

    client = make_client(handle)
    response = client.get_genai_completion(
        model="deployment", messages=[{"role": "user", "content": "hi"}]
    )
    assert response.choices[0].message.content == "Hello"
    (event,) = audit_events(client)
    assert event["total_cost"] == 1.12
    assert event["cached_input_token"] == 600
    assert event["request_id"] == "request-synthetic"


def test_chat_stream_uses_real_sdk_and_terminal_usage(make_client):
    base = {
        "id": "chatcmpl-stream",
        "object": "chat.completion.chunk",
        "created": 1,
        "model": "deployment",
    }
    chunks = [
        dict(
            base,
            choices=[{"index": 0, "delta": {"content": "Hi"}, "finish_reason": "stop"}],
        ),
        dict(base, choices=[], usage=chat_payload()["usage"]),
    ]
    source = EventBytes(chunks)

    def handle(request):
        assert json.loads(request.content)["stream_options"]["include_usage"]
        return httpx2.Response(
            200, headers={"content-type": "text/event-stream"}, stream=source
        )

    client = make_client(handle)
    stream = client.get_genai_completion(model="deployment", prompt="hi", stream=True)
    assert source.produced == 0
    assert next(stream).choices[0].delta.content == "Hi"
    assert source.produced == 1
    assert next(stream).usage.prompt_tokens_details.cached_tokens == 600
    list(stream)
    stream.close()
    (event,) = audit_events(client)
    assert event["status"] == "completed"
    assert event["total_cost"] == 1.12
    assert source.closed


@pytest.mark.parametrize("status", ["completed", "incomplete", "failed", "cancelled"])
def test_responses_preserve_sdk_result_and_account_usage(make_client, status):
    def handle(request):
        assert request.url.path == "/openai/v1/responses"
        assert "api-version" not in request.url.params
        assert json.loads(request.content)["input"] == "hi"
        return httpx2.Response(200, json=response_payload(status))

    client = make_client(handle)
    result = client.get_genai_response(model="deployment", input="hi")
    assert result.status == status
    assert result.output_text == "Hello"
    (event,) = audit_events(client)
    assert event["status"] == status
    assert event["operation"] == "responses"
    assert event["total_cost"] == 1.12


def test_responses_stream_preserves_events(make_client):
    source = EventBytes(
        [
            {
                "type": "response.created",
                "sequence_number": 0,
                "response": response_payload("in_progress"),
            },
            {
                "type": "response.output_text.delta",
                "sequence_number": 1,
                "item_id": "msg_synthetic",
                "output_index": 0,
                "content_index": 0,
                "delta": "Hello",
            },
            {
                "type": "response.completed",
                "sequence_number": 2,
                "response": response_payload(),
            },
        ]
    )
    client = make_client(
        lambda req: httpx2.Response(
            200, headers={"content-type": "text/event-stream"}, stream=source
        )
    )
    with client.get_genai_response(
        model="deployment", input="hi", stream=True
    ) as stream:
        assert source.produced == 0
        events = list(stream)
    assert [e.type for e in events] == [
        "response.created",
        "response.output_text.delta",
        "response.completed",
    ]
    assert source.closed
    (event,) = audit_events(client)
    assert event["total_cost"] == 1.12


@pytest.mark.parametrize("operation", ["chat", "responses"])
def test_rate_limit_propagates_without_accounting(make_client, operation):
    client = make_client(
        lambda req: httpx2.Response(
            429, json={"error": {"message": "synthetic throttle", "code": "rate_limit"}}
        )
    )
    with pytest.raises(RateLimitError):
        if operation == "chat":
            client.get_genai_completion(model="deployment", prompt="hi")
        else:
            client.get_genai_response(model="deployment", input="hi")
    assert client.log_manager.check_daily_cost() == 0
    assert not client.log_manager.budget_exceeded()
    assert audit_events(client) == []


def test_connection_error_remains_sdk_error(make_client):
    def handle(request):
        raise httpx2.ConnectError("synthetic disconnect", request=request)

    client = make_client(handle)
    with pytest.raises(APIConnectionError):
        client.get_genai_completion(model="deployment", prompt="hi")
    assert audit_events(client) == []


def test_embeddings_contract(make_client):
    def handle(request):
        assert request.url.path == "/openai/v1/embeddings"
        assert "api-version" not in request.url.params
        return httpx2.Response(
            200,
            json={
                "object": "list",
                "model": "deployment",
                "data": [{"object": "embedding", "index": 0, "embedding": [0.1, 0.2]}],
                "usage": {"prompt_tokens": 10, "total_tokens": 10},
            },
        )

    client = make_client(handle)
    assert client.get_genai_embeddings(
        model="deployment", input="hi", encoding_format="float", embeddings_only=True
    ) == [0.1, 0.2]
    (event,) = audit_events(client)
    assert event["operation"] == "embeddings"
    assert event["output_token"] == 0


@pytest.mark.parametrize(
    "outcome", ["partial", "usage_missing", "stream_error", "stream_timeout"]
)
def test_responses_interruption_has_unknown_cost_and_closes(make_client, outcome):
    delta = {
        "type": "response.output_text.delta",
        "sequence_number": 0,
        "item_id": "msg",
        "output_index": 0,
        "content_index": 0,
        "delta": "partial",
    }
    error = (
        httpx2.ReadError("synthetic interruption")
        if outcome == "stream_error"
        else None
    )
    if outcome == "stream_timeout":
        error = httpx2.ReadTimeout("synthetic timeout")
    source = EventBytes([delta], error=error)
    client = make_client(
        lambda req: httpx2.Response(
            200, headers={"content-type": "text/event-stream"}, stream=source
        )
    )
    stream = client.get_genai_response(model="deployment", input="hi", stream=True)
    assert next(stream).delta == "partial"
    if outcome == "partial":
        stream.close()
    elif outcome == "usage_missing":
        assert list(stream) == []
    else:
        expected_error = (
            APITimeoutError if outcome == "stream_timeout" else APIConnectionError
        )
        with pytest.raises(expected_error) as raised:
            next(stream)
        assert raised.value.__cause__ is error
    stream.close()
    assert source.closed
    (event,) = audit_events(client)
    assert event["status"] == (
        "stream_error" if outcome == "stream_timeout" else outcome
    )
    assert event["total_cost"] is None
    assert not client.log_manager.budget_exceeded()


def test_sdk_retry_logs_one_charge(make_client):
    requests = []

    def handle(request):
        requests.append(request)
        if len(requests) == 1:
            return httpx2.Response(
                500,
                json={"error": {"message": "retry"}},
                headers={"retry-after-ms": "1"},
            )
        return httpx2.Response(200, json=chat_payload())

    client = make_client(handle, max_retries=1)
    client.get_genai_completion(model="deployment", prompt="hi")
    assert len(requests) == 2
    assert len(audit_events(client)) == 1
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "1.12"


def test_responses_request_is_not_mutated_and_background_is_rejected(make_client):
    observed = []

    def handle(request):
        observed.append(json.loads(request.content))
        return httpx2.Response(200, json=response_payload())

    client = make_client(handle)
    payload = {
        "model": "deployment",
        "input": "original",
        "instructions": "Keep brief",
        "store": False,
    }
    client.get_genai_response(request=payload, **{"input": "replacement"})
    # Explicit fields retain the same precedence as existing convenience inputs.
    assert observed[0]["input"] == "original"
    assert payload["input"] == "original"
    assert observed[0]["store"] is False
    with pytest.raises(ValueError, match="Background"):
        client.get_genai_response(model="deployment", input="hi", background=True)
    assert len(observed) == 1
