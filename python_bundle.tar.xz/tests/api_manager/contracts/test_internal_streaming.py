"""Synthetic Azure JSON/SSE parity through the locked SDK and public client.

Provenance: docs/internal-streaming-research.md; fixtures are not live recordings.
"""

from tests.support.azure import (
    WireStream,
    chunk,
    choice,
    text_events,
    wire_response,
    tool,
)

from copy import deepcopy
from decimal import Decimal
import json

import httpx2
import openai
import pytest
from openai.types.chat import ChatCompletion
from openai import APIConnectionError, APIError, APITimeoutError

from genai_api_manager import (
    StreamAssemblyError,
    StreamEventError,
    UnexpectedStreamEndError,
    UnpricedModelError,
)

from tests.support.client import audit_events
from tests.support.azure import chat_payload, response_payload


@pytest.mark.parametrize("operation", ["chat", "responses"])
@pytest.mark.parametrize("configured", [..., True, False], ids=["default", "on", "off"])
@pytest.mark.parametrize(
    "stream", [..., None, False, True], ids=["omitted", "null", "false", "true"]
)
def test_stream_routing_and_accounting(make_client, operation, configured, stream):
    public = stream is True
    streaming = public or (configured is not False and stream is not False)
    payload = chat_payload() if operation == "chat" else response_payload()
    events = (
        text_events()
        if operation == "chat"
        else [{"type": "response.completed", "sequence_number": 0, "response": payload}]
    )
    source = WireStream(events)
    requests = []

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        assert bool(body.get("stream")) is streaming
        if operation == "chat":
            if streaming:
                assert body["stream_options"]["include_usage"] is True
            else:
                assert "stream_options" not in body
        return (
            wire_response(source) if streaming else httpx2.Response(200, json=payload)
        )

    client = make_client(handle, internal_streaming=configured)
    assert client.internal_streaming is (configured is not False)
    options = {} if stream is ... else {"stream": stream}
    call = (
        client.get_genai_completion
        if operation == "chat"
        else client.get_genai_response
    )
    result = call(
        model="deployment",
        **{"prompt" if operation == "chat" else "input": "hi"},
        **options,
    )
    if public:
        assert source.reads == 0
        with result:
            assert list(result)
    elif operation == "chat":
        assert type(result) is ChatCompletion
        assert result.choices[0].message.content == "Hello"
    else:
        assert result.object == "response" and result.output_text == "Hello"
    if streaming:
        assert source.closed
    assert len(requests) == 1
    (event,) = audit_events(client)
    assert event["status"] == "completed" and event["total_cost"] == 1.12
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "1.12"


@pytest.mark.parametrize("operation", ["chat", "responses"])
@pytest.mark.parametrize(
    "where", ["request", "extra_body", "duplicate", "keyword_override"]
)
def test_explicit_false_selects_native_without_mutating_request(
    make_client, operation, where
):
    seen = []

    def handle(request):
        body = json.loads(request.content)
        seen.append(body)
        assert body["stream"] is False
        return httpx2.Response(
            200, json=chat_payload() if operation == "chat" else response_payload()
        )

    client = make_client(handle, internal_streaming=...)
    payload = {
        "model": "deployment",
        "messages" if operation == "chat" else "input": [
            {"role": "user", "content": "hi"}
        ]
        if operation == "chat"
        else "hi",
    }
    if where in ("request", "duplicate"):
        payload["stream"] = False
    if where in ("extra_body", "duplicate"):
        payload["extra_body"] = {"stream": False}
    if where == "keyword_override":
        payload["stream"] = True
    before = deepcopy(payload)
    call = (
        client.get_genai_completion
        if operation == "chat"
        else client.get_genai_response
    )
    result = call(
        request=payload, **({"stream": False} if where == "keyword_override" else {})
    )
    assert result.model == "deployment"
    assert payload == before
    assert len(seen) == 1
    assert "stream" not in seen[0].get("extra_body", {})
    assert len(audit_events(client)) == 1


def test_hidden_chat_matches_native_sdk_object_and_dump(make_client):
    native = make_client(
        lambda _: httpx2.Response(
            200, json=chat_payload(), headers={"x-request-id": "request-synthetic"}
        ),
    ).get_genai_completion(model="deployment", prompt="hi")
    source = WireStream(text_events())
    requests = []

    def handle(request):
        requests.append(json.loads(request.content))
        assert "api-version" not in request.url.params
        return wire_response(source)

    client = make_client(handle, internal_streaming=True)
    payload = {
        "model": "deployment",
        "messages": [{"role": "user", "content": "hi"}],
    }
    before = deepcopy(payload)
    result = client.get_genai_completion(request=payload)
    assert type(result) is ChatCompletion
    assert type(result.choices[0]) is type(native.choices[0])
    assert type(result.choices[0].message) is type(native.choices[0].message)
    assert result.model_dump() == native.model_dump()
    assert result.to_dict() == native.to_dict()
    assert result._request_id == native._request_id
    assert payload == before
    assert len(requests) == 1
    assert requests[0]["stream"] is True
    assert requests[0]["stream_options"]["include_usage"] is True
    assert source.closed
    (event,) = audit_events(client)
    assert event["request_id"] == "request-synthetic"
    assert event["total_cost"] == 1.12


@pytest.mark.parametrize("status", ["completed", "incomplete", "failed"])
def test_hidden_responses_preserves_terminal_object(make_client, status):
    payload = response_payload(status)
    payload["output"][0]["content"][0]["annotations"] = [
        {
            "type": "url_citation",
            "start_index": 0,
            "end_index": 5,
            "url": "https://example.invalid/source",
            "title": "Synthetic",
        }
    ]
    payload["output"][0]["content"].append(
        {"type": "refusal", "refusal": "Synthetic refusal"}
    )
    payload["output"].append(
        {
            "type": "function_call",
            "id": "fc-synthetic",
            "call_id": "call-synthetic",
            "name": "synthetic",
            "arguments": "{raw}",
            "status": "completed",
        }
    )
    payload["vendor"] = {"flag": True}
    native = make_client(
        lambda _: httpx2.Response(200, json=payload)
    ).get_genai_response(
        model="deployment",
        input="hi",
    )
    source = WireStream(
        [{"type": f"response.{status}", "sequence_number": 1, "response": payload}],
        named=True,
        error=AssertionError("Must close at terminal"),
    )
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    result = client.get_genai_response(model="deployment", input="hi")
    assert result.status == status
    assert result.output_text == "Hello"
    assert type(result) is type(native)
    assert type(result.output[1]) is type(native.output[1])
    assert result.output[1].arguments == "{raw}"
    assert result.model_dump() == native.model_dump()
    assert result.to_dict() == native.to_dict()
    assert result._request_id == "request-synthetic"
    assert source.closed
    (event,) = audit_events(client)
    assert event["status"] == status
    assert event["request_id"] == "resp_synthetic"


def test_trailing_filter_without_delta_is_terminal_and_usage_survives(make_client):
    events = text_events("你好", usage=True)
    events.append(
        {
            "id": "",
            "object": "",
            "created": 0,
            "model": "",
            "usage": None,
            "choices": [
                choice(
                    index=0,
                    finish="content_filter",
                    content_filter_results={
                        "hate": {"filtered": True, "severity": "high"}
                    },
                    content_filter_offsets={
                        "start_offset": 0,
                        "end_offset": 2,
                        "check_offset": 2,
                    },
                )
            ],
        }
    )
    client = make_client(
        lambda _: wire_response(WireStream(events)), internal_streaming=True
    )
    result = client.get_genai_completion(model="deployment", prompt="hi")
    assert result.id == "chatcmpl-synthetic"
    assert result.choices[0].finish_reason == "content_filter"
    assert result.choices[0].message.content == "你好"
    assert result.choices[0].content_filter_results["hate"]["filtered"] is True
    assert (
        result.azure_stream_annotations[-1]["choices"][0]["content_filter_offsets"][
            "check_offset"
        ]
        == 2
    )
    assert result.usage.prompt_tokens == 1000
    assert audit_events(client)[0]["total_cost"] == 1.12


def test_leading_and_repeated_prompt_annotations_preserve_strongest_filter(make_client):
    def annotation(severity, filtered):
        return {
            "id": "",
            "object": "",
            "created": 0,
            "model": "",
            "choices": [],
            "prompt_filter_results": [
                {
                    "prompt_index": 0,
                    "content_filter_results": {
                        "hate": {"severity": severity, "filtered": filtered}
                    },
                }
            ],
        }

    events = [annotation("medium", True), *text_events(), annotation("safe", False)]
    client = make_client(
        lambda _: wire_response(WireStream(events)), internal_streaming=True
    )
    result = client.get_genai_completion(model="deployment", prompt="hi")
    assert result.id == "chatcmpl-synthetic"
    assert result.prompt_filter_results[0]["content_filter_results"]["hate"] == {
        "severity": "medium",
        "filtered": True,
    }
    assert len(result.azure_stream_annotations) == 2


def test_interleaved_choices_tools_refusal_logprobs_and_extensions(make_client):
    logprob = {"token": "No", "bytes": [78, 111], "logprob": -0.1, "top_logprobs": []}
    events = [
        chunk(
            [
                choice(
                    {"role": "assistant", "content": None, "refusal": "No"},
                    index=1,
                    logprobs=None,
                )
            ],
            vendor={"count": 2},
        ),
        chunk(
            [
                choice(
                    {
                        "role": "assistant",
                        "tool_calls": [
                            tool(1, id="b", name="wea", arguments='{"city":'),
                            tool(0, id="a", name="fi", arguments='{"parsed":'),
                        ],
                    }
                )
            ],
            service_tier="default",
        ),
        chunk(
            [
                choice(
                    {"role": "assistant", "refusal": " thanks"},
                    index=1,
                    finish="length",
                    logprobs={"content": None, "refusal": [logprob]},
                )
            ]
        ),
        chunk(
            [
                choice(
                    {
                        "tool_calls": [
                            tool(0, id="a", name="rst", arguments='{"x":1}}'),
                            tool(1, id="b", name="ther", arguments="invalid json"),
                        ]
                    },
                    finish="tool_calls",
                )
            ],
            vendor={"flag": True},
        ),
        chunk(
            [],
            usage=chat_payload()["usage"],
            system_fingerprint="fp-test",
            obfuscation="transport-only",
        ),
        chunk([], system_fingerprint=None),
    ]
    client = make_client(
        lambda _: wire_response(WireStream(events)), internal_streaming=True
    )
    result = client.get_genai_completion(
        model="deployment", prompt="hi", n=2, response_format={"type": "json_object"}
    )
    first, second = result.choices
    assert [c.index for c in result.choices] == [0, 1]
    assert [t.id for t in first.message.tool_calls] == ["a", "b"]
    assert first.message.tool_calls[0].function.arguments == '{"parsed":{"x":1}}'
    assert first.message.tool_calls[1].function.arguments == '{"city":invalid json'
    assert first.message.tool_calls[0].function.name == "first"
    assert first.message.tool_calls[1].function.name == "weather"
    assert "index" not in first.message.tool_calls[0].to_dict()
    assert "parsed_arguments" not in first.message.tool_calls[0].function.to_dict()
    assert "parsed" not in first.message.to_dict()
    assert second.message.content is None
    assert second.message.refusal == "No thanks"
    assert second.finish_reason == "length"
    assert second.logprobs.refusal[0].token == "No"
    assert result.vendor == {"count": 2, "flag": True}
    assert result.system_fingerprint == "fp-test"
    assert result.service_tier == "default"
    assert "obfuscation" not in result.to_dict()
    (event,) = audit_events(client)
    assert event["total_cost"] == 1.12


@pytest.mark.parametrize(
    "finish", ["stop", "length", "content_filter", "function_call"]
)
def test_finish_reasons_and_legacy_function_do_not_trigger_parsers(make_client, finish):
    delta = {"role": "assistant", "content": ""}
    if finish == "function_call":
        delta["function_call"] = {"name": "lookup", "arguments": "not-json"}
    events = [
        chunk([choice(delta, finish=finish)]),
        chunk([], usage=chat_payload()["usage"]),
    ]
    client = make_client(
        lambda _: wire_response(WireStream(events)), internal_streaming=True
    )
    result = client.get_genai_completion(
        model="deployment",
        prompt="hi",
        response_format={
            "type": "json_schema",
            "json_schema": {"name": "x", "schema": {"type": "object"}, "strict": True},
        },
    )
    assert result.choices[0].finish_reason == finish
    assert result.choices[0].message.content == ""
    if finish == "function_call":
        assert result.choices[0].message.function_call.arguments == "not-json"


@pytest.mark.parametrize(
    "events,error_type,status",
    [
        ([], UnexpectedStreamEndError, "interrupted"),
        (
            [chunk([choice({"content": "partial"})])],
            UnexpectedStreamEndError,
            "interrupted",
        ),
        (
            text_events() + [chunk([choice({"role": "user"})])],
            StreamAssemblyError,
            "assembly_error",
        ),
        (
            text_events() + [chunk([choice({}, index=-1)])],
            StreamAssemblyError,
            "assembly_error",
        ),
        (
            text_events() + [chunk([choice({}, index=2)])],
            StreamAssemblyError,
            "assembly_error",
        ),
        (
            text_events() + [chunk([], vendor=1), chunk([], vendor=2)],
            StreamAssemblyError,
            "assembly_error",
        ),
    ],
)
def test_chat_invalid_result_closes_and_preserves_known_cost(
    make_client, events, error_type, status
):
    source = WireStream(events, done=False)
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with pytest.raises(error_type) as raised:
        client.get_genai_completion(model="deployment", prompt="private prompt")
    assert "private prompt" not in str(raised.value)
    assert source.closed
    (event,) = audit_events(client)
    assert event["status"] == status
    assert event["total_cost"] == (
        1.12 if any(e.get("usage") for e in events) else None
    )
    assert client.log_manager.get_metrics()["request_status_counts"] == {status: 1}


@pytest.mark.parametrize("public", [False, True])
@pytest.mark.parametrize(
    "transport_error,sdk_error",
    [(httpx2.ReadError, APIConnectionError), (httpx2.ReadTimeout, APITimeoutError)],
)
def test_read_error_after_usage_is_not_early_success_or_retried(
    make_client, public, transport_error, sdk_error
):
    error = transport_error("synthetic read failure")
    source = WireStream(text_events(), error=error)
    dispatches = []

    def handle(request):
        dispatches.append(request)
        return wire_response(source)

    client = make_client(handle, internal_streaming=True)
    with pytest.raises(sdk_error) as raised:
        result = client.get_genai_completion(
            model="deployment", prompt="hi", stream=True if public else None
        )
        list(result)
    assert raised.value.__cause__ is error
    assert raised.value.request is dispatches[0]
    assert source.closed and len(dispatches) == 1
    (event,) = audit_events(client)
    assert event["status"] == "stream_error"
    assert event["total_cost"] == 1.12


def test_finished_chat_missing_usage_returns_result_and_allows_next_call(make_client):
    requests = []

    def handle(request):
        requests.append(request)
        return wire_response(WireStream(text_events(usage=False)))

    client = make_client(handle, internal_streaming=True)
    result = client.get_genai_completion(model="deployment", prompt="hi")
    assert result.usage is None
    assert client.get_genai_completion(model="deployment", prompt="hi").usage is None
    assert len(requests) == 2
    for event in audit_events(client):
        assert event["status"] == "usage_missing"
        assert event["total_cost"] is None


@pytest.mark.parametrize(
    "event,error_type",
    [
        (
            {
                "type": "error",
                "sequence_number": 0,
                "code": "bad",
                "message": "private response",
                "param": None,
            },
            StreamEventError,
        ),
        ({"error": {"message": "synthetic", "code": "bad"}}, APIError),
        (
            {
                "type": "response.completed",
                "sequence_number": 1,
                "response": response_payload("incomplete"),
            },
            StreamAssemblyError,
        ),
        ({"type": "response.completed", "sequence_number": 1}, StreamAssemblyError),
        (
            {
                "type": "response.output_text.delta",
                "sequence_number": 0,
                "delta": "partial",
                "item_id": "m",
                "output_index": 0,
                "content_index": 0,
            },
            UnexpectedStreamEndError,
        ),
    ],
)
def test_responses_error_and_missing_terminal(make_client, event, error_type):
    source = WireStream([event], done=False)
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with pytest.raises(error_type) as raised:
        client.get_genai_response(model="deployment", input="hi")
    if error_type is StreamEventError:
        assert event["message"] in str(raised.value)
        assert raised.value.body == event
    assert source.closed
    assert len(audit_events(client)) == 1


@pytest.mark.parametrize(
    "payload",
    [
        {"extra_body": {"model": "unpriced"}},
        {"extra_query": {"api-version": "2024-12-01-preview"}},
        {"stream": True, "extra_body": {"stream": False}},
        {"internal_streaming": True},
    ],
)
def test_conflicting_overrides_fail_before_dispatch(make_client, payload):
    client = make_client(
        lambda _: pytest.fail("must not dispatch"), internal_streaming=True
    )
    with pytest.raises(ValueError):
        client.get_genai_completion(model="deployment", prompt="hi", **payload)
    assert audit_events(client) == []


def test_extra_body_pricing_and_background_cannot_bypass_preflight(make_client):
    client = make_client(
        lambda _: pytest.fail("must not dispatch"), internal_streaming=True
    )
    with pytest.raises(UnpricedModelError):
        client.get_genai_completion(prompt="hi", extra_body={"model": "unpriced"})
    with pytest.raises(ValueError, match="Background"):
        client.get_genai_response(
            model="deployment", input="hi", extra_body={"background": True}
        )
    assert audit_events(client) == []


@pytest.mark.parametrize(
    "payload",
    [
        {
            "modalities": ["text", "audio"],
            "audio": {"format": "wav", "voice": "alloy"},
        },
        {"tools": [{"type": "custom", "custom": {"name": "test"}}]},
        {"web_search_options": {}},
        {"extra_body": {"provider_extension": True}},
    ],
)
def test_unsupported_ordinary_modes_choose_native_before_dispatch(make_client, payload):
    requests = []

    def handle(request):
        requests.append(json.loads(request.content))
        assert not requests[-1].get("stream")
        return httpx2.Response(200, json=chat_payload())

    client = make_client(handle, internal_streaming=True)
    assert (
        client.get_genai_completion(model="deployment", prompt="hi", **payload)
        .choices[0]
        .message.content
        == "Hello"
    )
    assert len(requests) == 1
    assert audit_events(client)[0]["status"] == "completed"


@pytest.mark.parametrize("value", ["true", 1, None, []])
def test_trusted_transport_flag_requires_boolean(make_client, value):
    with pytest.raises(ValueError, match="boolean"):
        make_client(
            lambda _: pytest.fail("must not dispatch"), internal_streaming=value
        )


@pytest.mark.parametrize("operation", ["chat", "responses"])
def test_internal_streaming_does_not_read_sdk_version(
    make_client, monkeypatch, operation
):
    monkeypatch.delattr(openai, "__version__")
    requests = []

    def handle(request):
        requests.append(json.loads(request.content))
        assert requests[-1]["stream"] is True
        if operation == "chat":
            return wire_response(WireStream(text_events()))
        return wire_response(
            WireStream(
                [
                    {
                        "type": "response.completed",
                        "sequence_number": 0,
                        "response": response_payload(),
                    }
                ]
            )
        )

    client = make_client(handle, internal_streaming=True)
    if operation == "chat":
        result = client.get_genai_completion(model="deployment", prompt="hi")
        assert result.id == "chatcmpl-synthetic"
    else:
        result = client.get_genai_response(model="deployment", input="hi")
        assert result.id == "resp_synthetic"
    assert len(requests) == 1
    assert audit_events(client)[0]["status"] == "completed"


def test_response_terminal_cleanup_failure_does_not_replace_result(make_client, caplog):
    source = WireStream(
        [
            {
                "type": "response.completed",
                "sequence_number": 0,
                "response": response_payload(),
            }
        ]
    )

    def close():
        source.closed = True
        raise OSError("private response or endpoint")

    source.close = close
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    result = client.get_genai_response(model="deployment", input="hi")
    assert result.status == "completed"
    assert source.closed
    assert "private response" not in caplog.text
    assert audit_events(client)[0]["total_cost"] == 1.12


@pytest.mark.parametrize("operation", ["chat", "responses"])
def test_hidden_result_preserves_known_cost_when_audit_queue_rejects(
    make_client, monkeypatch, operation
):
    events = (
        text_events()
        if operation == "chat"
        else [
            {
                "type": "response.completed",
                "sequence_number": 0,
                "response": response_payload(),
            }
        ]
    )
    client = make_client(
        lambda _: wire_response(WireStream(events)), internal_streaming=True
    )

    def reject(*args):
        raise RuntimeError("synthetic queue error")

    with monkeypatch.context() as patch:
        patch.setattr(client.log_manager._queue, "put_nowait", reject)
        if operation == "chat":
            result = client.get_genai_completion(model="deployment", prompt="hi")
        else:
            result = client.get_genai_response(model="deployment", input="hi")
    assert result.id
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "0"
    assert client.log_manager.get_metrics()["enqueue_errors"] == 1
    assert client.log_manager.get_metrics()["request_status_counts"] == {"completed": 1}
    assert audit_events(client) == []


def test_usage_charge_occurs_on_finalization_day(make_client, monkeypatch):
    import datetime

    real_datetime = datetime.datetime
    now = [real_datetime(2026, 10, 1, 23, 59, 59)]

    class Clock(real_datetime):
        @classmethod
        def now(cls, tz=None):
            return now[0].astimezone(tz) if tz else now[0]

    monkeypatch.setattr("genai_api_manager.genai_api_logger.datetime.datetime", Clock)
    client = make_client(lambda _: wire_response(WireStream(text_events())))
    first_key = client.log_manager._accounting_key()
    stream = client.get_genai_completion(model="deployment", prompt="hi", stream=True)
    assert next(stream).choices
    assert next(stream).choices[0].finish_reason == "stop"
    assert next(stream).usage is not None
    assert Decimal(client.log_manager.get_metrics()["daily_cost_exact"]) == 0
    now[0] = real_datetime(2026, 10, 2, 0, 0, 1)
    assert list(stream) == []
    assert client.log_manager._budget.snapshot(first_key) == 0
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "1.12"
    assert len(audit_events(client)) == 1


def test_hidden_usage_extensions_and_invalid_details_remain_observable(make_client):
    events = text_events()
    events[-1]["usage"]["prompt_tokens_details"] = {
        "cached_tokens": 600,
        "cache_write_tokens": 300,
    }
    events[-1]["usage"]["completion_tokens_details"] = {"reasoning_tokens": 100}
    client = make_client(
        lambda _: wire_response(WireStream(events)),
        internal_streaming=True,
        pricing_data={
            "deployment": {
                "input": "1",
                "cached_input": "0.2",
                "cache_write": "1.25",
                "output": "3",
            }
        },
    )
    result = client.get_genai_completion(model="deployment", prompt="hi")
    assert result.usage.prompt_tokens_details.cache_write_tokens == 300
    assert result.usage.completion_tokens_details.reasoning_tokens == 100
    event = audit_events(client)[0]
    assert event["total_cost"] == 1.195
    assert event["cache_write_token"] == 300


def test_request_options_preserved_and_equal_extras_normalized(make_client):
    seen = []

    def handle(request):
        seen.append(json.loads(request.content))
        assert "api-version" not in request.url.params
        return wire_response(WireStream(text_events()))

    client = make_client(handle, internal_streaming=True)
    payload = {
        "model": "deployment",
        "messages": [{"role": "user", "content": "hi"}],
        "store": False,
        "timeout": 12,
        "stream_options": {"include_obfuscation": False},
        "extra_body": {"model": "deployment"},
        "extra_query": {"synthetic-option": "value"},
    }
    before = deepcopy(payload)
    client.get_genai_completion(request=payload)
    assert payload == before
    assert seen[0]["stream"] is True
    assert seen[0]["stream_options"] == {
        "include_usage": True,
        "include_obfuscation": False,
    }
    assert seen[0]["store"] is False
