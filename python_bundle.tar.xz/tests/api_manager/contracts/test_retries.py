"""Constructor retry policy through the locked SDK over mocked Azure HTTP.

The SDK owns retry eligibility and backoff. No production requests or sleeps.
"""

from copy import deepcopy
from decimal import Decimal
import json
from unittest.mock import Mock

import httpx2
from openai import APIConnectionError, APIStatusError, OpenAI
from openai import _base_client
import pytest

from genai_api_manager import GenAiApiClient
from genai_api_manager import genai_api_client as client_module
from genai_api_manager.api import azure as azure_module
from tests.support.client import audit_events
from tests.support.standard import standard_handler


def invoke(client, api, **options):
    if api == "chat":
        return client.get_genai_completion(
            model="deployment", prompt="hi", stream=False, **options
        )
    if api == "responses":
        return client.get_genai_response(
            model="deployment", input="hi", stream=False, **options
        )
    return client.get_genai_embeddings(model="deployment", input="hi", **options)


@pytest.mark.parametrize(
    "options", [{}, {"max_retries": None}, {"max_retries": 0}, {"max_retries": 3}]
)
def test_constructor_preserves_sdk_default_or_passes_explicit_retries(
    make_client, monkeypatch, options
):
    # Seed only synthetic configuration/authentication; inspect the real constructor
    # without the usual fixture's zero-retry SDK override.
    make_client(standard_handler()).close()
    constructors = []

    def construct(**kwargs):
        constructors.append(kwargs)
        return OpenAI(
            **kwargs,
            http_client=httpx2.Client(
                transport=httpx2.MockTransport(standard_handler())
            ),
        )

    monkeypatch.setattr(azure_module, "OpenAI", construct)
    with GenAiApiClient(7.0, **options) as client:
        retries = options.get("max_retries")
        assert client._openai_client.max_retries == (2 if retries is None else retries)
        assert client.log_manager.daily_cost_limit == 7.0
        assert ("max_retries" in constructors[0]) is (retries is not None)
        if retries is not None:
            assert constructors[0]["max_retries"] == retries


@pytest.mark.parametrize("value", [-1, True, False, 1.0, "2", [], {}])
def test_invalid_retries_fail_before_loading_configuration(monkeypatch, value):
    load = Mock(side_effect=AssertionError("Must validate before setup"))
    monkeypatch.setattr(client_module, "load_config", load)
    with pytest.raises(ValueError, match="max_retries must be a nonnegative integer"):
        GenAiApiClient(max_retries=value)
    load.assert_not_called()


@pytest.mark.parametrize("api", ["chat", "responses", "embeddings"])
@pytest.mark.parametrize("failure", [408, 409, 429, 500, 503, "timeout", "connection"])
def test_sdk_retries_then_accounts_once(make_client, retry_delays, api, failure):
    requests = []
    success = standard_handler()

    def handle(request):
        requests.append(request)
        if len(requests) <= 2:
            if failure in ("timeout", "connection"):
                error = (
                    httpx2.ReadTimeout if failure == "timeout" else httpx2.ConnectError
                )
                raise error("Synthetic transport failure", request=request)
            return httpx2.Response(
                failure, json={"error": {"message": "Synthetic failure"}}
            )
        return success(request)

    client = make_client(handle, manager_options={"max_retries": 2})
    result = invoke(client, api)
    assert result.usage is not None
    assert len(requests) == 3 and len(retry_delays) == 2
    assert all(delay > 0 for delay in retry_delays)
    assert all(request.content == requests[0].content for request in requests)
    assert all(request.url == requests[0].url for request in requests)
    assert "max_retries" not in json.loads(requests[0].content)
    (event,) = audit_events(client)
    expected = Decimal("0.01" if api == "embeddings" else "1.12")
    assert Decimal(str(event["total_cost"])) == expected
    assert Decimal(client.log_manager.get_metrics()["daily_cost_exact"]) == expected
    assert event["status"] == "completed"


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("retries", [0, 2])
@pytest.mark.parametrize("failure", [429, "connection"])
def test_retry_exhaustion_preserves_final_error_and_does_not_account(
    make_client, retry_delays, api, retries, failure
):
    requests, errors = [], []

    def handle(request):
        requests.append(request)
        if failure == "connection":
            error = httpx2.ConnectError("Synthetic connection failure", request=request)
            errors.append(error)
            raise error
        return httpx2.Response(
            failure,
            headers={"x-request-id": f"failed-{len(requests)}"},
            json={
                "error": {"message": "Full synthetic failure", "attempt": len(requests)}
            },
        )

    client = make_client(handle, manager_options={"max_retries": retries})
    with pytest.raises(
        APIConnectionError if failure == "connection" else APIStatusError
    ) as caught:
        invoke(client, api)
    assert len(requests) == retries + 1 and len(retry_delays) == retries
    if failure == "connection":
        assert caught.value.__cause__ is errors[-1]
    else:
        assert caught.value.body == {
            "message": "Full synthetic failure",
            "attempt": retries + 1,
        }
        assert caught.value.request_id == f"failed-{retries + 1}"
    assert client.log_manager.check_daily_cost() == 0
    assert audit_events(client) == []


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize(
    "status,headers,attempts,delay",
    [
        (400, {}, 1, None),
        (401, {}, 1, None),
        (403, {}, 1, None),
        (404, {}, 1, None),
        (429, {"x-should-retry": "false"}, 1, None),
        (400, {"x-should-retry": "true", "retry-after": "2"}, 2, 2.0),
        (429, {"retry-after-ms": "1500"}, 2, 1.5),
    ],
)
def test_sdk_status_and_retry_headers_are_respected(
    make_client, retry_delays, api, status, headers, attempts, delay
):
    requests = []
    success = standard_handler()

    def handle(request):
        requests.append(request)
        if len(requests) == 1:
            return httpx2.Response(
                status,
                headers=headers,
                json={"error": {"message": "Synthetic failure"}},
            )
        return success(request)

    client = make_client(handle, manager_options={"max_retries": 3})
    if attempts == 1:
        with pytest.raises(APIStatusError) as caught:
            invoke(client, api)
        assert caught.value.status_code == status
    else:
        invoke(client, api)
    assert len(requests) == attempts
    assert retry_delays == ([] if delay is None else [delay])
    assert len(audit_events(client)) == attempts - 1


@pytest.mark.parametrize("api", ["chat", "responses", "embeddings"])
@pytest.mark.parametrize("location", ["keyword", "request", "extra_body"])
@pytest.mark.parametrize("value", [None, 2])
def test_request_level_retries_are_rejected(make_client, api, location, value):
    handler = Mock(side_effect=AssertionError("Must not dispatch"))
    client = make_client(handler, manager_options={"max_retries": 1})
    options = {"max_retries": value}
    if location != "keyword":
        options = {location: options}
    before = deepcopy(options)
    with pytest.raises(ValueError, match="max_retries on the client constructor"):
        invoke(client, api, **options)
    assert options == before
    handler.assert_not_called()
    assert client._openai_client.max_retries == 1
    assert audit_events(client) == []


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("random_value", [0.0, 1.0])
def test_sdk_exponential_backoff_jitter_and_cap(
    make_client, monkeypatch, retry_delays, api, random_value
):
    # Lock the random source, not the algorithm: exercise the pinned SDK's waits.
    monkeypatch.setattr(_base_client, "random", lambda: random_value)
    handler = Mock(
        return_value=httpx2.Response(429, json={"error": {"message": "Busy"}})
    )
    client = make_client(handler, manager_options={"max_retries": 6})
    with pytest.raises(APIStatusError):
        invoke(client, api)
    assert handler.call_count == 7
    assert retry_delays == [
        delay * (1 - 0.25 * random_value) for delay in (0.5, 1, 2, 4, 8, 8)
    ]
    assert audit_events(client) == []


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize(
    "headers,expected",
    [
        ({"retry-after-ms": "1250", "retry-after": "10"}, [1.25]),
        ({"retry-after": "Sun, 04 Oct 2026 00:00:02 GMT"}, [2.0]),
        ({"retry-after": "invalid"}, [0.5]),
        ({"retry-after": "0"}, [0.5]),
        ({"retry-after": "-1"}, [0.5]),
        ({"retry-after": "nan"}, [0.5]),
        ({"retry-after": "121"}, []),
        ({"retry-after": "1e999"}, []),
    ],
)
def test_retry_after_precedence_dates_invalid_and_excessive_delays(
    make_client, monkeypatch, retry_delays, api, headers, expected
):
    monkeypatch.setattr(_base_client, "random", lambda: 0.0)
    monkeypatch.setattr(_base_client.time, "time", lambda: 1791072000.0)
    handler = Mock(
        return_value=httpx2.Response(
            429, headers=headers, json={"error": {"message": "Busy"}}
        )
    )
    client = make_client(handler, manager_options={"max_retries": 1})
    with pytest.raises(APIStatusError):
        invoke(client, api)
    assert retry_delays == expected
    assert handler.call_count == len(expected) + 1
    assert audit_events(client) == []
