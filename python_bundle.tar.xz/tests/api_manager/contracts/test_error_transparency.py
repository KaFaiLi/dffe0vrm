"""Full caller errors through the actual locked SDK; diagnostics stay content-free."""

import json

import httpx2
import pytest
from openai import APIStatusError

from genai_api_manager import (
    StreamAssemblyError,
    StreamEventError,
    UnexpectedStreamEndError,
)
from genai_api_manager.api.streams import LoggedResponseStream

from tests.support.client import audit_events
from tests.support.azure import embedding_payload, response_payload
from tests.support.azure import WireStream, choice, chunk, text_events, wire_response


@pytest.mark.parametrize(
    "operation,mode",
    [
        (api, mode)
        for api in ("chat", "responses")
        for mode in ("native", "internal", "public")
    ]
    + [("embeddings", "native")],
)
@pytest.mark.parametrize("status_code", [400, 403, 429, 500])
def test_http_error_reaches_caller_unchanged(
    make_client, monkeypatch, operation, mode, status_code
):
    payload = {
        "error": {
            "message": "Full synthetic provider explanation",
            "code": "synthetic_error",
            "type": "synthetic_type",
            "param": "model",
            "innererror": {"detail": ["first detail", "second detail"]},
        },
        "provider_extension": "also retained in HTTP response",
    }
    requests = []

    def handle(request):
        requests.append(request)
        if len(requests) > 1:
            return httpx2.Response(200, json=embedding_payload("second-deployment"))
        return httpx2.Response(
            status_code,
            json=payload,
            headers={"x-request-id": "http-error-id", "retry-after": "7"},
        )

    client = make_client(
        handle,
        internal_streaming=mode == "internal",
        pricing_data={
            "deployment": {"input": "1", "output": "3"},
            "second-deployment": {"input": "1", "output": "0"},
        },
    )
    resource = (
        client._openai_client.chat.completions
        if operation == "chat"
        else getattr(client._openai_client, operation)
    )
    create = resource.create
    originals = []

    def capture(**kwargs):
        try:
            return create(**kwargs)
        except APIStatusError as error:
            originals.append(error)
            raise

    monkeypatch.setattr(resource, "create", capture)
    with pytest.raises(APIStatusError) as raised:
        if operation == "chat":
            client.get_genai_completion(
                model="deployment",
                prompt="hi",
                stream=True if mode == "public" else None,
            )
        elif operation == "responses":
            client.get_genai_response(
                model="deployment",
                input="hi",
                stream=True if mode == "public" else None,
            )
        else:
            client.get_genai_embeddings(model="deployment", input="hi")
    error = raised.value
    assert error is originals[0]
    assert error.status_code == status_code
    assert error.body == payload["error"]
    assert error.response.json() == payload
    assert error.response.headers["retry-after"] == "7"
    assert error.request_id == "http-error-id"
    assert (error.code, error.type, error.param) == (
        "synthetic_error",
        "synthetic_type",
        "model",
    )
    assert payload["error"]["message"] in str(error)
    assert len(requests) == 1
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "0"
    assert client.log_manager.get_metrics()["request_status_counts"] == {}
    assert client.get_genai_embeddings(
        model="second-deployment",
        input="hi",
        encoding_format="float",
        embeddings_only=True,
    ) == [0.1, 0.2]
    assert len(requests) == 2
    (event,) = audit_events(client)
    assert event["model_name"] == "second-deployment"
    assert event["operation"] == "embeddings"


def test_typed_error_exposes_original_event_and_full_body(
    make_client, monkeypatch, caplog
):
    payload = {
        "type": "error",
        "sequence_number": 7,
        "code": "invalid_request",
        "param": "input",
        "message": "Synthetic private provider explanation",
        "provider_extension": {"reason": "Full explanation " * 200},
    }
    observed = []
    observe = LoggedResponseStream._observe

    def capture(self, event):
        observed.append(event)
        observe(self, event)

    monkeypatch.setattr(LoggedResponseStream, "_observe", capture)
    source = WireStream([payload], named=True)
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with pytest.raises(StreamEventError) as raised:
        client.get_genai_response(model="deployment", input="hi")
    error = raised.value
    assert error.event is observed[0]
    assert error.body == payload
    assert error.message == payload["message"]
    assert (error.code, error.param, error.sequence_number) == (
        "invalid_request",
        "input",
        7,
    )
    assert payload["message"] in str(error)
    assert payload["provider_extension"]["reason"] in str(error)
    assert error.request_id == "request-synthetic"
    assert error.events_observed == 1
    assert source.closed
    audits = audit_events(client)
    assert len(audits) == 1
    assert audits[0]["status"] == "stream_error"
    assert payload["message"] not in json.dumps(audits)
    assert payload["message"] not in caplog.text


@pytest.mark.parametrize("failure", ["status", "id", "missing_response", "output"])
def test_malformed_terminal_retains_full_payload_and_validation_reason(
    make_client, failure
):
    first = {
        "type": "response.created",
        "sequence_number": 0,
        "response": response_payload("in_progress"),
    }
    payload = {
        "type": "response.completed",
        "sequence_number": 1,
        "response": response_payload(),
    }
    payload["response"]["provider_extension"] = {"detail": "synthetic private detail"}
    if failure == "status":
        payload["response"]["status"] = "in_progress"
    elif failure == "id":
        payload["response"]["id"] = "unexpected-id"
    elif failure == "output":
        payload["response"]["output"] = None
    else:
        del payload["response"]
    source = WireStream([first, payload])
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with pytest.raises(StreamAssemblyError) as raised:
        client.get_genai_response(model="deployment", input="hi")
    error = raised.value
    field = "response" if failure == "missing_response" else f"response.{failure}"
    assert field in error.details
    assert field in str(error)
    assert error.body == payload
    if failure == "status":
        assert error.details[field] == {
            "expected": "completed",
            "actual": "in_progress",
        }
    elif failure == "id":
        assert error.details[field] == {
            "expected": "resp_synthetic",
            "actual": "unexpected-id",
        }
    assert error.request_id == "request-synthetic"
    assert error.events_observed == 2
    assert source.closed and source.reads == 2
    (audit,) = audit_events(client)
    assert audit["status"] == "assembly_error"
    assert audit["total_cost"] == (None if failure == "missing_response" else 1.12)
    if failure != "missing_response":
        assert error.usage is error.event.response.usage


def test_chat_conflict_retains_both_values_and_usage_despite_sink_cleanup_errors(
    make_client, monkeypatch, caplog
):
    events = text_events() + [
        chunk([], vendor={"detail": "first"}),
        chunk([], vendor={"detail": "changed private detail"}),
    ]
    source = WireStream(events)

    def close():
        source.closed = True
        raise OSError("private cleanup failure")

    def reject(*args):
        raise RuntimeError("private queue failure")

    source.close = close
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    monkeypatch.setattr(client.log_manager._queue, "put_nowait", reject)
    with pytest.raises(StreamAssemblyError) as raised:
        client.get_genai_completion(model="deployment", prompt="hi")
    error = raised.value
    assert error.details == {
        "field": "vendor.detail",
        "previous": "first",
        "actual": "changed private detail",
    }
    assert error.body == events[-1]
    assert error.usage.prompt_tokens == 1000
    assert error.response_id == "chatcmpl-synthetic"
    assert source.closed
    metrics = client.log_manager.get_metrics()
    assert metrics["daily_cost_exact"] == "0"
    assert metrics["enqueue_errors"] == 1
    assert metrics["request_status_counts"] == {"assembly_error": 1}
    assert "private" not in caplog.text


@pytest.mark.parametrize(
    "operation,empty",
    [(api, empty) for api in ("chat", "responses") for empty in (True, False)],
)
def test_clean_early_eof_exposes_last_event_and_missing_completion(
    make_client, operation, empty
):
    event = (
        chunk([choice({"content": "partial"})])
        if operation == "chat"
        else {
            "type": "response.output_text.delta",
            "sequence_number": 0,
            "item_id": "msg",
            "output_index": 0,
            "content_index": 0,
            "delta": "partial",
        }
    )
    source = WireStream([] if empty else [event], done=False)
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with pytest.raises(UnexpectedStreamEndError) as raised:
        if operation == "chat":
            client.get_genai_completion(model="deployment", prompt="hi")
        else:
            client.get_genai_response(model="deployment", input="hi")
    error = raised.value
    assert error.body == (None if empty else event)
    assert error.events_observed == (0 if empty else 1)
    assert error.request_id == "request-synthetic"
    assert error.usage is None
    if operation == "chat":
        assert error.details["expected_choices"] == 1
        assert error.details["finish_reasons"] == ({} if empty else {0: None})
    assert source.closed
    assert audit_events(client)[0]["status"] == "interrupted"


def test_assembly_failure_preserves_cause(make_client):
    events = text_events() + [chunk([choice({"tool_calls": 42})])]
    source = WireStream(events)
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with pytest.raises(StreamAssemblyError) as raised:
        client.get_genai_completion(model="deployment", prompt="hi")
    assert isinstance(raised.value.__cause__, TypeError)
    assert str(raised.value.__cause__) in str(raised.value)
    assert raised.value.body == events[-1]
    assert audit_events(client)[0]["total_cost"] == 1.12


def test_public_typed_error_remains_an_original_sdk_event(make_client):
    payload = {
        "type": "error",
        "sequence_number": 0,
        "code": "bad",
        "param": None,
        "message": "full error",
    }
    source = WireStream([payload])
    client = make_client(lambda _: wire_response(source), internal_streaming=True)
    with client.get_genai_response(
        model="deployment", input="hi", stream=True
    ) as stream:
        (event,) = list(stream)
    assert event.model_dump(exclude_unset=True) == payload
    assert source.closed
    assert audit_events(client)[0]["status"] == "stream_error"
