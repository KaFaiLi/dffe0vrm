"""Azure GA v1 routing through the real SDK; synthetic JSON/SSE, no live calls."""

import json

import httpx2
import pytest
from openai import APIStatusError, OpenAI

from genai_api_manager import GenAiApiClient
from genai_api_manager import genai_api_client as client_module
from tests.support.client import audit_events
from tests.support.azure import (
    WireStream,
    chat_payload,
    response_payload,
    text_events,
    wire_response,
)


@pytest.mark.parametrize(
    "operation,mode",
    [
        (api, mode)
        for api in ("chat", "responses")
        for mode in ("native", "internal", "public")
    ]
    + [("embeddings", "native")],
)
@pytest.mark.parametrize(
    "endpoint",
    [
        "https://synthetic.openai.azure.com",
        "https://synthetic.services.ai.azure.com/",
        "https://synthetic.openai.azure.com/openai/v1",
        "https://synthetic.openai.azure.com/openai/v1/",
        "https://gateway.example.invalid/azure-resource",
        "https://gateway.example.invalid/azure-resource/openai/v1/",
    ],
)
def test_all_operations_use_v1_routes_and_deployment_body(
    make_client, operation, mode, endpoint
):
    requests = []
    prefix = "/azure-resource" if "gateway" in endpoint else ""
    path = {
        "chat": "chat/completions",
        "responses": "responses",
        "embeddings": "embeddings",
    }[operation]

    def handle(request):
        requests.append(request)
        assert request.url.path == f"{prefix}/openai/v1/{path}"
        assert "api-version" not in request.url.params
        assert request.headers["authorization"] == "Bearer synthetic-token"
        assert "api-key" not in request.headers
        payload = json.loads(request.content)
        assert payload["model"] == "azure-alias"
        assert bool(payload.get("stream")) is (mode != "native")
        if operation == "chat":
            return (
                wire_response(WireStream(text_events()))
                if mode != "native"
                else httpx2.Response(200, json=chat_payload())
            )
        if operation == "responses":
            if mode != "native":
                return wire_response(
                    WireStream(
                        [
                            {
                                "type": "response.completed",
                                "sequence_number": 0,
                                "response": response_payload(),
                            }
                        ],
                        named=True,
                    )
                )
            return httpx2.Response(200, json=response_payload())
        return httpx2.Response(
            200,
            json={
                "object": "list",
                "model": "azure-alias",
                "data": [{"object": "embedding", "index": 0, "embedding": [0.1, 0.2]}],
                "usage": {"prompt_tokens": 10, "total_tokens": 10},
            },
        )

    client = make_client(
        handle,
        endpoint=endpoint,
        internal_streaming=mode == "internal",
        pricing_aliases={"azure-alias": "deployment"},
    )
    assert type(client._openai_client) is OpenAI
    assert client.api_version == "v1"
    if operation == "chat":
        result = client.get_genai_completion(
            model="azure-alias", prompt="hi", stream=True if mode == "public" else None
        )
    elif operation == "responses":
        result = client.get_genai_response(
            model="azure-alias", input="hi", stream=True if mode == "public" else None
        )
    else:
        result = client.get_genai_embeddings(
            model="azure-alias", input="hi", encoding_format="float"
        )
    if mode == "public":
        with result:
            list(result)
    assert len(requests) == 1
    (event,) = audit_events(client)
    assert event["model_name"] == "azure-alias"
    assert event["total_cost"] == (0.01 if operation == "embeddings" else 1.12)


@pytest.mark.parametrize("operation", ["chat", "responses", "embeddings"])
def test_entra_provider_is_refreshed_for_each_request(
    make_client, monkeypatch, operation
):
    scopes, headers = [], []
    tokens = iter(["synthetic-first", "synthetic-refreshed"])

    def provider(credential, scope):
        scopes.append(scope)
        return lambda: next(tokens)

    monkeypatch.setattr(client_module, "get_bearer_token_provider", provider)

    def handle(request):
        headers.append(request.headers["authorization"])
        if operation == "chat":
            return httpx2.Response(200, json=chat_payload())
        if operation == "responses":
            return httpx2.Response(200, json=response_payload())
        return httpx2.Response(
            200,
            json={
                "object": "list",
                "model": "deployment",
                "data": [{"object": "embedding", "index": 0, "embedding": [0.1]}],
                "usage": {"prompt_tokens": 1, "total_tokens": 1},
            },
        )

    client = make_client(handle)
    for _ in range(2):
        if operation == "chat":
            client.get_genai_completion(model="deployment", prompt="hi")
        elif operation == "responses":
            client.get_genai_response(model="deployment", input="hi")
        else:
            client.get_genai_embeddings(
                model="deployment", input="hi", encoding_format="float"
            )
    assert scopes == ["https://ai.azure.com/.default"]
    assert headers == ["Bearer synthetic-first", "Bearer synthetic-refreshed"]
    assert len(audit_events(client)) == 2


@pytest.mark.parametrize("mode", ["native", "internal", "public"])
@pytest.mark.parametrize("status_code", [400, 403, 404, 429])
def test_v1_server_rejection_preserves_sdk_error_without_replay_or_accounting(
    make_client, mode, status_code
):
    requests = []

    def handle(request):
        requests.append(request)
        assert request.url.path == "/openai/v1/responses"
        assert "api-version" not in request.url.params
        return httpx2.Response(
            status_code,
            json={
                "error": {
                    "code": "SyntheticRejection",
                    "message": "Full synthetic Azure error",
                    "details": "retained",
                }
            },
        )

    client = make_client(handle, internal_streaming=mode == "internal")
    with pytest.raises(APIStatusError) as raised:
        client.get_genai_response(
            model="deployment", input="hi", stream=True if mode == "public" else None
        )
    assert raised.value.status_code == status_code
    assert raised.value.body["details"] == "retained"
    assert len(requests) == 1
    assert not client.log_manager.budget_exceeded()
    assert audit_events(client) == []


@pytest.mark.parametrize("operation", ["chat", "responses", "embeddings"])
@pytest.mark.parametrize("version", ["v1", "2025-04-01-preview", None])
def test_per_request_api_version_is_rejected_before_dispatch(
    make_client, operation, version
):
    client = make_client(lambda _: pytest.fail("Must not dispatch"))
    call = {
        "chat": client.get_genai_completion,
        "responses": client.get_genai_response,
        "embeddings": client.get_genai_embeddings,
    }[operation]
    request = (
        {"model": "deployment", "messages": [{"role": "user", "content": "hi"}]}
        if operation == "chat"
        else {"model": "deployment", "input": "hi"}
    )
    request["extra_query"] = {"api-version": version}
    with pytest.raises(ValueError, match="v1 does not use an api-version"):
        call(request=request)
    assert audit_events(client) == []


@pytest.mark.parametrize(
    "endpoint",
    [
        None,
        "",
        "http://synthetic.openai.azure.com",
        "https://synthetic.openai.azure.com/?api-version=old",
        "https://synthetic.openai.azure.com/#fragment",
        "https://synthetic:secret@synthetic.openai.azure.com",
    ],
)
def test_invalid_v1_endpoint_fails_before_authentication_or_proxy(
    make_client, monkeypatch, endpoint
):
    monkeypatch.setattr(
        GenAiApiClient,
        "_ensure_px_running",
        lambda _: pytest.fail("Must not start proxy"),
    )
    with pytest.raises(ValueError, match="Azure v1 requires an HTTPS endpoint"):
        make_client(lambda _: pytest.fail("Must not dispatch"), endpoint=endpoint)
