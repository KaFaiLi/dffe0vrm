"""Characterize why the locked SDK helper is not our compatibility collector.

These assertions intentionally document 2.54.0 behavior for future SDK upgrades.
Package tests cover the corresponding successful plain-object results separately.
"""

import pytest
from openai import ContentFilterFinishReasonError, LengthFinishReasonError
from openai.lib.streaming.chat._completions import ChatCompletionStreamState
from openai.types.chat import ChatCompletionChunk

from tests.support.azure import chunk, choice, text_events, tool


def feed(state, events):
    for event in events:
        state.handle_chunk(ChatCompletionChunk.construct(**event))


def test_helper_assumes_first_choice_is_list_position_zero():
    state = ChatCompletionStreamState()
    with pytest.raises(IndexError):
        feed(state, [chunk([choice({"content": "x"}, index=1)])])


def test_helper_concatenates_repeated_tool_identity():
    state = ChatCompletionStreamState()
    feed(
        state,
        [
            chunk(
                [choice({"tool_calls": [tool(0, id="same", name="f", arguments="x")]})]
            ),
            chunk(
                [
                    choice(
                        {"tool_calls": [tool(0, id="same", arguments="y")]},
                        finish="tool_calls",
                    )
                ]
            ),
        ],
    )
    assert (
        state.current_completion_snapshot.choices[0].message.tool_calls[0].id
        == "samesame"
    )


def test_helper_keeps_empty_initial_annotation_identity():
    state = ChatCompletionStreamState()
    feed(
        state,
        [
            {
                "id": "",
                "object": "",
                "created": 0,
                "model": "",
                "choices": [],
                "prompt_filter_results": [],
            },
            *text_events(),
        ],
    )
    assert state.current_completion_snapshot.id == ""


@pytest.mark.parametrize(
    "reason,error",
    [
        ("length", LengthFinishReasonError),
        ("content_filter", ContentFilterFinishReasonError),
    ],
)
def test_helper_final_parse_raises_even_without_parsing_options(reason, error):
    state = ChatCompletionStreamState()
    feed(
        state,
        [
            chunk([choice({"role": "assistant", "content": "hi"})]),
            chunk([choice({}, finish=reason)]),
        ],
    )
    assert hasattr(state.current_completion_snapshot.choices[0].message, "parsed")
    with pytest.raises(error):
        state.get_final_completion()
