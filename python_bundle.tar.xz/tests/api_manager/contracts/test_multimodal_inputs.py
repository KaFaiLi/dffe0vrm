"""Image/PDF pass-through using the production manager and actual v1 SDK.

Schemas: official OpenAI image/file-input guides and Azure Responses reference.
Synthetic replies test transport/accounting, not live model perception.
"""

import base64
from copy import deepcopy
from decimal import Decimal
import json

import httpx2
from openai import APIStatusError
from openai.types.chat import ChatCompletion, ChatCompletionChunk
from openai.types.responses import Response, ResponseCompletedEvent
import pytest

from tests.support.multimodal_inputs import EXPECTED, request_for
from tests.support.standard_usage.common import _decrypt as decrypt
from tests.support.client import audit_events
from tests.support.multimodal import PRICES, provider_result


FIELDS = {
    "model_name",
    "input_token",
    "output_token",
    "input_cost",
    "output_cost",
    "total_cost",
    "status",
    "timestamp",
    "prompt",
    "completion",
    "shared_key",
    "cumulative_input_cost",
    "cumulative_output_cost",
    "cumulative_total_cost",
    "operation",
    "request_id",
    "cached_input_token",
    "cache_write_token",
    "cost_status",
}


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("case", ["image", "pdf", "image-pdf"])
@pytest.mark.parametrize("mode", ["native", "public", "internal"])
@pytest.mark.parametrize("request_style", ["dictionary", "keywords"])
def test_structured_inputs_survive_sdk_streams_encryption_and_accounting(
    make_client, api, case, mode, request_style
):
    payload = request_for(api, "deployment", case)
    if mode != "internal":
        payload["stream"] = mode == "public"
    original = deepcopy(payload)
    key = "messages" if api == "chat" else "input"
    calls, sources = [], []

    def handle(request):
        calls.append(request)
        body = json.loads(request.content)
        assert request.url.path == "/openai/v1/" + (
            "chat/completions" if api == "chat" else "responses"
        )
        assert "api-version" not in request.url.params
        assert body[key] == original[key]
        assert body["model"] == "deployment"
        assert body["stream"] is (mode != "native")
        parts = body[key][0]["content"]
        assert parts[0]["type"] == ("text" if api == "chat" else "input_text")
        if "image" in case:
            part = parts[1]
            assert part["type"] == ("image_url" if api == "chat" else "input_image")
            data = part["image_url"]["url"] if api == "chat" else part["image_url"]
            prefix, encoded = data.split(",", 1)
            assert prefix == "data:image/png;base64"
            assert base64.b64decode(encoded, validate=True).startswith(
                b"\x89PNG\r\n\x1a\n"
            )
        if "pdf" in case:
            part = parts[-1]
            assert part["type"] == ("file" if api == "chat" else "input_file")
            file = part["file"] if api == "chat" else part
            assert file["filename"] == "sample.pdf"
            prefix, encoded = file["file_data"].split(",", 1)
            assert prefix == "data:application/pdf;base64"
            data = base64.b64decode(encoded, validate=True)
            assert data.startswith(b"%PDF-1.4") and data.endswith(b"%%EOF\n")
        if api == "chat" and mode != "native":
            assert body["stream_options"]["include_usage"] is True
        response, source = provider_result(api, case, mode != "native")
        if source:
            sources.append(source)
        return response

    client = make_client(
        handle, pricing_data=PRICES, internal_streaming=mode == "internal"
    )
    call = client.get_genai_completion if api == "chat" else client.get_genai_response
    result = call(request=payload) if request_style == "dictionary" else call(**payload)
    if mode == "public":
        assert sources[0].reads == 0
        with result:
            events = list(result)
        result.close()
        result.close()
        assert isinstance(
            events[-1], ChatCompletionChunk if api == "chat" else ResponseCompletedEvent
        )
    else:
        assert type(result) is (ChatCompletion if api == "chat" else Response)
        assert (
            result.choices[0].message.content if api == "chat" else result.output_text
        ) == EXPECTED[case]
    assert payload == original
    assert len(calls) == 1
    assert all(source.closed for source in sources)
    (event,) = audit_events(client)
    assert set(event) == FIELDS
    assert event["status"] == "completed" and event["cost_status"] == "exact"
    # 100 ordinary + 600 read + 300 write + 200 output; no image surcharge inferred.
    assert event["input_token"] == 1000 and event["output_token"] == 200
    assert event["cached_input_token"] == 600 and event["cache_write_token"] == 300
    assert event["input_cost"] == 0.595 and event["total_cost"] == 1.195
    assert Decimal(client.log_manager.get_metrics()["daily_cost_exact"]) == Decimal(
        "1.195"
    )
    assert json.loads(decrypt(event, "prompt")) == original[key]
    persisted = json.dumps(event)
    assert (
        "data:image/png;base64" not in persisted
        and "data:application/pdf;base64" not in persisted
    )
    assert "ORBIT-417" not in persisted


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("case", ["image", "pdf"])
@pytest.mark.parametrize("status", [400, 403])
def test_multimodal_sdk_rejection_does_not_block_next_call(
    make_client, api, case, status
):
    calls = []

    def handle(request):
        calls.append(request)
        if len(calls) == 1:
            return httpx2.Response(
                status,
                json={
                    "error": {
                        "message": "Full synthetic input rejection",
                        "code": "invalid_input",
                        "details": "preserved",
                    }
                },
            )
        return provider_result(api, "text", False)[0]

    client = make_client(handle, pricing_data=PRICES)
    call = client.get_genai_completion if api == "chat" else client.get_genai_response
    with pytest.raises(APIStatusError) as raised:
        call(request=request_for(api, "deployment", case))
    assert (
        raised.value.status_code == status
        and raised.value.body["details"] == "preserved"
    )
    assert client.log_manager.check_daily_cost() == 0
    assert not client.log_manager.budget_exceeded()
    call(request=request_for(api, "deployment", "text"))
    assert len(calls) == 2
    assert len(audit_events(client)) == 1


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("mode", ["native", "public", "internal"])
def test_multimodal_missing_usage_remains_unknown_and_does_not_block(
    make_client, api, mode
):
    client = make_client(
        lambda _: provider_result(
            api, "image-pdf", mode != "native", missing_usage=True
        )[0],
        pricing_data=PRICES,
        internal_streaming=mode == "internal",
    )
    call = client.get_genai_completion if api == "chat" else client.get_genai_response
    result = call(
        request=request_for(api, "deployment", "image-pdf"),
        stream=True if mode == "public" else None,
    )
    if mode == "public":
        with result:
            list(result)
    assert client.log_manager.check_daily_cost() == 0
    assert not client.log_manager.budget_exceeded()
    (event,) = audit_events(client)
    assert event["total_cost"] is None and event["cost_status"] == "usage_missing"


@pytest.mark.parametrize("case", ["image", "image-pdf"])
@pytest.mark.parametrize("mode", ["native", "public", "internal"])
def test_chat_image_usage_without_cache_write_count_remains_estimated(
    make_client, case, mode
):
    # Live v1 Chat image calls omitted cache_write_tokens; retain unknown writes.
    client = make_client(
        lambda _: provider_result(
            "chat", case, mode != "native", missing_cache_write=True
        )[0],
        pricing_data=PRICES,
        internal_streaming=mode == "internal",
    )
    result = client.get_genai_completion(
        request=request_for("chat", "deployment", case),
        stream=True if mode == "public" else None,
    )
    if mode == "public":
        with result:
            list(result)
    (event,) = audit_events(client)
    assert event["status"] == "completed"
    assert event["cache_write_token"] is None
    assert event["cost_status"] == "estimated_cache_write_unknown"
    # 600 reads at .2 + 400 remaining inputs at max(1, 1.25) + 200 outputs at 3.
    assert event["input_cost"] == 0.62 and event["total_cost"] == 1.22
    assert Decimal(client.log_manager.get_metrics()["daily_cost_exact"]) == Decimal(
        "1.22"
    )
    assert not client.log_manager.budget_exceeded()
