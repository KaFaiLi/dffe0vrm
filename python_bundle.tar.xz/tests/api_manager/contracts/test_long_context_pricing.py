"""Context pricing through the production manager and mocked Azure JSON/SSE."""

from decimal import Decimal

import httpx2
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

from genai_api_manager import AsyncLoggerConfig, GenaiAPILogger
from tests.support.azure import embedding_payload
from tests.support.client import audit_events
from tests.support.long_context import PRICING, provider_result


MODES = [
    (operation, mode)
    for operation in ("chat", "responses")
    for mode in ("native", "internal", "public")
] + [("embeddings", "native")]
AUDIT_FIELDS = {
    "request_id",
    "operation",
    "model_name",
    "input_token",
    "output_token",
    "cached_input_token",
    "cache_write_token",
    "input_cost",
    "output_cost",
    "total_cost",
    "cost_status",
    "status",
    "timestamp",
    "prompt",
    "completion",
    "shared_key",
    "cumulative_input_cost",
    "cumulative_output_cost",
    "cumulative_total_cost",
}


def invoke(client, operation, mode):
    if operation == "chat":
        return client.get_genai_completion(
            model="deployment", prompt="hi", stream=True if mode == "public" else None
        )
    if operation == "responses":
        return client.get_genai_response(
            model="deployment", input="hi", stream=True if mode == "public" else None
        )
    return client.get_genai_embeddings(model="deployment", input="hi")


@pytest.mark.parametrize("operation,mode", MODES)
@pytest.mark.parametrize("inputs", [272000, 272001])
def test_context_charge_preserves_logs_budget_equality_and_restart(
    make_client, operation, mode, inputs
):
    calls = []

    def handle(request):
        calls.append(request)
        if len(calls) == 1:
            return provider_result(operation, mode, inputs)
        return httpx2.Response(200, json=embedding_payload())

    client = make_client(
        handle,
        pricing_data=PRICING,
        pricing_aliases={"deployment": "priced"},
        internal_streaming=mode == "internal",
    )
    expected = Decimal(
        ("272" if inputs == 272000 else "544.002")
        if operation == "embeddings"
        else ("117.6" if inputs == 272000 else "234.902")
    )
    client.log_manager.daily_cost_limit = expected
    result = invoke(client, operation, mode)
    if mode == "public":
        with result:
            list(result)
        result.close()
        result.close()
    assert Decimal(client.log_manager.get_metrics()["daily_cost_exact"]) == expected
    assert not client.log_manager.budget_exceeded()
    assert client.get_genai_embeddings(
        model="deployment", input="hi", encoding_format="float", embeddings_only=True
    ) == [0.1, 0.2]
    assert client.log_manager.budget_exceeded()
    assert (
        client.get_genai_embeddings(model="deployment", input="hi")
        == "Daily cost limit exceeded."
    )
    assert len(calls) == 2
    first, second = audit_events(client)
    assert set(first) == set(second) == AUDIT_FIELDS
    assert first["input_token"] == inputs
    assert first["total_cost"] == float(expected)
    assert first["cost_status"] == "exact"
    assert first["cumulative_total_cost"] == float(expected)
    assert second["total_cost"] == 0.01

    # Recovery uses persisted amounts even if the configured rates change later.
    public_key = (
        ec.generate_private_key(ec.SECP256R1())
        .public_key()
        .public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
        )
        .decode()
    )
    restored = GenaiAPILogger(
        client.log_manager._root_log_directory,
        "",
        username=client.log_manager.username,
        public_key=public_key,
        config=AsyncLoggerConfig(async_logging_enabled=False),
        pricing_data={"deployment": {"input": "99", "output": "99"}},
    )
    try:
        assert Decimal(
            restored.get_metrics()["daily_cost_exact"]
        ) == expected + Decimal("0.01")
    finally:
        restored.close()


@pytest.mark.parametrize("operation,mode", MODES)
def test_missing_context_usage_does_not_block_next_call(make_client, operation, mode):
    calls = []

    def handle(request):
        calls.append(request)
        if len(calls) == 1:
            return provider_result(operation, mode, 300000, missing=True)
        return httpx2.Response(200, json=embedding_payload())

    client = make_client(
        handle,
        pricing_data=PRICING,
        pricing_aliases={"deployment": "priced"},
        internal_streaming=mode == "internal",
    )
    result = invoke(client, operation, mode)
    if mode == "public":
        with result:
            list(result)
    assert client.log_manager.get_metrics()["daily_cost_exact"] == "0"
    assert client.get_genai_embeddings(
        model="deployment", input="hi", encoding_format="float", embeddings_only=True
    ) == [0.1, 0.2]
    first, second = audit_events(client)
    assert first["total_cost"] is None
    assert first["cost_status"] == "usage_missing"
    assert second["total_cost"] == 0.01


def test_model_listing_prints_both_tiers_and_keeps_return_contract(make_client, capsys):
    client = make_client(
        lambda request: pytest.fail("Model listing must not dispatch"),
        pricing_data=PRICING,
    )
    assert client.get_models() == {"priced": {"input": 1.0, "output": 3.0}}
    printed = capsys.readouterr().out
    assert "priced (input <= 272,000)" in printed
    assert "priced (input > 272,000)" in printed
    assert printed.splitlines()[-1].split()[-2:] == ["2", "4.5"]
    assert client.get_models(print_models=False, exclude_substring="priced") == {}
    assert capsys.readouterr().out == ""
