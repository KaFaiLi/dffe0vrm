"""Exercise the same standard acceptance cases offline through the real SDK."""

import json

import httpx2
import pytest

from tests.support.standard_usage.api_manager import CASES
from tests.support.standard_usage.common import execute_case, selected_cases
from tests.support.standard import PRICES, standard_handler


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("internal", [False, True])
def test_standard_manager_cases(make_client, case, internal):
    sources = []
    manager = make_client(
        standard_handler(sources=sources),
        pricing_data=PRICES,
        internal_streaming=internal,
    )
    model = "embedding-deployment" if case == "embeddings" else "deployment"
    report = execute_case(manager, "genai_api_manager", case, model)
    assert report["success"], report
    assert report["attempts"] == report["audit_count"] == 1
    assert report["encryption_verified"] and report["audit_correlated"]
    assert all(source.closed for source in sources)


@pytest.mark.parametrize("failure", ["missing_usage", "incomplete", "http_error"])
def test_standard_manager_failures_are_safe_and_not_retried(make_client, failure):
    handler = (
        standard_handler(**{failure: True})
        if failure != "http_error"
        else (
            lambda _: httpx2.Response(
                429,
                json={"error": {"message": "private-secret https://private.invalid"}},
            )
        )
    )
    manager = make_client(handler, pricing_data=PRICES)
    report = execute_case(manager, "genai_api_manager", "chat-native", "deployment")
    assert not report["success"]
    assert report["attempts"] == 1
    assert "private-secret" not in json.dumps(report)
    assert "private.invalid" not in json.dumps(report)
    assert not report["logger_metrics"]["writer_alive"]


def test_case_selection_is_explicit():
    assert len(selected_cases("genai_api_manager")) == 6
    assert len(selected_cases("genai_api_manager", embedding_model="embedding")) == 7
    with pytest.raises(ValueError):
        selected_cases(
            "genai_api_manager", case="embedding-query", embedding_model="embedding"
        )
    with pytest.raises(ValueError):
        selected_cases("socgenai_llm", case="embedding-documents")


@pytest.mark.parametrize("deployment", [None, "deployment"])
def test_internal_manager_fixture_uses_public_constructor(
    make_client, standard_acceptance, monkeypatch, deployment
):
    seed = make_client(
        standard_handler(),
        pricing_data=PRICES,
        pricing_aliases={"5.6-luna": "deployment"},
        internal_streaming=True,
    )
    seed.close()
    if deployment is None:
        monkeypatch.delenv("GENAI_AZURE_CHAT_DEPLOYMENT", raising=False)
    else:
        monkeypatch.setenv("GENAI_AZURE_CHAT_DEPLOYMENT", deployment)
    monkeypatch.setenv("GENAI_EXPECT_INTERNAL_STREAMING", "true")
    report = standard_acceptance("genai_api_manager", "responses-default")
    assert report["success"]
    assert report["environment"] == "internal-azure"
    assert report["model"] == ("5.6-luna" if deployment is None else deployment)


def test_internal_initialization_failure_is_sanitized(
    standard_acceptance, monkeypatch, capsys
):
    monkeypatch.setenv("GENAI_AZURE_CHAT_DEPLOYMENT", "deployment")

    def fail():
        raise RuntimeError("synthetic-secret https://private.invalid")

    monkeypatch.setattr("genai_api_manager.GenAiApiClient", fail)
    with pytest.raises(pytest.fail.Exception) as error:
        standard_acceptance("genai_api_manager", "chat-default")
    assert "synthetic-secret" not in str(error.value)
    assert "private.invalid" not in str(error.value)
