import json
import pytest

from genai_api_manager import config_loader


def _write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj), encoding="utf-8")


def test_load_config_uses_default_path(tmp_path, monkeypatch):
    """
    load_config() must load ONLY from DEFAULT_CONFIG_PATH (hard-locked).
    In test, we patch DEFAULT_CONFIG_PATH to point at a tmp file.
    """
    cfg_path = tmp_path / "config.json"
    _write_json(cfg_path, {"hello": "world", "pricing_file": str(tmp_path / "p.json")})

    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
    config_loader.clear_config_cache()

    cfg = config_loader.load_config()
    assert cfg["hello"] == "world"


def test_load_config_override_param_is_forbidden(tmp_path, monkeypatch):
    """
    load_config(config_path=...) must always be rejected.
    """
    cfg_path = tmp_path / "config.json"
    _write_json(
        cfg_path, {"source": "default", "pricing_file": str(tmp_path / "p.json")}
    )

    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
    config_loader.clear_config_cache()

    with pytest.raises(PermissionError):
        config_loader.load_config(str(cfg_path))


def test_load_config_missing_file_raises(tmp_path, monkeypatch):
    """
    If DEFAULT_CONFIG_PATH points to a missing file, load_config() raises FileNotFoundError.
    """
    missing = tmp_path / "missing_config.json"
    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(missing))
    config_loader.clear_config_cache()

    with pytest.raises(FileNotFoundError):
        config_loader.load_config()


def test_config_caching_same_object_and_cache_hits(tmp_path, monkeypatch):
    """
    _read_json_file is cached; repeated load_config() returns same dict object.
    """
    cfg_path = tmp_path / "config.json"
    _write_json(cfg_path, {"a": 1, "pricing_file": str(tmp_path / "p.json")})

    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
    config_loader.clear_config_cache()

    # First call (miss)
    cfg1 = config_loader.load_config()
    info1 = config_loader._read_json_file.cache_info()
    assert info1.misses == 1

    # Second call (hit): should return same object from cache
    cfg2 = config_loader.load_config()
    info2 = config_loader._read_json_file.cache_info()
    assert info2.hits >= 1
    assert cfg1 is cfg2  # cached object identity


def test_clear_cache_forces_reload(tmp_path, monkeypatch):
    """
    clear_config_cache() must force a new dict instance on next read.
    """
    cfg_path = tmp_path / "config.json"
    _write_json(cfg_path, {"a": 1, "pricing_file": str(tmp_path / "p.json")})

    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
    config_loader.clear_config_cache()

    cfg1 = config_loader.load_config()

    # Clear cache and load again should produce a NEW dict object
    config_loader.clear_config_cache()
    cfg2 = config_loader.load_config()

    assert cfg1 == cfg2
    assert cfg1 is not cfg2


def test_load_pricing_caches_by_path_when_trusted(tmp_path, monkeypatch):
    """
    load_pricing() is allowed only if the requested path matches
    config.json["pricing_file"], and is cached by absolute path.
    """
    pricing_path = tmp_path / "MODELS_PRICE1K_AZURE.json"
    _write_json(pricing_path, {"gpt-4o": {"input": 1.0, "output": 2.0}})

    cfg_path = tmp_path / "config.json"
    _write_json(cfg_path, {"pricing_file": str(pricing_path)})

    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
    config_loader.clear_config_cache()

    p1 = config_loader.load_pricing(str(pricing_path))
    p2 = config_loader.load_pricing(str(pricing_path))

    assert p1 == p2
    assert p1 is p2  # cached object identity


def test_load_pricing_rejects_non_trusted_path(tmp_path, monkeypatch):
    """
    load_pricing() must reject any path not equal to config.json["pricing_file"].
    """
    trusted_pricing = tmp_path / "TRUSTED.json"
    untrusted_pricing = tmp_path / "UNTRUSTED.json"

    _write_json(trusted_pricing, {"ok": True})
    _write_json(untrusted_pricing, {"ok": False})

    cfg_path = tmp_path / "config.json"
    _write_json(cfg_path, {"pricing_file": str(trusted_pricing)})

    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
    config_loader.clear_config_cache()

    with pytest.raises(PermissionError):
        config_loader.load_pricing(str(untrusted_pricing))


def test_load_pricing_missing_file_raises(tmp_path, monkeypatch):
    """
    If config.json["pricing_file"] points to a missing file,
    load_pricing(missing_path) must raise FileNotFoundError.
    """
    missing_pricing = tmp_path / "nope.json"
    cfg_path = tmp_path / "config.json"
    _write_json(cfg_path, {"pricing_file": str(missing_pricing)})

    monkeypatch.setattr(config_loader, "DEFAULT_CONFIG_PATH", str(cfg_path))
    config_loader.clear_config_cache()

    with pytest.raises(FileNotFoundError):
        config_loader.load_pricing(str(missing_pricing))
