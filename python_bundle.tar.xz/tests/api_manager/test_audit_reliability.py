import base64
import json
from decimal import Decimal
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace

import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from genai_api_manager import AsyncLoggerConfig, GenaiAPILogger, GenAiApiClient
from genai_api_manager.telemetry.request import RequestAudit


@pytest.fixture
def logger_factory(tmp_path):
    private = ec.generate_private_key(ec.SECP256R1())
    public = (
        private.public_key()
        .public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
        )
        .decode()
    )
    loggers = []

    def create(*, pricing_data=None, **config):
        logger = GenaiAPILogger(
            str(tmp_path),
            "",
            public_key=public,
            pricing_data=pricing_data
            or {"m": {"input": "1", "cached_input": "0.2", "output": "3"}},
            config=AsyncLoggerConfig(**{"async_logging_enabled": False, **config}),
        )
        loggers.append(logger)
        return logger, private

    yield create
    for logger in loggers:
        logger.close()


def events(logger):
    return [
        e
        for line in Path(logger._get_daily_log_path())
        .read_text(encoding="utf-8")
        .splitlines()
        if (e := json.loads(line)).get("model_name")
    ]


def save(logger, **kwargs):
    logger._save_to_json(
        "m",
        1000,
        200,
        "synthetic confidential prompt",
        "answer",
        "",
        cached_input_tokens=600,
        **kwargs,
    )


ORIGINAL_LOG_FIELDS = {
    "model_name",
    "input_token",
    "output_token",
    "input_cost",
    "output_cost",
    "total_cost",
    "status",
    "timestamp",
    "prompt",
    "completion",
    "shared_key",
    "cumulative_input_cost",
    "cumulative_output_cost",
    "cumulative_total_cost",
}


@pytest.mark.parametrize("async_logging_enabled", [False, True])
@pytest.mark.parametrize("encrypt_in_writer", [False, True])
def test_original_encryption_format_decrypts_both_fields(
    logger_factory, async_logging_enabled, encrypt_in_writer
):
    logger, _ = logger_factory(
        async_logging_enabled=async_logging_enabled,
        encrypt_in_writer=encrypt_in_writer,
    )
    save(logger)
    logger.close()
    (event,) = events(logger)
    assert set(event) == ORIGINAL_LOG_FIELDS | {
        "request_id",
        "operation",
        "cached_input_token",
        "cache_write_token",
        "cost_status",
    }
    assert "encryption_version" not in event
    assert "ephemeral_public_key" not in event
    shared = base64.b64decode(event["shared_key"])
    assert shared == logger.public_key
    key = HKDF(
        algorithm=hashes.SHA256(), length=32, salt=None, info=b"ecies encryption"
    ).derive(shared)
    for field, expected in (
        ("prompt", b"synthetic confidential prompt"),
        ("completion", b"answer"),
    ):
        raw = base64.b64decode(event[field])
        assert AESGCM(key).decrypt(raw[:12], raw[28:] + raw[12:28], None) == expected
        assert expected.decode() not in json.dumps(event)


def test_concurrent_request_finalization_accounts_and_writes_once(logger_factory):
    logger, _ = logger_factory()
    audit = RequestAudit(logger, "m", "synthetic", "")
    usage = {
        "prompt_tokens": 1000,
        "completion_tokens": 200,
        "prompt_tokens_details": {"cached_tokens": 600},
    }
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(lambda _: audit.finish("completed", usage, "answer"), range(50)))
    assert len(events(logger)) == 1
    assert logger.get_metrics()["daily_cost_exact"] == "1.12"
    assert logger.get_metrics()["request_status_counts"] == {"completed": 1}


@pytest.mark.parametrize("async_logging_enabled", [False, True])
def test_permanent_write_failure_preserves_accepted_or_attempted_cost(
    logger_factory, monkeypatch, async_logging_enabled
):
    logger, _ = logger_factory(
        writer_retry_count=0, async_logging_enabled=async_logging_enabled
    )

    def fail(batch):
        raise OSError("synthetic confidential prompt")

    monkeypatch.setattr(logger, "_flush_batch", fail)
    save(logger)
    logger.close()
    assert logger.get_metrics()["daily_cost_exact"] == "1.12"
    assert logger.get_metrics()["dropped_events"] == 1
    assert "confidential" not in logger.get_metrics()["last_error_message"]


@pytest.mark.parametrize("failure", ["queue", "encryption", "closed"])
def test_unaccepted_event_does_not_increase_spending(
    logger_factory, monkeypatch, failure
):
    logger, _ = logger_factory(async_logging_enabled=True, encrypt_in_writer=False)
    if failure == "closed":
        logger.close()
    with monkeypatch.context() as patch:

        def fail(*args):
            raise RuntimeError("synthetic private failure")

        if failure == "queue":
            patch.setattr(logger._queue, "put_nowait", fail)
        elif failure == "encryption":
            patch.setattr(logger, "_encrypt_fields", fail)
        save(logger)
    logger.close()
    metrics = logger.get_metrics()
    assert metrics["daily_cost_exact"] == "0"
    assert metrics["written_events"] == 0
    assert not logger.budget_exceeded()
    assert "private" not in (metrics["last_error_message"] or "")


def test_successful_overflow_wait_counts_charge_once(logger_factory, monkeypatch):
    logger, _ = logger_factory(
        async_logging_enabled=True,
        queue_maxsize=1,
        batch_size=1,
        overflow_block_timeout_seconds=3,
    )
    entered, release, waiting = threading.Event(), threading.Event(), threading.Event()
    original_flush = logger._flush_batch
    original_overflow = logger._handle_overflow_block_only

    def blocked(batch):
        entered.set()
        assert release.wait(5)
        original_flush(batch)

    def overflow(event):
        waiting.set()
        return original_overflow(event)

    monkeypatch.setattr(logger, "_flush_batch", blocked)
    monkeypatch.setattr(logger, "_handle_overflow_block_only", overflow)
    try:
        save(logger)
        assert entered.wait(3)
        save(logger)
        with ThreadPoolExecutor(max_workers=1) as pool:
            pending = pool.submit(save, logger)
            try:
                assert waiting.wait(3)
                assert logger.check_daily_cost() == 2.24
            finally:
                release.set()
            pending.result(timeout=5)
        assert logger.get_metrics()["daily_cost_exact"] == "3.36"
    finally:
        release.set()
        logger.close()
    assert logger.get_metrics()["written_events"] == 3
    assert logger.get_metrics()["dropped_events"] == 0


def test_queue_overflow_counts_only_accepted_cost_and_close_is_bounded(
    logger_factory, monkeypatch
):
    logger, _ = logger_factory(
        async_logging_enabled=True,
        queue_maxsize=1,
        batch_size=1,
        overflow_block_timeout_seconds=0,
    )
    entered, release = threading.Event(), threading.Event()
    original = logger._flush_batch

    def blocked(batch):
        entered.set()
        assert release.wait(5)
        return original(batch)

    monkeypatch.setattr(logger, "_flush_batch", blocked)
    try:
        save(logger)
        assert entered.wait(3)
        save(logger)
        save(logger)
        assert logger.get_metrics()["daily_cost_exact"] == "2.24"
        assert logger.get_metrics()["dropped_events"] == 1
        handle = logger._writer_file_handle
        logger.close(timeout_seconds=0)
        assert logger.get_metrics()["writer_alive"]
        assert handle is None or not handle.closed
    finally:
        release.set()
        logger.close()
    assert not logger.get_metrics()["writer_alive"]
    assert logger.get_metrics()["written_events"] == 2


def test_corrupt_tail_preserves_known_cost_without_blocking_budget(logger_factory):
    logger, _ = logger_factory()
    save(logger)
    logger.close()
    with open(logger._get_daily_log_path(), "a", encoding="utf-8") as target:
        target.write('{"unfinished":')
    recovered, _ = logger_factory()
    assert recovered.get_metrics()["daily_cost_exact"] == "1.12"
    assert not recovered.budget_exceeded()


def test_restart_preserves_unknown_cost_before_later_known_usage(logger_factory):
    logger, _ = logger_factory()
    logger._save_to_json("m", None, None, "synthetic", "", "")
    save(logger)
    logger.close()
    recovered, _ = logger_factory()
    assert recovered.get_metrics()["daily_cost_exact"] == "1.12"
    assert "unpriced_events" not in recovered.get_metrics()
    assert not recovered.budget_exceeded()


@pytest.mark.parametrize("bad_cost", [None, "NaN", "Infinity", -1, "invalid", {}])
def test_restart_and_report_ignore_invalid_costs_without_losing_known_amounts(
    logger_factory, capsys, bad_cost
):
    logger, _ = logger_factory()
    save(logger)
    logger.close()
    with open(logger._get_daily_log_path(), "a", encoding="utf-8") as target:
        target.write(
            json.dumps(
                {
                    "model_name": "m",
                    "input_cost": bad_cost,
                    "output_cost": bad_cost,
                    "total_cost": bad_cost,
                }
            )
            + "\n"
        )
    recovered, _ = logger_factory()
    assert recovered.get_metrics()["daily_cost_exact"] == "1.12"
    assert not recovered.budget_exceeded()
    recovered.print_today_usage_report()
    report = capsys.readouterr().out
    assert "TOTAL cost    : 1.1200" in report
    assert "Calls with unknown cost: 1" in report


def test_restart_and_writer_use_original_numeric_cost_fields(logger_factory):
    pricing = {"m": {"input": "0.123456789123456789", "output": 0}}
    logger, _ = logger_factory(pricing_data=pricing)
    for _ in range(3):
        logger._save_to_json("m", 1000, 0, "synthetic", "answer", "")
    logger.close()
    recovered, _ = logger_factory(pricing_data=pricing)
    recorded_cost = Decimal(str(float(pricing["m"]["input"])))
    expected = recorded_cost * 3
    assert Decimal(recovered.get_metrics()["daily_cost_exact"]) == expected
    assert not recovered.budget_exceeded()
    recovered._save_to_json("m", 1000, 0, "synthetic", "answer", "")
    assert events(recovered)[-1]["cumulative_total_cost"] == float(
        expected + recorded_cost
    )


@pytest.mark.parametrize("legacy_metadata", [False, True])
def test_original_and_previous_logs_can_be_reopened(
    logger_factory, legacy_metadata, capsys
):
    logger, _ = logger_factory()
    save(logger)
    logger.close()
    path = Path(logger._get_daily_log_path())
    header, record = path.read_text(encoding="utf-8").splitlines()
    event = json.loads(record)
    if legacy_metadata:
        event.update(
            schema_version=2,
            event_id="synthetic-old-id",
            pricing={},
            currency="EUR",
            cumulative_input_cost_exact="0.52",
            cumulative_output_cost_exact="0.6",
            cumulative_total_cost_exact="1.12",
            cumulative_unpriced_events=0,
            cost_exact={"input": "999", "output": "999", "total": "1998"},
        )
    else:
        event = {
            name: value for name, value in event.items() if name in ORIGINAL_LOG_FIELDS
        }
    path.write_text(header + "\n" + json.dumps(event) + "\n", encoding="utf-8")
    recovered, _ = logger_factory()
    assert recovered.get_metrics()["daily_cost_exact"] == "1.12"
    assert not recovered.budget_exceeded()
    recovered.print_today_usage_report()
    assert "TOTAL cost    : 1.1200" in capsys.readouterr().out
    save(recovered)
    assert events(recovered)[-1]["cumulative_total_cost"] == 2.24


def test_ambiguous_write_retry_is_counted_once_after_restart(
    logger_factory, monkeypatch, capsys
):
    logger, _ = logger_factory(
        writer_retry_count=1, writer_retry_backoff_base_seconds=0
    )
    original = logger._flush_batch
    first = True

    def write_then_fail(batch):
        nonlocal first
        original(batch)
        if first:
            first = False
            raise OSError("synthetic post-write failure")

    monkeypatch.setattr(logger, "_flush_batch", write_then_fail)
    save(logger)
    logger.close()
    assert len(events(logger)) == 2
    assert events(logger)[0] == events(logger)[1]
    recovered, _ = logger_factory()
    assert recovered.get_metrics()["daily_cost_exact"] == "1.12"
    recovered.print_today_usage_report()
    report = capsys.readouterr().out
    assert "Calls         : 1" in report
    assert "TOTAL cost    : 1.1200" in report
    save(recovered)
    assert events(recovered)[-1]["cumulative_total_cost"] == 2.24


def test_request_finalization_keeps_original_outcome():
    recorded = []
    logger = SimpleNamespace(
        _get_daily_log_path=lambda: "synthetic",
        _save_to_json=lambda *args, **kwargs: recorded.append(kwargs),
    )
    audit = RequestAudit(logger, "m", "hi", "")
    audit.finish(
        "completed",
        {
            "prompt_tokens": 10,
            "completion_tokens": 100,
            "prompt_tokens_details": {"cached_tokens": 0},
        },
    )
    audit.finish("partial")
    assert len(recorded) == 1
    assert recorded[0]["status"] == "completed"


def test_client_cleanup_preserves_user_error_and_closes_every_resource(caplog):
    closed = []

    def fail():
        closed.append("sdk")
        raise RuntimeError("sensitive details must not appear in diagnostics")

    client = GenAiApiClient.__new__(GenAiApiClient)
    client._openai_client = SimpleNamespace(close=fail)
    client.log_manager = SimpleNamespace(close=lambda: closed.append("logger"))
    client._credential = SimpleNamespace(close=lambda: closed.append("credential"))
    error = ValueError("application error")
    with pytest.raises(ValueError) as observed:
        with client:
            raise error
    assert observed.value is error
    assert closed == ["sdk", "logger", "credential"]
    assert "sensitive details" not in caplog.text


def test_path_failure_skips_unaccepted_charge(logger_factory, monkeypatch):
    logger, _ = logger_factory()
    monkeypatch.setattr(
        logger,
        "_get_daily_log_path",
        lambda *args: (_ for _ in ()).throw(OSError("private path")),
    )
    audit = RequestAudit(logger, "m", "synthetic", "")
    usage = {
        "prompt_tokens": 1000,
        "completion_tokens": 200,
        "prompt_tokens_details": {"cached_tokens": 600},
    }
    audit.finish("completed", usage)
    audit.finish("partial")
    metrics = logger.get_metrics()
    assert metrics["daily_cost_exact"] == "0"
    assert metrics["dropped_events"] == 1
    assert metrics["enqueue_errors"] == 1
    assert "private path" not in metrics["last_error_message"]
    logger.daily_cost_limit = 1
    assert not logger.budget_exceeded()


def test_projection_failure_accounts_and_invalid_usage_does_not_block_budget(
    logger_factory,
):
    logger, _ = logger_factory()
    audit = RequestAudit(logger, "m", "synthetic", "")

    def fail():
        raise ValueError("private projection")

    audit.finish(
        "completed",
        {
            "prompt_tokens": 1000,
            "completion_tokens": 200,
            "prompt_tokens_details": {"cached_tokens": 600},
        },
        fail,
    )
    invalid = RequestAudit(logger, "m", "synthetic", "")
    invalid.finish("failed", {"prompt_tokens": -1, "completion_tokens": 1})
    first, second = events(logger)
    assert first["total_cost"] == 1.12
    assert second["status"] == "invalid_usage"
    assert second["cost_status"] == "usage_missing"
    assert not logger.budget_exceeded()
