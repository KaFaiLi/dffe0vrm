"""Default corporate acceptance of standard public manager usage."""

import pytest

from tests.support.standard_usage.api_manager import CASES


pytestmark = pytest.mark.azure


@pytest.mark.parametrize("case", CASES)
def test_standard_usage(standard_acceptance, case):
    standard_acceptance("genai_api_manager", case)
