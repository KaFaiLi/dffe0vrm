"""Offline validation of standard LangChain acceptance through its real manager."""

from unittest.mock import patch

import pytest
from socgenai_llm import GenAIChatModel, GenAIEmbeddings

from tests.support.standard_usage.common import execute_case
from tests.support.standard_usage.socgenai_llm import CASES
from tests.support.standard import PRICES, standard_handler


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("internal", [False, True])
def test_standard_langchain_cases(make_client, case, internal):
    sources = []
    manager = make_client(
        standard_handler(sources=sources),
        pricing_data=PRICES,
        internal_streaming=internal,
    )
    embedding = case.startswith("embedding")
    module = "embeddings" if embedding else "chat_model"
    model = "embedding-deployment" if embedding else "deployment"
    with patch(f"socgenai_llm.{module}.GenAiApiClient", return_value=manager):
        wrapper = (
            GenAIEmbeddings(model=model, encoding_format="float")
            if embedding
            else GenAIChatModel(model=model, cache=False)
        )
    report = execute_case(manager, "socgenai_llm", case, model, wrapper=wrapper)
    assert report["success"], report
    assert report["attempts"] == report["audit_count"] == 1
    assert all(source.closed for source in sources)


@pytest.mark.parametrize("deployment", [None, "deployment"])
def test_internal_langchain_fixture_uses_public_constructor(
    make_client, standard_acceptance, monkeypatch, deployment
):
    seed = make_client(
        standard_handler(),
        pricing_data=PRICES,
        pricing_aliases={"5.6-luna": "deployment"},
        internal_streaming=True,
    )
    seed.close()
    if deployment is None:
        monkeypatch.delenv("GENAI_AZURE_CHAT_DEPLOYMENT", raising=False)
    else:
        monkeypatch.setenv("GENAI_AZURE_CHAT_DEPLOYMENT", deployment)
    report = standard_acceptance("socgenai_llm", "responses-stream")
    assert report["success"]
    assert report["model"] == ("5.6-luna" if deployment is None else deployment)
