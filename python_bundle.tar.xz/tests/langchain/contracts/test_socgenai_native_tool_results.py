"""Hosted-tool output parity with the public, pinned ChatOpenAI integration.

Azure v1 JSON/SSE schemas checked on 2026-10-05:
https://learn.microsoft.com/en-us/rest/api/microsoft-foundry/azureopenai/responses
https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/web-search

Both models use real SDK clients over independent mocked HTTP transports.
These tests establish conversion parity, not live execution or tool billing.
"""

from copy import deepcopy
import json
from uuid import UUID

import httpx2
from langchain_openai import ChatOpenAI
from openai.types.responses import Response, ResponseStreamEvent
from pydantic import TypeAdapter
import pytest

from tests.langchain.support import aggregate, response_events
from tests.support.azure import WireStream, response_payload, wire_response
from tests.support.client import audit_events


TOOLS = [
    {"type": "web_search"},
    {"type": "file_search", "vector_store_ids": ["vs_synthetic"]},
    {"type": "code_interpreter", "container": {"type": "auto"}},
    {
        "type": "mcp",
        "server_label": "synthetic",
        "server_url": "https://example.invalid/mcp",
        "require_approval": "always",
    },
    {
        "type": "function",
        "name": "local_lookup",
        "parameters": {"type": "object", "properties": {"q": {"type": "string"}}},
    },
]
INCLUDE = [
    "web_search_call.action.sources",
    "file_search_call.results",
    "code_interpreter_call.outputs",
]
MODES = [
    "invoke",
    "internal_invoke",
    "stream",
    "ainvoke",
    "internal_ainvoke",
    "astream",
]
CASES = [
    "web-search",
    "web-no-sources",
    "web-failed",
    "file-search",
    "file-no-results",
    "file-failed",
    "code-interpreter",
    "code-failed",
    "mcp",
    "mcp-error",
    "mcp-malformed-arguments",
    "mcp-empty-output",
    "mcp-list",
    "mcp-approval",
    "mixed",
    "mixed-incomplete",
]
URL_CITATION = {
    "type": "url_citation",
    "start_index": 0,
    "end_index": 5,
    "url": "https://example.com/source",
    "title": "Synthetic source",
}
FILE_CITATION = {
    "type": "file_citation",
    "index": 0,
    "file_id": "file_synthetic",
    "filename": "example.txt",
}
CONTAINER_CITATION = {
    "type": "container_file_citation",
    "start_index": 0,
    "end_index": 5,
    "container_id": "cntr_synthetic",
    "file_id": "file_output",
    "filename": "output.png",
}


def hosted_response(case, *, status="completed"):
    if case == "mixed-incomplete":
        case, status = "mixed", "incomplete"
    web = {
        "type": "web_search_call",
        "id": "ws_synthetic",
        "status": "completed",
        "action": {
            "type": "search",
            "query": "synthetic search",
            "sources": [{"type": "url", "url": "https://example.com/source"}],
        },
    }
    file = {
        "type": "file_search_call",
        "id": "fs_synthetic",
        "status": "completed",
        "queries": ["synthetic search"],
        "results": [
            {
                "file_id": "file_synthetic",
                "filename": "example.txt",
                "score": 0.9,
                "text": "Synthetic search result \u4f60\u597d",
                "attributes": {"category": "synthetic"},
            }
        ],
    }
    code = {
        "type": "code_interpreter_call",
        "id": "ci_synthetic",
        "status": "completed",
        "container_id": "cntr_synthetic",
        "code": "print(2)",
        "outputs": [
            {"type": "logs", "logs": "2\n"},
            {"type": "image", "url": "https://example.invalid/output.png"},
        ],
    }
    mcp = {
        "type": "mcp_call",
        "id": "mcp_synthetic",
        "server_label": "synthetic",
        "name": "lookup",
        "arguments": '{"q":"synthetic"}',
        "output": '{"answer":"Synthetic MCP result"}',
        "error": None,
    }
    listed = {
        "type": "mcp_list_tools",
        "id": "mcp_list_synthetic",
        "server_label": "synthetic",
        "tools": [{"name": "lookup", "input_schema": {"type": "object"}}],
        "error": None,
    }
    approval = {
        "type": "mcp_approval_request",
        "id": "mcp_approval_synthetic",
        "server_label": "synthetic",
        "name": "lookup",
        "arguments": '{"q":"synthetic"}',
    }
    if case == "web-no-sources":
        web["action"].pop("sources")
    elif case == "web-failed":
        web["status"] = "failed"
        web["action"].pop("sources")
    elif case == "file-no-results":
        file.pop("results")
    elif case == "file-failed":
        file.update(status="failed", results=None)
    elif case == "code-failed":
        code.update(status="failed", outputs=None)
    elif case == "mcp-error":
        mcp.update(
            output=None,
            error={
                "type": "mcp_tool_execution_error",
                "content": [{"type": "text", "text": "Synthetic MCP error"}],
            },
        )
    elif case == "mcp-malformed-arguments":
        mcp["arguments"] = "malformed{"
    elif case == "mcp-empty-output":
        mcp["output"] = ""
    selected = {
        "web-search": [web],
        "web-no-sources": [web],
        "web-failed": [web],
        "file-search": [file],
        "file-no-results": [file],
        "file-failed": [file],
        "code-interpreter": [code],
        "code-failed": [code],
        "mcp": [mcp],
        "mcp-error": [mcp],
        "mcp-malformed-arguments": [mcp],
        "mcp-empty-output": [mcp],
        "mcp-list": [listed],
        "mcp-approval": [approval],
        "mixed": [
            {
                "type": "reasoning",
                "id": "rs_synthetic",
                "summary": [{"type": "summary_text", "text": "Synthetic summary."}],
            },
            web,
            file,
            code,
            listed,
            mcp,
            approval,
            {
                "type": "function_call",
                "id": "fc_synthetic",
                "call_id": "call_local",
                "name": "local_lookup",
                "arguments": '{"q":"synthetic"}',
                "status": "completed",
            },
        ],
    }[case]
    payload = response_payload(status)
    payload.update(parallel_tool_calls=True, tool_choice="auto", tools=deepcopy(TOOLS))
    payload["usage"]["input_tokens_details"]["cache_write_tokens"] = 0
    annotations = []
    types = {item["type"] for item in selected}
    for kind, annotation in (
        ("web_search_call", URL_CITATION),
        ("file_search_call", FILE_CITATION),
        ("code_interpreter_call", CONTAINER_CITATION),
    ):
        if kind in types:
            annotations.append(deepcopy(annotation))
    payload["output"][0]["content"][0]["annotations"] = annotations
    payload["output"] = selected + payload["output"]
    # Reject fixture drift against the locked SDK before either model consumes it.
    Response.model_validate(payload)
    return payload


def hosted_events(payload):
    """Complete items plus documented progress/delta/citation events."""
    events = []
    for event in response_events(payload):
        if event["type"] == "response.output_item.done":
            item = event["item"]
            kind = item["type"]
            common = {"item_id": item["id"], "output_index": event["output_index"]}
            if kind in (
                "web_search_call",
                "file_search_call",
                "code_interpreter_call",
                "mcp_call",
            ):
                initial = deepcopy(item)
                for key in ("results", "outputs", "output", "error"):
                    initial.pop(key, None)
                if kind != "mcp_call":
                    initial["status"] = "in_progress"
                events.append(
                    {
                        "type": "response.output_item.added",
                        "output_index": event["output_index"],
                        "item": initial,
                    }
                )
                if kind != "mcp_call":
                    events.append({**common, "type": f"response.{kind}.in_progress"})
                if kind == "code_interpreter_call":
                    events.append(
                        {
                            **common,
                            "type": "response.code_interpreter_call_code.delta",
                            "delta": item["code"],
                        }
                    )
                elif kind == "mcp_call":
                    events.append(
                        {
                            **common,
                            "type": "response.mcp_call_arguments.delta",
                            "delta": item["arguments"],
                        }
                    )
        elif event["type"] == "response.output_text.done":
            part = payload["output"][event["output_index"]]["content"][
                event["content_index"]
            ]
            for index, annotation in enumerate(part["annotations"]):
                events.append(
                    {
                        "item_id": event["item_id"],
                        "output_index": event["output_index"],
                        "content_index": event["content_index"],
                        "type": "response.output_text.annotation.added",
                        "annotation_index": index,
                        "annotation": annotation,
                    }
                )
        events.append(event)
    events = [{**event, "sequence_number": i} for i, event in enumerate(events)]
    adapter = TypeAdapter(ResponseStreamEvent)
    for event in events:
        adapter.validate_python(event)
    return events


class AsyncWireStream(httpx2.AsyncByteStream):
    def __init__(self, source):
        self.source = source

    async def __aiter__(self):
        for chunk in self.source:
            yield chunk

    async def aclose(self):
        self.source.close()


def reply_handler(payload, requests, sources, *, async_api=False):
    def handle(request):
        requests.append(request)
        if json.loads(request.content).get("stream"):
            source = WireStream(hosted_events(payload), named=True)
            sources.append(source)
            response = wire_response(source)
            if async_api:
                response = httpx2.Response(
                    200, headers=response.headers, stream=AsyncWireStream(source)
                )
            return response
        return httpx2.Response(200, json=deepcopy(payload))

    return handle


def invoke(model, mode, async_loop):
    chunks = []
    # Core assigns run IDs to chunks without a provider message ID. Keep the
    # independent invocations deterministic without discarding their IDs.
    config = {"run_id": UUID("00000000-0000-4000-8000-000000000001")}
    if mode == "stream":
        chunks = list(model.stream("Synthetic tool request.", config=config))
        return aggregate(chunks), chunks
    if "ainvoke" in mode or mode == "astream":

        async def run():
            if mode == "astream":
                chunks.extend(
                    [
                        chunk
                        async for chunk in model.astream(
                            "Synthetic tool request.", config=config
                        )
                    ]
                )
                return aggregate(chunks)
            options = {} if mode.startswith("internal_") else {"stream": False}
            return await model.ainvoke(
                "Synthetic tool request.", config=config, **options
            )

        return async_loop.run_until_complete(run()), chunks
    options = {} if mode.startswith("internal_") else {"stream": False}
    return model.invoke("Synthetic tool request.", config=config, **options), chunks


def assert_message_parity(actual, expected):
    assert actual.content == expected.content
    assert actual.content_blocks == expected.content_blocks
    assert actual.text == expected.text
    assert actual.tool_calls == expected.tool_calls
    assert actual.invalid_tool_calls == expected.invalid_tool_calls
    assert actual.id == expected.id
    assert actual.usage_metadata == expected.usage_metadata
    for key in ("status", "incomplete_details", "model_name", "model_provider"):
        assert actual.response_metadata.get(key) == expected.response_metadata.get(key)


def assert_hosted_results(message, payload):
    """Parity must also retain actual results, IDs, status, and raw MCP output."""
    names = {
        "web_search_call": "web_search",
        "file_search_call": "file_search",
        "code_interpreter_call": "code_interpreter",
        "mcp_call": "remote_mcp",
        "mcp_list_tools": "mcp_list_tools",
    }
    items = [item for item in payload["output"] if item["type"] in names]
    blocks = message.content_blocks
    calls = [block for block in blocks if block["type"] == "server_tool_call"]
    results = [block for block in blocks if block["type"] == "server_tool_result"]
    assert [call["id"] for call in calls] == [item["id"] for item in items]
    assert [result["tool_call_id"] for result in results] == [
        item["id"] for item in items
    ]
    for item, call, result in zip(items, calls, results):
        assert call["name"] == names[item["type"]]
        assert result["status"] == (
            "error"
            if item.get("error") or item.get("status") == "failed"
            else "success"
        )
        kind = item["type"]
        if kind == "web_search_call":
            sources = item["action"].get("sources")
            output = {"sources": sources} if sources else None
            assert call["args"] == {
                key: value for key, value in item["action"].items() if key != "sources"
            }
        elif kind == "file_search_call":
            output = item.get("results")
            assert call["args"] == {"queries": item["queries"]}
        elif kind == "code_interpreter_call":
            output = item.get("outputs")
            assert call["args"] == {"code": item["code"]}
            assert call["extras"]["container_id"] == item["container_id"]
        elif kind == "mcp_call":
            output = item.get("output") or None
            assert call["extras"]["tool_name"] == item["name"]
            assert call["extras"]["server_label"] == item["server_label"]
            if item["arguments"] == "malformed{":
                assert call["extras"]["arguments"] == item["arguments"]
            else:
                assert call["args"] == json.loads(item["arguments"])
            if item.get("error"):
                assert result["extras"]["error"] == item["error"]
        else:
            output = item["tools"]
        assert result.get("output") == output
    annotations = [
        annotation
        for block in blocks
        if block["type"] == "text"
        for annotation in block.get("annotations", [])
    ]
    provider_annotations = [
        annotation
        for item in payload["output"]
        if item["type"] == "message"
        for part in item["content"]
        for annotation in part.get("annotations", [])
    ]
    assert len(annotations) == len(provider_annotations)
    for annotation in provider_annotations:
        if annotation["type"] == "url_citation":
            assert any(
                converted.get("url") == annotation["url"]
                and converted.get("title") == annotation["title"]
                for converted in annotations
            )
        elif annotation["type"] == "file_citation":
            assert any(
                converted.get("extras", {}).get("file_id") == annotation["file_id"]
                and converted.get("title") == annotation["filename"]
                for converted in annotations
            )
        else:
            assert any(
                converted.get("value") == annotation for converted in annotations
            )
    for item in payload["output"]:
        if item["type"] == "mcp_approval_request":
            # The pinned translator retains approval requests as non-standard
            # blocks. It does not fabricate a completed tool result or approval.
            assert any(
                block["type"] == "non_standard"
                and {
                    key: value
                    for key, value in block["value"].items()
                    if key != "index"
                }
                == item
                for block in blocks
            )


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("output_version", [None, "v1"])
def test_hosted_tool_result_parity(wrapper, async_loop, case, mode, output_version):
    payload = hosted_response(case)
    before = deepcopy(payload)
    custom_requests, custom_sources, native_requests, native_sources = [], [], [], []
    model, manager = wrapper(
        reply_handler(payload, custom_requests, custom_sources),
        internal=True,
        use_responses_api=True,
        output_version=output_version,
    )
    actual, actual_chunks = invoke(
        model.bind_tools(deepcopy(TOOLS), include=INCLUDE), mode, async_loop
    )
    with httpx2.Client(
        transport=httpx2.MockTransport(
            reply_handler(payload, native_requests, native_sources)
        )
    ) as transport:
        async_transport = httpx2.AsyncClient(
            transport=httpx2.MockTransport(
                reply_handler(payload, native_requests, native_sources, async_api=True)
            )
        )
        native = ChatOpenAI(
            base_url="https://synthetic.openai.azure.com/openai/v1/",
            api_key="synthetic",
            model="deployment",
            http_client=transport,
            http_async_client=async_transport,
            use_responses_api=True,
            output_version=output_version,
            # The reference probes TCP defaults during construction otherwise.
            # These user-supplied transports never open sockets.
            http_socket_options=(),
            max_retries=0,
        )
        try:
            # Internal streaming is the manager's transport choice. ChatOpenAI's
            # ordinary public return is the reference for the collected result.
            expected, expected_chunks = invoke(
                native.bind_tools(deepcopy(TOOLS), include=INCLUDE), mode, async_loop
            )
        finally:
            native.root_client.close()
            async_loop.run_until_complete(native.root_async_client.close())
    assert_message_parity(actual, expected)
    assert_hosted_results(actual, payload)
    assert payload == before
    assert len(actual_chunks) == len(expected_chunks)
    for actual_chunk, expected_chunk in zip(actual_chunks, expected_chunks):
        assert_message_parity(actual_chunk, expected_chunk)
    assert len(custom_requests) == len(native_requests) == 1
    for request in custom_requests + native_requests:
        assert request.url.path == "/openai/v1/responses"
        assert not request.url.query
    assert bool(native_sources) == (mode in ("stream", "astream"))
    assert bool(custom_sources) == (mode not in ("invoke", "ainvoke"))
    assert all(source.closed for source in custom_sources + native_sources)
    assert actual.text == "Hello"
    if case.startswith("mixed"):
        assert [call["id"] for call in actual.tool_calls] == ["call_local"]
    else:
        assert actual.tool_calls == []
    if actual_chunks:
        assert sum(chunk.usage_metadata is not None for chunk in actual_chunks) == 1
    (audit,) = audit_events(manager)
    assert audit["operation"] == "responses"
    assert audit["status"] == payload["status"]
    assert audit["total_cost"] == 1.12
