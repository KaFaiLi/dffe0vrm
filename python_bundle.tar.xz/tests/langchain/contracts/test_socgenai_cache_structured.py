"""G01/G03 regressions through the real manager and SDK, with synthetic HTTP."""

from tests.langchain.support import Answer, METHODS, SCHEMA, payload_for, handler_for

from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import json
from threading import Barrier, Event
from unittest.mock import Mock

import httpx2
from langchain_core.caches import InMemoryCache
from langchain_core.exceptions import OutputParserException
from langchain_core.globals import get_llm_cache, set_llm_cache
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI
from openai import LengthFinishReasonError
import pytest

from socgenai_llm import GenAIRefusalError, GenAIResponseError
from socgenai_llm._streaming import StreamOwner
from tests.support.client import audit_events
from tests.support.azure import WireStream, wire_response
from tests.langchain.support import response_events


@pytest.mark.parametrize("responses", [False, True])
@pytest.mark.parametrize("async_api", [False, True])
@pytest.mark.parametrize("cache_mode", ["instance", "global", "disabled"])
def test_cache_hit_only_charges_provider_once(
    wrapper, async_loop, responses, async_api, cache_mode
):
    previous = get_llm_cache()
    cache = InMemoryCache()
    set_llm_cache(cache)
    try:
        handler = handler_for(payload_for(responses))
        model, manager = wrapper(
            handler,
            use_responses_api=responses,
            cache={"instance": cache, "global": None, "disabled": False}[cache_mode],
        )
        if async_api:

            async def run():
                return [await model.ainvoke("hi"), await model.ainvoke("hi")]

            values = async_loop.run_until_complete(run())
        else:
            values = [model.invoke("hi"), model.invoke("hi")]
        assert values[0].text == values[1].text
        count = 2 if cache_mode == "disabled" else 1
        assert handler.call_count == count
        events = audit_events(manager)
        assert len(events) == count
        assert all(e["total_cost"] == 1.12 for e in events)
    finally:
        set_llm_cache(previous)


def test_cache_identity_excludes_owner_but_preserves_options(wrapper):
    model, _ = wrapper(handler_for(payload_for(True)), use_responses_api=True)
    owners = [StreamOwner(), StreamOwner()]
    keys = [
        model._get_llm_string(_genai_stream_owner=o, temperature=0.2) for o in owners
    ]
    assert keys[0] == keys[1]
    assert "_genai_stream_owner" not in keys[0]
    assert all(repr(owner) not in keys[0] for owner in owners)


@pytest.mark.parametrize(
    "option",
    [
        {"temperature": 0.7},
        {"reasoning": {"effort": "low"}},
        {
            "tools": [
                {
                    "type": "function",
                    "function": {"name": "lookup", "parameters": {"type": "object"}},
                }
            ]
        },
        {"response_format": {"type": "json_object"}},
    ],
)
def test_cache_request_options_miss(wrapper, option):
    handler = handler_for(payload_for(True))
    model, manager = wrapper(handler, use_responses_api=True, cache=InMemoryCache())
    model.invoke("hi")
    model.bind(**option).invoke("hi")
    model.invoke("different")
    assert handler.call_count == 3
    assert len(audit_events(manager)) == 3


def test_cache_schema_and_representation_miss(wrapper):
    handler = handler_for(payload_for(True))
    cache = InMemoryCache()
    model, manager = wrapper(handler, use_responses_api=True, cache=cache)
    model.with_structured_output(Answer).invoke("hi")
    other = {**SCHEMA, "description": "Different requested schema"}
    model.with_structured_output(other).invoke("hi")
    model.output_version = "v1"
    model.with_structured_output(Answer).invoke("hi")
    assert handler.call_count == 3
    assert len(audit_events(manager)) == 3


@pytest.mark.parametrize("async_api", [False, True])
def test_cache_streamed_invoke_closes_cold_source(wrapper, async_loop, async_api):
    sources = []
    handler = handler_for(payload_for(True), sources)
    model, manager = wrapper(handler, use_responses_api=True, cache=InMemoryCache())
    if async_api:

        async def run():
            await model.ainvoke("hi", stream=True)
            await model.ainvoke("hi", stream=True)

        async_loop.run_until_complete(run())
    else:
        model.invoke("hi", stream=True)
        model.invoke("hi", stream=True)
    assert handler.call_count == 1
    assert len(sources) == 1 and sources[0].closed
    assert len(audit_events(manager)) == 1


def test_concurrent_cold_requests_keep_independent_owners(wrapper):
    barrier = Barrier(2, timeout=10)
    sources = []

    def handle(request):
        body = json.loads(request.content)
        payload = payload_for(
            True, text=json.dumps({"answer": body["input"][0]["content"]})
        )
        source = WireStream(response_events(payload))
        sources.append(source)
        barrier.wait()
        return wire_response(source)

    model, manager = wrapper(handle, use_responses_api=True, cache=InMemoryCache())
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [
            pool.submit(model.invoke, prompt, stream=True)
            for prompt in ("first", "second")
        ]
        values = [future.result(timeout=10).text for future in futures]
    assert [json.loads(value)["answer"] for value in values] == ["first", "second"]
    assert len(sources) == 2 and all(source.closed for source in sources)
    assert len(audit_events(manager)) == 2


@pytest.mark.parametrize("responses", [False, True])
@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("schema", [Answer, SCHEMA])
@pytest.mark.parametrize("async_api", [False, True])
def test_valid_final_structured_output(
    wrapper, async_loop, responses, method, schema, async_api
):
    model, manager = wrapper(
        handler_for(payload_for(responses, method)), use_responses_api=responses
    )
    structured = model.with_structured_output(schema, method=method, include_raw=True)
    result = (
        async_loop.run_until_complete(structured.ainvoke("hi"))
        if async_api
        else structured.invoke("hi")
    )
    assert result["parsed"] == (
        Answer(answer="Hello") if schema is Answer else {"answer": "Hello"}
    )
    assert result["parsing_error"] is None
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize("responses", [False, True])
@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("include_raw", [False, True])
@pytest.mark.parametrize(
    "text,complete",
    [
        ('{"answer":"unfinished', True),
        ('{"answer":"Hello"', True),
        ('{"answer":"Hello"}', False),
        ('{"answer":"Hello"} trailing', True),
        ('```json\n{"answer":"Hello"}\n```', True),
        ('{"answer":"bad\x01value"}', True),
        ('{"answer":NaN}', True),
        ('{"answer":Infinity}', True),
        ("", True),
        ('{"answer": 42}', True),
    ],
)
def test_final_output_rejects_bad_results_without_erasing_cost(
    wrapper, responses, method, include_raw, text, complete
):
    handler = handler_for(payload_for(responses, method, text, complete))
    model, manager = wrapper(handler, use_responses_api=responses)
    structured = model.with_structured_output(
        Answer, method=method, include_raw=include_raw
    )
    if include_raw:
        result = structured.invoke("hi")
        assert result["parsed"] is None
        error = result["parsing_error"]
        assert result["raw"] is not None
    else:
        with pytest.raises(OutputParserException) as caught:
            structured.invoke("hi")
        error = caught.value
    assert isinstance(error, OutputParserException)
    assert error.__cause__ is not None
    assert error.llm_output == text
    assert handler.call_count == 1
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("async_api", [False, True])
@pytest.mark.parametrize("output_version", [None, "v1"])
@pytest.mark.parametrize("include_raw", [False, True])
def test_stream_only_emits_validated_final_parsed_value(
    wrapper, async_loop, method, async_api, output_version, include_raw
):
    sources = []
    handler = handler_for(payload_for(True, method), sources)
    model, manager = wrapper(
        handler, use_responses_api=True, output_version=output_version
    )
    structured = model.with_structured_output(
        Answer, method=method, include_raw=include_raw
    )
    chunks = []

    def check(chunk):
        if not include_raw or "parsed" in chunk or "parsing_error" in chunk:
            assert sources[0].reads == len(sources[0].events)
        chunks.append(chunk)

    if async_api:

        async def run():
            async for chunk in structured.astream("hi"):
                check(chunk)

        async_loop.run_until_complete(run())
    else:
        for chunk in structured.stream("hi"):
            check(chunk)
    parsed = [c["parsed"] for c in chunks if "parsed" in c] if include_raw else chunks
    assert parsed == [Answer(answer="Hello")]
    assert sources[0].closed
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("complete", [False, True])
def test_cached_structured_result_is_revalidated(wrapper, method, complete):
    text = '{"answer":"Hello"}' if complete else '{"answer":"Hello"'
    handler = handler_for(payload_for(True, method, text))
    model, manager = wrapper(handler, use_responses_api=True, cache=InMemoryCache())
    structured = model.with_structured_output(Answer, method=method, include_raw=True)
    for _ in range(2):
        result = structured.invoke("hi")
        assert (result["parsed"] == Answer(answer="Hello")) is complete
        assert (result["parsing_error"] is None) is complete
    assert handler.call_count == 1
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("responses", [False, True])
def test_refusals_across_methods(wrapper, method, responses):
    payload = payload_for(responses)
    if responses:
        payload["output"][1]["content"] = [
            {"type": "refusal", "refusal": "synthetic refusal"}
        ]
    else:
        payload["choices"][0]["message"].update(
            content=None, refusal="synthetic refusal"
        )
    model, _ = wrapper(handler_for(payload), use_responses_api=responses)
    result = model.with_structured_output(
        Answer, method=method, include_raw=True
    ).invoke("hi")
    assert result["parsed"] is None and isinstance(
        result["parsing_error"], GenAIRefusalError
    )
    with pytest.raises(GenAIRefusalError):
        model.with_structured_output(Answer, method=method).invoke("hi")


def test_json_mode_without_schema_and_whitespace(wrapper):
    model, _ = wrapper(handler_for(payload_for(False, text=' \n {"answer":"Hello"}\t')))
    assert model.with_structured_output(method="json_mode").invoke("hi") == {
        "answer": "Hello"
    }


def test_native_and_custom_reject_truncated_pydantic_output(wrapper):
    payload = payload_for(False, text='{"answer":"unfinished', complete=False)
    model, _ = wrapper(handler_for(payload))
    with pytest.raises(OutputParserException):
        model.with_structured_output(Answer).invoke("hi")
    with httpx2.Client(
        transport=httpx2.MockTransport(handler_for(payload))
    ) as transport:
        native = ChatOpenAI(
            base_url="https://synthetic.openai.azure.com/openai/v1/",
            model="deployment",
            api_key="synthetic",
            http_client=transport,
            async_client=Mock(),
            http_socket_options=(),
            max_retries=0,
        )
        try:
            with pytest.raises(LengthFinishReasonError):
                native.with_structured_output(Answer).invoke(
                    [HumanMessage(content="hi")]
                )
        finally:
            native.root_client.close()


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("async_api", [False, True])
@pytest.mark.parametrize("include_raw", [False, True])
@pytest.mark.parametrize("failure", ["incomplete", "malformed", "eof", "callback"])
def test_structured_stream_failures_never_emit_success(
    wrapper, async_loop, method, async_api, include_raw, failure
):
    from langchain_core.callbacks import BaseCallbackHandler
    from genai_api_manager import UnexpectedStreamEndError

    payload = payload_for(
        True,
        method,
        text='{"answer":"broken' if failure == "malformed" else '{"answer":"Hello"}',
        complete=failure != "incomplete",
    )
    events = response_events(payload)
    if failure == "eof":
        events = events[:-1]
    source = WireStream(events)
    handler = Mock(return_value=wire_response(source))
    model, manager = wrapper(handler, use_responses_api=True)
    structured = model.with_structured_output(
        Answer, method=method, include_raw=include_raw
    )

    class BrokenCallback(BaseCallbackHandler):
        raise_error = True

        def on_llm_new_token(self, *args, **kwargs):
            raise LookupError("synthetic callback failure")

    config = {"callbacks": [BrokenCallback()] if failure == "callback" else []}
    chunks = []

    async def run():
        async for chunk in structured.astream("hi", config=config):
            chunks.append(chunk)

    def consume():
        if async_api:
            async_loop.run_until_complete(run())
        else:
            for chunk in structured.stream("hi", config=config):
                chunks.append(chunk)

    upstream = failure in ("eof", "callback") or (
        failure == "malformed" and method == "function_calling"
    )
    if upstream or not include_raw:
        error = {"eof": UnexpectedStreamEndError, "callback": LookupError}.get(
            failure, GenAIResponseError if upstream else OutputParserException
        )
        with pytest.raises(error):
            consume()
    else:
        consume()
        assert any(
            isinstance(c.get("parsing_error"), OutputParserException) for c in chunks
        )
    assert (
        not any(c.get("parsed") is not None for c in chunks)
        if include_raw
        else not chunks
    )
    assert source.closed and handler.call_count == 1
    (event,) = audit_events(manager)
    if failure in ("malformed", "incomplete"):
        assert event["total_cost"] == 1.12


@pytest.mark.parametrize("async_api", [False, True])
def test_raw_chunks_arrive_before_terminal_validation(wrapper, async_loop, async_api):
    allow_terminal = Event()

    class Gated(WireStream):
        def __iter__(self):
            for event in self.events:
                if event["type"] == "response.completed":
                    assert allow_terminal.wait(5), (
                        "raw stream was buffered until completion"
                    )
                self.reads += 1
                yield ("data: " + json.dumps(event) + "\n\n").encode()

    source = Gated(response_events(payload_for(True)))
    model, manager = wrapper(lambda _: wire_response(source), use_responses_api=True)
    structured = model.with_structured_output(Answer, include_raw=True)
    early_raw = []
    parsed = []

    def check(chunk):
        if "raw" in chunk and source.reads < len(source.events):
            early_raw.append(chunk["raw"])
            allow_terminal.set()
        if "parsed" in chunk:
            assert source.reads == len(source.events)
            parsed.append(chunk["parsed"])

    async def run():
        async for chunk in structured.astream("hi"):
            check(chunk)

    try:
        if async_api:
            async_loop.run_until_complete(run())
        else:
            for chunk in structured.stream("hi"):
                check(chunk)
    finally:
        allow_terminal.set()
    assert early_raw and parsed == [Answer(answer="Hello")]
    assert source.closed and len(audit_events(manager)) == 1


@pytest.mark.parametrize("async_api", [False, True])
def test_structured_raw_stream_early_close(wrapper, async_loop, async_api):
    source = WireStream(response_events(payload_for(True)))
    model, manager = wrapper(lambda _: wire_response(source), use_responses_api=True)
    structured = model.with_structured_output(Answer, include_raw=True)

    async def run():
        iterator = structured.astream("hi")
        first = await anext(iterator)
        assert "parsed" not in first
        await iterator.aclose()

    if async_api:
        async_loop.run_until_complete(run())
    else:
        iterator = structured.stream("hi")
        first = next(iterator)
        assert "parsed" not in first
        iterator.close()
    assert source.closed
    assert len(audit_events(manager)) == 1


def test_structured_stream_cancellation_closes_without_parsed_result(
    wrapper, async_loop
):
    import asyncio

    entered, proceed = Event(), Event()

    class Blocked(WireStream):
        def __iter__(self):
            entered.set()
            assert proceed.wait(5)
            yield from super().__iter__()

    source = Blocked(response_events(payload_for(True)))
    with ThreadPoolExecutor(max_workers=1) as pool:
        model, manager = wrapper(
            lambda _: wire_response(source), use_responses_api=True, executor=pool
        )
        structured = model.with_structured_output(Answer)

        async def run():
            iterator = structured.astream("hi")
            task = asyncio.create_task(anext(iterator))
            assert await asyncio.to_thread(entered.wait, 5)
            task.cancel()
            proceed.set()
            with pytest.raises(asyncio.CancelledError):
                await task
            await iterator.aclose()

        try:
            async_loop.run_until_complete(run())
        finally:
            proceed.set()
    assert source.closed and len(audit_events(manager)) == 1


@pytest.mark.parametrize("responses", [False, True])
@pytest.mark.parametrize("case", ["missing", "non_object", "first_match"])
def test_function_selection_and_arguments(wrapper, responses, case):
    text = "[]" if case == "non_object" else '{"answer":"Hello"}'
    payload = payload_for(responses, "function_calling", text)
    call = (
        payload["output"][1]
        if responses
        else payload["choices"][0]["message"]["tool_calls"][0]["function"]
    )
    if case == "missing":
        call["name"] = "different"
    if case == "first_match":
        if responses:
            payload["output"].append(
                {
                    **deepcopy(call),
                    "id": "fc_second",
                    "call_id": "second",
                    "arguments": '{"answer":"Second"}',
                }
            )
        else:
            payload["choices"][0]["message"]["tool_calls"].append(
                {
                    "id": "second",
                    "type": "function",
                    "function": {**call, "arguments": '{"answer":"Second"}'},
                }
            )
    model, _ = wrapper(handler_for(payload), use_responses_api=responses)
    structured = model.with_structured_output(Answer, method="function_calling")
    if case == "first_match":
        assert structured.invoke("hi") == Answer(answer="Hello")
    else:
        with pytest.raises((OutputParserException, GenAIResponseError)):
            structured.invoke("hi")


@pytest.mark.parametrize("reason", [None, "unknown"])
def test_missing_or_unknown_finish_metadata_is_not_success(wrapper, reason):
    payload = payload_for(False)
    payload["choices"][0]["finish_reason"] = reason
    model, _ = wrapper(handler_for(payload))
    with pytest.raises(OutputParserException):
        model.with_structured_output(Answer).invoke("hi")


def test_chat_stop_parameter_changes_cache_identity(wrapper):
    handler = handler_for(payload_for(False))
    model, manager = wrapper(handler, cache=InMemoryCache())
    model.invoke("hi", stop=["first"])
    model.invoke("hi", stop=["second"])
    assert handler.call_count == 2 and len(audit_events(manager)) == 2


@pytest.mark.parametrize("method", ["json_mode", "function_calling"])
def test_pydantic_v1_schema_still_validates(wrapper, method):
    from pydantic.v1 import BaseModel as BaseModelV1

    class AnswerV1(BaseModelV1):
        answer: str

    payload = payload_for(False, method)
    if method == "function_calling":
        payload["choices"][0]["message"]["tool_calls"][0]["function"]["name"] = (
            "AnswerV1"
        )
    model, _ = wrapper(handler_for(payload))
    result = model.with_structured_output(AnswerV1, method=method).invoke("hi")
    assert result == AnswerV1(answer="Hello")


def test_typed_dict_and_runnable_schemas(wrapper):
    from typing_extensions import TypedDict

    class TypedAnswer(TypedDict):
        answer: str

    model, _ = wrapper(handler_for(payload_for(False)))
    structured = model.with_structured_output(TypedAnswer)
    assert structured.invoke("hi") == {"answer": "Hello"}
    assert structured.get_input_schema() is not None
    assert structured.get_output_schema() is not None
    assert model.with_structured_output(Answer).get_output_schema() is Answer
    assert (
        model.with_structured_output(Answer, include_raw=True).get_output_schema()
        is not None
    )


@pytest.mark.parametrize("async_api", [False, True])
def test_streamed_structured_cache_invoke_revalidates_without_replay(
    wrapper, async_loop, async_api
):
    sources = []
    handler = handler_for(payload_for(True, text='{"answer":"broken'), sources)
    model, manager = wrapper(handler, use_responses_api=True, cache=InMemoryCache())
    structured = model.with_structured_output(Answer, include_raw=True)

    async def run():
        return [
            await structured.ainvoke("hi", stream=True),
            await structured.ainvoke("hi", stream=True),
        ]

    results = (
        async_loop.run_until_complete(run())
        if async_api
        else [
            structured.invoke("hi", stream=True),
            structured.invoke("hi", stream=True),
        ]
    )
    assert all(
        r["parsed"] is None and isinstance(r["parsing_error"], OutputParserException)
        for r in results
    )
    assert handler.call_count == 1 and sources[0].closed
    assert len(audit_events(manager)) == 1
