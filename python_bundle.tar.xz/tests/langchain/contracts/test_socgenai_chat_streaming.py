"""G04: real LangChain/manager/SDK contracts over synthetic Azure SSE."""

from tests.langchain.support import V3_BETA_WARNING, events_for

import asyncio
from copy import deepcopy
from decimal import Decimal
import json
from threading import Event
from unittest.mock import Mock

import httpx2
from langchain_core.caches import InMemoryCache
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import AIMessageChunk
from langchain_core.runnables.utils import AddableDict
from langchain_openai import ChatOpenAI
from openai import APIError, BadRequestError
import pytest

from genai_api_manager import (
    StreamAssemblyError,
    UnexpectedStreamEndError,
    UnpricedModelError,
)
from socgenai_llm import GenAIBudgetExceededError, GenAIRefusalError
from tests.support.client import audit_events
from tests.support.azure import chat_payload
from tests.support.azure import WireStream, chunk, text_events, wire_response
from tests.langchain.support import Answer, METHODS
from tests.langchain.support import aggregate


@pytest.mark.parametrize(
    "mode",
    [
        "stream",
        "invoke",
        "astream",
        "ainvoke",
        pytest.param("v3", marks=V3_BETA_WARNING),
        pytest.param("av3", marks=V3_BETA_WARNING),
        pytest.param(
            "events_v1",
            marks=pytest.mark.filterwarnings(
                "ignore:^astream_events version='v1' is deprecated\\.:"
                "langchain_core._api.deprecation.LangChainDeprecationWarning"
            ),
        ),
        "events_v2",
    ],
)
@pytest.mark.parametrize("output_version", ["v0", "v1"])
def test_full_surface(wrapper, async_loop, mode, output_version):
    source = WireStream(events_for(text="Hello world"))
    bodies, tokens = [], []

    def handle(request):
        bodies.append(json.loads(request.content))
        assert "api-version" not in request.url.params
        return wire_response(source)

    class Callback(BaseCallbackHandler):
        def on_llm_new_token(self, token, **kwargs):
            tokens.append(token)

    model, manager = wrapper(handle, output_version=output_version)
    config = {"callbacks": [Callback()]}
    if mode == "stream":
        iterator = model.stream("hi", config)
        assert not bodies
        first = next(iterator)
        assert isinstance(first, AIMessageChunk)
        assert source.reads == 1
        result = aggregate([first, *iterator])
    elif mode == "invoke":
        result = model.invoke("hi", config, stream=True)
    elif mode == "v3":
        stream = model.stream_events("hi", config, version="v3")
        result = stream.output
    else:

        async def run():
            if mode == "astream":
                return aggregate([c async for c in model.astream("hi", config)])
            if mode == "ainvoke":
                return await model.ainvoke("hi", config, stream=True)
            if mode == "av3":
                stream = await model.astream_events("hi", config, version="v3")
                async with stream:
                    return await stream.output
            events = [
                e async for e in model.astream_events("hi", config, version=mode[-2:])
            ]
            return next(
                e["data"]["output"] for e in events if e["event"] == "on_chat_model_end"
            )

        result = async_loop.run_until_complete(run())
    assert result.text == "Hello world"
    assert result.usage_metadata["input_tokens"] == 1000
    assert len(tokens) == 4
    assert len(bodies) == 1 and bodies[0]["stream"] is True
    assert bodies[0]["stream_options"]["include_usage"] is True
    assert "_genai_stream_owner" not in bodies[0]
    assert source.closed
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("async_api", [False, True])
@pytest.mark.parametrize("case", ["valid", "truncated", "length", "refusal"])
def test_structured_final_only(wrapper, async_loop, method, async_api, case):
    text = '{"answer":"Hello"}' if case != "truncated" else '{"answer":"Hello'
    events = events_for(method, text, "length" if case == "length" else None)
    if case == "refusal":
        events[0]["choices"][0]["delta"]["refusal"] = "Cannot comply"
    source = WireStream(events)
    model, manager = wrapper(lambda _: wire_response(source))
    structured = model.with_structured_output(Answer, method=method, include_raw=True)
    parts = []
    if async_api:

        async def run():
            async for part in structured.astream("hi"):
                parts.append(part)
                if "parsed" in part:
                    assert source.closed

        async_loop.run_until_complete(run())
    else:
        for part in structured.stream("hi"):
            parts.append(part)
            if "parsed" in part:
                assert source.closed
    assert "raw" in parts[0] and "parsed" not in parts[0]
    assert sum("parsed" in p for p in parts) == 1
    result = AddableDict()
    for part in parts:
        result += part
    if case == "valid":
        assert result["parsed"] == Answer(answer="Hello")
        assert result["parsing_error"] is None
    else:
        assert result["parsed"] is None
        assert result["parsing_error"] is not None
        if case == "refusal":
            assert isinstance(result["parsing_error"], GenAIRefusalError)
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize(
    "mode",
    [
        "stream",
        "invoke",
        pytest.param("v3", marks=V3_BETA_WARNING),
        "astream",
        "ainvoke",
        pytest.param("av3", marks=V3_BETA_WARNING),
    ],
)
@pytest.mark.parametrize(
    "outcome", ["callback", "early_close", "eof", "read_error", "conversion"]
)
def test_cleanup(wrapper, async_loop, mode, outcome):
    original = APIError(
        "synthetic error",
        request=httpx2.Request("POST", "https://synthetic.invalid"),
        body={"detail": "retained"},
    )
    events = events_for(text="Hello world")
    if outcome == "eof":
        events = events[:1]
    if outcome == "conversion":
        events[0]["choices"][0]["index"] = 7
    source = WireStream(events, error=original if outcome == "read_error" else None)
    handler = Mock(return_value=wire_response(source))
    model, manager = wrapper(handler)

    class Broken(BaseCallbackHandler):
        raise_error = True

        def on_llm_new_token(self, *args, **kwargs):
            raise LookupError("callback")

    config = {"callbacks": [Broken()] if outcome == "callback" else []}

    def sync():
        if mode == "invoke":
            return model.invoke("hi", config, stream=True)
        if mode == "v3":
            stream = model.stream_events("hi", config, version="v3")
            if outcome == "early_close":
                next(iter(stream.text))
                model.close()
                return
            return stream.output
        iterator = model.stream("hi", config)
        try:
            return next(iterator) if outcome == "early_close" else list(iterator)
        finally:
            iterator.close()

    async def run():
        if mode == "ainvoke":
            return await model.ainvoke("hi", config, stream=True)
        if mode == "av3":
            stream = await model.astream_events("hi", config, version="v3")
            async with stream:
                if outcome == "early_close":
                    return await anext(aiter(stream.text))
                return await stream.output
        iterator = model.astream("hi", config)
        try:
            return (
                await anext(iterator)
                if outcome == "early_close"
                else [c async for c in iterator]
            )
        finally:
            await iterator.aclose()

    expected = {
        "callback": LookupError,
        "eof": UnexpectedStreamEndError,
        "read_error": APIError,
        "conversion": StreamAssemblyError,
    }

    def call():
        return async_loop.run_until_complete(run()) if mode.startswith("a") else sync()

    if outcome == "early_close":
        call()
    else:
        with pytest.raises(expected[outcome]) as caught:
            call()
        if outcome == "read_error":
            assert caught.value is original
        if outcome in ("eof", "conversion"):
            assert caught.value.event is not None
            assert caught.value.request_id == "request-synthetic"
    assert source.closed
    assert handler.call_count == 1
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize(
    "mode", ["astream", "ainvoke", pytest.param("av3", marks=V3_BETA_WARNING)]
)
def test_cancel_blocked_read(wrapper, async_loop, mode):
    entered, release = Event(), Event()

    class Blocked(WireStream):
        def __iter__(self):
            entered.set()
            assert release.wait(5)
            yield from super().__iter__()

    source = Blocked(events_for(text="Hello world"))
    model, manager = wrapper(lambda _: wire_response(source))

    async def run():
        stream = None
        if mode == "av3":
            stream = await model.astream_events("hi", version="v3")
            task = asyncio.ensure_future(stream.output)
        elif mode == "ainvoke":
            task = asyncio.create_task(model.ainvoke("hi", stream=True))
        else:
            stream = model.astream("hi")
            task = asyncio.create_task(anext(stream))
        assert await asyncio.to_thread(entered.wait, 5)
        task.cancel()
        release.set()
        with pytest.raises(asyncio.CancelledError):
            await task
        if stream is not None:
            await stream.aclose()
        assert source.closed

    try:
        async_loop.run_until_complete(run())
    finally:
        release.set()
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize(
    "options",
    [
        {"n": 2},
        {"extra_body": {"n": 2}},
        {"stream": True, "extra_body": {"stream": False}},
    ],
)
def test_reject_before_dispatch(wrapper, options):
    handler = Mock()
    model, _ = wrapper(handler)
    with pytest.raises(ValueError):
        list(model.stream("hi", **options))
    handler.assert_not_called()


@pytest.mark.parametrize("disabled", [True, "tool_calling"])
def test_disabled_stream_uses_ordinary_result(wrapper, disabled):
    handler = Mock(return_value=httpx2.Response(200, json=chat_payload()))
    model, manager = wrapper(handler, disable_streaming=disabled)
    kwargs = (
        {
            "tools": [
                {
                    "type": "function",
                    "function": {"name": "lookup", "parameters": {"type": "object"}},
                }
            ]
        }
        if disabled == "tool_calling"
        else {}
    )
    assert model.invoke("hi", stream=True, **kwargs).text == "Hello"
    assert list(model.stream("hi", **kwargs))[0].text == "Hello"
    assert all(
        json.loads(call.args[0].content).get("stream", False) is False
        for call in handler.call_args_list
    )
    assert len(audit_events(manager)) == 2


def test_cache_and_authoritative_usage(wrapper):
    events = text_events()
    events.insert(0, chunk([], usage=chat_payload()["usage"]))
    handler = Mock(side_effect=lambda _: wire_response(WireStream(events)))
    model, manager = wrapper(handler, cache=InMemoryCache())
    for _ in range(2):
        result = model.invoke("hi", stream=True)
        assert result.usage_metadata["input_tokens"] == 1000
    assert handler.call_count == 1
    for _ in range(2):
        assert (
            aggregate(list(model.stream("hi"))).usage_metadata["input_tokens"] == 1000
        )
    assert handler.call_count == 3
    assert len(audit_events(manager)) == 3


@pytest.mark.parametrize(
    "case",
    [
        "missing_usage",
        "partial_usage",
        "filter",
        "length",
        "http",
        "unpriced",
        "budget",
    ],
)
def test_terminal_accounting(wrapper, case):
    events = text_events(
        finish={"filter": "content_filter", "length": "length"}.get(case, "stop")
    )
    if case == "missing_usage":
        events.pop()
    if case == "partial_usage":
        del events[-1]["usage"]["completion_tokens"]
    source = WireStream(events)
    handler = Mock(
        return_value=httpx2.Response(
            400, json={"error": {"message": "synthetic", "type": "bad_request"}}
        )
        if case == "http"
        else wire_response(source)
    )
    model, manager = wrapper(handler)
    if case == "budget":
        manager.log_manager.daily_cost_limit = 0
        manager.log_manager._budget.record(
            manager.log_manager._accounting_key(), Decimal("0.01")
        )
    errors = {
        "filter": ValueError,
        "http": BadRequestError,
        "unpriced": UnpricedModelError,
        "budget": GenAIBudgetExceededError,
    }
    kwargs = {"model": "unpriced"} if case == "unpriced" else {}
    if case in errors:
        with pytest.raises(errors[case]):
            list(model.stream("hi", **kwargs))
    else:
        result = aggregate(list(model.stream("hi")))
        if case in ("missing_usage", "partial_usage"):
            assert result.usage_metadata is None
        else:
            assert result.response_metadata["finish_reason"] == "length"
    if case in ("unpriced", "budget"):
        handler.assert_not_called()
    elif case == "http":
        assert audit_events(manager) == []
    else:
        (event,) = audit_events(manager)
        if case == "filter":
            assert source.closed and event["total_cost"] == 1.12


def test_native_tool_conversion_parity(wrapper):
    events = events_for("function_calling")
    # Two interleaved calls with independent indexes and fragmented arguments.
    for event in events[:2]:
        tool = deepcopy(event["choices"][0]["delta"]["tool_calls"][0])
        tool["index"] = 1
        if "id" in tool:
            tool["id"] = "call_second"
        event["choices"][0]["delta"]["tool_calls"].append(tool)
    model, _ = wrapper(lambda _: wire_response(WireStream(events)))
    actual = aggregate(list(model.stream("hi")))
    with httpx2.Client(
        transport=httpx2.MockTransport(lambda _: wire_response(WireStream(events)))
    ) as client:
        native = ChatOpenAI(
            base_url="https://synthetic.openai.azure.com/openai/v1/",
            api_key="synthetic",
            model="deployment",
            http_client=client,
            async_client=Mock(),
            http_socket_options=(),
            max_retries=0,
            stream_usage=True,
        )
        try:
            expected = aggregate(list(native.stream("hi")))
        finally:
            native.root_client.close()
    assert actual.tool_calls == expected.tool_calls
    assert actual.usage_metadata == {
        k: v for k, v in expected.usage_metadata.items() if v != {}
    }
    assert len(actual.tool_calls) == 2
    assert len(actual.additional_kwargs["tool_calls"]) == 2


@V3_BETA_WARNING
@pytest.mark.parametrize("async_api", [False, True])
def test_v3_tool_projection_and_event_callback_cleanup(wrapper, async_loop, async_api):
    sources = []

    def handle(request):
        source = WireStream(events_for("function_calling"))
        sources.append(source)
        return wire_response(source)

    model, manager = wrapper(handle)

    class BrokenEvent(BaseCallbackHandler):
        raise_error = True

        def on_stream_event(self, *args, **kwargs):
            raise LookupError("event callback failed")

    if async_api:

        async def run():
            stream = await model.astream_events("hi", version="v3")
            async with stream:
                calls = await stream.tool_calls
                assert calls[0]["args"] == {"answer": "Hello"}
            broken = await model.astream_events(
                "hi", {"callbacks": [BrokenEvent()]}, version="v3"
            )
            async with broken:
                with pytest.raises(LookupError):
                    await broken.output

        async_loop.run_until_complete(run())
    else:
        stream = model.stream_events("hi", version="v3")
        assert stream.tool_calls.get()[0]["args"] == {"answer": "Hello"}
        with pytest.raises(LookupError):
            model.stream_events(
                "hi", {"callbacks": [BrokenEvent()]}, version="v3"
            ).output
    assert all(source.closed for source in sources)
    assert len(audit_events(manager)) == 2


@pytest.mark.parametrize("internal", [False, True])
@pytest.mark.parametrize("where", ["call", "model_kwargs", "extra_body"])
def test_stream_controls_and_input_preservation(wrapper, internal, where):
    options = {"stream": True, "n": 1, "stream_options": {"include_usage": False}}
    original = deepcopy(options)
    handler = Mock(side_effect=lambda _: wire_response(WireStream(text_events())))
    model, manager = wrapper(
        handler,
        internal=internal,
        model_kwargs=options if where == "model_kwargs" else {},
    )
    kwargs = (
        options
        if where == "call"
        else {"extra_body": options}
        if where == "extra_body"
        else {}
    )
    assert model.invoke("hi", **kwargs).text == "Hello"
    body = json.loads(handler.call_args.args[0].content)
    assert body["stream"] is True and body["stream_options"]["include_usage"] is True
    assert options == original
    assert len(audit_events(manager)) == 1


def test_stream_metadata_and_cache_write_details(wrapper):
    events = text_events()
    events[0]["prompt_filter_results"] = [
        {"prompt_index": 0, "content_filter_results": {}}
    ]
    events[0]["choices"][0]["logprobs"] = {
        "content": [
            {"token": "Hello", "bytes": [72], "logprob": -0.1, "top_logprobs": []}
        ]
    }
    events[1].update(system_fingerprint="synthetic-fingerprint")
    events[-1]["usage"]["prompt_tokens_details"]["cache_write_tokens"] = 10
    events[-1]["usage"]["completion_tokens_details"] = {"reasoning_tokens": 4}
    model, manager = wrapper(lambda _: wire_response(WireStream(events)))
    result = aggregate(list(model.stream("hi")))
    assert result.id == "chatcmpl-synthetic"
    assert result.response_metadata["system_fingerprint"] == "synthetic-fingerprint"
    assert result.response_metadata["model_name"] == "deployment"
    assert (
        result.response_metadata["prompt_filter_results"]
        == events[0]["prompt_filter_results"]
    )
    assert result.response_metadata["logprobs"]["content"][0]["token"] == "Hello"
    assert result.usage_metadata["input_token_details"] == {
        "cache_read": 600,
        "cache_creation": 10,
    }
    assert result.usage_metadata["output_token_details"]["reasoning"] == 4
    (event,) = audit_events(manager)
    assert event["total_cost"] is None  # No configured cache-write rate.
