"""SDK retries shared by ordinary and streamed Chat Completions/Responses calls."""

from contextlib import aclosing, closing
from copy import deepcopy
from decimal import Decimal
import json
from unittest.mock import Mock

import httpx2
from langchain_core.caches import InMemoryCache
from openai import APIConnectionError, APIError, RateLimitError
import pytest

from genai_api_manager import UnexpectedStreamEndError, UnpricedModelError
from socgenai_llm import GenAIChatModel, GenAIBudgetExceededError, chat_model
from tests.langchain.support import aggregate
from tests.support.client import audit_events
from tests.support.standard import standard_handler


pytestmark = pytest.mark.usefixtures("retry_delays")


def call(model, mode, async_api, loop, **kwargs):
    options = {"stream": False} if mode == "native" else {}
    options.update(kwargs)
    if async_api:

        async def run():
            if mode == "stream":
                async with aclosing(model.astream("hi", **options)) as stream:
                    return aggregate([part async for part in stream])
            return await model.ainvoke("hi", **options)

        return loop.run_until_complete(run())
    if mode == "stream":
        with closing(model.stream("hi", **options)) as stream:
            return aggregate(list(stream))
    return model.invoke("hi", **options)


@pytest.mark.parametrize(
    "options", [{}, {"max_retries": None}, {"max_retries": 0}, {"max_retries": 3}]
)
def test_constructor_forwards_only_explicit_retries(make_client, monkeypatch, options):
    manager = make_client(standard_handler())
    constructor = Mock(return_value=manager)
    monkeypatch.setattr(chat_model, "GenAiApiClient", constructor)
    with GenAIChatModel(model="deployment", **options) as model:
        expected = {} if options.get("max_retries") is None else options
        constructor.assert_called_once_with(**expected)
        assert model.max_retries == options.get("max_retries")


@pytest.mark.parametrize("value", [-1, True, False, 1.0, "2", [], {}])
def test_invalid_retry_values_fail_before_manager_construction(monkeypatch, value):
    constructor = Mock(side_effect=AssertionError("Must not construct manager"))
    monkeypatch.setattr(chat_model, "GenAiApiClient", constructor)
    with pytest.raises(ValueError, match="max_retries"):
        GenAIChatModel(model="deployment", max_retries=value)
    constructor.assert_not_called()


@pytest.mark.parametrize(
    "options", [{"max_retries": 2}, {"extra_body": {"max_retries": 2}}]
)
def test_retry_in_model_kwargs_fails_before_manager_construction(monkeypatch, options):
    constructor = Mock(side_effect=AssertionError("Must not construct manager"))
    monkeypatch.setattr(chat_model, "GenAiApiClient", constructor)
    with pytest.raises(
        ValueError, match="max_retries on the GenAIChatModel constructor"
    ):
        GenAIChatModel(model="deployment", model_kwargs=options)
    constructor.assert_not_called()


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
@pytest.mark.parametrize("mode", ["native", "internal", "stream"])
@pytest.mark.parametrize("async_api", [False, True], ids=["sync", "async"])
def test_retry_before_response_preserves_payload_usage_and_one_charge(
    wrapper, async_loop, retry_delays, responses, mode, async_api
):
    requests, sources = [], []
    success = standard_handler(sources=sources)

    def handle(request):
        requests.append(request)
        if len(requests) <= 2:
            return httpx2.Response(429, json={"error": {"message": "Synthetic busy"}})
        return success(request)

    model, manager = wrapper(
        handle, max_retries=2, use_responses_api=responses, internal=...
    )
    assert manager._openai_client.max_retries == 2
    result = call(model, mode, async_api, async_loop)
    assert result.text == "Hello"
    assert result.usage_metadata["input_tokens"] == 1000
    assert result.usage_metadata["output_tokens"] == 200
    assert len(requests) == 3 and len(retry_delays) == 2
    assert all(request.content == requests[0].content for request in requests)
    assert all(request.url == requests[0].url for request in requests)
    assert requests[0].url.path == "/openai/v1/" + (
        "responses" if responses else "chat/completions"
    )
    body = json.loads(requests[0].content)
    assert "max_retries" not in body
    assert body["stream"] is (mode != "native")
    assert len(sources) == (mode != "native")
    assert all(source.closed for source in sources)
    model.close()
    model.close()
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12 and event["status"] == "completed"
    assert Decimal(manager.log_manager.get_metrics()["daily_cost_exact"]) == Decimal(
        "1.12"
    )


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
@pytest.mark.parametrize("mode", ["native", "internal", "stream"])
@pytest.mark.parametrize("async_api", [False, True], ids=["sync", "async"])
@pytest.mark.parametrize("retries", [0, 2])
def test_exhausted_or_disabled_retries_preserve_error_without_accounting(
    wrapper, async_loop, retry_delays, responses, mode, async_api, retries
):
    error = {
        "message": "Full synthetic rate limit",
        "code": "rate_limit",
        "details": ["preserved"],
    }
    handler = Mock(return_value=httpx2.Response(429, json={"error": error}))
    model, manager = wrapper(
        handler, max_retries=retries, use_responses_api=responses, internal=...
    )
    with pytest.raises(RateLimitError) as caught:
        call(model, mode, async_api, async_loop)
    assert caught.value.body == error
    assert error["message"] in str(caught.value)
    assert handler.call_count == retries + 1
    assert len(retry_delays) == retries
    assert manager.log_manager.check_daily_cost() == 0
    assert audit_events(manager) == []


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
@pytest.mark.parametrize("mode", ["internal", "stream"])
@pytest.mark.parametrize("async_api", [False, True], ids=["sync", "async"])
@pytest.mark.parametrize("failure", ["read_error", "sdk_error", "eof"])
def test_consumed_stream_is_closed_without_replay(
    wrapper, async_loop, retry_delays, responses, mode, async_api, failure
):
    requests, sources = [], []
    success = standard_handler(sources=sources)
    original = httpx2.ReadError("Synthetic failure during stream consumption")
    sdk_error = APIError(
        "Full synthetic SDK stream failure",
        request=httpx2.Request("POST", "https://synthetic.invalid"),
        body={"details": "preserved"},
    )

    def handle(request):
        requests.append(request)
        response = success(request)
        source = sources[-1]
        # Stop after the first actual content, before terminal status or usage.
        if responses:
            index = next(
                i
                for i, event in enumerate(source.events)
                if event["type"] == "response.output_text.delta"
            )
            source.events = source.events[: index + 1]
        else:
            source.events = source.events[:1]
        source.error = {"read_error": original, "sdk_error": sdk_error, "eof": None}[
            failure
        ]
        source.done = False
        return response

    model, manager = wrapper(
        handle, max_retries=3, use_responses_api=responses, internal=...
    )
    with pytest.raises(
        {
            "read_error": APIConnectionError,
            "sdk_error": APIError,
            "eof": UnexpectedStreamEndError,
        }[failure]
    ) as caught:
        call(model, mode, async_api, async_loop)
    if failure == "read_error":
        assert caught.value.__cause__ is original
    elif failure == "sdk_error":
        assert caught.value is sdk_error
    assert len(requests) == 1 and retry_delays == []
    assert sources[0].closed
    model.close()
    (event,) = audit_events(manager)
    assert event["total_cost"] is None
    assert event["status"] != "completed"
    assert manager.log_manager.check_daily_cost() == 0


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
@pytest.mark.parametrize("async_api", [False, True], ids=["sync", "async"])
def test_early_close_does_not_retry(
    wrapper, async_loop, retry_delays, responses, async_api
):
    sources = []
    handler = Mock(side_effect=standard_handler(sources=sources))
    model, manager = wrapper(handler, max_retries=3, use_responses_api=responses)
    if async_api:

        async def run():
            async with aclosing(model.astream("hi")) as stream:
                await anext(stream)

        async_loop.run_until_complete(run())
    else:
        with closing(model.stream("hi")) as stream:
            next(stream)
    assert handler.call_count == 1 and retry_delays == []
    assert sources[0].closed
    (event,) = audit_events(manager)
    assert event["status"] == "partial" and event["total_cost"] is None


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
@pytest.mark.parametrize("mode", ["native", "internal", "stream"])
@pytest.mark.parametrize(
    "location", ["call", "bind", "extra_body", "mutated_model_kwargs"]
)
def test_per_call_retries_are_rejected_without_dispatch(
    wrapper, async_loop, responses, mode, location
):
    handler = Mock(side_effect=AssertionError("Must not dispatch"))
    model, manager = wrapper(handler, max_retries=2, use_responses_api=responses)
    options = {"max_retries": 1}
    if location == "extra_body":
        options = {"extra_body": options}
    before = deepcopy(options)
    target = model.bind(**options) if location == "bind" else model
    if location == "mutated_model_kwargs":
        model.model_kwargs.update(options)
    with pytest.raises(
        ValueError, match="max_retries on the GenAIChatModel constructor"
    ):
        call(
            target,
            mode,
            False,
            async_loop,
            **(options if location in ("call", "extra_body") else {}),
        )
    assert options == before
    handler.assert_not_called()
    assert manager._openai_client.max_retries == 2
    assert audit_events(manager) == []


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
def test_retry_setting_does_not_change_cache_identity(wrapper, responses):
    cache = InMemoryCache()
    first_handler = Mock(side_effect=standard_handler())
    second_handler = Mock(side_effect=AssertionError("Expected a cache hit"))
    first, first_manager = wrapper(
        first_handler, max_retries=0, cache=cache, use_responses_api=responses
    )
    second, second_manager = wrapper(
        second_handler, max_retries=3, cache=cache, use_responses_api=responses
    )
    assert first.invoke("hi").text == second.invoke("hi").text == "Hello"
    assert first_handler.call_count == 1
    second_handler.assert_not_called()
    assert len(audit_events(first_manager)) == 1
    assert audit_events(second_manager) == []


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
@pytest.mark.parametrize("failure", ["budget", "unpriced"])
def test_local_rejections_do_not_enter_sdk_retries(
    wrapper, retry_delays, responses, failure
):
    handler = Mock(side_effect=AssertionError("Must not dispatch"))
    model, manager = wrapper(handler, max_retries=3, use_responses_api=responses)
    if failure == "budget":
        manager.log_manager.daily_cost_limit = 0
        manager.log_manager._budget.record(
            manager.log_manager._accounting_key(), Decimal("0.01")
        )
    else:
        model.model = "unpriced"
    with pytest.raises(
        GenAIBudgetExceededError if failure == "budget" else UnpricedModelError
    ):
        model.invoke("hi")
    handler.assert_not_called()
    assert retry_delays == []
    assert audit_events(manager) == []
