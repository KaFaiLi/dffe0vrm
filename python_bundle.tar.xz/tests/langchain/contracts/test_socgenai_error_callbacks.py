"""Error callbacks retain provider data without deprecated Pydantic serialization."""

import json
from unittest.mock import Mock
import warnings

import httpx2
from langchain_core.callbacks import BaseCallbackHandler
import pytest

from socgenai_llm import GenAIResponseError, _responses_compat
from tests.langchain.support import reasoning_response, response_events
from tests.support.azure import WireStream, wire_response
from tests.support.client import audit_events


@pytest.mark.parametrize(
    "mode,outcome",
    [
        (mode, outcome)
        for outcome in ("failed", "conversion")
        for mode in ("invoke", "stream", "ainvoke", "astream")
    ]
    + [
        ("invoke", "cancelled"),
        ("ainvoke", "cancelled"),
        ("stream", "error_event"),
        ("astream", "error_event"),
    ],
)
@pytest.mark.parametrize("warning_policy", ["always", "error"])
def test_error_callback_body_preserves_provider_data(
    wrapper, async_loop, monkeypatch, mode, outcome, warning_policy
):
    payload = reasoning_response(
        status=outcome if outcome in ("failed", "cancelled") else "completed"
    )
    payload["provider_extension"] = {"retained": "Synthetic provider detail"}
    payload["error"] = (
        {"code": "server_error", "message": "Synthetic provider failure"}
        if outcome == "failed"
        else None
    )
    sources = []

    def handle(request):
        if json.loads(request.content).get("stream"):
            events = (
                [
                    {
                        "type": "error",
                        "code": "server_error",
                        "message": "Synthetic provider failure",
                        "param": None,
                        "sequence_number": 0,
                        "provider_extension": payload["provider_extension"],
                    }
                ]
                if outcome == "error_event"
                else response_events(payload)
            )
            source = WireStream(events)
            sources.append(source)
            return wire_response(source)
        return httpx2.Response(200, json=payload)

    handler = Mock(side_effect=handle)
    model, manager = wrapper(handler, use_responses_api=True)
    original = ValueError("Synthetic conversion failure")
    if outcome == "conversion":
        if mode in ("stream", "astream"):
            convert = _responses_compat._convert_responses_chunk_to_generation_chunk

            def fail_at_terminal(event, *args, **kwargs):
                if event.type == "response.completed":
                    raise original
                return convert(event, *args, **kwargs)

            monkeypatch.setattr(
                _responses_compat,
                "_convert_responses_chunk_to_generation_chunk",
                fail_at_terminal,
            )
        else:
            monkeypatch.setattr(
                _responses_compat,
                "_construct_lc_result_from_responses_api",
                Mock(side_effect=original),
            )

    errors = []

    class Callback(BaseCallbackHandler):
        def on_llm_error(self, error, *, response, **kwargs):
            errors.append((error, response))

    config = {"callbacks": [Callback()]}

    async def run():
        if mode == "ainvoke":
            return await model.ainvoke("hi", config)
        return [chunk async for chunk in model.astream("hi", config)]

    # Warning-as-error alone misses this regression: LangChain catches the
    # deprecated serializer's error and silently discards the callback body.
    with warnings.catch_warnings(record=True) as observed:
        warnings.simplefilter(warning_policy)
        with pytest.raises(GenAIResponseError) as caught:
            if mode.startswith("a"):
                async_loop.run_until_complete(run())
            elif mode == "invoke":
                model.invoke("hi", config)
            else:
                list(model.stream("hi", config))
    assert not observed, [str(item.message) for item in observed]

    error = caught.value
    provider = getattr(error.event, "response", error.event)
    assert error.provider_response is provider
    assert getattr(error.response, "id", None) == getattr(provider, "id", None)
    assert getattr(error.response, "usage", None) is getattr(provider, "usage", None)
    assert error.response.model_dump() == provider.model_dump()
    assert error.body == error.event.model_dump(exclude_unset=True, warnings=False)
    assert error.usage is getattr(provider, "usage", None)
    if outcome == "conversion":
        assert error.__cause__ is original
    ((callback_error, result),) = errors
    assert callback_error is error
    metadata = result.generations[-1][0].message.response_metadata
    assert isinstance(metadata["body"], dict)
    assert metadata["body"] == provider.model_dump(mode="json")
    assert metadata["body"]["provider_extension"] == payload["provider_extension"]
    assert metadata["request_id"] == error.request_id
    assert handler.call_count == 1
    assert all(source.closed for source in sources)
    (event,) = audit_events(manager)
    assert event["total_cost"] == (None if outcome == "error_event" else 1.12)
