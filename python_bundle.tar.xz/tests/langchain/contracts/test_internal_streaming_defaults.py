"""Ordinary wrapper calls preserve the manager's default and explicit opt-out."""

from copy import deepcopy
import json

import httpx2
import pytest
from langchain_core.messages import AIMessage

from tests.support.azure import (
    WireStream,
    chat_payload,
    response_payload,
    text_events,
    wire_response,
)
from tests.support.client import audit_events


@pytest.mark.parametrize("responses", [False, True], ids=["chat", "responses"])
@pytest.mark.parametrize("async_api", [False, True], ids=["invoke", "ainvoke"])
@pytest.mark.parametrize("where", ["omitted", "call", "model_kwargs", "extra_body"])
def test_ordinary_wrapper_defaults_and_explicit_false(
    wrapper, async_loop, responses, async_api, where
):
    streaming = where == "omitted"
    requests, sources = [], []
    payload = response_payload() if responses else chat_payload()

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        assert body["stream"] is streaming
        if streaming:
            events = (
                [
                    {
                        "type": "response.completed",
                        "sequence_number": 0,
                        "response": payload,
                    }
                ]
                if responses
                else text_events()
            )
            source = WireStream(events)
            sources.append(source)
            return wire_response(source)
        return httpx2.Response(200, json=payload)

    options = {"stream": False}
    before = deepcopy(options)
    model, manager = wrapper(
        handle,
        internal=...,
        use_responses_api=responses,
        model_kwargs=options if where == "model_kwargs" else {},
    )
    kwargs = (
        options
        if where == "call"
        else {"extra_body": options}
        if where == "extra_body"
        else {}
    )
    result = (
        async_loop.run_until_complete(model.ainvoke("hi", **kwargs))
        if async_api
        else model.invoke("hi", **kwargs)
    )
    assert isinstance(result, AIMessage) and result.text == "Hello"
    assert result.usage_metadata["input_tokens"] == 1000
    assert result.usage_metadata["output_tokens"] == 200
    assert options == before
    assert len(requests) == 1 and all(source.closed for source in sources)
    (event,) = audit_events(manager)
    assert event["status"] == "completed" and event["total_cost"] == 1.12
