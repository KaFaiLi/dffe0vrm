"""Documented Azure native-tool requests through LangChain -> manager -> SDK.

Sources checked 2026-10-04, with the workspace's locked OpenAI 3.24.0 SDK:
https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/web-search
https://learn.microsoft.com/en-us/rest/api/microsoft-foundry/azureopenai/responses

Inspect serialized HTTP bodies, not mocked SDK method arguments. The replies are
synthetic acknowledgements: these tests establish request forwarding/format,
not live tool execution, deployment availability, resource validity, or billing.
"""

from copy import deepcopy
from functools import partial
import json

import httpx2
from openai import BadRequestError
import pytest

from tests.langchain.support import aggregate, response_events
from tests.support.azure import WireStream, response_payload, wire_response
from tests.support.client import audit_events


TOOL_CASES = [
    pytest.param(
        {
            "type": "web_search",
            "filters": {"allowed_domains": ["example.com"]},
            "user_location": {"type": "approximate", "country": "FR"},
        },
        ["web_search_call.action.sources"],
        # Azure's guide documents web_search, but the current tool-choice enum
        # does not list {"type": "web_search"}. With one tool, required selects it.
        "required",
        id="web-search",
    ),
    pytest.param(
        {
            "type": "file_search",
            "vector_store_ids": ["vs_synthetic"],
            "max_num_results": 3,
            "filters": {"type": "eq", "key": "category", "value": "synthetic"},
        },
        ["file_search_call.results"],
        {"type": "file_search"},
        id="file-search",
    ),
    pytest.param(
        {
            "type": "code_interpreter",
            "container": {"type": "auto", "file_ids": ["file-synthetic"]},
        },
        ["code_interpreter_call.outputs"],
        {"type": "code_interpreter"},
        id="code-interpreter",
    ),
    pytest.param(
        {
            "type": "mcp",
            "server_label": "synthetic",
            "server_url": "https://example.invalid/mcp",
            "allowed_tools": ["lookup"],
            "require_approval": "always",
            "headers": {"Authorization": "Bearer synthetic-mcp-token"},
        },
        [],
        {"type": "mcp", "server_label": "synthetic", "name": "lookup"},
        id="mcp",
    ),
]

PROMPT = "Synthetic tool request."
MODES = [
    "invoke",
    "internal_invoke",
    "stream",
    "ainvoke",
    "internal_ainvoke",
    "astream",
]


def _reply(request, requests, sources):
    requests.append(request)
    payload = response_payload()
    if json.loads(request.content).get("stream"):
        source = WireStream(response_events(payload), named=True)
        sources.append(source)
        return wire_response(source)
    return httpx2.Response(200, json=payload)


def _invoke(bound, mode, async_loop):
    if mode == "stream":
        return aggregate(list(bound.stream(PROMPT)))
    if mode == "astream":

        async def consume():
            return aggregate([chunk async for chunk in bound.astream(PROMPT)])

        return async_loop.run_until_complete(consume())
    # Omitted stream exercises the manager's default internal collection;
    # explicit False exercises the ordinary JSON transport.
    options = {} if mode.startswith("internal_") else {"stream": False}
    if mode.endswith("ainvoke"):
        return async_loop.run_until_complete(bound.ainvoke(PROMPT, **options))
    return bound.invoke(PROMPT, **options)


def _assert_request(request, tools, choice, include, *, streaming):
    assert request.method == "POST"
    assert request.url.host == "synthetic.openai.azure.com"
    assert request.url.path == "/openai/v1/responses"
    assert not request.url.query  # No api-version or deployment URL routing.
    assert request.headers["content-type"] == "application/json"
    # Exact wire contract also excludes leaked LangChain options, Chat messages,
    # nested function envelopes, and Chat-only stream_options/include_usage.
    assert json.loads(request.content) == {
        "model": "deployment",
        "input": [{"type": "message", "role": "user", "content": PROMPT}],
        "tools": tools,
        "tool_choice": choice,
        "include": include,
        "store": False,
        "max_output_tokens": 64,
        "stream": streaming,
    }


@pytest.mark.parametrize("tool,include,forced_choice", TOOL_CASES)
@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("force_tool", [False, True], ids=["auto", "selected"])
def test_native_tool_wire_contract(
    wrapper, async_loop, tool, include, forced_choice, mode, force_tool
):
    requests, sources = [], []
    model, manager = wrapper(
        partial(_reply, requests=requests, sources=sources),
        internal=...,
        use_responses_api=True,
        max_tokens=64,
    )
    choice = forced_choice if force_tool else "auto"
    options = deepcopy({"tools": [tool], "tool_choice": choice, "include": include})
    before = deepcopy(options)
    result = _invoke(model.bind_tools(**options), mode, async_loop)

    assert options == before
    assert len(requests) == 1
    streaming = mode not in ("invoke", "ainvoke")
    _assert_request(requests[0], [tool], choice, include, streaming=streaming)
    assert result.text == "Hello"
    assert len(sources) == int(streaming)
    assert all(source.closed for source in sources)
    # Confirm the manager lifecycle was used; do not equate token-only charges
    # on synthetic responses with native-tool billing coverage.
    (event,) = audit_events(manager)
    assert event["operation"] == "responses"
    assert event["status"] == "completed"


@pytest.mark.parametrize("tool,include,forced_choice", TOOL_CASES)
@pytest.mark.parametrize("mode", ["invoke", "internal_invoke", "stream"])
def test_native_and_function_tools_keep_distinct_wire_formats(
    wrapper, async_loop, tool, include, forced_choice, mode
):
    requests, sources = [], []
    model, _ = wrapper(
        partial(_reply, requests=requests, sources=sources),
        internal=...,
        use_responses_api=True,
        max_tokens=64,
    )
    function = {
        "name": "lookup",
        "description": "Look up a synthetic identifier.",
        "parameters": {
            "type": "object",
            "properties": {"identifier": {"type": "string"}},
            "required": ["identifier"],
            "additionalProperties": False,
        },
    }
    # A normal function schema needs conversion; native definitions stay intact.
    tools = deepcopy([tool, function])
    before = deepcopy(tools)
    bound = model.bind_tools(tools, tool_choice="lookup", strict=True, include=include)
    assert _invoke(bound, mode, async_loop).text == "Hello"

    assert tools == before
    assert len(requests) == 1
    _assert_request(
        requests[0],
        [tool, {"type": "function", **function, "strict": True}],
        {"type": "function", "name": "lookup"},
        include,
        streaming=mode != "invoke",
    )
    assert all(source.closed for source in sources)


@pytest.mark.parametrize("tool,include,forced_choice", TOOL_CASES)
def test_native_tool_provider_rejection_is_not_replayed(
    wrapper, tool, include, forced_choice
):
    requests = []
    error = {
        "error": {
            "message": "Synthetic deployment does not support this tool.",
            "type": "invalid_request_error",
            "param": "tools",
            "code": "unsupported_value",
        }
    }

    def reject(request):
        requests.append(request)
        return httpx2.Response(400, json=error)

    model, _ = wrapper(reject, internal=..., use_responses_api=True, max_tokens=64)
    with pytest.raises(BadRequestError) as failure:
        model.bind_tools([tool], tool_choice="auto", include=include).invoke(PROMPT)

    assert failure.value.body == error["error"]
    assert failure.value.request is requests[0]
    assert len(requests) == 1
    _assert_request(requests[0], [tool], "auto", include, streaming=True)
