"""LangChain -> manager -> OpenAI on Azure v1 over synthetic JSON/SSE (no live calls).

Contracts: OpenAI reasoning summaries, Azure Responses reference, and the
langchain-openai==1.6.7 converter source. These fixtures prove offline behavior,
not compatibility with an actual deployment/API version.
"""

from tests.langchain.support import (
    reasoning_response,
    response_events,
    summary_text,
    aggregate,
)

import asyncio
import base64
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from decimal import Decimal
import json
import socket
from threading import Event
from unittest.mock import Mock

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
import httpx2
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage, ToolMessage
from langchain_core.runnables.utils import AddableDict
from openai import APIError, BadRequestError, RateLimitError
from pydantic import BaseModel
import pytest
import pytest_socket

from genai_api_manager import UnexpectedStreamEndError, UnpricedModelError
from socgenai_llm import (
    GenAIBudgetExceededError,
    GenAIRefusalError,
    GenAIResponseError,
)

from tests.support.client import audit_events
from tests.support.azure import chat_payload, response_payload
from tests.support.azure import WireStream, text_events, wire_response


@pytest.mark.parametrize("internal", [False, True])
@pytest.mark.parametrize("summary", [None, "", "Compare the alternatives."])
def test_invoke_summary_and_encrypted_audit(wrapper, internal, summary):
    payload = reasoning_response(summary)
    calls = []

    def handle(request):
        calls.append(request)
        assert request.url.path == "/openai/v1/responses"
        assert "api-version" not in request.url.params
        body = json.loads(request.content)
        assert body["reasoning"] == {"summary": "auto"}
        assert body["store"] is False
        assert body["max_output_tokens"] == 512
        assert body.get("stream", False) is internal
        return (
            wire_response(WireStream(response_events(payload)))
            if internal
            else httpx2.Response(
                200, json=payload, headers={"x-request-id": "synthetic-request"}
            )
        )

    model, manager = wrapper(
        handle,
        internal=internal,
        reasoning={"summary": "auto"},
        max_tokens=512,
    )
    result = model.invoke("hi")
    assert isinstance(result, AIMessage)
    assert result.text == "Hello"
    assert summary_text(result) == (summary or "")
    assert result.id == "resp_synthetic"
    assert result.usage_metadata["output_token_details"]["reasoning"] == 10
    assert result.usage_metadata["input_token_details"]["cache_read"] == 600
    assert len(calls) == 1
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12
    shared = base64.b64decode(event["shared_key"])
    key = HKDF(
        algorithm=hashes.SHA256(), length=32, salt=None, info=b"ecies encryption"
    ).derive(shared)
    raw = base64.b64decode(event["completion"])
    output = json.loads(AESGCM(key).decrypt(raw[:12], raw[28:] + raw[12:28], None))
    if summary:
        assert summary not in json.dumps(event)
        assert output[0]["summary"][0]["text"] == summary


@pytest.mark.parametrize("output_version", [None, "v1"])
@pytest.mark.parametrize("status", ["completed", "incomplete"])
def test_stream_native_chunks_and_terminal_usage(wrapper, output_version, status):
    payload = reasoning_response(status=status)
    source = WireStream(response_events(payload))
    captured = []

    class Callback(BaseCallbackHandler):
        def on_llm_new_token(self, token, *, chunk, **kwargs):
            captured.append(chunk.message)

    model, manager = wrapper(
        lambda _: wire_response(source),
        use_responses_api=True,
        output_version=output_version,
    )
    chunks = list(model.stream("hi", config={"callbacks": [Callback()]}))
    result = aggregate(chunks)
    assert all(isinstance(c, AIMessageChunk) for c in chunks)
    assert len(captured) == len(chunks)
    assert result.text == "Hello"
    assert summary_text(result) == "Compare the alternatives."
    assert result.response_metadata["status"] == status
    assert result.id == "resp_synthetic"
    assert (
        sum(c.usage_metadata["output_tokens"] for c in chunks if c.usage_metadata)
        == 200
    )
    assert source.closed
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12


def test_chat_default_and_parameter_precedence(wrapper):
    bodies = []

    def handle(request):
        bodies.append(json.loads(request.content))
        if bodies[-1].get("stream"):
            return wire_response(WireStream(text_events()))
        return httpx2.Response(
            200,
            json=response_payload()
            if request.url.path.endswith("/responses")
            else chat_payload(),
        )

    model, _ = wrapper(handle, max_tokens=50, model_kwargs={"max_tokens": 10})
    assert model.invoke("hi").content == "Hello"
    assert list(model.stream("hi"))[0].content == "Hello"
    result = model.bind(reasoning={"summary": "auto"}).invoke("hi", max_tokens=70)
    assert result.text == "Hello"
    assert bodies[0]["max_tokens"] == 50
    assert bodies[2]["max_output_tokens"] == 70
    assert "use_responses_api" not in bodies[2]
    assert "_genai_stream_owner" not in bodies[2]


@pytest.mark.parametrize(
    "options",
    [
        {"use_responses_api": False, "reasoning": {"summary": "auto"}},
        {"stop": ["END"]},
        {"stream_options": {"include_usage": True}},
        {"n": 2},
        {"max_tokens": 20, "max_output_tokens": 30},
        {"reasoning_effort": "high", "reasoning": {"effort": "low"}},
    ],
)
def test_invalid_request_does_not_dispatch(wrapper, options):
    handler = Mock(side_effect=AssertionError("must not dispatch"))
    model, _ = wrapper(handler, use_responses_api=True)
    with pytest.raises(ValueError):
        model.invoke("hi", **options)
    handler.assert_not_called()


@pytest.mark.parametrize("streaming", [False, True])
def test_tool_round_trip_and_reasoning_replay(wrapper, streaming):
    payload = reasoning_response()
    payload["output"][0]["encrypted_content"] = "opaque-synthetic-context"
    payload["output"].append(
        {
            "type": "function_call",
            "id": "fc_synthetic",
            "call_id": "call_synthetic",
            "name": "lookup",
            "arguments": '{"city":"Paris"}',
            "status": "completed",
        }
    )
    requests = []

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        return (
            wire_response(WireStream(response_events(payload)))
            if body.get("stream", False)
            else httpx2.Response(200, json=payload)
        )

    model, _ = wrapper(handle, use_responses_api=True)
    bound = model.bind_tools(
        [
            {
                "name": "lookup",
                "description": "Look up a city",
                "parameters": {
                    "type": "object",
                    "properties": {"city": {"type": "string"}},
                },
            }
        ],
        tool_choice="lookup",
    )
    first = aggregate(list(bound.stream("hi"))) if streaming else bound.invoke("hi")
    assert first.tool_calls[0]["args"] == {"city": "Paris"}
    assert requests[0]["tools"][0]["name"] == "lookup"
    assert "function" not in requests[0]["tools"][0]
    history = [
        HumanMessage("hi"),
        first,
        ToolMessage("sunny", tool_call_id="call_synthetic"),
    ]
    before = deepcopy(history)
    bound.invoke(history)
    assert history == before
    items = requests[1]["input"]
    assert any(
        item.get("type") == "function_call_output"
        and item["call_id"] == "call_synthetic"
        for item in items
    )
    reasoning = next(item for item in items if item.get("type") == "reasoning")
    assert reasoning["encrypted_content"] == "opaque-synthetic-context"


class Answer(BaseModel):
    answer: str


@pytest.mark.parametrize("method", ["json_schema", "json_mode", "function_calling"])
@pytest.mark.parametrize("streaming", [False, True])
def test_structured_output_preserves_raw_summary(wrapper, method, streaming):
    payload = reasoning_response()
    payload["output"][1]["content"][0]["text"] = '{"answer":"Hello"}'
    if method == "function_calling":
        payload["output"][1] = {
            "type": "function_call",
            "id": "fc_structured",
            "call_id": "call_structured",
            "name": "Answer",
            "arguments": '{"answer":"Hello"}',
            "status": "completed",
        }
    bodies = []

    def handle(request):
        body = json.loads(request.content)
        bodies.append(body)
        return (
            wire_response(WireStream(response_events(payload)))
            if body.get("stream", False)
            else httpx2.Response(200, json=payload)
        )

    model, _ = wrapper(handle, reasoning={"summary": "auto"})
    structured = model.with_structured_output(Answer, method=method, include_raw=True)
    if streaming:
        result = AddableDict()
        for part in structured.stream("hi"):
            result += part
    else:
        result = structured.invoke("hi")
    assert result["parsed"] == Answer(answer="Hello")
    assert result["parsing_error"] is None
    assert summary_text(result["raw"]) == "Compare the alternatives."
    if method != "function_calling":
        assert bodies[0]["text"]["format"]["type"] == (
            "json_schema" if method == "json_schema" else "json_object"
        )
        assert "response_format" not in bodies[0]


def test_refusal_and_parse_error_include_raw(wrapper):
    payload = reasoning_response()
    payload["output"][1]["content"] = [
        {"type": "refusal", "refusal": "synthetic refusal"}
    ]
    model, _ = wrapper(
        lambda _: httpx2.Response(200, json=payload), use_responses_api=True
    )
    result = model.with_structured_output(Answer, include_raw=True).invoke("hi")
    assert isinstance(result["parsing_error"], GenAIRefusalError)
    assert summary_text(result["raw"]) == "Compare the alternatives."
    with pytest.raises(GenAIRefusalError):
        model.with_structured_output(Answer).invoke("hi")
    payload["output"][1]["content"] = [
        {"type": "output_text", "text": "bad json", "annotations": []}
    ]
    result = model.with_structured_output(Answer, include_raw=True).invoke("hi")
    assert result["parsed"] is None and result["parsing_error"] is not None


@pytest.mark.parametrize("streaming", [False, True])
@pytest.mark.parametrize(
    "missing", ["usage", "input_tokens", "output_tokens", "total_tokens"]
)
def test_unknown_usage_never_becomes_zero(wrapper, streaming, missing):
    payload = reasoning_response()
    if missing == "usage":
        payload["usage"] = None
    else:
        payload["usage"].pop(missing)
    model, manager = wrapper(
        lambda _: (
            wire_response(WireStream(response_events(payload)))
            if streaming
            else httpx2.Response(200, json=payload)
        ),
        use_responses_api=True,
    )
    result = aggregate(list(model.stream("hi"))) if streaming else model.invoke("hi")
    assert result.usage_metadata is None
    assert result.response_metadata["usage_status"] == "unknown"
    if missing != "total_tokens":
        (event,) = audit_events(manager)
        assert event["total_cost"] is None


@pytest.mark.parametrize("streaming", [False, True])
def test_budget_and_unpriced_reject_before_dispatch(wrapper, streaming):
    handler = Mock(side_effect=AssertionError("must not dispatch"))
    model, manager = wrapper(handler, use_responses_api=True)
    manager.log_manager.daily_cost_limit = 0
    manager.log_manager._budget.record(
        manager.log_manager._accounting_key(), Decimal("0.01")
    )

    def call():
        return list(model.stream("hi")) if streaming else model.invoke("hi")

    with pytest.raises(GenAIBudgetExceededError):
        call()
    model.model = "unpriced"
    with pytest.raises(UnpricedModelError):
        call()
    handler.assert_not_called()


@pytest.mark.parametrize("streaming", [False, True])
@pytest.mark.parametrize(
    "status,error_type", [(400, BadRequestError), (429, RateLimitError)]
)
def test_sdk_errors_are_preserved(wrapper, streaming, status, error_type):
    model, manager = wrapper(
        lambda _: httpx2.Response(
            status,
            json={
                "error": {
                    "message": "synthetic complete error",
                    "code": "synthetic",
                    "extra": "preserved",
                }
            },
        ),
        use_responses_api=True,
    )
    with pytest.raises(error_type) as caught:
        list(model.stream("hi")) if streaming else model.invoke("hi")
    assert caught.value.body["extra"] == "preserved"
    assert "synthetic complete error" in str(caught.value)
    assert audit_events(manager) == []


@pytest.mark.parametrize(
    "streaming,status", [(False, "failed"), (True, "failed"), (False, "cancelled")]
)
def test_failure_retains_full_provider_object(wrapper, streaming, status):
    payload = reasoning_response(status=status)
    payload["error"] = {
        "code": "server_error",
        "message": "full synthetic provider failure",
    }
    model, manager = wrapper(
        lambda _: (
            wire_response(WireStream(response_events(payload)))
            if streaming
            else httpx2.Response(200, json=payload)
        ),
        use_responses_api=True,
    )
    with pytest.raises(GenAIResponseError) as caught:
        list(model.stream("hi")) if streaming else model.invoke("hi")
    assert caught.value.response.id == "resp_synthetic"
    assert caught.value.usage.output_tokens == 200
    assert "full synthetic provider failure" in str(caught.value)
    assert caught.value.__cause__ is not None
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12


@pytest.mark.parametrize(
    "outcome",
    ["early_close", "eof", "read_error", "callback", "conversion", "provider_error"],
)
def test_stream_cleanup_and_no_replay(wrapper, monkeypatch, outcome):
    events = response_events(reasoning_response())
    original_error = APIError(
        "original full error",
        request=httpx2.Request("POST", "https://synthetic.invalid"),
        body={"secret": "synthetic payload"},
    )
    if outcome in ("eof", "read_error"):
        events = events[:-1]
    if outcome == "provider_error":
        events = [
            {
                "type": "error",
                "code": "server_error",
                "message": "full synthetic error",
                "param": None,
                "sequence_number": 0,
                "extension": "retained",
            }
        ]
    source = WireStream(
        events, error=original_error if outcome == "read_error" else None
    )
    handler = Mock(return_value=wire_response(source))
    model, manager = wrapper(handler, use_responses_api=True)

    class BrokenCallback(BaseCallbackHandler):
        raise_error = True

        def on_llm_new_token(self, *args, **kwargs):
            raise LookupError("callback failure")

    if outcome == "conversion":
        from socgenai_llm import _responses_compat

        monkeypatch.setattr(
            _responses_compat,
            "_convert_responses_chunk_to_generation_chunk",
            Mock(side_effect=ValueError("conversion failure")),
        )
    iterator = model.stream(
        "hi", config={"callbacks": [BrokenCallback()] if outcome == "callback" else []}
    )
    assert source.reads == 0
    if outcome == "early_close":
        next(iterator)
    else:
        expected = {
            "eof": UnexpectedStreamEndError,
            "read_error": APIError,
            "callback": LookupError,
            "conversion": GenAIResponseError,
            "provider_error": GenAIResponseError,
        }[outcome]
        with pytest.raises(expected) as caught:
            list(iterator)
        if outcome == "read_error":
            assert caught.value is original_error
        if outcome == "provider_error":
            assert caught.value.body["extension"] == "retained"
    iterator.close()
    iterator.close()
    assert source.closed
    assert handler.call_count == 1
    (event,) = audit_events(manager)
    assert event["total_cost"] is None


def test_executor_async_invoke_and_stream(wrapper, async_loop):
    payload = reasoning_response()

    def handle(request):
        return (
            wire_response(WireStream(response_events(payload)))
            if json.loads(request.content).get("stream", False)
            else httpx2.Response(200, json=payload)
        )

    with ThreadPoolExecutor(max_workers=1) as pool:
        model, manager = wrapper(handle, use_responses_api=True, executor=pool)

        async def run():
            result = await model.ainvoke("hi")
            chunks = [chunk async for chunk in model.astream("hi")]
            assert summary_text(result) == summary_text(aggregate(chunks))

        async_loop.run_until_complete(run())
    assert len(audit_events(manager)) == 2


@pytest.mark.parametrize("read_error", [False, True])
def test_executor_cancellation_waits_for_read_and_closes(
    wrapper, async_loop, read_error
):
    entered, proceed, cleanup = Event(), Event(), Event()

    class Blocked(WireStream):
        def __iter__(self):
            entered.set()
            assert proceed.wait(5)
            if read_error:
                raise APIError(
                    "synthetic error after cancellation",
                    request=httpx2.Request("POST", "https://synthetic.invalid"),
                    body={"private": "synthetic"},
                )
            yield from super().__iter__()

        def close(self):
            super().close()
            cleanup.set()

    source = Blocked(response_events(reasoning_response()))
    with ThreadPoolExecutor(max_workers=1) as pool:
        model, manager = wrapper(
            lambda _: wire_response(source), use_responses_api=True, executor=pool
        )

        async def run():
            iterator = model.astream("hi")
            task = asyncio.create_task(anext(iterator))
            assert await asyncio.to_thread(entered.wait, 5)
            task.cancel()
            proceed.set()
            with pytest.raises(asyncio.CancelledError):
                await task
            await iterator.aclose()
            assert cleanup.is_set()

        try:
            async_loop.run_until_complete(run())
        finally:
            proceed.set()
    assert source.closed
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize("streaming", [False, True])
def test_conversion_failure_after_usage_does_not_erase_cost(
    wrapper, monkeypatch, streaming
):
    from socgenai_llm import _responses_compat as compat

    payload = reasoning_response()
    model, manager = wrapper(
        lambda _: (
            wire_response(WireStream(response_events(payload)))
            if streaming
            else httpx2.Response(200, json=payload)
        ),
        use_responses_api=True,
    )
    if streaming:
        original = compat._convert_responses_chunk_to_generation_chunk

        def fail_at_terminal(event, *args, **kwargs):
            if event.type == "response.completed":
                raise ValueError("synthetic conversion failure")
            return original(event, *args, **kwargs)

        monkeypatch.setattr(
            compat, "_convert_responses_chunk_to_generation_chunk", fail_at_terminal
        )
    else:
        monkeypatch.setattr(
            compat,
            "_construct_lc_result_from_responses_api",
            Mock(side_effect=ValueError("synthetic conversion failure")),
        )
    with pytest.raises(GenAIResponseError) as caught:
        list(model.stream("hi")) if streaming else model.invoke("hi")
    assert caught.value.usage.output_tokens == 200
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12


def test_invoke_stream_callback_failure_closes(wrapper):
    source = WireStream(response_events(reasoning_response()))
    model, manager = wrapper(lambda _: wire_response(source), use_responses_api=True)

    class Callback(BaseCallbackHandler):
        raise_error = True

        def on_llm_new_token(self, *args, **kwargs):
            raise LookupError("synthetic callback failure")

    with pytest.raises(LookupError):
        model.invoke("hi", stream=True, config={"callbacks": [Callback()]})
    assert source.closed
    assert len(audit_events(manager)) == 1


def test_async_early_close_and_callback_failure(wrapper, async_loop):
    sources = []

    def handle(request):
        source = WireStream(response_events(reasoning_response()))
        sources.append(source)
        return wire_response(source)

    model, manager = wrapper(handle, use_responses_api=True)

    class Callback(BaseCallbackHandler):
        raise_error = True

        def on_llm_new_token(self, *args, **kwargs):
            raise LookupError("synthetic callback failure")

    async def run():
        iterator = model.astream("hi")
        await anext(iterator)
        await iterator.aclose()
        await iterator.aclose()
        assert sources[0].closed
        # Missing usage from early close must not disable subsequent requests.
        with pytest.raises(LookupError):
            async for _ in model.astream("hi", config={"callbacks": [Callback()]}):
                pass
        assert sources[1].closed

    async_loop.run_until_complete(run())
    assert len(audit_events(manager)) == 2


def test_model_and_iterator_close_finalize_once(wrapper):
    source = WireStream(response_events(reasoning_response()))
    model, manager = wrapper(lambda _: wire_response(source), use_responses_api=True)
    iterator = model.stream("hi")
    next(iterator)
    model.close()
    model.close()
    iterator.close()
    assert source.closed
    assert len(audit_events(manager)) == 1


def test_async_fixture_still_blocks_network(async_loop):
    with pytest.warns(UserWarning, match="socket.socket"):
        with pytest.raises(pytest_socket.SocketBlockedError):
            socket.socket()


def test_multiple_summary_parts(wrapper):
    payload = reasoning_response()
    payload["output"][0]["summary"].append(
        {"type": "summary_text", "text": "Then choose one."}
    )
    model, _ = wrapper(
        lambda _: wire_response(WireStream(response_events(payload))),
        use_responses_api=True,
    )
    result = aggregate(list(model.stream("hi")))
    assert summary_text(result) == "Compare the alternatives.Then choose one."


@pytest.mark.parametrize("streaming", [False, True])
def test_invalid_tool_arguments_do_not_appear_valid(wrapper, streaming):
    payload = reasoning_response()
    payload["output"].append(
        {
            "type": "function_call",
            "id": "fc_invalid",
            "call_id": "call_invalid",
            "name": "lookup",
            "arguments": "{invalid",
            "status": "completed",
        }
    )
    model, manager = wrapper(
        lambda _: (
            wire_response(WireStream(response_events(payload)))
            if streaming
            else httpx2.Response(200, json=payload)
        ),
        use_responses_api=True,
    )
    if streaming:
        with pytest.raises(GenAIResponseError) as caught:
            list(model.stream("hi"))
        assert caught.value.response.output[-1].arguments == "{invalid"
    else:
        result = model.invoke("hi")
        assert result.invalid_tool_calls[0]["args"] == "{invalid"
    (event,) = audit_events(manager)
    assert event["total_cost"] == 1.12


def test_parameter_copy_and_explicit_temperature(wrapper):
    body = {}

    def handle(request):
        body.update(json.loads(request.content))
        return httpx2.Response(200, json=reasoning_response())

    model, _ = wrapper(handle, use_responses_api=True)
    options = {
        "max_tokens": None,
        "max_output_tokens": 100,
        "temperature": 0.2,
        "reasoning": {"summary": "auto"},
        "reasoning_effort": "low",
    }
    before = deepcopy(options)
    model.invoke("hi", **options)
    assert options == before
    assert body["max_output_tokens"] == 100
    assert body["temperature"] == 0.2
    assert body["reasoning"] == {"summary": "auto", "effort": "low"}
