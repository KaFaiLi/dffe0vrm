"""Multimodal LangChain inputs through the real wrapper, manager and locked SDK.

Wire schemas follow the Azure v1 Responses reference and OpenAI image/PDF guides:
https://learn.microsoft.com/en-us/rest/api/aifoundry/azureopenai/responses
https://platform.openai.com/docs/guides/images-vision
https://platform.openai.com/docs/guides/pdf-files
Canonical blocks follow langchain-core 1.6.6's content/block translator schemas.
Synthetic replies verify conversion and lifecycle, not live model perception.
"""

from contextlib import aclosing, closing
from copy import deepcopy
from decimal import Decimal
import json

import httpx2
from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage
from openai import APIStatusError
import pytest

from tests.langchain.support import aggregate, response_events
from tests.support.azure import WireStream, wire_response
from tests.support.client import audit_events
from tests.support.multimodal import PRICES, provider_result
from tests.support.multimodal_inputs import EXPECTED, request_for
from tests.support.standard_usage.common import _decrypt as decrypt


@pytest.fixture(scope="module")
def multimodal_requests():
    # Generate the deterministic PNG/PDF once, then copy before every invocation.
    return {
        (api, case): request_for(api, "deployment", case)
        for api in ("chat", "responses")
        for case in ("image", "pdf", "image-pdf")
    }


def human_input(requests, api, case, style):
    """Build caller inputs independently from the expected Azure wire payload."""
    content = deepcopy(requests["chat", case]["messages"][0]["content"])
    key = "messages" if api == "chat" else "input"
    expected = deepcopy(requests[api, case][key])
    if api == "responses":
        expected[0]["type"] = "message"
    if style == "langchain":
        for index, block in enumerate(content):
            if block["type"] == "image_url":
                content[index] = {
                    "type": "image",
                    "base64": block["image_url"]["url"].split(",", 1)[1],
                    "mime_type": "image/png",
                }
                wire = expected[0]["content"][index]
                (wire["image_url"] if api == "chat" else wire).pop("detail")
            elif block["type"] == "file":
                content[index] = {
                    "type": "file",
                    "base64": block["file"]["file_data"].split(",", 1)[1],
                    "mime_type": "application/pdf",
                    "extras": {"filename": block["file"]["filename"]},
                }
    return [HumanMessage(content=content)], expected


def reply(api, case, streaming, *, missing_usage=False):
    response, source = provider_result(
        api, case, streaming and api == "chat", missing_usage=missing_usage
    )
    if api == "responses" and streaming:
        # Include item creation and completion so LangChain sees real indexes.
        source = WireStream(response_events(response.json()), named=True)
        response = wire_response(source)
    return response, source


def call(model, messages, mode, async_api, async_loop):
    options = {"stream": False} if mode == "native" else {}
    if async_api:

        async def run():
            if mode == "stream":
                async with aclosing(model.astream(messages)) as stream:
                    return aggregate([chunk async for chunk in stream])
            return await model.ainvoke(messages, **options)

        return async_loop.run_until_complete(run())
    if mode == "stream":
        with closing(model.stream(messages)) as stream:
            return aggregate(list(stream))
    return model.invoke(messages, **options)


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("case", ["image", "pdf", "image-pdf"])
@pytest.mark.parametrize("style", ["langchain", "openai"])
@pytest.mark.parametrize("mode", ["native", "internal", "stream"])
@pytest.mark.parametrize("async_api", [False, True], ids=["sync", "async"])
def test_multimodal_messages_preserve_content_usage_and_encrypted_audit(
    wrapper, async_loop, multimodal_requests, api, case, style, mode, async_api
):
    messages, expected = human_input(multimodal_requests, api, case, style)
    before = deepcopy(messages)
    requests, sources = [], []
    key = "messages" if api == "chat" else "input"

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        assert request.url.path == "/openai/v1/" + (
            "chat/completions" if api == "chat" else "responses"
        )
        assert "api-version" not in request.url.params
        assert body[key] == expected
        assert ("input" if api == "chat" else "messages") not in body
        assert body["model"] == "deployment"
        assert body["stream"] is (mode != "native")
        if api == "chat" and mode != "native":
            assert body["stream_options"]["include_usage"] is True
        response, source = reply(api, case, body["stream"])
        if source is not None:
            sources.append(source)
        return response

    model, manager = wrapper(
        handle, internal=..., pricing_data=PRICES, use_responses_api=api == "responses"
    )
    result = call(model, messages, mode, async_api, async_loop)
    assert isinstance(result, AIMessageChunk if mode == "stream" else AIMessage)
    assert result.text == EXPECTED[case]
    assert result.usage_metadata["input_tokens"] == 1000
    assert result.usage_metadata["output_tokens"] == 200
    assert result.usage_metadata["total_tokens"] == 1200
    assert result.usage_metadata["input_token_details"] == {
        "cache_read": 600,
        "cache_creation": 300,
    }
    assert messages == before
    assert len(requests) == 1
    assert len(sources) == (mode != "native")
    assert all(source.closed for source in sources)
    model.close()
    model.close()
    (event,) = audit_events(manager)
    assert event["operation"] == ("chat.completions" if api == "chat" else api)
    assert event["status"] == "completed" and event["cost_status"] == "exact"
    assert event["input_token"] == 1000 and event["output_token"] == 200
    assert event["cached_input_token"] == 600 and event["cache_write_token"] == 300
    # Authoritative provider totals already include image/file inputs.
    assert event["input_cost"] == 0.595 and event["total_cost"] == 1.195
    assert Decimal(manager.log_manager.get_metrics()["daily_cost_exact"]) == Decimal(
        "1.195"
    )
    assert json.loads(decrypt(event, "prompt")) == expected
    persisted = json.dumps(event)
    for message in expected:
        for block in message["content"]:
            assert json.dumps(block) not in persisted
    assert "data:image/png;base64" not in persisted
    assert "data:application/pdf;base64" not in persisted
    assert "ORBIT-417" not in persisted


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("mode", ["native", "internal", "stream"])
@pytest.mark.parametrize("style", ["langchain", "openai"])
def test_multimodal_dictionary_history_preserves_urls_file_ids_and_order(
    wrapper, async_loop, api, mode, style
):
    image_url = "https://example.invalid/synthetic-image.png"
    image = (
        {"type": "image", "url": image_url}
        if style == "langchain"
        else {"type": "image_url", "image_url": {"url": image_url}}
    )
    messages = [
        {"role": "user", "content": "Use the attachments in the next message."},
        {"role": "assistant", "content": "Ready."},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "Compare this image and these two PDFs."},
                image,
                {"type": "file", "file": {"file_id": "file-synthetic-first"}},
                {"type": "file", "file": {"file_id": "file-synthetic-second"}},
            ],
        },
    ]
    before = deepcopy(messages)
    requests, sources = [], []

    def handle(request):
        body = json.loads(request.content)
        requests.append(body)
        items = body["input" if api == "responses" else "messages"]
        assert [item["role"] for item in items] == ["user", "assistant", "user"]
        assert items[0]["content"] == messages[0]["content"]
        if api == "chat":
            assert items[1]["content"] == "Ready."
        else:
            assert items[1]["content"] == [
                {"type": "output_text", "text": "Ready.", "annotations": []}
            ]
        parts = items[2]["content"]
        if api == "chat":
            assert parts == [
                before[2]["content"][0],
                {"type": "image_url", "image_url": {"url": image_url}},
                *before[2]["content"][2:],
            ]
        else:
            assert parts == [
                {"type": "input_text", "text": before[2]["content"][0]["text"]},
                {"type": "input_image", "image_url": image_url},
                {"type": "input_file", "file_id": "file-synthetic-first"},
                {"type": "input_file", "file_id": "file-synthetic-second"},
            ]
        response, source = reply(api, "image-pdf", body["stream"])
        if source is not None:
            sources.append(source)
        return response

    model, manager = wrapper(
        handle, internal=..., pricing_data=PRICES, use_responses_api=api == "responses"
    )
    result = call(model, messages, mode, False, async_loop)
    assert result.text == EXPECTED["image-pdf"]
    assert messages == before
    assert len(requests) == 1 and all(source.closed for source in sources)
    (event,) = audit_events(manager)
    assert (
        json.loads(decrypt(event, "prompt"))
        == requests[0]["input" if api == "responses" else "messages"]
    )


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("mode", ["native", "internal", "stream"])
@pytest.mark.parametrize("status", [400, 403])
def test_multimodal_rejection_preserves_sdk_error_without_retry_or_charge(
    wrapper, async_loop, multimodal_requests, api, mode, status
):
    messages, _ = human_input(multimodal_requests, api, "image-pdf", "langchain")
    before = deepcopy(messages)
    bodies = []
    error = {
        "message": "Full synthetic multimodal input rejection",
        "code": "invalid_input",
        "param": "content",
        "details": {"reason": "Unsupported synthetic PDF"},
    }

    def handle(request):
        body = json.loads(request.content)
        bodies.append(body)
        if len(bodies) == 1:
            return httpx2.Response(status, json={"error": error})
        return reply(api, "text", body["stream"])[0]

    model, manager = wrapper(
        handle, internal=..., pricing_data=PRICES, use_responses_api=api == "responses"
    )
    with pytest.raises(APIStatusError) as caught:
        call(model, messages, mode, False, async_loop)
    assert caught.value.status_code == status
    assert caught.value.body == error
    assert error["message"] in str(caught.value)
    assert len(bodies) == 1
    assert messages == before
    assert manager.log_manager.check_daily_cost() == 0
    assert manager.log_manager.get_metrics()["written_events"] == 0
    assert manager.log_manager.get_metrics()["queue_size"] == 0
    # A rejected attachment must not block a subsequent valid request.
    result = call(model, "Reply hello.", mode, False, async_loop)
    assert result.text == EXPECTED["text"]
    assert len(bodies) == 2 and len(audit_events(manager)) == 1


@pytest.mark.parametrize("api", ["chat", "responses"])
@pytest.mark.parametrize("mode", ["native", "internal", "stream"])
def test_multimodal_missing_usage_stays_unknown_and_allows_next_request(
    wrapper, async_loop, multimodal_requests, api, mode
):
    messages, expected = human_input(multimodal_requests, api, "image-pdf", "openai")
    sources = []

    def handle(request):
        response, source = reply(
            api, "image-pdf", json.loads(request.content)["stream"], missing_usage=True
        )
        if source is not None:
            sources.append(source)
        return response

    model, manager = wrapper(
        handle, internal=..., pricing_data=PRICES, use_responses_api=api == "responses"
    )
    manager.log_manager.daily_cost_limit = 0
    for _ in range(2):
        result = call(model, messages, mode, False, async_loop)
        assert result.text == EXPECTED["image-pdf"]
        assert result.usage_metadata is None
        assert result.response_metadata["usage_status"] == "unknown"
        assert manager.log_manager.check_daily_cost() == 0
        assert not manager.log_manager.budget_exceeded()
    events = audit_events(manager)
    assert len(events) == 2
    assert all(source.closed for source in sources)
    for event in events:
        assert event["input_token"] is None and event["output_token"] is None
        assert event["total_cost"] is None and event["cost_status"] == "usage_missing"
        assert json.loads(decrypt(event, "prompt")) == expected
