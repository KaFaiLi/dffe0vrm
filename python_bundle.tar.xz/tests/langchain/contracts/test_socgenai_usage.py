"""G07 usage metadata through real SDK JSON/SSE with network disabled."""

from copy import deepcopy
import json
from unittest.mock import Mock

import httpx2
from langchain_core.caches import InMemoryCache
from langchain_core.globals import get_llm_cache, set_llm_cache
from langchain_core.messages import HumanMessage
from langchain_core.outputs import ChatGeneration, ChatResult
import pytest

from socgenai_llm._usage import project_usage, result_with_usage
from genai_api_manager.accounting import PriceBook
from tests.support.client import audit_events
from tests.support.azure import chat_payload
from tests.support.azure import WireStream, text_events, wire_response
from tests.langchain.support import (
    V3_BETA_WARNING,
    aggregate,
    reasoning_response,
    response_events,
)


def payload_for(responses, case="valid"):
    payload = reasoning_response() if responses else chat_payload()
    usage = payload["usage"]
    inp, out = (
        ("input_tokens", "output_tokens")
        if responses
        else ("prompt_tokens", "completion_tokens")
    )
    if case == "missing":
        payload["usage"] = None
    elif case == "incomplete":
        usage.pop(out)
    elif case == "null":
        usage["total_tokens"] = None
    elif case == "negative":
        usage[inp] = -1
    elif case == "boolean":
        usage[inp] = True
    elif case == "string":
        usage[inp] = "not-a-count"
    elif case == "total":
        usage["total_tokens"] += 1
    elif case == "cache":
        usage[inp + "_details"] = {"cached_tokens": 600, "cache_write_tokens": 500}
    elif case == "detail":
        usage[out + "_details"] = {"reasoning_tokens": -1}
    elif case == "zero":
        payload["usage"] = {inp: 0, out: 0, "total_tokens": 0}
    elif case == "details":
        usage[inp + "_details"] = {
            "cached_tokens": 600,
            "cache_write_tokens": 10,
            "audio_tokens": 2,
            "provider_extra": "kept",
        }
        usage[out + "_details"] = {
            "reasoning_tokens": 4,
            "audio_tokens": 2,
            "accepted_prediction_tokens": 3,
            "rejected_prediction_tokens": 1,
        }
        usage["provider_extra"] = {"retained": True}
        if not responses:
            # Provider extensions must not change the detected API schema.
            usage["input_tokens"] = 999
    return payload


def handler_for(payloads, sources=None):
    if isinstance(payloads, dict):
        payloads = [payloads]
    index = 0

    def handle(request):
        nonlocal index
        payload = deepcopy(payloads[min(index, len(payloads) - 1)])
        index += 1
        if json.loads(request.content).get("stream"):
            if "output" in payload:
                events = response_events(payload)
            else:
                events = text_events()
                events[-1]["usage"] = payload.get("usage")
            source = WireStream(events)
            if sources is not None:
                sources.append(source)
            return wire_response(source)
        return httpx2.Response(200, json=payload)

    return Mock(side_effect=handle)


CASES = [
    "valid",
    "zero",
    "details",
    "missing",
    "incomplete",
    "null",
    "negative",
    "boolean",
    "string",
    "total",
    "cache",
    "detail",
]


@pytest.mark.parametrize("responses", [False, True])
@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize(
    "mode",
    [
        "invoke",
        "ainvoke",
        "stream",
        "astream",
        "streamed_invoke",
        pytest.param("v3", marks=V3_BETA_WARNING),
        pytest.param("av3", marks=V3_BETA_WARNING),
    ],
)
def test_usage_paths(wrapper, async_loop, responses, case, mode):
    payload = payload_for(responses, case)
    sources = []
    handler = handler_for(payload, sources)
    model, manager = wrapper(handler, use_responses_api=responses)
    chunks = []
    if mode == "invoke":
        result = model.invoke("hi")
    elif mode == "stream":
        chunks = list(model.stream("hi"))
        result = aggregate(chunks)
    elif mode == "streamed_invoke":
        result = model.invoke("hi", stream=True)
    elif mode == "v3":
        result = model.stream_events("hi", version="v3").output
    else:

        async def run():
            if mode == "ainvoke":
                return await model.ainvoke("hi")
            if mode == "astream":
                chunks.extend([c async for c in model.astream("hi")])
                return aggregate(chunks)
            stream = await model.astream_events("hi", version="v3")
            async with stream:
                return await stream.output

        result = async_loop.run_until_complete(run())
    assert result.text == "Hello"
    known = case in ("valid", "zero", "details")
    assert result.response_metadata["usage_status"] == ("known" if known else "unknown")
    if known:
        assert result.usage_metadata["input_tokens"] == (0 if case == "zero" else 1000)
        if case == "details":
            assert result.usage_metadata["input_token_details"] == {
                "cache_read": 600,
                "cache_creation": 10,
                "audio": 2,
            }
            assert result.usage_metadata["output_token_details"] == {
                "reasoning": 4,
                "audio": 2,
                "accepted_prediction": 3,
                "rejected_prediction": 1,
            }
            assert result.response_metadata["usage"]["provider_extra"] == {
                "retained": True
            }
    else:
        assert result.usage_metadata is None
        reason = (
            "missing"
            if case == "missing"
            else "incomplete"
            if case in ("incomplete", "null")
            else "invalid"
        )
        assert result.response_metadata["usage_reason"] == reason
    raw = result.response_metadata["usage"]
    if case == "missing":
        assert raw is None
    elif case == "null":
        assert raw["total_tokens"] is None
    elif case == "incomplete":
        assert raw.get("output_tokens" if responses else "completion_tokens") is None
    if not responses:
        assert result.response_metadata["token_usage"] == raw
    if chunks:
        assert sum("usage_status" in c.response_metadata for c in chunks) == 1
        assert sum(c.usage_metadata is not None for c in chunks) == int(known)
    assert handler.call_count == 1
    assert all(source.closed for source in sources)
    assert len(audit_events(manager)) == 1


@pytest.mark.parametrize("responses", [False, True])
@pytest.mark.parametrize("async_api", [False, True])
@pytest.mark.parametrize("streaming", [False, True])
@pytest.mark.parametrize(
    "cases",
    [
        ("valid", "valid"),
        ("valid", "missing"),
        ("null", "missing"),
        ("details", "valid"),
    ],
)
def test_generate_summaries(
    wrapper, async_loop, responses, async_api, streaming, cases
):
    model, manager = wrapper(
        handler_for([payload_for(responses, c) for c in cases]),
        use_responses_api=responses,
    )
    # Supply synthetic cache-write rates for the batch's expected cost metadata.
    manager.log_manager._price_book = PriceBook(
        {
            "deployment": {
                "input": "1",
                "output": "3",
                "cached_input": "0.2",
                "cache_write": "1.25",
            }
        }
    )
    messages = [[HumanMessage(content="one")], [HumanMessage(content="two")]]
    result = (
        async_loop.run_until_complete(model.agenerate(messages, stream=streaming))
        if async_api
        else model.generate(messages, stream=streaming)
    )
    output = result.llm_output
    known = sum(c in ("valid", "details") for c in cases)
    assert output["usage_coverage"] == {
        "total_requests": 2,
        "known_requests": known,
        "unknown_requests": 2 - known,
    }
    assert output["usage_status"] == ("known" if known == 2 else "unknown")
    totals = output["token_usage"]
    if known == 1:
        assert "prompt_tokens" not in totals
        totals = totals["known_subtotal"]
    if known:
        assert totals["prompt_tokens"] == 1000 * known
        assert totals["completion_tokens"] == 200 * known
        assert totals["total_tokens"] == 1200 * known
        # Cache-write detail is absent from the second response: no invented 0.
        assert "cache_write_tokens" not in totals.get("prompt_tokens_details", {})
    else:
        assert totals == {}
    flattened = result.flatten()
    assert flattened[0].llm_output["token_usage"] == output["token_usage"]
    assert flattened[1].llm_output["token_usage"] == {}
    assert len(audit_events(manager)) == 2


@pytest.mark.parametrize("responses", [False, True])
@pytest.mark.parametrize("async_api", [False, True])
@pytest.mark.parametrize("global_cache", [False, True])
@pytest.mark.parametrize("case", ["valid", "missing"])
def test_cache_usage_is_copied_and_not_charged(
    wrapper, async_loop, responses, async_api, global_cache, case
):
    cache = InMemoryCache()
    previous = get_llm_cache()
    set_llm_cache(cache if global_cache else previous)
    try:
        handler = handler_for(payload_for(responses, case))
        model, manager = wrapper(
            handler, use_responses_api=responses, cache=None if global_cache else cache
        )
        messages = [[HumanMessage(content="hi")]]

        def call():
            return (
                async_loop.run_until_complete(model.agenerate(messages))
                if async_api
                else model.generate(messages)
            )

        first = call()
        snapshot = deepcopy(cache._cache)
        second = call()
        assert second.llm_output == first.llm_output
        assert cache._cache == snapshot
        second.generations[0][0].message.response_metadata["usage"] = {"tampered": True}
        assert cache._cache == snapshot
        assert handler.call_count == 1
        (event,) = audit_events(manager)
        assert event["total_cost"] == (1.12 if case == "valid" else None)
    finally:
        set_llm_cache(previous)


def test_mixed_api_models_and_request_scoped_usage(wrapper):
    payloads = [payload_for(False), payload_for(True)]
    payloads[1]["model"] = "provider-second"
    summaries = []
    for responses, payload in zip((False, True), payloads):
        model, _ = wrapper(handler_for(payload), use_responses_api=responses)
        result = model.generate([[HumanMessage(content="hi")]])
        message = result.generations[0][0].message
        # Several generations still describe one paid request.
        request_result = ChatResult(
            generations=[
                ChatGeneration(message=message),
                ChatGeneration(message=message.model_copy(deep=True)),
            ]
        )
        summaries.append(result_with_usage(request_result).llm_output)
    combined = model._combine_llm_outputs(summaries)
    assert combined["token_usage"]["prompt_tokens"] == 2000
    assert combined["model_names"] == sorted([payloads[0]["model"], "provider-second"])
    assert "model_name" not in combined
    assert "system_fingerprint" not in combined


@pytest.mark.parametrize("bad", [False, 1.2, "10", -1])
def test_projection_does_not_coerce_counts(bad):
    usage = {"prompt_tokens": bad, "completion_tokens": 0, "total_tokens": bad}
    original = deepcopy(usage)
    normalized, annotation = project_usage(usage)
    assert normalized is None and annotation["usage_reason"] == "invalid"
    assert usage == original == annotation["usage"]
