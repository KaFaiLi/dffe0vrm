"""LangChain schema and result helpers; no collected tests."""

from copy import deepcopy
import json
from unittest.mock import Mock
import httpx2
from pydantic import BaseModel
import pytest
from tests.support.azure import (
    chat_payload,
    response_payload,
    WireStream,
    wire_response,
    chunk,
    choice,
    text_events,
)


# Apply only to cases that explicitly select the upstream beta event API.
V3_BETA_WARNING = pytest.mark.filterwarnings(
    "ignore:^The method `BaseChatModel\\._a?chat_model_stream_v3` is in beta\\.:"
    "langchain_core._api.beta_decorator.LangChainBetaWarning"
)


def reasoning_response(summary="Compare the alternatives.", *, status="completed"):
    response = response_payload(status)
    if summary is not None:
        response["output"].insert(
            0,
            {
                "type": "reasoning",
                "id": "rs_synthetic",
                "summary": [{"type": "summary_text", "text": summary}]
                if summary
                else [],
            },
        )
    return response


def response_events(response):
    events = [
        {
            "type": "response.created",
            "response": {
                **response,
                "status": "in_progress",
                "output": [],
                "usage": None,
            },
        }
    ]
    for index, item in enumerate(response["output"]):
        if item["type"] == "reasoning":
            events.append(
                {
                    "type": "response.output_item.added",
                    "output_index": index,
                    "item": {**item, "summary": []},
                }
            )
            for part_index, part in enumerate(item["summary"]):
                common = {
                    "output_index": index,
                    "item_id": item["id"],
                    "summary_index": part_index,
                }
                events.append(
                    {
                        **common,
                        "type": "response.reasoning_summary_part.added",
                        "part": {"type": "summary_text", "text": ""},
                    }
                )
                text = part["text"]
                for fragment in (text[:5], text[5:]):
                    events.append(
                        {
                            **common,
                            "type": "response.reasoning_summary_text.delta",
                            "delta": fragment,
                        }
                    )
                events.append(
                    {
                        **common,
                        "type": "response.reasoning_summary_text.done",
                        "text": text,
                    }
                )
                events.append(
                    {
                        **common,
                        "type": "response.reasoning_summary_part.done",
                        "part": part,
                    }
                )
        elif item["type"] == "message":
            events.append(
                {
                    "type": "response.output_item.added",
                    "output_index": index,
                    "item": {**item, "content": [], "status": "in_progress"},
                }
            )
            for content_index, part in enumerate(item["content"]):
                common = {
                    "output_index": index,
                    "item_id": item["id"],
                    "content_index": content_index,
                }
                if part["type"] == "refusal":
                    events.append(
                        {
                            **common,
                            "type": "response.refusal.done",
                            "refusal": part["refusal"],
                        }
                    )
                    continue
                for fragment in (part["text"][:2], part["text"][2:]):
                    events.append(
                        {
                            **common,
                            "type": "response.output_text.delta",
                            "delta": fragment,
                            "logprobs": [],
                        }
                    )
                events.append(
                    {
                        **common,
                        "type": "response.output_text.done",
                        "text": part["text"],
                        "logprobs": [],
                    }
                )
        elif item["type"] == "function_call":
            events.append(
                {
                    "type": "response.output_item.added",
                    "output_index": index,
                    "item": {**item, "arguments": ""},
                }
            )
            for fragment in (item["arguments"][:5], item["arguments"][5:]):
                events.append(
                    {
                        "type": "response.function_call_arguments.delta",
                        "output_index": index,
                        "item_id": item["id"],
                        "delta": fragment,
                    }
                )
        events.append(
            {"type": "response.output_item.done", "output_index": index, "item": item}
        )
    events.append({"type": "response." + response["status"], "response": response})
    return [{**event, "sequence_number": number} for number, event in enumerate(events)]


def summary_text(message):
    return "".join(
        block.get("reasoning", "")
        for block in message.content_blocks
        if block["type"] == "reasoning"
    )


def aggregate(chunks):
    result = chunks[0]
    for part in chunks[1:]:
        result += part
    return result


class Answer(BaseModel):
    answer: str


METHODS = ["json_schema", "json_mode", "function_calling"]


SCHEMA = {
    "title": "Answer",
    "type": "object",
    "properties": {"answer": {"type": "string"}},
    "required": ["answer"],
}


def payload_for(
    responses, method="json_schema", text='{"answer":"Hello"}', complete=True
):
    payload = reasoning_response() if responses else chat_payload()
    if responses:
        payload["status"] = "completed" if complete else "incomplete"
        if method == "function_calling":
            payload["output"][1] = {
                "type": "function_call",
                "id": "fc_synthetic",
                "call_id": "call_synthetic",
                "name": "Answer",
                "arguments": text,
                "status": "completed",
            }
        else:
            payload["output"][1]["content"][0]["text"] = text
    else:
        choice = payload["choices"][0]
        choice["finish_reason"] = (
            ("tool_calls" if method == "function_calling" else "stop")
            if complete
            else "length"
        )
        choice["message"]["content"] = text
        if method == "function_calling":
            choice["message"]["content"] = None
            choice["message"]["tool_calls"] = [
                {
                    "id": "call_synthetic",
                    "type": "function",
                    "function": {"name": "Answer", "arguments": text},
                }
            ]
    return payload


def handler_for(payload, sources=None):
    def handle(request):
        if json.loads(request.content).get("stream"):
            source = WireStream(response_events(payload))
            if sources is not None:
                sources.append(source)
            return wire_response(source)
        return httpx2.Response(200, json=deepcopy(payload))

    return Mock(side_effect=handle)


def events_for(method="json_mode", text='{"answer":"Hello"}', finish=None):
    events = []
    for index, part in enumerate((text[:9], text[9:])):
        delta = {"content": part}
        if method == "function_calling":
            tool = {"index": 0, "function": {"arguments": part}}
            if not index:
                tool.update(id="call_synthetic", type="function")
                tool["function"]["name"] = "Answer"
            delta = {"tool_calls": [tool]}
        events.append(chunk([choice(delta)]))
    events.extend(
        text_events(
            "", finish or ("tool_calls" if method == "function_calling" else "stop")
        )[1:]
    )
    return events
