"""Default corporate acceptance of standard public LangChain usage."""

import pytest

from tests.support.standard_usage.socgenai_llm import CASES


pytestmark = pytest.mark.azure


@pytest.mark.parametrize("case", CASES)
def test_standard_usage(standard_acceptance, case):
    standard_acceptance("socgenai_llm", case)
