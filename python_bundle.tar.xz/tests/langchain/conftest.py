"""LangChain-only model wiring and Windows-safe asyncio fixtures."""

import asyncio
import socket
import pytest
import pytest_socket
from langsmith import tracing_context
from socgenai_llm import GenAIChatModel, chat_model


@pytest.fixture
def async_loop(monkeypatch):
    # Windows asyncio needs a loopback socketpair to wake its event loop.
    # Permit only that setup, before any request worker exists. Test execution
    # and executor workers still run with pytest-socket's construction guard.
    original = pytest_socket._true_socket
    connect = original.connect

    def local_connect(sock, address):
        if address[0] not in ("127.0.0.1", "::1"):
            raise AssertionError("Only event-loop loopback setup is allowed")
        return connect(sock, address)

    with monkeypatch.context() as setup:
        setup.setattr(socket, "socket", original)
        setup.setattr(original, "connect", local_connect)
        loop = asyncio.new_event_loop()
    try:
        yield loop
    finally:
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.run_until_complete(loop.shutdown_default_executor())
        loop.close()


@pytest.fixture
def wrapper(make_client, monkeypatch):
    models = []

    def create(handler, *, internal=False, pricing_data=None, **kwargs):
        def construct(**manager_options):
            return make_client(
                handler,
                internal_streaming=internal,
                pricing_data=pricing_data,
                manager_options=manager_options,
            )

        monkeypatch.setattr(chat_model, "GenAiApiClient", construct)
        model = GenAIChatModel(model="deployment", **kwargs)
        models.append(model)
        return model, model.client

    with tracing_context(enabled=False):
        yield create
    for model in models:
        model.close()
