"""Synthetic image/PDF provider replies shared by the manager and probe tests."""

import httpx2

from tests.support.multimodal_inputs import EXPECTED
from tests.support.azure import (
    WireStream,
    chat_payload,
    chunk,
    choice,
    response_payload,
    wire_response,
)


PRICES = {
    "deployment": {
        "input": "1",
        "cached_input": "0.2",
        "cache_write": "1.25",
        "output": "3",
    }
}


def provider_result(
    api, case, streaming, *, missing_usage=False, missing_cache_write=False
):
    text = EXPECTED[case]
    payload = chat_payload() if api == "chat" else response_payload()
    if api == "chat":
        payload["choices"][0]["message"]["content"] = text
        details = "prompt_tokens_details"
    else:
        payload["output"][0]["content"][0]["text"] = text
        details = "input_tokens_details"
    payload["usage"][details] = {"cached_tokens": 600, "cache_write_tokens": 300}
    if missing_cache_write:
        del payload["usage"][details]["cache_write_tokens"]
    if missing_usage:
        payload["usage"] = None
    if not streaming:
        return httpx2.Response(200, json=payload), None
    if api == "chat":
        events = [
            chunk([choice({"role": "assistant", "content": text[:4]})]),
            chunk([choice({"content": text[4:]})]),
            chunk([choice({}, finish="stop")]),
            chunk([], usage=payload["usage"]),
        ]
    else:
        events = [
            {
                "type": "response.output_text.delta",
                "sequence_number": 0,
                "item_id": "msg_synthetic",
                "output_index": 0,
                "content_index": 0,
                "delta": text,
            },
            {"type": "response.completed", "sequence_number": 1, "response": payload},
        ]
    source = WireStream(events, named=api == "responses")
    return wire_response(source), source
