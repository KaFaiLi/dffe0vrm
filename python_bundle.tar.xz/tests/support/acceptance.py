"""Corporate acceptance through normal public constructors and trusted config."""

from contextlib import ExitStack
import json
import logging
import os

import pytest

from tests.support.standard_usage.common import execute_case, safe_error


DEFAULT_CHAT_DEPLOYMENT = "5.6-luna"


@pytest.fixture
def standard_acceptance(record_property):
    """Return a runner that exports safe reports to optional pytest JUnit XML."""

    def run(suite, case):
        embedding = case.startswith("embedding")
        variable = (
            "GENAI_AZURE_EMBEDDING_DEPLOYMENT"
            if embedding
            else "GENAI_AZURE_CHAT_DEPLOYMENT"
        )
        model = os.environ.get(variable, None if embedding else DEFAULT_CHAT_DEPLOYMENT)
        if not model:
            if embedding:
                pytest.skip(
                    "Set GENAI_AZURE_EMBEDDING_DEPLOYMENT to include embeddings"
                )
            pytest.fail(
                "Set GENAI_AZURE_CHAT_DEPLOYMENT to an approved deployment",
                pytrace=False,
            )
        for name in ("openai", "httpx2", "httpcore", "httpcore2"):
            logging.getLogger(name).setLevel(logging.CRITICAL)
        try:
            with ExitStack() as resources:
                if suite == "genai_api_manager":
                    from genai_api_manager import GenAiApiClient

                    manager = resources.enter_context(GenAiApiClient())
                    wrapper = None
                else:
                    from langsmith import tracing_context
                    from socgenai_llm import GenAIChatModel, GenAIEmbeddings

                    resources.enter_context(tracing_context(enabled=False))
                    wrapper = (
                        GenAIEmbeddings(model=model, encoding_format="float")
                        if embedding
                        else GenAIChatModel(model=model, cache=False)
                    )
                    manager = wrapper.client
                    resources.callback(manager.close)
                expected = os.environ.get("GENAI_EXPECT_INTERNAL_STREAMING")
                if expected not in (None, "true", "false"):
                    raise ValueError("Invalid expected transport setting")
                if expected is not None and manager.internal_streaming is not (
                    expected == "true"
                ):
                    raise ValueError("Unexpected trusted transport setting")
                report = execute_case(
                    manager,
                    suite,
                    case,
                    model,
                    wrapper=wrapper,
                    reasoning_effort=os.environ.get("GENAI_AZURE_REASONING_EFFORT"),
                )
        except Exception as error:
            report = {
                "suite": suite,
                "case": case,
                "success": False,
                "error": safe_error(error),
            }
        report.update(environment="internal-azure", billing_verified=False)
        record_property("standard_report", json.dumps(report))
        if not report["success"]:
            pytest.fail(json.dumps(report, indent=2), pytrace=False)
        return report

    return run
