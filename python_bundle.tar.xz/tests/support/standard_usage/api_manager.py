"""Standard usage of the public GenAiApiClient methods."""

from openai.types import CreateEmbeddingResponse
from openai.types.chat import ChatCompletion, ChatCompletionChunk
from openai.types.responses import Response

from .common import PROMPT, OUTPUT_LIMIT, TIMEOUT, valid_vectors


CASES = (
    "chat-default",
    "chat-native",
    "chat-stream",
    "responses-default",
    "responses-native",
    "responses-stream",
    "embeddings",
)


def exercise(manager, case, model, *, reasoning_effort=None):
    """Make one bounded request and inspect its public result in memory."""
    if case == "embeddings":
        result = manager.get_genai_embeddings(
            model=model, input=PROMPT, encoding_format="float", timeout=TIMEOUT
        )
        vectors = [item.embedding for item in result.data]
        return {
            "result_valid": isinstance(result, CreateEmbeddingResponse)
            and valid_vectors(vectors, 1),
            "return_type": type(result).__name__,
            "embedding_dimensions": [len(vector) for vector in vectors],
        }
    api, mode = case.split("-", 1)
    options = {"model": model, "timeout": TIMEOUT}
    if mode != "default":
        options["stream"] = mode == "stream"
    if api == "chat":
        options.update(prompt=PROMPT, max_completion_tokens=OUTPUT_LIMIT)
        if reasoning_effort is not None:
            options["reasoning_effort"] = reasoning_effort
        result = manager.get_genai_completion(**options)
    else:
        options.update(input=PROMPT, max_output_tokens=OUTPUT_LIMIT, store=False)
        if reasoning_effort is not None:
            options["reasoning"] = {"effort": reasoning_effort}
        result = manager.get_genai_response(**options)
    text, completed, count, types_valid = [], False, 0, True
    if mode == "stream":
        with result:
            for event in result:
                count += 1
                if api == "chat":
                    types_valid &= isinstance(event, ChatCompletionChunk)
                    for choice in event.choices:
                        text.append(choice.delta.content or "")
                        if choice.finish_reason is not None:
                            completed = choice.finish_reason == "stop"
                else:
                    types_valid &= callable(getattr(event, "model_dump", None))
                    if event.type == "response.output_text.delta":
                        text.append(event.delta)
                    elif event.type.startswith("response.") and hasattr(
                        event, "response"
                    ):
                        completed = event.response.status == "completed"
    elif api == "chat":
        types_valid = isinstance(result, ChatCompletion)
        completed = result.choices[0].finish_reason == "stop"
        text.append(result.choices[0].message.content or "")
    else:
        types_valid = isinstance(result, Response)
        completed = result.status == "completed"
        text.append(result.output_text)
    return {
        "result_valid": types_valid
        and completed
        and "".join(text).strip().lower().rstrip(".! ") == "hello",
        "return_type": type(result).__name__,
        "stream_events": count,
    }
