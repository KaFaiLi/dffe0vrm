"""Shared safe reports; production clients and audit policy remain unchanged."""

import base64
from dataclasses import asdict
from datetime import datetime, timezone
from decimal import Decimal
from importlib.metadata import version
import json
import math
import platform
from pathlib import Path
import time
from unittest.mock import patch

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from openai import APIError

from genai_api_manager.accounting import Usage


PROMPT = "Reply with exactly the single word hello."
OUTPUT_LIMIT = 128
TIMEOUT = 45.0
CORE_CASES = (
    "chat-default",
    "chat-native",
    "chat-stream",
    "responses-default",
    "responses-native",
    "responses-stream",
)


def safe_error(error):
    result = {"type": type(error).__name__}
    if isinstance(error, APIError):
        result["http_status"] = getattr(error, "status_code", None)
    return result


def valid_vectors(vectors, expected):
    return (
        len(vectors) == expected
        and all(vectors)
        and len({len(vector) for vector in vectors}) == 1
        and all(math.isfinite(value) for vector in vectors for value in vector)
        and all(any(vector) for vector in vectors)
    )


def selected_cases(suite, *, embedding_model=None, case=None):
    if suite == "genai_api_manager":
        from .api_manager import CASES
    elif suite == "socgenai_llm":
        from .socgenai_llm import CASES
    else:
        raise ValueError("Unknown standard test suite")
    if case is not None:
        if case not in CASES:
            raise ValueError("Case is not supported by the selected suite")
        if case.startswith("embedding") and not embedding_model:
            raise ValueError("Embedding cases require --embedding-model")
        return (case,)
    return tuple(item for item in CASES if embedding_model or item in CORE_CASES)


def _decrypt(event, field):
    shared = base64.b64decode(event["shared_key"], validate=True)
    key = HKDF(
        algorithm=hashes.SHA256(), length=32, salt=None, info=b"ecies encryption"
    ).derive(shared)
    raw = base64.b64decode(event[field], validate=True)
    return AESGCM(key).decrypt(raw[:12], raw[28:] + raw[12:28], None).decode()


def _audit_check(logger, previous_path, offset, ids, model, operation, usage, charge):
    path = Path(logger._get_daily_log_path())
    with path.open("rb") as source:
        source.seek(offset if path == previous_path else 0)
        rows = [json.loads(line) for line in source if line.strip()]
    rows = [
        row
        for row in rows
        if row.get("model_name") == model
        and row.get("operation") == operation
        and (not ids or row.get("request_id") in ids)
    ]
    if len(rows) != 1:
        return {"audit_count": len(rows), "audit_valid": False}
    event = rows[0]
    encrypted = (
        bool(_decrypt(event, "prompt"))
        and bool(_decrypt(event, "completion"))
        and "ephemeral_public_key" not in event
        and "encryption_version" not in event
    )
    counts_match = all(
        event.get(field) == getattr(usage, attribute)
        for field, attribute in (
            ("input_token", "input_tokens"),
            ("output_token", "output_tokens"),
            ("cached_input_token", "cached_input_tokens"),
            ("cache_write_token", "cache_write_tokens"),
        )
    )
    cost_matches = (
        charge.total is not None
        and event.get("total_cost") is not None
        and (abs(Decimal(str(event["total_cost"])) - charge.total) <= Decimal("1e-12"))
    )
    return {
        "audit_count": 1,
        "audit_valid": encrypted
        and counts_match
        and cost_matches
        and event.get("status") == "completed"
        and event.get("cost_status") == charge.status,
        "encryption_verified": encrypted,
        "audit_correlated": bool(ids),
    }


def execute_case(manager, suite, case, model, *, wrapper=None, reasoning_effort=None):
    """Inspect one real request and its new audit event, exporting metadata only.

    The SDK transport hooks and dispatch observer are test-only instrumentation.
    The existing transport, authentication, proxy, accounting and writer are used.
    Each case owns its manager and closes it before checking persistence.
    """
    report = {
        "suite": suite,
        "case": case,
        "model": model,
        "success": False,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "currency": "EUR",
        "rate_unit": 1000,
        "error": None,
        "cleanup_error": None,
        "runtime": runtime_manifest(suite),
        "api_version": "v1",
    }
    sdk, logger = manager._openai_client, manager.log_manager
    operation = (
        "embeddings"
        if case.startswith("embedding")
        else ("responses" if case.startswith("responses") else "chat.completions")
    )
    before = logger.get_metrics()
    path = Path(logger._get_daily_log_path())
    offset = path.stat().st_size if path.exists() else 0
    attempts, response_ids, observed = [], set(), []
    http = sdk._client
    previous_hooks = http.event_hooks
    expected_stream = operation != "embeddings" and (
        case.endswith("-stream")
        or (case.endswith("-default") and manager.internal_streaming)
    )

    def request_hook(request):
        body = json.loads(request.content)
        attempts.append(
            {
                "route_valid": request.url.path.endswith(
                    "/openai/v1/" + operation.replace(".", "/")
                )
                and "api-version" not in request.url.params,
                "model_valid": body.get("model") == model,
                "stream": bool(body.get("stream")),
            }
        )

    def response_hook(response):
        value = response.headers.get("x-request-id")
        if value:
            response_ids.add(value)

    original_dispatch = manager._dispatch

    def dispatch(*args, **kwargs):
        result = original_dispatch(*args, **kwargs)
        observed.append(result)
        return result

    started = time.monotonic()
    try:
        sdk.max_retries = 0
        sdk.timeout = TIMEOUT
        logger.require_priced_model(model)
        if case == "embedding-documents":
            # Tokenizer vocabularies must already be cached. Acceptance must
            # never contact a public tokenizer download service.
            import tiktoken

            with patch(
                "tiktoken.load.read_file",
                side_effect=RuntimeError(
                    "Preload the approved tokenizer cache before acceptance"
                ),
            ):
                try:
                    tiktoken.encoding_for_model(model)
                except KeyError:
                    pass  # The real wrapper uses its existing plain-text fallback.
        http.event_hooks = {
            "request": [*previous_hooks.get("request", []), request_hook],
            "response": [*previous_hooks.get("response", []), response_hook],
        }
        with patch.object(manager, "_dispatch", side_effect=dispatch):
            if suite == "genai_api_manager":
                from .api_manager import exercise

                report.update(
                    exercise(manager, case, model, reasoning_effort=reasoning_effort)
                )
            elif suite == "socgenai_llm":
                from .socgenai_llm import exercise

                report.update(
                    exercise(wrapper, case, model, reasoning_effort=reasoning_effort)
                )
            else:
                raise ValueError("Unknown standard test suite")
    except Exception as error:
        report["error"] = safe_error(error)
    finally:
        report["request_seconds"] = time.monotonic() - started
        closing = time.monotonic()
        try:
            manager.close()
        except Exception as error:
            report["cleanup_error"] = safe_error(error)
        report["cleanup_seconds"] = time.monotonic() - closing
        http.event_hooks = previous_hooks
    report.update(
        attempts=len(attempts),
        api_operation=operation,
        transport_stream=expected_stream,
        internal_streaming=manager.internal_streaming,
    )
    try:
        raw = observed[-1] if observed else None
        for attribute in ("id", "_request_id"):
            value = getattr(raw, attribute, None)
            if value:
                response_ids.add(value)
        usage = Usage.from_sdk(
            getattr(raw, "usage", getattr(raw, "_usage", None)), operation
        )
        charge = logger._price_book.quote(model, usage)
        after = logger.get_metrics()
        report.update(
            usage=asdict(usage),
            cost=str(charge.total) if charge.total is not None else None,
            cost_status=charge.status,
            logger_metrics={
                key: after[key]
                for key in (
                    "written_events",
                    "dropped_events",
                    "write_errors",
                    "enqueue_errors",
                    "queue_size",
                    "writer_alive",
                )
            },
        )
        if observed:
            report.update(
                _audit_check(
                    logger, path, offset, response_ids, model, operation, usage, charge
                )
            )
        ledger_delta = Decimal(after["daily_cost_exact"]) - Decimal(
            before["daily_cost_exact"]
        )
        report["recorded_cost_delta"] = str(ledger_delta)
        langchain_usage = report.get("langchain_usage")
        wrapper_usage_valid = langchain_usage is None or (
            langchain_usage["input_tokens"] == usage.input_tokens
            and langchain_usage["output_tokens"] == usage.output_tokens
        )
        report["success"] = (
            report["error"] is None
            and report["cleanup_error"] is None
            and report.get("result_valid", False)
            and report.get("audit_valid", False)
            and len(attempts) == 1
            and all(
                item["route_valid"]
                and item["model_valid"]
                and item["stream"] == expected_stream
                for item in attempts
            )
            and usage.input_tokens is not None
            and usage.output_tokens is not None
            and charge.total is not None
            and ledger_delta == charge.total
            and wrapper_usage_valid
            and after["written_events"] - before["written_events"] == 1
            and all(
                after[key] == before[key]
                for key in ("dropped_events", "write_errors", "enqueue_errors")
            )
            and after["queue_size"] == 0
            and not after["writer_alive"]
        )
    except Exception as error:
        report["verification_error"] = safe_error(error)
    return report


def runtime_manifest(suite):
    packages = ["genai-api-manager", "openai"]
    if suite == "socgenai_llm":
        packages.extend(["socgenai-llm", "langchain-core", "langchain-openai"])
    return {
        "python": platform.python_version(),
        "os": platform.system(),
        "packages": {package: version(package) for package in packages},
    }
