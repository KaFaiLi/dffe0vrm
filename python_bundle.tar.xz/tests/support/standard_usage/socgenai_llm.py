"""Standard usage of the public LangChain chat and embeddings interfaces."""

from contextlib import closing

from langchain_core.messages import AIMessage, AIMessageChunk

from .common import PROMPT, OUTPUT_LIMIT, TIMEOUT, valid_vectors


CASES = (
    "chat-default",
    "chat-native",
    "chat-stream",
    "responses-default",
    "responses-native",
    "responses-stream",
    "embedding-query",
    "embedding-documents",
)


def exercise(wrapper, case, model, *, reasoning_effort=None):
    """Use invoke/stream/embed methods without exposing captured content."""
    if case.startswith("embedding-"):
        if case == "embedding-query":
            result = wrapper.embed_query(PROMPT)
            vectors, expected = [result], 1
        else:
            result = wrapper.embed_documents([PROMPT, "Hello world."])
            vectors, expected = result, 2
        return {
            "result_valid": valid_vectors(vectors, expected),
            "return_type": type(result).__name__,
            "embedding_dimensions": [len(vector) for vector in vectors],
        }
    api, mode = case.split("-", 1)
    options = {
        "use_responses_api": api == "responses",
        "max_completion_tokens": OUTPUT_LIMIT,
        "timeout": TIMEOUT,
    }
    if reasoning_effort is not None:
        options["reasoning_effort"] = reasoning_effort
    if mode == "native":
        options["stream"] = False
    count, result = 0, None
    if mode == "stream":
        with closing(wrapper.stream(PROMPT, **options)) as chunks:
            for chunk in chunks:
                if not isinstance(chunk, AIMessageChunk):
                    raise TypeError("Unexpected LangChain chunk type")
                count += 1
                result = chunk if result is None else result + chunk
    else:
        result = wrapper.invoke(PROMPT, **options)
    usage = result.usage_metadata if isinstance(result, AIMessage) else None
    return {
        "result_valid": isinstance(result, AIMessage)
        and result.text.strip().lower().rstrip(".! ") == "hello"
        and usage is not None,
        "return_type": type(result).__name__,
        "stream_events": count,
        "langchain_usage": {
            key: usage.get(key)
            for key in ("input_tokens", "output_tokens", "total_tokens")
        }
        if usage is not None
        else None,
    }
