"""Self-contained standard public usage and verification for corporate tests."""
