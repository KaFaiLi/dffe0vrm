"""Construct the production client with synthetic configuration and real SDK."""

import json
import time
from types import SimpleNamespace

import httpx2
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from openai import OpenAI
from openai import _base_client

from genai_api_manager import GenAiApiClient
from genai_api_manager import genai_api_client as client_module
from genai_api_manager.api import azure as azure_module


@pytest.fixture
def retry_delays(monkeypatch):
    """Exercise SDK retry/backoff decisions without waiting or changing global time."""
    delays = []
    monkeypatch.setattr(
        _base_client, "time", SimpleNamespace(time=time.time, sleep=delays.append)
    )
    return delays


@pytest.fixture
def make_client(tmp_path, monkeypatch):
    clients = []
    private_key = ec.generate_private_key(ec.SECP256R1())
    public = (
        private_key.public_key()
        .public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
        )
        .decode()
    )
    monkeypatch.setattr(
        client_module,
        "ClientSecretCredential",
        lambda *args: SimpleNamespace(close=lambda: None),
    )
    monkeypatch.setattr(
        client_module,
        "get_bearer_token_provider",
        lambda *args: lambda: "synthetic-token",
    )
    monkeypatch.setattr(client_module.os, "getlogin", lambda: "tester")
    monkeypatch.setattr(
        GenAiApiClient,
        "_resolve_path_with_onedrive_fallback",
        lambda self, primary_path, **kwargs: primary_path,
    )
    monkeypatch.setattr(
        GenAiApiClient, "_load_credentials", lambda *args: {"Public_Key": public}
    )

    def create(
        handler,
        pricing_aliases=None,
        pricing_data=None,
        internal_streaming=False,
        endpoint="https://synthetic.openai.azure.com",
        manager_options=None,
        **sdk_options,
    ):
        directory = tmp_path / str(len(clients))
        config = {
            "userinfo_url": "https://example.invalid/userinfo",
            "azure_openai_endpoint": endpoint,
            "llm_token_path": str(directory),
            "llm_log_path": str(directory),
            "pricing_file": str(directory / "pricing.json"),
            "pricing_aliases": pricing_aliases,
        }
        # Ellipsis omits the flag to exercise the production configuration default.
        if internal_streaming is not ...:
            config["internal_streaming"] = internal_streaming
        monkeypatch.setattr(client_module, "load_config", lambda: config)
        monkeypatch.setattr(
            client_module,
            "load_pricing",
            lambda path: (
                pricing_data
                if pricing_data is not None
                else {
                    "deployment": {"input": "1", "cached_input": "0.2", "output": "3"},
                }
            ),
        )

        def construct(sdk_type):
            return lambda **kwargs: sdk_type(
                **{
                    "max_retries": 0,
                    **kwargs,
                    "http_client": httpx2.Client(
                        transport=httpx2.MockTransport(handler)
                    ),
                    **sdk_options,
                },
            )

        monkeypatch.setattr(azure_module, "OpenAI", construct(OpenAI))
        client = GenAiApiClient(daily_cost_limit=100, **(manager_options or {}))
        clients.append(client)
        return client

    yield create
    for client in clients:
        client.close()


def audit_events(client):
    client.log_manager.close()
    with open(client.log_manager._get_daily_log_path(), encoding="utf-8") as source:
        return [
            event for line in source if (event := json.loads(line)).get("model_name")
        ]
