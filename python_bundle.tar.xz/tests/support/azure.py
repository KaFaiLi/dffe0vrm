"""Synthetic Azure payloads and SSE transports shared by both test suites."""

import json
import httpx2


def chat_payload():
    return {
        "id": "chatcmpl-synthetic",
        "object": "chat.completion",
        "created": 1,
        "model": "deployment",
        "choices": [
            {
                "index": 0,
                "finish_reason": "stop",
                "message": {"role": "assistant", "content": "Hello"},
            }
        ],
        "usage": {
            "prompt_tokens": 1000,
            "completion_tokens": 200,
            "total_tokens": 1200,
            "prompt_tokens_details": {"cached_tokens": 600},
        },
    }


def embedding_payload(model="deployment"):
    return {
        "object": "list",
        "model": model,
        "data": [{"object": "embedding", "index": 0, "embedding": [0.1, 0.2]}],
        "usage": {"prompt_tokens": 10, "total_tokens": 10},
    }


def response_payload(status="completed"):
    return {
        "id": "resp_synthetic",
        "object": "response",
        "created_at": 1,
        "model": "deployment",
        "status": status,
        "error": None,
        "incomplete_details": {"reason": "max_output_tokens"}
        if status == "incomplete"
        else None,
        "output": [
            {
                "type": "message",
                "id": "msg_synthetic",
                "role": "assistant",
                "status": "completed",
                "content": [
                    {"type": "output_text", "text": "Hello", "annotations": []}
                ],
            }
        ],
        "usage": {
            "input_tokens": 1000,
            "output_tokens": 200,
            "total_tokens": 1200,
            "input_tokens_details": {"cached_tokens": 600},
            "output_tokens_details": {"reasoning_tokens": 10},
        },
    }


class EventBytes(httpx2.SyncByteStream):
    def __init__(self, events, error=None):
        self.events = events
        self.produced = 0
        self.closed = False
        self.error = error

    def __iter__(self):
        for event in self.events:
            self.produced += 1
            data = ("data: " + json.dumps(event) + "\n\n").encode()
            # Splits inside SSE framing and JSON must still decode correctly.
            yield data[:7]
            yield data[7:]
        if self.error:
            raise self.error
        yield b"data: [DONE]\n\n"

    def close(self):
        self.closed = True


class WireStream(httpx2.SyncByteStream):
    def __init__(self, events, *, done=True, error=None, named=False):
        self.events = events
        self.done = done
        self.error = error
        self.named = named
        self.reads = 0
        self.closed = False

    def __iter__(self):
        yield b": heartbeat\n\n"
        for event in self.events:
            self.reads += 1
            prefix = f"event: {event['type']}\n" if self.named else ""
            data = (
                prefix + "data: " + json.dumps(event, ensure_ascii=False) + "\n\n"
            ).encode()
            # Exercise partial UTF-8 and SSE boundaries, not just parsed objects.
            for offset in range(0, len(data), 3):
                yield data[offset : offset + 3]
        if self.error:
            raise self.error
        if self.done:
            yield b"data: [DONE]\n\n"

    def close(self):
        self.closed = True


def chunk(choices, **extra):
    return {
        "id": "chatcmpl-synthetic",
        "object": "chat.completion.chunk",
        "created": 1,
        "model": "deployment",
        "choices": choices,
        **extra,
    }


def choice(delta=None, *, index=0, finish=None, **extra):
    result = {"index": index, "finish_reason": finish, **extra}
    if delta is not None:
        result["delta"] = delta
    return result


def text_events(text="Hello", finish="stop", usage=True):
    events = [
        chunk([choice({"role": "assistant", "content": text})]),
        chunk([choice({}, finish=finish)]),
    ]
    if usage:
        events.append(chunk([], usage=chat_payload()["usage"]))
    return events


def wire_response(source):
    return httpx2.Response(
        200,
        headers={
            "content-type": "text/event-stream",
            "x-request-id": "request-synthetic",
        },
        stream=source,
    )


def tool(index, *, id=None, name=None, arguments=None):
    result = {"index": index, "function": {}}
    if id is not None:
        result.update(id=id, type="function")
    if name is not None:
        result["function"]["name"] = name
    if arguments is not None:
        result["function"]["arguments"] = arguments
    return result
