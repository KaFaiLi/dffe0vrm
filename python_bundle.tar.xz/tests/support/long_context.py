"""Synthetic long-context Azure wire fixtures, independent of local probes."""

import httpx2
from tests.support.azure import (
    WireStream,
    chat_payload,
    embedding_payload,
    response_payload,
    text_events,
    wire_response,
)


PRICING = {
    "priced": {
        "input": "1",
        "cached_input": "0.2",
        "cache_write": "1.25",
        "output": "3",
        "long_context": {
            "input_tokens_above": 272000,
            "input": "2",
            "cached_input": "0.4",
            "cache_write": "2.5",
            "output": "4.5",
        },
    }
}


def provider_result(operation, mode, inputs, *, missing=False):
    if operation == "embeddings":
        payload = embedding_payload()
    elif operation == "responses":
        payload = response_payload()
    else:
        payload = chat_payload()
    usage = payload["usage"]
    usage["input_tokens" if operation == "responses" else "prompt_tokens"] = inputs
    outputs = 0 if operation == "embeddings" else 200
    usage["total_tokens"] = inputs + outputs
    if operation != "embeddings":
        usage[
            "input_tokens_details"
            if operation == "responses"
            else "prompt_tokens_details"
        ].update(cached_tokens=200000, cache_write_tokens=20000)
    if missing:
        payload["usage"] = None
    if mode == "native":
        return httpx2.Response(200, json=payload)
    if operation == "chat":
        events = text_events(usage=False)
        events.append(
            {
                "id": payload["id"],
                "object": "chat.completion.chunk",
                "created": 1,
                "model": "deployment",
                "choices": [],
                "usage": payload["usage"],
            }
        )
    else:
        events = [
            {"type": "response.completed", "sequence_number": 0, "response": payload}
        ]
    return wire_response(WireStream(events))
