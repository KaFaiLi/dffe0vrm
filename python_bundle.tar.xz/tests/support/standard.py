"""Synthetic wire replies for the shared standard acceptance cases."""

import json

import httpx2

from tests.support.azure import (
    WireStream,
    chat_payload,
    response_payload,
    embedding_payload,
    chunk,
    choice,
    wire_response,
)


PRICES = {
    "deployment": {
        "input": "1",
        "cached_input": "0.2",
        "cache_write": "1.25",
        "output": "3",
    },
    "embedding-deployment": {"input": "1", "output": "0"},
}


def standard_handler(*, sources=None, missing_usage=False, incomplete=False):
    def handle(request):
        body = json.loads(request.content)
        if request.url.path.endswith("/embeddings"):
            payload = embedding_payload(body["model"])
            inputs = body["input"]
            if isinstance(inputs, list) and len(inputs) == 2:
                payload["data"].append({**payload["data"][0], "index": 1})
        elif request.url.path.endswith("/chat/completions"):
            payload = chat_payload()
            payload["usage"]["prompt_tokens_details"]["cache_write_tokens"] = 0
            if incomplete:
                payload["choices"][0]["finish_reason"] = "length"
        else:
            payload = response_payload("incomplete" if incomplete else "completed")
            payload["usage"]["input_tokens_details"]["cache_write_tokens"] = 0
        payload["model"] = body["model"]
        if missing_usage:
            payload["usage"] = None
        if not body.get("stream"):
            return httpx2.Response(
                200, json=payload, headers={"x-request-id": "request-synthetic"}
            )
        if request.url.path.endswith("/chat/completions"):
            events = [
                chunk([choice({"role": "assistant", "content": "Hello"})]),
                chunk([choice({}, finish="length" if incomplete else "stop")]),
                chunk([], usage=payload["usage"]),
            ]
        else:
            message = payload["output"][0]
            part = message["content"][0]
            common = {"item_id": message["id"], "output_index": 0, "content_index": 0}
            events = [
                {
                    "type": "response.created",
                    "response": {
                        **payload,
                        "status": "in_progress",
                        "output": [],
                        "usage": None,
                    },
                },
                {
                    "type": "response.output_item.added",
                    "output_index": 0,
                    "item": {**message, "content": []},
                },
                {
                    "type": "response.content_part.added",
                    **common,
                    "part": {**part, "text": ""},
                },
                {"type": "response.output_text.delta", **common, "delta": "Hello"},
                {"type": "response.output_text.done", **common, "text": "Hello"},
                {"type": "response.content_part.done", **common, "part": part},
                {
                    "type": "response.output_item.done",
                    "output_index": 0,
                    "item": message,
                },
                {"type": "response." + payload["status"], "response": payload},
            ]
            events = [
                {**event, "sequence_number": index}
                for index, event in enumerate(events)
            ]
        source = WireStream(events, named=request.url.path.endswith("/responses"))
        if sources is not None:
            sources.append(source)
        return wire_response(source)

    return handle
