"""Small deterministic PNG/PDF inputs for offline contracts and opt-in probes."""

import base64
import struct
import zlib


CASES = ("text", "image", "pdf", "image-pdf")
EXPECTED = {
    "text": "hello",
    "image": "blue circle",
    "pdf": "ORBIT-417",
    "image-pdf": "image=blue circle; pdf=ORBIT-417",
}
PROMPTS = {
    "text": "Reply with exactly the single word hello.",
    "image": (
        "Identify the non-white shape and its color in the attached image. "
        "Reply with exactly two lowercase words: color then shape."
    ),
    "pdf": "Read the verification code in the attached PDF. Reply with only that code.",
    "image-pdf": (
        "Identify the non-white shape and its color in the image, and read the "
        "verification code in the PDF. Reply using exactly this format: "
        "image=<lowercase color and shape>; pdf=<verification code>"
    ),
}


def image_bytes():
    """384x384 white PNG with a blue circle; no text or answer-bearing filename."""
    width = 384
    rows = bytearray()
    for y in range(width):
        rows.append(0)  # PNG filter: none.
        for x in range(width):
            rows.extend(
                (0, 64, 255)
                if (x - 192) ** 2 + (y - 192) ** 2 <= 100**2
                else (255, 255, 255)
            )

    def chunk(kind, data):
        return (
            struct.pack(">I", len(data))
            + kind
            + data
            + struct.pack(">I", zlib.crc32(kind + data))
        )

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, width, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(rows))
        + chunk(b"IEND", b"")
    )


def pdf_bytes():
    """One page with large, extractable text, valid lengths and xref offsets."""
    content = (
        b"BT /F1 22 Tf 30 130 Td (Verification code:) Tj 0 -40 Td (ORBIT-417) Tj ET"
    )
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 200] "
        b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(content)} >>\nstream\n".encode() + content + b"\nendstream",
    ]
    result = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for number, body in enumerate(objects, 1):
        offsets.append(len(result))
        result.extend(f"{number} 0 obj\n".encode() + body + b"\nendobj\n")
    xref = len(result)
    result.extend(f"xref\n0 {len(offsets)}\n0000000000 65535 f \n".encode())
    for offset in offsets[1:]:
        result.extend(f"{offset:010} 00000 n \n".encode())
    result.extend(
        f"trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    )
    return bytes(result)


def request_for(operation, model, case):
    """Use each API's own content schema, with inline data and bounded output."""
    if operation not in ("chat", "responses") or case not in CASES:
        raise ValueError("Unsupported multimodal case or API")
    responses = operation == "responses"
    content = [{"type": "input_text" if responses else "text", "text": PROMPTS[case]}]
    if "image" in case:
        data = "data:image/png;base64," + base64.b64encode(image_bytes()).decode()
        content.append(
            {"type": "input_image", "image_url": data, "detail": "low"}
            if responses
            else {"type": "image_url", "image_url": {"url": data, "detail": "low"}}
        )
    if "pdf" in case:
        file = {
            "filename": "sample.pdf",
            "file_data": "data:application/pdf;base64,"
            + base64.b64encode(pdf_bytes()).decode(),
        }
        content.append(
            {"type": "input_file", **file}
            if responses
            else {"type": "file", "file": file}
        )
    return {
        "model": model,
        "input" if responses else "messages": [{"role": "user", "content": content}],
        "max_output_tokens" if responses else "max_completion_tokens": 128,
        **(
            {"reasoning": {"effort": "none"}, "store": False}
            if responses
            else {"reasoning_effort": "none", "store": False}
        ),
    }
